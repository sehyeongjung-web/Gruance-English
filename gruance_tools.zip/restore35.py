# -*- coding: utf-8 -*-
# 306번: 35번(무관한 문장) 레벨1~3을 「줄이기 전」 지문으로 되돌리기 위한 자료
# - data_restore35.json = GitHub 커밋 b69bf91(290번까지)의 35번 레벨1·2·3 서른 문항씩(지문·해석·풀이·해설)
# - snapshot()은 그 위에, 그사이 찾은 탈 넷을 고친 것을 돌려줌
import json, os, copy
_HERE = os.path.dirname(os.path.abspath(__file__))
FIXES = [
 # (레벨, 번째-1, [(옛, 새), ...])  — 지문·해석·풀이·해설 어디에 있든 모두 바꿈
 ('3', 11, [('어떤 씨앗은 불이나 동물 위의 산이 필요하다.', '어떤 씨앗은 불이나 동물의 위산이 필요하다.')]),          # 299번: 「동물 위에 있는 산」으로 읽힘
 ('3', 13, [('벌은 꿀샘 때문에 꽃을 찾고 다른 이유는 없다.', '벌은 꽃꿀을 얻으려고 꽃을 찾고 다른 이유는 없다.'),      # 299번: nectar는 꿀샘이 아니라 꽃꿀
            ('nectar 꿀 /', 'nectar 꽃꿀 /')]),
 ('3', 22, [('Bakeries in most towns begin work between two and four.', 'Sliced bread was first sold in the United States in 1928.'),   # 299·301번: 3번째의 무관한 문장과 겹침
            ('대부분의 마을에서 빵집은 2시에서 4시 사이에 일을 시작한다.', '썬 식빵은 1928년에 미국에서 처음 팔렸다.'),
            ('빵집의 작업 시작 시각은 빵이 굳는 원리와 무관해요.', '썬 식빵이 처음 팔린 해는 빵이 굳는 원리와 무관해요.')]),
 ('2', 26, [('Garden centres sell frost cloth in several weights.', 'Garden centres are at their busiest in the spring.'),            # 303번: 서리 방지 천 = 서리를 막는 방법으로도 읽힘
            ('원예 용품점은 여러 두께의 서리 방지 천을 판다.', '원예 용품점은 봄에 가장 바쁘다.'),
            ('서리 방지 천의 판매는 서리가 세포를 해치는 원리와 관계가 없어요.', '원예 용품점이 언제 바쁜지는 서리가 식물을 해치는 원리와 관계가 없어요.')]),
]
def snapshot():
    d = json.load(open(os.path.join(_HERE, 'data_restore35.json'), encoding='utf-8'))
    d = copy.deepcopy(d)
    for lv, n, pairs in FIXES:
        x = d[lv][n]
        for a, b in pairs:
            hit = 0
            for k in ('text', 'ko', 'walk'):
                hit += x[k].count(a); x[k] = x[k].replace(a, b)
            for i, c in enumerate(x['cn']):
                hit += c.count(a); x['cn'][i] = c.replace(a, b)
            assert hit >= 1, (lv, n, a)
    return d
