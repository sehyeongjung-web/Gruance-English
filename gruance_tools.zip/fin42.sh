#!/bin/bash
# 42번 한 묶음 끝내기: bash fin42.sh "<수정안 목록 전체>" <레벨> "<42번 수정안들>"
cd /home/claude/work
python3 build.py "$1" out/index.html > /tmp/b.txt 2>&1
python3 -c "
t=open('/tmp/b.txt','rb').read().decode('utf-8','replace')
print('\n'.join(l for l in t.split('\n') if '수정 문항' in l or 'Error' in l or 'ssert' in l or 'Traceback' in l)); print(t[-900:] if 'Traceback' in t else '')"
python3 zcheck42.py $2 "$3" > /tmp/z.txt 2>&1; python3 -c "print(open('/tmp/z.txt','rb').read().decode('utf-8','replace')[:2500])"
python3 check_all.py > /tmp/c.txt 2>&1; python3 -c "
t=open('/tmp/c.txt','rb').read().decode('utf-8','replace'); k=t.find('정답 번호'); print(t[k:][:430])"
