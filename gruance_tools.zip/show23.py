# -*- coding: utf-8 -*-
# 23번 읽기(선택지의 우리말 해석까지): python3 show23.py 7 10 20
import sys, re; sys.path.insert(0, '.')
from lib import *
lv, a, b = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
s, tb, te = load()
PAT = r"^(정답입니다\. )?'(.*?)' \((.*?)\) — "
for n in range(a, b):
    it = tb['23'][lv][n]; ex = te['23'][lv][n]
    print('=====', n + 1, 'ans', it['answer'], '(%d)' % len(it['text'].split())); print(it['text'])
    for k, c in enumerate(it['choices']):
        m = re.match(PAT, ex['cn'][k], re.S); print('   %s%d %s | %s' % ('*' if k == it['answer'] else ' ', k, c, m.group(3) if m else ''))
