import sys, importlib
from lib import load
_,TB,_=load()
for mod in sys.argv[1:]:
    F=importlib.import_module(mod)
    for k in sorted(F.E, key=lambda k:int(k[2])):
        r=F.E[k]['rewrite']; a=TB['23']['9'][k[2]]['answer']
        print('==',k[2]+1, '정답', a+1)
        for i,c in enumerate(r['choices']): print('  %s%d %s'%('✔' if i==a else ' ', i+1, c))
