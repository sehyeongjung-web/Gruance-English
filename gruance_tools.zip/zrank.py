# -*- coding: utf-8 -*-
# 원고(d63x)의 정답 선택지 길이 순위(1=가장 짧음)와 ±1글자 이내 오답을 보여 줌:  python3 zrank.py b
import sys, collections
sys.path.insert(0,'/home/claude/work'); sys.path.insert(0,'/home/claude/work/draft')
import importlib
d = importlib.import_module('d63' + sys.argv[1]); off = 0 if sys.argv[1] == 'a' else 15
rk = collections.Counter(); bad = 0
for n, v in sorted(d.I.items()):
    ch = v[1]; a = d.ANS[n]; L = [len(c) for c in ch]; c = L[a]
    rank = sum(1 for i in range(5) if L[i] < c) + 1; rk[rank] += 1
    near = [ch[i] for i in range(5) if i != a and abs(L[i] - c) <= 1]
    bad += len(near)
    print('%2d번째 길이 %s 정답 순위 %d%s' % (n + off + 1, L, rank, ('  ← ±1 이내: %s' % near) if near else ''))
print('순위 분포', sorted(rk.items()), '· ±1 이내 오답', bad)
