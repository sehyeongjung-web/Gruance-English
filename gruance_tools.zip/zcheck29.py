# -*- coding: utf-8 -*-
# 29번 레벨1(340·341번) 자체 검사.  python3 zcheck29.py [html=out/index.html] [시작-끝=0-29]
# 볼 것: 표시 ①~⑤ 한 번씩 · 정답 번호 불변 · 선택지 ①~⑤ · 정답 자리의 틀린 꼴 ≠ correctWord · 선택지별 해설 머리가 지문의 낱말과 같음
#        · 풀이가 정답 자리 문장을 그대로 인용 · 자리별 설명이 그 낱말을 담음 · 올바른 꼴로 고친 지문이 단문 · 문장 10~15낱말(zlevel)
import re, sys, collections; sys.path.insert(0, '.')
from lib import load
from zlevel import check_texts
path = sys.argv[1] if len(sys.argv) > 1 else 'out/index.html'
a, b = (sys.argv[2] if len(sys.argv) > 2 else '0-29').split('-')
s, tb, te = load(path); s0, tb0, te0 = load()
CIRC = '①②③④⑤'; bad = 0; tx = {}; changed = 0
for n in range(int(a), int(b) + 1):
    it = tb['29']['1'][n]; b0 = tb0['29']['1'][n]; ex = te['29']['1'][n]
    if it['text'] == b0['text']: continue
    changed += 1
    A = it['answer']; assert A == b0['answer'] and it.get('q') == b0.get('q'), (n, '정답 번호·발문')
    assert it['choices'] == list(CIRC) and ex['cn'] and len(ex['cn']) == 5, (n, '선택지·해설')
    t = it['text']
    sent = [x.replace('Mr_', 'Mr.') for x in re.split(r'(?<=[.!?])\s+', t.replace('Mr. ', 'Mr_ ').strip())]; assert len(sent) == 5, (n, '문장 수', len(sent))
    toks = []
    for k in range(5):
        assert sent[k].count(CIRC[k]) == 1 and sum(sent[k].count(c) for c in CIRC) == 1, (n, k, '표시')
        toks.append(re.search(CIRC[k] + r"([A-Za-z']+)", sent[k]).group(1))
    cw = it.get('correctWord'); assert cw and cw != toks[A], (n, 'correctWord', cw, toks[A])
    for k in range(5):
        c = ex['cn'][k]; head = ('정답이에요! ' if k == A else '') + '%s %s — ' % (CIRC[k], toks[k])
        assert c.startswith(head), (n, k, '해설 머리', c[:30], head)
        if k == A: assert '%s (×) → %s (○)' % (toks[k], cw) in c, (n, k, '정답 해설에 (×) → (○)')
        else: assert c.endswith('(○)') and toks[k].lower() in c.lower(), (n, k, '해설')
    w = ex['walk']
    assert '"%s"' % sent[A] in w and '정답은 %s번이에요' % CIRC[A] in w and '📌 문법:' in w and '📌 낱말:' in w, (n, '풀이')
    assert w.count('(×)') == 1, (n, '풀이의 (×)')
    assert len(re.findall('[가-힣]+', ex['ko'])) > 10 and ex['ko'].count('.') + ex['ko'].count('?') >= 5, (n, '해석')
    fixed = [x if k != A else x.replace(CIRC[k] + toks[k], cw) for k, x in enumerate(sent)]
    tx[n] = (re.sub('[①②③④⑤]', '', ' '.join(fixed)), 'x')
print('다시 쓴 문항', changed, '· 정답 자리', collections.Counter(tb['29']['1'][n]['answer'] + 1 for n in range(int(a), int(b) + 1)))
if tx: bad = check_texts('29', '1', tx, 5)
print('결과: 걸린 것', bad)
