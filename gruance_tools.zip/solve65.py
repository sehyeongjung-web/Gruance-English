# -*- coding: utf-8 -*-
# 29번 L1 원고(d65a/d65b)로 풀이꾼·감사꾼에게 줄 문제지를 만든다.  python3 solve65.py <폴더> [a|b|ab]
import re, sys, os
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
from lib import load
_, tb, _ = load('/home/claude/work/out/index.html')
STEM = {n: tb['29']['1'][n].get('q') for n in range(30)}
def sheets(tags):
    blind = []; audit = []
    for tag in tags:
        d = __import__('d65' + tag)
        for n in sorted(d.I):
            it = d.I[n]; a = tb['29']['1'][n]['answer']
            blind.append('[%d]\n%s\n' % (n + 1, ' '.join(it['S'])))
            audit.append('[%d] 정답 %s · 올바른 꼴 %s\n%s\n' % (n + 1, '①②③④⑤'[a], it['cw'], ' '.join(it['S'])))
    return '\n'.join(blind), '\n'.join(audit)
if __name__ == '__main__':
    out = sys.argv[1]; tags = sys.argv[2] if len(sys.argv) > 2 else 'ab'
    os.makedirs(out, exist_ok=True)
    b, a = sheets(tags)
    open(os.path.join(out, 'blind.txt'), 'w', encoding='utf-8').write(b)
    open(os.path.join(out, 'audit.txt'), 'w', encoding='utf-8').write(a)
    print('문항', b.count('\n[') + 1, '→', out)

def explain_sheet(path, html='/home/claude/work/out/index.html'):
    s, tb, te = load(html); out = []
    for n in range(30):
        it = tb['29']['1'][n]; ex = te['29']['1'][n]
        out.append('[%d] 정답 %s · 올바른 꼴(correctWord) %s\n지문: %s\n해석: %s\n풀이:\n%s\n선택지별 해설:\n%s\n' % (n + 1, '①②③④⑤'[it['answer']], it['correctWord'], it['text'], ex['ko'], ex['walk'], '\n'.join(ex['cn'])))
    open(path, 'w', encoding='utf-8').write('\n'.join(out))
if __name__ == '__main__' and len(sys.argv) > 3 and sys.argv[3] == 'explain':
    explain_sheet(os.path.join(sys.argv[1], 'explain.txt')); print('explain.txt 씀')
