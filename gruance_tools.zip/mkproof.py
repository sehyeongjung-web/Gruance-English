# 교정용 문제지 만들기: python3 mkproof.py <유형> <레벨> <출력파일>  (빌드한 out/index.html에서 뽑음)
import sys; sys.path.insert(0,'/home/claude/work')
from lib import load
T,L,outp=sys.argv[1],sys.argv[2],sys.argv[3]
_,tb,te=load('/home/claude/work/out/index.html')
out=[]
for n in range(30):
    t=tb[T][L][n]; e=te[T][L][n]
    out.append('=================== [%d]  key=%s'%(n+1,t['choices'][t['answer']]))
    out.append('EN: '+t['text'])
    out.append('CHOICES: '+' / '.join('%s%s'%('①②③④⑤'[k],c) for k,c in enumerate(t['choices'])))
    out.append('KO: '+e['ko'])
    w=e['walk']; out.append('WALK:\n'+(w[w.index('【이 문제에 적용】'):] if '【이 문제에 적용】' in w else w))
    out.append('CN:\n'+'\n'.join('%s %s'%('①②③④⑤'[k],c) for k,c in enumerate(e['cn'])))
    out.append('')
open(outp,'w',encoding='utf-8').write('\n'.join(out)); print('ok',len(out))
