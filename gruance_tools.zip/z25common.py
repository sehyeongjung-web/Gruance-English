# -*- coding: utf-8 -*-
# 371번: 25번(도표) 레벨1 — 공통 도우미
#   rw(n, kind, title, title_ko, unit, series, rows, sents, words, grp)
#   · kind 'table' | 'graph' (제목이 The table … / The graph … 로 시작 — 앱이 표/막대그래프로 그림)
#   · series = ('2023', '2024') 두 묶음, rows = [('Class A', 20, 35), …] 세 줄 또는 네 줄, grp = 줄을 부르는 우리말(반 · 공원 · 가게 …)
#   · sents = [(영어 문장, 한글 해석, 주장)] 다섯. 주장은 코드가 표로 참·거짓을 셈 — 거짓은 정답 자리 하나뿐이어야 함
#     주장: ('gt',A,B,s) ('lt',A,B,s) ('max',A,s) ('min',A,s) ('up',A) ('down',A) ('flat',A) ('chg',A,d) ('dbl',A)
#           ('same',A,B,s) ('total',s,t) ('gap',A,B,s,d)  A가 B보다 d 많음 ('vals',A,v0,v1) ('only_down',A)
#   · 해설은 주장에서 숫자를 그대로 뽑아 만듦(손으로 쓴 숫자가 없음). 조사는 「이름(수 단위)」 꼴로 단위 글자에 붙여 틀리지 않게 함
#   · 표현 목록은 그 문항 영어 문장에 실제로 쓰인 표현만 뽑음(교정꾼 지적 — 371번)
import sys, re; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
C = '①②③④⑤'
SK = {'Monday': '월요일', 'Tuesday': '화요일', 'Friday': '금요일', 'Saturday': '토요일', 'Sunday': '일요일',
      'March': '3월', 'April': '4월', 'May': '5월', 'June': '6월', 'July': '7월', 'August': '8월', 'September': '9월', 'October': '10월',
      'December': '12월', 'January': '1월', 'February': '2월', 'Spring': '봄', 'Fall': '가을', 'Morning': '오전', 'Afternoon': '오후'}
def sk(x): return SK.get(x, x + '년' if x.isdigit() else x)
def bat(w):
    c = w.strip().rstrip(')').strip()[-1]
    if '가' <= c <= '힣': return (ord(c) - 0xAC00) % 28 != 0
    if c.isdigit(): return c in '0136780'
    return True
def j(w, a, b): return w + (a if bat(w) else b)
def ev(cl, R, S):
    t = cl[0]; V = {r[0]: (r[1], r[2]) for r in R}
    if t == 'gt': return V[cl[1]][cl[3]] > V[cl[2]][cl[3]]
    if t == 'lt': return V[cl[1]][cl[3]] < V[cl[2]][cl[3]]
    if t == 'max': return all(V[cl[1]][cl[2]] > v[cl[2]] for k, v in V.items() if k != cl[1])
    if t == 'min': return all(V[cl[1]][cl[2]] < v[cl[2]] for k, v in V.items() if k != cl[1])
    if t == 'up': return V[cl[1]][1] > V[cl[1]][0]
    if t == 'down': return V[cl[1]][1] < V[cl[1]][0]
    if t == 'flat': return V[cl[1]][1] == V[cl[1]][0]
    if t == 'chg': return V[cl[1]][1] - V[cl[1]][0] == cl[2]
    if t == 'dbl': return V[cl[1]][1] == 2 * V[cl[1]][0]
    if t == 'same': return V[cl[1]][cl[3]] == V[cl[2]][cl[3]]
    if t == 'total': return sum(v[cl[1]] for v in V.values()) == cl[2]
    if t == 'gap': return V[cl[1]][cl[3]] - V[cl[2]][cl[3]] == cl[4]
    if t == 'vals': return V[cl[1]] == (cl[2], cl[3])
    if t == 'only_down': return [k for k, v in V.items() if v[1] < v[0]] == [cl[1]]
    raise ValueError(cl)
def fact(cl, R, S, u, grp):
    """표에서 읽은 사실을 우리말로 — 주장이 참이든 거짓이든 표 그대로를 말함"""
    t = cl[0]; V = {r[0]: (r[1], r[2]) for r in R}
    long_ = u in ('분', '시간')
    MORE, LESS = ('더 길어요.', '더 짧아요.') if long_ else ('더 많아요.', '더 적어요.')
    TOP, BOT = ('가장 시간이 긴', '가장 시간이 짧은') if long_ else ('가장 많은', '가장 적은')
    def q(A, s): return '%s(%d%s)' % (A, V[A][s], u)          # 조사는 단위 글자에 붙음
    def qq(A, s, a, b): return j(q(A, s), a, b)
    def lst(s): return ', '.join('%s %d%s' % (k, v[s], u) for k, v in V.items())
    def row(A): return '%s: %s %d%s → %s %d%s.' % (A, sk(S[0]), V[A][0], u, sk(S[1]), V[A][1], u)
    if t in ('gt', 'lt', 'same', 'gap'):
        A, B, s = cl[1], cl[2], cl[3]; a, b = V[A][s], V[B][s]
        head = '%s 수치는 %s %d%s, %s. ' % (sk(S[s]), A, a, u, j('%s %d%s' % (B, b, u), '이에요', '예요'))
        if a == b: return head + '그러니까 두 %s의 수가 같아요.' % grp
        hi, lo = (A, B) if a > b else (B, A)
        if t == 'gap': return head + '그러니까 %s %s보다 %d%s %s' % (qq(hi, s, '이', '가'), q(lo, s), abs(a - b), u, MORE)
        if t == 'lt': return head + '그러니까 %s %s보다 %s' % (qq(lo, s, '이', '가'), q(hi, s), LESS)
        return head + '그러니까 %s %s보다 %s' % (qq(hi, s, '이', '가'), q(lo, s), MORE)
    if t in ('max', 'min'):
        s = cl[2]; vs = sorted(V.items(), key=lambda kv: kv[1][s]); top = vs[-1][0] if t == 'max' else vs[0][0]
        return '%s 수치는 %s. 그러니까 %s %s %s' % (sk(S[s]), j(lst(s), '이에요', '예요'), TOP if t == 'max' else BOT, j(grp, '은', '는'), qq(top, s, '이에요.', '예요.'))
    if t == 'total':
        s = cl[1]; tot = sum(v[s] for v in V.values())
        return '%s 수치를 모두 더하면 %s = %s.' % (sk(S[s]), ' + '.join(str(v[s]) for v in V.values()), j('%d%s' % (tot, u), '이에요', '예요'))
    if t == 'only_down':
        dn = [k for k, v in V.items() if v[1] < v[0]]
        body = ' / '.join('%s %d→%d' % (k, v[0], v[1]) for k, v in V.items())
        tail = ('%s 한 곳뿐이에요.' % dn[0]) if len(dn) == 1 else ('%s, 모두 %d곳이에요.' % (', '.join(dn), len(dn))) if dn else '없어요.'
        return '%s → %s: %s. 그러니까 줄어든 %s %s' % (sk(S[0]), sk(S[1]), body, j(grp, '은', '는'), tail)
    A = cl[1]; a, b = V[A]; head = row(A)
    if t in ('up', 'down', 'flat', 'vals'):
        return head + (' 그러니까 늘었어요.' if b > a else ' 그러니까 줄었어요.' if b < a else ' 그러니까 두 때의 수가 같아요.')
    if t == 'chg':
        return head + (' 그러니까 %d%s 늘었어요.' % (b - a, u) if b > a else ' 그러니까 %d%s 줄었어요.' % (a - b, u) if b < a else ' 그러니까 그대로예요.')
    if t == 'dbl':
        if b == 2 * a: return head + ' %d의 두 배는 %d이니까 두 배가 맞아요.' % (a, 2 * a)
        k = b / a
        extra = (' %d은 %d의 %d배예요.' % (b, a, int(k))) if k == int(k) and bat(str(b)) else (' %d는 %d의 %d배예요.' % (b, a, int(k))) if k == int(k) else ''
        return head + ' %d의 두 배는 %d인데 %s 수치는 %s.%s 그러니까 두 배가 아니에요.' % (a, 2 * a, sk(S[1]), j('%d%s' % (b, u), '이에요', '예요'), extra)
    raise ValueError(cl)
NUMW = r'(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fourteen|fifteen|twenty|twenty-five|thirty|thirty-five|fifty|seventy|\d+)'
PHR = [(r'more \w+(?: \w+)? than any other', 'more … than any other ~ : 다른 어느 ~보다 더 많이'),
       (r'\bthe most\b', 'the most : 가장 많은(많이)'), (r'\bthe fewest\b', 'the fewest : 가장 적은(적게)'), (r'\bthe longest\b', 'the longest : 가장 긴(오래)'),
       (r'\btwice as many\b', 'twice as many … as ~ : ~의 두 배만큼 많은'), (r'\bdoubled\b', 'double(d) : 두 배가 되다'),
       (r'\bthe same number of\b', 'the same number of : 같은 수의'), (r'\ba total of\b', 'a total of : 모두 합해서 ~'), (r'\bin total\b', 'in total : 모두 합해서'),
       (r'\bwent up\b', 'went up : 늘었다'), (r'\bwent down\b', 'went down : 줄었다'),
       (r'\ba larger number of\b', 'a larger number of : 더 많은 수의'), (r'\ba smaller number of\b', 'a smaller number of : 더 적은 수의'),
       (r'^Only\b', 'Only A … : A만 …'),
       (NUMW + r' more\b[^.]* than (?:in|on)\b', '(수) more … than in / on ~ : ~ 때보다 (수)만큼 더 많이'),
       (NUMW + r' fewer\b[^.]* than (?:in|on)\b', '(수) fewer … than in / on ~ : ~ 때보다 (수)만큼 더 적게'),
       (NUMW + r' more \w+ than (?!in\b|on\b)', '(수) more … than ~ : ~보다 (수)만큼 더 많이'),
       (NUMW + r' minutes longer than\b', '(수) minutes longer than ~ : ~보다 (수)분 더 오래'),
       (r'\bmore \w+ than (?!any|in\b|on\b)', 'more … than ~ : ~보다 더 많이'), (r'\b[Ff]ewer \w+(?: \w+)? than (?!in\b|on\b)', 'fewer … than ~ : ~보다 더 적게'),
       (r'^Fewer \w+[^.]* than (?:in|on)\b', 'Fewer … than in / on ~ : ~ 때보다 더 적게')]
def exprs(sents):
    found = []
    for i, (en, _, _) in enumerate(sents):
        for rx, line in PHR:
            m = re.search(rx, en)
            if m: found.append((i * 1000 + m.start(), line))
    found.sort(); out = []
    for _, line in found:
        if line not in out: out.append(line)
    return ['· ' + x for x in out[:6]]
def maker(E, T='25', LV='1'):
    def rw(n, kind, title, title_ko, unit, series, rows, sents, words, grp):
        it = _tb[T][LV][n]; ans = it['answer']
        assert kind in ('table', 'graph') and title.startswith('The %s shows' % kind), (n, '제목은 The table/graph shows …')
        assert len(series) == 2 and 3 <= len(rows) <= 4 and len(sents) == 5, n
        truth = [ev(cl, rows, series) for _, _, cl in sents]
        assert [i for i, x in enumerate(truth) if not x] == [ans], (n, '거짓 문장은 정답 자리 하나뿐이어야 함', truth, ans)
        for en, ko, _ in sents: assert en.endswith('.') and ko.endswith('.') and "'" not in en, n
        data = '\n'.join('%s — %s: %d, %s: %d' % (r[0], series[0], r[1], series[1], r[2]) for r in rows)
        text = '%s\n\n%s\n\n%s' % (title, data, ' '.join('%s %s' % (C[k], s[0]) for k, s in enumerate(sents)))
        ko = '%s\n%s\n\n%s' % (title_ko, data, '\n'.join('%s %s' % (C[k], s[1]) for k, s in enumerate(sents)))
        F = [fact(cl, rows, series, unit, grp) for _, _, cl in sents]
        ex = exprs(sents); assert ex, (n, '표현 목록이 비었음')
        walk = ('[1단계] 이 문제는 문장 하나하나를 도표의 숫자와 맞춰 보면 풀려요. 먼저 이 문제에 나온 표현을 알아 두세요.\n%s\n'
                '[2단계] %s번 문장을 도표와 맞춰 보세요.\n"%s" (%s)\n→ %s 그래서 이 문장은 도표와 맞지 않아요.\n'
                '[3단계] 나머지 네 문장은 모두 도표와 맞아요. 그러니까 정답은 %s번이에요.\n📌 낱말: %s') % ('\n'.join(ex), C[ans], sents[ans][0], sents[ans][1], F[ans], C[ans], words)
        cn = [('정답이에요! %s번은 도표와 맞지 않아요. %s' if k == ans else '%s번은 도표와 맞아요. %s') % (C[k], F[k]) for k in range(5)]
        assert (T, LV, n) not in E
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(C), 'ko': ko, 'walk': walk, 'cn': cn}}
    return rw
