# -*- coding: utf-8 -*-
# 30번(어휘) 레벨1을 레벨 기준으로 다시 쓸 때의 도우미 (342·343번)
#   from z30rw import maker;  rw = maker(E)
#   rw(n, [다섯 문장(표시 ①~⑤ 한 번씩, 정답 자리는 틀린 말)], cw(올바른 말), [해석 다섯(정답 자리에는 「틀린 뜻(→ 올바른 뜻)」)], [표시 낱말의 뜻 다섯], [자리별 설명 다섯], 낱말 줄)
#   - 정답 자리는 바탕 그대로(어기면 멈춤) · 선택지는 ①~⑤ 그대로
#   - 정답 자리 설명은 「원래는 cw(뜻)」을 담고, 나머지 설명은 「맞아요.」로 끝남
#   - 풀이(walk)·선택지별 해설(cn)은 바탕 30번 레벨1의 꼴 그대로
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
_s, _tb, _te = load()
CIRC = '①②③④⑤'
HEAD = "① 낱말 쓰임 문제는 ①~⑤ 낱말이 앞뒤 내용과 맞는지 하나씩 확인해요. 답은 문맥과 반대되거나 어울리지 않는 낱말이에요."
def maker(E):
    def rw(n, S, cw, ko, gl, notes, words):
        base = _tb['30']['1'][n]; a = base['answer']
        assert len(S) == 5 == len(ko) == len(gl) == len(notes), (n, '문장·해석·뜻·설명은 다섯')
        toks = []
        for k in range(5):
            assert S[k].count(CIRC[k]) == 1 and sum(S[k].count(c) for c in CIRC) == 1, (n, k, '표시')
            m = re.search(CIRC[k] + r"([A-Za-z']+)", S[k]); assert m, (n, k, '표시 뒤 낱말'); toks.append(m.group(1))
            assert S[k].endswith('.'), (n, k, '문장 끝 마침표')
        assert list(base['choices']) == list(CIRC), (n, '선택지는 ①~⑤')
        assert toks[a].lower() != cw.lower(), (n, '정답 자리의 틀린 말과 올바른 말이 같음')
        assert '(→' in ko[a] and sum(x.count('(→') for x in ko) == 1, (n, '해석의 「(→ 올바른 뜻)」은 정답 자리에 한 번')
        assert all(re.search(r'[가-힣]', x) for x in ko) and all(re.search(r'[가-힣]', g) for g in gl), (n, '해석·뜻')
        for k in range(5):
            if k == a: assert '원래는 %s(' % cw in notes[k], (n, k, '정답 자리 설명에 「원래는 %s(뜻)」' % cw)
            else: assert notes[k].endswith('맞아요.'), (n, k, '다른 자리 설명은 「맞아요.」로 끝')
            assert '정답' not in notes[k], (n, k, '설명에 「정답」이라는 말')
        text = ' '.join(S)
        walk = (HEAD + '\n② 표시 %s번이 든 문장을 보세요.\n"%s" (%s)\n→ %s\n③ 나머지 네 낱말은 모두 문맥에 맞아요. 그러니까 정답은 %s번이에요.\n📌 낱말: %s'
                % (CIRC[a], S[a], ko[a], notes[a], CIRC[a], words))
        cn = [('정답이에요! ' if k == a else '') + '%s %s(%s) — %s' % (CIRC[k], toks[k], gl[k], notes[k]) for k in range(5)]
        assert ('30', '1', n) not in E, (n, '같은 문항을 두 번 씀')
        E[('30', '1', n)] = {'passage_ok': True, 'ans_ok': True,
                             'rewrite': {'text': text, 'choices': list(CIRC), 'ko': ' '.join(ko), 'walk': walk, 'cn': cn, 'cw': cw}}
    return rw
