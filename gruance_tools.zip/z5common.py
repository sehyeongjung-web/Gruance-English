# -*- coding: utf-8 -*-
# 38-39번(문장 삽입) 해설 두텁게 — 공통 도우미 (레벨9 때(180번)의 것을 220번에 다시 만들고 레벨 인자를 닮)
#   mk = maker(E, lv='8')
#   mk(n, 답 자리(1~5), [적용 네 줄], 헷갈리는 곳, [자리별 설명 5개])
# - "①번 자리는 맞지 않습니다." / "③번이 정답입니다." 머리말은 자동. 4)가 그 번호의 "답입니다."로 끝나지 않으면 멈춤
# - 원고의 «…»는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜
import re, sys; sys.path.insert(0, '.')
from lib import load as _load
_tb = _load()[1]
CIRC = '①②③④⑤'; JOSA = '이가이가가'   # ①이 ②가 ③이 ④가 ⑤가
TIP = ("【문장 삽입 요령】\n"
       "첫째, 삽입할 문장부터 읽고 단서를 찾습니다. 가리키는 말(this, that, such, these)과 이어 주는 말(however, therefore, also)이 단서입니다.\n"
       "둘째, 그 단서로 「앞에 무엇이 나와 있어야 하는가」와 「뒤에 무엇이 이어져야 하는가」를 짐작합니다.\n"
       "셋째, 지문을 읽으며 흐름이 건너뛰는 곳을 찾습니다. 뒤 문장의 가리키는 말이 받을 것이 앞 문장에 없으면 그 사이가 빈자리입니다.\n"
       "넷째, 문장을 넣고 앞 문장, 삽입 문장, 뒤 문장을 이어 읽어 양쪽이 다 맞물리는지 확인합니다.")
# 276번 뒤(290번): 레벨1~3은 해설의 말끝이 「~어요」(README) — 요령·머리말·맺음을 그 말끝으로
TIP3 = ("【문장 삽입 요령】\n"
        "첫째, 삽입할 문장부터 읽고 단서를 찾아요. 가리키는 말(this, that, such, these)과 이어 주는 말(however, therefore, also)이 단서예요.\n"
        "둘째, 그 단서로 「앞에 무엇이 나와 있어야 하는가」와 「뒤에 무엇이 이어져야 하는가」를 짐작해요.\n"
        "셋째, 지문을 읽으며 흐름이 건너뛰는 곳을 찾아요. 뒤 문장의 가리키는 말이 받을 것이 앞 문장에 없으면 그 사이가 빈자리예요.\n"
        "넷째, 문장을 넣고 앞 문장, 삽입 문장, 뒤 문장을 이어 읽어 양쪽이 다 맞물리는지 확인해요.")
def low(lv): return lv in ('1', '2', '3')
def ending(lv): return '답이에요.' if low(lv) else '답입니다.'
def cnhead(lv, right): return ("번이 정답이에요. " if right else "번 자리는 맞지 않아요. ") if low(lv) else ("번이 정답입니다. " if right else "번 자리는 맞지 않습니다. ")
HEADS = ('1) 삽입할 문장:', '2) 앞 문장 찾기:', '3) 뒤 문장 확인:', '4) 넣고 읽기:')
def seg(text):
    """지문을 삽입할 문장과 조각 여섯으로 나눔: [① 앞, ①~② 사이, …, ⑤ 뒤(없으면 빈 글)]"""
    m = re.match(r'^\[삽입할 문장\] (.*?)\n\n(.*)$', text, re.S); assert m, '지문 꼴'
    parts = re.split(r'\( [①②③④⑤] \)', m.group(2)); assert len(parts) == 6, '자리 다섯'
    return m.group(1).strip(), [p.strip() for p in parts]
def _q(x): return x.replace('«', '"').replace('»', '"')
def maker(E, lv='8'):
    def mk(n, ans, steps, confuse, cn, moved=False):   # moved: 정답 자리를 옮긴 문항(승인된 칸에서만 — ans_move.py)
        it = _tb['38_39'][lv][n]; a = it['answer']
        if moved: a = ans - 1
        assert a == ans - 1, ('원고의 답 자리가 문항과 다름', n, a + 1, ans)
        assert len(cn) == 5 and len(steps) == 4, n
        assert all(s.startswith(h) for s, h in zip(steps, HEADS)), (n, '적용 줄의 머리말')
        assert steps[3].endswith('%s%s %s' % (CIRC[a], JOSA[a], ending(lv))), (n, '4)의 끝')
        out = {}
        for k, body in enumerate(cn):
            assert '정답' not in body, (n, k, '설명에 "정답"이라는 말')
            assert not re.search('[①②③④⑤]', body), (n, k, '자리 해설에 다른 번호')
            out[k] = CIRC[k] + cnhead(lv, k == a) + _q(body)
        assert ('38_39', lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[('38_39', lv, n)] = {'walk': (TIP3 if low(lv) else TIP) + "\n\n【이 문제에 적용】\n" + "\n".join(_q(x) for x in steps) + "\n\n【헷갈리는 곳】\n" + _q(confuse), 'cn': out}
    return mk
