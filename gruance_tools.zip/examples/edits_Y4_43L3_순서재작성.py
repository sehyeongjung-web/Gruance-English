# 173번: 43번(이야기 글의 순서) 레벨3 틀 재작성 — 30문항 전부
#   · 정답 번호·선택지 그대로. 가리키는 말의 사슬로 순서가 하나로만 정해짐. 이야기 구조 여섯 가지 5문항씩
#   · 레벨3 언어: 쉬운 어휘, 문장마다 종속절은 많아야 하나(because/when/so that). 문단마다 두 문장. 해설은 "~요" 말투(레벨3 관례)
AUTO_SYNC = False
E = {}
STD = ['(B)-(D)-(C)', '(C)-(B)-(D)', '(C)-(D)-(B)', '(D)-(B)-(C)', '(D)-(C)-(B)']

def S(n, order, A, P1, P2, P3, r2, r3, clue, words):
    # A=(주어진 글, 해석) / P1~P3=이야기 순서대로 (영어, 해석, 한 줄 요약) / r2·r3=둘째·셋째 문단이 앞에 올 수 없는 까닭("~요") / clue=흐름 뒤에 붙는 단서 한 문장 / words="낱말 뜻 / 낱말 뜻"
    L = ['(%s)' % c for c in order]
    ans = '-'.join(L); assert ans in STD, (n, ans)
    paras = dict(zip(L, (P1, P2, P3)))
    text = A[0] + ''.join('\n\n%s %s' % (k, paras[k][0]) for k in ['(B)', '(C)', '(D)'])
    ko = A[1] + ''.join(' %s %s' % (k, paras[k][1]) for k in ['(B)', '(C)', '(D)'])
    f = lambda s: s.replace('{1}', L[0]).replace('{2}', L[1]).replace('{3}', L[2])
    flow = ' → '.join('%s(%s)' % (p[2], L[i]) for i, p in enumerate((P1, P2, P3))) + '의 흐름이에요. ' + f(clue)
    quoted = '\n'.join('%s "%s" (%s)' % (L[i], p[0], p[1]) for i, p in enumerate((P1, P2, P3)))
    walk = ("① 순서 문제는 시간의 흐름을 따라가요. 앞 문단에 나온 것을 'the ~', 'that ~', he, she, it 같은 말로 받는 곳이 단서예요.\n"
            "② 흐름을 따라가 보세요.\n%s\n→ %s\n③ 그러니까 정답은 %s예요.\n📌 낱말: %s") % (quoted, flow, ans, words)
    cn = []
    for c in STD:
        if c == ans: cn.append('정답이에요! %s — 첫 문장 뒤에 %s → %s → %s 순서로 이어져요. %s' % (c, L[0], L[1], L[2], flow))
        elif c[:3] == L[1]: cn.append('%s — %s' % (c, f(r2)))
        elif c[:3] == L[2]: cn.append('%s — %s' % (c, f(r3)))
        else: cn.append('%s — 첫 문단은 맞지만 그 다음이 틀렸어요. %s' % (c, f(r3)))
    assert ('43', '3', n) not in E, n
    E[('43', '3', n)] = {'passage_ok': True, 'ans_ok': True, '_order': ans,
                         'rewrite': {'text': text, 'choices': list(STD), 'ko': ko, 'walk': walk, 'cn': cn}}

# 1 ─ 하루: 아버지 차 닦기
S(0, 'CBD',
  ("Jiwoo wanted to wash her father's car before he woke up on Sunday.",
   "지우는 일요일에 아버지가 깨기 전에 아버지의 차를 닦고 싶었다."),
  ("She filled a bucket with water, but the hose was too short to reach the car. So she started to carry the water.",
   "그녀는 양동이에 물을 채웠지만, 호스가 너무 짧아서 차까지 닿지 않았다. 그래서 그녀는 물을 나르기 시작했다.",
   "호스가 짧아서 물을 나르기 시작함"),
  ("She carried the bucket ten times until her arms hurt. The car was still half dirty.",
   "그녀는 팔이 아플 때까지 양동이를 열 번이나 날랐다. 차는 아직 절반이 더러웠다.",
   "열 번을 날랐지만 차는 아직 절반이 더러움"),
  ("Her brother saw her tired arms and brought a longer hose from the garage. The two finished before their father came out.",
   "오빠가 그녀의 지친 팔을 보고 차고에서 더 긴 호스를 가져왔다. 두 사람은 아버지가 나오기 전에 다 끝냈다.",
   "오빠가 긴 호스를 가져와 함께 끝냄"),
  "{2}의 'the bucket(그 양동이)'은 {1}에서 물을 채운 양동이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'her tired arms(지친 팔)'는 {2}에서 열 번을 나르느라 아팠던 팔이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'the bucket'은 {1}의 양동이를, {3}의 'her tired arms'는 {2}의 아픈 팔을 가리켜요.",
  "bucket 양동이 / hose 호스 / garage 차고")

# 2 ─ 회상: 외투 주머니의 기차표
S(1, 'DCB',
  ("Mr. Kim found an old train ticket in the pocket of a coat that he had not worn for years.",
   "김 씨는 몇 년 동안 입지 않은 외투 주머니에서 오래된 기차표 한 장을 발견했다."),
  ("It was a ticket to the sea from thirty years ago. He had bought two tickets that day.",
   "그것은 30년 전에 산 바다행 기차표였다. 그날 그는 표를 두 장 샀었다.",
   "30년 전 바다행 표를 두 장 샀음"),
  ("The second ticket was for a girl who worked at the post office. She came to the station late, and the train left without them.",
   "두 번째 표는 우체국에서 일하던 한 아가씨의 것이었다. 그녀는 역에 늦게 왔고, 기차는 두 사람을 두고 떠났다.",
   "두 번째 표의 주인이 늦게 와서 기차를 놓침"),
  ("They took the next train together. That girl is now his wife, and he put the ticket back in the pocket with a smile.",
   "두 사람은 다음 기차를 함께 탔다. 그 아가씨는 지금 그의 아내이고, 그는 웃으며 표를 다시 주머니에 넣었다.",
   "다음 기차를 함께 탔고 그 아가씨가 지금의 아내임"),
  "{2}의 'The second ticket(두 번째 표)'은 {1}에서 두 장을 샀다고 해야 나올 수 있으니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'the next train(다음 기차)'과 'That girl(그 아가씨)'은 {2}에서 기차를 놓친 아가씨 이야기 뒤에 와야 하니까 {2}보다 먼저 올 수 없어요.",
  "주어진 글의 표를 {1}의 'It'이 받고, {2}의 'The second ticket'은 {1}의 두 장을, {3}의 'That girl'은 {2}의 아가씨를 가리켜요.",
  "pocket 주머니 / post office 우체국 / station 역")

# 3 ─ 대화: 보건 선생님의 노란 리본
S(2, 'DBC',
  ("Nabi asked the school nurse why she always wore a yellow ribbon in her hair.",
   "나비는 보건 선생님에게 왜 늘 머리에 노란 리본을 하고 있는지 물었다."),
  ("The nurse said that it was a long story. Nabi sat down to listen.",
   "보건 선생님은 그것이 긴 이야기라고 말했다. 나비는 들으려고 자리에 앉았다.",
   "긴 이야기라고 하자 나비가 앉아서 들음"),
  ("The story began years ago, when a student gave her the ribbon after a bad fall. The student said that yellow was the colour of getting better.",
   "그 이야기는 몇 년 전, 한 학생이 크게 넘어진 뒤 그녀에게 리본을 준 데서 시작되었다. 그 학생은 노란색이 낫는 색이라고 말했다.",
   "몇 년 전 한 학생이 리본을 주며 '낫는 색'이라고 함"),
  ("Nabi asked what happened to that student. The nurse smiled and said that she was now a nurse too, in the room next door.",
   "나비는 그 학생이 어떻게 되었는지 물었다. 선생님은 웃으며, 그 학생도 이제 옆방에서 일하는 간호사가 되었다고 말했다.",
   "그 학생은 이제 옆방의 간호사가 됨"),
  "{2}의 'The story(그 이야기)'는 {1}에서 선생님이 말한 'a long story'니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'that student(그 학생)'는 {2}에서 리본을 준 학생이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'The story'는 {1}의 'a long story'를, {3}의 'that student'는 {2}의 학생을 가리켜요.",
  "nurse 간호사, 보건 선생님 / ribbon 리본 / fall 넘어짐")

# 4 ─ 결말: 딸기 도둑
S(3, 'DBC',
  ("Mingyu was sure that someone was eating the strawberries in his garden.",
   "민규는 누군가 자기 밭의 딸기를 먹고 있다고 확신했다."),
  ("Every morning two or three were gone, but he never saw anyone. He decided to watch from his window at night.",
   "아침마다 두세 개씩 없어졌지만 그는 아무도 보지 못했다. 그는 밤에 창문에서 지켜보기로 했다.",
   "밤에 창문에서 지켜보기로 함"),
  ("At midnight he saw a small shadow move under the plants. It was far too small to be a person.",
   "자정에 그는 작은 그림자가 딸기 모종 아래에서 움직이는 것을 보았다. 사람이라기에는 너무 작았다.",
   "자정에 사람보다 훨씬 작은 그림자를 봄"),
  ("In the morning he found a hedgehog asleep under those plants, with red juice on its nose. He left it the biggest strawberry.",
   "아침에 그는 그 모종 아래에서 코에 빨간 즙을 묻힌 채 잠든 고슴도치 한 마리를 발견했다. 그는 가장 큰 딸기를 고슴도치에게 남겨 주었다.",
   "범인은 고슴도치였고 딸기를 남겨 줌"),
  "{2}의 'At midnight(자정에)'은 {1}에서 밤에 지켜보기로 한 뒤의 일이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'those plants(그 모종)'는 {2}에서 그림자가 움직인 모종이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'At midnight'은 {1}의 '밤에 지켜보기로 함' 다음이고, {3}의 'those plants'는 {2}의 모종을 가리켜요.",
  "shadow 그림자 / hedgehog 고슴도치 / juice 즙")

# 5 ─ 번갈아: 밤의 불빛
S(4, 'DBC',
  ("Two sisters, Yuna and Yuri, shared a room, and they argued about the light every night.",
   "자매인 유나와 유리는 방을 같이 썼는데, 밤마다 불빛 때문에 다투었다."),
  ("Yuna liked to read late, but Yuri wanted the room dark. One night Yuri hid the lamp.",
   "유나는 늦게까지 책을 읽고 싶어 했지만, 유리는 방이 어둡기를 바랐다. 어느 날 밤 유리는 전등을 숨겼다.",
   "유리가 전등을 숨김"),
  ("The next night Yuna read with the light of her phone under the blanket. Yuri could still see a glow through the cloth.",
   "다음 날 밤 유나는 이불 속에서 휴대전화 불빛으로 책을 읽었다. 유리는 천 너머로 희미한 빛이 비치는 것을 여전히 볼 수 있었다.",
   "유나가 이불 속에서 휴대전화 불빛으로 읽음"),
  ("Yuri got tired of that glow. She bought her sister a small lamp that clipped onto the book, and the arguing stopped.",
   "유리는 그 희미한 빛에 지쳤다. 그녀는 언니에게 책에 끼우는 작은 등을 사 주었고, 다툼은 끝났다.",
   "유리가 책에 끼우는 등을 사 주어 다툼이 끝남"),
  "{2}의 'The next night(다음 날 밤)'은 {1}에서 전등을 숨긴 밤의 다음 날이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'that glow(그 희미한 빛)'는 {2}에서 이불 너머로 비친 빛이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'The next night'은 {1}의 'One night' 다음이고, {3}의 'that glow'는 {2}의 'a glow'를 가리켜요.",
  "argue 다투다 / blanket 이불 / glow 희미한 빛")

# 6 ─ 이동: 처음 혼자 간 시내
S(5, 'CDB',
  ("Hoon went to the city alone to buy a birthday present for his mother.",
   "훈은 어머니의 생일 선물을 사려고 혼자 시내에 갔다."),
  ("He got off the bus at the wrong stop and did not know the street. He asked a man who was sweeping the road.",
   "그는 엉뚱한 정류장에서 버스를 내렸고 그 거리를 알지 못했다. 그는 길을 쓸고 있는 남자에게 물었다.",
   "엉뚱한 정류장에 내려 길 쓰는 남자에게 물음"),
  ("The man pointed to a tall white building. He said that the shops were behind it.",
   "그 남자는 높은 흰 건물을 가리켰다. 그는 가게들이 그 뒤에 있다고 말했다.",
   "남자가 흰 건물 뒤에 가게가 있다고 알려 줌"),
  ("Behind that building Hoon found a street full of small shops. He bought a scarf and found the right bus home.",
   "그 건물 뒤에서 훈은 작은 가게가 가득한 거리를 찾았다. 그는 목도리를 사고 집에 가는 맞는 버스를 찾았다.",
   "건물 뒤 거리에서 목도리를 사고 집에 감"),
  "{2}의 'The man(그 남자)'은 {1}에서 길을 쓸던 남자니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'that building(그 건물)'은 {2}에서 남자가 가리킨 흰 건물이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'The man'은 {1}의 'a man'을, {3}의 'that building'은 {2}의 'a tall white building'을 가리켜요.",
  "sweep 쓸다 / point 가리키다 / scarf 목도리")

# 7 ─ 하루: 비 오는 날의 동물원
S(6, 'DBC',
  ("Sera promised to take her little brother to the zoo on Saturday.",
   "세라는 토요일에 어린 남동생을 동물원에 데려가기로 약속했다."),
  ("In the morning it rained hard, and the boy cried at the window. Sera told him that they would still go.",
   "아침에 비가 세차게 내렸고, 동생은 창가에서 울었다. 세라는 그래도 갈 거라고 말했다.",
   "아침에 비가 와서 동생이 울지만 가기로 함"),
  ("At noon the rain stopped. They took the bus, and the boy held the tickets all the way.",
   "정오에 비가 그쳤다. 두 사람은 버스를 탔고, 동생은 가는 내내 표를 꼭 쥐고 있었다.",
   "정오에 비가 그쳐 버스를 탐"),
  ("The animals were out after the rain, and the monkeys came close to the fence. On the way home the boy fell asleep with those tickets in his hand.",
   "비가 온 뒤라 동물들이 밖에 나와 있었고, 원숭이들은 울타리 가까이 다가왔다. 집에 오는 길에 동생은 그 표를 손에 쥔 채 잠들었다.",
   "동물을 구경하고 돌아오는 길에 표를 쥔 채 잠듦"),
  "{2}의 'the rain stopped(비가 그쳤다)'는 {1}에서 비가 내린 뒤의 일이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'after the rain'과 'those tickets(그 표)'는 {2}에서 비가 그치고 동생이 쥔 표 뒤에 와야 하니까 {2}보다 먼저 올 수 없어요.",
  "하루의 흐름이에요. {1}는 'In the morning', {2}는 'At noon', {3}는 'On the way home'이고, {3}의 'those tickets'는 {2}의 표를 가리켜요.",
  "zoo 동물원 / fence 울타리 / fall asleep 잠들다")

# 8 ─ 회상: 이 빠진 파란 컵
S(7, 'CDB',
  ("Mrs. Lee keeps a chipped blue cup on her desk at the bank.",
   "이 씨는 은행의 자기 책상 위에 이가 빠진 파란 컵을 놓아둔다."),
  ("It was the first thing she bought with her first pay, forty years ago. It cost less than a bus ticket.",
   "그것은 40년 전 첫 월급으로 처음 산 물건이었다. 값은 버스표보다 쌌다.",
   "40년 전 첫 월급으로 산 싼 컵임"),
  ("A customer once laughed at that cheap cup. He said that a bank manager should have something better.",
   "한 손님이 그 싼 컵을 보고 웃은 적이 있었다. 그는 은행 지점장이라면 더 좋은 것을 써야 한다고 말했다.",
   "한 손님이 싼 컵을 보고 웃음"),
  ("She told him that the cup reminded her of her first day. He stopped laughing, and the next week he came back with an old cup of his own.",
   "그녀는 그에게 그 컵이 첫 출근 날을 떠올리게 한다고 말했다. 그는 웃음을 멈추었고, 다음 주에 자기의 낡은 컵을 들고 다시 왔다.",
   "이야기를 듣자 손님도 자기 낡은 컵을 가져옴"),
  "{2}의 'that cheap cup(그 싼 컵)'은 {1}에서 값이 버스표보다 쌌다고 해야 나올 수 있으니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'him(그)'과 'stopped laughing(웃음을 멈췄다)'은 {2}에서 웃은 손님이 있어야 하니까 {2}보다 먼저 올 수 없어요.",
  "주어진 글의 컵을 {1}의 'It'이 받고, {2}의 'that cheap cup'은 {1}의 싼 값을, {3}의 'him'은 {2}의 손님을 가리켜요.",
  "chipped 이가 빠진 / pay 월급 / customer 손님")

# 9 ─ 대화: 할머니의 서랍
S(8, 'CDB',
  ("Doyun asked his grandmother why she never threw anything away.",
   "도윤은 할머니에게 왜 아무것도 버리지 않으시는지 물었다."),
  ("She opened a drawer and took out a small bent spoon. She asked him what he saw.",
   "할머니는 서랍을 열어 작고 휜 숟가락을 꺼냈다. 할머니는 그에게 무엇이 보이느냐고 물었다.",
   "할머니가 휜 숟가락을 꺼내 무엇이 보이냐고 물음"),
  ("Doyun said that it was just an old spoon. His grandmother shook her head and told him that he ate with it when he was a baby.",
   "도윤은 그냥 낡은 숟가락이라고 말했다. 할머니는 고개를 저으며 그가 아기였을 때 그것으로 밥을 먹었다고 말해 주었다.",
   "낡은 숟가락이라고 하자 아기 때 쓰던 것이라고 함"),
  ("Doyun said sorry for calling it old. That evening he took a broken toy out of the bin.",
   "도윤은 낡았다고 말한 것을 사과했다. 그날 저녁 그는 쓰레기통에서 부서진 장난감을 다시 꺼냈다.",
   "사과하고 버린 장난감을 다시 꺼냄"),
  "{2}의 'it was just an old spoon'은 {1}에서 할머니가 꺼낸 숟가락에 대한 대답이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'calling it old(낡았다고 한 것)'는 {2}에서 도윤이 한 말이니까 {2}보다 먼저 올 수 없어요.",
  "{2}는 {1}의 질문에 대한 대답이고, {3}의 'calling it old'는 {2}의 'just an old spoon'을 가리켜요.",
  "drawer 서랍 / bent 휜 / bin 쓰레기통")

# 10 ─ 결말: 사라진 거북
S(9, 'DCB',
  ("Jiho's turtle, Kong, disappeared from the garden on Monday.",
   "지호의 거북 '콩'이 월요일에 마당에서 사라졌다."),
  ("The family looked under every bush and behind every pot. They put a photo of the turtle on every tree in the street.",
   "가족은 덤불 밑과 화분 뒤를 모두 찾아보았다. 그들은 거리의 나무마다 거북 사진을 붙였다.",
   "온 집을 뒤지고 나무마다 사진을 붙임"),
  ("On Thursday a neighbour called about the photo. She said that she had seen a turtle in the park.",
   "목요일에 한 이웃이 사진을 보고 전화를 했다. 그녀는 공원에서 거북 한 마리를 보았다고 말했다.",
   "이웃이 공원에서 거북을 봤다고 전화함"),
  ("Jiho ran to the park, but the turtle there was much bigger than Kong. When he came home sad, his own turtle was sitting in the kitchen, eating a leaf.",
   "지호는 공원으로 달려갔지만, 거기 있는 거북은 콩보다 훨씬 컸다. 그가 슬퍼하며 집에 왔을 때, 그의 거북은 부엌에 앉아 잎을 먹고 있었다.",
   "공원의 거북은 다른 거북이었고 콩은 부엌에 있었음"),
  "{2}의 'the photo(그 사진)'는 {1}에서 나무에 붙인 사진이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'the park(그 공원)'는 {2}에서 이웃이 말한 공원이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'the photo'는 {1}의 사진을, {3}의 'the park'는 {2}의 공원을 가리켜요.",
  "turtle 거북 / bush 덤불 / neighbour 이웃")

# 11 ─ 번갈아: 냉장고의 자석 글자
S(10, 'CBD',
  ("Taeyang and his father played a word game with the letter magnets on the fridge.",
   "태양과 아버지는 냉장고의 글자 자석으로 낱말 놀이를 했다."),
  ("Every morning Taeyang spelled one word before school. His father left a word in answer before he went to work.",
   "아침마다 태양은 학교에 가기 전에 낱말 하나를 만들었다. 아버지는 출근하기 전에 답으로 낱말 하나를 남겼다.",
   "아침마다 낱말을 하나씩 주고받음"),
  ("One morning the word his father left was 'sorry'. He had missed Taeyang's sports day the day before.",
   "어느 날 아침 아버지가 남긴 낱말은 '미안'이었다. 아버지는 전날 태양의 운동회에 오지 못했던 것이다.",
   "아버지가 '미안'이라는 낱말을 남김"),
  ("Taeyang moved the magnets for a long time. His answer had two words: 'next time'.",
   "태양은 오랫동안 자석을 옮겼다. 그의 답은 두 낱말, '다음에는'이었다.",
   "태양이 '다음에는'이라고 답함"),
  "{2}의 'the word his father left(아버지가 남긴 낱말)'는 {1}에서 아버지가 답으로 낱말을 남긴다고 해야 나올 수 있으니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'His answer(그의 답)'는 {2}의 'sorry'에 대한 답이니까 {2}보다 먼저 올 수 없어요.",
  "{1}가 놀이 방법을 설명하고, {2}의 'the word his father left'는 {1}의 'a word in answer'를, {3}의 'His answer'는 {2}의 'sorry'를 받아요.",
  "magnet 자석 / spell 철자를 쓰다 / sports day 운동회")

# 12 ─ 이동: 박물관에서 길을 잃음
S(11, 'BDC',
  ("Yeji lost her group on a school trip to the museum.",
   "예지는 박물관으로 간 학교 소풍에서 자기 무리를 놓쳤다."),
  ("She looked for her teacher in three rooms, but every room was full of other students. She began to feel afraid.",
   "그녀는 세 개의 전시실에서 선생님을 찾았지만, 전시실마다 다른 학생들로 가득했다. 그녀는 무서워지기 시작했다.",
   "세 전시실을 찾았지만 못 찾고 무서워짐"),
  ("A guard saw her frightened face and asked which school she was from. He took her to the front desk.",
   "한 경비원이 그녀의 겁먹은 얼굴을 보고 어느 학교에서 왔는지 물었다. 그는 그녀를 안내 데스크로 데려갔다.",
   "경비원이 안내 데스크로 데려감"),
  ("At that desk a woman called Yeji's name over the speaker. Her teacher came running from the dinosaur room.",
   "그 데스크에서 한 여자가 방송으로 예지의 이름을 불렀다. 선생님이 공룡 전시실에서 달려왔다.",
   "방송으로 이름을 부르자 선생님이 달려옴"),
  "{2}의 'her frightened face(겁먹은 얼굴)'는 {1}에서 무서워지기 시작한 뒤의 얼굴이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'that desk(그 데스크)'는 {2}에서 경비원이 데려간 안내 데스크니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'her frightened face'는 {1}의 'afraid'를, {3}의 'that desk'는 {2}의 'the front desk'를 가리켜요.",
  "museum 박물관 / guard 경비원 / front desk 안내 데스크")

# 13 ─ 하루: 아버지의 도시락
S(12, 'DCB',
  ("Minho's father left for work without his lunch box.",
   "민호의 아버지는 도시락을 두고 출근했다."),
  ("Minho found it on the table at eight. His father's office was only two bus stops away, so he decided to take it there.",
   "민호는 여덟 시에 식탁 위에서 도시락을 발견했다. 아버지의 사무실은 버스 정류장 두 개 거리밖에 안 되어서, 그는 도시락을 가져다주기로 했다.",
   "도시락을 발견하고 가져다주기로 함"),
  ("At the bus stop he saw the bus leaving. He decided to walk instead.",
   "정류장에서 그는 버스가 떠나는 것을 보았다. 그는 대신 걸어가기로 했다.",
   "버스를 놓쳐 걸어가기로 함"),
  ("He reached the office at nine, red and tired. His father laughed and shared the lunch with him.",
   "그는 아홉 시에 얼굴이 빨개지고 지친 채 사무실에 도착했다. 아버지는 웃으며 그와 도시락을 나누어 먹었다.",
   "지친 채 도착하자 아버지가 도시락을 나눠 먹음"),
  "{2}의 'the bus stop(그 정류장)'은 {1}에서 정류장 두 개 거리라고 한 뒤에 나오니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'red and tired(빨개지고 지친)'는 {2}에서 걸어갔기 때문이니까 {2}보다 먼저 올 수 없어요.",
  "시각이 여덟 시({1}) → 아홉 시({3})로 흐르고, 그 사이의 {2}에서 버스를 놓쳐 걸었기 때문에 {3}에서 지친 거예요.",
  "lunch box 도시락 / office 사무실 / share 나누다")

# 14 ─ 회상: 문 옆의 나무 썰매
S(13, 'BDC',
  ("Every winter Mr. Han hangs an old wooden sled by the door of his gym.",
   "해마다 겨울이면 한 씨는 자기 체육관 문 옆에 낡은 나무 썰매를 걸어 둔다."),
  ("It was his first sled. His father made it from an old door when there was no money for a real one.",
   "그것은 그의 첫 썰매였다. 진짜 썰매를 살 돈이 없을 때 아버지가 낡은 문짝으로 만들어 준 것이었다.",
   "아버지가 문짝으로 만들어 준 첫 썰매임"),
  ("The homemade sled was heavy and slow. Still, he pulled it up the hill a hundred times every winter.",
   "손수 만든 썰매는 무겁고 느렸다. 그래도 그는 겨울마다 그것을 언덕 위로 백 번씩 끌어올렸다.",
   "무거운 썰매를 겨울마다 백 번씩 끌어올림"),
  ("Those hard winters made him strong, and years later he became a sports teacher. He hangs the sled by the door so that his students see where he started.",
   "그 힘든 겨울들이 그를 튼튼하게 만들었고, 몇 년 뒤 그는 체육 교사가 되었다. 그는 학생들이 자기가 어디서 시작했는지 보도록 썰매를 문 옆에 걸어 둔다.",
   "그 겨울들 덕분에 체육 교사가 됨"),
  "{2}의 'The homemade sled(손수 만든 썰매)'는 {1}에서 아버지가 만들었다고 해야 나올 수 있으니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'Those hard winters(그 힘든 겨울들)'는 {2}에서 겨울마다 백 번씩 끌어올린 일을 가리키니까 {2}보다 먼저 올 수 없어요.",
  "주어진 글의 썰매를 {1}의 'It'이 받고, {2}의 'The homemade sled'는 {1}의 만든 썰매를, {3}의 'Those hard winters'는 {2}의 겨울들을 가리켜요.",
  "sled 썰매 / homemade 손수 만든 / hill 언덕")

# 15 ─ 대화: 건널목 아저씨의 아침 인사
S(14, 'CBD',
  ("Lily asked the man at the school crossing why he said good morning to every child.",
   "릴리는 학교 앞 건널목 아저씨에게 왜 아이들 모두에게 아침 인사를 하는지 물었다."),
  ("He said that one day, years ago, nobody had spoken to him from morning till night. He had felt invisible.",
   "아저씨는 몇 년 전 어느 날, 아침부터 밤까지 아무도 자기에게 말을 걸지 않은 적이 있다고 말했다. 그는 자기가 보이지 않는 사람처럼 느껴졌다고 했다.",
   "아무도 말을 걸지 않아 보이지 않는 사람 같았던 날 이야기"),
  ("Lily asked whether the children answered him now. He said that most of them did, and that some even waited for him when he was late.",
   "릴리는 지금은 아이들이 인사를 받아 주느냐고 물었다. 아저씨는 대부분 그렇고, 어떤 아이들은 그가 늦으면 기다려 주기까지 한다고 말했다.",
   "지금은 대부분 인사를 받아 주고 기다려 주기도 함"),
  ("That answer made Lily smile. The next morning she said good morning first, before he could.",
   "그 대답에 릴리는 웃었다. 다음 날 아침 그녀는 아저씨가 인사하기 전에 먼저 아침 인사를 했다.",
   "릴리가 다음 날 먼저 인사함"),
  "{2}의 'answered him now(지금은 받아 주는지)'는 {1}에서 아무도 말을 걸지 않았다는 이야기 뒤에 나올 물음이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'That answer(그 대답)'는 {2}에서 아저씨가 한 대답이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'now'는 {1}의 'years ago'와 짝을 이루고, {3}의 'That answer'는 {2}의 대답을 가리켜요.",
  "crossing 건널목 / invisible 보이지 않는 / answer 대답하다")

# 16 ─ 결말: 월요일의 꽃
S(15, 'CBD',
  ("Every Monday someone left a flower on the teacher's desk, and nobody in Dana's class knew who it was.",
   "월요일마다 누군가 선생님 책상 위에 꽃 한 송이를 놓고 갔는데, 다나네 반에서는 아무도 누군지 몰랐다."),
  ("The students made a list of everyone who came to school early. Three names were on it.",
   "학생들은 학교에 일찍 오는 사람들의 명단을 만들었다. 거기에는 이름 셋이 있었다.",
   "일찍 오는 사람 명단을 만드니 셋이 나옴"),
  ("Dana watched those three students for a month, but none of them ever carried a flower. The flower still came every Monday.",
   "다나는 한 달 동안 그 세 학생을 지켜보았지만, 아무도 꽃을 들고 오지 않았다. 꽃은 여전히 월요일마다 놓여 있었다.",
   "한 달 동안 셋을 지켜봤지만 아무도 아님"),
  ("After that month Dana came even earlier than those three. She saw the teacher herself put a flower on the desk, from her own garden.",
   "그 한 달이 지난 뒤 다나는 그 셋보다 더 일찍 학교에 왔다. 그녀는 선생님이 직접 자기 정원에서 가져온 꽃을 책상에 놓는 것을 보았다.",
   "더 일찍 와 보니 선생님이 직접 놓고 있었음"),
  "{2}의 'those three students(그 세 학생)'는 {1}의 명단에 오른 셋이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'After that month(그 한 달 뒤)'는 {2}에서 한 달을 지켜본 뒤니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'those three students'는 {1}의 'Three names'를, {3}의 'that month'는 {2}의 'a month'를 가리켜요.",
  "list 명단 / carry 들고 다니다 / garden 정원")

# 17 ─ 번갈아: 편지 대신 그림
S(16, 'CDB',
  ("Sora and her grandfather sent each other drawings instead of letters.",
   "소라와 할아버지는 편지 대신 그림을 주고받았다."),
  ("Sora drew their house and sent it. Her grandfather sent back the same house with a small tent in the garden.",
   "소라는 자기 집을 그려서 보냈다. 할아버지는 정원에 작은 텐트가 있는 같은 집 그림을 보내왔다.",
   "소라의 집 그림에 할아버지가 텐트를 그려 보냄"),
  ("Sora had no tent. She drew the house again, with a question mark where the tent was.",
   "소라네에는 텐트가 없었다. 그녀는 텐트가 있던 자리에 물음표를 넣어 집을 다시 그렸다.",
   "텐트 자리에 물음표를 그려 보냄"),
  ("The next drawing from her grandfather showed him carrying a big bag on his back. The following Sunday he arrived with a real tent, and they slept in the garden.",
   "할아버지의 다음 그림에는 큰 가방을 등에 멘 할아버지가 있었다. 다음 일요일에 할아버지는 진짜 텐트를 가지고 왔고, 두 사람은 정원에서 잤다.",
   "할아버지가 진짜 텐트를 가지고 와서 정원에서 잠"),
  "{2}의 'the tent(그 텐트)'는 {1}에서 할아버지가 그린 텐트니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'The next drawing(다음 그림)'은 {2}에서 소라가 물음표를 보낸 뒤의 답이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'the tent'는 {1}의 'a small tent'를, {3}의 'The next drawing'은 {2}의 물음표 그림 다음 그림을 가리켜요.",
  "instead of ~ 대신 / question mark 물음표 / following 다음의")

# 18 ─ 이동: 공항 가기 전에
S(17, 'CDB',
  ("Woojin had to take Jun's school bag to Jun's house before Jun's family left for the airport at six.",
   "우진은 준의 가족이 여섯 시에 공항으로 떠나기 전에 준의 책가방을 준의 집에 가져다주어야 했다."),
  ("He left school at five and got on a bus. The bus got stuck behind a broken truck.",
   "그는 다섯 시에 학교를 나와 버스를 탔다. 버스는 고장 난 트럭 뒤에서 꼼짝 못 하게 되었다.",
   "버스가 트럭 뒤에서 꼼짝 못 함"),
  ("He got off and ran along the river with the bag. His watch said five to six when he saw Jun's street.",
   "그는 버스에서 내려 가방을 들고 강을 따라 달렸다. 준의 집 골목이 보였을 때 그의 시계는 여섯 시 5분 전이었다.",
   "내려서 달려 5분 전에 골목에 닿음"),
  ("In that street a car was already waiting with its engine running. Jun's mother saw Woojin, took the bag through the window and waved.",
   "그 골목에는 이미 시동이 걸린 차 한 대가 기다리고 있었다. 준의 어머니는 우진을 보고 창문으로 가방을 받아 손을 흔들었다.",
   "골목의 차에 가방을 건넴"),
  "{2}의 'got off(내렸다)'는 {1}에서 탄 버스에서 내리는 것이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'that street(그 골목)'는 {2}에서 본 준의 집 골목이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'got off'는 {1}의 버스에서 내리는 것이고, {3}의 'that street'는 {2}의 'Jun's street'를 가리켜요.",
  "airport 공항 / stuck 꼼짝 못 하는 / engine 엔진, 시동")

# 19 ─ 하루: 할머니의 사진첩
S(18, 'DCB',
  ("Hyun wanted to make a photo album for his grandmother's birthday, which was that evening.",
   "현은 그날 저녁이 할머니 생신이어서 생신 선물로 사진첩을 만들고 싶었다."),
  ("In the morning he looked through old boxes and found forty photos. Many of them were brown and torn.",
   "아침에 그는 오래된 상자들을 뒤져 사진 마흔 장을 찾았다. 그중 많은 사진이 누렇게 바래고 찢어져 있었다.",
   "아침에 찾은 사진 중 많은 것이 찢어져 있음"),
  ("He took those torn photos to the print shop. The man there said that fixing them would take all afternoon.",
   "그는 그 찢어진 사진들을 사진관에 가져갔다. 사진관 아저씨는 고치는 데 오후 내내 걸릴 거라고 말했다.",
   "사진관에서 오후 내내 걸린다고 함"),
  ("Hyun waited in the shop and helped to sort the pictures. At six he ran home with the album, just as the family sat down for dinner.",
   "현은 가게에서 기다리며 사진을 정리하는 것을 도왔다. 여섯 시에 그는 사진첩을 들고 집으로 달려갔고, 마침 가족이 저녁을 먹으려고 앉던 참이었다.",
   "가게에서 기다렸다가 저녁에 사진첩을 들고 감"),
  "{2}의 'those torn photos(그 찢어진 사진들)'는 {1}에서 찾은 찢어진 사진이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'waited in the shop(가게에서 기다렸다)'은 {2}에서 오후 내내 걸린다고 한 뒤의 일이니까 {2}보다 먼저 올 수 없어요.",
  "하루의 흐름이에요. {1}는 'In the morning', {2}는 'all afternoon', {3}는 'At six'이고, {2}의 'those torn photos'는 {1}의 찢어진 사진을 가리켜요.",
  "album 사진첩 / torn 찢어진 / sort 정리하다")

# 20 ─ 회상: 운전석 앞의 그림
S(19, 'BDC',
  ("Mr. Song, a truck driver, keeps a child's drawing above the wheel of his truck.",
   "트럭 운전사인 송 씨는 트럭 운전대 위에 어린아이의 그림 한 장을 붙여 두고 있다."),
  ("A little girl drew it in his truck ten years ago, on a snowy night when no buses ran. Her mother cried in the back all the way.",
   "10년 전, 버스가 다니지 않던 눈 오는 밤에 한 어린 소녀가 그의 트럭 안에서 그것을 그렸다. 소녀의 어머니는 가는 내내 뒷자리에서 울었다.",
   "10년 전 눈 오는 밤에 소녀가 그린 그림"),
  ("The girl gave him the drawing when they got out. It showed a truck with a big smiling sun above it.",
   "소녀는 내릴 때 그에게 그림을 주었다. 그림에는 트럭 위로 크게 웃는 해가 그려져 있었다.",
   "소녀가 웃는 해가 그려진 그림을 줌"),
  ("Last month a young woman got into his truck and looked at the picture for a long time. Then she said, 'My mother is fine now, and the sun is still smiling.'",
   "지난달 한 젊은 여자가 그의 트럭에 타더니 그 그림을 오랫동안 바라보았다. 그러고는 '우리 엄마는 이제 괜찮아요. 그리고 해는 아직도 웃고 있네요.'라고 말했다.",
   "자란 소녀가 트럭에 타서 그림을 알아봄"),
  "{2}의 'The girl(그 소녀)'과 'they got out(내렸다)'은 {1}에서 트럭을 탄 소녀와 어머니 이야기 뒤에 와야 하니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'the sun is still smiling(해가 아직도 웃고 있다)'은 {2}에서 웃는 해가 그려져 있다고 해야 알 수 있으니까 {2}보다 먼저 올 수 없어요.",
  "주어진 글의 그림을 {1}의 'it'이 받고, {2}의 'The girl'은 {1}의 소녀를, {3}의 'the sun is still smiling'은 {2}의 웃는 해를 가리켜요.",
  "wheel 운전대 / snowy 눈 오는 / smiling 웃는")

# 21 ─ 대화: 주머니 속의 돌
S(20, 'DCB',
  ("Jun asked his uncle why he always kept a small stone in his pocket.",
   "준은 삼촌에게 왜 늘 주머니에 작은 돌을 넣고 다니는지 물었다."),
  ("His uncle took out the stone, which was round and grey. He said that it came from the bottom of a river.",
   "삼촌은 둥글고 회색인 그 돌을 꺼냈다. 삼촌은 그것이 강바닥에서 가져온 것이라고 말했다.",
   "강바닥에서 가져온 돌임"),
  ("Jun asked whether the river was wide. His uncle said that he had tried three times to swim across it as a boy, and that he had almost given up.",
   "준은 그 강이 넓었느냐고 물었다. 삼촌은 어릴 때 그 강을 헤엄쳐 건너려고 세 번이나 시도했고, 거의 포기할 뻔했다고 말했다.",
   "세 번 시도해 거의 포기할 뻔한 강 이야기"),
  ("Then he put the stone in Jun's hand and said that it felt heavy only when you stopped swimming. Jun did not understand then, but he does now.",
   "그러고는 삼촌은 준의 손에 돌을 쥐여 주며, 이 돌은 헤엄을 멈출 때만 무겁게 느껴진다고 말했다. 준은 그때는 이해하지 못했지만 지금은 이해한다.",
   "'헤엄을 멈출 때만 무겁다'는 말을 들음"),
  "{2}의 'the river(그 강)'는 {1}에서 삼촌이 말한 강이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'stopped swimming(헤엄을 멈추다)'은 {2}에서 강을 헤엄쳐 건넌 이야기 뒤에 와야 하니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'the river'는 {1}의 'a river'를, {3}의 'stopped swimming'은 {2}의 'swim across'를 받아요.",
  "pocket 주머니 / bottom 바닥 / give up 포기하다")

# 22 ─ 결말: 벽 속의 발소리
S(21, 'DCB',
  ("Every night Soyeon heard a strange noise inside the wall of her room.",
   "소연은 밤마다 방 벽 안에서 이상한 소리를 들었다."),
  ("It sounded like small running feet. Her father said that it was the wind, but the wind does not run.",
   "그것은 작은 발이 달리는 소리 같았다. 아버지는 바람 소리라고 했지만, 바람은 달리지 않는다.",
   "아버지는 바람이라고 하지만 소연은 믿지 않음"),
  ("To prove her father wrong, she put flour on the floor by the wall. In the morning there were tiny footprints in it.",
   "아버지가 틀렸다는 것을 보여 주려고 그녀는 벽 옆 바닥에 밀가루를 뿌렸다. 아침에 밀가루 위에 작은 발자국들이 찍혀 있었다.",
   "밀가루를 뿌리자 작은 발자국이 찍힘"),
  ("The footprints led to a hole behind the bookcase. Inside lived a family of mice, and her father stopped talking about the wind.",
   "발자국은 책장 뒤의 구멍으로 이어졌다. 그 안에는 생쥐 가족이 살고 있었고, 아버지는 더 이상 바람 이야기를 하지 않았다.",
   "발자국이 생쥐 가족의 구멍으로 이어짐"),
  "{2}의 'To prove her father wrong(아버지가 틀렸음을 보여 주려고)'은 {1}에서 아버지가 바람이라고 한 뒤니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'The footprints(그 발자국)'는 {2}에서 밀가루에 찍힌 발자국이니까 {2}보다 먼저 올 수 없어요.",
  "주어진 글의 소리를 {1}의 'It'이 받고, {2}의 'her father wrong'은 {1}의 바람 이야기를, {3}의 'The footprints'는 {2}의 'tiny footprints'를 가리켜요.",
  "prove 증명하다 / flour 밀가루 / footprint 발자국")

# 23 ─ 번갈아: 주차 자리 다툼
S(22, 'BDC',
  ("Ben and his neighbour Mr. Oh both wanted the one parking space in front of their building.",
   "벤과 이웃 오 씨는 둘 다 건물 앞의 하나뿐인 주차 자리를 원했다."),
  ("Ben parked there first every morning. So Mr. Oh started to get up earlier than Ben.",
   "벤은 아침마다 먼저 그 자리에 차를 세웠다. 그래서 오 씨는 벤보다 일찍 일어나기 시작했다.",
   "벤이 먼저 세우자 오 씨가 더 일찍 일어남"),
  ("Soon both of them were up before six. One day they reached the space at the same moment and laughed.",
   "곧 두 사람 모두 여섯 시 전에 일어나게 되었다. 어느 날 두 사람은 같은 순간에 그 자리에 도착했고 웃음을 터뜨렸다.",
   "둘 다 여섯 시 전에 일어나다 같은 순간에 만나 웃음"),
  ("After that morning they made a rule. Ben takes the space on even days, and Mr. Oh takes it on odd days.",
   "그날 아침 이후 두 사람은 규칙을 만들었다. 짝수 날에는 벤이, 홀수 날에는 오 씨가 그 자리를 쓴다.",
   "규칙을 만들어 날을 나눔"),
  "{2}의 'Soon both of them were up before six(곧 둘 다 여섯 시 전에 일어났다)'는 {1}에서 오 씨가 더 일찍 일어나기 시작한 뒤의 일이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'After that morning(그날 아침 이후)'은 {2}에서 같은 순간에 만나 웃은 아침이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'Soon'은 {1}의 '더 일찍 일어나기 시작함' 다음이고, {3}의 'that morning'은 {2}의 'One day'를 가리켜요.",
  "parking space 주차 자리 / even 짝수의 / odd 홀수의")

# 24 ─ 이동: 얼어붙은 호수
S(23, 'DBC',
  ("Eunho's family moved to a new town in the middle of winter.",
   "은호네 가족은 한겨울에 새 동네로 이사했다."),
  ("On his first day he walked to school alone and took a wrong turn. He ended up beside a frozen lake.",
   "첫날 그는 혼자 학교까지 걸어가다가 길을 잘못 들었다. 그는 얼어붙은 호숫가에 이르렀다.",
   "길을 잘못 들어 얼어붙은 호수에 이름"),
  ("An old man was fishing through a hole in the ice. He pointed the way to the school.",
   "한 노인이 얼음에 뚫은 구멍으로 낚시를 하고 있었다. 노인은 학교 가는 길을 가리켜 주었다.",
   "얼음낚시하던 노인이 길을 알려 줌"),
  ("Eunho was late that day, but he went back to that lake every Sunday. The old man taught him how to fish.",
   "은호는 그날 지각했지만, 일요일마다 그 호수에 다시 갔다. 노인은 그에게 낚시하는 법을 가르쳐 주었다.",
   "일요일마다 호수에 가서 낚시를 배움"),
  "{2}의 'the ice(그 얼음)'는 {1}에서 호수가 얼어 있다고 해야 나올 수 있으니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'The old man(그 노인)'은 {2}에서 낚시하던 노인이니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'the ice'는 {1}의 'frozen lake'를, {3}의 'The old man'은 {2}의 'An old man'을 가리켜요.",
  "frozen 얼어붙은 / hole 구멍 / late 늦은")

# 25 ─ 하루: 책갈피 장터
S(24, 'CBD',
  ("At the school fair, Nari's class sold bookmarks that they had made by hand.",
   "학교 장터에서 나리네 반은 손수 만든 책갈피를 팔았다."),
  ("In the morning nobody stopped at their table. The bookmarks were pretty but small, and people walked past them.",
   "아침에는 아무도 그들의 탁자 앞에 멈추지 않았다. 책갈피는 예뻤지만 작아서, 사람들은 그냥 지나쳐 갔다.",
   "아침에는 아무도 사지 않음"),
  ("At noon Nari put one bookmark inside every book on the free shelf next door. People found them and came to ask where they came from.",
   "정오에 나리는 옆자리 무료 책꽂이의 책마다 책갈피를 하나씩 끼워 두었다. 사람들이 그것을 발견하고 어디서 난 것인지 물으러 왔다.",
   "정오에 무료 책꽂이 책마다 책갈피를 끼움"),
  ("By three o'clock every bookmark was sold. The class used the money to buy ten new books for that shelf.",
   "세 시가 되자 책갈피는 모두 팔렸다. 반은 그 돈으로 그 책꽂이에 둘 새 책 열 권을 샀다.",
   "세 시에 다 팔려 그 책꽂이에 새 책을 사 줌"),
  "{2}의 'At noon(정오에)'은 {1}의 'In the morning' 다음이고, 책갈피를 끼운 것도 {1}에서 팔리지 않았기 때문이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'that shelf(그 책꽂이)'는 {2}에서 책갈피를 끼운 무료 책꽂이니까 {2}보다 먼저 올 수 없어요.",
  "하루의 흐름이에요. {1}는 'In the morning', {2}는 'At noon', {3}는 'By three o'clock'이고, {3}의 'that shelf'는 {2}의 'the free shelf'를 가리켜요.",
  "fair 장터 / bookmark 책갈피 / shelf 책꽂이")

# 26 ─ 회상: 빈 새장
S(25, 'CDB',
  ("Mr. Yoon keeps an empty bird cage in the corner of his classroom.",
   "윤 선생님은 교실 구석에 빈 새장을 두고 있다."),
  ("Thirty years ago his class kept a yellow canary in it. The bird sang every morning before the first lesson.",
   "30년 전 그의 반은 그 새장에서 노란 카나리아 한 마리를 길렀다. 그 새는 아침마다 첫 수업 전에 노래했다.",
   "30년 전 반에서 기르던 카나리아가 아침마다 노래함"),
  ("One spring the window was left open, and the canary flew away. The students were sad for weeks.",
   "어느 봄 창문이 열려 있었고, 카나리아는 날아가 버렸다. 학생들은 몇 주 동안 슬퍼했다.",
   "어느 봄 카나리아가 날아가 버림"),
  ("Then a yellow bird began to sing in the tree outside every morning. Mr. Yoon keeps the cage empty so that his students remember the one that chose to be free.",
   "그러다 아침마다 밖의 나무에서 노란 새가 노래하기 시작했다. 윤 선생님은 학생들이 자유를 택한 그 새를 기억하도록 새장을 비워 둔다.",
   "밖의 나무에서 노란 새가 노래하기 시작함"),
  "{2}의 'the canary(그 카나리아)'는 {1}에서 기르던 카나리아니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'Then(그러다)'과 'outside(밖에서)'는 {2}에서 새가 날아간 뒤의 일이니까 {2}보다 먼저 올 수 없어요.",
  "주어진 글의 새장을 {1}의 'it'이 받고, {2}의 'the canary'는 {1}의 카나리아를, {3}의 'the one that chose to be free'는 {2}에서 날아간 새를 가리켜요.",
  "cage 새장 / canary 카나리아 / free 자유로운")

# 27 ─ 대화: 세 번 두드리기
S(26, 'BDC',
  ("Mina asked her father why he always tapped the car three times before he drove.",
   "미나는 아버지에게 왜 운전하기 전에 늘 차를 세 번 두드리는지 물었다."),
  ("He said that his own father had done the same thing. Mina asked whether it was for luck.",
   "아버지는 자기 아버지도 똑같이 했다고 말했다. 미나는 행운을 비는 거냐고 물었다.",
   "할아버지도 그랬다고 하자 행운 때문이냐고 물음"),
  ("Her father thought for a moment and said no. One tap was for the brakes, one for the lights and one for the people inside, he said.",
   "아버지는 잠시 생각하더니 아니라고 했다. 한 번은 브레이크, 한 번은 전조등, 한 번은 안에 탄 사람들을 위한 거라고 아버지는 말했다.",
   "브레이크·전조등·사람을 위한 세 번이라고 답함"),
  ("Mina asked what the third tap meant. 'To remember that they matter more than the car,' he said.",
   "미나는 세 번째 두드림은 무슨 뜻이냐고 물었다. '사람들이 차보다 더 소중하다는 걸 기억하려고.'라고 아버지는 말했다.",
   "세 번째 두드림의 뜻을 물음"),
  "{2}의 'said no(아니라고 했다)'는 {1}에서 행운이냐고 물은 데 대한 대답이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'the third tap(세 번째 두드림)'은 {2}에서 세 번의 뜻을 말한 뒤에 물을 수 있으니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'said no'는 {1}의 'for luck?'에 대한 대답이고, {3}의 'the third tap'은 {2}의 'one for the people inside'를 가리켜요.",
  "tap 가볍게 두드리다 / luck 행운 / matter 중요하다")

# 28 ─ 결말: 빈집의 불빛
S(27, 'DBC',
  ("Every night at ten, a light came on in the empty house next to Jay's.",
   "밤마다 열 시가 되면 제이네 옆 빈집에 불이 켜졌다."),
  ("Nobody had lived there for a year. Jay's mother said that it was a timer, but Jay was not sure.",
   "그 집에는 1년 동안 아무도 살지 않았다. 제이의 어머니는 자동 타이머라고 했지만, 제이는 확신할 수 없었다.",
   "어머니는 타이머라고 하지만 제이는 확신이 없음"),
  ("To find out, he watched from his window with a camera. At ten the light came on, and a shadow moved across the curtain.",
   "알아내려고 그는 사진기를 들고 창문에서 지켜보았다. 열 시에 불이 켜졌고, 그림자 하나가 커튼을 가로질러 움직였다.",
   "지켜보다가 커튼에 비친 그림자를 찍음"),
  ("The next day he showed the photo to his mother. She laughed and said that the shadow was a tall plant moving in the warm air from the heater.",
   "다음 날 그는 어머니에게 그 사진을 보여 주었다. 어머니는 웃으며 그 그림자는 난방기의 따뜻한 바람에 흔들리는 키 큰 화초라고 말했다.",
   "그림자의 정체는 바람에 흔들리는 화초였음"),
  "{2}의 'To find out(알아내려고)'은 {1}에서 제이가 확신하지 못한 뒤의 일이니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'the photo(그 사진)'와 'the shadow(그 그림자)'는 {2}에서 찍은 사진과 그림자니까 {2}보다 먼저 올 수 없어요.",
  "{2}의 'To find out'은 {1}의 'not sure'를 받고, {3}의 'the photo'와 'the shadow'는 {2}의 사진기와 그림자를 가리켜요.",
  "timer 타이머 / curtain 커튼 / heater 난방기")

# 29 ─ 번갈아: 아침 식탁의 끝말잇기
S(28, 'BDC',
  ("Haru and her grandmother played a word game at breakfast every day.",
   "하루와 할머니는 날마다 아침 식탁에서 낱말 놀이를 했다."),
  ("Haru said a word, and her grandmother had to say one that began with its last letter. The game never ended before school.",
   "하루가 낱말을 말하면, 할머니는 그 낱말의 마지막 글자로 시작하는 낱말을 말해야 했다. 놀이는 학교 가기 전까지 끝나는 법이 없었다.",
   "끝말을 잇는 놀이를 매일 함"),
  ("One morning her grandmother was slow and said a word that did not fit. Haru pretended not to notice.",
   "어느 날 아침 할머니는 느려졌고 맞지 않는 낱말을 말했다. 하루는 못 알아챈 척했다.",
   "할머니가 틀렸지만 하루가 모른 척함"),
  ("After that morning Haru began to choose easy words. Her grandmother never found out, and the game still goes on.",
   "그날 아침 이후 하루는 쉬운 낱말을 고르기 시작했다. 할머니는 끝내 알아채지 못했고, 놀이는 지금도 이어지고 있다.",
   "그 뒤로 쉬운 낱말만 골라 놀이가 이어짐"),
  "{2}의 'a word that did not fit(맞지 않는 낱말)'은 {1}에서 놀이 규칙을 설명해야 알 수 있으니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'After that morning(그날 아침 이후)'은 {2}에서 할머니가 틀린 아침이니까 {2}보다 먼저 올 수 없어요.",
  "{1}가 규칙을 설명하고, {2}의 'did not fit'은 {1}의 규칙에 맞지 않았다는 뜻이며, {3}의 'that morning'은 {2}의 'One morning'을 가리켜요.",
  "last letter 마지막 글자 / pretend ~인 척하다 / notice 알아채다")

# 30 ─ 이동: 할아버지를 찾아서
S(29, 'CBD',
  ("Juno was sent to bring his grandfather home from the field for dinner.",
   "주노는 저녁을 먹으러 오시라고 할아버지를 밭에서 모셔 오는 심부름을 받았다."),
  ("He walked to the field by the river, but his grandfather was not there. Only his hat lay on the ground.",
   "그는 강가의 밭으로 걸어갔지만 할아버지는 거기 없었다. 땅에는 할아버지의 모자만 놓여 있었다.",
   "밭에는 모자만 남아 있음"),
  ("Juno picked up the hat and followed the path up the hill. From the top he saw smoke rising near the big pine tree.",
   "주노는 모자를 집어 들고 언덕으로 오르는 길을 따라갔다. 꼭대기에서 그는 큰 소나무 근처에서 연기가 오르는 것을 보았다.",
   "모자를 들고 언덕에 올라 연기를 봄"),
  ("His grandfather was there, roasting sweet potatoes on a small fire. They ate two and carried the rest home for dinner.",
   "할아버지는 거기서 작은 모닥불에 고구마를 굽고 있었다. 두 사람은 두 개를 먹고 나머지를 저녁거리로 집에 가져갔다.",
   "소나무 아래에서 고구마를 굽던 할아버지를 찾음"),
  "{2}의 'the hat(그 모자)'은 {1}에서 땅에 놓여 있던 모자니까 {1}보다 먼저 올 수 없어요.",
  "{3}의 'there(거기)'와 'a small fire(작은 모닥불)'는 {2}에서 본 연기가 나는 곳이니까 {2}보다 먼저 올 수 없어요.",
  "장소가 밭({1}) → 언덕 위({2}) → 소나무 아래({3})로 옮겨 가고, {2}의 'the hat'은 {1}의 모자를, {3}의 'there'는 {2}의 연기 나는 곳을 가리켜요.",
  "field 밭 / smoke 연기 / roast 굽다")

assert len(E) == 30
