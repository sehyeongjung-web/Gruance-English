# -*- coding: utf-8 -*-
# 176번(예정): 23번(주제 찾기) 레벨9 해설 두텁게 — 시범 1~3번째. 해설·풀이만 바꿈(지문·선택지·정답 변동 없음)
AUTO_SYNC = False
E = {}
TIP = ("【주제 찾기 요령】\n"
       "첫째, 같은 생각이 모양만 바꿔 되풀이되는 곳을 찾습니다. 가장 많이 되풀이된 생각이 주제입니다.\n"
       "둘째, 흐름이 꺾이는 말(but, yet, not A but B) 뒤가 글쓴이의 생각입니다.\n"
       "셋째, 끝까지 읽습니다. 주제가 마지막 문장에만 나오는 글도 있습니다.\n"
       "넷째, 되풀이된 생각을 다른 낱말로 묶은 선택지를 고릅니다. 지문 낱말이 그대로 들어 있다고 고르지 않습니다.")
def W(steps, traps):
    return TIP + "\n\n【이 문제에 적용】\n" + "\n".join(steps) + "\n\n【끌리는 오답】\n" + traps


# --- 도우미: «…»는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜. 선택지 영어는 문항에서 자동으로 가져옴 ---
import sys; sys.path.insert(0,'.')
from lib import load as _load
_tb = _load()[1]
def _q(x): return x.replace('«','"').replace('»','"')
def mk(n, steps, traps, cn):
    it = _tb['23']['9'][n]; assert len(cn)==5 and len(steps)==4, n
    out = {}
    for k,(ko,why) in enumerate(cn):
        out[k] = ("정답입니다. " if k==it['answer'] else "") + "'%s' (%s) — %s" % (it['choices'][k], ko, _q(why))
    E[('23','9',n)] = {'walk': W([_q(x) for x in steps], _q(traps)), 'cn': out}

# ---------- 1번째: 과학을 확실한 척 전하면 신뢰가 약해진다 ----------
E[('23','9',0)] = {
 'walk': W([
  "1) 되풀이: 「과학을 실제보다 확실한 것처럼 말한다」는 생각이 모양을 바꿔 네 번 나옵니다. \"as though it marked the end of inquiry\"(탐구의 끝인 것처럼) → \"described as settled\"(확정된 것으로 묘사된) → 'a bare claim'(앙상한 주장) → \"presenting science as more certain than it is\"(과학을 실제보다 더 확실하게 제시하는 것).",
  "2) 꺾이는 곳: 넷째 문장의 but입니다. 줄여 말하면 전하기는 편하지만, \"it leaves audiences without the means to distinguish a conclusion that would survive new evidence from one that would not\"(청중은 새 증거에도 버틸 결론과 못 버틸 결론을 가려낼 수단이 없어집니다).",
  "3) 끝 문장: 'Paradoxically, then'으로 결론을 못박습니다. \"does not make public trust more durable; it makes that trust brittle\"(대중의 신뢰를 더 튼튼하게 만들지 않고, 잘 부서지게 만든다). 이 글은 주제가 끝 문장에만 나오는 글입니다.",
  "4) 묶기: 되풀이된 생각 = 'overstating certainty'(확실함을 부풀리기). 끝 문장의 'does not make … more durable … brittle' = 'undermines rather than secures'(지켜 주기는커녕 무너뜨린다). 이 둘을 함께 담은 선택지가 답입니다."],
  "certain과 public trust가 지문 그대로 들어 있지만 방향이 거꾸로인 선택지(확실하게 제시해야 신뢰가 유지된다)가 가장 위험합니다. 끝 문장의 'does not'을 놓치면 고르게 됩니다. consensus, audiences처럼 지문 낱말만 빌려 온 선택지도 조심합니다."),
 'cn': {
  0: "'why presenting scientific findings as certain is necessary if public trust is to remain stable' (대중의 신뢰가 흔들리지 않으려면 과학적 발견을 확실한 것으로 제시해야 하는 이유) — 방향이 거꾸로입니다. certain, public trust가 지문 낱말 그대로라 가장 끌리지만, 끝 문장은 확실한 척하면 신뢰가 오히려 잘 부서진다(brittle)고 했습니다. 끝 문장의 'does not'을 놓친 학생이 고르는 함정입니다.",
  1: "'the role peer review plays in correcting errors after publication' (발표 뒤에 오류를 바로잡는 데 동료 검토가 하는 역할) — 지문에 없는 이야기입니다. 'revisions(수정)'라는 낱말에서 떠올리기 쉽지만, 동료 검토(peer review)는 한 번도 나오지 않습니다. 글은 수정을 누가 하는지가 아니라, 수정이 대중에게 어떻게 비치는지를 말합니다.",
  2: "정답입니다. 'how overstating certainty in science undermines rather than secures public trust' (과학에서 확실함을 부풀리는 것이 어떻게 대중의 신뢰를 지켜 주기는커녕 무너뜨리는가) — 끝 문장 \"presenting science as more certain than it is does not make public trust more durable; it makes that trust brittle\"을 다른 낱말로 바꿔 쓴 것입니다. 'presenting … as more certain'이 'overstating certainty'로, 'does not make … more durable … brittle'이 'undermines rather than secures'로 바뀌었습니다.",
  3: "'how consensus among researchers is reached in actively contested fields' (논쟁이 한창인 분야에서 연구자들의 합의가 이루어지는 방식) — 첫 낱말 consensus만 빌려 온 선택지입니다. 글이 다루는 것은 합의가 어떻게 이루어지는지가 아니라, 합의가 대중에게 어떻게 전해지는지(reported to the public)입니다. 첫 문장만 읽고 고르면 걸립니다.",
  4: "'the difficulty of translating technical terminology for non-specialist audiences in public documents' (공공 문서에서 전문 용어를 비전문가 독자에게 맞게 옮기는 어려움) — communication, audiences에서 떠올리기 쉬운 「과학 소통」 이야기지만 초점이 다릅니다. 글의 문제는 용어가 어렵다는 것이 아니라, 조건·검증 범위·수정 이력이 빠진 채 결론만 전해진다는 것입니다."}}

# ---------- 2번째: 한 산업에 꼭 맞춘 도시는 효율을 얻고 적응력을 잃는다 ----------
E[('23','9',1)] = {
 'walk': W([
  "1) 되풀이: 「한 산업에 꼭 맞춘 짜임」이 모양을 바꿔 계속 나옵니다. \"calibrated to that industry's needs\"(그 산업의 필요에 맞춰진) → 'this alignment'(이 맞물림) → \"the same tight coupling\"(바로 그 긴밀한 결합) → \"shaped to serve a system\"(한 체계에 봉사하도록 만들어진).",
  "2) 꺾이는 곳: 셋째 문장의 Yet입니다. Yet 앞은 얻은 것('remarkable efficiency', 놀라운 효율)이고, Yet 뒤는 그 값으로 치른 것입니다. \"narrowed the range of futures available\"(고를 수 있는 미래의 폭을 좁혔다).",
  "3) 끝 문장: 반대 사례로 확인합니다. 덜 조율된 지역이 더 빨리 회복한 까닭은 \"their looser fit left more of their capacities transferable\"(느슨하게 맞춰져 있어 더 많은 역량을 다른 데로 옮길 수 있었기 때문)입니다. 'not because … but because'에서 but 뒤를 읽어야 합니다.",
  "4) 묶기: 꼭 맞춘 짜임 = 'tight economic specialization'. 좁아진 미래와 옮길 수 있는 역량 = 'adaptability'(적응력). Yet 앞의 얻은 것 = 'present efficiency'. 'trades A for B'는 「A를 내주고 B를 얻는다」는 뜻이므로, Yet 앞과 뒤를 한 줄에 담은 선택지가 답입니다."],
  "끝 문장의 'recovered faster'에 주어만 바꿔 붙인 선택지(긴밀하게 특화된 지역이 가장 빨리 회복한다)가 가장 위험합니다. 빨리 회복한 쪽은 덜 조율된 지역입니다. civic institutions, trained, plan처럼 Yet 앞에만 나온 낱말로 만든 선택지도 조심합니다."),
 'cn': {
  0: "'why regional economies that specialize tightly are the quickest to recover from economic shocks' (긴밀하게 특화된 지역 경제가 경제 충격에서 가장 빨리 회복하는 이유) — 방향이 거꾸로입니다. 끝 문장의 'recovered faster'를 가져와 끌리지만, 빨리 회복한 쪽은 특화된 지역이 아니라 덜 조율된(less coordinated) 지역입니다. 누가 빨리 회복했는지 주어를 확인해야 합니다.",
  1: "정답입니다. 'how tight economic specialization trades future adaptability for present efficiency' (긴밀한 경제 특화가 어떻게 미래의 적응력을 내주고 지금의 효율을 얻는가) — Yet 앞(효율·번영)과 Yet 뒤(좁아진 미래, 바꿔 쓰기 어려운 기관)를 한 줄로 묶은 말입니다. 근거는 \"Yet the same tight coupling that generated prosperity also narrowed the range of futures available.\"입니다.",
  2: "'how civic institutions come to shape the character of local communities' (시민 기관이 지역 사회의 성격을 만들어 가는 방식) — 첫 문장의 civic institutions만 빌려 온 선택지입니다. 글에서 기관은 「한 산업에 맞춰진 것」의 예일 뿐이고, 기관이 지역의 성격을 만든다는 이야기는 없습니다. Yet 앞만 읽으면 걸립니다.",
  3: "'the role of vocational training in sustaining regional employment levels' (지역의 고용 수준을 유지하는 데 직업 훈련이 하는 역할) — 'workers arrived already trained(노동자들이 이미 훈련된 채로 왔다)'에서 떠올리기 쉽지만, 예 하나를 주제로 부풀린 것입니다. 직업 훈련이 고용을 지킨다는 주장은 지문에 없습니다.",
  4: "'why coordinated public planning consistently outperforms market-driven growth' (조율된 공공 계획이 시장 주도 성장보다 늘 나은 성과를 내는 이유) — 방향이 거꾸로이고, 지문에 없는 비교입니다. 'plan with confidence'에서 떠올리기 쉽지만, 끝 문장은 오히려 덜 조율된 지역이 더 빨리 회복했다고 합니다. 계획과 시장을 맞세우는 이야기도 글에 없습니다."}}

# ---------- 3번째: 음악의 슬픔을 알아보는 것과 느끼는 것은 다르다 ----------
E[('23','9',2)] = {
 'walk': W([
  "1) 통념: 첫 문장은 사실(청자들의 말이 서로 일치한다)이고, 둘째 문장은 거기서 일부 이론가가 끌어낸 결론입니다. \"the sadness resides in the music itself\"(슬픔은 음악 자체에 들어 있다). 'tempted … to conclude'(결론짓도록 유혹했다)라는 말투는 글쓴이가 이 결론과 거리를 둔다는 신호입니다.",
  "2) 꺾이는 곳: 셋째 문장의 But입니다. 청자들은 슬픔을 느끼지는 않는다고 답하고, \"they recognize sadness the way one recognizes it in a face\"(얼굴에서 슬픔을 알아보듯 알아본다)고 말합니다.",
  "3) 되풀이: But 뒤로 「알아보다 ↔ 느끼다」라는 짝이 모양을 바꿔 세 번 나옵니다. recognize ↔ feel → expresses(표현한다) ↔ induces(일으킨다) → expression ↔ \"what listeners actually undergo\"(청자가 실제로 겪는 것).",
  "4) 묶기: 'The distinction matters'(이 구별이 중요하다)가 글쓴이의 말입니다. 구별 = 'differs', 알아보기 = 'recognizing emotion', 느끼기·겪기 = 'experiencing that emotion'. 이 짝을 그대로 담은 선택지가 답입니다."],
  "'tempo and interval'이 들어 있는 선택지는 But 앞, 곧 일부 이론가의 생각을 옮긴 것입니다. 'make listeners feel'이 들어 있는 선택지는 들으면 느끼게 된다고 당연하게 여기는데, 글은 바로 그 둘을 갈라놓습니다."),
 'cn': {
  0: "'the techniques composers use to make listeners feel the emotions they hear' (청자가 듣는 감정을 직접 느끼게 하려고 작곡가들이 쓰는 기법) — 작곡가도 기법도 지문에 없습니다. 더 큰 문제는 「들은 감정을 느끼게 된다」를 당연하게 깔고 있다는 점입니다. 글이 갈라놓은 알아보기와 느끼기를 다시 하나로 합친 선택지입니다.",
  1: "정답입니다. 'why recognizing emotion in music differs from experiencing that emotion' (음악에서 감정을 알아보는 것이 그 감정을 겪는 것과 다른 이유) — But 뒤에서 되풀이되는 짝(recognize ↔ feel, expresses ↔ induces)을 묶은 말입니다. 근거는 \"The distinction matters, because it separates two claims that are easily conflated: that music expresses an emotion and that music induces it.\"입니다.",
  2: "'the influence of lyrics on the perceived mood of a song' (가사가 노래에서 느껴지는 분위기에 미치는 영향) — 지문에 없는 이야기입니다. 가사(lyrics)는 한 번도 나오지 않습니다. 「음악과 감정」이라는 소재만 같고, 글의 논점(알아보기 ↔ 느끼기)과는 관계가 없습니다.",
  3: "'how tempo and interval structure determine musical meaning' (박자와 음정 구조가 음악의 의미를 정하는 방식) — 'intervals and tempo'는 지문에 나오지만, But 앞에 소개된 일부 이론가의 결론입니다. 글쓴이는 But 뒤에서 초점을 「알아보기와 느끼기의 구별」로 옮깁니다. 통념을 주제로 착각하게 만드는 함정입니다.",
  4: "'why listeners disagree about the emotional content of music' (청자들이 음악에 담긴 감정에 대해 의견이 갈리는 이유) — 방향이 거꾸로입니다. 첫 문장은 청자들이 서로 일치한다(agree with one another)고 했습니다. agree를 disagree로 뒤집은 선택지입니다."}}

# ---------- 4번째: 선례는 결과가 아니라 논증의 말을 묶는다 ----------
mk(3, [
 "1) 통념: 첫 문장은 남들의 비판입니다. «binding the present to the reasoning of the past»(현재를 과거의 추론에 묶어 둔다). 'are sometimes criticized'는 글쓴이의 말이 아니라 남의 말을 소개하는 표현입니다.",
 "2) 꺾이는 곳: 둘째 문장 가운데의 'but in practice'입니다. 선례의 힘은 «how later courts characterize the case that produced it»(나중 법원이 그 사건을 어떻게 규정하느냐)에 달려 있다고 합니다. 쉼표 뒤에 숨은 but이라 놓치기 쉽습니다.",
 "3) 되풀이: 「묶이기는 하지만 결과까지 정해지지는 않는다」는 생각이 세 번 나옵니다. 'narrowed … or extended'(좁히거나 넓힐 수 있다) → «can shift substantially while every individual step claims fidelity»(걸음마다 충실하다고 하면서도 크게 옮겨 갈 수 있다) → «real but partial»(실제로 있지만 부분적이다).",
 "4) 묶기: 끝 문장 «it does not fix outcomes, it fixes the vocabulary in which departures must be justified»(결과를 고정하지 않고, 벗어남을 정당화할 때 써야 하는 말을 고정한다). 'fixes the vocabulary' = 'constrains legal reasoning'(법적 추론을 제약한다), 'does not fix outcomes' = 'without determining its eventual results'(최종 결과를 정하지는 않는다)."],
 "첫 문장의 비판을 그대로 옮긴 선택지(판사는 앞선 법원과 똑같은 결과에 묶인다)가 가장 위험합니다. 그것은 글쓴이가 but 뒤에서 고쳐 놓는 생각입니다. 반대로 너무 멀리 나가 선례를 무시해도 된다고 하는 선택지도 틀립니다. 글은 제약이 실제로 있다(real)고 했습니다.",
 [("판사들이 선례에 묶여 앞선 법원이 내린 것과 똑같은 결과에 이르게 되는 이유", "첫 문장에 소개된 비판을 그대로 옮긴 것입니다. 글쓴이는 'but in practice' 뒤에서 이 생각을 고칩니다. 끝 문장은 선례가 결과를 고정하지 않는다(does not fix outcomes)고 했으므로 방향이 거꾸로입니다."),
  ("판례 중심 법체계와 견준 성문법의 실제적 장점", "지문에 없는 비교입니다. 성문법(codified law)은 한 번도 나오지 않습니다. 선례 제도가 비판받는다는 첫 문장만 읽고 「다른 제도가 낫다는 글」이라고 넘겨짚으면 걸립니다."),
  ("법적 논증의 어휘가 시대에 따라 변해 온 방식", "끝 문장의 vocabulary만 빌려 온 선택지입니다. 글에서 어휘는 선례가 고정하는 것입니다. 어휘가 시대마다 변했다는 역사 이야기는 지문에 없습니다."),
  ("선례가 최종 결과를 정하지는 않으면서 법적 추론을 제약하는 방식", "끝 문장 «The constraint precedent imposes is therefore real but partial: it does not fix outcomes, it fixes the vocabulary in which departures must be justified.»를 바꿔 쓴 것입니다. 'real'이 'constrains'로, 'does not fix outcomes'가 'without determining its eventual results'로 바뀌었습니다."),
  ("법원이 옛 시대의 판결을 자유롭게 무시할 수 있어야 하는 이유", "너무 멀리 나간 선택지입니다. 글은 선례의 제약이 부분적이라고 했을 뿐, 실제로 있다(real)고 인정합니다. 「~해야 한다(ought to)」는 주장도 글에 없습니다. 글은 선례가 어떻게 작동하는지 설명할 뿐입니다.")])

# ---------- 5번째: 복원 목표는 생태가 아니라 남은 기록이 정한다 ----------
mk(4, [
 "1) 꺾이는 곳: 이 글에는 but이 없습니다. 대신 둘째 문장의 'The appeal … is'(좋은 점은)와 셋째 문장의 'Its difficulty is'(어려운 점은)가 짝을 이룹니다. 어려운 점 쪽이 글쓴이의 생각입니다. 표시 없이 꺾이는 숨은 역접입니다.",
 "2) 되풀이: 「A가 아니라 B」 꼴이 세 번 나옵니다. «selected less because it was ecologically privileged than because records happen to exist for it»(생태적으로 특별해서라기보다 마침 기록이 남아 있어서 골랐다) → «is not restored to nature; it is restored to the earliest date for which we have good documentation»(자연으로 되돌린 것이 아니라, 좋은 기록이 있는 가장 이른 때로 되돌린 것이다) → «a fact about archives rather than about ecosystems»(생태계가 아니라 기록 보관소에 관한 사실).",
 "3) 가운데 짧은 문장: «Pollen cores and photographs begin where they begin.»(꽃가루 시료와 사진은 시작되는 데서 시작될 뿐이다.) 기록이 언제부터 있느냐는 자연과 상관없는 우연이라는 뜻입니다.",
 "4) 묶기: 세 번 모두 버리는 쪽은 생태(ecologically, nature, ecosystems)이고 남는 쪽은 기록(records, documentation, archives)입니다. 기록 쪽 = 'the availability of records', 생태 쪽 = 'not ecological reasoning', 목표(baseline, target) = 'restoration targets'."],
 "ecological과 records가 둘 다 들어 있고 자리만 바뀐 선택지(기록이 아니라 생태 이론이 목표를 정해야 한다)가 가장 위험합니다. 글은 지금 무엇이 목표를 정하고 있는지를 밝힐 뿐, 무엇이 정해야 한다(should)고 주장하지 않습니다. photographs처럼 가운데 문장의 낱말을 빌려 온 선택지도 조심합니다.",
 [("역사 기록이 아니라 생태 이론이 복원 목표를 정해야 하는 이유", "ecological, records, targets가 들어 있어 가장 끌립니다. 하지만 글은 「지금은 기록이 목표를 정하고 있다」는 사실을 밝힐 뿐, 「생태 이론이 정해야 한다(should)」는 주장까지 나아가지 않습니다. 사실을 말한 글에 주장을 덧붙인 선택지입니다."),
  ("생태적 판단이 아니라 기록이 남아 있느냐가 복원 목표를 정하는 방식", "세 번 되풀이된 「생태가 아니라 기록」을 묶은 말입니다. 근거는 «selected less because it was ecologically privileged than because records happen to exist for it»입니다. 'records happen to exist'가 'the availability of records'로 바뀌었습니다."),
  ("사람이 남긴 교란의 흔적을 가능한 한 모두 되돌려야 하는 이유", "첫 문장의 'before human disturbance'에서 떠올리기 쉽습니다. 하지만 그것은 복원 사업이 흔히 내세우는 목표를 소개한 말이고, 글쓴이는 바로 그 목표에 어려운 점이 있다고 합니다. 통념을 주제로 착각한 선택지입니다."),
  ("사진 증거가 환경사의 정확성을 높여 온 방식", "photographs는 가운데 문장에 한 번 나오는 예입니다. 글은 사진이 정확성을 높였다고 하지 않고, 사진이 있는 때부터만 알 수 있다는 한계를 말합니다. 낱말만 빌리고 방향은 거꾸로입니다."),
  ("복원한 경관을 아주 오랫동안 유지하는 어려움", "'Its difficulty'의 difficulty를 빌려 왔지만, 글이 말하는 어려움은 복원한 뒤의 유지가 아니라 복원 목표를 고르는 기준입니다. 유지 이야기는 지문에 없습니다.")])

# ---------- 6번째: 익명성의 좋은 점과 해로운 점은 같은 데서 나온다 ----------
mk(5, [
 "1) 첫 문장: 익명성을 편드는 말과 공격하는 말을 나란히 놓습니다. could not(할 수 없었던 말)과 would not(하지 않았을 말), 낱말 하나만 다릅니다.",
 "2) 되풀이: 「둘은 같은 것에서 나온다」는 생각이 세 번 나옵니다. «they describe the same mechanism»(둘은 같은 작동 방식을 말한다) → «applies indifferently to the whistleblower and to the harasser»(내부 고발자와 괴롭히는 사람에게 가리지 않고 적용된다) → «what makes each of them possible is the same absence»(둘을 가능하게 하는 것은 같은 '없음'이다).",
 "3) 끝 문장: therefore가 결론 표시입니다. 좋은 쪽만 남기려는 제안은 «a structural rather than a technical obstacle»(기술의 벽이 아니라 구조의 벽)에 부딪힙니다. 'A rather than B'에서 글쓴이의 말은 A입니다. 기술을 다듬어서 풀 수 있는 문제가 아니라는 뜻입니다.",
 "4) 묶기: 내부 고발자 쪽 = 'benefits', 괴롭히는 사람 쪽 = 'harms', 'the same mechanism'과 'a structural … obstacle' = 'cannot be separated'(갈라놓을 수 없다), 'Proposals', 'any method' = 'by design'."],
 "끝 문장의 «Proposals that aim to keep the first while eliminating the second»(좋은 쪽은 남기고 나쁜 쪽은 없애려는 제안)를 그대로 주제로 삼은 선택지가 가장 위험합니다. 글은 그 제안이 넘을 수 없는 벽에 부딪힌다고 합니다. whistleblower나 harassment처럼 둘 가운데 한쪽만 다룬 선택지도 조심합니다.",
 [("꼼꼼한 플랫폼 설계가 익명성의 좋은 점은 남기고 해로운 점은 없앨 수 있는 방식", "방향이 거꾸로입니다. benefits, harms, design이 들어 있어 가장 끌리지만, 글은 그런 제안이 구조의 벽(a structural … obstacle)에 부딪힌다고 했습니다. 「할 수 있다(can)」가 아니라 「할 수 없다」가 글의 결론입니다."),
  ("대부분의 나라에서 지금 내부 고발자가 받을 수 있는 법적 보호", "whistleblower는 지문에 나오지만 익명성의 좋은 쪽을 보여 주는 예일 뿐입니다. 법적 보호 이야기는 지문에 없습니다. 둘 가운데 한쪽만 다룬 선택지입니다."),
  ("익명성의 좋은 점과 해로운 점을 설계로 갈라놓을 수 없는 이유", "세 번 되풀이된 「둘은 같은 것에서 나온다」를 묶은 말입니다. 근거는 «any method precise enough to identify the harasser is precise enough to identify the whistleblower»(괴롭히는 사람을 찾아낼 만큼 정밀한 방법은 내부 고발자도 찾아낼 만큼 정밀하다)입니다."),
  ("근대 초 유럽에서 익명 정치 출판물이 생겨난 역사적 기원", "지문에 없는 이야기입니다. 「익명」이라는 소재만 같고, 역사도 유럽도 나오지 않습니다."),
  ("디지털 공공 공간에서 괴롭힘이 눈에 띄게 늘어난 이유", "harasser는 지문에 나오지만 익명성의 해로운 쪽을 보여 주는 예일 뿐입니다. 괴롭힘이 늘었다는 말도, 디지털 공간이라는 말도 지문에 없습니다. 둘 가운데 한쪽만 다룬 선택지입니다.")])

# ---------- 7번째: 숫자를 목표로 삼으면 숫자가 알려 주는 힘을 잃는다 ----------
mk(6, [
 "1) 첫 문장이 이미 주제를 말합니다. «to reorganize the activity it was meant to observe»(지켜보려던 활동을 도리어 바꿔 놓는다). 끝 문장에서 같은 생각이 다시 나오는지 확인합니다.",
 "2) 통념: 셋째 문장 «usually described as gaming»(흔히 '꼼수'라고 불린다). 'usually described as'는 남들의 설명을 소개하는 표현입니다.",
 "3) 꺾이는 곳: 넷째 문장의 But입니다. «among participants with no intention to deceive»(속일 뜻이 없는 사람들 사이에서도) 같은 일이 일어납니다. 이어서 'not A. It is B'가 두 문장에 걸쳐 나옵니다. «The problem is not that people cheat the indicator.»(문제는 사람들이 지표를 속인다는 것이 아니다.) 다음 문장의 'It is that' 뒤가 글쓴이의 말입니다.",
 "4) 묶기: 끝 문장 «a number treated as a goal stops reporting on the thing it was chosen to represent»(목표로 삼은 숫자는 나타내려던 것을 더는 알려 주지 않는다). 'a number' = 'indicators', 'treated as a goal' = 'treated as targets', 'stops reporting' = 'lose their descriptive value'(알려 주는 힘을 잃는다). 첫 문장과 끝 문장이 같은 생각입니다."],
 "cheating(속임수)이 들어 있는 선택지가 가장 위험합니다. 병원·학교 예와 gaming만 읽으면 속임수 이야기로 보이지만, 글쓴이는 문제가 속임수가 아니라고 분명히 말합니다. 반대로 숫자로 재는 일이 아예 맞지 않는다고까지 말하는 선택지는 너무 멀리 나갔습니다.",
 [("병원과 학교가 수치를 일부러 속이는 일에 특히 빠지기 쉬운 이유", "병원·학교 예와 gaming만 읽은 학생이 고르는 함정입니다. 글쓴이는 But 뒤에서 속일 뜻이 없어도 같은 일이 일어난다고 하고, 문제는 속임수가 아니라고 못박습니다. 통념을 주제로 착각한 선택지입니다."),
  ("공공 부문에서 일하는 직원들의 정직이 중요하다는 것", "'bad faith', 'deceive'에서 떠올리기 쉽지만, 글은 정직한 사람들 사이에서도 같은 문제가 생긴다고 합니다. 정직을 강조하는 말은 지문에 없고, 글의 논점과 방향이 다릅니다."),
  ("숫자로 재는 일이 대부분의 공공 서비스에 근본적으로 맞지 않는 이유", "너무 멀리 나간 선택지입니다. 글은 숫자를 목표로 삼을 때 생기는 문제를 말할 뿐, 재는 일 자체가 맞지 않는다고 하지 않습니다. fundamentally, most 같은 센 말을 조심해야 합니다."),
  ("병원과 학교를 더 공정하고 한결같이 평가할 방법", "병원과 학교는 예일 뿐입니다. 글은 문제가 무엇인지 밝히는 데서 끝나고, 더 나은 평가 방법은 내놓지 않습니다. 예를 주제로, 진단을 해결책으로 바꾼 선택지입니다."),
  ("지표가 목표로 다뤄지는 순간 알려 주는 힘을 잃는 이유", "끝 문장 «It is that a number treated as a goal stops reporting on the thing it was chosen to represent.»를 바꿔 쓴 것입니다. 'a number treated as a goal'이 'indicators … treated as targets'로, 'stops reporting'이 'lose their descriptive value'로 바뀌었습니다.")])

# ---------- 8번째: 매끄러운 번역은 선택을 감춘다 ----------
mk(7, [
 "1) 통념: 첫 문장 «Translators are frequently urged to remain invisible»(번역가는 보이지 않게 있으라는 말을 자주 듣는다). 'are frequently urged'는 남들이 요구하는 것을 소개하는 표현입니다.",
 "2) 꺾이는 곳: 둘째 문장 가운데의 but입니다. «but it conceals a choice»(그러나 그것은 하나의 선택을 감춘다). 짧지만 이 글의 주제문입니다.",
 "3) 되풀이: 「매끄러운 번역은 선택을 감춘다」가 모양을 바꿔 세 번 나옵니다. 'conceals a choice' → «as if no alternative had existed»(다른 길은 없었던 것처럼 내놓는다) → 끝 문장의 absorbed(흡수된다, 곧 보이지 않게 된다). 반대쪽인 어색한 번역은 «it marks the resistance»(걸리는 곳을 표시한다), displayed(드러낸다)입니다.",
 "4) 묶기: 'reads smoothly' = 'fluent translation', 'conceals', 'absorbed' = 'hides', 'a choice', 'resolutions', 'a decision' = 'the interpretive choices'. 'necessarily'(어쩔 수 없이)는 원문이 옮겨지기를 버티는 곳마다 누군가는 정해야 한다는 뜻입니다."],
 "faithful(충실한), accurate(정확한)가 들어 있는 선택지가 위험합니다. 글쓴이는 어느 쪽이 더 충실한지 가리지 않습니다. «Neither approach is more faithful in the abstract.»(어느 방식도 그 자체로 더 충실하지는 않다.) 글이 어색한 번역 편을 든다고 넘겨짚으면 직역이 더 정확하다는 선택지를 고르게 됩니다.",
 [("가장 매끄러운 번역이 언제나 원문에 가장 충실한 번역인 이유", "첫 문장의 통념(번역가는 보이지 않아야 한다)을 더 세게 말한 것입니다. 글쓴이는 but 뒤에서 그 이상이 선택을 감춘다고 하고, 어느 방식도 더 충실하지 않다고 합니다. always 같은 센 말도 조심해야 합니다."),
  ("보통의 산문과 견주어 시를 번역할 때의 특별한 어려움", "지문에 없는 이야기입니다. 시도 산문도 나오지 않습니다. 「번역은 어렵다」는 소재만 같습니다."),
  ("매끄러운 번역이 어쩔 수 없이 내리는 해석상의 선택을 감추는 방식", "주제문 «The ideal is coherent, but it conceals a choice.»를 바꿔 쓴 것입니다. 'conceals'가 'hides'로, 'a choice'가 'the interpretive choices'로 바뀌었고, 끝 문장의 absorbed가 같은 생각을 한 번 더 말합니다."),
  ("직역이 자연스러운 의역보다 더 정확한 이유", "글이 어색한 번역 편을 든다고 넘겨짚으면 고르게 됩니다. 하지만 글쓴이는 어느 방식도 더 충실하지 않다(Neither approach is more faithful)고 분명히 말합니다. 둘의 차이는 정확성이 아니라 선택을 드러내느냐 감추느냐입니다."),
  ("보통의 독자가 번역 작품의 질을 판단하는 방식", "reader가 지문에 여러 번 나와서 끌립니다. 하지만 글에서 독자는 번역가의 선택을 보게 되거나 못 보게 되는 사람일 뿐이고, 독자가 번역의 질을 어떻게 판단하는지는 나오지 않습니다.")])

# ---------- 9번째: 전문성은 지식의 양이 아니라 보는 방식이다 ----------
mk(8, [
 "1) 통념과 꺾이는 곳이 첫 문장에 함께 있습니다. «commonly understood as the accumulation of knowledge»(흔히 지식이 쌓이는 것으로 이해된다)가 통념이고, 쉼표 뒤 but 다음이 글쓴이의 말입니다. «a different way of segmenting a situation»(상황을 나누어 보는 다른 방식).",
 "2) 되풀이: 「지식의 양이 아니라 보는 방식」이 세 번 나옵니다. 'a different way of segmenting' → «experienced players see configurations that carry implications»(경험 많은 선수는 뜻을 품은 배치를 본다) → «the expert's perception has already done work»(전문가의 지각이 이미 일을 해 두었다).",
 "3) 둘째 꺾이는 곳: 셋째 문장의 yet입니다. yet 앞의 «The number of facts available to each may be similar»(가진 사실의 수는 비슷할 수 있다)가 지식의 양 쪽을 한 번 더 지웁니다.",
 "4) 묶기: 끝 두 문장은 거기서 따라 나오는 결과입니다. 중요한 걸음이 «before any reasoning began»(추론이 시작되기도 전에) 일어나므로 전문가도 말로 설명하기 어렵습니다. 'segmenting', 'see', 'perception' = 'transforms perception', 통념인 'accumulation of knowledge' = 'merely adding knowledge'. 'A rather than B'로 통념을 밀어낸 선택지가 답입니다."],
 "'know more facts'가 들어 있는 선택지는 첫 문장 but 앞의 통념을 그대로 옮긴 것입니다. chess, explain처럼 예와 끝부분의 낱말로 만든 선택지도 조심합니다. 체스는 예이고, 설명하기 어렵다는 것은 주제에서 따라 나오는 결과입니다.",
 [("전문가가 오랜 연습 끝에 초보자보다 더 많은 사실을 알게 되는 방식", "첫 문장 but 앞의 통념(지식이 쌓이는 것)을 옮긴 것입니다. 글쓴이는 가진 사실의 수는 비슷할 수 있다(may be similar)고 했습니다. but 앞만 읽으면 걸립니다."),
  ("전문가가 자기 결정을 더 분명히 설명하도록 훈련받을 수 있는 방식", "끝부분의 'explain a judgment'에서 떠올리기 쉽습니다. 하지만 글은 전문가가 왜 설명하기 어려운지를 말할 뿐, 설명을 잘하게 만드는 훈련은 나오지 않습니다. 결과를 주제로, 진단을 해결책으로 바꾼 선택지입니다."),
  ("초보자와 경험 많은 체스 선수를 가르는 데 기억이 하는 역할", "chess, novice가 지문에 나오지만 체스는 예 하나일 뿐입니다. 또 글이 말하는 차이는 기억(memory)이 아니라 지각(perception), 곧 보는 방식입니다. 예를 주제로 삼고 핵심 낱말을 바꿔치기한 선택지입니다."),
  ("전문적인 능력을 기르는 데 필요한 시간", "지문에 없는 이야기입니다. 'The number of facts'의 number만 빌려 왔고, 연습 시간은 한 번도 나오지 않습니다."),
  ("전문성이 지식을 보태는 데 그치지 않고 지각을 바꾸어 놓는 방식", "첫 문장 but 뒤의 «what experts mainly acquire is a different way of segmenting a situation»을 바꿔 쓴 것입니다. 'a different way of segmenting'이 'transforms perception'으로, 통념인 'the accumulation of knowledge'가 'merely adding knowledge'로 바뀌었습니다.")])

# ---------- 10번째: 안전 장치는 그것이 불러오는 행동과 함께 평가해야 한다 ----------
mk(9, [
 "1) 되풀이: 「안전 장치가 행동을 바꾼다」가 세 번 나옵니다. «alter behavior in ways that offset the protection they provide»(보호 효과를 깎아 먹는 쪽으로 행동을 바꾼다) → «people adjust toward the new margin»(사람들은 새 여유 폭에 맞춰 움직인다) → «the behavior it invites»(그 장치가 불러오는 행동).",
 "2) 물러섰다가 뒤집기: 셋째 문장 «The effect is not universal and its size is disputed, but the mechanism is not mysterious»(이 효과가 늘 나타나는 것은 아니고 크기도 논란이지만, 작동 방식은 분명하다). but 앞은 물러서 주는 말이고 but 뒤가 글쓴이의 말입니다.",
 "3) 꺾이는 곳: 끝 두 문장이 'does not argue against A. It argues against B' 꼴입니다. «Recognizing this does not argue against safety measures.»(이 점을 안다고 안전 조치에 반대하게 되는 것은 아니다.) 반대하는 것은 «evaluating them by their technical capacity alone»(기술 성능만으로 평가하는 것)입니다.",
 "4) 묶기: 끝 문장의 'not A but B'에서 중요한 것은 «how much of that protection survives the behavior it invites»(그 보호가, 장치가 불러온 행동을 거치고도 얼마나 남느냐)입니다. 「성능만으로 평가하지 말라」는 거꾸로 말한 결론을 바로 세우면 「행동과 함께 평가하라」가 됩니다. 'evaluating' = 'assessed', 'not … alone' = 'together with', 'the behavior it invites' = 'the behavior they prompt'."],
 "이 글을 「안전 장치는 소용없다」로 읽으면 안 됩니다. 넷째 문장이 그 오해를 미리 막습니다. 반대로 안전 장치가 늘 사고를 줄인다는 선택지는 첫 문장의 offset(깎아 먹는다)과 어긋납니다. braking처럼 예에 나온 낱말로 만든 선택지도 조심합니다.",
 [("안전 조치를 그것이 불러오는 행동과 함께 평가해야 하는 이유", "끝 문장의 «It argues against evaluating them by their technical capacity alone»을 바로 세워 쓴 것입니다. 「성능만으로 평가하지 말라」가 「행동과 함께 평가하라」로, 'the behavior it invites'가 'the behavior they prompt'로 바뀌었습니다."),
  ("더 엄격한 안전 장비를 달면 언제나 사고가 오래도록 줄어드는 이유", "방향이 거꾸로입니다. 첫 문장은 바뀐 행동이 보호 효과를 깎아 먹을(offset) 수 있다고 했습니다. 「안전 장치는 좋은 것」이라는 상식으로 고르면 걸립니다. always 같은 센 말도 조심해야 합니다."),
  ("산업 현장에서 위험을 정확히 재는 어려움", "'its size is disputed'(크기는 논란이다)와 workers에서 떠올리기 쉽습니다. 하지만 그 말은 but 앞의 물러서 주는 말이고, 글의 논점은 위험을 재기 어렵다는 것이 아니라 장치를 무엇으로 평가할 것인가입니다."),
  ("현대의 자동 제동 장치가 교통사고 사망을 줄여 온 방식", "'braking systems'는 예 하나일 뿐입니다. 게다가 지문에서 그 예는 운전자가 앞차에 더 바짝 붙는다는, 효과가 깎이는 쪽 이야기입니다. 예를 주제로 삼고 방향까지 바꾼 선택지입니다."),
  ("보험 회사가 특히 위험한 일의 보험료를 계산하는 방식", "지문에 없는 이야기입니다. 「위험」이라는 소재만 같고 보험은 한 번도 나오지 않습니다.")])

# ---------- 11번째: 고령화를 하나로 보면 정책이 어긋난다 ----------
mk(10, [
 "1) 통념과 꺾이는 곳이 첫 문장에 함께 있습니다. «usually taken to describe a demographic fact»(흔히 하나의 인구 사실을 말하는 것으로 받아들여진다)가 통념이고, 쉼표 뒤 but 다음이 글쓴이의 말입니다. «the phrase compresses two distinct changes»(그 말은 서로 다른 두 변화를 하나로 눌러 담고 있다).",
 "2) 되풀이: 「둘은 따로다」가 짝을 이뤄 계속 나옵니다. 'live longer' ↔ 'fewer children are born' → 'The first' ↔ 'the second' → 정책도 «addresses the first without touching the second»(첫째는 다루지만 둘째는 건드리지 않는다).",
 "3) 가운데 문장: «Policies calibrated to one may be irrelevant or counterproductive for the other.»(한쪽에 맞춘 정책은 다른 쪽에는 쓸모없거나 도리어 해로울 수 있다.) 여기서 이야기가 정책으로 넘어갑니다.",
 "4) 묶기: 끝 문장의 therefore가 결론 표시입니다. «Debates that treat aging as a single problem»(고령화를 하나의 문제로 다루는 논의)은 효과를 알기 어려운 대책을 낳습니다. 'treat aging as a single problem' = 'treating population aging as one phenomenon', 'irrelevant or counterproductive', 'hard to interpret' = 'distorts the policies'(정책을 어긋나게 한다)."],
 "두 변화 가운데 한쪽만 다룬 선택지(출생률 감소의 결과, 가족 지원이 먼저)가 위험합니다. 글은 어느 한쪽을 편들지 않고 둘을 갈라 보라고 합니다. 'the same burden'(똑같은 부담)이 들어 있는 선택지는 글이 깨려는 「하나로 보기」를 되풀이한 것입니다.",
 [("고령화하는 인구가 모든 지역과 모든 서비스에 똑같은 부담을 지우는 이유", "「하나의 똑같은 것」으로 보는 생각은 글이 깨려는 쪽입니다. 글은 고령화 안에 서로 다른 두 변화가 들어 있다고 합니다. 지역이나 서비스별 부담 이야기도 지문에 없습니다."),
  ("정부가 연금 개혁보다 가족 지원을 앞세워야 하는 이유", "'supporting families'는 지문에 나오지만 둘째 변화에 맞는 정책의 예일 뿐입니다. 글은 어느 정책이 먼저라고 편들지 않습니다. 연금 개혁(pension reform)도 지문에 없습니다. 두 쪽 가운데 한쪽만 고른 선택지입니다."),
  ("산업화한 나라에서 출생률 감소가 가져오는 경제적 결과", "'fewer children are born'에서 떠올리기 쉽지만 두 변화 가운데 한쪽만 다룹니다. 경제적 결과도 지문에 없습니다. 글의 논점은 두 변화를 갈라 보아야 한다는 것입니다."),
  ("인구 고령화를 하나의 현상으로 다루면 그에 맞춰 만든 정책이 어긋나는 이유", "끝 문장의 «Debates that treat aging as a single problem therefore tend to produce measures whose effects are hard to interpret»를 바꿔 쓴 것입니다. 'a single problem'이 'one phenomenon'으로, 'measures'가 'the policies designed for it'으로 바뀌었습니다."),
  ("인구학자들이 앞으로의 인구 변화를 내다볼 때 쓰는 방법", "demographic이라는 낱말에서 떠올리기 쉽지만, 예측 방법은 지문에 없습니다. 「인구」라는 소재만 같은 딴 이야기입니다.")])

# ---------- 12번째: 증거를 더 모아도 쏠린 기록은 바로잡히지 않는다 ----------
mk(11, [
 "1) 첫 문장의 'less A than B'가 방향을 정합니다. «less to do with scarcity than with selection»(모자라서라기보다 골라져서 생기는 문제). 글쓴이의 말은 B, 곧 selection(선별)입니다. 증거가 적어서 문제라는 상식을 미리 밀어냅니다.",
 "2) 되풀이: 「남은 것은 골라진 것」이 모양을 바꿔 나옵니다. «not a random sample of what existed»(있었던 것의 무작위 표본이 아니다) → «Durable materials are overrepresented»(오래가는 재료가 지나치게 많이 잡힌다) → «systematically skewed»(한쪽으로 체계적으로 쏠려 있다).",
 "3) 결론: 다섯째 문장 뒤쪽의 «the skew is not corrected by finding more of the same kind of evidence»(같은 종류의 증거를 더 찾는다고 쏠림이 바로잡히지 않는다). 부정문으로 말한 결론입니다.",
 "4) 묶기: 끝 문장이 까닭을 댑니다. 더 찾은 것들은 «confirm the pattern that the selection produced»(선별이 만든 무늬를 다시 확인해 줄 뿐)입니다. 'finding more' = 'accumulating more evidence', 'is not corrected' = 'does not correct', 'systematically skewed' = 'a systematically biased record'."],
 "evidence, correct, 'biased record'가 다 들어 있는데 부정어만 빠진 선택지(증거를 더 모으는 것이 가장 확실한 길)가 가장 위험합니다. 「증거는 많을수록 좋다」는 상식으로 고르면 걸립니다. 답은 상식이 아니라 지문에서 찾습니다. construction, durable처럼 가운데 예에 나온 낱말로 만든 선택지도 조심합니다.",
 [("증거를 더 많이 모으는 것이 치우친 역사 기록을 바로잡는 가장 확실한 길인 이유", "방향이 거꾸로입니다. evidence, correct, 'biased … record'가 들어 있어 가장 끌리지만, 글은 더 찾아도 쏠림이 바로잡히지 않는다(is not corrected)고 했습니다. 「증거는 많을수록 좋다」는 상식으로 고르는 함정입니다."),
  ("증거를 더 쌓아도 체계적으로 치우친 기록이 바로잡히지 않는 이유", "다섯째 문장의 «the skew is not corrected by finding more of the same kind of evidence»를 바꿔 쓴 것입니다. 'finding more'가 'accumulating more evidence'로, 'the skew'가 'a systematically biased record'로 바뀌었습니다."),
  ("현대의 건설이 세계 곳곳의 고대 유적 상당수를 파괴해 온 방식", "'modern construction', 'built over'에서 떠올리기 쉽습니다. 하지만 지문에서 건설은 어느 유적이 조사되는지를 가르는 조건의 예이고(건설 현장 가까운 곳은 오히려 조사됩니다), 파괴 이야기가 아닙니다."),
  ("고대 사회가 오래가는 건축 재료에 기댄 정도", "durable은 지문에 나오지만, 글은 오래가는 재료가 많이 쓰였다고 하지 않고 많이 남았다고 합니다. 남은 것을 보고 많이 썼다고 여기는 것이 바로 글이 조심하라는 쏠림입니다."),
  ("발굴한 뒤 썩기 쉬운 재료를 보존하는 데 쓰는 기술", "perishable, excavated가 지문에 나오지만 보존 기술은 나오지 않습니다. 「고고학」이라는 소재만 같은 딴 이야기입니다.")])

# ---------- 13번째: 널리 쓰이는 자선 단체 수치는 거꾸로 상을 준다 ----------
mk(12, [
 "1) 통념: 첫 문장 «donors treat a low figure as evidence of efficiency»(기부자들은 낮은 수치를 효율의 증거로 여긴다). 'treat … as'는 남들이 그렇게 여긴다는 표현입니다.",
 "2) 꺾이는 곳: 이 글에는 but이 없습니다. 둘째 문장이 표시 없이 바로 뒤집습니다. «The ratio rewards a charity for not investing in the things that make it effective»(이 비율은, 단체를 효과 있게 만드는 것들에 투자하지 않는 단체에 상을 준다). 숨은 역접입니다.",
 "3) 되풀이: 「이 수치는 거꾸로 상을 준다」가 세 번 나옵니다. 'rewards … for not investing' → «will always show a better ratio than one that does»(측정에 돈을 쓰는 단체보다 늘 더 좋은 비율을 보인다) → «differ in the wrong direction»(잘 운영되는 단체와 속 빈 단체가 거꾸로 방향으로 갈린다).",
 "4) 묶기: 넷째·다섯째 문장은 그런데도 이 수치가 계속 쓰이는 까닭입니다(available, comparable, 곧 구하기 쉽고 견주기 쉽다). 'calculated the same way everywhere' = 'a widely used charity metric'(널리 쓰이는 평가 수치), 'rewards … for not investing', 'the wrong direction' = 'rewards the wrong behaviour'."],
 "행정비를 줄이는 방법을 말하는 선택지가 위험합니다. 첫 문장만 읽으면 「행정비는 적을수록 좋다」는 기부자들의 생각이 글의 생각처럼 보입니다. 글은 바로 그 생각이 거꾸로라고 합니다. evaluation, accounting, comparable처럼 가운데 낱말을 빌려 온 선택지도 조심합니다.",
 [("자선 단체가 직원을 잃지 않으면서 행정비를 줄일 수 있는 방법", "administration, staff가 지문에 나와서 끌립니다. 하지만 행정비가 적을수록 좋다는 것은 첫 문장의 기부자들 생각이고, 글은 그 생각이 거꾸로 상을 준다고 합니다. 통념 쪽에 서서 해결책까지 덧붙인 선택지입니다."),
  ("규모가 다른 자선 단체들을 견주는 어려움", "compared, comparable에서 떠올리기 쉽습니다. 하지만 글은 견주기가 어렵다고 하지 않습니다. 오히려 이 수치는 견주기가 쉬워서 계속 쓰인다고 합니다. 규모 이야기는 지문에 없습니다."),
  ("자선 단체 회계에서 투명성이 중요하다는 것", "'accounting systems', publish에서 떠올리기 쉽지만, 글에서 회계 체계는 단체가 투자해야 할 것의 예입니다. 투명성이 중요하다는 주장은 지문에 없고, 글은 공개되는 수치 자체가 문제라고 합니다."),
  ("널리 쓰이는 자선 단체 평가 수치가 잘못된 행동에 상을 주는 이유", "둘째 문장 «The ratio rewards a charity for not investing in the things that make it effective»를 바꿔 쓴 것입니다. 'The ratio'가 'a widely used charity metric'으로, 'not investing in the things that make it effective'가 'the wrong behaviour'로 바뀌었고, 끝 문장의 'the wrong direction'이 같은 생각을 다시 말합니다."),
  ("원조 사업의 효과를 평가하는 방법들", "evaluation, 'whether the programme works'에서 떠올리기 쉽습니다. 하지만 글에서 평가는 단체가 돈을 써야 할 곳의 예로 나올 뿐, 평가 방법은 설명하지 않습니다. 예를 주제로 부풀린 선택지입니다.")])

# ---------- 14번째: 보이는 절감이 안 보이는 위험을 늘 이긴다 ----------
mk(13, [
 "1) 짝 찾기: 셋째·넷째 문장이 짝입니다. «These savings are continuous and easily measured.»(이 절감은 끊임없이 생기고 쉽게 잴 수 있다.) ↔ «The costs of removing redundancy are neither»(여유를 없애는 데 따르는 비용은 둘 다 아니다). but은 없지만 neither가 뒤집는 자리입니다.",
 "2) 되풀이: 「한쪽은 보이고 한쪽은 안 보인다」가 세 번 나옵니다. 'easily measured' ↔ neither → «observed under such different conditions»(아주 다른 조건에서 관찰된다) → «one side of the ledger is visible every quarter and the other is not»(장부의 한쪽은 분기마다 보이고 다른 쪽은 보이지 않는다).",
 "3) 끝 문장의 'not A but B': «not through misjudgment but because»(판단을 잘못해서가 아니라 ~ 때문에). 정직하고 유능한 조직도 여유분을 걷어 내게 됩니다. 사람의 잘못이 아니라 보이는 정도의 차이가 원인이라는 것이 글쓴이의 말입니다.",
 "4) 묶기: 'easily measured', 'visible every quarter' = 'measurable savings', 'appear only when something fails' = 'unmeasured risks', 'will still tend to strip out reserves' = 'systematically outweigh'(늘 이긴다), 'organizations that optimize' = 'organizational decisions'."],
 "관리자의 판단 잘못을 탓하는 선택지가 위험합니다. 글은 'not through misjudgment'라고 분명히 했습니다. 게다가 재지 못하는 위험은 크게 보이는 것이 아니라 묻힙니다. 'supply chain', slack처럼 둘째 문장의 예로 만든 선택지도 조심합니다.",
 [("신중한 관리자가 수치로 잡히지 않는 위험을 실제보다 크게 보는 경향이 있는 이유", "방향이 거꾸로입니다. 글에서 재지 못하는 위험은 크게 보이는 것이 아니라 눈에 보이지 않아 묻힙니다. 또 글은 원인이 사람의 판단 잘못이 아니라고(not through misjudgment) 했습니다. risks, measure가 들어 있어 끌리는 함정입니다."),
  ("공급망을 뜻밖의 차질에도 버티도록 다시 짜는 방법", "'supply chain'은 둘째 문장의 예 하나일 뿐입니다. 글은 왜 여유가 사라지는지를 밝히는 데서 끝나고, 다시 짜는 방법은 내놓지 않습니다. 예를 주제로, 진단을 해결책으로 바꾼 선택지입니다."),
  ("경쟁이 기업으로 하여금 운영비를 줄이게 만드는 방식", "'costs less to operate'에서 떠올리기 쉽지만, 경쟁(competition)은 지문에 없습니다. 글이 든 원인은 경쟁이 아니라, 절감은 보이고 위험은 안 보인다는 차이입니다. 원인을 바꿔치기한 선택지입니다."),
  ("일정의 여유가 직원들의 근무 여건을 좋게 하는 이유", "'a schedule with no slack'은 둘째 문장의 예 하나일 뿐입니다. 근무 여건이나 직원 이야기는 지문에 없습니다."),
  ("조직의 결정에서 잴 수 있는 절감이 재지 못한 위험을 늘 이기는 이유", "끝 문장의 «one side of the ledger is visible every quarter and the other is not»을 바꿔 쓴 것입니다. 보이는 쪽이 'measurable savings', 안 보이는 쪽이 'unmeasured risks'이고, 정직하고 유능한 조직도 그렇게 된다는 말이 'systematically'(늘, 구조적으로)에 담겼습니다.")])

# ---------- 15번째: 지정한 넓이는 보호를 재는 잣대로 나쁘다 ----------
mk(14, [
 "1) 되풀이: 「지도에 그은 선과 실제 보호는 따로 논다」가 문장마다 모양을 바꿔 나옵니다. «the fish inside it do not read charts»(그 안의 물고기는 해도를 읽지 않는다) → «none of which follows the movements of anything alive»(그 어느 것도 살아 있는 것의 움직임을 따르지 않는다) → «covered less sea and produced larger recoveries»(더 좁은 바다를 덮었는데 더 크게 회복되었다).",
 "2) 꺾이는 곳: 이 글에는 but도 yet도 없습니다. 넷째 문장에서 'less sea'와 'larger recoveries'가 맞서는 것이 숨은 역접입니다. 넓이가 줄었는데 보호는 늘었으니, 넓이와 보호는 같이 가지 않습니다.",
 "3) 끝 문장: «What is measured and reported is the percentage of sea designated»(재고 보고하는 것은 지정된 바다의 비율이다). 그런데 이 비율은 «by designating water nobody fishes»(아무도 고기를 잡지 않는 바다를 지정해서) 올릴 수 있습니다. 주제가 끝 문장에서 완성되는 글입니다.",
 "4) 묶기: 'the percentage of sea designated' = 'the area designated', 'What is measured and reported' = 'measure', 넓이와 회복이 따로 논다는 것 = 'a poor measure of protection'(보호를 재는 잣대로 나쁘다)."],
 "「넓을수록 더 많이 보호된다」는 상식을 말하는 선택지가 가장 위험합니다. 넷째 문장이 정반대 사례입니다. enforcement, fishing처럼 셋째 문장에 나열된 낱말 하나를 키운 선택지도 조심합니다.",
 [("보호 구역이 넓을수록 언제나 더 많은 바다 생물을 보호하는 이유", "방향이 거꾸로입니다. 넷째 문장에서 더 좁게 다시 그린 구역이 더 크게 회복되었습니다. 「넓을수록 좋다」는 상식으로 고르면 걸립니다. always 같은 센 말도 조심해야 합니다."),
  ("지정된 넓이가 보호를 재는 잣대로 나쁜 이유", "끝 문장의 «What is measured and reported is the percentage of sea designated»와 넷째 문장의 «covered less sea and produced larger recoveries»를 묶은 말입니다. 재는 것은 넓이인데, 넓이는 실제 보호와 따로 놉니다."),
  ("바다에서 보호 규정을 단속하는 데 드는 비용", "'where enforcement is affordable'에서 떠올리기 쉽습니다. 하지만 단속 비용은 경계선을 어디에 긋는지 정하는 세 가지 사정 가운데 하나로 나올 뿐입니다. 나열된 것 하나를 주제로 부풀린 선택지입니다."),
  ("어선단과 보호 단체 사이의 갈등", "'fishing interests', resisted에서 떠올리기 쉽습니다. 하지만 글에서 다시 긋기에 반대한 까닭은 어업과의 갈등이 아니라, 좁아진 구역이 물러서는 것처럼 보였기 때문입니다. 갈등 이야기는 지문에 없습니다."),
  ("바다에 관한 국제 협약의 역사", "지문에 없는 이야기입니다. jurisdictions, country에서 떠올릴 수 있지만 협약도 역사도 나오지 않습니다. 「바다」라는 소재만 같습니다.")])

# ---------- 16번째: 침입종이라는 범주에는 판단이 실려 있다 ----------
mk(15, [
 "1) 통념: 첫 문장의 'are typically defined as'(흔히 ~로 정의된다)는 흔한 정의를 소개하는 표현입니다. 정의에는 조각이 셋 있습니다. 사람이 들여왔다, 빠르게 퍼진다, 원래 살던 것을 밀어낸다.",
 "2) 꺾이는 곳: 둘째 문장 가운데의 but입니다. «The definition seems descriptive, but each clause carries judgment.»(이 정의는 있는 그대로 그린 것처럼 보이지만, 조각마다 판단이 실려 있다.) seems(~처럼 보인다)는 곧 뒤집힌다는 신호이고, 이 문장이 주제문입니다.",
 "3) 되풀이: 셋째~다섯째 문장이 조각 셋을 하나씩 무너뜨립니다. 사람이 들여왔다는 것은 «a distinction of cause, not of ecological effect»(원인의 구별이지 생태적 결과의 구별이 아니다), 빠른 퍼짐은 토착종도 마찬가지(including native ones), 밀어내기는 늘 일어나는 일(undergo continually)입니다. 세 번 모두 「생태적 사실만으로는 가를 수 없다」는 같은 생각입니다.",
 "4) 묶기: 끝 문장의 'not A but B'. 이 범주가 골라내는 것은 생물의 종류가 아니라 «whose direction we have decided to resist»(우리가 막기로 정한 방향의) 변화입니다. 'we have decided' = 'judgment', 'seems descriptive' = 'ecological description'. 'A rather than B'로 판단을 고르고 묘사를 밀어낸 선택지가 답입니다."],
 "정의의 조각(사람의 운송, 빠른 퍼짐, 밀어내기)을 사실로 받아들인 선택지들이 위험합니다. 글은 그 조각들을 하나씩 무너뜨립니다. 가장 위험한 것은 생태 자료만으로 객관적으로 가려낼 수 있다는 선택지로, but 앞의 'seems descriptive'를 그대로 믿은 것입니다.",
 [("침입종을 생태 자료만으로 객관적으로 가려낼 수 있는 이유", "방향이 거꾸로입니다. but 앞의 'seems descriptive'(있는 그대로 그린 것처럼 보인다)를 그대로 믿은 선택지입니다. 글쓴이는 but 뒤에서 정의의 조각마다 판단이 실려 있다고 합니다."),
  ("생태 공동체의 구성이 오랜 시간에 걸쳐 바뀌는 이유", "다섯째 문장의 'ecological communities undergo continually'에서 떠올리기 쉽습니다. 하지만 그 문장은 정의의 셋째 조각(밀어내기)을 무너뜨리는 근거 하나일 뿐입니다. 근거 하나를 주제로 부풀린 선택지입니다."),
  ("침입종이라는 범주가 생태적 묘사가 아니라 판단을 담고 있는 방식", "주제문 «The definition seems descriptive, but each clause carries judgment.»를 바꿔 쓴 것입니다. 'The definition'이 'the category of invasive species'로, 'seems descriptive'가 밀려나는 쪽인 'ecological description'으로 바뀌었고, 끝 문장의 'we have decided'가 같은 생각을 다시 말합니다."),
  ("사람의 운송망이 생물의 이동을 빠르게 해 온 방식", "'human transport'가 지문에 나와서 끌립니다. 하지만 글은 사람의 운송을 따로 떼어 보는 것이 원인의 구별일 뿐이라고, 곧 판단이 들어간 것이라고 합니다. 운송망이 무엇을 빠르게 했다는 이야기는 지문에 없습니다."),
  ("들여온 생물이 토착 생물보다 더 빨리 퍼지는 이유", "방향이 거꾸로입니다. 넷째 문장은 빠른 퍼짐이 토착종에게도 나타나는 특징(including native ones)이라고 했습니다. 정의의 둘째 조각을 사실로 받아들인 선택지입니다.")])

# ---------- 17번째: 알파벳순은 배열이 전하던 주장을 없앴다 ----------
mk(16, [
 "1) 첫 문장의 신호: «seems merely practical until one considers the alternative it displaced»(그것이 밀어낸 다른 방식을 떠올리기 전까지는 그저 실용적인 결정처럼 보인다). 'seems … until'은 곧 뒤집힌다는 표시입니다. but이 없는 숨은 역접입니다.",
 "2) 되풀이: 「배열이 품고 있던 가르침이 사라졌다」가 세 번 나옵니다. «the instruction the arrangement had carried»(배열이 실어 나르던 가르침) → «without learning its relation to anything else»(다른 것과의 관계를 배우지 않고도) → «a claim about how the content fit together»(내용이 서로 어떻게 맞물리는지에 관한 주장).",
 "3) 물러섰다가 뒤집기: 다섯째 문장 «The gain in access was real and the loss was not obvious»(찾기 쉬워진 것은 사실이고, 잃은 것은 눈에 잘 띄지 않았다). 얻은 것을 먼저 인정하고, 글의 무게는 잃은 것 쪽에 둡니다.",
 "4) 묶기: 끝 문장의 'not A but B'. «What disappeared was not content but a claim»(사라진 것은 내용이 아니라 하나의 주장이었다). 'disappeared' = 'removed', 'a claim about how the content fit together' = 'the structural claims', 'the arrangement had carried' = 'that ordering had conveyed'."],
 "얻은 것만 말하는 선택지(알파벳순 덕분에 더 빠르고 쉽게 찾게 되었다)가 가장 위험합니다. 지문에 있는 사실이지만 글의 무게는 잃은 것에 있습니다. 맞는 말이라도 절반만 담으면 주제가 아닙니다.",
 [("알파벳순이 독자가 참고 도서를 더 빠르고 쉽게 찾아보게 만든 방식", "지문에 있는 사실(The gain in access was real)이라서 가장 끌립니다. 하지만 글쓴이는 얻은 것을 먼저 인정한 뒤, 눈에 띄지 않게 잃은 것을 말하는 데 글의 무게를 둡니다. 맞는 말이지만 절반만 담은 선택지입니다."),
  ("독자가 인쇄된 참고 자료에서 정보를 찾아내는 방식", "'finding an item', 'retrieve an entry'에서 떠올리기 쉽습니다. 하지만 너무 넓고, 글의 논점인 「배열이 바뀌면서 사라진 것」이 빠져 있습니다."),
  ("알파벳순 색인이 참고 도서의 표준이 된 이유", "alphabetical이 들어 있어 끌리지만, 글은 알파벳순이 왜 퍼졌는지를 묻지 않습니다. 글이 묻는 것은 그것이 무엇을 없앴는가입니다. 물음을 바꿔치기한 선택지입니다."),
  ("알파벳순 배열이, 순서가 전하던 구조에 관한 주장을 없앤 방식", "끝 문장의 «What disappeared was not content but a claim about how the content fit together»를 바꿔 쓴 것입니다. 'a claim about how the content fit together'가 'the structural claims'로, 'the arrangement had carried'가 'ordering had conveyed'로 바뀌었습니다."),
  ("빠짐없는 백과사전을 오랫동안 유지하는 어려움", "지문에 없는 이야기입니다. 「백과사전」이라는 소재만 같고, 유지하기 어렵다는 말은 나오지 않습니다.")])

# ---------- 18번째: 복잡한 것을 공개하면 책임지는 겉모습만 생길 수 있다 ----------
mk(17, [
 "1) 통념: 첫 문장의 assume(~라고 전제한다)이 신호입니다. «disclosure and understanding move together»(공개와 이해는 함께 간다). 남들이 깔고 있는 전제를 소개한 것입니다.",
 "2) 꺾이는 곳: but 없이 둘째 문장이 바로 뒤집습니다. 'move together' ↔ «they can move apart»(둘은 따로 갈 수 있다). 숨은 역접이고, 이 짧은 문장이 주제문입니다.",
 "3) 되풀이: 「공개는 했지만 이해는 생기지 않는다」가 세 번 나옵니다. «no one outside the field can evaluate»(분야 밖의 누구도 평가할 수 없다) → «the ability to verify nothing and the impression that verification has occurred»(아무것도 확인하지 못하는 능력과, 확인이 이루어졌다는 인상) → 끝 문장에서 정보의 분포는 크게 바뀌고 지식의 분포는 거의 바뀌지 않습니다.",
 "4) 묶기: 끝 문장의 «the appearance of accountability»(책임을 지는 듯한 겉모습). 'the disclosed material is complex' = 'disclosing complex information', 'the impression', 'the appearance' = 겉으로만 만들어 낸다, 'changed hardly at all' = 'without producing it'(실제로는 낳지 못한다)."],
 "첫 문장의 전제를 그대로 옮긴 선택지(정보를 더 공개하면 저절로 책임을 지게 된다)가 가장 위험합니다. 「투명할수록 좋다」는 상식과도 맞아서 끌립니다. regulator, records처럼 예에 나온 낱말로 만든 선택지도 조심합니다.",
 [("정보를 더 많이 공개할수록 공공 기관이 저절로 책임을 지게 되는 이유", "첫 문장의 전제(공개와 이해는 함께 간다)를 그대로 옮긴 것으로, 글의 방향과 거꾸로입니다. 글쓴이는 둘째 문장에서 둘이 따로 갈 수 있다고 뒤집습니다. 「투명할수록 좋다」는 상식으로 고르면 걸립니다."),
  ("규제 기관이 어떤 기록을 공개할지 정하는 방식", "regulator, records가 지문에 나오지만 예 속의 낱말입니다. 글에서 규제 기관은 기록을 빠짐없이 공개합니다. 무엇을 공개할지 고르는 이야기는 지문에 없습니다."),
  ("대중이 정부 기관의 믿을 만함을 평가하는 방식", "evaluate에서 떠올리기 쉽습니다. 하지만 글은 분야 밖 사람들이 평가할 수 없다(no one outside the field can evaluate)고 했습니다. 평가하는 방식을 설명하는 글이 아닙니다."),
  ("투명한 공공 기관을 유지하는 데 따르는 행정 비용", "지문에 없는 이야기입니다. transparent라는 소재만 같고 비용은 한 번도 나오지 않습니다."),
  ("복잡한 정보를 공개하는 것이 책임성을 실제로 낳지는 못하면서 겉으로만 만들어 낼 수 있는 이유", "끝 문장의 «with the appearance of accountability supplied by the first»(책임을 지는 듯한 겉모습은 앞의 것, 곧 바뀐 정보 분포가 대 준다)를 바꿔 쓴 것입니다. 정보는 퍼졌지만 지식은 거의 그대로이므로 실제 책임성은 생기지 않습니다.")])

# ---------- 19번째: 상관관계 격언을 들이대면 따져 보기가 사라진다 ----------
mk(18, [
 "1) 꺾이는 곳: 첫 문장 가운데의 yet입니다. yet 앞은 누구나 아는 격언(상관관계가 인과관계를 세워 주지는 않는다)이고, yet 뒤가 글쓴이의 문제 제기입니다. «it is often applied as though it settled matters»(그 말이 마치 문제를 매듭짓는 것처럼 쓰이는 일이 많다). 'as though'는 실제로는 그렇지 않다는 신호입니다.",
 "2) 가장 짧은 문장: «It does not.»(그렇지 않다.) 세 낱말짜리 문장이 글쓴이의 태도를 못박습니다. 격언은 문제를 매듭짓지 못합니다.",
 "3) 되풀이: 「격언을 뭉뚱그려 쓰면 진짜 따져 보기가 사라진다」가 모양을 바꿔 나옵니다. «disposes of nearly all empirical reasoning»(경험에 바탕을 둔 추론을 거의 다 내다 버린다) → «substitutes a general caution for that specific inquiry»(그 구체적인 따져 보기 자리에 두루뭉술한 조심을 대신 앉힌다).",
 "4) 묶기: 'A blanket appeal to the maxim' = 'invoking the correlation maxim', 'substitutes … for' = 'replace', 'that specific inquiry'(넷째 문장의 쓸모 있는 물음) = 'causal inquiry'. 'rather than advance'(나아가게 하기는커녕)는 탐구를 도우려던 격언이 도리어 탐구를 막는다는 뜻입니다."],
 "격언의 내용 자체를 주제로 삼은 선택지(연구자들이 상관과 인과를 자주 혼동한다)가 위험합니다. 글이 문제 삼는 것은 혼동이 아니라 격언을 쓰는 방식입니다. 반대로 상관관계는 증거가 될 수 없다는 선택지는 셋째 문장(상관관계는 인과 주장을 세우는 보통의 증거다)과 정반대입니다.",
 [("상관관계 격언을 들먹이는 것이 인과 탐구를 나아가게 하기는커녕 대신해 버릴 수 있는 이유", "끝 문장의 «A blanket appeal to the maxim substitutes a general caution for that specific inquiry»를 바꿔 쓴 것입니다. 'A blanket appeal to the maxim'이 'invoking the correlation maxim'으로, 'substitutes … for'가 'replace'로 바뀌었습니다."),
  ("과학 연구에서 상관관계를 어떤 증거로도 다루어서는 안 되는 이유", "방향이 거꾸로입니다. 셋째 문장은 상관관계가 인과 주장을 세우는 보통의 증거(the ordinary evidence)라고 했습니다. 격언을 가장 세게 밀어붙인 선택지로, 글쓴이가 비판하는 바로 그 태도입니다."),
  ("무작위 대조 실험이 관찰보다 인과관계를 더 믿을 만하게 세우는 방식", "'controlled trials'가 지문에 나와서 끌립니다. 하지만 지문에서는 「대조 실험 밖의 추론」이라는 말 속에 한 번 스칠 뿐이고, 실험이 어떻게 인과를 세우는지는 나오지 않습니다."),
  ("연구자들이 발표한 연구에서 상관관계와 인과관계를 자주 혼동하는 이유", "격언의 내용 그 자체를 주제로 삼은 선택지입니다. 글이 문제 삼는 것은 둘을 혼동하는 일이 아니라, 격언을 뭉뚱그려 들이대는 일입니다. 첫 문장의 yet 앞만 읽으면 걸립니다."),
  ("인과 주장을 훈련받지 않은 청중에게 어떻게 전해야 하는가", "지문에 없는 이야기입니다. 'causal claims'라는 낱말만 같고, 청중에게 전하는 문제는 나오지 않습니다.")])

# ---------- 20번째: 자료를 더 넣으면 치우침이 더 굳어진다 ----------
mk(19, [
 "1) 첫 문장의 'not only A but B': 시스템은 낱말만이 아니라 «the distributions within them»(자료 안의 분포)까지 되살려 냅니다. B 쪽이 이 글의 소재입니다.",
 "2) 셋째 문장의 'not A; it is B': «The output is not an error in any ordinary sense»(그 결과는 보통 말하는 오류가 아니다). 쌍반점(;) 뒤가 글쓴이의 말입니다. «an accurate reflection of the statistical regularities present in the material»(자료에 들어 있는 통계적 규칙성을 정확히 비춘 것).",
 "3) 꺾이는 곳: 넷째 문장 «This is what makes the problem resistant to correction by more data.»(바로 이 때문에 자료를 더 넣어도 문제가 잘 고쳐지지 않는다.) but은 없지만, 「자료를 늘리면 나아진다」는 상식을 뒤집는 문장입니다.",
 "4) 묶기: 끝 문장 «Additional text drawn from the same population reinforces the regularity»(같은 모집단에서 뽑은 글을 더하면 그 규칙성이 더 굳어진다). 'Additional text' = 'enlarging training data', 'resistant to correction' = 'rather than removes', 'the regularity' = 'statistical bias'. reinforces는 지문과 선택지에 같은 낱말로 나옵니다."],
 "enlarging, training, 'statistical bias'가 다 들어 있고 방향만 반대인 선택지(자료를 늘리면 치우침이 없어진다)가 가장 위험합니다. 「자료는 많을수록 좋다」는 상식으로 고르면 걸립니다. 'grammatical gender', occupations처럼 둘째 문장의 예로 만든 선택지도 조심합니다.",
 [("학습 자료를 늘리는 것이 통계적 치우침을 없애기는커녕 더 굳히는 이유", "끝 문장의 «Additional text drawn from the same population reinforces the regularity»를 바꿔 쓴 것입니다. 'Additional text'가 'enlarging training data'로, 'the regularity'가 'statistical bias'로 바뀌었고, 넷째 문장의 'resistant to correction'이 'rather than removes'에 담겼습니다."),
  ("학습 자료를 늘리면 작은 자료에 있던 통계적 치우침이 없어지는 이유", "방향이 거꾸로입니다. enlarging, training, statistical이 다 들어 있어 가장 끌리지만, 글은 자료를 더해도 고쳐지지 않고 오히려 굳어진다고 했습니다. 「자료는 많을수록 좋다」는 상식으로 고르는 함정입니다."),
  ("글로 남은 자료에서 직업 관련 어휘가 시대에 따라 변해 온 방식", "occupations, vocabulary가 지문에 나오지만 예 속의 낱말입니다. 어휘가 시대에 따라 변했다는 이야기는 지문에 없습니다."),
  ("기계 번역 시스템이 여러 언어에서 문법적 성을 다루는 방식", "'grammatical gender'는 둘째 문장의 예입니다. 글은 그 예를 거쳐 「자료를 더해도 고쳐지지 않는다」는 데로 나아갑니다. 예를 주제로 삼았고, 끝 두 문장의 논점이 빠져 있습니다."),
  ("자동 번역이 여전히 사람의 번역보다 덜 정확한 이유", "사람의 번역과 견주는 이야기는 지문에 없습니다. 게다가 글은 그 결과가 오류가 아니라 자료를 정확히 비춘 것(an accurate reflection)이라고 했으므로, 정확성이 낮다는 방향도 맞지 않습니다.")])

# ---------- 21번째: 반환 다툼은 박물관의 목적을 어떻게 보느냐에서 갈린다 ----------
mk(20, [
 "1) 첫 문장: 맞서는 두 평가를 나란히 놓습니다. 'sometimes said to be'가 두 번 나오므로 둘 다 남들의 말입니다. 글쓴이는 어느 편도 들지 않습니다.",
 "2) 꺾이는 곳: 둘째 문장 가운데의 but입니다. but 앞의 «usually framed as one about ownership»(흔히 소유권 다툼으로 그려진다)이 통념이고, but 뒤의 «it rests on a prior difference about what a collection is for»(그보다 앞선, 소장품이 무엇을 위한 것이냐에 대한 차이에 뿌리를 둔다)가 글쓴이의 말입니다.",
 "3) 되풀이: 「목적을 어떻게 보느냐에 따라 갈린다」가 세 번 나옵니다. 'what a collection is for' → 'If the purpose is'가 두 번(보존과 비교 연구 ↔ 그 역사의 주인을 위해 맡아 두는 것) → «different accounts of what a museum is»(박물관이 무엇인가에 대한 서로 다른 설명).",
 "4) 묶기: 끝 문장 «They are weighing the same facts against different accounts of what a museum is.»(양쪽은 같은 사실을, 박물관이 무엇인가에 대한 서로 다른 설명에 비추어 달고 있다.) 'The disagreement' = 'disputes over repatriation'(반환을 둘러싼 다툼), 'rests on' = 'turn on'(~에 달려 있다), 'different accounts'와 'the purpose' = 'competing views'와 'purpose'."],
 "두 편 가운데 한쪽 말만 옮긴 선택지(돌려주어야 한다, 비교 연구에는 여러 지역의 유물이 필요하다)가 위험합니다. 글쓴이는 어느 편도 들지 않고, 다툼이 어디서 갈리는지를 밝힙니다. 한쪽 주장이 옳아 보여도 그것은 이 글의 주제가 아닙니다.",
 [("반환을 둘러싼 다툼이 박물관의 목적에 대한 맞서는 견해에 달려 있는 방식", "둘째 문장 but 뒤의 «it rests on a prior difference about what a collection is for»를 바꿔 쓴 것입니다. 'rests on'이 'turn on'으로, 'a prior difference'가 'competing views'로, 'what a collection is for'가 박물관의 purpose로 바뀌었습니다."),
  ("박물관이 다툼이 있는 모든 유물을 원래 있던 곳으로 돌려줄 법적 의무가 있는 이유", "법 이야기는 지문에 없습니다. 게다가 둘째 문장은 이 다툼이 소유권 문제로 그려지는 것이 겉모습일 뿐이라고 합니다. 돌려주자는 한쪽 편에 서서 지문에 없는 법적 의무까지 덧붙인 선택지입니다."),
  ("비교 연구를 하려면 여러 지역의 유물을 한데 모아야 하는 이유", "'comparative study'가 지문에 나와서 끌립니다. 하지만 그것은 셋째 문장에 나오는 한쪽 편의 목적입니다. 두 편 가운데 한쪽만 옮긴 선택지입니다."),
  ("식민 지배 시기에 얻은 유물을 원래 있던 곳으로 돌려주어야 하는 이유", "첫 문장의 'correcting a historical wrong'(역사적 잘못을 바로잡는다)에서 떠올리기 쉽습니다. 하지만 그것은 한쪽 편의 말이고, 글쓴이는 어느 편도 들지 않습니다. 식민 지배(colonial rule)라는 말도 지문에 없습니다."),
  ("박물관이 소장품 가운데 무엇을 전시할지 정하는 방식", "지문에 없는 이야기입니다. 「박물관」이라는 소재만 같고 전시 이야기는 나오지 않습니다.")])

# ---------- 22번째: 잠이 모자라면 느낌이 실제를 따라가지 못한다 ----------
mk(21, [
 "1) 첫 문장이 주제를 먼저 말합니다. «people are poor judges of their own impairment»(사람은 자기 능력이 떨어진 정도를 잘 가늠하지 못한다). 뒤에서 이 생각이 되풀이되는지 확인합니다.",
 "2) 되풀이: 「실제는 계속 떨어지는데 느낌은 멈춘다」가 세 번 나옵니다. 둘째 문장의 while 앞뒤(수행은 꾸준히 떨어지고, 스스로 매긴 각성도는 하루 이틀 떨어지다가 «then levels off», 곧 평평해진다) → «even as their measured performance keeps falling»(재어 본 수행은 계속 떨어지는데도) → «plateaus in perception while deepening in fact»(느낌에서는 멈추고 실제로는 깊어진다).",
 "3) 무게가 실린 곳: 넷째 문장 «The mismatch matters more than the deficit itself»(모자람 자체보다 이 어긋남이 더 중요하다). 'A matters more than B'에서 글쓴이가 고른 것은 A, 곧 느낌과 실제의 어긋남입니다. 이 글에는 but이 없고, while과 'even as'가 맞서는 두 쪽을 보여 줍니다.",
 "4) 묶기: 'self-rated alertness', 'how one feels', 'in perception' = 'the perception of sleep deprivation', 'measured performance', 'in fact' = 'its actual effects', 'levels off', 'plateaus' = 'stops tracking'(더는 따라가지 못한다)."],
 "수면 부족의 해로움 자체(the deficit)를 주제로 잡으면 안 됩니다. 글쓴이는 그보다 어긋남이 더 중요하다고 했습니다. 'attention tasks', drive, working처럼 실험 도구나 예에 나온 낱말로 만든 선택지를 조심합니다.",
 [("잠을 덜 자는 사람이 자기가 실제로 얼마나 피곤한지를 더 잘 알아차리게 되는 이유", "방향이 거꾸로입니다. 첫 문장은 사람이 자기 상태를 잘 가늠하지 못한다(poor judges)고 했고, 잠이 모자란 날이 이어질수록 느낌은 실제를 따라가지 못합니다."),
  ("사람의 수면 주기를 조절하는 생리적 작동 방식", "지문에 없는 이야기입니다. 「수면」이라는 소재만 같고, 몸속 작동 방식은 나오지 않습니다."),
  ("실험실에서 인지 수행을 재는 데 주의력 과제가 쓰이는 방식", "'attention tasks', measured가 지문에 나오지만 실험에 쓴 도구일 뿐입니다. 글은 재는 방법이 아니라, 재어 본 결과와 느낌이 어긋난다는 것을 말합니다."),
  ("교대 근무자가 낮 근무자보다 사고를 더 많이 겪는 이유", "'drive, operate equipment, or continue working'에서 떠올리기 쉽습니다. 하지만 교대 근무자도, 사고를 견준 이야기도 지문에 없습니다. 상식으로 이어 붙인 선택지입니다."),
  ("수면 부족에 대한 느낌이 실제 영향을 더는 따라가지 못하는 이유", "끝 문장 «One that plateaus in perception while deepening in fact removes the signal that would prompt anyone to act.»를 바꿔 쓴 것입니다. 'plateaus in perception'이 'the perception … stops tracking'으로, 'deepening in fact'가 'its actual effects'로 바뀌었습니다.")])

# ---------- 23번째: 아무도 책임지지 않는 소프트웨어의 위험 ----------
mk(22, [
 "1) 꺾이는 곳: 둘째 문장에는 but이 없고 and가 있습니다. «The arrangement is enormously productive and it distributes an obligation that nobody has accepted»(이 짜임은 엄청나게 생산적이고, 아무도 받아들인 적 없는 의무를 퍼뜨린다). and 앞은 좋은 점이고, and 뒤가 글쓴이가 하려는 말입니다. 표시 없이 꺾이는 숨은 역접입니다.",
 "2) 되풀이: 「맡은 사람이 없다」가 nobody, absence, Nothing으로 되풀이됩니다. 'nobody has accepted' → «not a bug but an absence»(오류가 아니라 '없음') → «a security advisory nobody is positioned to answer»(아무도 답할 자리에 있지 않은 보안 경고) → 끝 문장의 'Nothing … distinguishes'(아무것도 가려 주지 않는다).",
 "3) 넷째 문장: 기업은 이름 붙일 수 있는 위험(licence, 법적 위험)은 살피고 유지 관리는 거의 살피지 않습니다. «an unmaintained library works perfectly until the day it does not»(관리되지 않는 라이브러리는 멈추는 그날까지 완벽하게 돌아간다). 그래서 이 위험은 미리 보이지 않습니다.",
 "4) 묶기: 'load-bearing infrastructure', 'the failure', 'security advisory' = 'a risk', 'libraries', 'component' = 'software', 'nobody has accepted', 'nobody is positioned to answer' = 'that nobody is responsible for'(아무도 책임지지 않는)."],
 "둘째 문장 and 앞의 좋은 점(productive)만 담은 선택지가 위험합니다. 글의 무게는 and 뒤에 있습니다. legal, security, volunteers처럼 지문 낱말 하나로 만든 선택지도 조심합니다. 특히 'legal risk'는 지문에서 기업이 이미 살피는 쪽의 위험으로, 글이 말하려는 위험의 반대편에 있습니다.",
 [("개발자가 자기 코드의 결함에 법적 책임을 지게 되는 이유", "'legal risk'가 지문에 나오지만, 그것은 라이선스에 관한 것이고 기업이 이미 살피는 위험입니다. 글의 논점은 오히려 아무도 책임지지 않는다는 것이므로 방향도 맞지 않습니다."),
  ("함께 쓰는 코드에서 얻을 수 있는 생산성 이득", "둘째 문장의 'enormously productive'를 옮긴 것으로, 지문에 있는 사실입니다. 하지만 그것은 and 앞의 좋은 점이고, 글의 무게는 and 뒤의 「아무도 맡지 않은 의무」에 있습니다. 맞는 말이지만 절반만 담은 선택지입니다."),
  ("라이브러리의 보안 결함을 찾아내는 방법들", "'security advisory', libraries에서 떠올리기 쉽습니다. 하지만 글은 문제가 결함(bug)이 아니라 맡은 사람이 없다는 것(absence)이라고 했습니다. 찾아내는 방법도 지문에 없습니다."),
  ("아무도 책임지지 않는 소프트웨어가 안고 있는 위험", "둘째 문장의 «it distributes an obligation that nobody has accepted»를 바꿔 쓴 것입니다. 'an obligation that nobody has accepted'가 'that nobody is responsible for'로 바뀌었고, 셋째 문장의 'nobody is positioned to answer'와 끝 문장의 Nothing이 같은 생각을 되풀이합니다."),
  ("자원봉사자들이 돈을 받지 않고 프로젝트에 이바지하는 이유", "volunteers, unpaid가 지문에 나오지만, 글은 그들이 왜 그렇게 하는지를 묻지 않습니다. 글이 묻는 것은 그들이 멈췄을 때 생기는 일입니다. 물음을 바꿔치기한 선택지입니다.")])

# ---------- 24번째: 글자냐 취지냐는 기관이 무엇을 앞세우느냐로 정해진다 ----------
mk(23, [
 "1) 첫 문장이 두 길을 내놓습니다. «whether to follow the words or the evident purpose»(글자를 따를 것인가, 분명한 취지를 따를 것인가). 둘 가운데 한쪽을 편드는 글인지, 다른 말을 하려는 글인지 끝까지 읽어야 합니다.",
 "2) 되풀이: 「어느 쪽에도 치르는 값이 있다」가 세 번 나옵니다. «Each option carries a cost that the other avoids.»(각 길에는 다른 길이 피하는 값이 따른다.) → 셋째 문장의 but(미리 알 수 있지만, 아무도 뜻하지 않은 결과가 나옴) → 넷째 문장의 but(결과는 사리에 맞지만, 미리 알 수 없음). 두 but이 서로 맞비기므로 글쓴이는 어느 편도 들지 않습니다.",
 "3) 끝 문장의 쌍반점(;) 앞뒤가 'not A; B' 꼴입니다. «the choice is rarely settled by argument»(이 선택은 논증으로 매듭지어지는 일이 드물다). 쌍반점 뒤가 글쓴이의 말입니다. 주제가 끝 문장에만 나오는 글입니다.",
 "4) 묶기: «it is settled by which cost the institution in question is currently more anxious to avoid»(그 기관이 지금 어느 값을 더 피하고 싶어 하느냐로 정해진다). 'the words' = 'literal', 'the purpose' = 'purposive', 기관이 더 피하고 싶어 하는 값 = 'institutional priorities'(기관이 무엇을 앞세우느냐)."],
 "두 길 가운데 한쪽이 낫다고 말하는 선택지(글자대로 읽는 쪽이 더 공정하다, 예측 가능성이 앞서야 한다)가 위험합니다. 셋째·넷째 문장 가운데 하나만 읽으면 그렇게 보입니다. 글쓴이는 우열을 가리지 않고, 무엇이 선택을 정하는지를 말합니다.",
 [("법을 글자대로 읽는 판사가 취지를 살피는 판사보다 더 공정한 결정에 이르는 이유", "두 길 가운데 한쪽 편을 든 선택지입니다. 글은 글자를 따르면 아무도 뜻하지 않은 결과가 나온다(outcomes that no one intended)고도 했습니다. 어느 쪽이 더 공정한지는 가리지 않습니다."),
  ("글자대로 해석할 것인가 취지대로 해석할 것인가의 선택이 기관이 무엇을 앞세우느냐를 비추는 이유", "끝 문장 쌍반점 뒤의 «it is settled by which cost the institution in question is currently more anxious to avoid»를 바꿔 쓴 것입니다. 기관이 지금 더 피하고 싶어 하는 값이 'institutional priorities'로 바뀌었습니다."),
  ("입법자가 더 넓은 범위의 사례를 내다보는 규칙을 짤 수 있는 방법", "첫 문장의 'cases its author did not envisage'(만든 사람이 내다보지 못한 사례)에서 떠올리기 쉽습니다. 하지만 글은 그런 사례가 생기는 것을 피할 수 없는 일로 깔고 시작합니다. 규칙을 잘 짜는 방법은 지문에 없습니다."),
  ("법에서 예측 가능성이 사리에 맞는 결과보다 앞서야 하는 이유", "predictability, 'sensible outcomes'가 지문에 나와서 끌립니다. 하지만 글은 어느 쪽이 앞서야 한다(should)고 하지 않습니다. 논증으로는 매듭지어지지 않는다는 것이 글의 말입니다. 한쪽 편을 든 선택지입니다."),
  ("일반 규칙이 여러 법 전통에서 서로 다르게 적용되는 방식", "'general terms', rule에서 떠올리기 쉽지만, 법 전통을 견주는 이야기는 지문에 없습니다.")])

# ---------- 25번째: 품종을 줄이는 것은 육종이 아니라 뒤 단계의 표준화다 ----------
mk(24, [
 "1) 되풀이: 「밭 다음 단계들이 하나의 규격에 맞춰진다」가 one으로 세 번 나옵니다. 'one size'(기계), 'one grade'(계약), 'one appearance'(소비자). 첫 문장의 «every stage of the system adapts to a standard product»(체계의 모든 단계가 표준 제품에 맞춰진다)를 풀어 쓴 것입니다.",
 "2) 셋째 문장의 'not because A but because B': 규격에 안 맞는 품종이 사라지는 까닭은 «not because they perform poorly in the field but because nothing downstream can accommodate them»(밭에서 못 자라서가 아니라, 뒤 단계 어디서도 받아 줄 수 없어서)입니다. but 뒤가 글쓴이의 말입니다.",
 "3) 끝 문장의 통념과 꺾이는 곳: «often attributed to breeding choices»(흔히 육종의 선택 탓으로 돌려진다)가 통념이고, 쉼표 뒤의 though가 뒤집습니다. «breeding was responding to constraints that the rest of the system had already fixed»(육종은 체계의 나머지가 이미 정해 놓은 제약에 따랐을 뿐이다). though도 but과 같은 구실을 합니다.",
 "4) 묶기: 'nothing downstream', 'the rest of the system' = 'downstream standardization'(뒤 단계의 표준화), 통념 쪽 'breeding choices' = 'not breeding itself', 'The narrowing', 'they disappear' = 'narrows the range of crop varieties'."],
 "끝 문장 though 앞의 통념(육종가가 품종을 줄인다)을 옮긴 선택지가 가장 위험합니다. 'is often attributed to'는 남들의 설명을 소개하는 표현입니다. machinery, consumers처럼 둘째 문장에 나열된 것 하나를 키운 선택지도 조심합니다. 기계, 계약, 소비자는 셋이 함께 「뒤 단계」를 이룹니다.",
 [("식물 육종가들이 농부가 기를 수 있는 작물 품종의 수를 일부러 줄이는 방식", "끝 문장 though 앞의 통념(육종의 선택 탓)을 옮긴 것입니다. 글쓴이는 though 뒤에서 육종은 이미 정해진 제약에 따랐을 뿐이라고 합니다. 통념을 주제로 착각한 선택지입니다."),
  ("현대의 수확 기계가 농사짓는 방식을 바꾸어 놓은 방식", "harvest, Machinery가 지문에 나오지만, 기계는 뒤 단계의 예 셋 가운데 하나입니다. 나열된 것 하나를 주제로 부풀린 선택지입니다."),
  ("육종 자체가 아니라 뒤 단계의 표준화가 작물 품종의 폭을 좁히는 방식", "끝 문장의 «breeding was responding to constraints that the rest of the system had already fixed»를 바꿔 쓴 것입니다. 'the rest of the system'이 'downstream standardization'으로, 'The narrowing'이 'narrows the range of crop varieties'로 바뀌었고, 통념을 밀어내는 'not breeding itself'가 though의 구실을 합니다."),
  ("고른 작물이 여러 품종을 섞어 심는 것보다 농부에게 더 이익이 되는 이유", "첫 문장의 'easier to harvest, process, and sell'에서 떠올리기 쉽습니다. 하지만 그것은 글의 출발점일 뿐이고, 농부의 이익을 견주는 이야기는 지문에 없습니다. 글의 논점은 품종이 왜 줄어드는가입니다."),
  ("소비자가 크기와 겉모습이 고른 농산물을 더 좋아하는 이유", "'consumers come to expect one appearance'에서 떠올리기 쉽습니다. 하지만 소비자는 뒤 단계의 예 셋 가운데 하나이고, 글은 소비자가 왜 그런지를 묻지 않습니다. 나열된 것 하나를 주제로 부풀린 선택지입니다.")])

# ---------- 26번째: 평점의 평균은 따져지지 않은 전제 위에 서 있다 ----------
mk(25, [
 "1) 첫 문장이 주제를 먼저 말합니다. «arithmetic that the scale may not support»(그 척도가 받쳐 주지 못할 수도 있는 셈). 숫자가 붙어 있으니 셈을 하고 싶어지지만, 해도 되는지는 따로 따져야 한다는 뜻입니다.",
 "2) 꺾이는 곳: 셋째 문장의 while입니다. while 앞은 «a number that behaves like a measurement»(재어 얻은 값처럼 구는 숫자), while 뒤는 «resting on assumptions that were never established»(한 번도 확인된 적 없는 전제에 기대고 있음)입니다. 겉과 속이 맞섭니다.",
 "3) 되풀이: 「확인되지 않은 채 넘어간다」가 세 번 나옵니다. 'never established' → «nothing in the output signals the difficulty»(결과 어디에도 문제가 있다는 표시가 없다) → «as though the question had been settled»(그 물음이 이미 풀린 것처럼). 'as though'는 실제로는 풀리지 않았다는 신호입니다.",
 "4) 묶기: 'Averaging such ratings' = 'averaging rating scales', 'a number', 'A mean of 3.7' = 'figures', 'never established', 'as though … settled' = 'whose validity remains unexamined'(타당한지 따져지지 않은 채 남은)."],
 "평균 낸 점수를 믿을 만한 것으로 말하는 선택지(가장 정밀한 잣대)가 가장 위험합니다. 3.7 같은 숫자는 정밀해 보이지만, 글은 바로 그 겉모습이 문제라고 합니다. ranking, decisions처럼 넷째·다섯째 문장의 낱말로 만든 선택지도 조심합니다.",
 [("평가 척도의 평균을 내면 타당한지 따져지지 않은 수치가 나오는 이유", "셋째 문장 «Averaging such ratings produces a number that behaves like a measurement while resting on assumptions that were never established.»를 바꿔 쓴 것입니다. 'a number'가 'figures'로, 'assumptions that were never established'가 'whose validity remains unexamined'로 바뀌었습니다."),
  ("평균 낸 평가 척도가 사람들의 생각을 재는 가장 정밀한 잣대가 되는 이유", "방향이 거꾸로입니다. averaged, 'rating scales'가 들어 있어 끌리지만, 글은 그 숫자가 재어 얻은 값처럼 굴 뿐(behaves like a measurement)이라고 했습니다. 숫자는 정밀해 보인다는 겉모습으로 고르는 함정입니다."),
  ("설문을 만드는 사람이 믿을 만한 자료를 내는 척도를 어떻게 짜야 하는가", "글은 문제가 무엇인지 밝히는 데서 끝나고, 척도를 어떻게 짜야 하는지는 말하지 않습니다. 설문을 만드는 사람도 지문에 없습니다. 진단을 해결책으로 바꾼 선택지입니다."),
  ("평점에서 나온 순위가 기관의 의사 결정 과정에 미치는 영향", "ranking, decisions가 지문에 나와서 끌립니다. 하지만 순위는 이 관행이 이어지는 까닭 하나로, 결정은 끝 문장에서 스치듯 나올 뿐입니다. 글의 논점은 영향이 아니라, 그 숫자를 믿어도 되는지가 확인되지 않았다는 것입니다."),
  ("평가에서 숫자 평점이 글로 쓴 의견보다 나은 이유", "지문에 없는 비교입니다. 글로 쓴 의견은 나오지 않고, 글은 숫자 평점의 좋은 점이 아니라 문제를 말합니다.")])

# ---------- 27번째: 사람은 기관과 닿은 곳에서만 기록에 보인다 ----------
mk(26, [
 "1) 첫 문장의 신호: «runs deeper than gaps in the record»(기록의 빈틈보다 더 깊은 문제). 'deeper than'은 기록이 모자란다는 흔한 생각을 밀어내고 다른 문제를 말하겠다는 표시입니다.",
 "2) 되풀이: 「사람은 기관과 닿은 곳에서만 기록에 나타난다」가 세 번 나옵니다. «the reasons were institutional»(문서가 만들어진 까닭은 기관의 일이었다) → «at moments when they came into contact with authority»(권력과 닿은 순간에) → «visible where it intersected an institution and invisible elsewhere»(기관과 만난 곳에서는 보이고 다른 곳에서는 보이지 않는다).",
 "3) 넷째 문장 뒤쪽: «the record is densest precisely where it is least representative»(기록은 가장 덜 대표적인 바로 그곳에서 가장 빽빽하다). 세금, 소송, 처벌은 보통의 나날이 아니기 때문입니다.",
 "4) 묶기: 끝 문장의 'not A but B'는 그래서 역사가가 무엇을 해야 하는지를 말합니다. 'appear in the archive', 'visible' = 'archival visibility', 'contact with authority', 'intersected an institution' = 'institutional contact', 'ordinary life', 'least representative' = 'rather than ordinary experience'."],
 "기록이 많이 남은 것을 좋은 것으로 읽은 선택지(공식 기록이 보통 사람의 삶을 가장 온전히 담는다, 세금·법원 기록이 가장 믿을 만하다)가 위험합니다. 글은 많이 남은 곳일수록 덜 대표적이라고 합니다. 끝 문장의 'assembling scattered traces'(흩어진 흔적 모으기)를 주제로 삼은 선택지도 조심합니다. 그것은 not 뒤, 곧 글쓴이가 밀어내는 쪽입니다.",
 [("기록에 드러나는 것이 보통의 경험이 아니라 기관과 닿은 곳을 따라가는 이유", "넷째 문장의 «A life is visible where it intersected an institution and invisible elsewhere»를 바꿔 쓴 것입니다. 'visible'이 'archival visibility'로, 'intersected an institution'이 'institutional contact'로 바뀌었고, 'least representative'가 'rather than ordinary experience'에 담겼습니다."),
  ("공식 기록 보관소가 다른 어떤 자료보다 사람들의 보통 삶을 더 온전히 담는 이유", "방향이 거꾸로입니다. archives, 'ordinary lives'가 들어 있어 끌리지만, 글은 기록이 가장 빽빽한 곳이 가장 덜 대표적이라고 했습니다. 기록이 많으면 잘 담겼을 것이라는 상식으로 고르는 함정입니다."),
  ("세금 기록과 법원 기록이 역사 자료 가운데 가장 믿을 만한 이유", "taxation, litigation이 지문에 나와서 끌립니다. 하지만 그것들은 문서가 만들어진 까닭의 예이고, 글은 그런 기록이 한쪽으로 쏠려 있다고 합니다. 가장 믿을 만하다는 평가는 지문에 없습니다."),
  ("역사가들이 불완전한 문서 증거로 일상을 다시 짜 맞추는 방식", "가장 그럴듯한 오답입니다. 하지만 흩어진 흔적을 모아 짜 맞추는 일은 끝 문장에서 not 뒤에 놓인, 글쓴이가 밀어내는 쪽입니다. 또 글은 문제가 기록이 불완전하다(gaps)는 것보다 더 깊은 데 있다고 했습니다."),
  ("보통 삶의 연구가 전통적인 정치사와 어떻게 다른가", "지문에 없는 비교입니다. 'ordinary life'만 같고 정치사는 한 번도 나오지 않습니다.")])

# ---------- 28번째: 사람을 향한 피드백은 고치는 데 쓸 주의를 빼앗는다 ----------
mk(27, [
 "1) 첫 문장: «Feedback intended to improve performance frequently does the opposite»(수행을 높이려던 피드백이 자주 정반대 결과를 낸다). 왜 그런지가 이 글의 물음입니다. 'systematic rather than incidental'은 어쩌다가 아니라 늘 그런 까닭이 있다는 뜻입니다.",
 "2) 되풀이: 「사람을 향하느냐, 일을 향하느냐」라는 짝이 세 번 나옵니다. 둘째 문장의 'to the person' ↔ 'to the task' → 넷째 문장의 'the first'(사람 쪽) → 끝 문장의 «thinking about the work or about themselves»(일을 생각하느냐, 자기 자신을 생각하느냐).",
 "3) 꺾이는 곳: 넷째 문장의 But입니다. But 앞의 «Both may be delivered kindly and both may be accurate.»(둘 다 친절할 수 있고 둘 다 정확할 수 있다.)는 물러서 주는 말이고, But 뒤가 글쓴이의 말입니다. 사람을 향한 말은 «competes for the same resources that the correction would require»(고치는 데 써야 할 바로 그 자원을 두고 다툰다).",
 "4) 묶기: 'directs attention to the person', 'the first' = 'feedback directed at the person', 'competes for the same resources' = 'displaces the attention'(주의를 밀어낸다), 'the correction would require' = 'that correction requires'."],
 "친절하게(kindly), 정확하게(accurate) 말하면 된다는 쪽으로 읽으면 안 됩니다. 글쓴이는 But 앞에서 그것만으로는 갈리지 않는다고 미리 말합니다. 사람을 칭찬하면 더 잘 고친다는 선택지는 방향이 거꾸로입니다. 칭찬도 사람을 향한 말이기 때문입니다.",
 [("사람의 능력을 칭찬하면 그 사람이 잘못을 고치는 데 더 주의를 기울이게 되는 이유", "방향이 거꾸로입니다. 능력을 칭찬하는 것도 사람을 향한 말입니다. 글은 사람을 향한 말이 고치는 데 쓸 주의를 빼앗는다고 했습니다. 「칭찬은 좋은 것」이라는 상식으로 고르면 걸립니다."),
  ("잦은 피드백이 이따금 하는 검토보다 결과를 더 좋게 하는 이유", "첫 문장의 frequently에서 떠올릴 수 있지만, 피드백을 얼마나 자주 주느냐는 지문에 없습니다. 글이 가르는 기준은 횟수가 아니라 향하는 곳(사람 ↔ 일)입니다."),
  ("윗사람이 일터의 관계를 해치지 않으면서 비판을 전하는 방법", "'delivered kindly'에서 떠올리기 쉽습니다. 하지만 글쓴이는 친절하게 전하는 것만으로는 갈리지 않는다고 했습니다. 관계 이야기도 지문에 없습니다."),
  ("받는 사람이 자기 일에 대한 뜻밖의 비판에 흔히 반응하는 방식", "recipient가 지문에 나오지만 너무 넓습니다. 「사람을 향한 말이 주의를 빼앗는다」는 논점이 빠져 있고, 뜻밖의 비판이라는 말도 지문에 없습니다."),
  ("사람을 향한 피드백이 고치는 데 필요한 주의를 밀어내는 이유", "넷째 문장 «But the first initiates a process concerned with what the evaluation implies about the recipient, which competes for the same resources that the correction would require.»를 바꿔 쓴 것입니다. 'the first'가 'feedback directed at the person'으로, 'competes for the same resources'가 'displaces the attention'으로 바뀌었습니다.")])

# ---------- 29번째: 의사를 붙잡아 두는 것은 돈이 아니라 일의 조건이다 ----------
mk(28, [
 "1) 짝 찾기: 둘째·셋째 문장이 짝입니다. 둘째는 돈을 주는 방식, 셋째는 일 자체를 바꾸는 방식입니다. but은 없지만 두 문장의 결과가 맞섭니다. 표시 없이 맞세우는 숨은 역접입니다.",
 "2) 돈 쪽의 결과: «a payment buys a stay of the length it funds»(돈은 그 돈이 대 주는 기간만큼의 머묾을 산다). 받은 사람은 기간을 채우고 떠나고, 자리는 다시 빕니다.",
 "3) 일 쪽의 결과: «Places that retained staff did so by changing what the job was»(의사를 붙잡아 둔 곳은 일이 어떤 것인지를 바꾸어서 그렇게 했다). 쉴 수 있게 대신 봐 줄 사람을 두고, 혼자만 할 수 있는 일이 없도록 진료소들을 이었습니다.",
 "4) 묶기: 'retained staff' = 'retention'(붙잡아 두기), 'changing what the job was' = 'the conditions of the job', payments = pay. 'A rather than B'로 일의 조건을 고르고 돈을 밀어낸 선택지가 답입니다. 끝 두 문장(둘 다 싸지 않고, 비용이 드러나는 방식이 다르다)은 덧붙인 말입니다."],
 "「돈을 더 주면 남는다」는 상식을 말하는 선택지가 가장 위험합니다. 둘째 문장은 돈이 머무는 기간만 산다고 했습니다. 끝부분 때문에 일을 바꾸는 쪽이 더 싸다고 읽어도 안 됩니다. «Neither approach is cheap.»(어느 방식도 싸지 않다.)",
 [("더 높은 급여를 주는 것이 직원이 떠나는 것을 막는 가장 효과적인 방법인 이유", "방향이 거꾸로입니다. 둘째 문장은 돈을 받은 사람이 기간을 채우고 떠난다고 했습니다. 「돈을 더 주면 남는다」는 상식으로 고르면 걸립니다."),
  ("시골 지역에서 일할 의사를 구하는 어려움", "'a new recruit to find', county에서 떠올리기 쉽습니다. 하지만 글의 논점은 구하기(recruiting)가 아니라 붙잡아 두기(retained)입니다. 구해 와도 떠난다는 것이 글의 문제입니다. 시골(rural)이라는 말도 지문에 없습니다."),
  ("금전적 유인이 진로 선택에 미치는 영향", "Incentives, payments가 지문에 나와서 끌립니다. 하지만 글은 돈 쪽만 다루지 않고 일을 바꾸는 쪽과 맞세웁니다. 진로 선택 이야기도 지문에 없습니다. 두 쪽 가운데 한쪽만 옮긴 선택지입니다."),
  ("붙잡아 두는 일이 급여가 아니라 일의 조건에 달려 있는 이유", "셋째 문장의 «Places that retained staff did so by changing what the job was»를 바꿔 쓴 것입니다. 'retained staff'가 'retention'으로, 'changing what the job was'가 'the conditions of the job'으로 바뀌었고, 둘째 문장의 payments가 'rather than on pay'로 밀려났습니다."),
  ("도시와 시골 사이의 건강 결과 차이", "지문에 없는 이야기입니다. 「의사」라는 소재만 같고, 건강 결과도 도시와 시골의 비교도 나오지 않습니다.")])

# ---------- 30번째: 번역은 못한 원문이 아니라 해석의 증거다 ----------
mk(29, [
 "1) 통념과 물러서기: 첫 문장의 «commonly treated as a diminished version»(흔히 한 단계 낮은 것으로 다뤄진다)이 통념입니다. 글쓴이는 'and for close verbal analysis it is'(낱말을 꼼꼼히 따질 때는 실제로 그렇다)라고 먼저 인정합니다.",
 "2) 꺾이는 곳: but 없이 둘째 문장이 뒤집습니다. «For other purposes the relation is less straightforward.»(다른 목적에서는 그 관계가 그렇게 단순하지 않다.) 숨은 역접입니다.",
 "3) 되풀이: 「번역에는 번역한 사람의 이해가 남아 있다」가 세 번 나옵니다. «the marks of a second encounter»(두 번째 만남의 자국) → «are themselves evidence»(그 자체가 증거다) → «a complete record of another»(다른 어떤 것의 온전한 기록).",
 "4) 묶기: 끝 문장의 thus가 결론 표시이고, 'not only A but B' 꼴입니다. A는 인정한 통념('a lesser version')이고 B가 글쓴이의 말입니다. 'evidence, bearing on how the work was understood' = 'evidence of interpretation'(해석의 증거), 'not only a lesser version' = 'rather than merely a lesser original'."],
 "첫 문장의 통념을 그대로 옮긴 선택지(원어로 읽는 것이 언제나 낫다, 원문의 글귀를 얼마나 그대로 옮겼는지로만 판단해야 한다)가 위험합니다. 글쓴이는 그 생각을 일부 인정하지만 거기서 멈추지 않습니다. always, only 같은 센 말이 붙으면 「일부 인정」과 맞지 않습니다.",
 [("번역을 원문의 글귀를 얼마나 가깝게 되살렸는지로만 판단해야 하는 이유", "첫 문장의 통념(번역은 원문보다 낮은 것) 쪽에 선 선택지입니다. 글쓴이는 낱말을 꼼꼼히 따질 때만 그렇다고 하고, 다른 목적에서는 번역이 따로 증거가 된다고 합니다. only가 글의 방향과 맞지 않습니다."),
  ("같은 작품의 번역들이 시대에 따라 어떻게 다른가", "'at a particular moment'(어느 한 시점에)에서 떠올리기 쉽습니다. 하지만 글은 여러 시대의 번역을 견주지 않습니다. 번역 하나가 그 시점의 이해를 담은 기록이라는 것까지만 말합니다."),
  ("번역이 그저 원문보다 못한 것이 아니라 해석의 증거가 되는 방식", "끝 문장 «The translation is thus not only a lesser version of one thing but a complete record of another.»를 바꿔 쓴 것입니다. 'a complete record of another'가 'evidence of interpretation'으로, 'not only a lesser version'이 'rather than merely a lesser original'로 바뀌었습니다."),
  ("언어 사이를 옮길 때 문체의 특징을 지키는 어려움", "'what resisted transfer'(옮겨지기를 버틴 것)에서 떠올리기 쉽습니다. 하지만 글에서 그것은 번역이 남긴 자국의 한 가지일 뿐이고, 글은 번역의 어려움이 아니라 번역이 무엇의 증거가 되는지를 말합니다."),
  ("문학 작품을 원어로 읽는 것이 언제나 더 나은 이유", "첫 문장의 통념을 더 세게 말한 것입니다. 글쓴이는 둘째 문장에서 다른 목적에서는 그렇게 단순하지 않다고 뒤집습니다. always 같은 센 말을 조심해야 합니다.")])

# ---------- 승인 반영(2026-10-03): 18번째 정답 문구 create → simulate ----------
# 'create accountability without producing it'는 create와 producing이 같은 뜻이라 말이 맞지 않았음
_OLD18 = 'why disclosing complex information can create accountability without producing it'
_NEW18 = 'why disclosing complex information can simulate accountability without producing it'
_e = E[('23','9',17)]
assert _tb['23']['9'][17]['choices'][4] == _OLD18 and _tb['23']['9'][17]['answer'] == 4
_e['ch'] = {4: _NEW18}; _e['ans_ok'] = True
_e['cn'][4] = ("정답입니다. '%s' (복잡한 정보를 공개하는 것이 책임성을 실제로 낳지는 못하면서 그 흉내만 낼 수 있는 이유) — " % _NEW18
    + "끝 문장의 \"with the appearance of accountability supplied by the first\"(책임을 지는 듯한 겉모습은 앞의 것, 곧 바뀐 정보 분포가 대 준다)를 바꿔 쓴 것입니다. "
    + "'the appearance of accountability'가 'simulate accountability'로 바뀌었습니다. 정보는 퍼졌지만 지식은 거의 그대로이므로 실제 책임성은 생기지 않고, 그것이 'without producing it'입니다.")
_a = "'the impression', 'the appearance' = 겉으로만 만들어 낸다, 'changed hardly at all' = 'without producing it'(실제로는 낳지 못한다)."
_b = "'the impression', 'the appearance of accountability' = 'simulate accountability'(책임을 지는 흉내를 낸다), 'changed hardly at all' = 'without producing it'(실제로는 낳지 못한다)."
assert _e['walk'].count(_a) == 1; _e['walk'] = _e['walk'].replace(_a, _b)
