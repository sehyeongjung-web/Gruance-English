# -*- coding: utf-8 -*-
# 203번: 23번(주제) 레벨9 선택지를 수능식 명사구로 — 1~10번째 (선생님 승인: 202번 시범 뒤 "계속")
# why·how로 시작하던 선택지를 머리 명사가 있는 명사구로. 뜻은 그대로, 다섯 선택지의 길이 차례도 되도록 그대로.
# 이미 명사구인 선택지는 손대지 않음. 해설은 머리의 영어·우리말 해석과, 옛 선택지의 영어를 옮긴 대목만 맞춤
AUTO_SYNC = False
E = {}
from n23common import R

# 1번째 (202번 시범에 보여 드린 그대로)
R(E, 0,
  {0: 'the necessity of presenting scientific findings as certain to keep public trust stable',
   2: 'the way overstated certainty in science weakens rather than secures public trust',
   3: 'the process of reaching consensus among researchers in contested fields'},
  {0: '대중의 신뢰를 흔들리지 않게 지키려면 과학적 발견을 확실한 것으로 제시해야 한다는 필요성',
   2: '과학에서 부풀린 확실함이 대중의 신뢰를 지켜 주기는커녕 약하게 만드는 방식',
   3: '논쟁이 있는 분야에서 연구자들이 합의에 이르는 과정'},
  subs={2: [("'presenting … as more certain'이 'overstating certainty'로", "'presenting … as more certain'이 'overstated certainty'로"),
            ("'undermines rather than secures'로 바뀌었습니다", "'weakens rather than secures'로 바뀌었습니다")]},
  walk_sub=[("되풀이된 생각 = 'overstating certainty'(확실함을 부풀리기).", "되풀이된 생각 = 'overstated certainty'(부풀린 확실함)."),
            ("= 'undermines rather than secures'(지켜 주기는커녕 무너뜨린다).", "= 'weakens rather than secures'(지켜 주기는커녕 약하게 만든다).")])

# 2번째 (시범 그대로)
R(E, 1,
  {0: 'the reason tightly specialized regional economies are the quickest to recover from economic shocks',
   1: 'the exchange of future adaptability for present efficiency in tight economic specialization',
   2: 'the influence of civic institutions on the character of local communities',
   4: 'the consistent advantage of coordinated public planning over market-driven growth'},
  {0: '긴밀하게 특화된 지역 경제가 경제 충격에서 가장 빨리 회복하는 이유',
   1: '긴밀한 경제 특화에서 미래의 적응력을 내주고 지금의 효율을 얻는 맞바꿈',
   2: '시민 기관이 지역 사회의 성격에 미치는 영향',
   4: '조율된 공공 계획이 시장 주도 성장보다 늘 앞선다는 것'},
  walk_sub=[("'trades A for B'는 「A를 내주고 B를 얻는다」는 뜻이므로", "'the exchange of A for B'는 「A를 내주고 B를 얻는 맞바꿈」이라는 뜻이므로")])

# 3번째 (시범 그대로)
R(E, 2,
  {1: 'the difference between recognizing emotion in music and experiencing it',
   3: 'tempo and interval structure as determinants of musical meaning',
   4: 'causes of disagreement among listeners about emotion in music'},
  {1: '음악에서 감정을 알아보는 것과 그 감정을 겪는 것의 차이',
   3: '음악의 의미를 정하는 것으로서의 박자와 음정 구조',
   4: '음악에 담긴 감정을 두고 청자들의 의견이 갈리는 까닭'},
  subs={4: [("agree를 disagree로 뒤집은 선택지입니다", "agree를 disagreement로 뒤집은 선택지입니다")]},
  walk_sub=[("구별 = 'differs', 알아보기 = 'recognizing emotion', 느끼기·겪기 = 'experiencing that emotion'.",
             "구별 = 'the difference between', 알아보기 = 'recognizing emotion', 느끼기·겪기 = 'experiencing it'.")])

# 4번째
R(E, 3,
  {0: 'the reason judges are bound by precedent to reach exactly the results earlier courts reached',
   2: 'changes in the vocabulary of legal argument across historical periods',
   3: 'the way precedent constrains legal reasoning without determining its eventual results',
   4: 'the freedom courts ought to have to disregard decisions made in earlier eras'},
  {0: '판사들이 선례에 묶여 앞선 법원이 내린 것과 똑같은 결과에 이르게 되는 이유',
   2: '시대에 따른 법적 논증 어휘의 변화',
   3: '선례가 최종 결과를 정하지는 않으면서 법적 추론을 제약하는 방식',
   4: '법원이 옛 시대의 판결을 무시할 수 있도록 가져야 하는 자유'})

# 5번째
R(E, 4,
  {0: 'the reason ecological theory rather than historical records should set the targets of restoration',
   1: 'the dependence of restoration targets on the availability of records, not ecological reasoning',
   2: 'the duty to reverse every trace of human disturbance where possible',
   3: 'the contribution of photographic evidence to the accuracy of environmental history'},
  {0: '역사 기록이 아니라 생태 이론이 복원 목표를 정해야 하는 이유',
   1: '복원 목표가 생태적 판단이 아니라 기록이 남아 있느냐에 달려 있다는 것',
   2: '사람이 남긴 교란의 흔적을 가능한 한 모두 되돌려야 한다는 의무',
   3: '사진 증거가 환경사의 정확성에 보탠 몫'})

# 6번째
R(E, 5,
  {0: 'ways careful platform design can keep the benefits of anonymity and remove its harms',
   2: 'the impossibility of separating the benefits and harms of anonymity by design',
   4: 'reasons for the marked increase in harassment in digital public spaces'},
  {0: '꼼꼼한 플랫폼 설계가 익명성의 좋은 점은 남기고 해로운 점은 없앨 수 있는 길',
   2: '익명성의 좋은 점과 해로운 점을 설계로 갈라놓을 수 없다는 것',
   4: '디지털 공공 공간에서 괴롭힘이 눈에 띄게 늘어난 까닭'},
  walk_sub=[("= 'cannot be separated'(갈라놓을 수 없다)", "= 'the impossibility of separating'(갈라놓을 수 없음)")])

# 7번째
R(E, 6,
  {0: 'the special tendency of hospitals and schools toward deliberate cheating on their figures',
   2: 'the fundamental unsuitability of quantitative measurement for most public services',
   3: 'ways of evaluating hospitals and schools more fairly and consistently',
   4: 'the loss of descriptive value in indicators once they are treated as targets'},
  {0: '병원과 학교가 수치를 일부러 속이는 쪽으로 특히 기울기 쉽다는 것',
   2: '숫자로 재는 일이 대부분의 공공 서비스에 근본적으로 맞지 않는다는 것',
   3: '병원과 학교를 더 공정하고 한결같이 평가하는 방법',
   4: '지표가 목표로 다뤄지는 순간 알려 주는 힘을 잃는 일'},
  subs={2: [("fundamentally, most 같은 센 말", "fundamental, most 같은 센 말")],
        4: [("'stops reporting'이 'lose their descriptive value'로 바뀌었습니다", "'stops reporting'이 'the loss of descriptive value'로 바뀌었습니다")]},
  walk_sub=[("'stops reporting' = 'lose their descriptive value'(알려 주는 힘을 잃는다)", "'stops reporting' = 'the loss of descriptive value'(알려 주는 힘을 잃음)")])

# 8번째
R(E, 7,
  {0: 'the reason the most fluent translation is always the one most faithful to the original',
   2: 'the way fluent translation hides the interpretive choices it necessarily makes',
   3: 'the greater accuracy of literal translation over idiomatic translation',
   4: 'the methods ordinary readers use to judge the quality of a translated work'},
  {0: '가장 매끄러운 번역이 언제나 원문에 가장 충실한 번역인 이유',
   2: '매끄러운 번역이 어쩔 수 없이 내리는 해석상의 선택을 감추는 방식',
   3: '직역이 자연스러운 의역보다 더 정확하다는 것',
   4: '보통의 독자가 번역 작품의 질을 판단할 때 쓰는 방법'},
  walk_sub=[("faithful(충실한), accurate(정확한)가 들어 있는 선택지가 위험합니다.", "faithful(충실한), accuracy(정확함)가 들어 있는 선택지가 위험합니다.")])

# 9번째
R(E, 8,
  {0: 'the way experts come to know more facts than beginners after many years of practice',
   1: 'methods of training experts to explain their decisions more clearly',
   4: 'expertise as a change in perception rather than a mere gain in knowledge'},
  {0: '전문가가 오랜 연습 끝에 초보자보다 더 많은 사실을 알게 되는 방식',
   1: '전문가가 자기 결정을 더 분명히 설명하도록 훈련하는 방법',
   4: '지식을 얻는 데 그치지 않는, 지각의 바뀜으로서의 전문성'},
  subs={4: [("'a different way of segmenting'이 'transforms perception'으로", "'a different way of segmenting'이 'a change in perception'으로"),
            ("'the accumulation of knowledge'가 'merely adding knowledge'로 바뀌었습니다", "'the accumulation of knowledge'가 'a mere gain in knowledge'로 바뀌었습니다")]},
  walk_sub=[("= 'transforms perception', 통념인 'accumulation of knowledge' = 'merely adding knowledge'.",
             "= 'a change in perception', 통념인 'accumulation of knowledge' = 'a mere gain in knowledge'.")])

# 10번째
R(E, 9,
  {0: 'the need to assess safety measures together with the behavior they prompt',
   1: 'the lasting fall in accidents that fitting stricter safety equipment always produces',
   3: 'the reduction of traffic fatalities by modern automatic braking systems',
   4: 'the calculation of insurance premiums for especially hazardous kinds of work'},
  {0: '안전 조치를 그것이 불러오는 행동과 함께 평가해야 할 필요성',
   1: '더 엄격한 안전 장비를 달면 언제나 따라온다는, 사고의 오래가는 줄어듦',
   3: '현대의 자동 제동 장치에 따른 교통사고 사망의 줄어듦',
   4: '특히 위험한 일의 보험료 계산'},
  walk_sub=[("'evaluating' = 'assessed'", "'evaluating' = 'assess'")])
