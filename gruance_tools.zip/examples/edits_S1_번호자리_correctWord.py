# -*- coding: utf-8 -*-
# 202번: 미뤄 둔 작은 일 두 가지 (선생님 말씀 "작은 것 한꺼번에 처리하고 23번 처리합시다")
#  ① 30번 레벨1 — 「올바른 낱말」(correctWord) 칸이 비어 있던 일곱 문항에 채워 넣음(해설이 말하는 그 낱말)
#  ② 29·30번 레벨5~9 — 번호가 묻는 낱말 바로 앞에 오도록 옮김(낱말은 한 글자도 바꾸지 않고 번호 자리만) 31문항 35곳
#  ③ 30번 레벨5 29번째 — ②를 하다가 찾은 것: 해석 한 낱말과 풀이·해설이 정답과 어긋나 있어 바로잡음
AUTO_SYNC = False
E = {}

# ---------- ① 30번 레벨1 correctWord ----------
for n, w in {13: 'slowly', 14: 'warmest', 15: 'sharp', 17: 'towards', 18: 'worst', 19: 'air', 20: 'dark'}.items():
    E[('30', '1', n)] = {'cw_new': w}

# ---------- ② 번호 자리 옮기기: (유형, 레벨, 몇째(1부터), [(옛, 새), ...]) ----------
MOVES = [
 ('29', '5', 27, [('Teachers ②therefore turn away', 'Teachers therefore ②turn away')]),
 ('29', '6', 12, [('is not ③as calmer as it appears', 'is not as ③calmer as it appears')]),
 ('29', '6', 20, [('Forecasters ⑤therefore give the dew point', 'Forecasters therefore ⑤give the dew point')]),
 ('29', '6', 24, [('which makes ⑤forecasting it a difficult task.', 'which makes forecasting it a difficult ⑤task.')]),
 ('29', '6', 28, [('moves ③as faster as the warm one', 'moves as ③faster as the warm one')]),
 ('29', '7', 14, [('and ④some of them respond to fire', 'and some of them ④respond to fire')]),
 ('29', '8', 5,  [('④because the student rather than the seat were the variable', 'because the student rather than the seat ④were the variable'),
                  ('a decision ⑤already made before', 'a decision already ⑤made before')]),
 ('29', '8', 7,  [('③To space the sessions therefore cost the learner', 'To space the sessions therefore ③cost the learner')]),
 ('29', '8', 12, [('by people ①already committed to reading them', 'by people already ①committed to reading them')]),
 ('29', '8', 17, [('warn that ③repairs by untrained owners invites accidents', 'warn that repairs by untrained owners ③invites accidents'),
                  ('a property of ⑤the materials themselves.', 'a property of the materials ⑤themselves.')]),
 ('29', '9', 10, [('a test ②correctly identifying ninety-nine percent', 'a test correctly ②identifying ninety-nine percent')]),
 ('29', '9', 19, [('cases ②therefore recording worse outcomes', 'cases therefore ②recording worse outcomes')]),
 ('29', '9', 24, [('such planets ②accordingly dominating the catalogue', 'such planets accordingly ②dominating the catalogue')]),
 ('30', '5', 2,  [('and ⑤price alone says nothing.', 'and price alone ⑤says nothing.')]),
 ('30', '5', 4,  [('The ④door is where the temperature is least stable, which is why ⑤it suits milk and eggs best.',
                   'The door is where the temperature is ④least stable, which is why it ⑤suits milk and eggs best.')]),
 ('30', '5', 6,  [('A ③long slow draught is the expensive method', 'A long slow draught is the ③expensive method')]),
 ('30', '5', 13, [('The ⑤hot setting feels more thorough and is doing the opposite.', 'The hot setting feels more thorough and is doing ⑤the opposite.')]),
 ('30', '5', 15, [('an old egg ①contains a smaller air pocket', 'an old egg contains a ①smaller air pocket')]),
 ('30', '5', 19, [('while ④heating the glass from behind works permanently', 'while heating the glass from behind works ④permanently')]),
 ('30', '5', 28, [('The ④counter is where food is safest to thaw', 'The counter is where food is ④safest to thaw')]),
 ('30', '5', 29, [('Brushing from the ①outside pushes that dust', 'Brushing from the outside ①pushes that dust')]),
 ('30', '5', 30, [('a damp ④cloth is the safest method', 'a damp cloth is the ④safest method')]),
 ('30', '6', 2,  [('the lights ②means going considerably faster than', 'the lights means going considerably ②faster than')]),
 ('30', '6', 8,  [('laws ⑤treat them differently.', 'laws treat them ⑤differently.')]),
 ('30', '6', 20, [('The join itself ⑤is the weakest point.', 'The join itself is the ⑤weakest point.')]),
 ('30', '6', 27, [('any handle that ⑤fails does so at a knot.', 'any handle that fails does so at a ⑤knot.')]),
 ('30', '7', 3,  [('refrigerator ②slows those enzymes far less than', 'refrigerator slows those enzymes ②far less than')]),
 ('30', '8', 8,  [('a hard edge ⑤report fewer incidents.', 'a hard edge report ⑤fewer incidents.')]),
 ('30', '8', 12, [('species ③shelters more species than the one it replaced, and it ④recovers more slowly',
                   'species shelters ③more species than the one it replaced, and it recovers ④more slowly')]),
 ('30', '8', 14, [('a reservoir ①is warmer and clearer', 'a reservoir is ①warmer and clearer')]),
 ('30', '8', 19, [('a heavy one ①must wait less,', 'a heavy one must ①wait less,')]),
]
for t, lv, n1, pairs in MOVES:
    E[(t, lv, n1 - 1)] = {'passage_ok': True, 'text': pairs}

# ---------- ③ 30번 레벨5 29번째: 해석·풀이·해설이 정답과 어긋나 있던 것 ----------
E[('30', '5', 28)].update({
    'ko': ('안쪽에서 솔질하면 그 먼지가 그 망 속으로 더 깊이 밀려 들어간다.', '바깥쪽에서 솔질하면 그 먼지가 그 망 속으로 더 깊이 밀려 들어간다.'),
    'walk': "②번이 문맥과 반대되는 낱말입니다. 먼지는 바깥쪽에 붙고, 바깥쪽에서 솔질하면 그 먼지가 망 속으로 더 밀려 들어간다고 했습니다. 그러니 먼지를 없애려면 반대쪽인 안쪽에서 솔질해야 합니다. 끝 문장도 안쪽에서 청소하는 것이 틀이 설계된 방식이라고 했습니다. outside가 아니라 inside여야 합니다.",
    'cn': {0: "①번은 바깥쪽에서 솔질하면 먼지가 망 속으로 '밀려 들어간다'는 뜻이므로 pushes가 알맞습니다.",
           1: "②번이 정답입니다. 바깥쪽에서 솔질하면 먼지가 더 밀려 들어간다고 했으므로, 먼지를 없애는 쪽은 outside가 아니라 inside여야 합니다."},
})
