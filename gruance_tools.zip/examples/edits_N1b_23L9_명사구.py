# -*- coding: utf-8 -*-
# 204번: 23번(주제) 레벨9 선택지를 수능식 명사구로 — 11~20번째 (선생님 승인: 202번 시범 뒤 "계속")
AUTO_SYNC = False
E = {}
from n23common import R

# 11번째
R(E, 10,
  {0: 'the same burden an ageing population places on every region and every service',
   1: 'the need for governments to prioritize family support over pension reform',
   3: 'the way treating population aging as one phenomenon distorts the policies designed for it'},
  {0: '고령화하는 인구가 모든 지역과 모든 서비스에 지우는 똑같은 부담',
   1: '정부가 연금 개혁보다 가족 지원을 앞세워야 할 필요성',
   3: '인구 고령화를 하나의 현상으로 다루는 것이 그에 맞춰 만든 정책을 어긋나게 하는 방식'})

# 12번째
R(E, 11,
  {0: 'the gathering of more and more evidence as the surest way to correct a biased historical record',
   1: 'the failure of accumulating more evidence to correct a systematically biased record',
   2: 'the destruction of a significant portion of ancient sites worldwide by modern construction'},
  {0: '증거를 더 많이 모으는 것이 치우친 역사 기록을 바로잡는 가장 확실한 길이라는 것',
   1: '증거를 더 쌓아도 체계적으로 치우친 기록을 바로잡지 못한다는 것',
   2: '현대의 건설이 세계 곳곳의 고대 유적 상당수를 파괴한 일'},
  walk_sub=[("'is not corrected' = 'does not correct'", "'is not corrected' = 'the failure … to correct'")])

# 13번째
R(E, 12,
  {0: 'ways for charities to cut administrative costs without losing staff',
   3: 'the wrong behaviour rewarded by a widely used charity metric'},
  {0: '자선 단체가 직원을 잃지 않으면서 행정비를 줄이는 방법',
   3: '널리 쓰이는 자선 단체 평가 수치가 상을 주는 잘못된 행동'},
  walk_sub=[("= 'rewards the wrong behaviour'.", "= 'the wrong behaviour rewarded'.")])

# 14번째
R(E, 13,
  {0: 'the tendency of cautious managers to overestimate the risks that their figures do not measure',
   1: 'ways of redesigning supply chains to withstand unexpected disruptions',
   2: 'the pressure of competition on firms to reduce their operating expenses',
   3: 'the benefit of scheduling slack for the working conditions of employees',
   4: 'the systematic advantage of measurable savings over unmeasured risks in organizational decisions'},
  {0: '신중한 관리자가 수치로 잡히지 않는 위험을 실제보다 크게 보는 경향',
   1: '공급망을 뜻밖의 차질에도 버티도록 다시 짜는 방법',
   2: '경쟁이 기업에 운영비를 줄이라고 가하는 압력',
   3: '일정의 여유가 직원들의 근무 여건에 주는 이로움',
   4: '조직의 결정에서 잴 수 있는 절감이 재지 못한 위험보다 늘 앞선다는 것'},
  subs={4: [("'systematically'(늘, 구조적으로)에 담겼습니다", "'systematic'(늘 그러한, 구조적인)에 담겼습니다")]},
  walk_sub=[("= 'systematically outweigh'(늘 이긴다)", "= 'the systematic advantage of … over'(늘 앞섬)")])

# 15번째
R(E, 14,
  {0: 'the reason a larger protected area always protects more marine life',
   1: 'the designated area as a poor measure of protection'},
  {0: '보호 구역이 넓을수록 언제나 더 많은 바다 생물을 보호하는 이유',
   1: '보호를 재는 잣대로는 나쁜, 지정된 넓이'},
  walk_sub=[("'the percentage of sea designated' = 'the area designated'", "'the percentage of sea designated' = 'the designated area'")])

# 16번째
R(E, 15,
  {0: 'the objective identification of invasive species from ecological data alone',
   1: 'changes in the composition of ecological communities over long time periods',
   2: 'the category of invasive species as a reflection of judgment rather than ecological description',
   3: 'the acceleration of biological exchange by human transportation networks',
   4: 'the more rapid spread of introduced organisms compared with native ones'},
  {0: '생태 자료만으로 침입종을 객관적으로 가려내는 일',
   1: '오랜 시간에 걸친 생태 공동체 구성의 변화',
   2: '생태적 묘사가 아니라 판단을 담은 것으로서의 침입종이라는 범주',
   3: '사람의 운송망이 생물의 이동을 빠르게 한 일',
   4: '토착 생물과 견주어 더 빠른, 들여온 생물의 퍼짐'})

# 17번째
R(E, 16,
  {0: 'the speed and ease alphabetical order brought to readers consulting reference works',
   1: 'the ways readers locate information in printed reference materials',
   2: 'the rise of alphabetical indexing as the standard for reference works',
   3: 'the loss of the structural claims that ordering had conveyed under alphabetical arrangement'},
  {0: '알파벳순이 참고 도서를 찾아보는 독자에게 가져다준 빠름과 쉬움',
   1: '독자가 인쇄된 참고 자료에서 정보를 찾아내는 방식들',
   2: '알파벳순 색인이 참고 도서의 표준으로 떠오른 일',
   3: '알파벳순 배열 아래에서, 순서가 전하던 구조에 관한 주장이 사라진 일'},
  walk_sub=[("'disappeared' = 'removed'", "'disappeared' = 'the loss of'")])

# 18번째 (176번에서 승인받아 넣은 simulate를 살림)
R(E, 17,
  {0: 'the automatic accountability of public institutions that publish ever more information',
   1: 'the way regulators decide which records ought to be released publicly',
   2: 'public evaluation of the trustworthiness of government agencies',
   4: 'the ability of complex disclosures to simulate accountability without producing it'},
  {0: '정보를 갈수록 더 많이 공개하는 공공 기관에 저절로 생긴다는 책임성',
   1: '규제 기관이 어떤 기록을 공개할지 정하는 방식',
   2: '정부 기관의 믿을 만함에 대한 대중의 평가',
   4: '복잡한 정보 공개가 책임성을 실제로 낳지는 못하면서 그 흉내만 내는 힘'},
  walk_sub=[("= 'disclosing complex information'", "= 'complex disclosures'")])

# 19번째
R(E, 18,
  {0: 'the use of the correlation maxim to replace rather than advance causal inquiry',
   1: 'the reason correlation should never be treated as any kind of evidence in scientific research',
   2: 'the way randomized controlled trials establish causation more reliably than observation',
   3: 'the frequent confusion of correlation with causation by researchers in published work',
   4: 'the proper way to communicate causal claims to audiences without training'},
  {0: '상관관계 격언을 인과 탐구를 나아가게 하는 데가 아니라 그것을 대신하는 데 쓰는 일',
   1: '과학 연구에서 상관관계를 어떤 증거로도 다루어서는 안 되는 이유',
   2: '무작위 대조 실험이 관찰보다 인과관계를 더 믿을 만하게 세우는 방식',
   3: '연구자들이 발표한 연구에서 상관관계와 인과관계를 자주 혼동하는 일',
   4: '인과 주장을 훈련받지 않은 청중에게 전하는 알맞은 방법'},
  subs={0: [("'A blanket appeal to the maxim'이 'invoking the correlation maxim'으로", "'A blanket appeal to the maxim'이 'the use of the correlation maxim'으로")]},
  walk_sub=[("'A blanket appeal to the maxim' = 'invoking the correlation maxim'", "'A blanket appeal to the maxim' = 'the use of the correlation maxim'")])

# 20번째
R(E, 19,
  {0: 'the tendency of larger training data to reinforce rather than remove statistical bias',
   1: 'the way enlarging a training dataset removes the statistical biases found in smaller ones',
   2: 'changes in occupational vocabulary in written sources over time',
   3: 'the handling of grammatical gender by machine translation systems across many languages',
   4: 'the lasting gap in accuracy between automatic and human translation'},
  {0: '더 많아진 학습 자료가 통계적 치우침을 없애기는커녕 더 굳히는 경향',
   1: '학습 자료를 늘리면 작은 자료에 있던 통계적 치우침이 없어지는 방식',
   2: '글로 남은 자료에서 시대에 따른 직업 관련 어휘의 변화',
   3: '여러 언어에 걸쳐 기계 번역 시스템이 문법적 성을 다루는 일',
   4: '자동 번역과 사람의 번역 사이에 여전히 남아 있는 정확성의 차이'},
  subs={0: [("'Additional text'가 'enlarging training data'로", "'Additional text'가 'larger training data'로"),
            ("'resistant to correction'이 'rather than removes'에 담겼습니다", "'resistant to correction'이 'rather than remove'에 담겼습니다")]},
  walk_sub=[("'Additional text' = 'enlarging training data', 'resistant to correction' = 'rather than removes'", "'Additional text' = 'larger training data', 'resistant to correction' = 'rather than remove'"),
            ("reinforces는 지문과 선택지에 같은 낱말로 나옵니다.", "지문의 reinforces는 선택지에 'reinforce'로 나옵니다.")])
