# 172번: 45번(내용 일치하지 않는 것) 레벨4 틀 재작성 — 30문항 전부 (선생님 승인: "셋 다, 유형마다 다른 이야기" · "30문항 전부")
#   · 정답 번호·발문 그대로. 43·44번 레벨4와 다른 이야기. 약 85~95단어(전 56)
#   · 선택지는 이 칸의 관례대로 영어 문장 5개(레벨5부터 한글). 정답 하나만 본문과 반대·어긋남
AUTO_SYNC = False
E = {}

def item(n, ans, text, ko, choices, why):
    # choices: [(영어 선택지, 해석)] 5개 / why: 정답이 본문과 어긋나는 까닭(한 문장, "~틀립니다/반대입니다" 꼴)
    assert len(choices) == 5 and len(set(c for c, k in choices)) == 5, n
    cn = []
    for k, (c, kk) in enumerate(choices):
        if k == ans: cn.append("정답입니다. '%s' (%s) — 본문과 일치하지 않습니다. %s" % (c, kk, why))
        else: cn.append("'%s' (%s) — 본문과 일치합니다." % (c, kk))
    walk = "%s 나머지 네 선택지는 모두 본문과 일치하므로 정답은 '%s'(%s)입니다." % (why, choices[ans][0], choices[ans][1])
    assert ('45', '4', n) not in E, n
    E[('45', '4', n)] = {'passage_ok': True, 'ans_ok': True, '_ans': ans,
                         'rewrite': {'text': text, 'choices': [c for c, k in choices], 'ko': ko, 'walk': walk, 'cn': cn}}

item(0, 1,
 "Hajin knocked her mother's favourite flowerpot off the balcony shelf, and it broke into seven pieces. Instead of hiding them, she spent the evening gluing the pieces together and painted every crack with a thin line of gold. The pot looked older but somehow more interesting. Her mother found it the next morning, with a new plant inside and a note which said sorry. She did not replace the pot, and it still sits on the same shelf, where the gold lines catch the afternoon sun.",
 "하진은 발코니 선반에서 어머니가 가장 아끼는 화분을 떨어뜨렸고, 화분은 일곱 조각으로 깨졌다. 조각을 숨기는 대신 그녀는 저녁 내내 조각을 붙이고 갈라진 금마다 가는 금색 선을 칠했다. 화분은 더 낡아 보였지만 어딘가 더 흥미로워졌다. 어머니는 다음 날 아침 새 식물이 심기고 미안하다는 쪽지가 붙은 화분을 발견했다. 어머니는 화분을 새것으로 바꾸지 않았고, 화분은 지금도 같은 선반에 놓여 오후 햇살에 금색 선이 반짝인다.",
 [("The pot broke into seven pieces", "화분은 일곱 조각으로 깨졌다"),
  ("Hajin hid the broken pieces from her mother", "하진은 깨진 조각을 어머니에게 숨겼다"),
  ("She painted the cracks with gold lines", "그녀는 갈라진 금을 금색 선으로 칠했다"),
  ("Her mother found a note on the pot", "어머니는 화분에서 쪽지를 발견했다"),
  ("The pot still stands on the same shelf", "화분은 지금도 같은 선반에 있다")],
 "본문에 조각을 숨기는 대신 붙였다고 나오므로, 조각을 숨겼다는 것은 반대입니다.")

item(1, 3,
 "The bell in the clock tower of Tomas's school had not rung for two years, because the rope had broken and nobody had climbed up to replace it. Tomas asked the caretaker whether he could try. The caretaker lent him a new rope and a helmet, and he went up with the boy as far as the first ladder. The rest of the way Tomas climbed alone, tied the rope through the iron ring and came down covered in dust. The bell rang at nine the next morning, and the whole school stopped to listen.",
 "토마스네 학교 시계탑의 종은 줄이 끊어졌는데 아무도 올라가 바꾸지 않아서 2년 동안 울리지 않았다. 토마스는 관리인에게 자기가 해 봐도 되는지 물었다. 관리인은 새 줄과 안전모를 빌려주고 첫 번째 사다리까지 소년과 함께 올라갔다. 나머지 길은 토마스 혼자 올라가 쇠고리에 줄을 묶고 먼지투성이가 되어 내려왔다. 종은 다음 날 아침 아홉 시에 울렸고, 학교 전체가 멈춰 서서 귀를 기울였다.",
 [("The bell had been silent for two years", "종은 2년 동안 울리지 않았다"),
  ("The caretaker lent Tomas a rope and a helmet", "관리인은 토마스에게 줄과 안전모를 빌려주었다"),
  ("Tomas went up the last part by himself", "토마스는 마지막 구간을 혼자 올라갔다"),
  ("The caretaker tied the rope to the ring", "관리인이 쇠고리에 줄을 묶었다"),
  ("The bell rang the next morning at nine", "종은 다음 날 아침 아홉 시에 울렸다")],
 "본문에 토마스가 혼자 올라가 쇠고리에 줄을 묶었다고 나오므로, 관리인이 묶었다는 것은 틀립니다.")

item(2, 2,
 "Seoyul's grandmother kept her recipes in a small notebook written entirely in Korean. When Seoyul's cousin in Canada asked for the recipe for seaweed soup, Seoyul decided to translate the whole notebook. It took her the winter holiday, because the notebook used old words that she had to look up, and because her grandmother kept adding details that were not written anywhere. She typed the English version and printed two copies. One went to Canada, and the other now lies beside the original in the kitchen drawer.",
 "서율의 할머니는 요리법을 모두 한국어로 쓴 작은 공책에 적어 두었다. 캐나다에 사는 사촌이 미역국 요리법을 물어보자, 서율은 공책 전체를 번역하기로 마음먹었다. 공책에 찾아봐야 하는 옛말이 많고, 할머니가 어디에도 적혀 있지 않은 세부 내용을 자꾸 덧붙여서 겨울 방학이 다 걸렸다. 그녀는 영어판을 타자로 쳐서 두 부를 인쇄했다. 한 부는 캐나다로 갔고, 다른 한 부는 지금 부엌 서랍에 원본과 나란히 놓여 있다.",
 [("The recipes were written only in Korean", "요리법은 한국어로만 적혀 있었다"),
  ("A cousin abroad asked for one recipe first", "외국의 사촌이 먼저 요리법 하나를 물었다"),
  ("Seoyul finished the translation in a week", "서율은 번역을 일주일 만에 끝냈다"),
  ("Her grandmother added details while she worked", "할머니는 작업 중에 세부 내용을 덧붙였다"),
  ("One printed copy stays in the kitchen drawer", "인쇄본 한 부는 부엌 서랍에 있다")],
 "본문에 번역에 겨울 방학이 다 걸렸다고 나오므로, 일주일 만에 끝냈다는 것은 틀립니다.")

item(3, 3,
 "At the spring fair Ryan won a goldfish in a plastic bag by throwing three rings onto a bottle. The bag was far too small, so on the way home he bought a glass bowl with the last of his money. A neighbour who kept tropical fish saw the bowl on the windowsill and told him that goldfish need much more space than people think. She gave him an old tank, a filter and a bag of gravel, and showed him how to change the water. The fish, which Ryan named Captain, is still alive five years later.",
 "봄 축제에서 라이언은 병에 고리 세 개를 던져 넣어 비닐봉지에 든 금붕어 한 마리를 탔다. 봉지가 너무 작아서 그는 집에 가는 길에 남은 돈을 다 털어 유리 어항을 샀다. 열대어를 기르는 이웃 아주머니가 창턱에 놓인 어항을 보고, 금붕어는 사람들 생각보다 훨씬 넓은 공간이 필요하다고 말해 주었다. 아주머니는 그에게 낡은 수조와 여과기, 자갈 한 봉지를 주고 물 가는 법을 보여 주었다. 라이언이 '캡틴'이라고 이름 붙인 그 물고기는 5년이 지난 지금도 살아 있다.",
 [("Ryan won the fish at a ring-throwing game", "라이언은 고리 던지기에서 물고기를 탔다"),
  ("He bought a glass bowl on the way home", "그는 집에 가는 길에 유리 어항을 샀다"),
  ("A neighbour said the bowl was too small", "이웃은 어항이 너무 작다고 말했다"),
  ("Ryan bought a tank and a filter himself", "라이언은 수조와 여과기를 직접 샀다"),
  ("The goldfish is still alive after five years", "금붕어는 5년이 지나도 살아 있다")],
 "본문에 이웃 아주머니가 수조와 여과기를 주었다고 나오므로, 라이언이 직접 샀다는 것은 틀립니다.")

item(4, 4,
 "The iron gate at the end of Lena's street had squeaked for as long as anyone could remember. Every neighbour who passed through it winced, but nobody did anything. One Saturday Lena borrowed a can of oil from her father's garage and spent ten minutes on the hinges. The squeak was gone. Nobody noticed for a week, because a problem that disappears is easy to miss. Then Mrs. Costa, who lived nearest the gate, worked out what had happened and left a box of biscuits on Lena's doorstep.",
 "레나네 골목 끝의 철문은 기억하는 사람이 없을 만큼 오래전부터 삐걱거렸다. 문을 지나는 이웃마다 얼굴을 찡그렸지만 아무도 손을 쓰지 않았다. 어느 토요일 레나는 아버지의 차고에서 기름통을 빌려 경첩에 10분을 들였다. 삐걱 소리가 사라졌다. 사라진 문제는 알아채기 어려워서 일주일 동안 아무도 눈치채지 못했다. 그러다 문에서 가장 가까이 사는 코스타 아주머니가 무슨 일이 있었는지 알아내고 레나네 집 문 앞에 과자 한 상자를 놓고 갔다.",
 [("The gate had squeaked for a very long time", "철문은 아주 오랫동안 삐걱거렸다"),
  ("Lena oiled the hinges on a Saturday", "레나는 토요일에 경첩에 기름을 쳤다"),
  ("The job took her about ten minutes", "그 일은 10분쯤 걸렸다"),
  ("Nobody noticed the change for a week", "일주일 동안 아무도 변화를 알아채지 못했다"),
  ("Mrs. Costa thanked Lena in person", "코스타 아주머니는 레나에게 직접 고마워했다")],
 "본문에 문 앞에 과자 상자를 놓고 갔다고 나오므로, 직접 만나 고마워했다는 것은 본문과 다릅니다.")

item(5, 2,
 "Mateo's town had no map for visitors, and tourists who got off the train often asked the same questions at the café where he worked on weekends. So he drew one himself. He walked every street with a notebook, measured the distances by counting steps and marked the places that people usually asked about: the castle, the river path and the only cash machine. The café owner printed a hundred copies. They were gone in a month, and the town hall now prints the map with Mateo's name in the corner.",
 "마테오의 동네에는 방문객을 위한 지도가 없어서, 기차에서 내린 관광객들은 그가 주말에 일하는 카페에서 똑같은 질문을 자주 했다. 그래서 그는 직접 지도를 그렸다. 공책을 들고 모든 거리를 걸으며 걸음 수로 거리를 재고, 사람들이 흔히 묻는 곳인 성과 강변 길, 하나뿐인 현금 인출기를 표시했다. 카페 주인이 백 장을 인쇄했다. 지도는 한 달 만에 동이 났고, 이제는 시청이 한쪽 구석에 마테오의 이름을 넣어 그 지도를 인쇄한다.",
 [("Tourists asked the same questions at the café", "관광객들은 카페에서 똑같은 질문을 했다"),
  ("Mateo measured distances by counting his steps", "마테오는 걸음 수로 거리를 쟀다"),
  ("The town hall printed the first hundred copies", "시청이 처음 백 장을 인쇄했다"),
  ("The map shows the only cash machine", "지도에는 하나뿐인 현금 인출기가 표시되어 있다"),
  ("The copies ran out within a month", "지도는 한 달 안에 동이 났다")],
 "본문에 처음 백 장은 카페 주인이 인쇄했다고 나오므로, 시청이 처음 백 장을 인쇄했다는 것은 틀립니다.")

item(6, 0,
 "When her friend Dabin went into hospital for a month, Hyeri decided to fold a thousand paper cranes, because her grandmother had told her that a thousand cranes could carry a wish. She folded forty a day during lunch breaks, and classmates who saw her began to fold too. By the third week there were cranes in every colour hanging from a string across the classroom. Hyeri carried them to the hospital in two large bags. Dabin hung them above her bed, and the nurses said that the room looked like a garden.",
 "친구 다빈이 한 달 동안 입원하게 되자, 혜리는 할머니에게서 종이학 천 마리가 소원을 이루어 준다는 말을 들은 적이 있어 종이학 천 마리를 접기로 했다. 그녀는 점심시간마다 하루 마흔 마리씩 접었고, 그것을 본 반 친구들도 접기 시작했다. 셋째 주가 되자 교실을 가로지른 줄에 온갖 색깔의 학이 걸려 있었다. 혜리는 큰 가방 두 개에 학을 담아 병원으로 가져갔다. 다빈은 그것을 침대 위에 걸었고, 간호사들은 병실이 정원 같다고 말했다.",
 [("Hyeri folded all the cranes by herself", "혜리는 학을 모두 혼자 접었다"),
  ("Her grandmother had told her about the wish", "할머니가 소원 이야기를 들려주었다"),
  ("She folded forty cranes a day at lunch", "그녀는 점심시간에 하루 마흔 마리를 접었다"),
  ("The cranes were carried in two large bags", "학은 큰 가방 두 개에 담겨 갔다"),
  ("Dabin hung the cranes above her bed", "다빈은 학을 침대 위에 걸었다")],
 "본문에 반 친구들도 함께 접기 시작했다고 나오므로, 혼자 다 접었다는 것은 틀립니다.")

item(7, 3,
 "Aiden's class borrowed an incubator from a farm and placed twelve eggs inside it in April. The teacher explained that the eggs had to be turned three times a day, so the students made a timetable and took turns, even at weekends. On the twenty-first day the first egg cracked during a maths lesson, and nobody did any maths after that. Nine chicks hatched in all. The class kept them for two weeks in a warm box and then returned them to the farm, where the farmer let the students visit them in June.",
 "에이든네 반은 농장에서 부화기를 빌려 4월에 달걀 열두 개를 넣었다. 선생님이 달걀을 하루 세 번 뒤집어야 한다고 설명해서, 학생들은 시간표를 만들어 주말에도 번갈아 맡았다. 21일째 되는 날 수학 시간에 첫 번째 달걀이 갈라졌고, 그 뒤로 아무도 수학을 하지 않았다. 모두 병아리 아홉 마리가 부화했다. 반은 병아리들을 따뜻한 상자에 2주 동안 기른 뒤 농장으로 돌려보냈고, 농장 주인은 6월에 학생들이 병아리를 보러 오게 해 주었다.",
 [("The incubator came from a farm", "부화기는 농장에서 빌려 왔다"),
  ("The eggs were turned three times a day", "달걀은 하루 세 번 뒤집었다"),
  ("The first egg cracked during a maths lesson", "첫 달걀은 수학 시간에 갈라졌다"),
  ("All twelve eggs hatched into chicks", "열두 개 달걀이 모두 병아리가 되었다"),
  ("The chicks went back to the farm after two weeks", "병아리는 2주 뒤 농장으로 돌아갔다")],
 "본문에 열두 개 가운데 아홉 마리가 부화했다고 나오므로, 모두 부화했다는 것은 틀립니다.")

item(8, 0,
 "Nayeon started a ten-minute radio programme that was played through the school speakers during lunch. At first she only read the weather and the day's menu, and most students did not even notice it. In the second week she began to play one song that a student had requested and to read the reason for the request aloud. Requests arrived in a box outside the office, forty in the first week alone. The programme is now fifteen minutes long, and a second student reads the sports news.",
 "나연은 점심시간에 학교 스피커로 나가는 10분짜리 라디오 방송을 시작했다. 처음에는 날씨와 그날의 급식 메뉴만 읽었고, 학생들은 대부분 방송이 있는지도 몰랐다. 둘째 주부터 그녀는 학생이 신청한 노래 한 곡을 틀고 신청 사연을 소리 내어 읽기 시작했다. 신청곡은 교무실 앞 상자에 들어왔는데, 첫 주에만 마흔 건이었다. 방송은 이제 15분으로 늘었고, 다른 학생 한 명이 스포츠 소식을 읽는다.",
 [("The programme was popular from the first day", "방송은 첫날부터 인기가 있었다"),
  ("At first Nayeon read only the weather and the menu", "처음에 나연은 날씨와 메뉴만 읽었다"),
  ("She began to read the reasons for requests aloud", "그녀는 신청 사연을 소리 내어 읽기 시작했다"),
  ("Forty requests arrived in the first week", "첫 주에 신청 마흔 건이 들어왔다"),
  ("The programme is now fifteen minutes long", "방송은 이제 15분이다")],
 "본문에 처음에는 학생들이 방송이 있는지도 몰랐다고 나오므로, 첫날부터 인기였다는 것은 반대입니다.")

item(9, 4,
 "Felix entered a photo contest whose theme was 'My Town at Dawn', and he decided to photograph the old stone bridge before anyone was on it. He set his alarm for four o'clock and carried his father's old camera through empty streets. The first morning it rained. On the second he found the light perfect, but his photographs were blurred because his hands were shaking in the cold. On the third morning he rested the camera on the wall and took one clear picture, which won second prize and was printed in the December issue of the town magazine.",
 "펠릭스는 '새벽의 우리 동네'가 주제인 사진 대회에 참가했고, 아무도 없을 때의 오래된 돌다리를 찍기로 했다. 그는 알람을 네 시에 맞추고 아버지의 낡은 사진기를 들고 텅 빈 거리를 걸어갔다. 첫째 아침에는 비가 왔다. 둘째 아침에는 빛이 완벽했지만, 추위에 손이 떨려 사진이 흐릿하게 나왔다. 셋째 아침에 그는 사진기를 담 위에 올려놓고 선명한 사진 한 장을 찍었고, 그 사진은 2등 상을 받아 동네 잡지 12월 호에 실렸다.",
 [("The contest theme was the town at dawn", "대회 주제는 새벽의 동네였다"),
  ("Felix used his father's old camera", "펠릭스는 아버지의 낡은 사진기를 썼다"),
  ("Rain spoiled the first morning", "첫째 아침은 비 때문에 못 찍었다"),
  ("His second-morning pictures were blurred", "둘째 아침 사진은 흐릿했다"),
  ("His photograph won the first prize", "그의 사진은 1등 상을 받았다")],
 "본문에 2등 상을 받았다고 나오므로, 1등 상을 받았다는 것은 틀립니다.")

item(10, 1,
 "Jiho's neighbour, Mr. Fisher, had three large dogs and a broken ankle. For six weeks Jiho walked the dogs every morning before school, one hour in the park whatever the weather. The first week was a disaster: the dogs pulled him in three directions and he arrived at school muddy. By the second week he had learned to let the strongest dog set the pace. Mr. Fisher paid him at the end of each week, but Jiho spent the money on a proper lead and gave the rest back when the ankle healed.",
 "지호의 이웃 피셔 씨는 큰 개 세 마리를 키웠는데 발목이 부러졌다. 6주 동안 지호는 매일 아침 등교 전에 날씨와 상관없이 공원에서 한 시간씩 개들을 산책시켰다. 첫 주는 엉망이었다. 개들이 세 방향으로 그를 끌어당겨 그는 진흙투성이로 학교에 도착했다. 둘째 주에는 가장 힘센 개가 속도를 정하게 두는 법을 익혔다. 피셔 씨는 매주 말에 돈을 주었지만, 지호는 그 돈으로 제대로 된 목줄을 사고 발목이 나았을 때 나머지를 돌려주었다.",
 [("Mr. Fisher could not walk his dogs himself", "피셔 씨는 개를 직접 산책시킬 수 없었다"),
  ("Jiho walked the dogs only on dry days", "지호는 비가 오지 않는 날에만 개를 산책시켰다"),
  ("The dogs pulled him in different directions at first", "처음에 개들은 그를 여러 방향으로 끌어당겼다"),
  ("He bought a proper lead with the money", "그는 그 돈으로 제대로 된 목줄을 샀다"),
  ("He returned the rest of the money later", "그는 나중에 나머지 돈을 돌려주었다")],
 "본문에 날씨와 상관없이 매일 아침 산책시켰다고 나오므로, 비가 오지 않는 날에만 했다는 것은 틀립니다.")

item(11, 4,
 "An old telephone box stood empty at the corner of Olivia's village, and the council planned to remove it. Olivia asked instead whether she could turn it into a seed library. She fitted shelves, labelled a hundred small envelopes and asked gardeners to leave spare seeds and take what they needed. The rule was simple: bring some back at the end of the season. In the first year the box was emptied twice. Now it also holds a notebook in which people write what grew well and what did not.",
 "올리비아네 마을 모퉁이에 낡은 공중전화 부스가 빈 채로 서 있었고, 의회는 그것을 치울 계획이었다. 올리비아는 대신 그것을 씨앗 도서관으로 바꿔도 되는지 물었다. 그녀는 선반을 달고 작은 봉투 백 개에 이름표를 붙인 뒤, 정원을 가꾸는 사람들에게 남는 씨앗을 두고 필요한 것을 가져가라고 했다. 규칙은 간단했다. 철이 끝나면 조금 다시 가져오라는 것이었다. 첫해에 부스는 두 번이나 비었다. 이제 그 안에는 무엇이 잘 자랐고 무엇이 안 자랐는지 사람들이 적는 공책도 있다.",
 [("The council wanted to remove the telephone box", "의회는 공중전화 부스를 치우려 했다"),
  ("Olivia put shelves inside the box", "올리비아는 부스 안에 선반을 달았다"),
  ("People were asked to bring seeds back later", "사람들은 나중에 씨앗을 다시 가져오라고 요청받았다"),
  ("The box was emptied twice in the first year", "첫해에 부스는 두 번 비었다"),
  ("The notebook records who took which seeds", "공책에는 누가 어떤 씨앗을 가져갔는지 적는다")],
 "본문에 공책에는 무엇이 잘 자랐고 안 자랐는지 적는다고 나오므로, 누가 가져갔는지 적는다는 것은 본문과 다릅니다.")

item(12, 0,
 "For his twelfth birthday Woojin asked for a microscope, and his parents bought a small second-hand one from a teacher who was retiring. The first thing Woojin looked at was a drop of pond water, which turned out to be full of tiny creatures swimming in every direction. He ran downstairs to show his sister. She looked for a long time and said nothing. The next evening she was at the desk before him, with a jar of water from the fish tank and a notebook in which she had already drawn two of the creatures.",
 "열두 번째 생일에 우진은 현미경을 사 달라고 했고, 부모님은 퇴직하는 선생님에게서 작은 중고 현미경을 샀다. 우진이 처음 본 것은 연못 물 한 방울이었는데, 사방으로 헤엄치는 작은 생물로 가득했다. 그는 아래층으로 달려 내려가 여동생에게 보여 주었다. 여동생은 오랫동안 들여다보고는 아무 말도 하지 않았다. 다음 날 저녁 여동생은 수조에서 뜬 물 한 병과 벌써 생물 두 마리를 그려 둔 공책을 들고 그보다 먼저 책상 앞에 앉아 있었다.",
 [("The microscope was bought new from a shop", "현미경은 가게에서 새것으로 샀다"),
  ("The pond water was full of tiny creatures", "연못 물은 작은 생물로 가득했다"),
  ("Woojin showed the microscope to his sister", "우진은 여동생에게 현미경을 보여 주었다"),
  ("His sister said nothing after looking", "여동생은 들여다본 뒤 아무 말도 하지 않았다"),
  ("She had drawn two creatures by the next evening", "여동생은 다음 날 저녁까지 생물 두 마리를 그렸다")],
 "본문에 퇴직하는 선생님에게서 중고로 샀다고 나오므로, 가게에서 새것으로 샀다는 것은 틀립니다.")

item(13, 4,
 "Hyunwoo found a typewriter in a box of things that his grandfather no longer wanted. Half the keys stuck, and the ribbon was dry. He cleaned every key with a toothbrush, ordered a new ribbon online and learned that you have to hit the keys much harder than on a computer. His first letter, to his grandfather, had eleven mistakes and no way to correct them. His grandfather wrote back on the same machine, with eight mistakes. The two now exchange one letter a month, and neither of them counts the mistakes any more.",
 "현우는 할아버지가 더 이상 쓰지 않는 물건 상자에서 타자기를 발견했다. 자판은 절반이 뻑뻑했고 리본은 말라 있었다. 그는 칫솔로 자판을 하나하나 닦고, 인터넷으로 새 리본을 주문하고, 컴퓨터보다 자판을 훨씬 세게 쳐야 한다는 것을 배웠다. 할아버지에게 보낸 첫 편지에는 실수가 열한 개였고 고칠 방법이 없었다. 할아버지는 같은 기계로 실수 여덟 개짜리 답장을 보냈다. 두 사람은 이제 한 달에 한 통씩 편지를 주고받고, 둘 다 더는 실수를 세지 않는다.",
 [("Half of the keys stuck at first", "처음에 자판 절반이 뻑뻑했다"),
  ("Hyunwoo cleaned the keys with a toothbrush", "현우는 칫솔로 자판을 닦았다"),
  ("His first letter had eleven mistakes", "그의 첫 편지에는 실수가 열한 개였다"),
  ("His grandfather replied on the same typewriter", "할아버지는 같은 타자기로 답장했다"),
  ("The two write to each other every week", "두 사람은 매주 편지를 주고받는다")],
 "본문에 한 달에 한 통씩 주고받는다고 나오므로, 매주 주고받는다는 것은 틀립니다.")

item(14, 0,
 "Sumin's hiking club was coming down a mountain in fog when the leader counted heads and found that one boy, Jaeho, was missing. Nobody had a phone signal. Sumin remembered that Jaeho carried a whistle, so she asked everyone to be quiet and blew hers three times. From somewhere below came three faint blasts in reply. The group followed the sound for twenty minutes and found Jaeho sitting on a rock beside a stream, with a twisted ankle but perfectly calm. He said that he had known somebody would whistle.",
 "수민의 등산 동아리가 안개 속에서 산을 내려오고 있을 때, 대장이 인원을 세다가 재호라는 남학생 한 명이 없다는 것을 알았다. 아무도 휴대전화 신호가 잡히지 않았다. 수민은 재호가 호루라기를 가지고 다닌다는 것을 떠올리고, 모두 조용히 하라고 한 뒤 자기 호루라기를 세 번 불었다. 아래쪽 어딘가에서 희미한 호루라기 소리 세 번이 답으로 들려왔다. 일행은 20분 동안 그 소리를 따라가, 발목을 삔 채 개울가 바위에 앉아 있는 재호를 찾았다. 그는 아주 침착했고, 누군가 호루라기를 불 줄 알았다고 말했다.",
 [("Sumin was the first to notice the missing boy", "수민이 없어진 아이를 가장 먼저 알아챘다"),
  ("The phones had no signal on the mountain", "산에서는 휴대전화 신호가 잡히지 않았다"),
  ("Sumin blew her whistle three times", "수민은 호루라기를 세 번 불었다"),
  ("The group followed the sound for twenty minutes", "일행은 20분 동안 소리를 따라갔다"),
  ("Jaeho had hurt his ankle on the way down", "재호는 내려오다가 발목을 다쳤다")],
 "본문에 대장이 인원을 세다가 알았다고 나오므로, 수민이 가장 먼저 알아챘다는 것은 틀립니다.")

item(15, 1,
 "The houses on Ivan's street had no numbers, and delivery drivers rang the wrong bell at least once a day. Ivan bought a tin of white paint and a brush and offered to paint a number beside every door for free. Most neighbours said yes; two preferred to buy metal numbers instead. It took him three Saturdays, because he painted each one twice. The pizza shop at the corner noticed the difference first and gave him a free pizza. The drivers now find the right door, although one of them says he misses the chats.",
 "이반네 거리의 집들에는 번지수가 없어서, 배달 기사들이 하루에 적어도 한 번은 엉뚱한 집의 초인종을 눌렀다. 이반은 흰 페인트 한 통과 붓을 사서 모든 집 문 옆에 공짜로 번호를 써 주겠다고 했다. 이웃 대부분은 좋다고 했고, 두 집은 대신 금속 번호판을 사겠다고 했다. 번호를 두 번씩 덧칠해서 토요일 세 번이 걸렸다. 모퉁이의 피자 가게가 가장 먼저 달라진 것을 알아채고 공짜 피자를 주었다. 이제 기사들은 제대로 된 문을 찾지만, 한 기사는 수다를 떨던 때가 그립다고 한다.",
 [("Delivery drivers often rang the wrong bell", "배달 기사들은 자주 엉뚱한 초인종을 눌렀다"),
  ("Every neighbour accepted Ivan's offer", "이웃 모두가 이반의 제안을 받아들였다"),
  ("Ivan painted each number twice", "이반은 번호를 두 번씩 칠했다"),
  ("The work took three Saturdays", "그 일은 토요일 세 번이 걸렸다"),
  ("The pizza shop gave him a free pizza", "피자 가게는 그에게 공짜 피자를 주었다")],
 "본문에 두 집은 금속 번호판을 사겠다고 했다고 나오므로, 모두가 받아들였다는 것은 틀립니다.")

item(16, 4,
 "Yerin's bedroom window faced the window of Mr. Adler, a retired sailor who lived across the narrow street. One winter evening he flashed his desk lamp at her three times, and she flashed back. The next day he showed her a card with the Morse code alphabet and explained that sailors had once talked between ships with lights. Yerin learned the code in a month. Now the two send short messages every night, mostly about the weather and homework, and her parents still think she is studying when her lamp blinks.",
 "예린의 방 창문은 좁은 길 건너편에 사는 은퇴한 선원 애들러 씨의 창문과 마주 보고 있었다. 어느 겨울 저녁 그가 책상 등을 세 번 깜빡이자 그녀도 깜빡여 답했다. 다음 날 그는 모스 부호 알파벳이 적힌 카드를 보여 주며, 옛날 선원들이 배와 배 사이에서 불빛으로 이야기를 나누었다고 설명했다. 예린은 한 달 만에 부호를 익혔다. 이제 두 사람은 밤마다 날씨와 숙제 이야기가 대부분인 짧은 메시지를 주고받는데, 그녀의 등이 깜빡일 때 부모님은 여전히 그녀가 공부하는 줄 안다.",
 [("Mr. Adler lived across a narrow street", "애들러 씨는 좁은 길 건너편에 살았다"),
  ("He used to be a sailor", "그는 선원이었다"),
  ("Yerin learned the code within a month", "예린은 한 달 안에 부호를 익혔다"),
  ("The messages are mostly about everyday things", "메시지는 대부분 일상적인 내용이다"),
  ("Her parents know about the night messages", "부모님은 밤의 메시지에 대해 알고 있다")],
 "본문에 부모님은 그녀가 공부하는 줄 안다고 나오므로, 메시지에 대해 알고 있다는 것은 반대입니다.")

item(17, 0,
 "Jaemin noticed that the school canteen threw away a bin of vegetable peelings every day, while the garden club paid for bags of compost. He asked the science teacher whether the peelings could be turned into compost at school. Together they built two wooden boxes behind the greenhouse and asked the cooks to keep the peelings in a separate bucket. The first box took three months to turn into dark soil. The garden club now uses its own compost from April to October and buys bags only in the driest weeks of summer.",
 "재민은 학교 급식실이 날마다 채소 껍질 한 통을 버리는데, 정원 동아리는 퇴비 포대를 돈 주고 산다는 것을 알아챘다. 그는 과학 선생님에게 껍질을 학교에서 퇴비로 만들 수 있는지 물었다. 두 사람은 함께 온실 뒤에 나무 상자 두 개를 만들고, 조리사들에게 껍질을 따로 양동이에 모아 달라고 부탁했다. 첫 상자가 검은 흙으로 바뀌는 데 석 달이 걸렸다. 이제 정원 동아리는 4월부터 10월까지 직접 만든 퇴비를 쓰고, 여름 중 가장 가문 몇 주에만 포대를 산다.",
 [("Jaemin built the compost boxes entirely on his own", "재민은 퇴비 상자를 혼자서 만들었다"),
  ("The canteen used to throw the peelings away", "급식실은 전에 껍질을 버렸다"),
  ("The cooks keep the peelings in a separate bucket", "조리사들은 껍질을 따로 양동이에 모은다"),
  ("The first box took three months to become soil", "첫 상자가 흙이 되는 데 석 달이 걸렸다"),
  ("The club still buys compost in the driest weeks", "동아리는 가장 가문 몇 주에는 여전히 퇴비를 산다")],
 "본문에 과학 선생님과 함께 상자를 만들었다고 나오므로, 혼자서 만들었다는 것은 틀립니다.")

item(18, 2,
 "Chloe's teacher paired every student with a pen pal from a school in Finland, and Chloe was given a girl named Aino. The first letters were short and polite. Then Aino wrote that the sun did not rise at all for three weeks where she lived, and Chloe wrote back a full page of questions. By spring the letters were six pages long and came with photographs, drawings and once a pressed flower. The two have never met, but they have agreed that whoever travels first will sleep on the other's floor.",
 "클로이의 선생님은 모든 학생에게 핀란드 학교의 펜팔 친구를 한 명씩 짝지어 주었고, 클로이는 아이노라는 소녀를 맡았다. 처음 편지들은 짧고 예의 바른 내용이었다. 그러다 아이노가 자기가 사는 곳에서는 3주 동안 해가 전혀 뜨지 않는다고 썼고, 클로이는 질문으로 가득한 한 장을 답장으로 보냈다. 봄이 되자 편지는 여섯 장으로 늘었고 사진과 그림, 한 번은 눌러 말린 꽃도 함께 왔다. 두 사람은 아직 만난 적이 없지만, 누구든 먼저 여행하는 쪽이 상대방 집 바닥에서 자기로 약속했다.",
 [("The teacher chose the pen pals for the students", "선생님이 학생들의 펜팔 친구를 정해 주었다"),
  ("The first letters were short", "처음 편지들은 짧았다"),
  ("Aino wrote that the sun never set in winter", "아이노는 겨울에 해가 지지 않는다고 썼다"),
  ("A pressed flower once came with a letter", "한 번은 눌러 말린 꽃이 편지와 함께 왔다"),
  ("The two girls have not met yet", "두 소녀는 아직 만나지 않았다")],
 "본문에 3주 동안 해가 전혀 뜨지 않는다고 썼다고 나오므로, 해가 지지 않는다고 썼다는 것은 반대입니다.")

item(19, 2,
 "The swing in the park near Dongha's flat had hung by one chain for most of the summer, and a sign on it said 'Do not use'. Dongha wrote to the city office, received a polite reply and waited. In September he went to the office in person with a photograph and a list of thirty children who used the park. A week later a van arrived, and two workers replaced both chains and the seat. The sign is gone, and Dongha's little sister now refuses to go home before dark.",
 "동하네 아파트 근처 공원의 그네는 여름 내내 사슬 하나에만 매달려 있었고, '사용 금지'라는 팻말이 붙어 있었다. 동하는 시청에 편지를 보내 정중한 답장을 받고 기다렸다. 9월에 그는 사진 한 장과 그 공원을 이용하는 아이 서른 명의 명단을 들고 직접 시청에 갔다. 일주일 뒤 승합차가 왔고, 작업자 두 명이 사슬 두 개와 앉는 판을 모두 바꾸었다. 팻말은 사라졌고, 동하의 여동생은 이제 어두워지기 전에는 집에 가지 않으려 한다.",
 [("The swing was broken for most of the summer", "그네는 여름 대부분 동안 고장 나 있었다"),
  ("Dongha first wrote a letter to the city office", "동하는 먼저 시청에 편지를 썼다"),
  ("The swing was repaired right after his letter", "그네는 그의 편지 직후에 고쳐졌다"),
  ("He took a list of thirty children to the office", "그는 아이 서른 명의 명단을 시청에 가져갔다"),
  ("Both chains and the seat were replaced", "사슬 두 개와 앉는 판이 모두 바뀌었다")],
 "본문에 편지에는 답장만 왔고 직접 찾아간 뒤 일주일 만에 고쳐졌다고 나오므로, 편지 직후에 고쳐졌다는 것은 틀립니다.")

item(20, 1,
 "Amelia's grandfather left her a stamp album with stamps from forty countries, some of them more than a hundred years old. She knew nothing about stamps, so she took the album to a shop in the city. The owner looked through it slowly and told her that it was worth very little as a collection, but that three of the stamps were rare. He offered to buy those three. Amelia thought about it on the bus home and decided to keep the album whole. It now sits on her desk, and she adds one stamp a month.",
 "에밀리아의 할아버지는 마흔 개 나라의 우표가 든 우표첩을 그녀에게 남겼는데, 그중에는 백 년이 넘은 것도 있었다. 그녀는 우표에 대해 아무것도 몰라서 시내의 가게에 우표첩을 가져갔다. 가게 주인은 천천히 훑어보고 나서, 수집품 전체로는 값이 거의 없지만 우표 세 장은 희귀한 것이라고 말했다. 그는 그 세 장을 사겠다고 했다. 에밀리아는 집에 가는 버스에서 생각한 끝에 우표첩을 통째로 간직하기로 했다. 우표첩은 이제 그녀의 책상 위에 놓여 있고, 그녀는 한 달에 한 장씩 우표를 더한다.",
 [("Some of the stamps were over a hundred years old", "우표 중에는 백 년이 넘은 것도 있었다"),
  ("The shop owner said the whole album was valuable", "가게 주인은 우표첩 전체가 값지다고 말했다"),
  ("He wanted to buy three of the stamps", "그는 우표 세 장을 사고 싶어 했다"),
  ("Amelia decided to keep the album whole", "에밀리아는 우표첩을 통째로 간직하기로 했다"),
  ("She adds one stamp every month", "그녀는 매달 우표 한 장을 더한다")],
 "본문에 수집품 전체로는 값이 거의 없다고 했다고 나오므로, 전체가 값지다고 했다는 것은 반대입니다.")

item(21, 2,
 "Siwoo's school had a lost-property box that was emptied once a year, and most of what went in was never claimed. When he was put in charge of it, he changed two things. Every Friday he laid everything from the box on a table in the hall for one hour, and he wrote a short list of the strangest items on the noticeboard. Teachers were not allowed to claim anything until the students had looked. By the end of the year nearly everything found its owner, and the box was emptied every week.",
 "시우네 학교에는 1년에 한 번 비우는 분실물 상자가 있었는데, 거기 들어간 물건은 대부분 주인이 찾아가지 않았다. 그 상자를 맡게 되자 그는 두 가지를 바꾸었다. 금요일마다 그는 상자 안의 모든 물건을 한 시간 동안 현관 탁자에 늘어놓았고, 가장 엉뚱한 물건들의 짧은 목록을 게시판에 써 붙였다. 선생님들은 학생들이 다 본 뒤에야 물건을 찾아갈 수 있었다. 학년 말이 되자 거의 모든 물건이 주인을 찾았고, 상자는 매주 비워졌다.",
 [("The box used to be emptied once a year", "상자는 전에 1년에 한 번 비워졌다"),
  ("Siwoo laid the items out every Friday", "시우는 금요일마다 물건을 늘어놓았다"),
  ("Teachers were allowed to look at the items first", "선생님들이 물건을 먼저 볼 수 있었다"),
  ("A list of strange items went on the noticeboard", "엉뚱한 물건 목록이 게시판에 붙었다"),
  ("Nearly everything found its owner by the year's end", "학년 말에는 거의 모든 물건이 주인을 찾았다")],
 "본문에 선생님들은 학생들이 다 본 뒤에야 찾아갈 수 있었다고 나오므로, 선생님들이 먼저 볼 수 있었다는 것은 반대입니다.")

item(22, 2,
 "Haeun lost her grandmother's ring in the river while she was washing her hands after a picnic. She searched the shallow water until dark and went home crying. Her uncle, who used a metal detector on beaches as a hobby, came the next morning. The river was fast and cold, and the detector beeped at every bottle top. After four hours it beeped differently, and he lifted the ring out of the sand with a kitchen sieve. Haeun no longer wears it near water; it stays in a box on her shelf.",
 "하은은 소풍 뒤 손을 씻다가 할머니의 반지를 강에 빠뜨렸다. 그녀는 어두워질 때까지 얕은 물을 뒤지다가 울면서 집에 갔다. 취미로 해변에서 금속 탐지기를 쓰는 삼촌이 다음 날 아침 찾아왔다. 강물은 빠르고 차가웠고, 탐지기는 병뚜껑마다 삑 소리를 냈다. 네 시간 뒤 탐지기가 다른 소리를 냈고, 삼촌은 부엌용 체로 모래 속에서 반지를 건져 올렸다. 하은은 이제 물 근처에서는 반지를 끼지 않는다. 반지는 그녀의 책꽂이 위 상자에 들어 있다.",
 [("The ring had belonged to Haeun's grandmother", "반지는 하은의 할머니 것이었다"),
  ("Haeun searched the water until it got dark", "하은은 어두워질 때까지 물속을 뒤졌다"),
  ("Her uncle found the ring within an hour", "삼촌은 한 시간 안에 반지를 찾았다"),
  ("The detector reacted to bottle tops", "탐지기는 병뚜껑에 반응했다"),
  ("The ring is now kept in a box", "반지는 이제 상자에 보관된다")],
 "본문에 네 시간 뒤에 반지를 찾았다고 나오므로, 한 시간 안에 찾았다는 것은 틀립니다.")

item(23, 1,
 "The city museum asked schools to count birds in their playgrounds for one hour on the same Saturday in January. Noah's class took part, with six students watching from different corners and one writing everything down. They counted eleven kinds of bird, including a hawk that nobody had expected and that sat on the fence for a full minute. The museum put the results of all the schools on a map. Noah's school had the most kinds in the whole city, probably because of the old trees along the back wall.",
 "시립 박물관은 학교들에 1월의 같은 토요일에 한 시간 동안 운동장의 새를 세어 달라고 부탁했다. 노아네 반이 참여했는데, 학생 여섯 명이 서로 다른 모퉁이에서 지켜보고 한 명이 모든 것을 적었다. 그들은 열한 종류의 새를 세었는데, 그중에는 아무도 예상하지 못한 매 한 마리가 있었고 매는 1분 내내 울타리에 앉아 있었다. 박물관은 모든 학교의 결과를 지도에 올렸다. 노아네 학교는 도시 전체에서 새의 종류가 가장 많았는데, 아마 뒷담을 따라 선 오래된 나무들 때문일 것이다.",
 [("All schools counted on the same Saturday", "모든 학교가 같은 토요일에 새를 세었다"),
  ("The count lasted the whole morning", "새 세기는 오전 내내 이어졌다"),
  ("One student wrote down what the others saw", "학생 한 명이 다른 학생들이 본 것을 적었다"),
  ("A hawk sat on the fence for a minute", "매 한 마리가 1분 동안 울타리에 앉아 있었다"),
  ("Noah's school recorded the most kinds of bird", "노아네 학교가 가장 많은 종류의 새를 기록했다")],
 "본문에 한 시간 동안 세었다고 나오므로, 오전 내내 이어졌다는 것은 틀립니다.")

item(24, 0,
 "Yejun's grandfather had played the accordion at village weddings for fifty years, but his fingers had grown stiff, and the instrument stayed in its case. Yejun asked to try it. The accordion was so heavy that he had to sit down, and the first sound he made sent the cat out of the room. His grandfather laughed for the first time in weeks and began to teach him one tune a Sunday. By the summer Yejun could play three wedding songs, and in August he played one at his cousin's wedding while his grandfather clapped the beat.",
 "예준의 할아버지는 50년 동안 마을 결혼식에서 아코디언을 연주했지만, 손가락이 굳어져 악기는 케이스에 들어 있기만 했다. 예준이 한번 해 보겠다고 했다. 아코디언은 너무 무거워서 그는 앉아서 들어야 했고, 처음 낸 소리에 고양이가 방에서 뛰쳐나갔다. 할아버지는 몇 주 만에 처음으로 웃고는 일요일마다 한 곡씩 가르치기 시작했다. 여름이 되자 예준은 결혼식 노래 세 곡을 연주할 수 있었고, 8월에는 사촌의 결혼식에서 할아버지가 박자에 맞춰 손뼉을 치는 가운데 한 곡을 연주했다.",
 [("The grandfather still played at weddings", "할아버지는 여전히 결혼식에서 연주했다"),
  ("Yejun had to sit down to hold the accordion", "예준은 아코디언을 들려고 앉아야 했다"),
  ("The first sound frightened the cat", "첫 소리에 고양이가 놀랐다"),
  ("The grandfather taught one tune each Sunday", "할아버지는 일요일마다 한 곡씩 가르쳤다"),
  ("Yejun played at a wedding in August", "예준은 8월에 결혼식에서 연주했다")],
 "본문에 손가락이 굳어져 악기가 케이스에 들어 있기만 했다고 나오므로, 여전히 연주했다는 것은 반대입니다.")

item(25, 3,
 "Ruby lived on the ninth floor and had no garden, so she grew herbs in pots on the kitchen windowsill. The basil died twice before she learned that it hated the cold glass at night. The mint, on the other hand, grew so fast that she had to give some to the neighbours. In winter she moved the pots to a shelf under a lamp. Her mother, who had said that nothing would grow in a flat, now asks for a handful of parsley every evening and has stopped buying herbs at the market.",
 "루비는 9층에 살아 정원이 없었기 때문에 부엌 창턱의 화분에 허브를 길렀다. 바질은 밤의 차가운 유리를 싫어한다는 것을 알기까지 두 번이나 죽었다. 반면 민트는 너무 빨리 자라서 이웃들에게 나눠 주어야 했다. 겨울에는 화분을 전등 아래 선반으로 옮겼다. 아파트에서는 아무것도 안 자란다고 했던 어머니는 이제 저녁마다 파슬리 한 줌을 달라고 하고, 시장에서 허브를 사지 않게 되었다.",
 [("Ruby grew the herbs on a windowsill", "루비는 창턱에서 허브를 길렀다"),
  ("The basil died more than once", "바질은 한 번 넘게 죽었다"),
  ("She gave some of the mint to neighbours", "그녀는 민트 일부를 이웃에게 주었다"),
  ("The pots stayed on the windowsill all winter", "화분은 겨울 내내 창턱에 있었다"),
  ("Her mother no longer buys herbs at the market", "어머니는 더 이상 시장에서 허브를 사지 않는다")],
 "본문에 겨울에는 화분을 전등 아래 선반으로 옮겼다고 나오므로, 겨울 내내 창턱에 있었다는 것은 틀립니다.")

item(26, 3,
 "Every Sunday in June, Sejin drew a huge picture in chalk on the empty car park behind the market. The first one was a whale, and it took her four hours and nine sticks of chalk. People stopped to watch, and a few children asked if they could help with the sea. The next week the whale had washed away in the rain, so she drew a forest. By the last Sunday forty people were drawing with her, and the market manager had bought the chalk. The pictures never last, which Sejin says is the point.",
 "6월의 일요일마다 세진은 시장 뒤 빈 주차장에 분필로 커다란 그림을 그렸다. 첫 그림은 고래였는데 네 시간과 분필 아홉 개가 들었다. 사람들이 멈춰 서서 구경했고, 몇몇 아이들은 바다를 그리는 것을 도와도 되는지 물었다. 다음 주에는 고래가 비에 씻겨 나가서 그녀는 숲을 그렸다. 마지막 일요일에는 마흔 명이 함께 그리고 있었고, 시장 관리인이 분필을 사 주었다. 그림은 결코 오래가지 않는데, 세진은 바로 그것이 핵심이라고 말한다.",
 [("Sejin drew on a car park behind the market", "세진은 시장 뒤 주차장에 그림을 그렸다"),
  ("The whale took four hours to draw", "고래를 그리는 데 네 시간이 걸렸다"),
  ("Rain washed the whale away", "비가 고래를 씻어 냈다"),
  ("Sejin paid for all the chalk herself", "세진은 분필 값을 모두 직접 냈다"),
  ("Forty people joined her on the last Sunday", "마지막 일요일에는 마흔 명이 함께했다")],
 "본문에 시장 관리인이 분필을 사 주었다고 나오므로, 분필 값을 모두 직접 냈다는 것은 틀립니다.")

item(27, 3,
 "On the last day of term Sam's class held an egg-drop contest from the second-floor window. Each student had one raw egg, a sheet of newspaper, some string and ten minutes to build something that would protect it. Sam wrapped his egg too loosely, and it broke on the first try. The winner was Priya, whose design was tiny but hung from a newspaper parachute. The teacher gave her a notebook as a prize, and she showed the class how she had folded the paper. Sam has kept a sheet of newspaper in his bag ever since, in case there is a second contest.",
 "학기 마지막 날 샘의 반은 2층 창문에서 달걀 떨어뜨리기 대회를 열었다. 학생마다 날달걀 하나, 신문지 한 장, 끈 약간, 그리고 달걀을 보호할 장치를 만들 시간 10분이 주어졌다. 샘은 달걀을 너무 느슨하게 싸서 첫 시도에 깨뜨렸다. 우승자는 프리야였는데, 그녀의 장치는 아주 작았지만 신문지 낙하산에 매달려 있었다. 선생님은 상으로 공책을 주었고, 그녀는 반 친구들에게 종이를 접은 방법을 보여 주었다. 샘은 그 뒤로 두 번째 대회가 있을까 봐 가방에 신문지 한 장을 넣어 다닌다.",
 [("The contest was held on the last day of term", "대회는 학기 마지막 날에 열렸다"),
  ("Each student had ten minutes to build a design", "학생마다 장치를 만들 시간 10분이 있었다"),
  ("Sam's egg broke on the first try", "샘의 달걀은 첫 시도에 깨졌다"),
  ("Priya's design was the largest in the contest", "프리야의 장치는 대회에서 가장 컸다"),
  ("Priya showed the class how she had folded the paper", "프리야는 반 친구들에게 종이 접은 방법을 보여 주었다")],
 "본문에 프리야의 장치는 아주 작았다고 나오므로, 가장 컸다는 것은 반대입니다.")

item(28, 1,
 "Hyun found that his neighbours threw away umbrellas as soon as one spoke bent, so he put a sign on his door offering to repair any umbrella for the price of a bus ticket. The first customer was his own teacher. Hyun used wire, pliers and spare parts from umbrellas that had been thrown out. Some repairs took five minutes and some took an evening. He kept a notebook of every umbrella, with the owner's name and the fault. By the end of the year it listed sixty-three umbrellas, and only two had come back a second time.",
 "현은 이웃들이 우산살 하나만 휘어도 우산을 바로 버린다는 것을 알고, 버스 요금 값에 어떤 우산이든 고쳐 준다는 안내문을 자기 집 문에 붙였다. 첫 손님은 바로 그의 선생님이었다. 현은 철사와 펜치, 버려진 우산에서 떼어 낸 부품을 썼다. 어떤 수리는 5분이면 끝났고 어떤 것은 저녁 내내 걸렸다. 그는 우산마다 주인의 이름과 고장을 적은 공책을 썼다. 연말에 공책에는 우산 예순세 개가 적혀 있었고, 두 번 다시 온 우산은 두 개뿐이었다.",
 [("Hyun charged the price of a bus ticket", "현은 버스 요금 값을 받았다"),
  ("His first customer was a neighbour", "그의 첫 손님은 이웃이었다"),
  ("He used parts from thrown-away umbrellas", "그는 버려진 우산의 부품을 썼다"),
  ("He wrote down every umbrella in a notebook", "그는 우산마다 공책에 적었다"),
  ("Only two umbrellas came back a second time", "두 번 다시 온 우산은 두 개뿐이었다")],
 "본문에 첫 손님은 그의 선생님이었다고 나오므로, 이웃이었다는 것은 틀립니다.")

item(29, 4,
 "Mia's class buried a time capsule in the school garden in their final year. Each student put in one object that fitted in a hand: a bus ticket, a broken watch, a letter to their future self. The capsule was a metal lunch box sealed with tape, and the class agreed to open it in ten years. Mia put in a photograph of the class taken on a rainy day, with everyone squinting. The spot is marked by a small stone with the year carved on it, and the head teacher keeps a copy of the map in a drawer.",
 "미아네 반은 마지막 학년에 학교 정원에 타임캡슐을 묻었다. 학생마다 손에 들어가는 물건 하나씩을 넣었는데, 버스표, 고장 난 시계, 미래의 자신에게 쓴 편지 같은 것이었다. 캡슐은 테이프로 봉한 금속 도시락통이었고, 반은 10년 뒤에 열기로 했다. 미아는 비 오는 날 찍어 모두가 눈을 찡그리고 있는 반 사진을 넣었다. 그 자리는 연도를 새긴 작은 돌로 표시되어 있고, 교장 선생님은 서랍에 지도 사본을 보관한다.",
 [("The capsule was buried in the school garden", "캡슐은 학교 정원에 묻혔다"),
  ("Each object had to fit in a hand", "물건은 손에 들어가는 크기여야 했다"),
  ("A lunch box was used as the capsule", "도시락통이 캡슐로 쓰였다"),
  ("Mia put in a photograph of the class", "미아는 반 사진을 넣었다"),
  ("The class will open the capsule in five years", "반은 5년 뒤에 캡슐을 열 것이다")],
 "본문에 10년 뒤에 열기로 했다고 나오므로, 5년 뒤에 연다는 것은 틀립니다.")

assert len(E) == 30
