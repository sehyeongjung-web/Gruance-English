# -*- coding: utf-8 -*-
# 188번: 31번(빈칸 추론) 레벨9 — 선생님 승인("전부 수정")을 받은 두 건
#   ① 28번째: 답으로도 읽힐 여지가 있던 오답의 앞뒤를 바꿈 (legislatures/courts)
#   ② 1번째: 지문이 96낱말이라 두 문장을 넣어 142낱말로 늘림(해석·풀이·해설도 맞춤)
AUTO_SYNC = False
E = {}
import sys; sys.path.insert(0, '.')
from lib import load as _load
_s, _tb, _te = _load()
def _q(x): return x.replace('«', '"').replace('»', '"')

# ---------- ① 28번째 ----------
_w = _te['31']['9'][27]['walk']; _old_trap = _w.split('【끌리는 오답】\n')[1]
assert _old_trap.startswith('「법원이 아니라 의회가 내놓은 변화」가 가장 위험합니다.'), _old_trap[:40]
assert _tb['31']['9'][27]['choices'][3] == 'changes proposed by legislatures rather than by courts'
NEW3 = 'changes proposed by courts rather than by legislatures'
_new_trap = ("「의회가 아니라 법원이 내놓은 변화」가 가장 위험합니다. 법원의 해석이 글의 한가운데 있어서 눈에 들어오지만 방향이 거꾸로입니다. "
             "법원의 해석은 개정 절차를 거치지 않으므로, 그 보호가 미치지 못하는 쪽이 바로 법원이 만드는 변화입니다. 의회는 지문에 한 번도 나오지 않습니다. "
             "그리고 글이 가른 것은 누가 바꾸느냐가 아니라 무엇이 바뀌느냐입니다. 글자냐, 그 글자가 요구하는 바냐입니다. "
             "첫 문장의 arrangements가 끝에서 돌아온다는 점도 답을 가리킵니다.")
E[('31', '9', 27)] = {
    'ch': {3: NEW3},
    'walk_sub': [(_old_trap, _new_trap)],
    'cn': {3: "'%s' (의회가 아니라 법원이 내놓은 변화) — " % NEW3 + _q(
        "법원(Courts)의 해석이 글의 한가운데 있어서 가장 끌립니다. 하지만 방향이 거꾸로입니다. 법원의 해석은 어느 걸음도 그 높은 절차를 건드리지 않습니다('no step triggers the heightened procedure'). "
        "개정 절차의 보호가 미치지 못하는 것이 바로 법원이 만드는 변화입니다. 또 의회는 지문에 나오지 않습니다. "
        "글이 가른 것은 누가 바꾸느냐가 아니라 무엇이 바뀌느냐입니다. 글자('a word')냐, 그것이 요구하는 바('what it requires')냐입니다.")},
}

# ---------- ② 1번째 ----------
ADD_EN = ("This is possible only because four players sit within a few feet of one another, close enough to catch a lifted bow or a slight nod before the note it announces. "
          "Nothing is agreed in advance about these signals; they are simply read as they occur. ")
ADD_KO = ("이것은 네 연주자가 서로 몇 피트 안쪽에 앉아 있어서, 들어 올린 활이나 가벼운 고갯짓을 그것이 알리는 음보다 먼저 알아챌 만큼 가깝기 때문에만 가능하다. "
          "이런 신호에 대해 미리 합의된 것은 아무것도 없으며, 그것들은 일어나는 대로 그저 읽힐 뿐이다. ")
_old2 = "사중주가 잘 맞는 까닭은 「서로 보기」입니다. 빈칸은 이 「보기」 쪽 말이어야 합니다."
_new2 = ("사중주가 잘 맞는 까닭은 「서로 보기」입니다. 셋째 문장이 그 조건을 말합니다. 네 사람이 들어 올린 활이나 가벼운 고갯짓을 알아챌 만큼 가까이('within a few feet of one another') 앉아 있어서입니다. "
         "빈칸은 이 「보기」 쪽 말이어야 합니다.")
E[('31', '9', 0)] = {
    'passage_ok': True,
    'text': ("before the audience hears it. An orchestra of ninety", "before the audience hears it. " + ADD_EN + "An orchestra of ninety"),
    'ko': ("바로잡힌다. 90명의 오케스트라는", "바로잡힌다. " + ADD_KO + "90명의 오케스트라는"),
    'walk_sub': [(_old2, _new2)],
    'cn': {2: "'a record of the agreed tempo' (합의된 빠르기의 기록) — "
              "tempo(빠르기)가 time(박자)과 통하고 agreed(합의된)도 지문 낱말이라 끌립니다. 그런데 빈칸 문장은 'not a source of time'으로 박자 쪽을 이미 버렸습니다. "
              "버린 쪽을 말만 바꿔 다시 넣은 선택지입니다. 또 글은 미리 합의된 것은 없다('Nothing is agreed in advance')고 했습니다. "
              "신호는 연주하는 동안 그때그때 읽히고, 실수도 그 자리에서 바로잡힙니다(a slip by one is corrected by three)."},
}
