# -*- coding: utf-8 -*-
# 199~201번: 41번(장문 — 제목) 레벨9 해설 두텁게 — 30문항 (edits_Z14a·b·c를 하나로 합친 것)
# 풀이(walk)·선택지별 해설(cn)을 새로 씀. 지문·정답·해석 변동 없음. z41common.py가 같은 폴더에 있어야 함
# 오답 하나를 바꿈: 29번째 'How Beekeepers Prevent the Loss of Their Stock' → 'How Beekeepers Recapture a Swarm That Has Left'
AUTO_SYNC = False
E = {}
from z41common import maker
mk = maker(E)

# ---------- 1번째: 배 소음은 고래의 소리를 줄이고, 소음을 멈추면 그 해는 곧바로 사라진다 ----------
mk(0, 3, [
 "1) 되풀이: 「배 소리 때문에 고래의 소리가 닿는 거리가 줄었다」는 생각이 모양을 바꿔 이어집니다. «Commercial shipping changed that range permanently.»(상업 선박이 그 폭을 영영 바꾸어 놓았다.) → «The consequence is not injury but compression.»(그 결과는 다침이 아니라 눌려 줄어듦이다.) → «A call that once carried hundreds of kilometres now carries a fraction of that»(한때 수백 킬로미터를 가던 부름이 이제는 그 한 조각만 간다). 앞의 세 문장은 고래가 왜 소리에 기대는지를 말하는 바탕 이야기입니다.",
 "2) 꺾이는 곳: 글은 두 번 꺾입니다. 넷째 문장에서 바탕 이야기가 문제로 넘어가고, 아홉째 문장에서 글쓴이가 힘주어 말하려는 것이 나옵니다. «What makes the problem unusual among environmental harms is that it leaves nothing behind.»(이 문제가 여느 환경 피해와 다른 점은 아무것도 남기지 않는다는 것이다.) 바로 뒤가 그 풀이입니다. «Reduce the noise and the ocean recovers immediately»(소음을 줄이면 바다는 곧바로 되살아난다). 남는 찌꺼기도, 천천히 다시 불어나야 할 무리도 없습니다.",
 "3) 끝 문장: «The obstacle has never been the difficulty of the remedy but the invisibility of the damage.»(걸림돌은 고치기가 어렵다는 것이 아니라 그 피해가 보이지 않는다는 것이었다.) 'never A but B' 틀입니다. 고치는 길은 이미 있습니다. 더 조용한 프로펠러가 있고, 빠르기를 조금만 줄여도 소음이 크게 줍니다. 멈추면 사라지는 해인데도 그대로인 것은, 그 해가 눈에 보이지 않기 때문입니다.",
 "4) 묶기: 제목의 콜론 앞 'Shrinking Conversations'(줄어드는 대화) = 'compression'(눌려 줄어듦), 'now carries a fraction of that'(이제는 그 한 조각만 간다). 고래가 친척을 부르는 소리를 「대화」라고 했습니다. 콜론 뒤 'A Harm That Vanishes When It Stops'(멈추면 사라지는 해) = 'it leaves nothing behind'(아무것도 남기지 않는다), 'recovers immediately'(곧바로 되살아난다). 콜론 앞이 문제, 콜론 뒤가 그 문제의 남다른 점입니다. 둘 다 글과 맞습니다."],
 "「상업 선박을 모든 연안 바다에서 금지해야 하는 까닭」이 가장 위험합니다. 배가 문제의 까닭이니 막아야 한다고 넘겨짚기 쉽습니다. 하지만 글은 금지를 말하지 않았습니다. 더 조용한 프로펠러와 빠르기 줄이기처럼 값싼 길이 있다고 했습니다. 'Must Be Banned', 'All' 같은 센 말은 글이 하지 않은 주장입니다. 「큰 바다 동물의 스트레스 호르몬 재기」도 조심합니다. 연구 하나를 그대로 옮긴 것이라, 글의 한 대목일 뿐입니다.",
 [("상업 선박을 모든 연안 바다에서 금지해야 하는 까닭", "글이 하지 않은 센 주장입니다. 배 소리가 문제의 까닭이니 금지해야 한다고 읽기 쉽습니다. 하지만 글이 내놓은 길은 금지가 아닙니다. 더 조용한 프로펠러가 이미 있고, 빠르기를 조금 줄이면('modest speed reductions') 적은 값으로 소음이 크게 준다고 했습니다. 'Must Be Banned'와 'All'은 글보다 훨씬 나아간 말입니다. 연안 바다만 따로 말한 적도 없습니다."),
  ("날개와 물살: 배 프로펠러의 공학 역사", "지문에 없는 이야기입니다. 프로펠러가 지문에 나오지만, 고래가 쓰는 소리 띠에서 소음을 내는 것으로 나올 뿐입니다. 프로펠러가 어떻게 만들어져 왔는지는 한 줄도 없습니다. 글의 눈은 배의 기계가 아니라 바닷속에서 줄어든 고래의 소리에 있습니다. 낱말만 빌려 온 제목입니다."),
  ("고래는 어떻게 그 놀라운 듣는 힘을 길러 왔는가", "글 첫머리의 바탕 이야기만 붙잡았습니다. 글은 바다 동물이 왜 소리에 기대게 되었는지를 말하며 시작하지만, 그것은 뒤에 올 문제를 알아듣게 하려는 바탕입니다. 듣는 힘이 어떻게 길러졌는지는 지문에 나오지 않습니다. 배 소음 이야기가 통째로 빠진 제목입니다."),
  ("줄어드는 바다의 대화: 멈추면 사라지는 해", "아홉째 문장 «What makes the problem unusual among environmental harms is that it leaves nothing behind.»와 여섯째 문장 «The consequence is not injury but compression.»이 근거입니다. 배 소음은 고래를 다치게 하는 것이 아니라 소리가 닿는 거리를 줄입니다. 그리고 소음을 줄이면 바다는 곧바로 되살아납니다. 'compression'이 'Shrinking Conversations'로, 'leaves nothing behind'가 'Vanishes When It Stops'로 바뀌었습니다."),
  ("큰 바다 동물의 스트레스 호르몬 재기", "글의 한 대목만 담았습니다. 배가 갑자기 멈춘 동안 고래의 호르몬을 잰 연구는 소음이 고래를 힘들게 한다는 것을 보여 주는 본보기 하나입니다. 글 전체는 호르몬을 재는 법이 아니라, 소음이 고래의 소리를 줄이고 소음을 줄이면 곧바로 되돌아온다는 이야기입니다. 본보기를 제목으로 삼은 것입니다.")])

# ---------- 2번째: 불빛이 곤충의 길 찾기를 그르치지만, 그것은 가장 값싸게 고칠 수 있는 짐이다 ----------
mk(1, 1, [
 "1) 되풀이: 이 글은 두 생각이 앞뒤로 이어집니다. 앞 절반은 「불빛이 곤충의 길 찾기를 그르친다」입니다. «their navigational systems assume that the brightest thing in the night sky is unreachably distant»(곤충의 길 찾기 체계는 밤하늘에서 가장 밝은 것이 닿을 수 없이 멀리 있다고 여긴다) → «a navigational instruction executing correctly on impossible input»(있을 수 없는 입력에 대고 제대로 돌아가는 길 찾기 명령). 뒤 절반은 「값싸게 고칠 수 있다」입니다. «how cheaply it can be adjusted»(얼마나 싸게 고칠 수 있는가) → «costs almost nothing at all»(거의 아무 값도 들지 않는다) → «saves money rather than spending it»(돈을 쓰는 것이 아니라 아낀다).",
 "2) 꺾이는 곳: 여섯째 문장입니다. «What makes light unusual on that list is how cheaply it can be adjusted.»(그 목록에서 불빛이 남다른 점은 얼마나 싸게 고칠 수 있느냐이다.) 여기서 글이 문제에서 풀이로 넘어갑니다. 뒤로 고치는 법 셋이 이어집니다. 불빛을 따뜻한 빛깔로 바꾸고, 빛이 아래로만 떨어지게 가리고, 자정 뒤에는 어둡게 합니다. 셋 다 거리를 그대로 밝히면서 돈은 덜 듭니다.",
 "3) 끝 문장: «this one is unusual in being reversible by a decision that saves money rather than spending it»(이 짐은 돈을 쓰는 것이 아니라 아끼는 결정으로 되돌릴 수 있다는 점에서 남다르다). 여섯째 문장의 'unusual'(남다른)이 끝에서 한 번 더 나옵니다. 글쓴이가 가장 힘주어 말하려는 것이 「되돌릴 수 있고, 그것도 돈이 남는다」임을 알 수 있습니다.",
 "4) 묶기: 제목은 and로 두 절반을 이었습니다. 앞쪽 'A Navigational System Betrayed by Lamps'(등불에 속은 길 찾기 체계) = 'a navigational instruction executing correctly on impossible input'. 뒤쪽 'the Cheapest Available Repair'(가장 값싼 고침) = 'how cheaply it can be adjusted', 'saves money rather than spending it'. 글의 앞 절반과 뒤 절반이 제목의 앞쪽과 뒤쪽에 하나씩 맞습니다. 긴 글의 제목은 이렇게 글의 두 절반을 다 담아야 합니다."],
 "「도시가 가로등을 아예 꺼야 하는 까닭」이 가장 위험합니다. 불빛이 문제이니 끄면 된다고 넘겨짚기 쉽습니다. 하지만 글이 내놓은 길은 끄기가 아니라 고치기입니다. 빛깔을 바꾸고, 가리고, 자정 뒤에 어둡게 합니다. 거리는 운전하는 사람에게 똑같이 잘 보인다고 했습니다. 'Entirely'(아예)는 글이 하지 않은 센 주장입니다. 「나방은 어떻게 달을 써서 길을 찾는가」도 조심합니다. 앞쪽의 본보기 하나만 담은 제목입니다.",
 [("가스에서 전기로: 유럽 도시의 거리 불빛 역사", "지문에 없는 이야기입니다. 가로등이 나오고 유럽의 연구가 나오지만, 거리 불빛이 가스에서 전기로 바뀌어 온 역사는 한 줄도 없습니다. 글은 불빛의 역사가 아니라 불빛이 곤충에게 하는 일과 그것을 값싸게 고치는 길을 말합니다. 낱말만 빌려 온 제목입니다."),
  ("등불에 속은 길 찾기 체계, 그리고 가장 값싼 고침", "첫 문장 «their navigational systems assume that the brightest thing in the night sky is unreachably distant»와 끝 문장 «reversible by a decision that saves money rather than spending it»이 근거입니다. 곤충은 가장 밝은 것이 아주 멀리 있다고 여기도록 되어 있어서, 가로등 앞에서 길 찾기가 어긋납니다. 그런데 이 짐은 불빛의 빛깔과 방향과 밝기만 바꾸어도, 돈을 아끼면서 되돌릴 수 있습니다. 'saves money'가 'the Cheapest Available Repair'로 바뀌었습니다."),
  ("나방은 어떻게 달을 써서 길을 찾는가", "글의 한 대목만 담았습니다. 달과 일정한 각을 지키며 곧게 나는 나방 이야기는 둘째 문장에 나옵니다. 그것은 가로등 앞에서 왜 길 찾기가 어긋나는지를 알려 주려는 본보기입니다. 글은 거기서 멈추지 않고 곤충이 줄어든 것, 그리고 불빛을 값싸게 고치는 길로 나아갑니다. 뒤 절반이 통째로 빠진 제목입니다."),
  ("도시가 가로등을 아예 꺼야 하는 까닭", "글이 하지 않은 센 주장입니다. 불빛이 곤충을 해친다고 했으니 꺼야 한다고 읽기 쉽습니다. 하지만 글이 든 것은 끄기가 아닙니다. 따뜻한 빛깔로 바꾸어도 거리는 똑같이 잘 보인다('leaving the street equally visible')고 했고, 가리개와 자정 뒤 어둡게 하기를 들었습니다. 'Entirely'는 글보다 훨씬 나아간 말입니다."),
  ("한꺼번에 닥친 모든 짐: 곤충이 줄어드는 까닭의 모든 것", "글보다 넓은 제목입니다. 곤충이 줄어드는 까닭이 여럿이라는 말은 지문에 있습니다. 불빛은 그 여럿 가운데 하나('one contributor among several')로 나왔습니다. 하지만 글이 다룬 것은 그 하나, 불빛뿐입니다. 'Every Pressure'와 'Complete'는 글이 다루지 않은 것까지 다 다룬 것처럼 말합니다.")])

# ---------- 3번째: 시험은 견본인데 가르침이 견본만 따라가, 견본이 과목을 대신한다 ----------
mk(2, 3, [
 "1) 되풀이: 「시험은 더 큰 것의 견본인데, 가르침이 그 견본만 따라간다」는 생각이 이어집니다. «the test was designed as a sample of something larger»(시험은 더 큰 무언가의 견본으로 짜였다) → «None of that can be examined in ninety minutes, so none of it is taught»(그 어느 것도 아흔 분 안에 시험할 수 없으니, 그 어느 것도 가르치지 않는다) → «Scores rise, and they rise honestly, while the capacity the scores were meant to represent does not.»(점수는 오르고 그것도 정직하게 오르지만, 그 점수가 나타내려던 힘은 오르지 않는다.)",
 "2) 꺾이는 곳: 셋째 문장입니다. «The difficulty begins when the test was designed as a sample of something larger.»(어려움은 시험이 더 큰 무언가의 견본으로 짜였을 때 시작된다.) 앞의 두 문장은 바탕 이야기입니다. 시험에 맞춰 가르치는 교사는 잘못하는 것이 아니라 제 할 일을 하는 것이라고 했습니다. 글은 교사를 탓하지 않습니다. 탈은 시험이 견본이라는 데서 납니다. 읽기 시험은 짧은 글로 묻지만, 읽는 힘에는 긴 책을 끝까지 붙드는 일이 들어 있습니다.",
 "3) 끝 문장: «The more durable response has been to lower the stakes rather than to improve the instrument»(더 오래가는 대응은 도구를 고치는 것이 아니라 걸린 것을 낮추는 것이었다). 시험을 넓히는 길은 값이 들어 다시 줄어든다고 했습니다. 끝 문장은 대책이고, 글의 생각을 뒤집지 않습니다. 중요한 것을 정하는 시험일수록 가르침이 그리로 휜다는 글 첫머리와 맞물립니다.",
 "4) 묶기: 콜론 앞 'the Sample Replaces the Subject'(견본이 과목을 대신한다) = 'a sample of something larger' + 'none of it is taught'. 시험에 나오는 견본만 가르치니, 견본이 과목 전체의 자리를 차지합니다. 콜론 뒤 'the Narrowing of Teaching'(좁아지는 가르침) = 'watched a curriculum narrow year by year'(교육 과정이 해마다 좁아지는 것을 지켜보았다). 'narrow'가 'Narrowing'으로 이어졌습니다."],
 "「교사가 시험 대비를 마다해야 하는 까닭」이 가장 위험합니다. 시험에 맞춘 가르침이 탈을 낳는다는 글이니 그렇게 읽기 쉽습니다. 하지만 글은 정반대로 말했습니다. 시험에 맞춰 가르치는 교사는 제 할 일을 하는 것이고, 그것을 무시하는 교사는 남의 앞날을 걸고 내기를 하는 것이라고 했습니다. 「시험장 너머: 포트폴리오 평가의 좋은 점」도 조심합니다. 포트폴리오는 지문에 나오지만, 그런 덧붙임은 값이 들어 결국 다시 줄어든다고 했습니다.",
 [("해마다 더 높이: 온 세계 시험 점수가 오른 백 년", "지문 낱말 하나를 키운 제목입니다. 점수가 오른다('Scores rise')는 말이 지문에 있습니다. 하지만 글은 점수가 올랐다는 것을 알리려는 것이 아니라, 점수가 올라도 그것이 나타내려던 힘은 오르지 않는다는 것을 말합니다. 온 세계, 백 년이라는 말도 지문에 없습니다. 글보다 넓고, 방향도 다릅니다."),
  ("시험장 너머: 포트폴리오 평가의 좋은 점", "글의 한 대목만 담았고, 방향도 어긋납니다. 포트폴리오는 시험을 넓히려는 대책 가운데 하나로 나옵니다. 하지만 글은 그런 덧붙임이 시간과 견줄 수 있음에서 값을 치러 결국 다시 줄어든다('eventually reduce it again')고 했습니다. 좋은 점을 말한 것이 아닙니다. 글이 더 오래간다고 한 대응은 걸린 것을 낮추는 쪽입니다."),
  ("흠 없이 타당한 읽기 시험을 짜는 법", "글과 방향이 다릅니다. 글은 흠 없는 시험을 짜는 법을 알려 주지 않습니다. 오히려 긴 책을 붙드는 힘 같은 것은 시험장에서 잴 수 없다고 했고, 도구를 고치는 것보다 걸린 것을 낮추는 쪽이 오래간다고 했습니다. 'Perfectly Valid'(흠 없이 타당한)는 글이 될 수 없다고 본 것입니다."),
  ("견본이 과목을 대신할 때: 시험과 좁아지는 가르침", "셋째 문장 «The difficulty begins when the test was designed as a sample of something larger.»와 일곱째 문장 «Scores rise, and they rise honestly, while the capacity the scores were meant to represent does not.»가 근거입니다. 시험은 읽는 힘의 견본만 물을 수 있는데, 학교는 시험에 나오는 것만 가르칩니다. 그래서 점수는 오르고 힘은 오르지 않습니다. 'a sample'이 'the Sample'로, 'a curriculum narrow'가 'the Narrowing of Teaching'으로 바뀌었습니다."),
  ("교사가 시험 대비를 마다해야 하는 까닭", "글과 거꾸로인 센 주장입니다. 시험에 맞춘 가르침이 탈을 낳는다고 했으니 대비를 마다하라는 글로 읽기 쉽습니다. 하지만 글은 그 재주에 힘을 쏟는 교사가 제 할 일을 하는 것('behaving responsibly')이라고 했습니다. 마다하는 교사는 학생의 앞날을 걸고 내기를 하는 셈입니다. 글이 탓한 것은 교사가 아니라 시험에 걸린 것의 크기입니다.")])

# ---------- 4번째: 건성으로 베끼기는 글의 내력을 지키고, 똑똑한 고치기는 그것을 가린다 ----------
mk(3, 4, [
 "1) 되풀이: 「베끼다 생긴 틀림이 오히려 책의 내력을 알려 준다」는 생각이 이어집니다. «Modern editors treat this drift as evidence rather than damage.»(요즘의 편집자들은 이 벗어남을 흠이 아니라 증거로 다룬다.) → 같은 틀림을 지닌 사본들은 같은 조상에서 나왔다는 풀이 → «faithful copying with occasional variation preserves history in the variations themselves»(가끔 달라지는 충실한 베끼기는 바로 그 달라진 데에 내력을 남긴다).",
 "2) 꺾이는 곳: 여섯째 문장입니다. «What complicates the picture is the scribe who understood the text.»(이야기를 꼬이게 하는 것은 글을 알아들은 베끼는 이다.) 틀림처럼 보이는 것을 알아채고 고친 사람은 물려받음의 사슬을 끊습니다. 그래서 그 사본은 본디 글에서 더 멀면서도 이웃 사본들보다 더 오래되고 더 깨끗해 보입니다('looks older and purer than its neighbours'). 편집자들이 가장 매끈한 사본을 믿지 않고 거친 사본을 아끼게 된 까닭입니다.",
 "3) 끝 문장: «the carelessness of copyists is what preserves the record, and their intelligence is what obscures it»(베끼는 이들의 건성이 기록을 지키고, 그들의 똑똑함이 기록을 가린다). 글쓴이는 이것을 'an uncomfortable inversion'(거북한 뒤집힘)이라고 불렀습니다. 건성은 나쁘고 똑똑함은 좋다는 여느 생각이 여기서는 뒤집힙니다. 글 전체가 이 한 줄로 모입니다.",
 "4) 묶기: 제목이 끝 문장을 거의 그대로 옮겼습니다. 'Careless Copying Preserves a Text'(건성으로 베끼기가 글을 지킨다) = 'the carelessness of copyists is what preserves the record'. 'Clever Correction Hides It'(똑똑한 고치기가 글을 가린다) = 'their intelligence is what obscures it'. 'carelessness'가 'Careless'로, 'intelligence'가 'Clever'로, 'obscures'가 'Hides'로 바뀌었습니다. 제목의 두 쪽이 글의 앞 절반과 뒤 절반에 하나씩 맞습니다."],
 "「생물의 진화와 문화의 전해짐을 견주기」가 조심할 선택지입니다. 사본의 내력을 되짚는 법이 진화의 갈래를 되짚는 것과 닮았다는 말이 지문에 나옵니다. 하지만 그것은 그 법이 왜 듣는지를 알려 주려는 견줌 하나입니다. 글은 진화와 문화를 견주는 글이 아닙니다. 「낱활자: 인쇄술의 발명과 손으로 베낀 책의 끝」은 첫머리의 'Before printing'(인쇄술 이전에)에서 낱말만 빌려 왔습니다. 인쇄술이 어떻게 생겼는지는 지문에 없습니다.",
 [("낱활자: 인쇄술의 발명과 손으로 베낀 책의 끝", "지문에 없는 이야기입니다. 글은 'Before printing'(인쇄술 이전에)으로 시작하지만, 그것은 손으로 베끼던 때를 말하려는 것입니다. 인쇄술이 어떻게 생겼는지, 손으로 베낀 책이 어떻게 끝났는지는 한 줄도 없습니다. 첫 낱말만 보고 고르면 걸립니다."),
  ("생물의 진화와 문화의 전해짐을 견주기", "글의 한 대목만 담았습니다. 사본의 내력을 되짚는 법이 진화의 갈래를 되짚는 것과 닮았다('resembles')는 말이 한 번 나옵니다. 그것은 달라진 데에 내력이 남는다는 것을 알아듣게 하려는 견줌입니다. 글은 그 뒤로 똑똑한 베끼는 이가 사슬을 끊는다는 이야기로 나아갑니다. 견줌 하나를 제목으로 삼은 것입니다."),
  ("정확한 요즘 번역을 만드는 규칙", "지문에 없는 이야기입니다. 글이 다루는 것은 번역이 아니라 베끼기입니다. 편집자들이 거친 사본을 아끼게 되었다는 말은 있지만, 번역을 정확하게 하는 규칙은 나오지 않습니다. 옛 글과 편집자라는 말에서 떠올린 것일 뿐입니다."),
  ("책상과 햇빛: 중세 수도원은 글 쓰는 방을 어떻게 꾸렸는가", "지문에 없는 이야기입니다. 베끼는 이들이 일하던 방이 어떠했는지, 수도원이 그것을 어떻게 꾸렸는지는 나오지 않습니다. 글의 눈은 베끼는 곳이 아니라 베끼다 생긴 틀림과 고침에 있습니다. 손으로 베낀 책에서 떠올린 그림일 뿐입니다."),
  ("왜 건성으로 베끼기는 글을 지키고 똑똑한 고치기는 글을 가리는가", "끝 문장 «the carelessness of copyists is what preserves the record, and their intelligence is what obscures it»이 근거입니다. 건성으로 베껴 생긴 틀림은 그대로 물려져 사본들의 내력을 알려 줍니다. 글을 알아듣고 고친 사람은 그 사슬을 끊어, 본디 글에서 더 먼 사본을 더 깨끗해 보이게 만듭니다. 'carelessness'가 'Careless Copying'으로, 'intelligence'가 'Clever Correction'으로, 'obscures'가 'Hides'로 바뀌었습니다.")])

# ---------- 5번째: 모두가 같은 숫자를 좇으면 경기가 서로 닮아 간다 ----------
mk(4, 0, [
 "1) 되풀이: 「모두가 같은 가장 좋은 답에 이르러 경기가 서로 닮아 간다」는 생각이 이어집니다. «every team had arrived at the same optimum»(모든 팀이 같은 가장 좋은 답에 이르렀다) → «the resulting style spread until distinguishing one side from another required more attention than casual viewers wished to give»(그렇게 생긴 방식이 퍼져서, 한 팀을 다른 팀과 가려보려면 가볍게 보는 사람이 들이고 싶은 것보다 더 눈여겨보아야 했다) → «will converge on whatever maximizes it»(그것을 가장 크게 하는 것으로 모여들 것이다).",
 "2) 꺾이는 곳: 셋째 문장입니다. «What remained was subtler and more permanent: analysis changed which actions players attempt.»(남은 것은 더 잘 보이지 않고 더 오래가는 것이었다. 분석이 선수들이 어떤 움직임을 하려 드는지를 바꾸었다.) 앞의 두 문장은 바탕 이야기입니다. 분석의 첫 이점은 모든 구단이 분석가를 두자 사라졌습니다. 글이 말하려는 것은 그 뒤에 남은 것입니다. 농구에서는 중거리 슛이 거의 사라졌습니다.",
 "3) 끝 문장: 끝의 세 문장이 한 묶음입니다. «The deeper lesson is not that measurement misled anyone.»(더 깊은 가르침은 재기가 누구를 그르쳤다는 것이 아니다.) 셈은 모두 맞았습니다. 가르침은 이것입니다. «a competitive system rewarding a single measurable quantity will converge on whatever maximizes it»(잴 수 있는 한 가지 양에 상을 주는 겨룸의 체계는 그것을 가장 크게 하는 것으로 모여든다). 그리고 재지 않은 것들, 곧 다양함과 뜻밖의 재미는 아무도 없애자고 하지 않았는데 사라집니다.",
 "4) 묶기: 콜론 앞 'Everyone Optimizes the Same Number'(모두가 같은 숫자를 가장 좋게 하려 든다) = 'a competitive system rewarding a single measurable quantity', 'every team had arrived at the same optimum'. 콜론 뒤 'the Convergence of Play'(닮아 가는 경기) = 'will converge'(모여들 것이다). 'a single measurable quantity'가 'the Same Number'로, 'converge'가 'Convergence'로 바뀌었습니다."],
 "「프로 스포츠가 자료 분석을 버려야 하는 까닭」이 가장 위험합니다. 분석 탓에 경기가 지루해졌다는 글이니 버리자는 말로 읽기 쉽습니다. 하지만 글은 재기가 누구를 그르친 것이 아니라고 했고, 셈은 모두 맞았다고 했습니다. 버리자는 말은 없습니다. 「통계는 어떻게 작은 구단에 처음으로 참된 이점을 주었는가」도 조심합니다. 분석의 첫 이점은 글 첫머리의 바탕 이야기이고, 그 이점은 사라졌다고 했습니다. 작은 구단이라는 말은 지문에 없습니다.",
 [("모두가 같은 숫자를 좇을 때: 분석과 닮아 가는 경기", "끝 문장의 «a competitive system rewarding a single measurable quantity will converge on whatever maximizes it»이 근거입니다. 분석이 가장 좋은 답을 알려 주자 모든 팀이 같은 답으로 갔고, 경기가 서로 닮아 갔습니다. 셈은 틀리지 않았습니다. 다만 재지 않은 다양함과 뜻밖의 재미가 사라졌습니다. 'a single measurable quantity'가 'the Same Number'로, 'converge'가 'the Convergence of Play'로 바뀌었습니다."),
  ("더 나은 통계 모형으로 경기 결과 미리 맞히기", "지문에 없는 이야기입니다. 통계와 분석이 나오지만, 경기 결과를 미리 맞히는 모형은 나오지 않습니다. 글에서 분석이 한 일은 결과를 맞히는 것이 아니라 선수들이 어떤 움직임을 하려 드는지를 바꾼 것입니다. 통계라는 말에서 떠올린 것일 뿐입니다."),
  ("프로 스포츠가 자료 분석을 버려야 하는 까닭", "글이 하지 않은 센 주장입니다. 분석 탓에 경기가 되풀이처럼 보이게 되었다고 했으니 버리자는 글로 읽기 쉽습니다. 하지만 글은 재기가 누구를 그르친 것이 아니고 셈은 모두 맞았다('Every calculation was correct')고 했습니다. 리그들이 한 일도 분석을 버린 것이 아니라 규칙을 손본 것입니다. 'Should Abandon'은 글에 없는 주장입니다."),
  ("통계는 어떻게 작은 구단에 처음으로 참된 이점을 주었는가", "글 첫머리의 바탕 이야기만 붙잡았습니다. 분석의 첫 승리가 남들이 못 본 것을 잰 데서 왔다는 말은 있습니다. 하지만 바로 다음 문장이 그 이점은 사라졌다('that advantage disappeared')고 했고, 글은 그 뒤에 남은 것으로 넘어갑니다. 작은 구단이라는 말도 지문에 없습니다. 글이 버리고 지나간 대목을 제목으로 삼은 것입니다."),
  ("선과 테두리: 바뀌어 가는 요즘 농구 규칙", "글의 한 대목만 담았습니다. 리그들이 규칙을 손보고 선을 옮겼다는 말이 일곱째 문장에 나옵니다. 그것은 분석이 찾은 가장 좋은 답이 팔려는 것과 같지 않다는 것을 보여 주는 한 줄입니다. 농구 규칙이 어떻게 바뀌어 왔는지는 글의 이야기가 아닙니다. 농구는 본보기이고, 축구도 같은 본보기로 나옵니다.")])

# ---------- 6번째: 범위를 「모른다는 털어놓음」에서 결정을 짜는 도구로 바꾸어 읽기 ----------
mk(5, 0, [
 "1) 되풀이: 「범위를 어떻게 받아들이게 하느냐」가 글을 꿰는 물음입니다. 한쪽은 «A range is easily read as a confession of ignorance»(범위는 모른다는 털어놓음으로 읽히기 쉽다)이고, 다른 쪽은 «the same range becomes a tool»(같은 범위가 도구가 된다)입니다. 글 첫머리도 같은 쪽입니다. 모형들이 엇갈리는 것은 부끄러운 것이 아니라 알려 주는 것('informative rather than embarrassing')이라고 했습니다.",
 "2) 꺾이는 곳: 두 번 꺾입니다. 셋째 문장이 문제를 내놓습니다. «Communicating that spread to the public has proved harder than producing it.»(그 폭을 사람들에게 알리는 일이 그것을 만들어 내는 일보다 어려웠다.) 여섯째 문장이 풀이로 넘어갑니다. «What has worked better is reframing the question.»(더 잘 들은 것은 물음의 틀을 바꾸는 것이다.) 얼마나 더워질지를 물으면 범위는 의심을 부르고, 어떤 결정이 어떤 더워짐을 더 그럴 법하게 만드는지를 물으면 같은 범위가 도구가 됩니다.",
 "3) 끝 문장: 끝에서 두 번째 문장이 글을 못 박습니다. «not the scientist asked to promise a number, but the decision that must be robust across the numbers that remain possible»(숫자 하나를 다짐하라는 말을 듣는 과학자가 아니라, 남아 있는 여러 숫자에 두루 버텨야 하는 결정). 모르는 것의 짐을 누가 지느냐가 바뀝니다. 맨 끝의 보험 회사는 그렇게 해 온 본보기 하나를 덧붙인 것입니다.",
 "4) 묶기: 'a Confession'(털어놓음) = 'a confession of ignorance'(모른다는 털어놓음). 'a Design Tool'(설계의 도구) = 'becomes a tool' + 다리를 짓는 기술자가 큰물 하나가 아니라 큰물의 분포에 맞춰 크기를 정한다는 본보기. 'Turning … From … Into'(~에서 ~으로 바꾸기) = 'reframing the question'(물음의 틀을 바꾸기). 범위는 그대로인데, 읽는 법이 바뀝니다."],
 "「여럿 대신 숫자 하나: 가운데 어림값 하나만 내자는 주장」이 가장 위험합니다. 범위가 헷갈리게 하니 숫자 하나로 말하자는 것은 그럴듯합니다. 하지만 글은 그 길이 통하지 않았다고 했습니다. 가운데 어림값만 알린 과학자들은 관측이 범위의 다른 데에 떨어지자 거짓 정밀함이라는 말을 들었습니다. 「기후 정책의 가장 큰 걸림돌인 사람들의 오해」도 조심합니다. 사람들이 범위를 잘못 읽는다는 말은 있지만, 글은 그것을 탓하는 데서 멈추지 않고 물음을 바꾸는 풀이로 나아갑니다.",
 [("범위를 「모른다는 털어놓음」에서 설계의 도구로 바꾸기", "넷째 문장 «A range is easily read as a confession of ignorance»와 일곱째 문장의 «the same range becomes a tool»이 근거입니다. 범위는 모른다는 털어놓음처럼 읽히기 쉽습니다. 하지만 물음을 「얼마나 더워질까」에서 「이 결정이 무엇을 더 그럴 법하게 만드는가」로 바꾸면, 같은 범위가 결정을 짜는 도구가 됩니다. 'a confession of ignorance'가 'a Confession'으로, 'a tool'이 'a Design Tool'로 바뀌었습니다."),
  ("짐과 여유: 기술자는 다리의 힘을 어떻게 셈하는가", "글의 한 대목만 담았습니다. 다리를 짓는 기술자가 큰물의 분포에 맞춰 크기를 정한다는 말이 나옵니다. 그것은 범위를 도구로 쓰는 일이 낯설지 않다는 것을 보여 주려는 견줌입니다. 다리의 힘을 어떻게 셈하는지는 글의 이야기가 아닙니다. 견줌 하나를 제목으로 삼은 것입니다."),
  ("기후 모형들이 구름을 두고 아직도 엇갈리는 까닭", "글 첫머리의 낱말을 빌려 왔습니다. 모형마다 구름에 대한 가정이 조금씩 다르다는 말이 둘째 문장에 있습니다. 하지만 글은 왜 엇갈리는지를 파고들지 않습니다. 엇갈려서 생긴 범위를 사람들에게 어떻게 알리느냐가 글의 물음입니다. 까닭이 아니라 알리는 법입니다."),
  ("여럿 대신 숫자 하나: 가운데 어림값 하나만 내자는 주장", "글과 거꾸로입니다. 숫자 하나로 말하면 알기 쉬우리라는 생각은 그럴듯합니다. 하지만 가운데 어림값만 알린 과학자들은 거짓 정밀함('false precision')이라는 말을 들었습니다. 글이 더 잘 들었다고 한 것은 숫자를 하나로 줄이는 것이 아니라 물음의 틀을 바꾸는 것입니다. 글이 통하지 않았다고 한 길을 제목으로 삼은 것입니다."),
  ("기후 정책의 가장 큰 걸림돌인 사람들의 오해", "글의 앞쪽 문제만 담았고, 말도 지나칩니다. 사람들이 범위를 모른다는 털어놓음으로 읽는다는 것은 지문에 있습니다. 하지만 글은 그 오해가 기후 정책의 가장 큰 걸림돌이라고 하지 않았습니다. 정책이라는 말도 나오지 않습니다. 글의 무게는 오해를 탓하는 데가 아니라, 물음을 바꾸면 같은 범위가 도구가 된다는 풀이에 있습니다.")])

# ---------- 7번째: 시키는 사람 없이 앱이 시키고, 규제는 그 안 보이는 규칙을 겨눈다 ----------
mk(6, 3, [
 "1) 되풀이: 「시키는 사람은 없는데 앱이 시킨다」는 생각이 이어집니다. «No supervisor assigns a shift or reviews performance in person.»(어떤 감독자도 일 시간을 정해 주거나 몸소 일솜씨를 살피지 않는다.) → «Direction arrives instead through the application»(시킴은 그 대신 앱을 거쳐 온다) → «presented as information rather than instruction, and together they produce compliance more reliably than a manager could»(시킴이 아니라 알림으로 내놓지만, 그것들이 모여 관리자보다 더 틀림없이 따르게 만든다).",
 "2) 꺾이는 곳: 두 군데입니다. 셋째 문장의 'instead'(그 대신)에서 겉모습(스스로 시간을 고르는 독립 계약자)이 속 모습(앱이 내리는 시킴)으로 넘어갑니다. 다섯째 문장이 남다른 점을 짚습니다. «the worker cannot see the rule being applied»(일하는 사람은 자기에게 쓰이는 규칙을 볼 수 없다). 그리고 여덟째 문장의 'not A but B'가 대응을 말합니다. «not by reclassifying the workers but by regulating the opacity itself»(일하는 사람들을 다시 가르는 것이 아니라, 그 안 보임 자체를 규제함으로써).",
 "3) 끝 문장: 끝에서 두 번째 문장이 글의 생각을 못 박습니다. «It treats the algorithm as the locus of authority rather than as a neutral tool through which authority passes»(그것은 알고리즘을, 권위가 지나가는 중립적인 도구가 아니라 권위가 놓인 자리로 다룬다). 맨 끝 문장은 그 규제가 벌써 낳은 바뀜을 덧붙입니다. 플랫폼들이 한 번도 적어 둔 적 없는 관행을 글로 밝혀야 했습니다.",
 "4) 묶기: 콜론 앞 'Authority Without Orders'(시킴 없는 권위) = 'No supervisor assigns a shift', 'information rather than instruction', 'the locus of authority'. 콜론 뒤 'Invisible Rule'(보이지 않는 규칙) = 'cannot see the rule being applied', 'the opacity'(안 보임). 'Regulating'(규제하기) = 'regulating the opacity itself'. 콜론 앞이 문제의 모습, 콜론 뒤가 그에 대한 대응입니다. 둘 다 글과 맞습니다."],
 "「플랫폼 일꾼을 직원으로 갈라야 하는 까닭」이 가장 위험합니다. 이런 글은 흔히 그 결론으로 가기 때문입니다. 하지만 이 글은 그 길을 'not'으로 버렸습니다. 여러 곳이 일하는 사람들을 다시 가르는 것이 아니라 안 보임 자체를 규제했다고 했습니다. 「배달 앱은 값을 어떻게 셈하는가」도 조심합니다. 값 매기기는 앱이 시킴을 내리는 길 가운데 하나로 나올 뿐이고, 셈하는 법은 지문에 없습니다.",
 [("배달 앱은 값을 어떻게 셈하는가", "글의 한 대목만 담았습니다. 일감에 값이 어떻게 매겨지는지는 앱이 시킴을 내리는 여러 길 가운데 하나로 나옵니다. 값을 셈하는 법은 지문에 없습니다. 오히려 일하는 사람이 그 규칙을 볼 수 없다는 것이 글의 문제입니다. 글의 눈은 셈법이 아니라 그 셈법이 시킴으로 구실한다는 데 있습니다."),
  ("플랫폼 일꾼을 직원으로 갈라야 하는 까닭", "글이 버린 쪽을 담은 센 주장입니다. 플랫폼 노동 이야기라 이 결론이 익숙합니다. 하지만 글은 여러 곳이 일하는 사람들을 다시 가르는 것이 아니라('not by reclassifying the workers') 안 보임 자체를 규제했다고 했습니다. 글쓴이는 그쪽이 이 짜임이 실제로 돌아가는 모습에 더 가깝다고 보았습니다. 'Should'는 글에 없는 주장입니다."),
  ("요즘 일하는 사람에게 좋은, 마음대로 짜는 일 시간", "글 첫머리에 나오는 겉모습만 붙잡았습니다. 스스로 시간을 고른다는 말은 회사들이 하는 말이고, 글은 곧바로 그 뒷면으로 넘어갑니다. 앱이 관리자보다 더 틀림없이 따르게 만든다고 했습니다. 마음대로 짜는 시간의 좋은 점을 말하는 글이 아닙니다. 방향이 거꾸로입니다."),
  ("시킴 없는 권위: 보이지 않는 규칙으로 하는 관리를 규제하기", "넷째 문장 «presented as information rather than instruction, and together they produce compliance more reliably than a manager could»와 여덟째 문장 «by regulating the opacity itself»가 근거입니다. 시키는 사람은 없지만, 앱이 보여 주는 일감과 값과 기다려 주는 시간이 시킴 구실을 합니다. 일하는 사람은 그 규칙을 볼 수 없습니다. 그래서 여러 곳이 그 안 보임을 규제합니다. 'information rather than instruction'이 'Authority Without Orders'로, 'the opacity'가 'Invisible Rule'로 바뀌었습니다."),
  ("다섯 관할 지역: 여러 나라 노동법 견주기", "지문 낱말 하나를 키운 제목입니다. 여러 곳('Several jurisdictions')이 대응했다는 말은 있습니다. 하지만 어느 나라인지, 몇 곳인지, 서로 어떻게 다른지는 나오지 않습니다. 다섯이라는 수도 지문에 없습니다. 글은 나라들을 견주는 글이 아니라, 대응의 방향이 무엇으로 바뀌었는지를 말하는 글입니다.")])

# ---------- 8번째: 「참된 맛」은 역사의 사실이 아니라 사회 속의 주장이다 ----------
mk(7, 2, [
 "1) 되풀이: 「본디 꼴이라는 것은 역사로는 서지 않는다」는 생각이 이어집니다. «Food historians find this assumption difficult to sustain.»(음식의 역사를 살피는 사람들은 이 가정을 지키기 어렵다고 본다.) → 참된 것으로 여겨지는 꼴은 그 음식이 처음 적히거나 찍힌 때의 꼴이고, 그것은 «a fact about documentation rather than about cooking»(요리에 관한 사실이 아니라 기록에 관한 사실)입니다 → «A cuisine defended as timeless is almost always a snapshot of one prosperous moment»(예부터 그대로라고 편드는 음식은 거의 언제나 넉넉했던 한때를 찍은 사진이다).",
 "2) 꺾이는 곳: 여섯째 문장입니다. «This does not make authenticity meaningless.»(그렇다고 참됨이라는 말이 뜻 없는 것이 되지는 않는다.) 여기서 글이 한 번 꺾입니다. 참됨을 내세우는 말은 실제로 하는 일이 있습니다. 관광을 받치고, 고장 생산자를 지키고, 이름 붙이기 다툼을 매듭짓습니다. 그리고 여덟째 문장이 그 구실의 성질을 말합니다. «they are social rather than historical»(그것들은 역사의 것이 아니라 사회의 것이다).",
 "3) 끝 문장: 끝의 두 문장이 맺습니다. 헷갈림은 정치의 일을 하는 주장을 땅에서 파낸 사실인 것처럼('as though it were an archaeological finding') 편들 때 생깁니다. 그러면 그 다툼은 이길 수 없게 됩니다. 어느 때를 본디 때로 잡든 멋대로이기 때문입니다. 맨 끝이 못 박습니다. «preserved because someone happened to be writing»(누군가 마침 적고 있었기 때문에 남았다).",
 "4) 묶기: 'a Social Claim'(사회 속의 주장) = 'Claims about it do real work'(그것을 내세우는 말은 실제로 일을 한다), 'social'. 'Rather Than a Historical Fact'(역사의 사실이 아니라) = 'rather than historical', 'a fact about documentation rather than about cooking'. 제목이 여덟째 문장의 'social rather than historical'을 거의 그대로 옮겼습니다. 참됨을 없는 것으로 치지도, 역사의 사실로 치지도 않는 것이 이 글의 자리입니다."],
 "「내려오는 조리법을 결코 바꾸어서는 안 되는 까닭」이 가장 위험합니다. 참된 맛을 다루는 글이니 지키자는 말로 읽기 쉽습니다. 하지만 글은 정반대를 보여 주었습니다. 토마토도 고추도 감자도 바깥에서 들어와 받아들여진 것입니다. 본디 꼴이 없으니 바꾸지 말라는 말도 설 수 없습니다. 'Never'는 글에 없는 센 주장입니다. 「고장 음식을 지키는 데 관광이 하는 구실」도 조심합니다. 관광은 참됨을 내세우는 말이 하는 일 넷 가운데 하나로 한 번 나올 뿐입니다.",
 [("상표에 적는 이름: 법으로 고장 생산자 지키기", "글의 한 대목만 담았습니다. 고장 생산자를 지키고 이름 붙이기 다툼을 매듭짓는다는 것은 참됨을 내세우는 말이 하는 일로 일곱째 문장에 나옵니다. 하지만 법으로 어떻게 지키는지는 지문에 없습니다. 글은 그 일들을 늘어놓고, 그것들이 역사가 아니라 사회의 일이라는 데로 나아갑니다. 본보기 하나를 제목으로 삼은 것입니다."),
  ("내려오는 조리법을 결코 바꾸어서는 안 되는 까닭", "글과 거꾸로인 센 주장입니다. 참된 맛 이야기라 조리법을 지키자는 글로 읽기 쉽습니다. 하지만 글은 음식에 본디 꼴이 있다는 가정이 지키기 어렵다고 했습니다. 지금 예부터 내려온 것으로 편드는 음식도 들어온 재료를 받아들인 것입니다. 'Never'(결코)는 글이 하지 않은 주장이고, 글의 흐름과도 부딪힙니다."),
  ("역사의 사실이 아니라 사회 속의 주장인 「참된 맛」", "여덟째 문장 «they are social rather than historical»과 다섯째 문장의 «a fact about documentation rather than about cooking»이 근거입니다. 참된 꼴이라는 것은 역사로 따지면 처음 적힌 때의 꼴일 뿐입니다. 하지만 참됨을 내세우는 말은 고장과 생산자를 지키는 실제 일을 합니다. 그 값어치는 역사가 아니라 사회에 있습니다. 'social rather than historical'이 제목에 거의 그대로 옮겨졌습니다."),
  ("고장 음식을 지키는 데 관광이 하는 구실", "글의 한 대목만 담았습니다. 관광은 참됨을 내세우는 말이 받쳐 주는 것으로 한 번 나옵니다. 관광이 고장 음식을 지킨다는 말은 지문에 없습니다. 글이 든 것은 관광, 생산자 지키기, 이름 붙이기, 공동체의 목소리 넷이고, 그것들을 묶어 「사회의 일」이라고 했습니다. 넷 가운데 하나만 붙잡은 제목입니다."),
  ("제자리를 떠난 열매: 토마토는 어떻게 아메리카에서 유럽으로 건너갔는가", "글의 한 대목만 담았습니다. 토마토가 십육 세기에 이탈리아에 닿았다는 것은 본보기 셋 가운데 하나입니다. 고추와 감자도 같은 자리에 나옵니다. 토마토가 어떻게 건너갔는지는 지문에 없습니다. 본보기는 본디 꼴이라는 가정이 서기 어렵다는 것을 보이려고 나왔습니다.")])

# ---------- 9번째: 알려지지 않은 실패는 자원자에게 한 약속을 깨는 일이다 ----------
mk(8, 3, [
 "1) 되풀이: 「실패한 시험이 알려지지 않는다」는 생각이 이어집니다. «the failures are mostly invisible»(실패는 거의 보이지 않는다) → 같은 생각이 여러 팀에서 되풀이해 시험되는데, 저마다 그것이 이미 실패했다는 것을 모릅니다 → 등록부를 만들어도 결과가 뒤에 올라오는 것은 실망스러운 몫뿐입니다 → «When a result is never reported»(결과가 끝내 알려지지 않으면).",
 "2) 꺾이는 곳: 여섯째 문장의 but입니다. «The argument for change is usually framed as scientific efficiency, but the stronger version is ethical.»(바꾸자는 주장은 흔히 과학의 효율로 짜이지만, 더 센 주장은 윤리의 것이다.) 효율은 낮추는 쪽, 윤리가 글쓴이가 힘을 싣는 쪽입니다. 시험에 나선 사람들은 제가 앎에 보탬이 된다고 알고 불편을 받아들입니다. 결과가 알려지지 않으면 그 다짐이 깨집니다. «that understanding is broken retroactively, and the volunteers have borne a cost for nothing»(그 다짐은 거슬러 올라가 깨지고, 자원자들은 헛되이 값을 치른 것이 된다).",
 "3) 끝 문장: «a negative result is not an absence of information but information somebody paid for in advance»(좋지 않은 결과는 알림이 없는 것이 아니라, 누군가 미리 값을 치른 알림이다). 'not A but B' 틀입니다. 값을 치른 「누군가」가 바로 자원자들입니다. 끝 문장도 윤리 쪽에 서 있습니다.",
 "4) 묶기: 'Unreported Failures'(알려지지 않은 실패) = 'the failures are mostly invisible', 'never reported'. 'the Broken Promise Made to Volunteers'(자원자에게 한 약속의 깨짐) = 'that understanding is broken retroactively'. 'understanding'(서로 그렇게 알고 있던 것)이 'Promise'(약속)로, 'Participants'(참가자)가 'Volunteers'로 바뀌었습니다. 제목의 앞쪽이 글의 앞 절반, 뒤쪽이 꺾인 뒤의 절반입니다."],
 "「제약 연구 예산을 더 알뜰하게 쓰기」가 가장 위험합니다. 같은 시험이 되풀이된다는 말에서 돈과 효율을 떠올리기 쉽습니다. 하지만 효율은 글이 but 앞에 두어 낮춘 쪽입니다. 더 센 주장은 윤리라고 했습니다. 「열에 아홉: 새 약의 대부분이 늦은 단계 시험에서 떨어지는 까닭」도 조심합니다. 글 첫머리의 숫자를 그대로 가져왔지만, 글은 왜 떨어지는지를 말하지 않습니다. 떨어진 것이 알려지지 않는다는 것을 말합니다.",
 [("제약 회사는 어떤 물질을 개발할지 어떻게 정하는가", "지문에 없는 이야기입니다. 회사들이 실망스러운 결과를 낼 까닭이 없다는 말은 있지만, 어떤 물질을 개발할지 어떻게 정하는지는 나오지 않습니다. 글의 눈은 개발을 정하는 일이 아니라 실패한 시험의 결과가 알려지지 않는다는 데 있습니다."),
  ("열에 아홉: 새 약의 대부분이 늦은 단계 시험에서 떨어지는 까닭", "글 첫머리의 숫자를 빌려 왔지만 물음이 다릅니다. 열에 아홉이 약국에 닿지 못한다는 말은 글의 들머리입니다. 글은 왜 떨어지는지를 파고들지 않습니다. 떨어진 것이 보이지 않고, 그래서 같은 시험이 되풀이되며 자원자가 헛되이 위험을 진다는 것을 말합니다. 늦은 단계라는 말도 지문에 없습니다."),
  ("제약 연구 예산을 더 알뜰하게 쓰기", "글이 낮춘 쪽을 제목으로 삼았습니다. 같은 시험이 수천 번 되풀이된다고 했으니 효율과 돈 이야기로 읽기 쉽습니다. 하지만 글은 그 주장이 흔히 효율로 짜이지만 더 센 것은 윤리('the stronger version is ethical')라고 했습니다. 예산이라는 말도 지문에 없습니다. but 앞쪽만 붙잡은 제목입니다."),
  ("알려지지 않은 실패, 그리고 자원자에게 한 약속의 깨짐", "여섯째 문장 «the stronger version is ethical»과 여덟째 문장 «When a result is never reported, that understanding is broken retroactively, and the volunteers have borne a cost for nothing.»이 근거입니다. 실패한 시험의 결과가 알려지지 않으면, 앎에 보탬이 된다고 알고 나선 자원자들과의 다짐이 깨집니다. 'never reported'가 'Unreported'로, 'that understanding is broken'이 'the Broken Promise'로 바뀌었습니다."),
  ("모든 시험을 적어 두기: 임상 시험 등록부의 짜임과 굴림", "글의 한 대목만 담았습니다. 시험을 시작하기 전에 적어 두게 하는 등록부는 다섯째 문장에 나옵니다. 하지만 그것은 문제를 풀려고 들인 길 하나이고, 결과가 뒤에 올라오지 않으면 듣지 않는다고 했습니다. 등록부를 어떻게 짜고 굴리는지는 지문에 없습니다. 글은 거기서 윤리의 물음으로 나아갑니다.")])

# ---------- 10번째: 걸음마다 스스로 한 거래인데, 모이면 아무도 고르지 않은 결과가 된다 ----------
mk(9, 2, [
 "1) 되풀이: 「걸음 하나하나는 스스로 한 거래인데, 모아 놓으면 아무도 고르지 않은 결과가 된다」는 생각이 이어집니다. «every individual step involves a voluntary transaction between willing parties»(걸음 하나하나가, 하겠다는 두 쪽 사이의 스스로 한 거래다) → «No one is expelled.»(아무도 쫓겨나지 않는다.) → «this produces a transformation that nobody chose and few residents wanted»(이것이 아무도 고르지 않았고 사는 사람 거의 누구도 바라지 않은 바뀜을 낳는다).",
 "2) 꺾이는 곳: 셋째 문장입니다. «What makes the process politically intractable is that every individual step involves a voluntary transaction between willing parties.»(이 과정을 정치로 다루기 어렵게 하는 것은, 걸음 하나하나가 하겠다는 두 쪽 사이의 스스로 한 거래라는 점이다.) 앞의 두 문장은 바탕 이야기입니다. 싼 집세가 예술가와 작은 가게를 부르고, 그들이 동네를 좋게 만들고, 눈길이 집세를 올리고, 그들이 떠납니다. 글이 말하려는 것은 그 얼개가 아니라, 그것을 왜 막기 어려운가입니다.",
 "3) 끝 문장: 끝의 두 문장이 맺습니다. «the outcome can be shaped only before it becomes visible»(그 결과는 눈에 보이게 되기 전에만 손댈 수 있다). 동네가 바뀌고 있다고 알아볼 때쯤이면 끼어드는 값도 다른 모든 것과 함께 올라 있습니다. 누가 정한 일이 아니어서, 막을 때를 잡기도 어렵습니다. 아무도 고르지 않은 결과라는 생각이 끝까지 이어집니다.",
 "4) 묶기: 'Voluntary Transactions'(스스로 한 거래들) = 'a voluntary transaction between willing parties'. 지문 낱말 그대로입니다. 'an Outcome Nobody Selected'(아무도 고르지 않은 결과) = 'a transformation that nobody chose'(아무도 고르지 않은 바뀜). 'chose'가 'Selected'로, 'transformation'이 'Outcome'으로 바뀌었습니다. 끝쪽 문장에도 'the outcome'이 나옵니다. and가 두 쪽을 이어, 「스스로 한 거래」와 「아무도 고르지 않은 결과」의 어긋남을 그대로 보여 줍니다."],
 "「치솟는 도시 집세가 예술가 탓인 까닭」이 가장 위험합니다. 예술가가 와서 동네가 좋아지고 집세가 오른다는 얼개만 보면 그렇게 읽힙니다. 하지만 글은 누구도 탓하지 않습니다. 걸음마다 스스로 한 거래이고, 예술가들은 오히려 가장 먼저 떠나는 사람들입니다. 「집세 묶기 법의 모든 것」, 역사 지구, 토지 신탁을 담은 제목들은 모두 가운데의 정책 셋 가운데 하나씩만 붙잡았습니다. 글은 그 셋의 성적이 엇갈린다고 했을 뿐입니다.",
 [("치솟는 도시 집세가 예술가 탓인 까닭", "글이 하지 않은 탓하기입니다. 예술가들이 동네를 좋게 만들었고 그 뒤에 집세가 올랐다는 얼개는 지문에 있습니다. 하지만 글은 누구에게도 책임을 묻지 않았습니다. 걸음마다 스스로 한 거래이고, 그 바뀜은 아무도 고르지 않았다고 했습니다. 예술가들은 오른 집세를 못 내고 가장 먼저 떠나는('the first to leave') 쪽입니다."),
  ("제자리에 붙든 겉모습: 역사 지구는 어떻게 유산을 지키는가", "글의 한 대목만 담았고, 방향도 어긋납니다. 역사 지구로 정하는 것은 정책 셋 가운데 하나로 나옵니다. 하지만 글은 그것이 동네의 겉모습을 얼려 둘 뿐 거기 사는 누구도 지켜 주지 못한다('without protecting anyone living in it')고 했습니다. 유산을 어떻게 지키는지를 말하는 글이 아닙니다."),
  ("스스로 한 거래들, 그리고 아무도 고르지 않은 결과", "셋째 문장의 «every individual step involves a voluntary transaction between willing parties»와 다섯째 문장의 «a transformation that nobody chose and few residents wanted»가 근거입니다. 집주인이 세를 올리고, 세 든 사람이 다시 맺지 않고, 새 사람이 들어옵니다. 하나하나는 스스로 한 거래인데, 수백 번 되풀이되면 아무도 고르지 않은 바뀜이 됩니다. 'nobody chose'가 'Nobody Selected'로 바뀌었습니다."),
  ("집세 묶기 법의 모든 것", "글의 한 대목만 담았습니다. 집세 묶기는 정책 셋 가운데 하나로 한 문장 나옵니다. 그것도 어떤 세입은 지켜 주지만 다른 데의 짐을 덜어 줄 집을 줄인다는 엇갈린 성적으로 나옵니다. 그 법을 낱낱이 알려 주는 글이 아닙니다. 'Complete Guide'는 글이 하지 않은 일입니다."),
  ("시장에서 빠진 땅: 빠르게 자라는 공동체 토지 신탁", "글의 한 대목만 담았고, 사실도 어긋납니다. 공동체 토지 신탁은 증거가 가장 센 정책으로 나옵니다. 하지만 글은 그것의 크기가 가장 작다('the smallest scale')고 했습니다. 값이 오르는 바로 그때 돈이 있어야 하기 때문입니다. 'Rapid Growth'(빠르게 자람)는 지문과 거꾸로입니다.")])

# ---------- 11번째: 앞날의 기술이 지금의 결정을 슬그머니 눈감아 준다 ----------
mk(10, 0, [
 "1) 되풀이: 「앞날에 없앨 수 있다는 다짐이 지금의 결정을 무르게 한다」는 생각이 이어집니다. «their objection concerns what the promise of removal does to decisions being made now»(그들의 반대는 없애 주겠다는 다짐이 지금 내리는 결정에 무슨 일을 하느냐에 관한 것이다) → «the case for reducing emissions today weakens»(오늘 내보내는 양을 줄여야 한다는 주장이 약해진다) → «how a possible future technology alters present behaviour»(있을 수도 있는 앞날의 기술이 지금의 행동을 어떻게 바꾸는가).",
 "2) 꺾이는 곳: 넷째 문장입니다. «Critics rarely dispute the chemistry»(비판하는 사람들은 그 화학을 두고 다투는 일이 드물다). 앞의 세 문장은 바탕 이야기입니다. 공기에서 이산화탄소를 없애는 기술은 듣지만 비싸고 느리고 작습니다. 편드는 쪽은 모든 기술이 그렇게 시작한다고 합니다. 글은 기술이 되느냐 안 되느냐에서, 그 다짐이 지금 무슨 일을 하느냐로 물음을 옮깁니다. 여섯째 문장이 못을 박습니다. 이것은 공학이 아니라 제도에 관한 물음입니다.",
 "3) 끝 문장: 끝의 두 문장이 풀이를 내놓습니다. 두 장부를 아예 따로 두어, 없애기로는 채울 수 없는 줄이기 목표를 세우자는 것입니다. 그래야 «capture becomes an addition to the effort rather than a substitute for it»(걸러 내기가 그 노력을 대신하는 것이 아니라 거기에 보태는 것이 된다). 버리자는 것이 아니라, 줄이기를 대신하지 못하게 하자는 것입니다. 글의 걱정이 끝까지 이어집니다.",
 "4) 묶기: 'A Future Technology'(앞날의 기술) = 'a possible future technology'. 'the Present Decisions'(지금의 결정들) = 'decisions being made now', 'present behaviour'. 'It Quietly Excuses'(그것이 슬그머니 눈감아 주는) = 'the case for reducing emissions today weakens'. 여러 나라의 계획에서 뒤쪽 십 년들에 적어 넣은 없애기가 지금의 정책이 메우지 못한 틈을 채우고 있다는 여덟째 문장이 그 모습입니다."],
 "「탄소 없애기를 쓸 수 없는 것으로 버려야 하는 까닭」이 가장 위험합니다. 글이 그 기술을 걱정하니 버리자는 말로 읽기 쉽습니다. 하지만 글은 첫 문장에서 그 기술이 듣는다고 했고, 끝에서는 줄이기에 보태는 것으로 쓰자고 했습니다. 'Should Be Abandoned'는 글이 하지 않은 센 주장입니다. 「공기에서 바로 걸러 내기는 어떻게 이산화탄소를 없애는가」도 조심합니다. 글은 그 화학을 다투지 않는다고 하고 곧바로 다른 물음으로 넘어갔습니다. 없애는 방법은 지문에 없습니다.",
 [("앞날의 기술, 그리고 그것이 슬그머니 눈감아 주는 지금의 결정들", "여섯째 문장 «how a possible future technology alters present behaviour»와 다섯째 문장 «the case for reducing emissions today weakens»가 근거입니다. 앞날에 걸러 낼 수 있다고 하면 오늘 줄여야 할 까닭이 약해집니다. 글의 물음은 그 기술이 되느냐가 아니라, 그 다짐이 지금의 결정을 어떻게 바꾸느냐입니다. 'a possible future technology'가 'A Future Technology'로, 'present behaviour'가 'the Present Decisions'로 바뀌었습니다."),
  ("해마다 더 싸게: 내려가는 환경 기술의 값", "글의 한 대목만 담았고, 글보다 넓습니다. 일찍 써 보아야 값이 내린다는 것은 편드는 쪽의 말로 한 번 나옵니다. 글은 그 말을 받아 적었을 뿐, 값이 내려가고 있다고 하지 않았습니다. 오히려 비싸고 느리고 작다고 했습니다. 환경 기술 전체를 말한 적도 없습니다. 글이 지나간 한 줄을 제목으로 삼은 것입니다."),
  ("공기에서 바로 걸러 내기는 어떻게 이산화탄소를 없애는가", "지문에 없는 이야기입니다. 그 기술이 듣는다는 말은 있지만, 어떻게 없애는지는 한 줄도 없습니다. 글은 비판하는 사람들이 그 화학을 다투지 않는다('rarely dispute the chemistry')고 하고, 물음을 제도 쪽으로 옮겼습니다. 방법을 알려 주는 글이 아닙니다."),
  ("종이 위의 길: 대륙마다 견주어 본 나라별 기후 계획", "글의 한 대목만 담았습니다. 여러 나라가 뒤쪽 십 년들에 큰 없애기를 적어 넣은 계획을 냈다는 말이 나옵니다. 그것은 걱정이 근거 있음을 보이는 증거로 나왔습니다. 나라들을 서로 견주거나 대륙별로 나눈 적은 없습니다. 증거 하나를 제목으로 삼은 것입니다."),
  ("탄소 없애기를 쓸 수 없는 것으로 버려야 하는 까닭", "글이 하지 않은 센 주장입니다. 글이 그 기술이 낳는 탈을 말하니 버리자는 글로 읽기 쉽습니다. 하지만 글은 그 기술이 듣는다고 했고, 끝에서는 걸러 내기가 줄이기에 보태는 것('an addition to the effort')이 되게 하자고 했습니다. 버리는 것이 아니라 장부를 따로 두는 것입니다. 'Abandoned'와 'Unworkable'은 지문과 어긋납니다.")])

# ---------- 12번째: 어떤 것은 멈춤으로써만 지켜지고, 모으기가 모은 것을 바꾼다 ----------
mk(11, 2, [
 "1) 되풀이: 「모으는 일이 모은 것을 바꾸었다」는 생각이 이어집니다. «how much the act of collection would change the thing collected»(모으는 일이 모은 것을 얼마나 바꾸어 놓을지) → «became fixed at the moment it was recorded»(녹음된 그때 굳어 버렸다) → «captured a living practice by converting it into an object»(살아 있는 관행을 물건으로 바꿈으로써 붙잡았다). 수십 가지로 불리던 노래가 한 가지로 굳었습니다.",
 "2) 꺾이는 곳: 둘째 문장입니다. «What they did not anticipate was how much the act of collection would change the thing collected.»(그들이 내다보지 못한 것은 모으는 일이 모은 것을 얼마나 바꾸어 놓을지였다.) 첫 문장은 바탕입니다. 모으는 사람들은 사라져 가는 노래를 지킨다고 믿었고, 많은 경우 그랬습니다. 일곱째 문장에서 한 번 더 꺾입니다. «None of this makes the recordings less valuable.»(이 가운데 어느 것도 그 녹음의 값어치를 줄이지 않는다.) 탓하는 글이 아닙니다.",
 "3) 끝 문장: 끝에서 두 번째 문장이 글을 한 줄로 묶습니다. «certain things can be preserved only by being stopped, and what is preserved is therefore never quite what was there»(어떤 것은 멈춤으로써만 지킬 수 있고, 그래서 지켜진 것은 거기 있던 것과 꼭 같지는 않다). 글쓴이는 이것을 'The paradox'(어긋나 보이는 참)라고 불렀습니다. 맨 끝 문장은 그 녹음을 읽는 법을 덧붙입니다.",
 "4) 묶기: 콜론 앞 'Preserved by Being Stopped'(멈춤으로써 지켜지다) = 'can be preserved only by being stopped'. 지문을 거의 그대로 옮겼습니다. 콜론 뒤 'What Collection Did'(모으기가 한 일) = 'the act of collection would change the thing collected'. 'a Living Tradition'(살아 있는 전통) = 'a living practice'. 콜론 앞이 끝의 맺음, 콜론 뒤가 글 전체의 이야기입니다."],
 "「민요가 유럽 시골에서 사라진 까닭」이 가장 위험합니다. 첫 문장의 'about to vanish'(곧 사라질)에서 사라짐 이야기로 읽기 쉽습니다. 하지만 글은 노래가 왜 사라졌는지를 말하지 않습니다. 지키려고 모은 일이 그 노래를 어떻게 바꾸었는지를 말합니다. 「요즘 가수들은 내려오는 노래를 어떻게 배우는가」도 조심합니다. 뒷날의 가수들이 이웃이 아니라 자료관에서 배웠다는 한 문장만 붙잡은 제목입니다.",
 [("요즘 가수들은 내려오는 노래를 어떻게 배우는가", "글의 한 대목만 담았습니다. 뒷날의 가수들이 이웃이 아니라 자료관에서 노래를 배웠다는 말이 넷째 문장에 나옵니다. 그것은 녹음이 노래를 한 가지로 굳혔다는 것을 보여 주는 결과 하나입니다. 가수들이 배우는 법을 알려 주는 글이 아닙니다."),
  ("밀랍과 쇠줄: 들고 다니는 초기 녹음 기술의 발달", "지문에 없는 이야기입니다. 녹음 장비를 들고 시골을 다녔다는 말은 있지만, 그 장비가 어떻게 만들어지고 나아졌는지는 한 줄도 없습니다. 글의 눈은 기계가 아니라 녹음이라는 일이 노래에 한 일에 있습니다. 낱말만 빌려 온 제목입니다."),
  ("멈춤으로써 지켜지다: 모으기가 살아 있는 전통에 한 일", "둘째 문장 «What they did not anticipate was how much the act of collection would change the thing collected.»와 끝쪽의 «certain things can be preserved only by being stopped»가 근거입니다. 여러 가지로 불리던 노래가 녹음되는 그때 한 가지로 굳었고, 모으는 사람의 고르기도 거기 담겼습니다. 지키는 일이 지킨 것을 바꾼 것입니다. 'a living practice'가 'a Living Tradition'으로 바뀌었습니다."),
  ("스무 세기 자료관에 담긴 시골살이", "지문 낱말을 빌려 왔지만 이야기가 다릅니다. 시골과 자료관이 나오지만, 글은 시골 사람들이 어떻게 살았는지를 말하지 않습니다. 오히려 모으는 사람들이 시골 배경과 나이 든 가수를 골랐다고 했습니다. 자료관이 담은 것은 시골살이가 아니라 모으는 사람의 생각이기도 하다는 것이 글의 말입니다."),
  ("민요가 유럽 시골에서 사라진 까닭", "글의 물음이 아닙니다. 모으는 사람들이 곧 사라질 음악을 지킨다고 믿었다는 말은 있습니다. 하지만 글은 왜 사라졌는지를 따지지 않고, 지키려는 일이 무엇을 바꾸었는지를 따집니다. 유럽이라는 말도 지문에 없습니다. 글의 들머리만 보고 넘겨짚은 제목입니다.")])

# ---------- 13번째: 원인이 여럿에 흩어진 사고에서, 뒤에 누가 책임지는가 ----------
mk(12, 1, [
 "1) 되풀이: 「한 사고의 원인이 여럿에 흩어져 있다」는 생각이 이어집니다. «An automated vehicle distributes the same event across a manufacturer, a supplier who wrote the perception software, a regulator who approved the system»(자율 주행차는 같은 일을 만든 회사, 알아보는 소프트웨어를 쓴 납품 회사, 그 체계를 허가한 규제 기관에 걸쳐 흩어 놓는다) → «Each contributed a necessary condition and none is obviously sufficient»(저마다 꼭 있어야 할 조건 하나씩을 보탰고, 어느 것도 그것만으로 넉넉하지는 않다) → «a single event now has many authors and the law was written for one»(한 가지 일에 이제 지은이가 여럿인데, 법은 하나를 두고 쓰였다).",
 "2) 꺾이는 곳: 다섯째 문장입니다. «The harder and more common question concerns who answers afterwards.»(더 어렵고 더 흔한 물음은 뒤에 누가 책임지느냐이다.) 바로 앞 문장이 낮추는 쪽입니다. 사람들의 말다툼은 차가 누구를 다치게 고를 것이냐는 갈림길 이야기에 쏠려 있지만, 그런 일은 아주 드물다고 했습니다. 글은 그 익숙한 물음을 밀어 두고 책임의 물음으로 넘어갑니다.",
 "3) 끝 문장: 끝에서 두 번째 문장이 못을 박습니다. «Neither family of proposals removes the underlying difficulty»(어느 쪽 제안도 밑에 깔린 어려움을 없애지 못한다). 그 어려움이 바로 지은이가 여럿이라는 것입니다. 맨 끝 문장은 나라들이 두 길을 섞고 있다는 것을 덧붙입니다.",
 "4) 묶기: 'Distributed Causes'(여럿에 흩어진 원인) = 'distributes the same event across', 'many authors'. 'the Question of Who Answers Afterwards'(뒤에 누가 책임지는가 하는 물음) = 'who answers afterwards'. 지문 낱말 그대로입니다. 제목의 앞쪽이 문제의 생김새, 뒤쪽이 글이 붙든 물음입니다. 두 갈래의 제안(만든 회사에 지우기, 기록으로 되짚기)은 그 물음에 대한 답들입니다."],
 "「자율 주행차를 설계하는 사람들이 마주한 도덕의 갈림길」이 가장 위험합니다. 자율 주행차라고 하면 가장 익숙한 이야기이기 때문입니다. 하지만 글은 바로 그 이야기를 낮추었습니다. 그런 갈림길은 비 오는 날 알아보기가 어긋나는 여느 탈에 견주면 아주 드물다('vanishingly rare')고 했습니다. 「하늘에서 배운 것: 항공 사고 조사 절차와 그 역사」도 조심합니다. 항공은 두 갈래 제안 가운데 하나가 본뜬 본보기로 한 번 나올 뿐입니다.",
 [("감지기 위의 비: 자율 주행차는 둘레를 어떻게 알아보는가", "지문 낱말을 빌려 왔지만 이야기가 다릅니다. 비 오는 날 알아보기가 어긋난다는 말이 한 번 나옵니다. 그것은 도덕의 갈림길보다 여느 탈이 훨씬 흔하다는 것을 말하려는 것입니다. 차가 둘레를 어떻게 알아보는지는 지문에 없습니다. 글의 눈은 탈이 난 뒤의 책임에 있습니다."),
  ("여럿에 흩어진 원인, 그리고 뒤에 누가 책임지는가 하는 물음", "다섯째 문장 «The harder and more common question concerns who answers afterwards.»와 끝쪽의 «a single event now has many authors and the law was written for one»이 근거입니다. 사람이 몰 때는 책임질 곳이 하나였습니다. 자율 주행차에서는 만든 회사, 납품 회사, 규제 기관, 운영하는 쪽, 탄 사람이 저마다 조건 하나씩을 보탭니다. 그래서 뒤에 누가 책임지느냐가 물음이 됩니다. 'many authors'가 'Distributed Causes'로 바뀌었습니다."),
  ("하늘에서 배운 것: 항공 사고 조사 절차와 그 역사", "글의 한 대목만 담았습니다. 낱낱이 적어 두게 해서 어느 부품이 탈이 났는지 되짚는 제안이 항공을 본떴다('on the aviation model')는 말이 한 번 나옵니다. 항공 조사가 어떻게 이루어지는지, 어떻게 생겨났는지는 지문에 없습니다. 두 갈래 제안 가운데 하나의 본보기일 뿐입니다."),
  ("자율 주행차가 사람 운전자보다 안전한 까닭", "지문에 없는 이야기입니다. 글은 자율 주행차와 사람 가운데 어느 쪽이 안전한지를 견주지 않았습니다. 견준 것은 책임을 묻는 길입니다. 사람이 몰 때는 책임질 곳이 또렷하고, 자율 주행차에서는 흩어진다는 것입니다. 안전하다는 주장은 글에 없습니다."),
  ("자율 주행차를 설계하는 사람들이 마주한 도덕의 갈림길", "글이 낮춘 쪽을 제목으로 삼았습니다. 누구를 다치게 고를 것이냐는 갈림길 이야기는 넷째 문장에 나옵니다. 하지만 글은 사람들의 말다툼이 거기에 쏠려 있다고 한 뒤, 기술자들의 말을 빌려 그런 일은 아주 드물다고 했습니다. 그리고 더 어렵고 더 흔한 물음으로 넘어갑니다. 익숙하다고 고르면 걸립니다.")])

# ---------- 14번째: 돈은 장부인가 상품인가 — 생겨난 이야기가 지금도 중요하다 ----------
mk(13, 4, [
 "1) 되풀이: 「돈은 물건 맞바꾸기가 아니라 빚 적기에서 나왔다」는 생각이 이어집니다. «anthropologists have spent a century failing to find a society that matches it»(인류학자들은 백 해 동안 그 이야기에 맞는 사회를 찾지 못했다) → «What the record shows instead is credit.»(기록이 그 대신 보여 주는 것은 외상이다.) → 메소포타미아의 흙판은 거의 다 빚을 적은 것입니다('overwhelmingly accounts of debt').",
 "2) 꺾이는 곳: 두 번 꺾입니다. 셋째 문장의 'instead'(그 대신)에서 교과서의 이야기가 뒤집힙니다. 그리고 일곱째 문장에서 글이 옛일에서 지금으로 넘어옵니다. «The correction matters beyond history.»(이 바로잡음은 역사 너머에서도 중요하다.) 돈이 낯선 사람끼리의 맞바꾸기를 매끄럽게 하려고 나왔다면 돈은 상품이고, 공동체 안의 갚을 것을 적는 길로 나왔다면 돈은 장부입니다. 어느 쪽이냐에 따라 정책이 무엇을 보아야 하는지가 달라집니다.",
 "3) 끝 문장: 끝에서 두 번째 문장이 못을 박습니다. «Two accounts of the same institution therefore lead to different assumptions about what monetary authorities are actually managing.»(그러므로 같은 제도에 대한 두 이야기가, 돈을 다스리는 쪽이 실제로 무엇을 다스리는가에 대한 서로 다른 가정으로 이어진다.) 맨 끝 문장은 교과서의 마을 이야기가 왜 아직 남아 있는지를 덧붙입니다. 첫 장을 쓰기 쉽게 해 주기 때문입니다.",
 "4) 묶기: 콜론 앞 'Ledger or Commodity'(장부냐 상품이냐) = 'it is essentially a ledger', 'it is essentially a commodity'. 지문 낱말 그대로입니다. 콜론 뒤 'the Origin Story of Money'(돈이 생겨난 이야기) = 교과서의 마을 이야기와 그것을 뒤집은 기록. 'Still Matters'(아직도 중요하다) = 'The correction matters beyond history'. 글의 앞 절반(어디서 나왔나)과 뒤 절반(그래서 지금 무엇이 달라지나)을 다 담았습니다."],
 "「물물 교환 경제가 기록된 역사 내내 실패한 까닭」이 조심할 선택지입니다. 교과서의 이야기가 물건 맞바꾸기의 어려움에서 시작하니 끌립니다. 하지만 글은 그 이야기에 맞는 사회를 찾지 못했다고 했습니다. 물건 맞바꾸기는 돈보다 앞선 단계가 아니라 돈이 무너진 뒤에 나타나는 것이라고 했습니다. 실패했다는 말도 없습니다. 메소포타미아의 흙판, 은을 담은 제목들은 모두 여섯째 문장의 증거 하나씩만 붙잡았습니다.",
 [("물물 교환 경제가 기록된 역사 내내 실패한 까닭", "글이 뒤집은 이야기 쪽에 선 제목입니다. 물건 맞바꾸기가 어려워서 돈을 만들었다는 것은 교과서의 이야기이고, 글은 그것에 맞는 사회가 없었다고 했습니다. 물건 맞바꾸기는 주로 낯선 사람 사이에서, 또는 돈이 무너진 뒤에 나타납니다. 역사 내내 실패했다는 말은 지문에 없습니다."),
  ("메소포타미아의 글 쓰는 이들은 거래를 흙판에 어떻게 적었는가", "글의 한 대목만 담았습니다. 메소포타미아의 흙판이 거의 다 빚을 적은 것이라는 말이 한 번 나옵니다. 그것은 돈이 외상에서 나왔다는 읽기를 받치는 증거입니다. 어떻게 적었는지는 지문에 없습니다. 증거 하나를 제목으로 삼은 것입니다."),
  ("달았으되 움직이지 않은: 옛 교역 체계에서 은이 한 구실", "글의 한 대목만 담았습니다. 빚이 대개 움직이지 않은 은으로 셈해졌다는 말이 같은 문장 끝에 나옵니다. 은이 교역에서 무슨 구실을 했는지를 다루는 글이 아닙니다. 그 한 줄은 돈이 오가는 물건이 아니라 적는 잣대였다는 것을 보이려는 것입니다."),
  ("인류학 현장 조사 방법 훑어보기", "지문에 없는 이야기입니다. 인류학자들이 그런 사회를 찾지 못했다는 말은 있지만, 어떻게 조사하는지는 나오지 않습니다. 글의 눈은 조사하는 법이 아니라 그 조사가 뒤집은 돈 이야기에 있습니다. 낱말만 빌려 온 제목입니다."),
  ("장부냐 상품이냐: 돈이 생겨난 이야기가 아직도 중요한 까닭", "일곱째 문장 «The correction matters beyond history.»와 끝쪽의 «Two accounts of the same institution therefore lead to different assumptions about what monetary authorities are actually managing.»이 근거입니다. 돈이 맞바꾸기에서 나왔다면 상품이고, 빚 적기에서 나왔다면 장부입니다. 어느 이야기를 믿느냐에 따라 돈을 다스리는 일이 무엇인지가 달라집니다. 'matters beyond history'가 'Still Matters'로 바뀌었습니다.")])

# ---------- 15번째: 기억에 남는 그림이 그것이 가리키는 문제를 대신한다 ----------
mk(14, 4, [
 "1) 되풀이: 「그림 하나가 복잡한 문제를 대신했다」는 생각이 이어집니다. «they collapsed a distinction that matters»(그 운동들은 중요한 가름 하나를 뭉개 버렸다) → «a memorable image stands in for a complex problem»(기억에 남는 그림이 복잡한 문제를 대신한다) → 끝 문장의 사진 이야기. 벌이 사라진다는 그림이 「꿀벌」과 「야생 벌」의 가름을 지웠습니다. 꿀벌은 사람이 치는 가축이고 오히려 늘었습니다. 어려운 쪽은 야생 벌입니다.",
 "2) 꺾이는 곳: 둘째 문장의 but입니다. «The campaigns were not wrong, but they collapsed a distinction that matters.»(그 운동들이 틀린 것은 아니었지만, 중요한 가름 하나를 뭉개 버렸다.) 넷째 문장이 그 결과를 한 줄로 말합니다. «Adding hives adds competitors.»(벌통을 보태면 겨루는 쪽이 보태진다.) 그리고 일곱째 문장의 'What the episode illustrates is'(이 일이 보여 주는 것은)에서 글이 벌 이야기를 넘어 더 넓은 가르침으로 갑니다.",
 "3) 끝 문장: «None of those measures produces a photograph of a person in a white suit holding a frame, which may be the most instructive part of the story.»(그 대책 가운데 어느 것도 흰옷을 입고 벌집 틀을 든 사람의 사진을 내놓지 않는데, 그것이 이 이야기에서 가장 배울 만한 대목일지 모른다.) 참으로 듣는 대책은 그림이 되지 않습니다. 그림이 문제를 대신한다는 생각이 끝에서 뒤집힌 꼴로 한 번 더 나옵니다.",
 "4) 묶기: 제목이 일곱째 문장을 거의 그대로 옮겼습니다. 'a Memorable Image'(기억에 남는 그림) = 'a memorable image'. 'Replaces'(대신한다) = 'stands in for'(~을 대신해 선다). 'the Problem It Represents'(그것이 가리키는 문제) = 'a complex problem'. 제목에는 벌이 한 마디도 없습니다. 벌은 본보기이고, 글이 말하려는 것은 그 본보기가 보여 주는 탈의 꼴이기 때문입니다."],
 "「도시에서 벌 치기를 모두 법으로 막아야 하는 까닭」이 가장 위험합니다. 벌통이 야생 벌을 해친다고 했으니 막자는 말로 읽기 쉽습니다. 하지만 글이 든 대책은 그것이 아닙니다. 꽃이 이어서 피는 풀과 나무를 심고, 둥지 틀 자리를 남기고, 먹이가 받쳐 주는 것보다 벌통이 이미 많은 구역에 더 보태지 않는 것입니다. 'All'과 'Illegal'은 글이 하지 않은 센 주장입니다. 「거리 위의 벌통: 빠르게 늘어난 옥상 벌 치기」는 첫 문장의 바탕 이야기만 담았습니다.",
 [("도시에서 벌 치기를 모두 법으로 막아야 하는 까닭", "글이 하지 않은 센 주장입니다. 벌통을 보태면 야생 벌과 겨루게 된다고 했으니 막아야 한다고 읽기 쉽습니다. 하지만 글의 대책은 벌통이 이미 너무 많은 구역에 더 보태지 않는 것('stop adding hives')입니다. 벌을 치는 사람들도 좋은 뜻에서 준 도움말을 따랐다고 했습니다. 모두 막자는 말은 지문에 없습니다."),
  ("거리 위의 벌통: 빠르게 늘어난 옥상 벌 치기", "글 첫머리의 바탕 이야기만 붙잡았습니다. 옥상 벌통이 지난 스무 해 동안 늘었다는 것은 첫 문장입니다. 글은 거기서 곧바로 그 운동이 뭉갠 가름으로, 그리고 그림이 문제를 대신한다는 가르침으로 나아갑니다. 늘어났다는 것을 알리는 글이 아닙니다."),
  ("꿀벌 무리는 꿀을 어떻게 찾아 모으는가", "글의 한 대목만 담았습니다. 튼튼한 무리가 몇 킬로미터에 걸쳐 먹이를 찾는다는 말이 한 번 나옵니다. 그것은 벌통이 야생 벌의 먹이를 가져간다는 것을 보이려는 한 줄입니다. 꿀을 어떻게 찾고 모으는지를 알려 주는 글이 아닙니다."),
  ("남은 것 세기: 유럽 도시의 야생 꽃가루받이 벌레들", "글의 한 대목만 담았습니다. 벌통이 빽빽한 도시에서 야생 벌이 줄었다는 조사가 나옵니다. 하지만 글은 야생 벌이 얼마나 남았는지를 세는 글이 아닙니다. 그 조사는 좋은 뜻의 운동이 왜 엇나갔는지를 보이려는 증거입니다. 증거 하나를 제목으로 삼은 것입니다."),
  ("기억에 남는 그림이 그것이 가리키는 문제를 대신할 때", "일곱째 문장의 «a memorable image stands in for a complex problem and the public responds by doing something that the image implies rather than something the problem requires»가 근거입니다. 벌이 사라진다는 그림을 본 사람들은 벌통을 놓았습니다. 그림이 시키는 일이었지 문제가 바라는 일이 아니었습니다. 'stands in for'가 'Replaces'로 바뀌었습니다.")])

# ---------- 16번째: 팔아서는 안 되는 약에 값을 치르는 길 ----------
mk(15, 2, [
 "1) 되풀이: 「잘 듣는 항생제일수록 덜 쓰여서 돈이 되지 않는다」는 생각이 이어집니다. 좋은 항생제는 한 주 먹고 낫게 한 뒤, 견디는 세균이 생기지 않도록 병원이 일부러 아껴 둡니다('deliberately withheld'). 그래서 «expensive to develop, briefly used, and reserved for emergencies precisely in proportion to how well it works»(개발하는 데 비싸고, 잠깐 쓰이고, 잘 들을수록 급할 때를 위해 아껴 두는) 물건이 됩니다 → 큰 회사들은 항생제 부서를 닫았고, 새 약을 내놓은 작은 회사들은 망했습니다.",
 "2) 꺾이는 곳: 여섯째 문장입니다. «Proposals to fix this share a common shape: they detach the reward from the volume sold.»(이것을 고치려는 제안들은 꼴이 같다. 받는 몫을 팔린 양에서 떼어 낸다.) 여기서 글이 문제에서 풀이로 넘어갑니다. 구독 방식은 몇 번 썼든 정해진 돈을 내고, 상금 방식은 팔릴 때가 아니라 허가받을 때 돈을 줍니다. 그러면 «a developer profits from a drug that sits unused»(개발한 쪽이 쓰이지 않고 놓여 있는 약에서 돈을 번다).",
 "3) 끝 문장: «a market functioning exactly as designed while producing an outcome that everyone involved would prefer to avoid»(짜인 그대로 돌아가면서도, 얽힌 모두가 비켜 가고 싶어 할 결과를 내는 시장). 누가 잘못해서가 아닙니다. 첫 문장의 'structural rather than scientific'(과학의 탓이 아니라 짜임의 탓)이 끝에서 돌아왔습니다.",
 "4) 묶기: 'a Medicine That Must Not Be Sold'(팔아서는 안 되는 약) = 'deliberately withheld'(일부러 아껴 두는), 'a drug that sits unused'(쓰이지 않고 놓여 있는 약), 'a medicine nobody wants to use'(아무도 쓰고 싶어 하지 않는 약). 'Paying for'(값을 치르기) = 'detach the reward from the volume sold'(받는 몫을 팔린 양에서 떼어 내다). 많이 팔리면 안 되는 물건에 어떻게 값을 치르느냐가 글 전체의 물음입니다."],
 "「눌림 속에서 살아남기: 세균은 어떻게 항생제를 견디는가」가 조심할 선택지입니다. 항생제와 견디는 세균은 익숙한 짝이라 끌립니다. 하지만 글은 첫 문장에서 까닭이 과학이 아니라 짜임이라고 못 박았습니다. 세균이 어떻게 견디는지는 지문에 없습니다. 「병원은 어떤 약을 아껴 둘지 어떻게 정하는가」도 조심합니다. 병원이 아껴 둔다는 말은 있지만, 그것은 약이 팔리지 않는 까닭으로 나왔을 뿐입니다.",
 [("벌이와 개발 줄: 약 만드는 회사들의 돈 역사", "글보다 넓고, 지문에 없는 이야기입니다. 약 회사의 벌이가 나오지만, 약 회사들의 돈 역사를 훑는 글이 아닙니다. 글이 다룬 것은 항생제 하나, 그것도 잘 들을수록 덜 팔린다는 짜임입니다. 'History'는 글이 하지 않은 일입니다."),
  ("의학의 앞날인 오래가는 병 다스리기", "글의 한 대목을 거꾸로 읽었습니다. 날마다 수십 해를 먹는 오래가는 병의 약이 훨씬 많이 번다는 말이 한 번 나옵니다. 그것은 항생제가 왜 돈이 되지 않는지를 보이려는 견줌입니다. 글은 그것을 앞날이라고 하지 않았습니다. 오히려 아무도 낫게 하지 않는 약이 더 번다는 어긋남을 짚은 것입니다."),
  ("팔아서는 안 되는 약에 값을 치르기", "여섯째 문장 «they detach the reward from the volume sold»와 일곱째 문장의 «a developer profits from a drug that sits unused»가 근거입니다. 잘 듣는 항생제는 아껴 두어야 하니 많이 팔 수 없습니다. 그래서 팔린 양이 아니라 쓸 수 있게 해 둔 것에 돈을 내는 길을 찾습니다. 'detach the reward from the volume sold'가 'Paying for'로, 'a drug that sits unused'가 'a Medicine That Must Not Be Sold'로 바뀌었습니다."),
  ("눌림 속에서 살아남기: 세균은 어떻게 항생제를 견디는가", "지문에 없는 이야기입니다. 견디는 세균이 생기지 않게 하려고 약을 아껴 둔다는 말은 있습니다. 하지만 세균이 어떻게 견디게 되는지는 한 줄도 없습니다. 글은 까닭이 과학이 아니라 짜임('structural rather than scientific')이라고 했습니다. 익숙한 짝이라고 고르면 걸립니다."),
  ("병원은 어떤 약을 아껴 둘지 어떻게 정하는가", "글의 한 대목만 담았습니다. 병원이 잘 듣는 항생제를 일부러 아껴 둔다는 말은 둘째 문장에 나옵니다. 하지만 병원이 그것을 어떻게 정하는지는 지문에 없습니다. 그 한 줄은 좋은 항생제가 왜 팔리지 않는지를 알려 주려는 것이고, 글은 거기서 시장의 짜임과 그 풀이로 나아갑니다.")])

# ---------- 17번째: 누군가 계속 베껴 주는 동안에만 살아남는 기록 ----------
mk(16, 3, [
 "1) 되풀이: 「디지털 기록은 누군가 계속 손을 대야만 남는다」는 생각이 이어집니다. «a digital one survives only active maintenance, copied forward through successive formats»(디지털 문서는 손수 돌보아야만 살아남고, 잇따르는 꼴들을 거쳐 앞으로 베껴져야 한다) → «accept that the work never ends»(그 일이 끝나지 않는다는 것을 받아들인다) → «closer to maintenance than to storage»(넣어 두기보다 돌보기에 가깝다).",
 "2) 꺾이는 곳: 셋째 문장의 세미콜론 앞뒤가 맞섭니다. 종이 문서는 내버려 두어도 남고, 디지털 문서는 돌보아야만 남습니다. 그리고 일곱째 문장에서 한 번 더 꺾입니다. «What archivists describe as the hardest part is not technical.»(자료를 지키는 사람들이 가장 어렵다고 하는 것은 기술이 아니다.) 가장 어려운 것은, 눈에 보이는 것을 아무것도 내놓지 않는 일에 예산의 한 줄을 길이 내주도록 기관을 설득하는 것입니다.",
 "3) 끝 문장: «they measure success by the absence of any event worth reporting»(그들은 알릴 만한 일이 아무것도 없는 것으로 잘됨을 잰다). 가장 오래 해낸 기관들은 이 일을 넣어 두기가 아니라 돌보기에 가깝다고 말합니다. 한 번 넣어 두면 끝나는 일이 아니라, 누군가 계속하고 있어야 하는 일입니다.",
 "4) 묶기: 'Survives Only While Someone Keeps Copying It'(누군가 계속 베껴 주는 동안에만 살아남는다) = 'survives only active maintenance, copied forward'. 'Keeps'(계속 ~하다) = 'budget for the copying indefinitely'(끝없이 그 베끼기에 예산을 대다), 'the work never ends'. 'Someone'(누군가) = 예산의 한 줄을 대야 하는 기관. 제목이 셋째 문장을 풀어 쓴 것입니다."],
 "「열린 것이냐 임자 있는 것이냐: 넣어 두기에 가장 좋은 파일 꼴 고르기」가 조심할 선택지입니다. 단순하고 열린 꼴로 넣어 두라는 말이 지문에 나옵니다. 하지만 그것은 네 가지 대응 가운데 하나이고, 글은 가장 어려운 것이 기술이 아니라고 했습니다. 「우주 기관들은 맨 처음 임무 자료를 어떻게 되찾았는가」도 조심합니다. 낡은 테이프 읽는 기계를 사진을 보고 다시 지어야 했다는 본보기 하나만 담은 제목입니다.",
 [("언제든 열려 있는: 디지털 기술이 자료관 드나들기를 낫게 한 까닭", "지문에 없는 이야기이고 방향도 다릅니다. 글은 디지털이 자료를 보기 쉽게 했다고 하지 않았습니다. 디지털로 넘어오면서 오래가는 쪽으로 가던 흐름이 뒤집혔다고 했습니다. 좋은 점이 아니라 지키기 어려워진 점을 말하는 글입니다. 디지털이라는 말에서 떠올린 상식일 뿐입니다."),
  ("우주 기관들은 맨 처음 임무 자료를 어떻게 되찾았는가", "글의 한 대목만 담았습니다. 우주 기관들이 낡은 테이프 읽는 기계를 사진을 보고 다시 지어야 했다는 말이 다섯째 문장에 나옵니다. 그것은 돌보지 않은 디지털 기록이 어떻게 되는지를 보여 주는 본보기입니다. 어떻게 되찾았는지를 알려 주는 글이 아니고, 몇몇 기록은 그냥 잃었다고도 했습니다."),
  ("옛 도서관에서 종이가 삭는 화학적 까닭", "글 첫 문장의 낱말만 빌려 왔습니다. 산성 종이가 백 해쯤 간다는 말은 있지만, 종이가 왜 삭는지는 나오지 않습니다. 종이는 디지털과 견주려고 나왔을 뿐입니다. 글의 눈은 종이가 아니라 디지털 기록을 지키는 일에 있습니다."),
  ("누군가 계속 베껴 주는 동안에만 살아남는 기록", "셋째 문장 «a digital one survives only active maintenance, copied forward through successive formats»와 여섯째 문장의 «accept that the work never ends»가 근거입니다. 종이는 내버려 두어도 남지만, 디지털 기록은 누군가 새 꼴로 계속 옮겨 주어야 남습니다. 그 일은 끝나지 않고, 그래서 예산의 한 줄이 길이 있어야 합니다. 'copied forward'가 'Keeps Copying'으로 바뀌었습니다."),
  ("열린 것이냐 임자 있는 것이냐: 넣어 두기에 가장 좋은 파일 꼴 고르기", "글의 한 대목만 담았습니다. 단순하고 열린 꼴로 넣어 두라는 것은 여섯째 문장의 네 가지 대응 가운데 하나입니다. 글은 바로 뒤에 가장 어려운 것은 기술이 아니라고('not technical') 했습니다. 어느 꼴이 가장 좋은지를 고르는 글이 아니라, 그 일을 누가 계속 맡아 주느냐를 말하는 글입니다.")])

# ---------- 18번째: 공항에서 잰 공식 기온은 사람들이 사는 곳을 말해 주지 못한다 ----------
mk(17, 2, [
 "1) 되풀이: 「다른 데서 잰 숫자가 사람들이 사는 곳의 더위를 말해 주지 못한다」는 생각이 이어집니다. «Heat is measured at airports, and people do not live at airports.»(더위는 공항에서 재는데, 사람들은 공항에 살지 않는다.) → 공식 숫자는 그늘 없는 빽빽한 동네에 사는 사람이 겪는 것보다 몇 도 낮습니다 → «a hazard defined by a measurement taken somewhere else will be managed as though it occurred somewhere else»(다른 데서 잰 값으로 정한 위험은, 다른 데서 일어난 것처럼 다루어진다).",
 "2) 꺾이는 곳: 셋째 문장입니다. «That gap has practical consequences»(그 틈은 실제 결과를 낳는다). 일하는 규칙, 학교 문 닫기, 비상 계획에 적힌 문턱이 공식 숫자로 움직이기 때문입니다. 같은 날 오후에 한 도시 안에서 동네마다 열 도까지 다르고, 그 차이가 벌이와 맞물립니다. 밖에서 일하는 사람들이 공식 숫자가 가장 심하게 낮춰 말하는 바로 그 동네에 몰려 있습니다.",
 "3) 끝 문장: 끝에서 두 번째 문장이 까닭을 짚습니다. 두 가지 고침이 더딘 것은 물려받은 잣대를 «as though it described a condition rather than a location»(어떤 곳이 아니라 어떤 형편을 그리는 것처럼) 다루는 버릇 때문입니다. 공항에서 잰 값은 「공항이라는 곳」의 값인데, 「도시의 더위」로 읽힙니다. 맨 끝 문장은 잣대를 먼저 바꾼 도시들에서 나머지가 빨리 따라왔다고 덧붙입니다.",
 "4) 묶기: 콜론 앞 'The Airport Reading'(공항에서 잰 값) = 'Heat is measured at airports'. 콜론 뒤 'the Official Temperature'(공식 기온) = 'the official number', 'the official figure'. 'Describes Nowhere'(어느 곳도 그리지 못한다) = 사람들이 살지 않는 곳에서 잰 값이라, 사람들이 사는 어느 동네의 더위도 말해 주지 못한다는 뜻입니다. 'a measurement taken somewhere else'(다른 데서 잰 값)를 더 세게 말한 것입니다."],
 "「더위에 폭풍처럼 이름을 붙여야 하는 까닭」이 가장 위험합니다. 이름 붙이기는 지문에 나오는 고침이고, 'Should'가 붙어 주장처럼 보입니다. 하지만 그것은 두 가지 고침 가운데 하나이고, 글은 둘이 같은 밑바탕을 겨눈다고 했습니다. 그 밑바탕이 잣대의 문제입니다. 「꾸며 만든 그늘: 도시 더위의 풀이로서의 나무 심기」도 조심합니다. 나무 그늘은 동네마다 기온이 다른 것과 맞물리는 것으로 나올 뿐, 나무를 심자는 말은 지문에 없습니다.",
 [("꾸며 만든 그늘: 도시 더위의 풀이로서의 나무 심기", "지문 낱말에서 떠올린, 지문에 없는 풀이입니다. 동네마다의 기온 차이가 나무 그늘과 맞물린다('tree cover')는 말은 있습니다. 하지만 나무를 심자는 말은 없습니다. 글이 든 고침은 더위에 이름 붙이기와 동네마다 재기, 둘입니다. 둘 다 잣대의 문제를 겨눕니다."),
  ("탁 트인 땅: 날씨 관측소는 어떻게 자리 잡고 맞추는가", "글 앞쪽의 낱말을 빌려 왔습니다. 관측소가 그럴 만한 까닭으로 탁 트인 땅에 있다는 말이 둘째 문장에 나옵니다. 하지만 관측소를 어떻게 놓고 맞추는지는 지문에 없습니다. 글은 그 자리에서 잰 값이 사람들이 사는 곳과 어긋난다는 것으로 곧바로 나아갑니다."),
  ("공항에서 잰 값: 공식 기온이 어느 곳도 그리지 못할 때", "첫 문장 «Heat is measured at airports, and people do not live at airports.»와 여덟째 문장의 «a hazard defined by a measurement taken somewhere else will be managed as though it occurred somewhere else»가 근거입니다. 공식 기온은 사람들이 살지 않는 곳에서 잰 값입니다. 그런데 일하는 규칙과 비상 계획이 그 숫자로 움직여, 가장 더운 동네가 가장 덜 지켜집니다. 'the official number'가 'the Official Temperature'로 바뀌었습니다."),
  ("더위에 폭풍처럼 이름을 붙여야 하는 까닭", "글의 한 대목만 담았습니다. 몇몇 도시가 더위에 이름을 붙이고 차례를 매기기 시작했다는 말이 여섯째 문장에 나옵니다. 그것은 두 가지 고침 가운데 하나입니다. 글은 그래야 한다고 내세우지 않았고, 두 고침이 겨누는 같은 밑바탕, 곧 다른 데서 잰 값이라는 문제를 말했습니다. 'Should'는 글에 없는 주장입니다."),
  ("볕 아래 일하기: 높은 기온이 일하는 사람의 몸에 미치는 영향", "글의 한 대목만 담았습니다. 밖에서 일하는 사람들이 먼저, 가장 크게 겪는다는 말이 다섯째 문장에 나옵니다. 하지만 더위가 몸에 무슨 일을 하는지는 지문에 없습니다. 그 한 줄은 공식 숫자가 낮춰 말하는 동네에 바로 그 사람들이 몰려 있다는 것을 보이려는 것입니다.")])

# ---------- 19번째: 적어 두기만으로는 말을 살릴 수 없고, 써야만 하는 처지를 다시 지어야 한다 ----------
mk(18, 0, [
 "1) 되풀이: 「말은 날마다 써야 하는 처지에서 배운다」는 생각이 이어집니다. «what must be restored is not vocabulary but the ordinary daily use in which children acquire a language without instruction»(되살려야 하는 것은 낱말이 아니라, 아이들이 가르침 없이 말을 익히는 여느 날의 쓰임이다) → «settings where the language is the only practical option»(그 말이 쓸 수 있는 단 하나의 길인 자리) → «necessity rather than admiration»(우러러봄이 아니라 써야만 함).",
 "2) 꺾이는 곳: 여섯째 문장입니다. «Revival efforts that concentrate on documentation produce dictionaries and grammars while the chain stays broken.»(적어 두기에 힘을 모으는 되살리기는 사전과 문법책을 내놓지만, 사슬은 끊긴 채로 남는다.) 앞의 다섯 문장은 바탕 이야기입니다. 말은 부모들의 그럴 만한 결정이 쌓여서 죽습니다. 일곱째 문장의 'instead'(그 대신)가 되는 길을 내놓습니다. 그 말만 쓰는 어린이집, 나이 든 사람과 젊은 집을 짝짓기, 그 말로만 하는 일터입니다.",
 "3) 끝 문장: 끝에서 두 번째 문장이 그 바뀜을 그립니다. 말하는 사람들은 판가름 난 때를 정책이나 운동이 아니라, «the first ordinary morning on which the language was simply the easiest way to ask for something»(그 말이 무언가를 달라고 하는 가장 쉬운 길이었던 첫 여느 아침)이라고 합니다. 써야만 하는 처지가 다시 생긴 때입니다. 맨 끝 문장은 거기까지 간 사업은 돈이 더 없어도 살아남는다고 덧붙입니다.",
 "4) 묶기: 콜론 앞 'Rebuilding Necessity'(써야만 하는 처지 다시 짓기) = 'reproduce the condition under which any language is learned, which is necessity'(어떤 말이든 배우게 되는 조건, 곧 써야만 함을 다시 만든다). 콜론 뒤 'Documentation Alone Cannot Save a Language'(적어 두기만으로는 말을 살릴 수 없다) = 'while the chain stays broken'. 콜론 앞이 되는 길, 콜론 뒤가 안 되는 길입니다."],
 "「부모가 집에서 물려받은 말을 써야 하는 까닭」이 가장 위험합니다. 부모가 다른 말로 아이를 기르면서 말이 죽는다고 했으니, 부모가 써야 한다는 말로 읽기 쉽습니다. 하지만 글은 부모를 탓하지 않았습니다. 그 결정은 그럴 만한('reasonable') 것이라고 했습니다. 되는 길은 부모에게 바라는 것이 아니라, 그 말을 써야만 하는 자리를 짓는 것입니다. 「쓰는 사람이 적은 말의 사전 엮기」는 글이 모자라다고 한 바로 그 길입니다.",
 [("「써야만 하는 처지」 다시 짓기: 적어 두기만으로는 말을 살릴 수 없는 까닭", "여섯째 문장 «Revival efforts that concentrate on documentation produce dictionaries and grammars while the chain stays broken.»과 여덟째 문장의 «necessity rather than admiration»이 근거입니다. 사전과 문법책을 만들어도 아이들이 그 말을 날마다 쓰지 않으면 사슬은 이어지지 않습니다. 듣는 길은 그 말을 써야만 하는 자리를 짓는 것입니다. 'reproduce the condition'이 'Rebuilding'으로 바뀌었습니다."),
  ("소리와 격: 사라져 가는 말들의 짜임과 문법", "지문에 없는 이야기입니다. 문법책이라는 말이 한 번 나오지만, 그것은 적어 두기에 힘을 모은 되살리기가 내놓는 것으로 나올 뿐입니다. 사라져 가는 말들이 어떤 짜임을 가졌는지는 한 줄도 없습니다. 글의 눈은 말의 짜임이 아니라 말이 이어지는 길에 있습니다."),
  ("쓰는 사람이 적은 말의 사전 엮기", "글이 모자라다고 한 쪽을 제목으로 삼았습니다. 사전은 적어 두기에 힘을 모으는 되살리기가 내놓는 것으로 나옵니다. 글은 그렇게 해도 사슬은 끊긴 채 남는다고 했습니다. 되살려야 하는 것은 낱말이 아니라 날마다의 쓰임이라고 했습니다. 방향이 거꾸로입니다."),
  ("부모가 집에서 물려받은 말을 써야 하는 까닭", "글이 하지 않은 센 주장입니다. 부모가 다른 말로 아이를 기른다는 것이 말이 죽는 길로 나오니 끌립니다. 하지만 글은 그것을 그럴 만한 결정이라고 했고, 어느 집도 그 결과를 뜻하지 않았다고 했습니다. 글이 든 되는 길은 부모를 타이르는 것이 아니라, 그 말만 쓰는 어린이집과 일터 같은 자리를 짓는 것입니다. 'Should'는 글에 없습니다."),
  ("지난날 정부들은 소수의 말을 어떻게 억눌렀는가", "글이 첫 문장에서 밀어 둔 쪽입니다. 말하는 것을 막아서 말이 죽는 일도 있었다고 한 번 말합니다('though that has happened'). 하지만 글은 곧바로, 더 흔하게는 부모들의 그럴 만한 결정이 쌓여서 죽는다고 했습니다. 억누름의 역사는 지문에 없습니다.")])

# ---------- 20번째: 아무도 부정직하다고 여기지 않은 관행이 치우친 기록을 낳는다 ----------
mk(19, 3, [
 "1) 되풀이: 「속임이 아니라 여느 관행 때문이다」라는 생각이 이어집니다. 되풀이해 보면 다시 나오지 않는 결과가 많은데, 그것은 드문 부정으로는 풀이되지 않습니다 → «It is explained by ordinary practices that each seemed harmless.»(그것은 하나하나는 해롭지 않아 보인 여느 관행들로 풀이된다.) → 여러 결과 가운데 유의한 것만 알린 연구자도, 놀라운 결과만 싣는 학술지도 'has not lied'(거짓말한 것이 아니다) → «the problem was never honesty»(문제는 한 번도 정직함이 아니었다).",
 "2) 꺾이는 곳: 셋째 문장입니다. 바로 앞에서 부정이라는 풀이를 버리고('not explained by fraud'), 여기서 참된 까닭을 내놓습니다. 다섯째 문장이 그 결과를 말합니다. «the published record overrepresents flukes»(발표된 기록은 우연히 나온 결과를 실제보다 많이 담는다). 우연은 그 뜻부터 놀라운 것이라 실리기 쉽기 때문입니다. 여섯째 문장이 고침의 성질을 말합니다. «The reforms that followed are procedural rather than moral.»(뒤따른 고침은 도덕이 아니라 절차의 것이다.)",
 "3) 끝 문장: 끝쪽의 두 문장이 글을 못 박습니다. «None of this makes science more honest, because the problem was never honesty.»(이 가운데 어느 것도 과학을 더 정직하게 만들지 않는다. 문제는 한 번도 정직함이 아니었기 때문이다.) «It makes the published record a less biased sample of the research that was actually conducted.»(그것은 발표된 기록을, 실제로 한 연구의 덜 치우친 견본으로 만든다.) 맨 끝 문장은 그 고침이 낳은 결과와 팔기 어려운 까닭을 덧붙입니다.",
 "4) 묶기: 'A Biased Record'(치우친 기록) = 'the published record overrepresents flukes', 'a less biased sample'의 반대쪽. 'Practices That Nobody Considered Dishonest'(아무도 부정직하다고 여기지 않은 관행) = 'ordinary practices that each seemed harmless', 'has not lied'. 'harmless'(해롭지 않은)가 'Nobody Considered Dishonest'로 바뀌었습니다. 제목의 앞쪽이 결과, 뒤쪽이 까닭입니다."],
 "「일부러 한 속임: 과학 부정이 더 흔해진 까닭」이 가장 위험합니다. 결과가 다시 나오지 않는다고 하면 속임수부터 떠오릅니다. 하지만 글은 그 풀이를 바로 버렸습니다. 부정은 여전히 드물다('fraud, which remains rare')고 했습니다. 방향이 거꾸로입니다. 「약한 연구의 풀이로서의 더 큰 표본」도 조심합니다. 더 큰 표본은 고침 넷 가운데 하나로 한 문장 나올 뿐입니다.",
 [("약한 연구의 풀이로서의 더 큰 표본", "글의 한 대목만 담았습니다. 더 큰 표본과 자료 나누기가 결과를 덜 깨지기 쉽게 한다는 말이 아홉째 문장에 나옵니다. 그것은 미리 적어 두기, 미리 받아 주기와 함께 나온 고침 가운데 하나입니다. 글은 어느 하나를 풀이로 내세우지 않고, 그 고침들이 함께 발표된 기록을 덜 치우치게 만든다고 했습니다."),
  ("여러 연구실이 한꺼번에: 심리학의 되풀이 연구는 어떻게 꾸려졌는가", "글 앞쪽의 낱말을 빌려 왔습니다. 심리학과 암 생물학의 큰 되풀이 연구가 절반도 다시 얻지 못했다는 말이 있습니다. 하지만 그 연구들이 어떻게 꾸려졌는지는 지문에 없습니다. 그 한 줄은 문제가 있다는 것을 알리는 들머리입니다."),
  ("유의성 문턱의 통계적 뜻", "지문에 없는 이야기입니다. 유의한 결과만 알린다는 말이 나오지만, 유의성이 통계로 무엇을 뜻하는지를 풀이하는 글이 아닙니다. 글의 눈은 통계의 뜻이 아니라, 어떤 결과가 실리고 어떤 결과가 빠지느냐에 있습니다."),
  ("아무도 부정직하다고 여기지 않은 관행이 낳은 치우친 기록", "셋째 문장 «It is explained by ordinary practices that each seemed harmless.»와 다섯째 문장의 «the published record overrepresents flukes»가 근거입니다. 유의한 결과만 알리는 연구자도, 놀라운 결과만 싣는 학술지도 거짓말을 한 것이 아닙니다. 하지만 둘이 만나면 발표된 기록이 우연 쪽으로 치우칩니다. 'ordinary practices that each seemed harmless'가 'Practices That Nobody Considered Dishonest'로 바뀌었습니다."),
  ("일부러 한 속임: 과학 부정이 더 흔해진 까닭", "글과 거꾸로입니다. 결과가 다시 나오지 않는다는 말에서 속임수를 떠올리기 쉽습니다. 하지만 글은 그 모자람이 부정으로 풀이되지 않고, 부정은 여전히 드물다고 했습니다. 끝에서도 문제는 한 번도 정직함이 아니었다고 했습니다. 글이 맨 먼저 버린 풀이를 제목으로 삼은 것입니다.")])

# ---------- 21번째: 재료가 이미 남이 나아지게 해 놓은 것일 때, 무엇이 발명인가 ----------
mk(20, 1, [
 "1) 되풀이: 「씨앗을 누가 쥐느냐」를 두고 두 쪽의 말이 맞섭니다. 사 가야 하는 품종이 나오면서 «the shift in who controls the beginning of the growing cycle»(기르기의 첫머리를 누가 쥐느냐의 바뀜)이 일어났고, 특허가 그것을 더 밀었습니다. 편드는 쪽은 품종 하나에 열 해가 걸리니 홀로 쥘 권리가 없으면 아무도 돈을 대지 않는다고 합니다. 비판하는 쪽은 «the arrangement privatizes an inheritance while charging for access to it»(그 짜임이 물려받은 것을 제 것으로 만들고는 거기에 닿는 값을 받는다)라고 합니다.",
 "2) 꺾이는 곳: 여덟째 문장입니다. «The dispute persists because it is not really about seeds.»(그 다툼이 이어지는 것은, 그것이 사실은 씨앗에 관한 것이 아니기 때문이다.) 앞의 일곱 문장은 두 쪽의 말을 나란히 놓은 바탕입니다. 여기서 글쓴이가 다툼의 참모습을 내놓습니다. 씨앗이 아니라면 무엇에 관한 다툼인지가 다음 문장에 나옵니다.",
 "3) 끝 문장: 끝에서 두 번째 문장이 그 답입니다. «It concerns what counts as an invention when the material being improved is itself the product of uncredited work.»(그것은, 나아지게 하는 그 재료가 이름 없이 한 일의 결과물일 때 무엇을 발명으로 치느냐에 관한 것이다.) 맨 끝 문장이 덧붙입니다. 어느 쪽도 사실은 다투지 않습니다. 그래서 수십 해의 협상이 뜻 모음이 아니라 절차만 낳았습니다.",
 "4) 묶기: 제목이 끝에서 두 번째 문장을 거의 그대로 옮겼습니다. 'What Counts as an Invention'(무엇이 발명으로 쳐지는가) = 'what counts as an invention'. 'When the Material Was Already Improved'(재료가 이미 나아져 있던 것일 때) = 'the material being improved is itself the product of uncredited work'. 농부들이 여러 세기에 걸쳐 길러 온 토박이 품종이 그 재료입니다. 제목은 어느 쪽 편도 들지 않고, 다툼이 무엇에 관한 것인지만 말합니다."],
 "「농부가 씨앗을 마음대로 받아 두게 해야 하는 까닭」이 가장 위험합니다. 비판하는 쪽의 말이 더 길고 마음이 가기 쉬워서, 글이 농부 편을 든다고 읽기 쉽습니다. 하지만 글은 두 쪽을 나란히 놓았고, 어느 쪽도 사실을 다투지 않는다고 했습니다. 'Should'는 글이 하지 않은 주장입니다. 「밭에서 실험실로: 지난 백 해의 식물 품종 만들기 역사」도 조심합니다. 글 앞쪽이 옛날에서 지금으로 흘러서 역사처럼 보이지만, 그것은 다툼을 알아듣게 하려는 바탕입니다.",
 [("밭에서 실험실로: 지난 백 해의 식물 품종 만들기 역사", "글 앞쪽의 바탕 이야기만 붙잡았습니다. 농부가 씨앗을 받아 두던 때에서 사 가야 하는 품종으로 바뀌었다는 흐름이 앞에 나옵니다. 하지만 글은 품종 만들기의 역사를 훑지 않습니다. 그 바뀜이 낳은 다툼, 그리고 그 다툼이 참으로 무엇에 관한 것인지로 나아갑니다. 실험실도, 백 해라는 말도 지문에 없습니다."),
  ("재료가 이미 나아져 있던 것일 때 무엇이 발명인가", "여덟째 문장 «The dispute persists because it is not really about seeds.»와 아홉째 문장 «It concerns what counts as an invention when the material being improved is itself the product of uncredited work.»가 근거입니다. 보호받는 품종은 농부들이 여러 세기에 걸쳐 길러 온 품종에서 나왔습니다. 그래서 다툼은 씨앗이 아니라, 남이 나아지게 해 놓은 재료를 더 나아지게 한 것을 발명으로 칠 수 있느냐에 있습니다. 제목이 아홉째 문장을 거의 그대로 옮겼습니다."),
  ("잡종 품종은 어떻게 어버이보다 더 많이 거두게 하는가", "지문에 없는 이야기입니다. 새 품종이 훨씬 많이 거두게 한다는 말은 있지만, 어떻게 그렇게 되는지는 한 줄도 없습니다. 글의 눈은 품종의 생물학이 아니라 그 품종을 누가 쥐느냐에 있습니다. 낱말만 빌려 온 제목입니다."),
  ("나라를 넘는 규칙: 농산물 거래를 다스리는 국제 협정", "글의 한 대목만 담았고, 이야기도 다릅니다. 국제 협정이 이득 나누기 기금으로 가운데 길을 찾으려 했다는 말이 한 번 나옵니다. 그것은 다툼이 풀리지 않았다는 것을 보이려는 한 줄입니다. 농산물 거래를 다스리는 협정은 지문에 없습니다."),
  ("농부가 씨앗을 마음대로 받아 두게 해야 하는 까닭", "글이 하지 않은 센 주장입니다. 비판하는 쪽의 말을 글쓴이의 말로 읽으면 고르게 됩니다. 하지만 글은 편드는 쪽의 말도 나란히 실었습니다. 품종 하나에 열 해가 걸리고, 홀로 쥘 권리가 없으면 돈을 댈 사람이 없다는 것입니다. 글은 어느 쪽도 사실을 다투지 않는다('Neither side disputes the facts')고 했을 뿐, 한쪽 손을 들어 주지 않았습니다.")])

# ---------- 22번째: 박수와 평점은 합이 아니라 사슬이고, 합계를 가리면 얻는 것과 잃는 것이 있다 ----------
mk(21, 4, [
 "1) 되풀이: 「저마다 따로 매긴 것의 합처럼 보이지만, 사실은 앞사람을 따라가는 사슬」이라는 생각이 이어집니다. «by contagion rather than by evaluation»(매겨서가 아니라 옮아서) → «the length of an ovation carries almost no information about quality»(박수가 이어지는 길이는 솜씨에 대해 거의 아무것도 알려 주지 않는다) → «a signal that participants read as an aggregate of independent judgements when it is in fact a chain»(사람들은 따로 내린 판단들의 합으로 읽지만 사실은 사슬인 신호).",
 "2) 꺾이는 곳: 두 군데입니다. 여섯째 문장의 'Each case involves'(어느 경우에나 ~이 들어 있다)에서 박수, 온라인 평점, 기부가 한 가지 꼴로 묶입니다. 그리고 여덟째 문장에서 글이 한 번 꺾입니다. «What remains difficult is that the chain also does something valuable»(여전히 어려운 것은, 그 사슬이 값진 일도 한다는 점이다). 낯선 사람들로 가득 찬 방을, 혼자서는 아무도 하지 않을 한 가지 몸짓으로 묶어 줍니다.",
 "3) 끝 문장: «Removing the cue entirely would produce more accurate ratings and colder rooms»(그 실마리를 아예 없애면 평점은 더 정확해지고 방은 더 차가워질 것이다). 얻는 것과 잃는 것이 한 문장에 나란히 있습니다. 글은 없애자고도, 그대로 두자고도 하지 않습니다. 합계를 가리면 무엇이 달라지는지를 양쪽으로 보여 줍니다.",
 "4) 묶기: 콜론 앞 'A Chain Mistaken for a Sum'(합으로 잘못 읽힌 사슬) = 'read as an aggregate of independent judgements when it is in fact a chain'. 'aggregate'(합)가 'Sum'으로, 'read as'(~으로 읽다)가 'Mistaken for'(~으로 잘못 알다)로 바뀌었습니다. 콜론 뒤 'What Hiding the Total Changes'(합계를 가리면 무엇이 달라지는가) = 'hide the running total'(쌓여 가는 합계를 가린다) + 끝 문장의 얻는 것과 잃는 것. 콜론 앞이 글의 앞 절반, 콜론 뒤가 뒤 절반입니다."],
 "「온라인 평점 체계를 없애야 하는 까닭」이 가장 위험합니다. 평점이 사슬일 뿐이라니 없애자는 말로 읽기 쉽습니다. 하지만 글이 든 것은 없애기가 아니라 합계를 가리거나 차례를 섞는 것이고, 그 사슬이 값진 일도 한다고 했습니다. 'Should Be Abolished'는 글이 하지 않은 센 주장입니다. 「공연장에서 박수가 이어지는 길이 재기」도 조심합니다. 박수의 길이는 글의 들머리이고, 글은 그것이 솜씨를 알려 주지 않는다는 데서 더 넓은 이야기로 갑니다.",
 [("듣는 이들은 빼어난 음악 공연에 어떻게 반응하는가", "글과 방향이 다릅니다. 글은 박수가 무대에서 벌어진 일이 아니라 둘레의 소리 크기에 따라 정해진다고 했습니다. 공연이 빼어난지와 박수는 거의 상관이 없다는 것이 글의 말입니다. 빼어난 공연에 대한 반응을 다루는 제목은 글이 뒤집은 생각 쪽에 서 있습니다."),
  ("공연장에서 박수가 이어지는 길이 재기", "글의 한 대목만 담았습니다. 수백 번의 공연을 녹음해 알아냈다는 말과 박수의 길이 이야기는 글 앞쪽에 나옵니다. 하지만 재는 법을 알려 주는 글이 아닙니다. 글은 그 길이가 솜씨를 알려 주지 않는다는 데서 출발해, 온라인 평점과 기부까지 같은 꼴로 묶습니다."),
  ("모르는 채로 주기: 기부의 심리", "글의 한 대목만 담았습니다. 알려진 기부가 뒤의 기부를 움직인다는 말이 다섯째 문장에 한 번 나옵니다. 그것은 박수와 같은 꼴을 보이는 본보기 셋 가운데 하나입니다. 기부의 심리를 다루는 글이 아닙니다."),
  ("온라인 평점 체계를 없애야 하는 까닭", "글이 하지 않은 센 주장입니다. 처음의 좋은 표 하나가 끝 점수를 크게 올린다고 했으니 없애자는 글로 읽기 쉽습니다. 하지만 글이 든 대응은 평가가 끝날 때까지 합계를 가리거나 차례를 섞는 것입니다. 그리고 사슬이 값진 일도 한다('does something valuable')고 했습니다. 'Abolished'는 글보다 훨씬 나아간 말입니다."),
  ("합으로 잘못 읽힌 사슬: 합계를 가리면 무엇이 달라지는가", "여섯째 문장의 «a signal that participants read as an aggregate of independent judgements when it is in fact a chain»과 끝 문장의 «more accurate ratings and colder rooms»가 근거입니다. 박수도 평점도 따로 내린 판단의 합이 아니라 앞사람을 따라가는 사슬입니다. 합계를 가리면 더 정확해지지만, 사슬이 해 주던 묶어 주는 일도 사라집니다. 'aggregate'가 'Sum'으로 바뀌었습니다.")])

# ---------- 23번째: 익숙한 시간표가 살펴지지 않은 채 몸의 정책 노릇을 해 왔다 ----------
mk(22, 2, [
 "1) 되풀이: 「시간표가 몸의 때와 어긋나는데, 그것이 고른 것으로 여겨지지 않는다」는 생각이 이어집니다. «Institutions are built around the earlier pattern»(제도는 이른 쪽에 맞춰 지어져 있다) → 등교 때는 «chosen for reasons unrelated to adolescents»(청소년과 상관없는 까닭으로 고른) 것입니다 → «a familiar timetable has been functioning as a biological policy without ever being examined as one»(익숙한 시간표가, 한 번도 그런 것으로 살펴진 적 없이, 몸에 관한 정책 노릇을 해 왔다).",
 "2) 꺾이는 곳: 여섯째 문장입니다. «The change is nonetheless resisted, and the objections are almost never about learning.»(그런데도 그 바꿈은 반대에 부딪히고, 반대하는 까닭은 배움에 관한 것이 거의 아니다.) 앞쪽은 바탕입니다. 몸 시계는 타고나고, 등교를 한 시간 늦춘 곳에서는 출석과 성적이 나아지고 사고가 줄었습니다. 여덟째 문장이 'not'으로 한쪽을 버립니다. 연구가 한 일은 십대가 피곤하다는 것을 찾아낸 것이 아닙니다.",
 "3) 끝 문장: «That reframing, rather than any new finding about adolescent biology, is what has moved districts to act.»(청소년의 몸에 관한 새 발견이 아니라 그 틀 바꾸기가, 교육구들을 움직이게 한 것이다.) 'A rather than B' 틀입니다. 시간표를 「고른 것」으로 보게 되자, 그 시각은 여느 고르기처럼 값을 따져 볼 수 있는 것이 되었습니다.",
 "4) 묶기: 제목이 아홉째 문장을 거의 그대로 옮겼습니다. 'A Timetable'(시간표) = 'a familiar timetable'. 'Has Been Setting Biological Policy'(몸의 정책을 정해 왔다) = 'has been functioning as a biological policy'. 'Unexamined'(살펴지지 않은 채) = 'without ever being examined as one'. 'functioning as'가 'Setting'으로 바뀌었습니다."],
 "「십대가 지금보다 일찍 자야 하는 까닭」이 가장 위험합니다. 십대의 잠 이야기라 익숙한 타이름으로 읽기 쉽습니다. 하지만 글은 정반대 쪽에 서 있습니다. 몸 시계의 다름은 타고난 것이고 버릇을 들여도 그대로라고 했습니다('persists regardless of discipline'). 바꿀 것은 십대가 자는 때가 아니라 학교가 여는 때입니다. 「길 위 사고의 까닭인 잠 모자람」도 조심합니다. 학생 운전자의 사고가 줄었다는 것은 증거 셋 가운데 하나일 뿐입니다.",
 [("종달새와 올빼미: 타고난 몸 시계의 다름은 어떻게 재는가", "글 앞쪽의 바탕 이야기만 붙잡았습니다. 몸 시계가 사람마다 다르고 그것이 타고난다는 말은 첫머리에 나옵니다. 하지만 그것을 어떻게 재는지는 지문에 없습니다. 글은 그 다름을 바탕으로 삼아, 시간표가 한쪽에만 맞춰져 있다는 데로 나아갑니다."),
  ("길 위 사고의 까닭인 잠 모자람", "글의 한 대목만 담았습니다. 등교를 늦춘 곳에서 학생 운전자의 사고가 크게 줄었다는 말이 다섯째 문장에 나옵니다. 그것은 출석, 성적과 함께 나온 증거 셋 가운데 하나입니다. 길 위 사고를 다루는 글이 아닙니다."),
  ("살펴지지 않은 채 몸의 정책을 정해 온 시간표", "아홉째 문장 «It is to show that a familiar timetable has been functioning as a biological policy without ever being examined as one.»이 근거입니다. 등교 때는 청소년과 상관없는 까닭으로 정해졌는데, 그것이 누가 제 몸의 밤에 일어나야 하는지를 정해 왔습니다. 아무도 그것을 정책으로 살펴본 적이 없습니다. 'without ever being examined'가 'Unexamined'로 바뀌었습니다."),
  ("십대가 지금보다 일찍 자야 하는 까닭", "글과 거꾸로인 센 주장입니다. 십대의 잠이라는 글감에서 떠올리기 쉬운 타이름입니다. 하지만 글은 늦게 깨어나는 쪽이 버릇의 탓이 아니라 타고난 것이라고 했습니다. 그들은 몸의 밤에 자명종으로 일어나는 것입니다. 글이 바꾸자고 한 것은 자는 때가 아니라 학교의 시간표입니다. 'Should'는 글에 없습니다."),
  ("버스와 연습: 학교 통학과 운동부의 짜임", "글의 한 대목만 담았습니다. 버스 시간표와 운동부 연습은 등교를 늦추는 데 반대하는 까닭으로 일곱째 문장에 나옵니다. 그것들이 어떻게 짜이는지는 지문에 없습니다. 글은 그 까닭들이 배움과 상관없다는 것을 짚으려고 들었을 뿐입니다.")])

# ---------- 24번째: 불빛을 알아보게 하는 것은 닿는 거리가 아니라 깜박임의 가락이다 ----------
mk(23, 0, [
 "1) 되풀이: 「불빛을 알아보게 하는 것은 밝기가 아니라 깜박임의 꼴」이라는 생각이 이어집니다. «Brightness cannot answer the question.»(밝기는 그 물음에 답하지 못한다.) → «What distinguishes one from another is the pattern in which it appears and disappears»(하나를 다른 것과 가르는 것은 불빛이 나타났다 사라지는 꼴이다) → 등의 세기를 키워도 «added nothing whatever to the question the mariner was asking»(뱃사람이 묻는 물음에는 아무것도 보태지 못했다).",
 "2) 꺾이는 곳: 둘째 문장과 넷째 문장입니다. 첫 문장이 물음을 던집니다. 밤에 낯선 바닷가로 다가가는 뱃사람은 저 불빛이 어느 불빛인지를 알아야 합니다. 둘째 문장이 밝기를 버리고, 넷째 문장이 답을 내놓습니다. 깜박임의 꼴입니다. 여덟째 문장에서 한 번 더 넘어갑니다. «The principle survives the technology.»(그 원리는 기술이 바뀌어도 살아남는다.) 등대가 저절로 돌아가고 위성이 자리를 알려 주어도, 깜박임의 꼴은 여전히 발표되고 바닷가마다 하나뿐입니다.",
 "3) 끝 문장: «The identifying property was never the one that made the light impressive.»(알아보게 해 주는 성질은 한 번도 그 불빛을 대단해 보이게 하는 성질이 아니었다.) 대단해 보이게 하는 것은 밝기와 닿는 거리이고, 알아보게 하는 것은 가락입니다. 글 전체가 이 한 줄로 모입니다.",
 "4) 묶기: 콜론 앞 'Rhythm, Not Reach'(닿는 거리가 아니라 가락) = 'the pattern in which it appears and disappears', 'the rhythms'(가락들)와 'extended the distance from which it could be seen'(보이는 거리를 늘렸다)의 맞섬. 'Reach'(닿는 거리)는 지문에 없는 낱말로, 불빛이 얼마나 멀리 보이느냐를 가리킵니다. 콜론 뒤 'How a Light at Sea Is Actually Identified'(바다의 불빛은 실제로 어떻게 알아보는가) = 'needs to know which light it is', 'The identifying property'."],
 "「요즘의 길 찾기에 등대가 더는 쓸모없는 까닭」이 가장 위험합니다. 위성이 자리를 바로 알려 준다는 말에서 그렇게 넘겨짚기 쉽습니다. 하지만 글은 정반대로 말했습니다. 깜박임의 꼴은 지금도 발표되고, 전자 장비가 탈 난 배들이 그것을 확인합니다. 원리가 살아남는다는 것이 글의 말입니다. 「렌즈와 탑: 바닷가 불빛의 공학 역사」, 등불 기술을 담은 제목은 기술 쪽 이야기인데, 글은 기술이 아니라 알아보는 원리를 말합니다.",
 [("닿는 거리가 아니라 가락: 바다의 불빛은 실제로 어떻게 알아보는가", "넷째 문장 «What distinguishes one from another is the pattern in which it appears and disappears»와 끝 문장 «The identifying property was never the one that made the light impressive.»가 근거입니다. 같은 등도 안개 속에서는 흐리고 맑은 밤에는 밝으니, 밝기로는 어느 등인지 알 수 없습니다. 뱃사람은 깜박임을 시계로 재어 압니다. 세기를 키우면 멀리서 보일 뿐입니다. 'the pattern'이 'Rhythm'으로 바뀌었습니다."),
  ("렌즈와 탑: 바닷가 불빛의 공학 역사", "지문에 없는 이야기입니다. 등대가 나오지만 렌즈도 탑도, 그것이 어떻게 지어져 왔는지도 나오지 않습니다. 글은 오히려 그 원리가 기술이 바뀌어도 살아남는다고 했습니다. 글의 눈은 기계가 아니라 불빛을 알아보는 길에 있습니다."),
  ("요즘의 길 찾기에 등대가 더는 쓸모없는 까닭", "글과 거꾸로입니다. 위성 수신기가 자리를 바로 알려 준다는 말이 나오니 그렇게 읽기 쉽습니다. 하지만 같은 문장이 깜박임의 꼴은 여전히 발표되고 전자 장비가 탈 난 배들이 그것을 확인한다('still checked')고 했습니다. 더는 쓸모없다는 말은 지문과 부딪힙니다."),
  ("등불 기술은 두 세기 동안 어떻게 나아졌는가", "지문에 없는 이야기입니다. 등의 세기를 키웠다는 말은 있지만, 그것은 세기를 키워도 어느 등인지는 알 수 없다는 것을 말하려는 것입니다. 기술이 어떻게 나아졌는지를 훑는 글이 아닙니다. 두 세기라는 말도 지문에 없습니다."),
  ("바닷가의 옛 건물 지키기", "지문에 없는 이야기입니다. 등대를 옛 건물로 지키는 일은 나오지 않습니다. 등대라는 글감에서 떠올린 것일 뿐, 글이 다루는 것은 불빛을 알아보는 원리입니다.")])

# ---------- 25번째: 종의 음은 붓기 전에 정해지고, 부은 뒤에는 고칠 수 없다 ----------
mk(24, 1, [
 "1) 되풀이: 「음은 쇠를 붓기 전에 정해지고, 부은 뒤에는 고칠 수 없다」는 생각이 이어집니다. «A bell is tuned before any metal is melted.»(종은 쇠를 녹이기도 전에 음이 맞춰진다.) → «What follows cannot easily be undone.»(그 뒤의 일은 쉽게 되돌릴 수 없다.) → «A bell that emerges sharp cannot be corrected at all.»(음이 높게 나온 종은 아예 고칠 수 없다.) → «treat the casting as the moment when the decisions become permanent»(붓는 때를 그 결정들이 굳어지는 때로 여긴다).",
 "2) 꺾이는 곳: 둘째 문단의 첫머리입니다. 붓는 일 자체는 몇 분이면 끝납니다. 그 바로 뒤에 «What follows cannot easily be undone.»이 옵니다. 첫 문단이 「미리 정한다」 쪽이고, 둘째 문단이 「뒤에는 못 고친다」 쪽입니다. 음이 낮게 나온 종은 안쪽 쇠를 깎아 올릴 수 있지만 그것은 되돌릴 수 없고, 깎을 때마다 이미 맞던 다른 소리들이 어긋납니다.",
 "3) 끝 문장: «the skill they guarded was arithmetic rather than metallurgy»(그들이 지킨 솜씨는 쇠 다루기가 아니라 셈이었다). 'A rather than B' 틀입니다. 살아남은 주물 공방은 처음에 맞게 하는 법을 익힌 곳입니다. 뒤에 고칠 수 없으니, 솜씨는 붓기 전의 셈에 있습니다. 첫 문장과 끝 문장이 같은 말을 합니다.",
 "4) 묶기: 'A Note Fixed in the Mould'(틀에서 정해지는 음) = 'tuned before any metal is melted', 'the decisions become permanent'. 'Beyond Correction Afterwards'(그 뒤에는 고칠 수 없는) = 'cannot easily be undone', 'cannot be corrected at all', 'irreversible'. and 앞이 첫 문단, and 뒤가 둘째 문단입니다. 'Mould'(틀)는 이 지문에 없는 낱말로, 붓기 전에 그려 둔 옆모습대로 만든 틀을 가리킵니다."],
 "「쇠붙이의 성분은 악기에 어떤 영향을 주는가」가 조심할 선택지입니다. 종소리는 쇠에 달렸다는 상식에 끌립니다. 하지만 글은 끝 문장에서 그쪽을 버렸습니다. 솜씨는 쇠 다루기가 아니라 셈이라고 했습니다. 「장인과 작업장: 유럽 종 만들기의 솜씨 전통」도 조심합니다. 주물 공방과 솜씨라는 말이 끝에 나오지만, 글은 전통을 훑지 않고 음이 언제 정해지는지를 말합니다.",
 [("녹여서 붓기: 교회 종을 두드려 만들지 않고 부어 만드는 까닭", "지문에 없는 이야기입니다. 쇠를 녹여 붓는다는 말은 있지만, 두드려 만드는 것과 견준 적은 없습니다. 글의 물음은 왜 붓느냐가 아니라, 음이 언제 정해지고 뒤에 고칠 수 있느냐입니다. 교회라는 말도 지문에 없습니다."),
  ("틀에서 정해지고 그 뒤에는 고칠 수 없는 음", "첫 문장 «A bell is tuned before any metal is melted.»와 다섯째 문장 «What follows cannot easily be undone.»이 근거입니다. 종 만드는 사람은 붓기 전에 벽의 두께를 곳곳마다 셈해 음을 정합니다. 부은 뒤에는 낮은 음만 깎아서 올릴 수 있고, 그것도 다른 소리를 흩뜨립니다. 높게 나오면 고칠 수 없습니다. 'cannot be corrected'가 'Beyond Correction'으로 바뀌었습니다."),
  ("내려오는 주물 일의 기울어 감", "지문 낱말에서 떠올린, 지문에 없는 이야기입니다. 산업 시대까지 살아남은 주물 공방이라는 말이 끝에 나옵니다. 하지만 글은 주물 일이 기울어 갔다고 하지 않았습니다. 살아남은 곳이 어떤 곳이었는지를 말했을 뿐입니다. 처음에 맞게 하는 법을 익힌 곳입니다."),
  ("장인과 작업장: 유럽 종 만들기의 솜씨 전통", "글 끝의 낱말을 빌려 왔습니다. 주물 공방과 그들이 지킨 솜씨라는 말이 끝 문장에 나옵니다. 하지만 글은 종 만들기의 전통을 훑지 않습니다. 유럽이라는 말도 없습니다. 그 솜씨가 무엇이었는지, 곧 셈이었다는 것을 말하려고 나온 한 줄입니다."),
  ("쇠붙이의 성분은 악기에 어떤 영향을 주는가", "글이 버린 쪽입니다. 종소리는 쇠에 달렸다는 상식으로 고르기 쉽습니다. 하지만 글에서 음을 정하는 것은 벽의 두께이고, 끝 문장은 솜씨가 쇠 다루기가 아니라 셈('arithmetic rather than metallurgy')이라고 했습니다. 쇠의 성분도, 다른 악기도 지문에 없습니다.")])

# ---------- 26번째: 콘이 재는 것은 온도가 아니라 시간에 걸쳐 쌓인 열이다 ----------
mk(25, 4, [
 "1) 되풀이: 「가마에서 중요한 것은 한때의 온도가 아니라 시간에 걸쳐 쌓인 열」이라는 생각이 이어집니다. «A potter firing a kiln is not trying to reach a temperature.»(가마에 불을 때는 도공은 어떤 온도에 이르려는 것이 아니다.) → «Clay and glaze respond to heat applied over time»(흙과 유약은 시간에 걸쳐 가해진 열에 반응한다) → «The cone integrates the whole firing in a way no instrument reading a single moment can.»(콘은 한때만 읽는 어떤 기기도 하지 못하는 식으로 불 때기 전체를 한데 모은다.)",
 "2) 꺾이는 곳: 셋째 문단의 첫 문장입니다. «Electric kilns with digital controllers have not displaced them.»(디지털 조절기가 달린 전기 가마도 콘을 밀어내지 못했다.) 새 기계가 나왔으니 옛 도구는 사라졌으리라는 생각을 꺾습니다. 조절기는 짜 둔 차례를 따를 뿐이고, 콘은 그 차례가 실제로 무엇을 주었는지를 알려 줍니다. 그것은 그릇을 얼마나 넣었는지, 가마 안 어디인지, 열선이 얼마나 낡았는지에 따라 달라집니다.",
 "3) 끝 문장: «Potters who trust the display and never place a cone discover the discrepancy when a glaze that worked for two years stops working and nothing visible has changed.»(화면만 믿고 콘을 놓지 않는 도공은, 두 해 동안 잘되던 유약이 눈에 보이는 바뀜도 없이 안 되기 시작할 때에야 그 어긋남을 알게 된다.) 온도 숫자는 그대로인데 결과가 달라집니다. 숫자가 재는 것과 그릇이 받은 것이 다르기 때문입니다.",
 "4) 묶기: 콜론 앞 'Heat Over Time'(시간에 걸친 열) = 'heat applied over time', 'a particular combination of heat and duration'(열과 시간의 어떤 어울림). 지문 낱말 그대로입니다. 콜론 뒤 'Temperature Is Not What the Cone Measures'(온도는 콘이 재는 것이 아니다) = 'not trying to reach a temperature', 'integrates the whole firing'. 온도계는 가마 안 공기를 알려 주고, 콘은 그릇이 받아들인 것을 알려 줍니다."],
 "「프로그램과 열선: 요즘 가마는 어떻게 한결같은 결과를 내는가」가 가장 위험합니다. 'programme'과 'elements'가 지문 낱말 그대로라 끌립니다. 하지만 방향이 거꾸로입니다. 글은 조절기가 따르는 차례와 실제로 준 것이 다르다고 했고, 화면만 믿으면 탈이 난다고 했습니다. 요즘 가마가 한결같다는 것은 글이 뒤집은 생각입니다. 「녹음과 빛깔: 도자기 유약의 화학」은 유약이라는 낱말만 빌려 왔습니다.",
 [("손으로 빚은 그릇이 공장 그릇보다 비싸게 팔리는 까닭", "지문에 없는 이야기입니다. 도공이 나오지만 그릇의 값도, 공장 그릇도 나오지 않습니다. 글이 다루는 것은 가마의 불 때기가 다 되었는지를 무엇으로 아느냐입니다."),
  ("녹음과 빛깔: 도자기 유약의 화학", "지문 낱말을 빌려 왔지만 이야기가 다릅니다. 유약이 시간에 걸친 열에 반응한다는 말은 있지만, 유약이 무엇으로 되어 있고 어떻게 빛깔을 내는지는 나오지 않습니다. 글의 눈은 유약의 성분이 아니라 불 때기를 가늠하는 길에 있습니다."),
  ("프로그램과 열선: 요즘 가마는 어떻게 한결같은 결과를 내는가", "글과 거꾸로입니다. 프로그램과 열선이 지문에 나와서 끌립니다. 하지만 글은 조절기가 따르는 차례와 실제로 준 것이 그릇의 양, 자리, 열선의 낡음에 따라 다르다고 했습니다. 화면만 믿은 도공은 잘되던 유약이 안 되는 것을 겪습니다. 한결같지 않다는 것이 글의 말입니다."),
  ("동아시아 도자기 만들기의 역사", "지문에 없는 이야기입니다. 어느 곳의 도자기인지도, 그 역사도 나오지 않습니다. 도자기라는 글감에서 떠올린 것일 뿐입니다."),
  ("시간에 걸친 열: 온도가 콘이 재는 것이 아닌 까닭", "첫 문장 «A potter firing a kiln is not trying to reach a temperature.»와 여섯째 문장 «The cone integrates the whole firing in a way no instrument reading a single moment can.»이 근거입니다. 흙과 유약은 한때의 온도가 아니라 시간에 걸쳐 받은 열에 따라 익습니다. 콘은 열과 시간의 어울림에 따라 휘도록 만들어져, 불 때기 전체를 한데 모아 보여 줍니다. 'heat applied over time'이 'Heat Over Time'으로 옮겨졌습니다.")])

# ---------- 27번째: 치즈 껍질은 덮는 것이 아니라 익히는 일을 하는 것이다 ----------
mk(26, 4, [
 "1) 되풀이: 「껍질은 싸개가 아니라 익어 가는 일의 한 몫」이라는 생각이 이어집니다. «The surface of a maturing cheese is frequently mistaken for packaging.»(익어 가는 치즈의 겉은 흔히 싸개로 잘못 여겨진다.) → «It is an organ of the process.»(그것은 그 과정의 한 기관이다.) → «The wrapping is not a cheaper rind; it is the absence of one»(그 싸개는 더 싼 껍질이 아니다. 껍질이 없는 것이다).",
 "2) 꺾이는 곳: 첫 두 문장입니다. 첫 문장이 흔한 생각을 내놓고('mistaken for'), 둘째 문장이 곧바로 그것을 바로잡습니다. 그 뒤가 껍질이 하는 일입니다. 물기는 껍질을 거쳐 빠져나가고, 익히는 사람은 껍질을 씻고 솔질하고 곰팡이를 앉혀서 그 빠르기를 다스립니다. 너무 빨리 마르면 겉이 막혀 속이 굳지 않고, 너무 축축하면 치즈가 겉에서부터 무릅니다.",
 "3) 끝 문장: «The wrapping is not a cheaper rind; it is the absence of one, and the product is a different food that happens to begin the same way.»(그 싸개는 더 싼 껍질이 아니다. 껍질이 없는 것이고, 그렇게 나온 것은 시작만 같을 뿐인 다른 먹거리다.) 비닐로 싼 어린 치즈는 덮여 있기만 합니다. 덮는 것과 일하는 것의 맞섬이 끝에서 한 번 더 나옵니다.",
 "4) 묶기: 'Doing Something'(무언가를 하고 있는) = 'an organ of the process'(그 과정의 한 기관), 물기가 껍질을 거쳐 빠져나간다는 셋째 문장. 'Rather Than Covering Something'(무언가를 덮는 것이 아니라) = 'mistaken for packaging'(싸개로 잘못 여겨진다), 'The wrapping is not a cheaper rind'. 'organ'이 'Doing Something'으로, 'packaging'이 'Covering Something'으로 바뀌었습니다. 제목이 첫 두 문장의 맞섬을 그대로 담았습니다."],
 "「굳은 젖에서 둥근 덩이로: 작은 농장에서 젖으로 치즈를 만드는 법」이 조심할 선택지입니다. 치즈 이야기라 만드는 법을 떠올리기 쉽습니다. 하지만 글은 젖에서 치즈가 되는 과정을 다루지 않습니다. 익어 가는 동안 껍질이 하는 일 하나만 다룹니다. 글보다 훨씬 넓은 제목입니다. 「통 속의 균: 요즘 젖 가공에 쓰이는 세균」은 곰팡이와 균이라는 낱말에서 떠올린 것일 뿐입니다.",
 [("내려오는 먹거리가 유럽에서 사라지는 까닭", "지문에 없는 이야기입니다. 비닐로 싸서 파는 어린 치즈가 나오지만, 내려오는 먹거리가 사라진다는 말도 유럽이라는 말도 없습니다. 글은 그 치즈가 다른 먹거리라고 했을 뿐입니다."),
  ("통 속의 균: 요즘 젖 가공에 쓰이는 세균", "지문 낱말에서 떠올린 다른 이야기입니다. 껍질에 곰팡이를 앉힌다는 말과 치즈를 무르게 하는 균이 들어온다는 말은 있습니다. 하지만 젖 가공에 어떤 세균을 쓰는지는 나오지 않습니다. 글의 눈은 균이 아니라 껍질이 물기를 내보내는 일에 있습니다."),
  ("익히지 않은 젖으로 만든 것의 판매를 다스리는 규정", "지문에 없는 이야기입니다. 규정도, 익히지 않은 젖도 나오지 않습니다. 치즈라는 글감에서 떠올린 것일 뿐입니다."),
  ("굳은 젖에서 둥근 덩이로: 작은 농장에서 젖으로 치즈를 만드는 법", "글보다 넓은 제목입니다. 치즈 이야기라 만드는 법으로 읽기 쉽습니다. 하지만 글은 젖을 굳히는 일도, 덩이를 빚는 일도 다루지 않습니다. 이미 빚은 치즈가 익어 가는 동안 껍질이 무슨 일을 하는지만 다룹니다. 농장이라는 말도 지문에 없습니다."),
  ("무언가를 덮는 것이 아니라 무언가를 하고 있는 껍질", "첫 문장 «The surface of a maturing cheese is frequently mistaken for packaging.»과 둘째 문장 «It is an organ of the process.»가 근거입니다. 껍질은 물기가 빠져나가는 길이고, 그 빠르기가 여섯 달 뒤 속의 결을 정합니다. 비닐 싸개는 더 싼 껍질이 아니라 껍질이 없는 것입니다. 'an organ of the process'가 'Doing Something'으로 바뀌었습니다.")])

# ---------- 28번째: 악보의 사이 띄우기는 꾸밈이 아니라 읽는 눈에 일러 주는 말이다 ----------
mk(27, 1, [
 "1) 되풀이: 「악보의 사이 띄우기는 꾸밈이 아니라 읽는 눈을 이끄는 구실」이라는 생각이 이어집니다. «spaced notes according to their duration rather than fitting them evenly across the stave»(음표를 줄 위에 고르게 맞춰 넣지 않고 그 길이에 따라 사이를 띄웠다) → «the eye travels at a rate matching the music»(눈이 음악에 맞는 빠르기로 나아간다) → «None of it is decoration»(그 어느 것도 꾸밈이 아니다).",
 "2) 꺾이는 곳: 셋째 문장입니다. «The convention is invisible to anyone not looking for it and unmistakable when it is absent.»(그 관례는 찾아보지 않는 사람에게는 보이지 않고, 없을 때에는 틀림없이 드러난다.) 뒤가 그 본보기입니다. 초기의 컴퓨터 조판은 기호를 고르게 띄웠고, 연주자들은 까닭도 대지 못한 채 읽기 어렵다고 했습니다. 출판사들은 새긴 악보를 본뜨는 쪽으로 돌아갔습니다.",
 "3) 끝 문장: «None of it is decoration, and all of it was arrived at by people who watched musicians fail to read something and changed it.»(그 어느 것도 꾸밈이 아니고, 그 모두가 연주자가 무언가를 읽지 못하는 것을 지켜보고 그것을 고친 사람들이 이른 것이다.) 사이 띄우기만이 아닙니다. 이음줄이 살짝 올라가는 것, 손이 비는 곳에 놓인 쪽 넘김도 같은 식으로 일합니다.",
 "4) 묶기: 'Spacing'(사이 띄우기) = 'spaced notes according to their duration'. 'Carries Instructions'(일러 주는 말을 싣고 있다) = 'the eye travels at a rate matching the music'. 사이가 넓고 좁은 것이 눈에게 얼마나 빨리 가라고 일러 줍니다. 'A Page'(한 쪽) = 'Much else on the page works the same way'(그 쪽의 다른 많은 것도 같은 식으로 일한다). 'Instructions'는 지문에 없는 낱말로, 「꾸밈이 아니다」를 뒤집어 말한 것입니다."],
 "「디지털 악보가 인쇄 악보를 밀어낸 까닭」이 가장 위험합니다. 컴퓨터 조판이 나오니 그렇게 넘겨짚기 쉽습니다. 하지만 글에서 일어난 일은 그 반대입니다. 초기의 컴퓨터 조판은 읽기 어려웠고, 출판사들은 새긴 악보를 본뜨는 쪽으로 돌아갔습니다. 밀어낸 것이 아니라 옛 규칙을 다시 배운 것입니다. 「인쇄술의 발명과 유럽으로의 퍼짐」은 인쇄된 악보라는 낱말만 빌려 왔습니다.",
 [("편지와 교정지: 작곡가들은 출판사와 어떻게 일했는가", "지문에 없는 이야기입니다. 출판사가 나오지만 작곡가도, 둘이 주고받은 것도 나오지 않습니다. 글의 눈은 악보를 새기는 사람들이 음표 사이를 어떻게 띄웠느냐에 있습니다."),
  ("사이 띄우기가 일러 주는 말을 싣고 있는 쪽", "둘째 문장의 «spaced notes according to their duration rather than fitting them evenly across the stave»와 끝 문장의 «None of it is decoration»이 근거입니다. 손이 바쁜 연주자는 찾지 않고도 다음 마디를 보아야 합니다. 그래서 음표의 사이를 길이에 맞춰 띄워, 눈이 음악의 빠르기대로 가게 했습니다. 그 사이 띄우기는 꾸밈이 아니라 읽는 사람에게 일러 주는 말입니다."),
  ("상자에 넣어 두기: 도서관의 손글씨 악보 지키기", "지문에 없는 이야기입니다. 손으로 쓴 악보도, 도서관도, 지키는 일도 나오지 않습니다. 악보라는 글감에서 떠올린 것일 뿐입니다."),
  ("디지털 악보가 인쇄 악보를 밀어낸 까닭", "글과 거꾸로입니다. 컴퓨터 조판이 나오니 그렇게 읽기 쉽습니다. 하지만 초기의 컴퓨터 조판은 기호를 고르게 띄워서 읽기 어려웠고, 출판사들은 새긴 악보를 본뜨는 쪽으로 돌아갔습니다('reverted to imitating the engraved page'). 소프트웨어가 옛 규칙을 따르게 된 것입니다. 밀어냈다는 말은 지문과 부딪힙니다."),
  ("인쇄술의 발명과 유럽으로의 퍼짐", "지문 낱말을 빌린, 지문에 없는 이야기입니다. 인쇄된 악보가 나오지만 인쇄술이 어떻게 생기고 퍼졌는지는 한 줄도 없습니다. 글보다 훨씬 넓고, 이야기도 다릅니다.")])

# ---------- 29번째: 벌 떼가 떠나는 것은 잘못된 것이 아니라 튼튼한 무리가 불어나는 것이다 ----------
NEW29 = 'How Beekeepers Recapture a Swarm That Has Left'
mk(28, 0, [
 "1) 되풀이: 「벌 떼가 떠나는 것은 잘못된 것이 아니라 불어나는 것」이라는 생각이 이어집니다. «A colony that sends half its workers away with the old queen has not failed.»(옛 여왕벌과 함께 일벌의 절반을 내보내는 무리는 잘못된 것이 아니다.) → «It has reproduced.»(그 무리는 새끼를 친 것이다.) → «Swarming is how a hive becomes two hives»(떼 나감은 벌통 하나가 둘이 되는 길이다) → «Working with the impulse produces two colonies»(그 본능과 함께 일하면 두 무리가 생긴다).",
 "2) 꺾이는 곳: 첫 두 문장입니다. 절반을 잃었으니 잘못된 것처럼 보이는데, 글은 그것을 곧바로 뒤집습니다. 떼 나감은 무리가 붐비고, 잘 먹고, 새 여왕벌을 기를 때 일어납니다. 튼튼하다는 표입니다. 둘째 문단이 벌 치는 사람 쪽으로 넘어갑니다. 그 어려움은 'economic rather than biological'(생물의 것이 아니라 돈의 것)입니다. 벌에게는 탈이 아니고, 꿀을 거둘 사람에게만 아쉬운 일입니다.",
 "3) 끝 문장: «Working with the impulse produces two colonies; working against it frequently produces none.»(그 본능과 함께 일하면 두 무리가 생기고, 거슬러 일하면 흔히 하나도 남지 않는다.) 떼 나감이 자연스러운 불어남이니, 막으려 들기보다 벌 치는 사람이 고른 때에 무리를 나누는 쪽이 낫습니다. 첫머리의 「잘못된 것이 아니다」가 끝에서 「함께 일하라」로 이어집니다.",
 "4) 묶기: 콜론 앞 'Losing Half the Hive'(벌통의 절반을 잃기) = 'sends half its workers away'(일벌의 절반을 내보낸다). 콜론 뒤 'The Departure That Signals a Healthy Colony'(튼튼한 무리임을 알리는 떠남) = 'has not failed', 'It has reproduced', 그리고 붐비고 잘 먹은 무리에서 일어난다는 셋째 문장. 콜론 앞이 겉보기(잃음), 콜론 뒤가 속(튼튼함)입니다. 'Healthy'는 지문에 없는 낱말입니다."],
 "「꿀벌 무리의 사회 짜임」이 조심할 선택지입니다. 여왕벌과 일벌이 나오니 무리의 짜임 이야기로 읽기 쉽습니다. 하지만 글은 무리가 어떻게 짜여 있는지를 훑지 않고, 떼 나감 하나만 다룹니다. 글보다 훨씬 넓은 제목입니다. 「벌 치는 사람은 떠난 벌 떼를 어떻게 다시 붙잡는가」도 조심합니다. 떠난 떼는 대개 손이 닿지 않는 곳에 앉는다고 했습니다. 글이 든 것은 붙잡기가 아니라, 떠나기 전에 손쓰는 길입니다.",
 [("벌통의 절반을 잃기: 튼튼한 무리임을 알리는 떠남", "첫 문장 «A colony that sends half its workers away with the old queen has not failed.»와 끝 문장 «Working with the impulse produces two colonies; working against it frequently produces none.»이 근거입니다. 떼 나감은 붐비고 잘 먹은 무리가 둘로 불어나는 일입니다. 그래서 막으려 싸우기보다 그 본능에 맞춰 무리를 나누는 쪽이 낫습니다. 'sends half its workers away'가 'Losing Half the Hive'로 바뀌었습니다."),
  ("(아래에서 새 선택지로 바꿈)", "자리 채움"),
  ("농약과 기생충: 벌이 줄어든 까닭", "지문에 없는 이야기입니다. 농약도 기생충도, 벌이 줄어든다는 말도 나오지 않습니다. 글에서 벌통의 벌이 절반으로 주는 것은 탈이 아니라 무리가 불어나는 일입니다. 벌이라는 글감에서 떠올린 익숙한 이야기일 뿐입니다."),
  ("추운 철 돌보기: 겨울 동안 벌통 다루기", "지문에 없는 이야기입니다. 겨울도, 추운 철의 돌보기도 나오지 않습니다. 글은 철이 깊어 갈수록 떼 나가려는 본능이 세진다고 했을 뿐입니다."),
  ("꿀벌 무리의 사회 짜임", "글보다 넓은 제목입니다. 여왕벌과 일벌, 새 여왕벌을 기르는 방이 나오니 무리의 짜임을 다루는 글로 읽기 쉽습니다. 하지만 글은 그 가운데 떼 나감 하나만, 그리고 벌 치는 사람이 그것을 어떻게 다루느냐만 말합니다. 무리가 어떻게 짜여 있는지를 훑는 글이 아닙니다.")])
E[('41', '9', 28)]['ch'] = {1: NEW29}
E[('41', '9', 28)]['cn'][1] = ("'%s' (벌 치는 사람은 떠난 벌 떼를 어떻게 다시 붙잡는가) — " % NEW29) + (
    "지문과 어긋나는 이야기입니다. 떠난 떼는 그 철의 꿀을 낼 일벌들을 데리고 가서 대개 손이 닿지 않는 곳에 앉는다('usually settles somewhere unreachable')고 했습니다. "
    "다시 붙잡는 법은 지문에 없습니다. 글이 든 것은 떠나기 전에 자리를 넓히거나, 여왕벌 방을 떼어 내거나, 무리를 미리 나누는 길입니다.")

# ---------- 30번째: 판 뱃길은 퍼내는 만큼 다시 메워진다 ----------
mk(29, 1, [
 "1) 되풀이: 「판 뱃길은 저절로 다시 메워진다」는 생각이 이어집니다. «A harbour approached through an estuary is not a fixed depth of water.»(강어귀를 거쳐 들어가는 항구는 정해진 깊이의 물이 아니다.) → «the place the current slows most is the deep channel that was dug to admit ships»(물살이 가장 느려지는 곳이, 배를 들이려고 판 바로 그 깊은 뱃길이다) → «Dredging therefore is not a project but an obligation.»(그러므로 바닥 파내기는 한 번의 공사가 아니라 져야 할 짐이다.)",
 "2) 꺾이는 곳: 셋째 문장입니다. 'not A but B' 틀로 글의 생각을 못 박습니다. 한 번 하고 끝나는 공사가 아니라 해마다 해야 하는 일입니다. 더 큰 배를 들이려고 뱃길을 깊게 판 항구는 그 뒤로 해마다 같은 흙을 퍼내야 합니다. 물결을 막으려고 둑을 늘인 항구는 잔잔해진 물이 전보다 더 빨리 메워지는 것을 보았습니다. 잔잔함과 물살이 멎음은 같은 성질이기 때문입니다.",
 "3) 끝 문장: 끝의 두 문장이 다른 길을 내놓습니다. «Some authorities now design for the sediment rather than against it»(몇몇 당국은 이제 흙에 맞서지 않고 흙을 헤아려 설계한다). 뱃길로는 물살이 빠르게 지나고 흙은 다른 데 쌓이게 하는 벽을 놓습니다. 이 길은 짓는 데 더 들고 지키는 데 덜 듭니다. 메워지는 것을 막을 수 없으니, 메워지는 곳을 옮기는 것입니다.",
 "4) 묶기: 'A Channel That Fills In'(메워지는 뱃길) = 흙이 물살이 느려지는 곳에 가라앉고, 그곳이 바로 판 뱃길이라는 둘째 문장. 'as Fast as It Is Emptied'(퍼내는 만큼 빨리) = 'removing the same material every year afterwards'(그 뒤로 해마다 같은 흙을 퍼낸다), 'not a project but an obligation'. 제목에는 'Dredging'이라는 말이 없지만, 「퍼낸다」와 「메워진다」의 끝없는 되풀이가 글 전체를 한 줄로 그립니다."],
 "「때도 넘기고 돈도 넘기고: 바닷가 공사가 예산을 넘는 까닭」이 조심할 선택지입니다. 운영 예산, 값 같은 돈 이야기가 지문에 나와서 끌립니다. 하지만 글은 공사가 예산을 넘는다고 하지 않았습니다. 그 값이 한 번의 공사비가 아니라 해마다 드는 운영비로 나타나, 정할 때에는 잘 보이지 않는다고 했습니다. 바닷가 공사 전체를 다루는 글도 아닙니다. 「요즘 항구는 갈수록 커지는 컨테이너선을 어떻게 받는가」는 더 큰 배라는 한 마디만 붙잡았습니다.",
 [("때도 넘기고 돈도 넘기고: 바닷가 공사가 예산을 넘는 까닭", "지문 낱말에서 떠올린 다른 이야기이고, 글보다 넓습니다. 예산이 나오지만 넘는다는 말은 없습니다. 글은 퍼내는 값이 공사 예산이 아니라 운영 예산에 나타난다('in the operating budget rather than the capital one')고 했습니다. 정할 때 잘 보이지 않는다는 뜻입니다. 바닷가 공사 전체도, 때를 넘긴다는 말도 지문에 없습니다."),
  ("퍼내는 만큼 빨리 다시 메워지는 뱃길", "셋째 문장 «Dredging therefore is not a project but an obligation.»과 둘째 문장의 «the place the current slows most is the deep channel that was dug to admit ships»가 근거입니다. 흙은 물살이 느려지는 곳에 가라앉는데, 깊게 판 뱃길이 바로 그런 곳입니다. 그래서 한 번 파면 해마다 다시 퍼내야 합니다. 'not a project but an obligation'을 그림처럼 바꿔 말한 제목입니다."),
  ("요즘 항구는 갈수록 커지는 컨테이너선을 어떻게 받는가", "글의 한 대목만 담았습니다. 더 큰 배를 들이려고 뱃길을 깊게 판다는 말이 한 번 나옵니다. 그것은 깊게 팔수록 해마다 퍼낼 짐을 스스로 진다는 것을 말하려는 것입니다. 큰 배를 어떻게 받는지를 다루는 글이 아닙니다. 컨테이너선이라는 말도 지문에 없습니다."),
  ("흙과 삶터: 항구 짓기가 환경에 미치는 영향", "지문 낱말에서 떠올린, 지문에 없는 이야기입니다. 가라앉는 흙이 나오지만, 그것이 살아 있는 것들의 삶터에 무슨 일을 하는지는 나오지 않습니다. 글에서 흙은 환경의 걱정거리가 아니라 뱃길을 메우는 것입니다."),
  ("바다와 강으로: 뱃길과 항구 도시의 자람", "지문에 없는 이야기입니다. 항구와 강어귀가 나오지만, 거래의 길도 항구 도시가 어떻게 자랐는지도 나오지 않습니다. 글보다 훨씬 넓고, 이야기도 다릅니다.")])
