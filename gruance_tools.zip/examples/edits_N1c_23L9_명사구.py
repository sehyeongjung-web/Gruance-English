# -*- coding: utf-8 -*-
# 205번: 23번(주제) 레벨9 선택지를 수능식 명사구로 — 21~30번째, 30문항 끝 (선생님 승인: 202번 시범 뒤 "계속")
AUTO_SYNC = False
E = {}
from n23common import R

# 21번째
R(E, 20,
  {0: "competing views of a museum's purpose as the basis of disputes over repatriation",
   1: 'the legal requirement that museums return every disputed object to its place of origin',
   2: 'the need for comparative study to assemble objects from many different regions',
   3: 'the reason objects acquired during colonial rule should be returned to their origins',
   4: 'the way museums decide which items from their holdings to place on display'},
  {0: '반환을 둘러싼 다툼의 바탕에 놓인, 박물관의 목적에 대한 맞서는 견해',
   1: '박물관이 다툼이 있는 모든 유물을 원래 있던 곳으로 돌려주어야 한다는 법적 요구',
   2: '비교 연구를 하려면 여러 지역의 유물을 한데 모아야 할 필요',
   3: '식민 지배 시기에 얻은 유물을 원래 있던 곳으로 돌려주어야 하는 이유',
   4: '박물관이 소장품 가운데 무엇을 전시할지 정하는 방식'},
  subs={0: [("'rests on'이 'turn on'으로", "'rests on'이 'the basis of'로")]},
  walk_sub=[("'rests on' = 'turn on'(~에 달려 있다)", "'rests on' = 'as the basis of'(~의 바탕으로서)")])

# 22번째
R(E, 21,
  {0: 'the improved ability of people who sleep less to notice how tired they really are',
   2: 'the use of attention tasks to measure cognitive performance in laboratories',
   3: 'the higher accident rate of shift workers compared with daytime employees',
   4: 'the gap between the perception of sleep deprivation and its actual effects'},
  {0: '잠을 덜 자는 사람이 자기가 실제로 얼마나 피곤한지를 더 잘 알아차리게 되는 능력',
   2: '실험실에서 인지 수행을 재는 데 주의력 과제를 쓰는 일',
   3: '낮 근무자와 견주어 더 높은 교대 근무자의 사고율',
   4: '수면 부족에 대한 느낌과 그 실제 영향 사이의 벌어짐'},
  subs={4: [("'plateaus in perception'이 'the perception … stops tracking'으로", "'plateaus in perception'이 'the perception of sleep deprivation'으로")]},
  walk_sub=[("'levels off', 'plateaus' = 'stops tracking'(더는 따라가지 못한다)", "느낌은 'levels off', 'plateaus'(멈춤)이고 실제는 'deepening'(깊어짐)이니, 그 둘의 어긋남 = 'the gap between'(둘 사이의 벌어짐)")])

# 23번째 (정답은 이미 명사구 — 그대로)
R(E, 22,
  {0: 'the legal liability developers bear for flaws in their own code',
   4: 'reasons volunteers contribute to projects without payment'},
  {0: '개발자가 자기 코드의 결함에 지는 법적 책임',
   4: '자원봉사자들이 돈을 받지 않고 프로젝트에 이바지하는 까닭'})

# 24번째
R(E, 23,
  {0: 'the reason judges who read the law literally reach fairer decisions than those who look to its purpose',
   1: 'the choice between literal and purposive interpretation as a reflection of institutional priorities',
   2: 'ways legislators can draft rules that anticipate a wider range of cases',
   3: 'the priority predictability should have over sensible outcomes in law',
   4: 'differences in the application of general rules across various legal traditions'},
  {0: '법을 글자대로 읽는 판사가 취지를 살피는 판사보다 더 공정한 결정에 이르는 이유',
   1: '글자대로 해석할 것인가 취지대로 해석할 것인가의 선택이 기관이 무엇을 앞세우느냐를 비춘다는 것',
   2: '입법자가 더 넓은 범위의 사례를 내다보는 규칙을 짤 수 있는 방법',
   3: '법에서 예측 가능성이 사리에 맞는 결과보다 가져야 할 우선순위',
   4: '여러 법 전통에 걸친 일반 규칙 적용의 차이'})

# 25번째
R(E, 24,
  {0: 'the deliberate reduction by plant breeders of the number of crop varieties that farmers can grow',
   1: 'the transformation of farming practices by modern harvesting machinery',
   2: 'the narrowing of the range of crop varieties by downstream standardization, not breeding itself',
   3: 'the greater profitability of uniform crops over diverse plantings for farmers',
   4: 'the consumer preference for produce with a consistent size and appearance'},
  {0: '식물 육종가들이 농부가 기를 수 있는 작물 품종의 수를 일부러 줄이는 일',
   1: '현대의 수확 기계가 농사짓는 방식을 바꾸어 놓은 일',
   2: '육종 자체가 아니라 뒤 단계의 표준화 때문에 작물 품종의 폭이 좁아지는 일',
   3: '여러 품종을 섞어 심는 것보다 고른 작물이 농부에게 주는 더 큰 이익',
   4: '크기와 겉모습이 고른 농산물에 대한 소비자의 선호'},
  subs={2: [("'The narrowing'이 'narrows the range of crop varieties'로", "'The narrowing'이 'the narrowing of the range of crop varieties'로")]},
  walk_sub=[("= 'narrows the range of crop varieties'.", "= 'the narrowing of the range of crop varieties'.")])

# 26번째
R(E, 25,
  {0: 'the unexamined validity of figures produced by averaging rating scales',
   1: 'averaged rating scales as the most precise measure available of what people think',
   2: 'the way survey designers should construct scales that produce reliable data',
   3: 'the influence of rankings derived from ratings on institutional decision-making processes',
   4: 'the advantage of numerical ratings over written feedback in evaluation'},
  {0: '평가 척도의 평균을 내어 얻은 수치의, 따져지지 않은 타당함',
   1: '사람들의 생각을 재는 가장 정밀한 잣대로서의, 평균 낸 평가 척도',
   2: '설문을 만드는 사람이 믿을 만한 자료를 내는 척도를 짜야 하는 방식',
   3: '평점에서 나온 순위가 기관의 의사 결정 과정에 미치는 영향',
   4: '평가에서 숫자 평점이 글로 쓴 의견보다 나은 점'},
  subs={0: [("'assumptions that were never established'가 'whose validity remains unexamined'로", "'assumptions that were never established'가 'the unexamined validity'로")]},
  walk_sub=[("= 'whose validity remains unexamined'(타당한지 따져지지 않은 채 남은)", "= 'the unexamined validity'(따져지지 않은 타당함)")])

# 27번째
R(E, 26,
  {0: 'the dependence of archival visibility on institutional contact rather than ordinary experience',
   1: 'the reason official archives record the ordinary lives of people more fully than any other source',
   2: 'tax and court records as the most reliable of historical sources',
   3: 'the reconstruction of daily life by historians from incomplete documentary evidence',
   4: 'the difference between the study of ordinary life and traditional political history'},
  {0: '기록에 드러나는 것이 보통의 경험이 아니라 기관과 닿은 곳에 달려 있다는 것',
   1: '공식 기록 보관소가 다른 어떤 자료보다 사람들의 보통 삶을 더 온전히 담는 이유',
   2: '역사 자료 가운데 가장 믿을 만한 것으로서의 세금 기록과 법원 기록',
   3: '역사가들이 불완전한 문서 증거로 일상을 다시 짜 맞추는 일',
   4: '보통 삶의 연구와 전통적인 정치사의 차이'})

# 28번째
R(E, 27,
  {0: "the reason praising a person's ability makes them attend more carefully to correcting their mistakes",
   1: 'the advantage of frequent feedback over occasional review in improving outcomes',
   2: 'ways supervisors can deliver criticism without damaging working relationships',
   3: 'the typical response of recipients to unexpected criticism of their work',
   4: 'the displacement of the attention that correction requires by feedback directed at the person'},
  {0: '사람의 능력을 칭찬하면 그 사람이 잘못을 고치는 데 더 주의를 기울이게 되는 이유',
   1: '결과를 좋게 하는 데에서 잦은 피드백이 이따금 하는 검토보다 나은 점',
   2: '윗사람이 일터의 관계를 해치지 않으면서 비판을 전하는 방법',
   3: '받는 사람이 자기 일에 대한 뜻밖의 비판에 흔히 보이는 반응',
   4: '사람을 향한 피드백이 고치는 데 필요한 주의를 밀어내는 일'},
  subs={4: [("'competes for the same resources'가 'displaces the attention'으로", "'competes for the same resources'가 'the displacement of the attention'으로")]},
  walk_sub=[("= 'displaces the attention'(주의를 밀어낸다)", "= 'the displacement of the attention'(주의를 밀어냄)")])

# 29번째
R(E, 28,
  {0: 'the offer of higher pay as the most effective way to stop staff leaving',
   3: 'the conditions of the job, rather than pay, as the key to retention'},
  {0: '직원이 떠나는 것을 막는 가장 효과적인 방법으로서의 더 높은 급여 제안',
   3: '붙잡아 두는 일의 열쇠인, 급여가 아닌 일의 조건'},
  subs={3: [("payments가 'rather than on pay'로 밀려났습니다", "payments가 'rather than pay'로 밀려났습니다")]})

# 30번째
R(E, 29,
  {0: 'the reason a translation should be judged only by how closely it reproduces the wording of the original',
   1: 'differences among translations of the same work across historical periods',
   2: 'a translation as evidence of interpretation rather than merely a lesser original',
   4: 'the reason reading literary works in the original language is always preferable'},
  {0: '번역을 원문의 글귀를 얼마나 가깝게 되살렸는지로만 판단해야 하는 이유',
   1: '같은 작품의 번역들이 시대에 따라 보이는 차이',
   2: '그저 원문보다 못한 것이 아니라 해석의 증거로서의 번역',
   4: '문학 작품을 원어로 읽는 것이 언제나 더 나은 이유'})
