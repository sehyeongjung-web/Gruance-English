# 170번: 43번(이야기 글의 순서) 레벨4 틀 재작성 — 30문항 전부 (선생님 승인: "셋 다, 유형마다 다른 이야기" · "30문항 전부")
#   · 정답 번호·선택지는 그대로. 문단마다 두 문장, 이야기 구조 여섯 가지(하루의 일·회상·주고받는 말·뜻밖의 결말·두 사람이 번갈아·장소 이동)
#   · 순서는 가리키는 말의 사슬로 하나로만 정해짐: 첫 문단은 주어진 글을 받고, 둘째 문단은 첫 문단에 처음 나온 것을, 셋째 문단은 둘째 문단에 처음 나온 것을 가리킴
AUTO_SYNC = False
E = {}
STD = ['(B)-(D)-(C)', '(C)-(B)-(D)', '(C)-(D)-(B)', '(D)-(B)-(C)', '(D)-(C)-(B)']

def S(n, order, A, P1, P2, P3, r2, r3, clue):
    # n: 문항 번호(0부터) / order: 이야기 순서대로의 문단 기호(예 'DCB') / A: (주어진 글, 해석)
    # P1~P3: 이야기 순서대로 (영어, 해석, 한 줄 요약) / r2: 둘째 문단이 첫 문단보다 먼저 올 수 없는 까닭 / r3: 셋째 문단이 둘째 문단보다 먼저 올 수 없는 까닭
    L = ['(%s)' % c for c in order]
    ans = '-'.join(L); assert ans in STD, (n, ans)
    paras = dict(zip(L, (P1, P2, P3)))
    text = A[0] + ''.join('\n\n%s %s' % (k, paras[k][0]) for k in ['(B)', '(C)', '(D)'])
    ko = A[1] + ''.join(' %s %s' % (k, paras[k][1]) for k in ['(B)', '(C)', '(D)'])
    f = lambda s: s.replace('{1}', L[0]).replace('{2}', L[1]).replace('{3}', L[2])
    flow = ' → '.join('%s %s' % (L[i], p[2]) for i, p in enumerate((P1, P2, P3)))
    walk = '%s 따라서 %s → %s → %s 순서인 %s가 답입니다.' % (f(clue), L[0], L[1], L[2], ans)
    cn = []
    for c in STD:
        if c == ans: cn.append('%s: 정답입니다. %s의 흐름입니다.' % (c, flow))
        elif c[:3] == L[1]: cn.append('%s: %s' % (c, f(r2)))
        elif c[:3] == L[2]: cn.append('%s: %s' % (c, f(r3)))
        else: cn.append('%s: 첫 문단은 맞지만 그다음이 틀렸습니다. %s' % (c, f(r3)))
    assert ('43', '4', n) not in E, n
    E[('43', '4', n)] = {'passage_ok': True, 'ans_ok': True, '_order': ans,
                         'rewrite': {'text': text, 'choices': list(STD), 'ko': ko, 'walk': walk, 'cn': cn}}

# 1 ─ 하루의 일: 없어진 종이별 상자
S(0, 'DCB',
  ("On the morning of the school festival, Jisu found that the box of paper stars which her class had made was missing.",
   "학교 축제 날 아침, 지수는 반 친구들이 만든 종이별 상자가 없어진 것을 알았다."),
  ("She ran to the teachers' office, where a cleaner was mopping the floor. He said that he had seen a boy carrying a large box toward the gym.",
   "그녀는 교무실로 달려갔는데, 거기서는 청소하시는 분이 바닥을 닦고 있었다. 그는 한 남자아이가 큰 상자를 들고 체육관 쪽으로 가는 것을 보았다고 말했다.",
   "교무실에서 상자를 든 남자아이 이야기를 들음"),
  ("The boy turned out to be Minho, who was already hanging the stars from the gym ceiling. He had come early to surprise everyone.",
   "그 남자아이는 민호였고, 그는 벌써 체육관 천장에 별을 달고 있었다. 그는 모두를 놀라게 해 주려고 일찍 온 것이었다.",
   "그 남자아이가 별을 달고 있던 민호였음"),
  ("Jisu laughed with relief and held the ladder for him. When their classmates arrived, every star was in its place above the stage.",
   "지수는 마음이 놓여 웃고는 그를 위해 사다리를 잡아 주었다. 반 친구들이 도착했을 때 별은 모두 무대 위 제자리에 걸려 있었다.",
   "지수가 민호를 도와 별을 다 닮"),
  "{2}의 'The boy(그 남자아이)'는 {1}에서 청소하시는 분이 보았다고 한 'a boy(한 남자아이)'를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'him(그)'은 {2}에서 천장에 별을 달고 있던 민호이고, 지수가 마음을 놓는 것도 그것을 본 뒤이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 상자가 없어졌으므로, 상자를 찾아 교무실로 달려가는 {1}가 먼저입니다. {2}의 'The boy'는 {1}의 'a boy'를 받고, {3}에서 지수가 사다리를 잡아 주는 'him'은 {2}의 민호입니다.")

# 2 ─ 회상: 아버지가 깎아 준 나무배
S(1, 'DCB',
  ("While he was emptying a cupboard under the stairs, Mr. Oh found a small wooden boat with a broken sail.",
   "오 씨는 계단 밑 벽장을 비우다가 돛이 부러진 작은 나무배를 발견했다."),
  ("His father had carved it for him forty years earlier, in a summer when the family could not afford a holiday. They sailed it on the pond every evening.",
   "그것은 40년 전, 가족이 휴가를 갈 형편이 못 되던 어느 여름에 아버지가 그를 위해 깎아 만든 배였다. 두 사람은 저녁마다 연못에 그 배를 띄웠다.",
   "아버지가 배를 만들어 주고 저녁마다 함께 띄움"),
  ("On the last of those evenings, the wind pushed the boat into the reeds and its sail snapped. His father promised to mend it but soon fell ill.",
   "그 저녁들 가운데 마지막 날, 바람이 배를 갈대밭으로 밀어 넣어 돛이 부러졌다. 아버지는 고쳐 주겠다고 약속했지만 얼마 뒤 병이 났다.",
   "돛이 부러지고 아버지가 고쳐 주겠다고 약속함"),
  ("Mr. Oh carried the boat to the kitchen table and finally kept that promise himself. The next Sunday, he took his own daughter to the pond.",
   "오 씨는 배를 식탁으로 가져가 마침내 그 약속을 직접 지켰다. 다음 일요일에 그는 자기 딸을 데리고 그 연못에 갔다.",
   "오 씨가 그 약속을 직접 지킴"),
  "{2}의 'those evenings(그 저녁들)'는 {1}의 'every evening(저녁마다)'을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that promise(그 약속)'는 {2}에서 아버지가 돛을 고쳐 주겠다고 한 약속이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 배를 {1}의 'it'이 받아 어떤 배인지 설명합니다. {2}의 'those evenings'는 {1}의 'every evening'을, {3}의 'that promise'는 {2}의 아버지 약속을 가리킵니다.")

# 3 ─ 주고받는 말: 꽃집의 노인
S(2, 'BDC',
  ("One rainy afternoon, an old man came into the flower shop where Hana worked and stood silently in front of the roses.",
   "비 오는 어느 오후, 한 노인이 하나가 일하는 꽃집에 들어와 장미 앞에 말없이 서 있었다."),
  ("She asked whether he needed help, and he said that he wanted one yellow rose. His wife had loved that colour since their wedding day.",
   "그녀가 도와 드릴지 묻자, 그는 노란 장미 한 송이를 원한다고 말했다. 그의 아내는 결혼식 날부터 그 색을 좋아해 왔다.",
   "노인이 아내가 좋아하는 노란 장미를 찾음"),
  ("Hana looked in every bucket for the colour he wanted, but it had sold out. She apologised and offered him a white rose instead.",
   "하나는 그가 원하는 색을 찾아 양동이를 모두 들여다보았지만, 그 색은 다 팔리고 없었다. 그녀는 사과하고 대신 흰 장미 한 송이를 권했다.",
   "노란 장미가 없어 흰 장미를 권함"),
  ("He smiled and said that white would do, since his wife could no longer see colours anyway. What she still loved, he explained, was the smell.",
   "그는 미소를 지으며, 아내가 어차피 이제는 색을 볼 수 없으니 흰색이어도 괜찮다고 말했다. 아내가 여전히 좋아하는 것은 향기라고 그는 설명했다.",
   "노인이 흰색이어도 괜찮다고 답함"),
  "{2}의 'the colour he wanted(그가 원하는 색)'는 {1}에서 노인이 말한 노란색을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'white would do(흰색이어도 괜찮다)'는 {2}에서 하나가 흰 장미를 권한 데 대한 대답이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 노인이 장미 앞에 서 있으므로, 하나가 말을 거는 {1}가 먼저입니다. {2}의 'the colour he wanted'는 {1}의 노란색을 받고, {3}의 'white would do'는 {2}에서 권한 흰 장미에 대한 대답입니다.")

# 4 ─ 뜻밖의 결말: 샌드위치 도둑
S(3, 'DCB',
  ("Every day for a week, one corner of the sandwich in Nora's lunch bag went missing, and she blamed her little brother.",
   "일주일 동안 날마다 노라의 도시락 가방 속 샌드위치의 한쪽 귀퉁이가 없어졌고, 그녀는 남동생을 탓했다."),
  ("So on Friday night she hid behind the kitchen door with a torch and watched the bag. For an hour nothing moved, and she nearly fell asleep.",
   "그래서 금요일 밤에 그녀는 손전등을 들고 부엌 문 뒤에 숨어 그 가방을 지켜보았다. 한 시간 동안 아무것도 움직이지 않았고, 그녀는 거의 잠들 뻔했다.",
   "손전등을 들고 숨어서 가방을 지켜봄"),
  ("Then a soft noise made her switch on the torch. The bag was shaking on the table, and a grey tail was sticking out of it.",
   "그때 작은 소리가 나서 그녀는 손전등을 켰다. 식탁 위에서 가방이 흔들리고 있었고, 회색 꼬리 하나가 가방 밖으로 삐져나와 있었다.",
   "손전등을 켜자 가방 밖으로 나온 회색 꼬리가 보임"),
  ("The owner of that tail was the neighbour's cat, which had been climbing in through the window. Nora apologised to her brother the next morning.",
   "그 꼬리의 주인은 창문으로 기어 들어오던 이웃집 고양이였다. 노라는 다음 날 아침 남동생에게 사과했다.",
   "범인은 이웃집 고양이였고, 동생에게 사과함"),
  "{2}의 'the torch(그 손전등)'는 {1}에서 그녀가 들고 숨은 'a torch'를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that tail(그 꼬리)'은 {2}에서 가방 밖으로 나와 있던 회색 꼬리를 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 남동생을 탓했으므로, 'So(그래서)'로 시작해 숨어서 지켜보는 {1}가 먼저입니다. {2}의 'the torch'는 {1}의 'a torch'를, {3}의 'that tail'은 {2}의 'a grey tail'을 가리킵니다.")

# 5 ─ 두 사람이 번갈아: 책상 위의 테이프
S(4, 'CDB',
  ("Two brothers, Taeho and Taemin, shared a desk, and they argued every night about who had left it in a mess.",
   "태호와 태민 형제는 책상 하나를 같이 썼는데, 누가 책상을 어질러 놓았는지를 두고 밤마다 다투었다."),
  ("One evening Taeho stuck a line of blue tape down the middle of the desk. Each of them, he said, would keep his own half clean.",
   "어느 날 저녁 태호는 책상 한가운데에 파란 테이프를 한 줄 붙였다. 그는 각자 자기 쪽 절반을 깨끗이 쓰자고 말했다.",
   "태호가 파란 테이프로 책상을 나눔"),
  ("Taemin did not answer, but the next day he added a strip of red tape right beside the blue line. On it he had written, \"My half is cleaner.\"",
   "태민은 대답하지 않았지만, 다음 날 그 파란 줄 바로 옆에 빨간 테이프를 한 줄 덧붙였다. 그 위에는 \"내 쪽이 더 깨끗해.\"라고 적혀 있었다.",
   "태민이 빨간 테이프에 글을 써서 붙임"),
  ("Taeho read those words and laughed in spite of himself. After that the brothers competed, not about the mess, but about whose side looked better.",
   "태호는 그 글을 읽고 자기도 모르게 웃음을 터뜨렸다. 그 뒤로 형제는 누가 어질렀는지가 아니라 누구 쪽이 더 보기 좋은지를 두고 겨루었다.",
   "태호가 그 글을 읽고 웃음"),
  "{2}의 'the blue line(그 파란 줄)'은 {1}에서 태호가 붙인 파란 테이프를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'those words(그 글)'는 {2}에서 태민이 빨간 테이프에 쓴 말을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 다툼에 이어 태호가 파란 테이프를 붙이는 {1}가 먼저입니다. {2}의 'the blue line'은 {1}의 파란 테이프를, {3}의 'those words'는 {2}에서 태민이 쓴 'My half is cleaner.'를 가리킵니다.")

# 6 ─ 장소 이동: 잘못 탄 기차
S(5, 'CBD',
  ("On her way to her cousin's wedding, Maya took the wrong train and got off at a station that she had never heard of.",
   "사촌의 결혼식에 가는 길에 마야는 기차를 잘못 타서, 들어 본 적도 없는 역에서 내렸다."),
  ("The only person on the platform was a woman selling boiled eggs. When Maya explained her problem, the woman pointed to a bus stop across the road.",
   "승강장에 있는 사람은 삶은 달걀을 파는 여자 한 명뿐이었다. 마야가 사정을 설명하자 그 여자는 길 건너 버스 정류장을 가리켰다.",
   "승강장의 여자가 버스 정류장을 알려 줌"),
  ("The bus at that stop went only as far as the river, its driver told her. From the bridge, however, she would see the wedding hall.",
   "그 정류장의 버스는 강까지만 간다고 운전기사가 그녀에게 말했다. 하지만 다리에서는 결혼식장이 보일 것이라고 했다.",
   "버스 기사가 다리에서 식장이 보인다고 알려 줌"),
  ("She thanked him, got off at the bridge and ran across it in her good shoes. She reached the hall just as the music began.",
   "그녀는 그에게 고맙다고 하고 다리에서 내려, 좋은 구두를 신은 채 다리를 뛰어 건넜다. 그녀는 음악이 막 시작될 때 식장에 도착했다.",
   "다리를 건너 제때 식장에 도착함"),
  "{2}의 'that stop(그 정류장)'은 {1}에서 여자가 가리킨 버스 정류장이므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'him(그)'은 {2}의 버스 운전기사이고 'the bridge(그 다리)'도 {2}에 처음 나오므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 낯선 역에 내렸으므로, 승강장에서 사정을 설명하는 {1}가 먼저입니다. {2}의 'that stop'은 {1}의 버스 정류장을, {3}의 'him'과 'the bridge'는 {2}의 운전기사와 다리를 가리킵니다.")

# 7 ─ 하루의 일: 토요일의 허수아비
S(6, 'CBD',
  ("Mr. Baek promised his granddaughter Sori that the scarecrow which they were building would be working by Saturday evening.",
   "백 씨 할아버지는 손녀 소리에게, 둘이 만들고 있는 허수아비가 토요일 저녁이면 제 구실을 할 것이라고 약속했다."),
  ("In the morning they tied two sticks into a cross and dressed it in his old coat. Before lunch three sparrows were sitting on its arms.",
   "아침에 두 사람은 막대 두 개를 십자로 묶고 그의 낡은 외투를 입혔다. 점심 전에 참새 세 마리가 그 팔 위에 앉아 있었다.",
   "아침에 세운 허수아비의 팔에 참새가 앉음"),
  ("After they had eaten, he tried a different idea and hung shiny tin lids from the sleeves. The lids flashed in the sun, but the birds soon noticed that they made no sound.",
   "점심을 먹은 뒤 그는 다른 방법을 떠올려 소매에 반짝이는 양철 뚜껑을 매달았다. 뚜껑은 햇빛에 번쩍였지만, 새들은 그것이 아무 소리도 내지 않는다는 것을 곧 알아챘다.",
   "점심 뒤 반짝이는 뚜껑을 달았지만 소리가 나지 않음"),
  ("To end that silence, Sori tied her bicycle bell to one arm and ran a string to the kitchen window. By sunset no bird dared to come near.",
   "그 조용함을 없애려고 소리는 자전거 종을 한쪽 팔에 묶고 부엌 창문까지 줄을 이었다. 해 질 무렵에는 어떤 새도 감히 가까이 오지 못했다.",
   "종을 달아 해 질 무렵에는 새가 오지 못함"),
  "{2}의 'After they had eaten(식사를 한 뒤)'은 {1}의 'Before lunch(점심 전)' 다음이고, 'the sleeves(그 소매)'도 {1}에서 입힌 외투의 소매이므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that silence(그 조용함)'는 {2}에서 뚜껑이 아무 소리도 내지 않는다고 한 것을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "하루의 흐름을 따라갑니다. {1}는 'In the morning'과 'Before lunch', {2}는 'After they had eaten', {3}는 'By sunset'입니다. 또 {3}의 'that silence'는 {2}의 '소리를 내지 않는다'를 가리킵니다.")

# 8 ─ 회상: 20년 만에 돌아온 사전
S(7, 'DCB',
  ("At her retirement party, Ms. Yoon was handed a wrapped present by a tall young man whom she did not recognise at first.",
   "퇴임식에서 윤 선생님은 처음에는 누구인지 알아보지 못한 키 큰 청년에게서 포장된 선물을 건네받았다."),
  ("Inside was an old dictionary with her own name on the first page. She had lent it to a quiet boy in her class twenty years before.",
   "안에는 첫 장에 그녀의 이름이 적힌 낡은 사전이 들어 있었다. 20년 전 그녀가 반의 조용한 남자아이에게 빌려준 것이었다.",
   "선물은 20년 전 한 남자아이에게 빌려준 사전"),
  ("That boy had moved away in the middle of the term without saying goodbye. The book had gone with him.",
   "그 아이는 학기 중간에 인사도 없이 이사를 갔다. 책도 그와 함께 사라졌다.",
   "그 아이가 인사도 없이 이사를 감"),
  ("The young man apologised for leaving like that and said that the dictionary had made him a translator. He had kept it so that he could return it in person.",
   "청년은 그렇게 떠난 것을 사과하고, 그 사전 덕분에 번역가가 되었다고 말했다. 그는 직접 돌려 드리려고 사전을 간직해 온 것이었다.",
   "청년이 그렇게 떠난 것을 사과하고 사전을 돌려줌"),
  "{2}의 'That boy(그 아이)'는 {1}의 'a quiet boy(조용한 남자아이)'를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'leaving like that(그렇게 떠난 것)'은 {2}에서 인사도 없이 이사 간 일을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 선물을 여는 {1}('Inside')가 먼저입니다. {2}의 'That boy'는 {1}의 'a quiet boy'를, {3}의 'leaving like that'은 {2}의 인사 없는 이사를 가리킵니다.")

# 9 ─ 주고받는 말: 시험 시간에 울린 전화
S(8, 'DBC',
  ("Omar's phone rang during the history exam, and the whole class watched as the teacher walked slowly to his desk.",
   "역사 시험 도중에 오마르의 휴대전화가 울렸고, 선생님이 천천히 그의 책상으로 걸어가는 것을 반 전체가 지켜보았다."),
  ("Instead of taking the phone away, the teacher asked quietly who was calling. Omar looked at the screen and whispered that it was the hospital where his mother worked.",
   "선생님은 전화기를 빼앗는 대신 누구에게서 온 전화인지 조용히 물었다. 오마르는 화면을 보고, 어머니가 일하는 병원이라고 속삭였다.",
   "선생님이 누구 전화인지 묻고, 어머니의 병원임을 앎"),
  ("She told him to answer it in the corridor. The caller was a nurse from that hospital, who said that his mother had fainted but was already awake.",
   "선생님은 복도에 나가 전화를 받으라고 했다. 전화를 건 사람은 그 병원의 간호사였는데, 어머니가 쓰러졌지만 이미 깨어났다고 말했다.",
   "복도에서 전화를 받아 어머니 소식을 들음"),
  ("When he came back in, the teacher had already packed his bag. \"Go to her,\" she said. \"The exam can wait until Monday.\"",
   "그가 다시 들어왔을 때 선생님은 벌써 그의 가방을 싸 놓았다. \"어머니께 가 보렴. 시험은 월요일까지 기다릴 수 있어.\"라고 선생님이 말했다.",
   "교실로 돌아오자 선생님이 어머니에게 가 보라고 함"),
  "{2}의 'that hospital(그 병원)'은 {1}에서 오마르가 말한 어머니의 병원을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'came back in(다시 들어왔다)'은 {2}에서 복도로 나간 뒤의 일이고, 'her'는 {2}에서 쓰러졌다고 한 어머니이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 선생님이 책상으로 다가왔으므로, 전화기를 빼앗는 대신 묻는 {1}가 먼저입니다. {2}의 'that hospital'은 {1}의 병원을 가리키고, {3}의 'came back in'은 {2}에서 복도로 나갔다가 돌아오는 것입니다.")

# 10 ─ 뜻밖의 결말: 대회에서 잊어버린 곡
S(9, 'BDC',
  ("Sofia had practised her cello piece for three months, but on the contest stage her mind went completely blank.",
   "소피아는 석 달 동안 첼로 곡을 연습했지만, 대회 무대 위에서 머릿속이 완전히 하얘졌다."),
  ("For a long moment she sat with the bow on the strings. Then she began to play a simple tune that her grandmother used to hum.",
   "한참 동안 그녀는 활을 줄에 올린 채 앉아 있었다. 그러다 그녀는 할머니가 흥얼거리시던 단순한 가락을 켜기 시작했다.",
   "곡 대신 할머니의 가락을 켬"),
  ("This was not the piece on the programme, and the judges looked at one another in surprise. Still, nobody stopped her, and the hall grew very quiet.",
   "이것은 순서지에 적힌 곡이 아니었고, 심사위원들은 놀라 서로를 쳐다보았다. 그래도 아무도 그녀를 멈추지 않았고, 연주장은 아주 조용해졌다.",
   "심사위원들이 놀랐지만 아무도 멈추지 않음"),
  ("She won no prize that day. But one of those judges found her afterwards and said that her little tune was the only music he had really listened to all afternoon.",
   "그날 그녀는 상을 받지 못했다. 하지만 그 심사위원들 가운데 한 사람이 나중에 그녀를 찾아와, 그녀의 작은 가락이 오후 내내 자신이 정말로 귀 기울여 들은 단 하나의 음악이었다고 말했다.",
   "상은 못 받았지만 심사위원 한 사람이 그 가락을 칭찬함"),
  "{2}의 'This(이것)'는 {1}에서 소피아가 켜기 시작한 할머니의 가락을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'those judges(그 심사위원들)'는 {2}에 나온 심사위원들을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 머릿속이 하얘졌으므로, 무대에 앉아 있다가 다른 가락을 켜는 {1}가 먼저입니다. {2}의 'This'는 {1}의 가락을, {3}의 'those judges'는 {2}의 심사위원들을 가리킵니다.")

# 11 ─ 두 사람이 번갈아: 문손잡이의 복숭아
S(10, 'DBC',
  ("Mrs. Seo, who lived alone on the third floor, found a bag of fresh peaches hanging on her door handle one morning.",
   "3층에 혼자 사는 서 씨 할머니는 어느 날 아침 문손잡이에 신선한 복숭아 한 봉지가 걸려 있는 것을 발견했다."),
  ("There was no note, so she could only guess who had left it. She made peach jam and put a jar outside the door of the new family downstairs.",
   "쪽지가 없어서 그녀는 누가 두고 갔는지 짐작만 할 수 있었다. 그녀는 복숭아 잼을 만들어, 아래층에 새로 이사 온 가족의 문 앞에 한 병을 놓아두었다.",
   "잼을 만들어 아래층 문 앞에 한 병을 둠"),
  ("The jar came back the next day, washed, with a drawing of a smiling peach inside. A child had clearly made it.",
   "그 병은 다음 날 깨끗이 씻긴 채, 웃는 복숭아 그림 한 장을 담고 돌아왔다. 아이가 그린 것이 분명했다.",
   "병이 아이의 그림과 함께 돌아옴"),
  ("That drawing went up on her fridge, and soon bags and jars were travelling up and down the stairs every week. She never asked who had started it.",
   "그 그림은 그녀의 냉장고에 붙었고, 곧 매주 봉지와 병이 계단을 오르내리게 되었다. 그녀는 누가 먼저 시작했는지 끝내 묻지 않았다.",
   "그림을 냉장고에 붙이고 나눔이 이어짐"),
  "{2}의 'The jar(그 병)'는 {1}에서 그녀가 아래층 문 앞에 둔 잼 병을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'That drawing(그 그림)'은 {2}에서 병에 담겨 온 그림을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 복숭아 봉지에 대해 'There was no note(쪽지가 없었다)'라고 잇는 {1}가 먼저입니다. {2}의 'The jar'는 {1}의 잼 병을, {3}의 'That drawing'은 {2}의 그림을 가리킵니다.")

# 12 ─ 장소 이동: 해돋이를 보러 간 길
S(11, 'DCB',
  ("Kiho wanted to see the sunrise from the mountain behind his town, so he left home at four, long before it was light.",
   "기호는 동네 뒷산에서 해돋이를 보고 싶어서, 날이 밝기 한참 전인 네 시에 집을 나섰다."),
  ("The forest path was darker than he had expected, and he soon came to a place where it divided. An old sign there had lost its letters.",
   "숲길은 그가 생각했던 것보다 어두웠고, 그는 곧 길이 갈라지는 곳에 이르렀다. 거기 있는 낡은 표지판은 글자가 지워져 있었다.",
   "어두운 숲길에서 갈림길에 이름"),
  ("He chose the left side of that fork because it seemed to go up. Instead it led down to a stream, where a monk was filling a kettle.",
   "그는 위로 올라가는 것처럼 보여서 그 갈림길의 왼쪽을 골랐다. 하지만 그 길은 아래쪽 개울로 이어졌고, 거기서 한 스님이 주전자에 물을 담고 있었다.",
   "왼쪽 길로 내려가 개울에서 스님을 만남"),
  ("The monk laughed at his story and led him to a rock above the temple. The sun rose while they shared hot tea.",
   "스님은 그의 이야기를 듣고 웃더니 절 위쪽의 바위로 그를 데려갔다. 두 사람이 따뜻한 차를 나누어 마시는 동안 해가 떠올랐다.",
   "스님과 함께 바위에서 해돋이를 봄"),
  "{2}의 'that fork(그 갈림길)'는 {1}에서 길이 갈라지던 곳을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'The monk(그 스님)'는 {2}에서 개울에 있던 'a monk(한 스님)'를 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 날이 밝기 전에 집을 나섰으므로, 어두운 숲길을 걷는 {1}가 먼저입니다. {2}의 'that fork'는 {1}의 갈림길을, {3}의 'The monk'는 {2}의 'a monk'를 가리킵니다.")

# 13 ─ 하루의 일: 달걀 없는 생일 케이크
S(12, 'CDB',
  ("Narae had promised to bake a birthday cake for her father, who would be home from work at seven.",
   "나래는 일곱 시에 퇴근해 집에 올 아버지를 위해 생일 케이크를 굽기로 약속했다."),
  ("At three she discovered that there were no eggs in the house. She ran to the shop on the corner, which was closed for a holiday.",
   "세 시에 그녀는 집에 달걀이 하나도 없다는 것을 알았다. 모퉁이 가게로 달려갔지만, 가게는 휴일이라 문이 닫혀 있었다.",
   "세 시에 달걀이 없는 것을 알았지만 가게가 닫혀 있음"),
  ("She was standing outside that shop, close to tears, when the woman from next door passed by. The woman had six eggs at home and gladly gave them away.",
   "그녀가 울음이 터질 듯한 얼굴로 그 가게 앞에 서 있는데, 옆집 아주머니가 지나갔다. 아주머니는 집에 달걀 여섯 개가 있었고 기꺼이 내주었다.",
   "가게 앞에서 만난 옆집 아주머니가 달걀을 줌"),
  ("With those eggs the cake was in the oven by five. At seven her father came home to the smell of chocolate, and a slice later went next door.",
   "그 달걀 덕분에 케이크는 다섯 시에 오븐에 들어갔다. 일곱 시에 아버지는 초콜릿 냄새가 가득한 집에 돌아왔고, 나중에 케이크 한 조각이 옆집으로 건너갔다.",
   "그 달걀로 케이크를 굽고 한 조각을 옆집에 보냄"),
  "{2}의 'that shop(그 가게)'은 {1}의 문 닫힌 모퉁이 가게를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'those eggs(그 달걀)'는 {2}에서 옆집 아주머니가 내준 달걀 여섯 개를 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "시각을 따라갑니다. {1}는 'At three', {3}는 'by five'와 'At seven'입니다. 그 사이의 {2}는 'that shop'으로 {1}의 가게를 받고, {3}의 'those eggs'는 {2}의 달걀을 가리킵니다.")

# 14 ─ 회상: 헐리는 극장의 매표소
S(13, 'DBC',
  ("Before the old cinema in her town was pulled down, Mrs. Ahn went to see it one last time and stood at the ticket window.",
   "동네의 오래된 극장이 헐리기 전에, 안 씨 할머니는 마지막으로 그곳을 보러 가서 매표소 창구 앞에 섰다."),
  ("Fifty years earlier she had sold tickets behind that glass. One winter night a young soldier had bought two and then waited outside alone until the film ended.",
   "50년 전 그녀는 그 유리창 뒤에서 표를 팔았다. 어느 겨울밤 한 젊은 군인이 표 두 장을 사고는, 영화가 끝날 때까지 밖에서 혼자 기다렸다.",
   "50년 전, 표 두 장을 사고 혼자 기다리던 군인"),
  ("She had felt sorry for him and taken him a cup of tea. He came back every week after that, always buying a single ticket.",
   "그녀는 그가 안쓰러워 차 한 잔을 가져다주었다. 그 뒤로 그는 매주 다시 왔고, 늘 표를 한 장만 샀다.",
   "차 한 잔을 가져다주자 군인이 매주 다시 옴"),
  ("The man who had drunk that tea was now standing beside her and holding her hand. \"I never did see that first film,\" he said.",
   "그 차를 마셨던 남자가 지금 그녀 곁에 서서 손을 잡고 있었다. \"그 첫 영화는 끝내 못 봤지.\"라고 그가 말했다.",
   "그 차를 마신 남자가 지금 곁에 서 있음"),
  "{2}의 'him(그)'은 {1}에서 밖에서 혼자 기다리던 젊은 군인을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that tea(그 차)'는 {2}에서 그녀가 가져다준 차 한 잔을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 매표소 창구를 {1}의 'that glass(그 유리창)'가 받으며 50년 전으로 돌아갑니다. {2}의 'him'은 {1}의 군인을, {3}의 'that tea'는 {2}의 차를 가리키고, {3}는 다시 지금으로 돌아옵니다.")

# 15 ─ 주고받는 말: 작가에게 보낸 편지
S(14, 'BDC',
  ("Eunji wrote a letter to the author of her favourite novel and asked why the main character had to leave home at the end.",
   "은지는 가장 좋아하는 소설의 작가에게 편지를 써서, 주인공이 왜 마지막에 집을 떠나야 했는지 물었다."),
  ("She did not expect an answer, but a postcard arrived a month later. On it the author asked a question of her own: where did the character go?",
   "그녀는 답장을 기대하지 않았지만, 한 달 뒤 엽서 한 장이 도착했다. 거기에서 작가는 오히려 질문을 던졌다. 그 주인공은 어디로 갔을까?",
   "작가가 엽서로 되물음"),
  ("Eunji thought about the author's question for days and then sent back three pages. They described a town by the sea and a job in a bookshop.",
   "은지는 작가의 질문을 며칠 동안 생각한 뒤 세 장짜리 글을 써서 보냈다. 거기에는 바닷가 마을과 서점 일자리가 그려져 있었다.",
   "은지가 세 장짜리 글로 답함"),
  ("The author's second reply was very short. It said that those three pages were better than her own ending, and that Eunji should keep writing.",
   "작가의 두 번째 답장은 아주 짧았다. 그 세 장이 자신이 쓴 결말보다 낫고, 은지는 계속 글을 써야 한다는 내용이었다.",
   "작가가 두 번째 답장에서 그 글을 칭찬함"),
  "{2}의 'the author's question(작가의 질문)'은 {1}의 엽서에 적힌 질문을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'second reply(두 번째 답장)'와 'those three pages(그 세 장)'는 {2}에서 은지가 보낸 글이 있어야 나올 수 있으므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 편지를 보냈으므로, 답장을 기대하지 않았는데 엽서가 왔다는 {1}가 먼저입니다. {2}의 'the author's question'은 {1}의 엽서 질문을, {3}의 'those three pages'는 {2}에서 보낸 글을 가리킵니다.")

# 16 ─ 뜻밖의 결말: 호수 둘레 달리기
S(15, 'CBD',
  ("Diego's school held a race around the lake each spring, and he had finished last two years in a row.",
   "디에고의 학교는 봄마다 호수 둘레를 도는 달리기 대회를 열었는데, 그는 2년 연속 꼴찌로 들어왔다."),
  ("This year he trained every morning. On the day of the race he was in third place when the runner ahead of him slipped on the wet grass.",
   "올해 그는 매일 아침 훈련했다. 대회 날 그가 3등으로 달리고 있을 때, 앞서 달리던 선수가 젖은 풀밭에서 미끄러졌다.",
   "3등으로 달리던 중 앞 선수가 미끄러짐"),
  ("Diego stopped, helped the fallen boy to his feet and gave him an arm to lean on. Almost everyone else passed them.",
   "디에고는 멈춰 서서 넘어진 아이를 일으켜 세우고 기댈 수 있게 팔을 내주었다. 다른 선수들은 거의 모두 그들을 지나쳐 갔다.",
   "멈춰서 넘어진 아이를 돕는 사이 모두가 지나감"),
  ("The two of them crossed the line arm in arm, last again. But at the closing ceremony the head teacher gave them a prize that had never existed before.",
   "두 사람은 팔을 낀 채 결승선을 넘었고, 이번에도 꼴찌였다. 하지만 폐회식에서 교장 선생님은 두 사람에게 전에는 없던 상을 주었다.",
   "둘이 함께 꼴찌로 들어왔지만 새로 만든 상을 받음"),
  "{2}의 'the fallen boy(넘어진 아이)'는 {1}에서 미끄러진 앞 선수를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'The two of them(두 사람)'과 'last again(이번에도 꼴찌)'은 {2}에서 디에고가 아이를 돕고 다른 선수들이 지나간 뒤의 일이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 '2년 연속 꼴찌'에 이어 'This year(올해)'로 시작하는 {1}가 먼저입니다. {2}의 'the fallen boy'는 {1}에서 미끄러진 선수를, {3}의 'The two of them'은 {2}의 두 사람을 가리킵니다.")

# 17 ─ 두 사람이 번갈아: 우편으로 주고받는 수수께끼
S(16, 'CDB',
  ("Sunwoo and his grandmother exchanged riddles by post, because letters reached her mountain village only once a week.",
   "선우와 할머니는 우편으로 수수께끼를 주고받았는데, 할머니의 산골 마을에는 편지가 일주일에 한 번만 들어갔기 때문이다."),
  ("Each letter carried a single riddle. In March she asked him what has hands but cannot clap, and she added that no one in her village had solved it.",
   "편지 한 통에는 수수께끼가 하나씩 담겼다. 3월에 할머니는 손(바늘)은 있는데 손뼉은 못 치는 것이 무엇이냐고 묻고, 마을에서 아무도 풀지 못했다고 덧붙였다.",
   "할머니가 '손은 있는데 손뼉은 못 치는 것' 수수께끼를 보냄"),
  ("Sunwoo thought about that riddle for six days before he looked up at the wall and laughed. His answer, which he posted the next morning, was one word: \"Clock.\"",
   "선우는 그 수수께끼를 엿새 동안 생각하다가 벽을 올려다보고 웃음을 터뜨렸다. 다음 날 아침에 부친 그의 답은 한 단어, \"시계\"였다.",
   "선우가 엿새 만에 '시계'라고 답함"),
  ("The reply to that word took two weeks to come. It contained no new riddle, only a photograph of his grandmother pointing proudly at her kitchen clock.",
   "그 한 단어에 대한 답장은 2주가 걸려서 왔다. 거기에는 새 수수께끼가 없고, 부엌 시계를 자랑스럽게 가리키는 할머니의 사진 한 장만 들어 있었다.",
   "할머니가 시계를 가리키는 사진을 답장으로 보냄"),
  "{2}의 'that riddle(그 수수께끼)'은 {1}에서 할머니가 3월에 보낸 수수께끼를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that word(그 한 단어)'는 {2}에서 선우가 보낸 'Clock'을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 수수께끼 주고받기를 {1}의 'Each letter(편지 한 통마다)'가 이어 설명합니다. {2}의 'that riddle'은 {1}의 할머니 수수께끼를, {3}의 'that word'는 {2}의 'Clock'을 가리킵니다.")

# 18 ─ 장소 이동: 섬에 두고 온 스케치북
S(17, 'BDC',
  ("On the ferry back from a class trip to an island, Mirae realised that she had left her sketchbook on the beach.",
   "섬으로 간 반 여행에서 돌아오는 배 위에서, 미래는 스케치북을 해변에 두고 왔다는 것을 깨달았다."),
  ("Her teacher could not turn the boat round, but he telephoned the island's only café. The owner promised to look for it when the tide went out.",
   "선생님은 배를 돌릴 수는 없었지만, 섬에 하나뿐인 카페에 전화를 걸었다. 카페 주인은 물이 빠지면 찾아보겠다고 약속했다.",
   "선생님이 섬의 카페 주인에게 찾아 달라고 부탁함"),
  ("That evening the owner found it under a bench and saw that the last drawing was of her own café. She decided not to wait for the next ferry.",
   "그날 저녁 주인은 벤치 밑에서 스케치북을 찾았고, 마지막 그림이 바로 자기 카페를 그린 것임을 보았다. 그녀는 다음 배를 기다리지 않기로 했다.",
   "주인이 스케치북을 찾고, 다음 배를 기다리지 않기로 함"),
  ("Instead she gave the sketchbook to a fisherman who was sailing across at dawn. It lay on Mirae's desk before the first lesson, with a seashell beside it.",
   "대신 그녀는 새벽에 바다를 건너가는 어부에게 스케치북을 맡겼다. 스케치북은 첫 수업 전에 조개껍데기 하나와 함께 미래의 책상 위에 놓여 있었다.",
   "어부 편에 보내 다음 날 첫 수업 전에 돌아옴"),
  "{2}의 'the owner(그 주인)'는 {1}에서 선생님이 전화한 카페의 주인을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'Instead(대신)'는 {2}의 '다음 배를 기다리지 않기로 했다'를 받는 말이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 배 위에서야 두고 온 것을 알았으므로, 선생님이 섬으로 전화를 거는 {1}가 먼저입니다. {2}의 'the owner'는 {1}의 카페 주인을, {3}의 'Instead'는 {2}의 '다음 배를 기다리지 않기로 했다'를 받습니다.")

# 19 ─ 하루의 일: 호텔 아르바이트 첫날
S(18, 'DBC',
  ("On the first day of his holiday job at a hotel, Samir had to carry breakfast trays to the fifth floor.",
   "호텔 방학 아르바이트 첫날, 사미르는 5층으로 아침 식사 쟁반을 날라야 했다."),
  ("By eight o'clock he had delivered eleven of them without a mistake. The twelfth, however, slipped from his hands outside room 507 and crashed onto the carpet.",
   "여덟 시까지 그는 쟁반 열한 개를 실수 없이 날랐다. 하지만 열두 번째 쟁반이 507호 앞에서 손에서 미끄러져 카펫 위로 떨어졌다.",
   "열두 번째 쟁반을 507호 앞에서 떨어뜨림"),
  ("The door of that room opened, and an elderly guest looked down at the broken plates. Then she knelt and began to pick up the pieces with him.",
   "그 방의 문이 열리고, 나이 지긋한 손님이 깨진 접시를 내려다보았다. 그러더니 그녀는 무릎을 꿇고 그와 함께 조각을 줍기 시작했다.",
   "그 방의 손님이 나와 함께 조각을 주움"),
  ("She told him that she had once dropped a whole wedding cake on her own first day at work. Later she left a note which praised \"the careful young man.\"",
   "그녀는 자신도 첫 출근 날 웨딩 케이크를 통째로 떨어뜨린 적이 있다고 말해 주었다. 나중에 그녀는 \"꼼꼼한 청년\"을 칭찬하는 쪽지를 남겼다.",
   "손님이 자기 실수 이야기를 해 주고 칭찬 쪽지를 남김"),
  "{2}의 'that room(그 방)'은 {1}의 507호를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'She(그녀)'는 {2}에 처음 나온 나이 지긋한 손님을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 쟁반을 {1}의 'eleven of them(그것들 가운데 열한 개)'이 받습니다. {2}의 'that room'은 {1}의 507호를, {3}의 'She'는 {2}의 손님을 가리킵니다.")

# 20 ─ 회상: 유리 상자 속의 탄 빵
S(19, 'DCB',
  ("Mr. Jang, who owns a large bakery, keeps a burnt loaf in a glass case in his office, and visitors often ask him why.",
   "큰 빵집을 운영하는 장 씨는 사무실의 유리 상자에 탄 빵 한 덩이를 넣어 두는데, 찾아온 사람들은 종종 그 까닭을 묻는다."),
  ("He tells them that it was the first loaf he ever baked, in a small shop where he swept the floor at fifteen. He had forgotten it in the oven.",
   "그는 그것이 열다섯 살 때 바닥 청소를 하던 작은 가게에서 난생처음 구운 빵이라고 말해 준다. 그는 빵을 오븐에 넣어 둔 채 잊어버렸던 것이다.",
   "열다섯 살 때 작은 가게에서 처음 구워 태운 빵"),
  ("The baker who owned that shop did not shout at him. He only cut the black loaf in half and showed him that the middle was still soft.",
   "그 가게의 주인인 제빵사는 그에게 소리를 지르지 않았다. 그는 까맣게 탄 빵을 반으로 갈라 속은 아직 부드럽다는 것을 보여 주었을 뿐이다.",
   "가게 주인인 제빵사가 빵을 갈라 속을 보여 줌"),
  ("He held out one of the halves. \"A bad outside can hide a good inside,\" he said, \"and that is true of boys too.\"",
   "그는 반쪽 하나를 내밀었다. \"겉이 나빠도 속은 좋을 수 있지. 사내아이도 마찬가지란다.\"라고 그는 말했다.",
   "제빵사가 반쪽을 내밀며 한마디를 해 줌"),
  "{2}의 'that shop(그 가게)'과 'the black loaf(까맣게 탄 빵)'는 {1}의 작은 가게와 태운 빵을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'one of the halves(반쪽 하나)'는 {2}에서 제빵사가 빵을 반으로 가른 뒤에야 나올 수 있으므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 방문객들을 {1}의 'He tells them(그는 그들에게 말해 준다)'이 받습니다. {2}의 'that shop'은 {1}의 가게를 가리키고, {3}의 'one of the halves'는 {2}에서 반으로 가른 빵의 반쪽입니다.")

# 21 ─ 주고받는 말: 울타리를 칠하는 날
S(20, 'BDC',
  ("Ellen was painting the fence in front of her house when a small boy stopped and watched her for several minutes.",
   "엘런이 집 앞 울타리를 칠하고 있는데, 한 꼬마가 멈춰 서서 몇 분 동안 그녀를 지켜보았다."),
  ("At last he asked whether painting was difficult. Ellen said that it was not, and she held out a second brush which was lying on the grass.",
   "마침내 그는 칠하는 것이 어려운지 물었다. 엘런은 어렵지 않다고 말하고, 풀밭에 놓여 있던 또 하나의 붓을 내밀었다.",
   "꼬마가 묻자 엘런이 붓을 내밂"),
  ("He took it and painted one board very slowly. When he had finished, he asked how much he owed her for the lesson.",
   "그는 그 붓을 받아 판자 하나를 아주 천천히 칠했다. 다 칠하고 나서 그는 가르쳐 준 값으로 얼마를 드려야 하느냐고 물었다.",
   "꼬마가 판자 하나를 칠하고 값이 얼마냐고 물음"),
  ("Ellen laughed at this second question and said that the lesson was free. The boy came back with two friends the next day, and the fence was finished by evening.",
   "엘런은 이 두 번째 질문에 웃으며, 가르쳐 준 것은 공짜라고 말했다. 그 아이는 다음 날 친구 둘을 데리고 다시 왔고, 울타리는 저녁 무렵 다 칠해졌다.",
   "엘런이 공짜라고 답하고, 다음 날 아이들이 와서 끝냄"),
  "{2}의 'He took it(그는 그것을 받았다)'의 'it'은 {1}에서 엘런이 내민 붓이므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'this second question(이 두 번째 질문)'은 {2}에서 아이가 값이 얼마냐고 물은 것을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 지켜보기만 하던 아이가 'At last(마침내)' 말을 거는 {1}가 먼저입니다. {2}의 'it'은 {1}의 붓을, {3}의 'this second question'은 {2}의 값을 묻는 질문을 가리킵니다.")

# 22 ─ 뜻밖의 결말: 버스에서 주운 열쇠
S(21, 'CDB',
  ("Victor found a set of keys on the bus, with a metal tag which gave an address far across the city.",
   "빅터는 버스에서 열쇠 꾸러미를 주웠는데, 거기 달린 쇠 이름표에는 도시 반대편의 주소가 적혀 있었다."),
  ("He took two more buses to reach that address, which was a tiny shoe-repair shop. An old man was sitting on the step outside, unable to get in.",
   "그는 버스를 두 번 더 갈아타고 그 주소로 갔는데, 그곳은 아주 작은 구두 수선 가게였다. 한 노인이 안으로 들어가지 못한 채 가게 앞 계단에 앉아 있었다.",
   "주소를 찾아가니 구두 수선 가게 앞에 노인이 앉아 있음"),
  ("The old man unlocked the door at once and offered him money as a reward. Victor refused it but mentioned that the sole of his shoe was coming off.",
   "노인은 곧바로 문을 열고는 사례로 돈을 주려 했다. 빅터는 사양했지만, 자기 신발 밑창이 떨어지려 한다는 말을 꺼냈다.",
   "노인이 문을 열고 사례하려 하자 사양하고 밑창 이야기를 함"),
  ("Ten minutes later that sole had been glued and sewn for nothing. Victor walked back to the bus stop in the best-mended shoes he had ever owned.",
   "10분 뒤 그 밑창은 돈 한 푼 받지 않고 붙이고 꿰매어져 있었다. 빅터는 지금껏 가져 본 것 가운데 가장 잘 고쳐진 신발을 신고 버스 정류장으로 걸어 돌아갔다.",
   "노인이 그 밑창을 공짜로 고쳐 줌"),
  "{2}의 'The old man(그 노인)'은 {1}에서 가게 앞에 앉아 있던 'An old man(한 노인)'을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that sole(그 밑창)'은 {2}에서 빅터가 말한 떨어지려는 신발 밑창을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 주소를 {1}의 'that address(그 주소)'가 받습니다. {2}의 'The old man'은 {1}의 'An old man'을, {3}의 'that sole'은 {2}의 신발 밑창을 가리킵니다.")

# 23 ─ 두 사람이 번갈아: 스웨터와 초콜릿
S(22, 'DBC',
  ("Minji and Sua, who had been best friends since primary school, stopped speaking after a quarrel about a borrowed sweater.",
   "초등학교 때부터 단짝이던 민지와 수아는 빌려 간 스웨터 때문에 다툰 뒤 서로 말을 하지 않게 되었다."),
  ("For a week they sat at opposite ends of the classroom. Then Minji found the sweater in her locker, washed and folded, with a chocolate bar on top.",
   "일주일 동안 두 사람은 교실의 양쪽 끝에 떨어져 앉았다. 그러다 민지는 사물함에서 깨끗이 빨아 개어 놓은 스웨터와 그 위에 놓인 초콜릿 하나를 발견했다.",
   "민지가 사물함에서 스웨터와 초콜릿을 발견함"),
  ("She ate half of the chocolate and left the other half in Sua's locker with a note. The note said only, \"I was wrong too.\"",
   "그녀는 초콜릿을 절반만 먹고 나머지 절반을 쪽지와 함께 수아의 사물함에 넣어 두었다. 쪽지에는 \"나도 잘못했어.\"라고만 적혀 있었다.",
   "민지가 초콜릿 반쪽과 쪽지를 수아의 사물함에 둠"),
  ("Sua read it between lessons and walked straight across the classroom. Neither of them could remember afterwards who had said sorry first.",
   "수아는 쉬는 시간에 그것을 읽고 곧장 교실을 가로질러 걸어갔다. 나중에 두 사람 모두 누가 먼저 미안하다고 했는지 기억하지 못했다.",
   "수아가 쪽지를 읽고 곧장 다가감"),
  "{2}의 'the chocolate(그 초콜릿)'은 {1}에서 스웨터 위에 놓여 있던 초콜릿을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'Sua read it(수아는 그것을 읽었다)'의 'it'은 {2}에서 민지가 남긴 쪽지이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글에서 말을 하지 않게 되었으므로, 'For a week(일주일 동안)' 떨어져 앉았다는 {1}가 먼저입니다. {2}의 'the chocolate'은 {1}의 초콜릿을, {3}의 'it'은 {2}의 쪽지를 가리킵니다.")

# 24 ─ 장소 이동: 손자의 졸업식에 가는 길
S(23, 'CBD',
  ("Mr. Noh had not left his village for ten years, but he decided to travel to Seoul alone to see his grandson graduate.",
   "노 씨 할아버지는 10년 동안 마을을 떠난 적이 없었지만, 손자의 졸업식을 보려고 혼자 서울에 가기로 했다."),
  ("At the bus terminal he could not understand the ticket machine. A student who was waiting in line pressed the buttons for him.",
   "버스 터미널에서 그는 승차권 기계를 다룰 줄 몰랐다. 줄을 서 있던 한 학생이 그를 대신해 단추를 눌러 주었다.",
   "터미널에서 한 학생이 표 사는 것을 도와줌"),
  ("The same student happened to sit next to him on the bus. When she heard where he was going, she drew a subway map on the back of his ticket.",
   "바로 그 학생이 우연히 버스에서 그의 옆자리에 앉았다. 그가 어디로 가는지 듣고, 그녀는 그의 표 뒷면에 지하철 약도를 그려 주었다.",
   "그 학생이 버스에서 지하철 약도를 그려 줌"),
  ("With that map he changed trains twice without getting lost. He walked into the hall just as his grandson's name was being called.",
   "그 약도 덕분에 그는 길을 잃지 않고 지하철을 두 번 갈아탔다. 그가 식장에 들어섰을 때 마침 손자의 이름이 불리고 있었다.",
   "그 약도를 따라 식장에 제때 도착함"),
  "{2}의 'The same student(바로 그 학생)'는 {1}에서 표 사는 것을 도와준 학생을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that map(그 약도)'은 {2}에서 학생이 그려 준 지하철 약도를 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "장소가 터미널{1} → 버스 안{2} → 지하철과 식장{3}으로 옮겨 갑니다. {2}의 'The same student'는 {1}의 학생을, {3}의 'that map'은 {2}의 약도를 가리킵니다.")

# 25 ─ 하루의 일: 한 조각이 모자란 퍼즐
S(24, 'CDB',
  ("One rainy Sunday, Daeun and her grandfather opened a jigsaw puzzle of a thousand pieces, which they hoped to finish before bedtime.",
   "비 오는 어느 일요일, 다은과 할아버지는 천 조각짜리 그림 퍼즐을 펼쳤고, 잠자리에 들기 전에 다 맞추고 싶어 했다."),
  ("By noon they had built the frame and most of the sky. Then they counted what was left and found that one piece was missing.",
   "정오까지 두 사람은 테두리와 하늘의 대부분을 맞추었다. 그러고 나서 남은 조각을 세어 보니 한 조각이 모자랐다.",
   "정오에 한 조각이 모자란 것을 앎"),
  ("The missing piece belonged to the middle of the picture, where a red boat should have been. They searched under the sofa all afternoon without success.",
   "그 모자란 조각은 빨간 배가 있어야 할 그림 한가운데의 것이었다. 두 사람은 오후 내내 소파 밑을 뒤졌지만 찾지 못했다.",
   "모자란 조각은 한가운데의 빨간 배였고 오후 내내 찾지 못함"),
  ("So Daeun cut a new piece from the lid of the box and painted that boat on it herself. At nine the puzzle was complete.",
   "그래서 다은은 상자 뚜껑에서 새 조각을 오려 내어 그 배를 직접 그려 넣었다. 아홉 시에 퍼즐은 완성되었다.",
   "다은이 새 조각에 그 배를 그려 넣어 아홉 시에 완성함"),
  "{2}의 'The missing piece(그 모자란 조각)'는 {1}에서 한 조각이 모자란 것을 알게 된 뒤에 나올 말이므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that boat(그 배)'는 {2}에서 그림 한가운데에 있어야 한다고 한 빨간 배를 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "시간이 정오{1} → 오후 내내{2} → 아홉 시{3}로 흐릅니다. {2}의 'The missing piece'는 {1}에서 모자란 한 조각을, {3}의 'that boat'는 {2}의 빨간 배를 가리킵니다.")

# 26 ─ 회상: 해마다 심는 해바라기 씨앗
S(25, 'CBD',
  ("Every April, Ms. Ha plants a single sunflower seed beside the gate of the school where she teaches.",
   "해마다 4월이면 하 선생님은 자신이 가르치는 학교의 교문 옆에 해바라기 씨앗 하나를 심는다."),
  ("She began doing this after her first year as a teacher. On its last day, a boy who had hardly spoken all year gave her a seed in a paper cup.",
   "그녀는 교사로서 첫해를 보낸 뒤 이 일을 시작했다. 그해 마지막 날, 일 년 내내 거의 말이 없던 남학생이 종이컵에 담긴 씨앗 하나를 그녀에게 주었다.",
   "첫해 마지막 날 말이 없던 남학생이 씨앗이 든 종이컵을 줌"),
  ("She put the cup on a shelf and forgot it over the holiday. When she came back, a thin green shoot was leaning toward the window.",
   "그녀는 그 컵을 선반에 올려놓고 방학 동안 잊고 지냈다. 돌아와 보니 가느다란 초록 싹이 창문 쪽으로 기울어 있었다.",
   "잊고 둔 그 컵에서 싹이 돋아 있음"),
  ("She has never forgotten that stubborn little shoot. Each new sunflower reminds her that quiet children can be growing even when nobody is watching.",
   "그녀는 그 고집 센 작은 싹을 한 번도 잊은 적이 없다. 새 해바라기를 볼 때마다 그녀는 조용한 아이들도 아무도 지켜보지 않는 사이에 자라고 있을 수 있음을 떠올린다.",
   "그 싹을 잊지 않고 해마다 떠올림"),
  "{2}의 'the cup(그 컵)'은 {1}에서 남학생이 준 종이컵을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that stubborn little shoot(그 고집 센 작은 싹)'은 {2}에서 창문 쪽으로 기울어 있던 싹을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 씨앗 심기를 {1}의 'doing this(이 일을 하는 것)'가 받습니다. {2}의 'the cup'은 {1}의 종이컵을, {3}의 'that stubborn little shoot'은 {2}의 싹을 가리킵니다.")

# 27 ─ 주고받는 말: 바다는 왜 짤까
S(26, 'DBC',
  ("Five-year-old Rin once asked her grandfather, who was a fisherman, why the sea was salty.",
   "다섯 살 린은 어느 날 어부인 할아버지에게 바다는 왜 짜냐고 물었다."),
  ("He did not know the real answer, so he invented one. Long ago, he said, a giant had dropped his salt jar into the water while he was cooking.",
   "그는 진짜 답을 몰라서 하나 지어냈다. 아주 오래전에 한 거인이 요리를 하다가 소금 단지를 물에 빠뜨렸다고 그는 말했다.",
   "할아버지가 소금 단지를 빠뜨린 거인 이야기를 지어냄"),
  ("Rin thought about the giant for a while and then asked what he had been cooking. Her grandfather, who had not prepared for this, said that it was seaweed soup.",
   "린은 그 거인에 대해 한동안 생각하더니 거인이 무엇을 요리하고 있었느냐고 물었다. 이런 질문에 준비가 안 된 할아버지는 미역국이라고 말했다.",
   "린이 무슨 요리였느냐고 되묻자 미역국이라고 답함"),
  ("\"Then the seaweed is still in there,\" she said, and he had to agree. Rin grew up to be a marine scientist, and she still tells this story.",
   "\"그럼 미역이 아직 그 안에 있겠네요.\"라고 그녀가 말했고, 그는 그렇다고 할 수밖에 없었다. 린은 자라서 해양 과학자가 되었고, 지금도 이 이야기를 들려준다.",
   "린이 '그럼 미역이 아직 있겠다'고 받아침"),
  "{2}의 'the giant(그 거인)'는 {1}에서 할아버지가 지어낸 이야기 속 거인을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'the seaweed(그 미역)'는 {2}에서 할아버지가 말한 미역국의 미역이므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 질문에 대해 '진짜 답을 몰랐다'고 잇는 {1}가 먼저입니다. {2}의 'the giant'는 {1}의 거인을, {3}의 'the seaweed'는 {2}의 미역국을 가리킵니다.")

# 28 ─ 뜻밖의 결말: 손을 흔들어 주지 않는 전학생
S(27, 'BDC',
  ("Chanho was certain that the new student, Leo, disliked him, because Leo never waved back when Chanho waved from across the playground.",
   "찬호는 새로 전학 온 레오가 자기를 싫어한다고 확신했는데, 운동장 건너편에서 손을 흔들어도 레오가 한 번도 마주 흔들어 주지 않았기 때문이다."),
  ("One day Chanho complained about it to their class teacher. She listened and then told him something that the rest of the class had not yet heard.",
   "어느 날 찬호는 담임 선생님에게 그 일을 불평했다. 선생님은 이야기를 듣고 나서, 반의 다른 아이들은 아직 듣지 못한 사실을 그에게 알려 주었다.",
   "찬호가 담임 선생님에게 불평함"),
  ("Leo could hardly see anything more than a few steps away, she said, and his new glasses had not arrived. She suggested trying again from much closer.",
   "레오는 몇 걸음만 떨어져도 거의 보지 못하는데 새 안경이 아직 오지 않았다고 선생님은 말했다. 선생님은 훨씬 가까이에서 다시 해 보라고 권했다.",
   "레오가 멀리 있는 것을 잘 못 본다는 사실을 듣고 조언을 받음"),
  ("The next morning Chanho followed this advice and waved from right in front of Leo. Leo grinned and waved back at once, and they walked to class together.",
   "다음 날 아침 찬호는 이 조언대로 레오 바로 앞에서 손을 흔들었다. 레오는 활짝 웃으며 곧바로 손을 흔들어 주었고, 두 사람은 함께 교실로 걸어갔다.",
   "조언대로 가까이에서 손을 흔들자 레오가 마주 흔들어 줌"),
  "{2}의 'she said(선생님이 말했다)'의 'she'는 {1}의 담임 선생님이고, {2}의 내용은 {1}에서 예고한 '다른 아이들은 아직 듣지 못한 사실'이므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'this advice(이 조언)'는 {2}에서 선생님이 더 가까이에서 해 보라고 권한 것을 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 일을 {1}의 'it'이 받아 선생님에게 이야기합니다. {2}는 {1}에서 예고한 사실을 밝히고, {3}의 'this advice'는 {2}의 '가까이에서 다시 해 보라'는 권유를 가리킵니다.")

# 29 ─ 두 사람이 번갈아: 바이올린과 새
S(28, 'CDB',
  ("Clara, a violinist, used to practise every evening by an open window, and one summer a blackbird in the tree outside began to listen.",
   "바이올린 연주자인 클라라는 저녁마다 열린 창가에서 연습하곤 했는데, 어느 여름 창밖 나무의 검은지빠귀 한 마리가 귀를 기울이기 시작했다."),
  ("After a few weeks the bird started to copy the first four notes of her favourite piece. It sang them back to her each time she stopped.",
   "몇 주가 지나자 그 새는 그녀가 가장 좋아하는 곡의 첫 네 음을 따라 하기 시작했다. 새는 그녀가 멈출 때마다 그 음들을 되받아 불렀다.",
   "새가 첫 네 음을 따라 부르기 시작함"),
  ("She was amused and answered those four notes with the next four, which she played slowly again and again. The bird needed nine days to learn them.",
   "재미있어진 그녀는 그 네 음에 이어지는 다음 네 음으로 답하며, 그것을 천천히 되풀이해 연주했다. 새가 그것을 익히는 데는 아흐레가 걸렸다.",
   "클라라가 다음 네 음을 들려주고 새가 아흐레 만에 익힘"),
  ("After those nine days each new group of notes came faster. By autumn the two could finish the first line together, and the neighbours opened their windows to listen.",
   "그 아흐레가 지나자 새로운 음들은 점점 빨리 익혀졌다. 가을 무렵 둘은 첫 줄을 함께 마칠 수 있었고, 이웃들은 창문을 열고 귀를 기울였다.",
   "그 뒤로 점점 빨라져 가을에는 첫 줄을 함께 마침"),
  "{2}의 'those four notes(그 네 음)'는 {1}에서 새가 따라 한 첫 네 음을 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'those nine days(그 아흐레)'는 {2}에서 새가 다음 네 음을 익히는 데 걸린 아흐레를 가리키므로 {2}보다 먼저 올 수 없습니다.",
  "주어진 글의 검은지빠귀를 {1}의 'the bird(그 새)'가 받습니다. {2}의 'those four notes'는 {1}의 첫 네 음을, {3}의 'those nine days'는 {2}의 아흐레를 가리킵니다.")

# 30 ─ 장소 이동: 번지수 없는 소포
S(29, 'CBD',
  ("Sangmin, a delivery rider, was given a parcel with no house number on it, only the words \"the blue door near the old well.\"",
   "배달 기사인 상민은 번지수 없이 \"옛 우물 근처의 파란 문\"이라는 말만 적힌 소포를 받았다."),
  ("He asked at a rice shop in the oldest part of town. The owner knew of no well, but she sent him to a barber who had worked nearby for fifty years.",
   "그는 동네에서 가장 오래된 구역의 쌀가게에 물었다. 주인은 우물을 알지 못했지만, 근처에서 50년 동안 일해 온 이발사에게 그를 보냈다.",
   "쌀가게 주인이 50년 된 이발사에게 가 보라고 함"),
  ("The barber remembered the well, which had been covered by a car park long ago. He pointed with his scissors to a narrow lane behind it.",
   "이발사는 그 우물을 기억했는데, 우물은 오래전에 주차장으로 덮였다고 했다. 그는 가위로 주차장 뒤의 좁은 골목을 가리켰다.",
   "이발사가 우물 자리와 그 뒤의 좁은 골목을 알려 줌"),
  ("At the end of that lane there was indeed a blue door. The old woman who opened it said that she had been waiting for the parcel all week.",
   "그 골목 끝에는 정말로 파란 문이 있었다. 문을 연 할머니는 일주일 내내 그 소포를 기다리고 있었다고 말했다.",
   "그 골목 끝에서 파란 문을 찾아 소포를 전함"),
  "{2}의 'The barber(그 이발사)'는 {1}에서 쌀가게 주인이 알려 준 'a barber(한 이발사)'를 가리키므로 {1}보다 먼저 올 수 없습니다.",
  "{3}의 'that lane(그 골목)'은 {2}에서 이발사가 가리킨 좁은 골목이므로 {2}보다 먼저 올 수 없습니다.",
  "장소가 쌀가게{1} → 이발소{2} → 골목 끝의 파란 문{3}으로 옮겨 갑니다. {2}의 'The barber'는 {1}의 'a barber'를, {3}의 'that lane'은 {2}의 'a narrow lane'을 가리킵니다.")

assert len(E) == 30
