# 171번: 44번(가리키는 대상이 다른 것) 레벨4 틀 재작성 — 30문항 전부 (선생님 승인: "셋 다, 유형마다 다른 이야기" · "30문항 전부")
#   · 정답 번호는 그대로. 두 인물은 같은 성별, 넷은 A·하나는 B. B는 글 첫머리(첫째~둘째 문장)에서 소개
#   · 가리키는 말의 꼴(주어 he/she · 목적어 him/her · 소유 his/her)과 자리를 섞고, 정답 문장에만 나타나는 꼴(had+p.p. 등)을 없앰
AUTO_SYNC = False
E = {}
L = ['(a)', '(b)', '(c)', '(d)', '(e)']

def item(n, ans, A, B, sents, refs):
    # n: 문항 번호(0부터) / ans: 정답 자리(0~4) / A: 넷이 가리키는 사람 / B: 혼자 다른 사람
    # sents: [(영어, 해석)] / refs: (a)~(e) 차례로 '누구인지 알 수 있는 까닭' 다섯 개
    text = ' '.join(e for e, k in sents); ko = ' '.join(k for e, k in sents)
    assert all(text.count(x) == 1 and ko.count(x) == 1 for x in L), (n, [text.count(x) for x in L], [ko.count(x) for x in L])
    assert len(refs) == 5
    cn = []
    for k, why in enumerate(refs):
        if k == ans: cn.append("%s가 정답입니다. %s → %s. %s 나머지 넷은 모두 %s입니다." % (L[k], L[k], B, why, A))
        else: cn.append("%s → %s. %s" % (L[k], A, why))
    e, kk = [x for x in sents if L[ans] in x[0]][0]
    walk = "%s가 든 문장을 봅니다. '%s' (%s) %s 나머지 넷은 모두 %s입니다. 따라서 %s가 정답입니다." % (L[ans], e, kk, refs[ans], A, L[ans])
    assert ('44', '4', n) not in E, n
    E[('44', '4', n)] = {'passage_ok': True, 'ans_ok': True, '_ans': ans, 'rewrite': {'text': text, 'choices': list(L), 'ko': ko, 'walk': walk, 'cn': cn}}

item(0, 2, '혜진', '이모',
 [("Hyejin spent the winter holiday at the noodle restaurant which her aunt ran.", "혜진은 이모가 운영하는 국숫집에서 겨울 방학을 보냈다."),
  ("On the first morning her aunt gave (a)her an apron and a heavy knife.", "첫날 아침 이모는 (a)그녀에게 앞치마와 묵직한 칼을 주었다."),
  ("The girl cut the dough so slowly that (b)she finished only one bowl in an hour.", "소녀는 반죽을 너무 천천히 썰어서 (b)그녀는 한 시간에 한 그릇 분량밖에 끝내지 못했다."),
  ("Her aunt did not hurry the girl, for the same knife was once slow in (c)her own hands.", "이모는 소녀를 재촉하지 않았는데, 그 칼이 한때는 (c)그녀 자신의 손에서도 느렸기 때문이다."),
  ("By February the girl was almost as fast, and customers began to ask for (d)her noodles.", "2월이 되자 소녀는 거의 그만큼 빨라졌고, 손님들은 (d)그녀의 국수를 찾기 시작했다."),
  ("When the holiday ended, the girl took the apron home, and (e)she still wears it.", "방학이 끝나자 소녀는 앞치마를 집으로 가져갔고, (e)그녀는 지금도 그것을 입는다.")],
 ["이모가 앞치마와 칼을 준 상대는 혜진입니다.", "반죽을 천천히 썬 소녀, 곧 혜진입니다.", "'her own hands'는 이 문장의 주어인 이모 자신의 손입니다. 이모도 한때는 칼질이 느렸다는 뜻입니다.", "칼질이 빨라진 소녀의 국수이므로 혜진입니다.", "앞치마를 집으로 가져간 소녀, 곧 혜진입니다."])

item(1, 1, '민재', '삼촌',
 [("Minjae was afraid of bees, but his uncle, who kept forty hives, needed help for one summer.", "민재는 벌을 무서워했지만, 벌통 마흔 개를 치는 삼촌이 한여름 동안 일손이 필요했다."),
  ("On the first day the boy stood far from the hives, and (a)he kept a net over his head.", "첫날 소년은 벌통에서 멀찍이 서 있었고, (a)그는 머리에 그물망을 쓰고 있었다."),
  ("His uncle lifted a frame full of bees with bare hands because (b)he knew that slow movements kept them calm.", "삼촌은 벌이 가득 붙은 벌집틀을 맨손으로 들어 올렸는데, 천천히 움직이면 벌이 얌전하다는 것을 (b)그는 알고 있었기 때문이다."),
  ("After a week his uncle handed the boy a frame, and (c)he held it without breathing.", "일주일 뒤 삼촌이 소년에게 벌집틀 하나를 건넸고, (c)그는 숨도 쉬지 않고 그것을 들고 있었다."),
  ("Not one bee stung (d)him that day.", "그날 벌은 한 마리도 (d)그를 쏘지 않았다."),
  ("In August the boy filled the first jar, and (e)he wrote his own name on the label.", "8월에 소년은 첫 번째 병을 채웠고, (e)그는 상표에 자기 이름을 썼다.")],
 ["멀찍이 서서 그물망을 쓴 사람은 벌을 무서워하는 소년, 곧 민재입니다.", "맨손으로 벌집틀을 들 수 있는 까닭을 아는 사람은 삼촌입니다. 'because' 뒤의 주어는 앞의 'His uncle'과 같습니다.", "삼촌에게서 벌집틀을 건네받아 숨죽이고 든 사람은 민재입니다.", "처음 벌집틀을 든 날 쏘이지 않은 사람이므로 민재입니다.", "첫 병을 채운 소년, 곧 민재입니다."])

item(2, 1, '예린', '배 씨 할머니',
 [("A green parrot escaped from the home of Mrs. Bae, who had just moved into Yerin's street.", "예린이 사는 골목에 막 이사 온 배 씨 할머니의 집에서 초록 앵무새 한 마리가 달아났다."),
  ("The next morning Yerin heard \"Good morning\" from a tree, and (a)she saw the bird on a branch.", "다음 날 아침 예린은 나무에서 \"좋은 아침\"이라는 소리를 들었고, (a)그녀는 나뭇가지에 앉은 그 새를 보았다."),
  ("Mrs. Bae was searching everywhere, and notices in (b)her handwriting appeared on every wall.", "배 씨 할머니는 사방을 찾아다니고 있었고, (b)그녀의 손글씨로 쓴 전단이 담벼락마다 붙었다."),
  ("The girl saw one on her way to school and called the number before (c)she went into class.", "소녀는 등굣길에 그 전단 하나를 보고, (c)그녀가 교실에 들어가기 전에 그 번호로 전화를 걸었다."),
  ("That evening the old woman came with a cage and thanked (d)her many times.", "그날 저녁 할머니는 새장을 들고 와서 (d)그녀에게 여러 번 고맙다고 했다."),
  ("The parrot now greets the girl whenever (e)she walks past.", "이제 그 앵무새는 (e)그녀가 지나갈 때마다 소녀에게 인사한다.")],
 ["나무에서 소리를 듣고 새를 본 사람은 예린입니다.", "새를 찾는 전단을 손으로 써 붙인 사람은 새 주인인 배 씨 할머니입니다.", "등굣길에 전단을 보고 전화한 소녀, 곧 예린입니다.", "할머니가 고맙다고 한 상대는 새를 찾아 준 예린입니다.", "앵무새가 인사하는 소녀, 곧 예린입니다."])

item(3, 1, '톰', '리드 코치',
 [("Tom, the goalkeeper of his school team, let in three penalties in one match.", "학교 축구팀 골키퍼인 톰은 한 경기에서 페널티킥 세 개를 내주었다."),
  ("The next day Mr. Reed, the coach, stayed after training and took fifty penalties at (a)him.", "다음 날 리드 코치는 훈련이 끝난 뒤 남아서 (a)그를 상대로 페널티킥 쉰 개를 찼다."),
  ("At first the boy dived the wrong way almost every time.", "처음에 소년은 거의 매번 엉뚱한 쪽으로 몸을 날렸다."),
  ("The coach then showed (b)his own trick: watch the kicker's hips, not the ball.", "그러자 코치는 (b)그 자신의 비결을 보여 주었다. 공이 아니라 차는 사람의 허리를 보라는 것이었다."),
  ("Tom tried it and found that (c)he could guess the direction more often.", "톰은 그대로 해 보았고, (c)그가 방향을 더 자주 맞힐 수 있다는 것을 알았다."),
  ("By Friday (d)he was stopping half of the shots.", "금요일 무렵 (d)그는 슛의 절반을 막아 내고 있었다."),
  ("In the next match the boy saved a penalty, and the whole team ran to lift (e)him.", "다음 경기에서 소년은 페널티킥을 막아 냈고, 팀 전체가 달려와 (e)그를 들어 올렸다.")],
 ["코치가 페널티킥을 차는 상대는 골키퍼인 톰입니다.", "'his own trick'은 이 문장의 주어인 코치 자신의 비결입니다.", "비결을 써 보고 방향을 맞히게 된 사람은 톰입니다.", "슛을 막는 사람은 골키퍼인 톰입니다.", "페널티킥을 막아 팀이 들어 올린 소년, 곧 톰입니다."])

item(4, 1, '사라', '할머니',
 [("Sara's grandmother lived alone by the sea and had never used a smartphone.", "사라의 할머니는 바닷가에 혼자 살았고 스마트폰을 한 번도 써 본 적이 없었다."),
  ("When Sara visited in spring, (a)she brought an old phone and a list of five simple steps.", "봄에 사라가 찾아갔을 때, (a)그녀는 쓰던 전화기와 간단한 다섯 단계를 적은 종이를 가져갔다."),
  ("Her grandmother was nervous about breaking it, so (b)she touched the screen with only one finger.", "할머니는 전화기를 망가뜨릴까 봐 조마조마해서, (b)그녀는 손가락 하나로만 화면을 건드렸다."),
  ("The girl did not laugh; (c)she just drew a big arrow next to each step.", "소녀는 웃지 않았다. (c)그녀는 단계마다 옆에 큰 화살표를 그려 넣었을 뿐이다."),
  ("After three days Sara went home to Seoul, and the next evening (d)her phone rang.", "사흘 뒤 사라는 서울 집으로 돌아갔고, 다음 날 저녁 (d)그녀의 전화가 울렸다."),
  ("A smiling face filled the screen.", "웃는 얼굴이 화면을 가득 채웠다."),
  ("Now her grandmother calls (e)her every Sunday.", "이제 할머니는 일요일마다 (e)그녀에게 전화를 건다.")],
 ["할머니를 찾아가며 전화기를 가져간 사람은 사라입니다.", "망가뜨릴까 봐 조마조마해서 손가락 하나로만 건드린 사람은 할머니입니다.", "웃지 않고 화살표를 그려 준 소녀, 곧 사라입니다.", "서울로 돌아간 사라의 전화입니다.", "할머니가 전화를 거는 상대는 사라입니다."])

item(5, 1, '훈', '최 씨 아저씨',
 [("Hoon kicked a ball into the school flower beds and was sent to help Mr. Choi, the gardener, for a week.", "훈은 학교 꽃밭으로 공을 차 넣어서, 일주일 동안 정원사인 최 씨 아저씨를 돕게 되었다."),
  ("The boy arrived on Monday, and (a)he expected to be bored.", "소년은 월요일에 왔고, (a)그는 지루할 것이라고 생각했다."),
  ("The old man hardly spoke, but (b)he showed how to plant pumpkin seeds in neat rows.", "노인은 말이 거의 없었지만, (b)그는 호박씨를 줄 맞춰 심는 법을 보여 주었다."),
  ("Hoon watered them every afternoon, even after (c)his week of punishment was over.", "훈은 (c)그의 벌 받는 일주일이 끝난 뒤에도 오후마다 물을 주었다."),
  ("In October the gardener carved a face on the biggest pumpkin and told the boy to carry it to (d)his classroom.", "10월에 정원사는 가장 큰 호박에 얼굴을 새기고, 소년에게 그것을 (d)그의 교실로 가져가라고 했다."),
  ("Hoon joined the garden club, and (e)he is its leader now.", "훈은 원예 동아리에 들어갔고, (e)그는 지금 그 동아리의 대표이다.")],
 ["월요일에 와서 지루할 것이라 생각한 소년, 곧 훈입니다.", "말이 거의 없지만 심는 법을 보여 준 노인, 곧 최 씨 아저씨입니다.", "벌로 일주일을 보낸 사람은 훈입니다.", "교실이 있는 사람은 학생인 훈입니다. 정원사가 소년에게 '그의 교실'로 가져가라고 한 것입니다.", "동아리에 들어가 대표가 된 사람은 훈입니다."])

item(6, 1, '리나', '다나',
 [("Lina and her classmate Dana were partners for the science fair.", "리나와 같은 반 다나는 과학 박람회의 짝이었다."),
  ("Lina wanted to build a model volcano, and (a)she spent a whole weekend making it from clay.", "리나는 화산 모형을 만들고 싶어 했고, (a)그녀는 주말 내내 찰흙으로 그것을 만들었다."),
  ("The quieter job of writing the labels went to Dana, and (b)her careful letters filled every card.", "이름표를 쓰는 조용한 일은 다나가 맡았고, (b)그녀의 꼼꼼한 글씨가 카드마다 채워졌다."),
  ("At the fair the volcano would not erupt, and Lina's face turned red.", "박람회에서 화산은 터지지 않았고, 리나의 얼굴이 빨개졌다."),
  ("Her partner whispered to (c)her that the bottle inside was upside down.", "짝이 (c)그녀에게 안에 든 병이 거꾸로 놓였다고 속삭였다."),
  ("Lina turned it over, and red foam poured out.", "리나가 병을 바로 놓자 붉은 거품이 쏟아져 나왔다."),
  ("When the judges asked who had built it, Dana pointed at (d)her.", "심사위원들이 누가 만들었느냐고 묻자, 다나는 (d)그녀를 가리켰다."),
  ("But Lina said that (e)she could not have done it alone.", "하지만 리나는 (e)그녀 혼자서는 해낼 수 없었을 것이라고 말했다.")],
 ["화산 모형을 만든 사람은 리나입니다.", "이름표 쓰는 일을 맡은 사람이 다나이므로, 꼼꼼한 글씨는 다나의 것입니다.", "'Her partner'는 다나이고, 다나가 속삭인 상대는 얼굴이 빨개진 리나입니다.", "다나가 가리킨 사람은 화산을 만든 리나입니다.", "혼자서는 못 했을 것이라고 말한 사람은 리나 자신입니다."])

item(7, 2, '준', '아버지',
 [("Jun's family had a new puppy, and his father agreed to build a kennel for it with him.", "준의 가족은 새로 강아지를 들였고, 그의 아버지는 그와 함께 개집을 만들어 주기로 했다."),
  ("In the shop Jun chose the wood, and (a)he picked a pale pine that smelled of the forest.", "가게에서 준은 나무를 골랐는데, (a)그는 숲 냄새가 나는 연한 소나무를 골랐다."),
  ("His father marked the lines, but he handed the saw to the boy and let (b)him cut.", "아버지는 선을 그었지만, 톱은 소년에게 건네고 (b)그가 자르게 했다."),
  ("The first wall came out crooked.", "첫 번째 벽은 비뚤게 잘렸다."),
  ("His father only laughed, because (c)he remembered making the same mistake at that age.", "아버지는 그저 웃었는데, 그 나이에 똑같은 실수를 했던 것을 (c)그가 기억했기 때문이다."),
  ("Jun cut the next piece more slowly, and (d)he measured twice.", "준은 다음 판을 더 천천히 잘랐고, (d)그는 두 번씩 쟀다."),
  ("The kennel still leans a little, but the puppy sleeps in it every night with (e)his old sweater.", "개집은 아직도 조금 기울어 있지만, 강아지는 밤마다 (e)그의 낡은 스웨터를 깔고 그 안에서 잔다.")],
 ["나무를 고른 사람은 준입니다.", "아버지가 톱을 건네 자르게 한 사람은 소년, 곧 준입니다.", "'그 나이에' 같은 실수를 했던 것을 떠올리며 웃은 사람은 아버지입니다.", "다음 판을 자르며 두 번씩 잰 사람은 준입니다.", "개집을 만든 소년의 스웨터이므로 준입니다."])

item(8, 2, '에마', '케이트',
 [("Emma had to give a speech to the whole school, and (a)she practised it in the bedroom every night.", "에마는 전교생 앞에서 연설을 해야 했고, (a)그녀는 밤마다 침실에서 그것을 연습했다."),
  ("Her older sister Kate shared the room and heard every word.", "언니 케이트는 같은 방을 써서 한 마디도 빠짐없이 들었다."),
  ("One night Emma stopped in the middle because (b)she could not remember the next line.", "어느 날 밤 에마는 (b)그녀가 다음 줄을 기억하지 못해서 중간에 멈추었다."),
  ("From the other bed Kate said the line aloud, for (c)she knew the speech by heart by then.", "다른 침대에서 케이트가 그 줄을 소리 내어 말해 주었는데, (c)그녀는 그때쯤 연설을 다 외우고 있었기 때문이다."),
  ("On the day Emma looked for one face in the crowd, and Kate nodded at (d)her.", "그날 에마는 사람들 속에서 한 얼굴을 찾았고, 케이트가 (d)그녀에게 고개를 끄덕여 주었다."),
  ("Emma did not forget a single line, and afterwards (e)she bought her sister an ice cream.", "에마는 한 줄도 잊지 않았고, 끝난 뒤 (e)그녀는 언니에게 아이스크림을 사 주었다.")],
 ["밤마다 연설을 연습한 사람은 에마입니다.", "다음 줄이 기억나지 않아 멈춘 사람은 에마입니다.", "밤마다 듣다 보니 연설을 다 외워서 그 줄을 말해 준 사람은 케이트입니다.", "케이트가 고개를 끄덕여 준 상대는 에마입니다.", "'her sister(언니)'에게 아이스크림을 사 준 사람은 에마입니다."])

item(9, 2, '대호', '할아버지',
 [("Daeho thought that writing with a brush was boring until (a)he spent a month at his grandfather's house.", "대호는 (a)그가 할아버지 댁에서 한 달을 보내기 전까지는 붓글씨가 지루하다고 생각했다."),
  ("The old man wrote one large character every morning.", "할아버지는 아침마다 큰 글자 하나를 썼다."),
  ("The boy copied it, but (b)his lines were thick in the wrong places.", "소년은 그것을 따라 썼지만, (b)그의 획은 엉뚱한 곳이 굵었다."),
  ("His grandfather never corrected the paper; (c)he simply wrote the same character again, more slowly.", "할아버지는 그 종이를 고쳐 준 적이 없었다. (c)그는 같은 글자를 더 천천히 다시 썼을 뿐이다."),
  ("Daeho began to watch the old man's wrist instead of the brush, and soon (d)he understood.", "대호는 붓 대신 할아버지의 손목을 보기 시작했고, 곧 (d)그는 깨달았다."),
  ("At the end of the month the old man hung on the wall a sheet which the boy had signed with (e)his red stamp.", "그달 말에 할아버지는 소년이 (e)그의 빨간 도장을 찍은 종이 한 장을 벽에 걸었다.")],
 ["할아버지 댁에서 한 달을 보낸 사람은 대호입니다.", "따라 쓴 소년의 획이므로 대호입니다.", "종이를 고쳐 주는 대신 같은 글자를 다시 써 보인 사람은 할아버지입니다.", "할아버지의 손목을 보다가 깨달은 사람은 대호입니다.", "그 종이에 도장을 찍은 사람은 소년, 곧 대호입니다."])

item(10, 2, '나리', '임 선생님',
 [("Nari was chosen to paint a mural on the library wall, and Ms. Lim, the art teacher, was asked to help (a)her.", "나리는 도서관 벽에 벽화를 그릴 사람으로 뽑혔고, 미술 교사인 임 선생님이 (a)그녀를 돕게 되었다."),
  ("The girl drew a huge whale, but (b)she was too short to reach the top.", "소녀는 커다란 고래를 그렸지만, (b)그녀는 키가 작아 맨 위까지 손이 닿지 않았다."),
  ("The teacher did not paint that part for the girl.", "선생님은 그 부분을 소녀 대신 칠해 주지 않았다."),
  ("Instead (c)she borrowed a tall stool and held it steady for two afternoons.", "대신 (c)그녀는 높은 의자를 빌려 와 이틀 오후 동안 흔들리지 않게 잡아 주었다."),
  ("Nari painted the whale's eye last, with (d)her arm stretched as far as it would go.", "나리는 (d)그녀의 팔을 한껏 뻗어 마지막으로 고래의 눈을 그렸다."),
  ("At the opening the girl stood proudly in front of (e)her whale and pulled the teacher forward too.", "공개하는 날 소녀는 (e)그녀의 고래 앞에 자랑스럽게 서서 선생님도 앞으로 끌어당겼다.")],
 ["임 선생님이 돕게 된 사람은 벽화를 맡은 나리입니다.", "키가 작아 손이 닿지 않은 소녀, 곧 나리입니다.", "바로 앞 문장의 주어가 선생님입니다. 대신 칠해 주지 않고 의자를 빌려 와 잡아 준 사람은 임 선생님입니다.", "팔을 뻗어 고래의 눈을 그린 사람은 나리입니다.", "고래를 그린 소녀, 곧 나리의 고래입니다."])

item(11, 2, '피터', '그랜트 씨',
 [("After a heavy snowfall Peter went out with a shovel, for (a)he hoped to earn some money.", "눈이 많이 내린 뒤 피터는 삽을 들고 나갔는데, (a)그는 돈을 좀 벌고 싶었기 때문이다."),
  ("His first customer was Mr. Grant, an old neighbour who walked with a stick.", "첫 손님은 지팡이를 짚고 다니는 이웃 노인 그랜트 씨였다."),
  ("Peter cleared the long path while the old man watched (b)him from the window.", "피터가 긴 길의 눈을 치우는 동안 노인은 창문으로 (b)그를 지켜보았다."),
  ("When the boy knocked, Mr. Grant held out some coins, and then (c)his stick pointed at the path next door.", "소년이 문을 두드리자 그랜트 씨는 동전 몇 개를 내밀었고, 이어서 (c)그의 지팡이가 옆집 길을 가리켰다."),
  ("A young mother lived there with a new baby.", "거기에는 젊은 엄마가 갓난아기와 함께 살고 있었다."),
  ("Peter understood and cleared it for nothing before (d)he went home.", "피터는 뜻을 알아듣고, (d)그가 집에 가기 전에 그 길을 돈을 받지 않고 치웠다."),
  ("That evening the young mother brought the boy a warm cake and thanked (e)him.", "그날 저녁 젊은 엄마는 소년에게 따뜻한 케이크를 가져와 (e)그에게 고맙다고 했다.")],
 ["삽을 들고 돈을 벌러 나간 사람은 피터입니다.", "노인이 창문으로 지켜본 사람은 눈을 치우는 피터입니다.", "지팡이를 짚고 다니는 사람은 그랜트 씨입니다. 동전을 내민 그랜트 씨가 자기 지팡이로 옆집을 가리킨 것입니다.", "옆집 길까지 치우고 집에 간 사람은 피터입니다.", "젊은 엄마가 고맙다고 한 소년, 곧 피터입니다."])

item(12, 4, '소희', '어머니',
 [("Sohee's mother worked late at a hospital, so the girl decided that (a)she would cook dinner for the first time.", "소희의 어머니는 병원에서 늦게까지 일했기 때문에, 소녀는 (a)그녀가 처음으로 저녁을 짓겠다고 마음먹었다."),
  ("The recipe said that the soup needed twenty minutes, but (b)she boiled it for an hour.", "조리법에는 국을 20분 끓이라고 되어 있었지만, (b)그녀는 한 시간이나 끓였다."),
  ("The potatoes disappeared, and the pot turned black.", "감자는 흔적도 없이 풀어졌고 냄비는 까맣게 탔다."),
  ("When the door opened at ten, Sohee wanted to hide (c)her face.", "열 시에 문이 열리자 소희는 (c)그녀의 얼굴을 숨기고 싶었다."),
  ("Her mother sat down at the table, and the girl served the soup with (d)her eyes on the floor.", "어머니가 식탁에 앉았고, 소녀는 (d)그녀의 눈을 바닥에 떨군 채 국을 내놓았다."),
  ("The tired woman ate every spoonful, and a second bowl was soon in front of (e)her.", "지친 어머니는 한 숟가락도 남기지 않고 먹었고, 곧 두 번째 그릇이 (e)그녀 앞에 놓였다.")],
 ["처음으로 저녁을 짓겠다고 마음먹은 소녀, 곧 소희입니다.", "국을 끓인 사람은 저녁을 지은 소희입니다.", "얼굴을 숨기고 싶었던 사람은 국을 태운 소희입니다.", "눈을 바닥에 떨군 채 국을 내놓은 소녀, 곧 소희입니다.", "국을 다 먹고 두 번째 그릇을 받은 사람은 지친 어머니입니다."])

item(13, 4, '케빈', '알렉스',
 [("Kevin shared a room with his older brother Alex, who was studying for an important exam.", "케빈은 형 알렉스와 방을 같이 썼는데, 형은 중요한 시험공부를 하고 있었다."),
  ("On his birthday Kevin received a model plane kit, and (a)he opened the box before breakfast.", "생일에 케빈은 모형 비행기 조립 세트를 받았고, (a)그는 아침을 먹기도 전에 상자를 열었다."),
  ("There were two hundred tiny parts, and by noon the boy was close to tears because (b)he could not find the first piece.", "작은 부품이 이백 개나 있었고, 정오 무렵 소년은 (b)그가 첫 조각조차 찾지 못해 울음이 터질 지경이었다."),
  ("Kevin did not want to disturb the older boy, so (c)he tried again alone.", "케빈은 형을 방해하고 싶지 않아서, (c)그는 혼자 다시 해 보았다."),
  ("In the end Kevin stood beside the desk with (d)his head down.", "결국 케빈은 (d)그의 고개를 숙인 채 책상 옆에 섰다."),
  ("Alex closed the book at once and said that (e)he loved model planes.", "알렉스는 곧바로 책을 덮고 (e)그가 모형 비행기를 아주 좋아한다고 말했다.")],
 ["생일 선물 상자를 연 사람은 케빈입니다.", "첫 조각을 찾지 못해 울 뻔한 소년, 곧 케빈입니다.", "형을 방해하지 않으려고 혼자 다시 해 본 사람은 케빈입니다.", "고개를 숙인 채 책상 옆에 선 사람은 케빈입니다.", "책을 덮고 자신이 모형 비행기를 좋아한다고 말한 사람은 알렉스입니다."])

item(14, 4, '유리', '소민',
 [("Yuri had the main part in the class play, and (a)she feared one long speech in the last scene.", "유리는 학급 연극의 주인공을 맡았는데, (a)그녀는 마지막 장면의 긴 대사 하나가 걱정이었다."),
  ("Her friend Somin had no part and sat behind the curtain with the script.", "친구 소민은 맡은 역이 없어서 대본을 들고 막 뒤에 앉아 있었다."),
  ("On the night Yuri reached that speech, and suddenly (b)she could not remember a word.", "공연 날 밤 유리는 그 대사에 이르렀고, 갑자기 (b)그녀는 한 마디도 기억나지 않았다."),
  ("Then a whisper came from behind the curtain, and Yuri went on.", "그때 막 뒤에서 속삭이는 소리가 들려왔고, 유리는 대사를 이어 갔다."),
  ("The audience clapped loudly for (c)her at the end.", "끝나자 관객들은 (c)그녀에게 큰 박수를 보냈다."),
  ("Afterwards Yuri ran behind the curtain, where (d)she found Somin with the script.", "공연이 끝난 뒤 유리는 막 뒤로 달려갔고, 거기서 (d)그녀는 대본을 든 소민을 찾았다."),
  ("Yuri called her the real star, but Somin said that (e)she preferred the dark.", "유리는 소민이 진짜 주인공이라고 했지만, 소민은 (e)그녀는 어두운 곳이 더 좋다고 말했다.")],
 ["긴 대사를 걱정한 사람은 주인공을 맡은 유리입니다.", "무대에서 대사가 기억나지 않은 사람은 유리입니다.", "관객이 박수를 보낸 사람은 무대에 선 유리입니다.", "막 뒤로 달려가 소민을 찾은 사람은 유리입니다.", "어두운 곳이 더 좋다고 자기 이야기를 한 사람은 소민입니다."])

item(15, 4, '태준', '신 기사님',
 [("Taejun fell asleep on the last bus home, which Mr. Shin was driving, and (a)he did not wake up until the engine stopped.", "태준은 신 기사님이 모는 막차에서 잠이 들었고, (a)그는 시동이 꺼질 때까지 깨지 못했다."),
  ("The bus was standing in a dark garage far from the city.", "버스는 시내에서 멀리 떨어진 어두운 차고에 서 있었다."),
  ("The driver was checking the seats when the boy sat up and rubbed (b)his eyes.", "기사가 좌석을 살피고 있을 때 소년이 일어나 앉아 (b)그의 눈을 비볐다."),
  ("The boy explained that (c)he had a bus card but no phone.", "소년은 (c)그가 버스 카드는 있지만 전화기는 없다고 설명했다."),
  ("Mr. Shin took (d)him to the office so that the boy could call home.", "신 기사님은 소년이 집에 전화할 수 있도록 (d)그를 사무실로 데려갔다."),
  ("Then the driver drove the boy to his door in a small car, although (e)his own home was in the opposite direction.", "그러고 나서 기사는 작은 차로 소년을 집 앞까지 태워다 주었는데, (e)그 자신의 집은 반대 방향이었다.")],
 ["버스에서 잠들어 깨지 못한 사람은 태준입니다.", "일어나 앉아 눈을 비빈 소년, 곧 태준입니다.", "자기 사정을 설명한 소년, 곧 태준입니다.", "신 기사님이 사무실로 데려간 사람은 태준입니다.", "'his own home'은 소년을 태워다 준 기사 자신의 집입니다. 소년의 집과 반대 방향인데도 데려다주었다는 뜻입니다."])

item(16, 4, '그레이스', '오언 씨',
 [("Grace found under her bed a book from the library where Mrs. Owen worked, and (a)she saw that it was two years late.", "그레이스는 침대 밑에서 오언 씨가 일하는 도서관의 책 한 권을 발견했고, (a)그녀는 그것이 2년이나 연체된 것을 알았다."),
  ("The fine would be more than the price of the book.", "연체료는 책값보다 많을 터였다."),
  ("The girl passed the door three times before (b)she had the courage to go in.", "소녀는 (b)그녀가 들어갈 용기를 내기까지 문 앞을 세 번이나 지나쳤다."),
  ("Mrs. Owen turned the book over while the girl counted the coins in (c)her pocket.", "오언 씨가 책을 이리저리 살펴보는 동안 소녀는 (c)그녀의 주머니 속 동전을 세었다."),
  ("The old woman asked whether the girl liked the story.", "나이 지긋한 사서는 소녀에게 그 이야기가 마음에 들었느냐고 물었다."),
  ("Grace said that it was (d)her favourite.", "그레이스는 그것이 (d)그녀가 가장 좋아하는 책이라고 말했다."),
  ("Mrs. Owen smiled, and (e)she tore up the card with the fine on it.", "오언 씨는 미소를 짓더니, (e)그녀는 연체료가 적힌 카드를 찢어 버렸다.")],
 ["침대 밑에서 책을 발견하고 연체된 것을 안 사람은 그레이스입니다.", "용기를 내어 들어간 소녀, 곧 그레이스입니다.", "주머니 속 동전을 센 소녀, 곧 그레이스입니다.", "그 책이 가장 좋아하는 책이라고 말한 사람은 그레이스입니다.", "미소를 짓고 연체료 카드를 찢은 사람은 사서인 오언 씨입니다."])

item(17, 4, '인호', '세호',
 [("Inho visited his cousin Seho every summer, and this year (a)he wanted to learn to walk on stilts.", "인호는 여름마다 사촌 형 세호네 집에 갔는데, 올해 (a)그는 죽마 타는 법을 배우고 싶었다."),
  ("Seho, who was two years older, could cross the whole yard on them without a wobble.", "두 살 위인 세호는 흔들림 없이 죽마로 마당 전체를 건널 수 있었다."),
  ("On the first day Inho fell so often that (b)his knees were covered in bruises.", "첫날 인호는 너무 자주 넘어져서 (b)그의 무릎은 멍투성이가 되었다."),
  ("His cousin did not tease the younger boy; he only let (c)him hold the fence for the first few steps.", "사촌 형은 동생을 놀리지 않았다. 다만 처음 몇 걸음은 (c)그가 울타리를 잡게 해 주었을 뿐이다."),
  ("For a week Inho practised until (d)he could take ten steps alone.", "일주일 동안 인호는 (d)그가 혼자 열 걸음을 뗄 수 있을 때까지 연습했다."),
  ("On the last day the younger boy crossed the yard, and Seho shouted with joy and gave (e)him the stilts as a present.", "마지막 날 동생이 마당을 건너자, 세호는 기뻐서 소리를 지르고 (e)그에게 그 죽마를 선물로 주었다.")],
 ["죽마 타는 법을 배우고 싶어 한 사람은 인호입니다.", "자주 넘어진 인호의 무릎입니다.", "사촌 형이 울타리를 잡게 해 준 상대는 동생, 곧 인호입니다.", "혼자 열 걸음을 뗄 때까지 연습한 사람은 인호입니다.", "세호가 죽마를 선물로 준 상대는 마당을 건넌 동생, 곧 인호입니다."])

item(18, 0, '도준', '양 씨 아저씨',
 [("Mr. Yang sold fruit at the same corner for thirty years, and (a)he always worked alone.", "양 씨 아저씨는 30년 동안 같은 길모퉁이에서 과일을 팔았고, (a)그는 늘 혼자 일했다."),
  ("One summer his back began to hurt, so a boy named Dojun came to carry boxes.", "어느 여름 허리가 아프기 시작해서, 도준이라는 소년이 상자를 나르러 왔다."),
  ("The boy was strong, but (b)he piled the pears too high and bruised them.", "소년은 힘이 셌지만, (b)그는 배를 너무 높이 쌓아 멍들게 했다."),
  ("The old man said nothing and simply moved the top ones down.", "노인은 아무 말 없이 위에 있는 것들을 아래로 옮겨 놓았다."),
  ("The next day Dojun arranged the fruit in single rows before anyone told (c)him.", "다음 날 도준은 누가 (c)그에게 시키기도 전에 과일을 한 줄씩 늘어놓았다."),
  ("Customers began to ask the boy for (d)his advice on melons.", "손님들은 멜론을 고를 때 소년에게 (d)그의 의견을 묻기 시작했다."),
  ("By autumn Mr. Yang gave (e)him the key to the shop.", "가을 무렵 양 씨 아저씨는 (e)그에게 가게 열쇠를 맡겼다.")],
 ["30년 동안 과일을 팔며 혼자 일한 사람은 양 씨 아저씨입니다.", "배를 너무 높이 쌓은 소년, 곧 도준입니다.", "시키기도 전에 스스로 과일을 늘어놓은 도준입니다.", "손님들이 의견을 물은 소년, 곧 도준입니다.", "양 씨 아저씨가 열쇠를 맡긴 상대는 도준입니다."])

item(19, 0, '보미', '할머니',
 [("Bomi's grandmother pushed a cart of vegetables to the market every dawn, and the hill on the way was hard on (a)her old knees.", "보미의 할머니는 새벽마다 채소 수레를 밀고 시장에 갔는데, 가는 길의 언덕은 (a)그녀의 늙은 무릎에 힘겨웠다."),
  ("One morning Bomi woke early and followed the cart because (b)she wanted to see where it went.", "어느 날 아침 보미는 일찍 일어나 수레를 따라갔는데, (b)그녀는 수레가 어디로 가는지 보고 싶었기 때문이다."),
  ("Halfway up, the girl ran forward and began to push from behind.", "언덕 중간쯤에서 소녀는 앞으로 달려가 뒤에서 밀기 시작했다."),
  ("The old woman turned round in surprise, but she did not send (c)her back to bed.", "할머니는 깜짝 놀라 돌아보았지만, (c)그녀를 다시 자라고 돌려보내지는 않았다."),
  ("At the market Bomi counted the change for customers, and (d)she never made a mistake.", "시장에서 보미는 손님들의 거스름돈을 셌고, (d)그녀는 한 번도 틀리지 않았다."),
  ("Before school the old woman bought the girl a hot bun, which (e)she ate on the way.", "학교 가기 전에 할머니는 소녀에게 따끈한 찐빵을 사 주었고, (e)그녀는 가는 길에 그것을 먹었다.")],
 ["수레를 밀고 언덕을 오르는 사람은 할머니이므로, 늙은 무릎은 할머니의 무릎입니다.", "수레가 어디로 가는지 보고 싶어 따라간 사람은 보미입니다.", "할머니가 돌려보내지 않은 사람은 수레를 민 소녀, 곧 보미입니다.", "거스름돈을 센 사람은 보미입니다.", "할머니가 사 준 찐빵을 학교 가는 길에 먹은 소녀, 곧 보미입니다."])

item(20, 0, '예지', '박 선생님',
 [("Ms. Park, the swimming teacher, saw at once that Yeji was afraid of deep water, and (a)she did not say so to the class.", "수영 교사인 박 선생님은 예지가 깊은 물을 무서워한다는 것을 한눈에 알아보았지만, (a)그녀는 반 아이들에게 그 말을 하지 않았다."),
  ("On the first day the girl held the edge of the pool and would not let go.", "첫날 소녀는 수영장 가장자리를 붙잡고 놓지 않으려 했다."),
  ("The teacher did not pull the girl away; she stood in the water below and asked (b)her to count to ten.", "선생님은 소녀를 억지로 떼어 내지 않았다. 대신 아래쪽 물속에 서서 (b)그녀에게 열까지 세어 보라고 했다."),
  ("Yeji let go for ten seconds, and then (c)she grabbed the edge again.", "예지는 10초 동안 손을 놓았다가 (c)그녀는 다시 가장자리를 붙잡았다."),
  ("Each day the count grew longer, until one morning (d)her hands forgot the edge completely.", "날마다 세는 숫자가 길어졌고, 마침내 어느 날 아침 (d)그녀의 손은 가장자리를 완전히 잊었다."),
  ("In July the girl swam the whole length, and Ms. Park clapped for (e)her from the far end.", "7월에 소녀는 수영장 끝까지 헤엄쳤고, 박 선생님은 반대편 끝에서 (e)그녀에게 박수를 보냈다.")],
 ["아이의 두려움을 알아보고도 반 아이들에게 말하지 않은 사람은 박 선생님입니다.", "선생님이 열까지 세어 보라고 한 상대는 가장자리를 붙잡은 소녀, 곧 예지입니다.", "손을 놓았다가 다시 붙잡은 사람은 예지입니다.", "가장자리를 잊은 손은 날마다 연습한 예지의 손입니다.", "박 선생님이 박수를 보낸 상대는 끝까지 헤엄친 예지입니다."])

item(21, 0, '준서', '강 씨 할아버지',
 [("Mr. Kang fed the stray cats behind the apartment building every evening, and (a)his bag of food was always empty by seven.", "강 씨 할아버지는 저녁마다 아파트 뒤의 길고양이들에게 먹이를 주었고, (a)그의 먹이 봉지는 일곱 시면 늘 비어 있었다."),
  ("Junseo watched from the balcony for weeks before (b)he dared to go down.", "준서는 몇 주 동안 발코니에서 지켜보다가 (b)그는 용기를 내어 내려갔다."),
  ("The old man put a few pieces in the boy's palm, and a thin grey cat ate from (c)his hand without fear.", "할아버지가 소년의 손바닥에 먹이 몇 알을 놓아 주자, 마른 회색 고양이 한 마리가 겁 없이 (c)그의 손에서 먹이를 먹었다."),
  ("When Mr. Kang went into hospital in March, Junseo carried the bag himself, although (d)he was late for school all that week.", "3월에 강 씨 할아버지가 병원에 입원하자 준서가 직접 먹이 봉지를 들었는데, 그 주 내내 (d)그는 학교에 지각했다."),
  ("The grey cat now follows the boy to the gate, and (e)he always feeds it first.", "이제 그 회색 고양이는 소년을 따라 정문까지 오고, (e)그는 언제나 그 고양이에게 먹이를 먼저 준다.")],
 ["저녁마다 고양이에게 먹이를 주는 사람의 봉지이므로 강 씨 할아버지의 봉지입니다.", "발코니에서 지켜보다 내려간 사람은 준서입니다.", "할아버지가 먹이를 놓아 준 손바닥은 소년의 것이므로, 고양이가 먹이를 먹은 손은 준서의 손입니다.", "할아버지 대신 봉지를 들고 지각한 사람은 준서입니다.", "고양이가 정문까지 따라가는 소년, 곧 준서입니다."])

item(22, 0, '지원', '조 씨 아주머니',
 [("Mrs. Jo delivered the post in Jiwon's village, and (a)her red bicycle was known to every dog on the road.", "조 씨 아주머니는 지원이네 마을에 우편물을 배달했고, (a)그녀의 빨간 자전거는 길가의 개들이 모두 알아볼 정도였다."),
  ("Jiwon waited at the gate every afternoon because (b)she was hoping for a letter from her father, who worked abroad.", "지원은 오후마다 대문 앞에서 기다렸는데, (b)그녀는 외국에서 일하는 아버지의 편지를 기다리고 있었기 때문이다."),
  ("For three weeks nothing came, and the girl stopped coming out.", "3주 동안 아무것도 오지 않자 소녀는 더 이상 나오지 않았다."),
  ("One day the postwoman knocked on the door and gave (c)her a thick envelope with foreign stamps.", "어느 날 집배원 아주머니가 문을 두드리고 (c)그녀에게 외국 우표가 붙은 두툼한 봉투를 건넸다."),
  ("Jiwon read the letter twice and then ran after the bicycle, for (d)she wanted to say thank you.", "지원은 편지를 두 번 읽고 나서 자전거를 뒤쫓아 달렸는데, (d)그녀는 고맙다고 말하고 싶었기 때문이다."),
  ("Mrs. Jo now rings her bell twice at the gate whenever a letter for (e)her is in the bag.", "조 씨 아주머니는 이제 가방에 (e)그녀에게 온 편지가 있을 때마다 대문 앞에서 종을 두 번 울린다.")],
 ["우편물을 배달하는 사람의 자전거이므로 조 씨 아주머니의 자전거입니다.", "아버지의 편지를 기다리며 대문 앞에 서 있던 사람은 지원입니다.", "집배원이 봉투를 건넨 상대는 지원입니다.", "편지를 읽고 자전거를 뒤쫓은 사람은 지원입니다.", "편지를 받는 사람이므로 지원입니다. 조 씨 아주머니가 종을 울려 알려 주는 것입니다."])

item(23, 0, '승민', '도현',
 [("Dohyun broke his leg in April, and (a)he had to stay at home for six weeks in the middle of the school year.", "도현은 4월에 다리가 부러져서, 학년 한가운데에 (a)그는 6주 동안 집에 있어야 했다."),
  ("His friend Seungmin lived on the same floor, and every evening (b)he brought the day's notes across the hall.", "그의 친구 승민은 같은 층에 살았고, 저녁마다 (b)그는 그날의 필기를 들고 복도를 건너왔다."),
  ("Copying the notes took Seungmin an hour each night, so (c)he started to record the lessons on his phone instead.", "필기를 옮겨 적는 데 밤마다 한 시간이 걸려서, (c)그는 대신 수업을 휴대전화로 녹음하기 시작했다."),
  ("Dohyun passed the exam, and then he told the teacher who had really done the work.", "도현은 시험에 통과했고, 그러고 나서 선생님께 진짜로 애쓴 사람이 누구인지 말씀드렸다."),
  ("The teacher gave Seungmin a prize for (d)his kindness, and the whole class clapped.", "선생님은 승민에게 (d)그의 친절에 대한 상을 주었고, 반 전체가 박수를 쳤다."),
  ("When Seungmin broke his arm the next winter, Dohyun recorded every lesson for (e)him.", "다음 겨울에 승민이 팔이 부러지자, 도현은 (e)그를 위해 모든 수업을 녹음해 주었다.")],
 ["다리가 부러져 집에 있어야 했던 사람은 도현입니다.", "필기를 들고 복도를 건너온 사람은 승민입니다.", "필기를 옮겨 적는 데 한 시간이 걸리던 사람이 녹음을 시작한 것이므로 승민입니다.", "상을 받은 사람의 친절이므로 승민입니다.", "도현이 녹음해 준 상대는 팔이 부러진 승민입니다."])

item(24, 3, '민서', '오 선생님',
 [("Minseo joined the school band and was given a trumpet that nobody else wanted.", "민서는 학교 밴드에 들어가서 아무도 원하지 않는 트럼펫을 받았다."),
  ("Ms. Oh, the music teacher, told the girl that (a)she would sound terrible for a month and that this was normal.", "음악 교사인 오 선생님은 소녀에게 (a)그녀가 한 달 동안은 형편없는 소리를 낼 것이고, 그것이 정상이라고 말했다."),
  ("Minseo practised in the garage so that (b)her family would not hear the noise.", "민서는 (b)그녀의 가족이 그 소리를 듣지 못하도록 차고에서 연습했다."),
  ("After two weeks the girl could play five clean notes, and (c)she showed them to the teacher.", "2주 뒤 소녀는 깨끗한 음 다섯 개를 낼 수 있게 되었고, (c)그녀는 그것을 선생님에게 들려주었다."),
  ("Ms. Oh listened and then took out (d)her own trumpet from a dusty case under the desk.", "오 선생님은 듣고 나서 책상 밑의 먼지 쌓인 케이스에서 (d)그녀 자신의 트럼펫을 꺼냈다."),
  ("The two played together at the spring concert, and Minseo kept the old trumpet even after (e)she left school.", "두 사람은 봄 연주회에서 함께 연주했고, 민서는 (e)그녀가 학교를 졸업한 뒤에도 그 낡은 트럼펫을 간직했다.")],
 ["선생님이 소녀에게 '형편없는 소리를 낼 것'이라고 한 것이므로 민서입니다.", "차고에서 연습한 소녀의 가족이므로 민서의 가족입니다.", "다섯 음을 낼 수 있게 되어 선생님에게 들려준 사람은 민서입니다.", "'her own trumpet'은 이 문장의 주어인 오 선생님 자신의 트럼펫입니다. 선생님도 트럼펫을 불 줄 알았다는 뜻입니다.", "낡은 트럼펫을 간직한 채 학교를 졸업한 사람은 민서입니다."])

item(25, 3, '하준', '진 씨 아저씨',
 [("Hajun spent August in the hills with Mr. Jin, who kept sheep and a small weather station.", "하준은 양을 치면서 작은 기상 관측소도 맡고 있는 진 씨 아저씨와 함께 산에서 8월을 보냈다."),
  ("The boy climbed to the station every evening, and (a)he wrote the numbers in a notebook.", "소년은 저녁마다 관측소에 올라갔고, (a)그는 숫자를 공책에 적었다."),
  ("One night a storm broke, and (b)he ran up the hill in the rain to tie down the roof.", "어느 날 밤 폭풍이 몰아쳤고, (b)그는 지붕을 묶어 두려고 빗속에서 언덕을 뛰어 올라갔다."),
  ("The old man was already there, and the boy held the rope until (c)his arms ached.", "노인은 벌써 거기에 있었고, 소년은 (c)그의 팔이 아플 때까지 밧줄을 잡고 있었다."),
  ("At dawn the old man patted the boy's shoulder, although (d)his own eyes were red from the long night.", "새벽에 노인은 긴 밤 때문에 (d)그 자신의 눈이 빨갛게 되었는데도 소년의 어깨를 두드려 주었다."),
  ("Hajun went home with a sheep bell, and (e)he rings it every time a storm comes.", "하준은 양 방울 하나를 가지고 집에 돌아왔고, (e)그는 폭풍이 올 때마다 그 종을 울린다.")],
 ["저녁마다 관측소에 올라가 숫자를 적은 사람은 하준입니다.", "폭풍이 몰아치자 언덕을 뛰어 올라간 사람은 하준입니다.", "밧줄을 잡고 버틴 소년의 팔이므로 하준의 팔입니다.", "'his own eyes'는 이 문장의 주어인 노인 자신의 눈입니다. 밤새 지붕을 지킨 사람은 진 씨 아저씨입니다.", "양 방울을 가지고 집에 돌아온 사람은 하준입니다."])

item(26, 3, '서연', '나영',
 [("Seoyeon and Nayoung both wanted to be the class president, and only one of them could win.", "서연과 나영은 둘 다 반장이 되고 싶었지만, 둘 중 한 사람만 될 수 있었다."),
  ("Seoyeon made a hundred posters, and (a)she gave a speech about a new bookcase for the classroom.", "서연은 포스터 백 장을 만들었고, (a)그녀는 교실에 새 책장을 두겠다는 연설을 했다."),
  ("On the day of the vote (b)she lost by three votes.", "투표 날 (b)그녀는 세 표 차이로 졌다."),
  ("The girl went home and cried, for (c)she had worked on the plan for weeks.", "소녀는 집에 가서 울었는데, (c)그녀는 몇 주 동안 그 계획에 매달렸기 때문이다."),
  ("The next morning Nayoung came to Seoyeon's desk with a sheet of paper in (d)her hand: the plan for the bookcase.", "다음 날 아침 나영은 (d)그녀의 손에 종이 한 장을 들고 서연의 책상으로 왔다. 책장 계획이었다."),
  ("By June the bookcase stood in the corner, and Seoyeon found (e)her own name beside Nayoung's on the sign above it.", "6월이 되자 책장은 교실 구석에 놓였고, 서연은 그 위의 팻말에서 나영의 이름 옆에 (e)그녀 자신의 이름을 발견했다.")],
 ["포스터를 만들고 책장 연설을 한 사람은 서연입니다.", "세 표 차이로 진 사람은 서연입니다. 바로 앞에서 서연이 연설을 했고, 다음 문장에서 울었다고 했습니다.", "몇 주 동안 계획에 매달려서 운 사람은 서연입니다.", "서연의 책상으로 종이를 들고 온 사람은 나영이므로, 손에 든 사람도 나영입니다.", "팻말에서 자기 이름을 발견한 사람은 서연입니다. 'her own name'은 이 문장의 주어인 서연 자신의 이름입니다."])

item(27, 3, '루카스', '유 씨 아저씨',
 [("Lucas lost his school bag on the way home, and Mr. Yoo, the school guard, saw him searching the road.", "루카스는 집에 가는 길에 책가방을 잃어버렸고, 학교 정문 경비원인 유 씨 아저씨는 그가 길을 뒤지는 것을 보았다."),
  ("The boy had put the bag on a bench while (a)he tied his shoe, and then it was gone.", "소년은 (a)그가 신발 끈을 묶는 동안 가방을 벤치에 두었는데, 그러고 나서 가방이 사라져 버렸다."),
  ("Inside were his homework and the money for (b)his school trip.", "안에는 그의 숙제와 (b)그의 수학여행 비용이 들어 있었다."),
  ("Mr. Yoo walked the road with the boy and asked at every shop about (c)his blue bag.", "유 씨 아저씨는 소년과 함께 길을 걸으며 가게마다 (c)그의 파란 가방에 대해 물었다."),
  ("Nobody knew anything, so the two walked back, and the guard opened a box behind (d)his desk.", "아는 사람이 없어서 두 사람은 돌아왔고, 경비원은 (d)그의 책상 뒤에 있는 상자를 열었다."),
  ("The blue bag was inside, handed in by a passer-by, and Lucas promised that (e)he would never leave it on a bench again.", "파란 가방은 지나가던 사람이 맡겨 놓아 그 안에 있었고, 루카스는 (e)그가 다시는 가방을 벤치에 두지 않겠다고 약속했다.")],
 ["벤치에 가방을 두고 신발 끈을 묶은 사람은 루카스입니다.", "수학여행 비용이 든 가방의 주인이므로 루카스입니다.", "잃어버린 파란 가방은 루카스의 것입니다.", "상자를 연 사람이 경비원이므로, 책상은 유 씨 아저씨의 책상입니다.", "다시는 가방을 벤치에 두지 않겠다고 약속한 사람은 루카스입니다."])

item(28, 3, '아린', '하영',
 [("Arin moved from Canada in the spring and could not yet follow the lessons in Korean.", "아린은 봄에 캐나다에서 이사 왔고, 아직 한국어 수업을 따라갈 수 없었다."),
  ("On the first day (a)she sat at the back and wrote nothing.", "첫날 (a)그녀는 뒷자리에 앉아 아무것도 쓰지 않았다."),
  ("Hayoung, who sat beside the new girl, drew a small picture next to each word that (b)she did not understand.", "새로 온 소녀 옆에 앉은 하영은 (b)그녀가 이해하지 못하는 낱말마다 옆에 작은 그림을 그려 주었다."),
  ("By winter Arin could answer in class, and (c)her notebook was full of tiny drawings.", "겨울이 되자 아린은 수업 시간에 대답할 수 있게 되었고, (c)그녀의 공책은 작은 그림으로 가득했다."),
  ("At the school festival Hayoung showed (d)her own comics, and the first page was a girl sitting at the back of a classroom.", "학교 축제에서 하영은 (d)그녀 자신의 만화를 선보였는데, 첫 장은 교실 뒷자리에 앉은 한 소녀였다."),
  ("Arin bought the first copy, and (e)she keeps it on her shelf today.", "아린은 첫 번째 책을 샀고, (e)그녀는 오늘도 그것을 책꽂이에 두고 있다.")],
 ["첫날 뒷자리에 앉아 아무것도 쓰지 못한 사람은 새로 온 아린입니다.", "낱말을 이해하지 못한 사람은 한국어가 서툰 아린입니다. 하영이 그 낱말 옆에 그림을 그려 준 것입니다.", "그림으로 가득한 공책은 그림을 받아 온 아린의 공책입니다.", "'her own comics'는 이 문장의 주어인 하영 자신의 만화입니다. 축제에서 만화를 선보인 사람은 하영입니다.", "첫 번째 책을 사서 간직하는 사람은 아린입니다."])

item(29, 3, '윤호', '이 씨 아저씨',
 [("Yunho left half of his lunch on the tray every day, and Mr. Lee, the school cook, noticed.", "윤호는 날마다 점심을 절반씩 식판에 남겼고, 학교 조리사인 이 씨 아저씨는 그것을 알아챘다."),
  ("One Friday the cook stopped the boy at the counter and asked what (a)he disliked.", "어느 금요일 조리사는 배식대에서 소년을 불러 세우고 (a)그가 무엇을 싫어하는지 물었다."),
  ("The boy said that everything tasted the same, and then (b)he felt rude.", "소년은 모든 음식 맛이 똑같다고 말했고, 그러고 나서 (b)그는 무례했다고 느꼈다."),
  ("On Monday Yunho found a small dish of something new on (c)his tray.", "월요일에 윤호는 (c)그의 식판에서 처음 보는 음식이 담긴 작은 접시를 발견했다."),
  ("The cook stood at the kitchen door with a towel in (d)his hands and watched the boy's face.", "조리사는 (d)그의 손에 행주를 든 채 주방 문 앞에 서서 소년의 얼굴을 지켜보았다."),
  ("Yunho ate every bit, and since then (e)he has tried one new dish a week.", "윤호는 남김없이 먹었고, 그때부터 (e)그는 일주일에 한 가지씩 새 음식을 먹어 보고 있다.")],
 ["조리사가 무엇을 싫어하는지 물은 상대는 소년, 곧 윤호입니다.", "음식 맛이 다 똑같다고 말하고 나서 무례했다고 느낀 사람은 윤호입니다.", "새 음식이 담긴 식판은 점심을 먹는 윤호의 식판입니다.", "주방 문 앞에 서서 행주를 든 사람은 조리사이므로 이 씨 아저씨의 손입니다.", "그때부터 새 음식을 먹어 보는 사람은 윤호입니다."])

assert len(E) == 30
