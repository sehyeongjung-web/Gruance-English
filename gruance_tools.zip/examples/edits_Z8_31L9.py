# -*- coding: utf-8 -*-
# 183~185번: 31번(빈칸 추론) 레벨9 해설 두텁게 — 30문항 (edits_Z8a·b·c를 하나로 합친 것)
# 풀이(walk)·선택지별 해설(cn)만 바꿈. 지문·선택지·정답·해석 변동 없음. z8common.py가 같은 폴더에 있어야 함
AUTO_SYNC = False
E = {}
from z8common import maker
mk = maker(E, '31')

# ---------- 1번째: 지휘봉은 서로 보는 시선을 대신한다 ----------
mk(0, 0, [
 "1) 빈칸 문장: 'not A but B'(A가 아니라 B) 틀입니다. A는 'a source of time'(박자가 나오는 곳)이고 빈칸이 B입니다. 지휘봉이 정말로 하는 일이 무엇인지를 묻습니다. 버리는 쪽 A는 첫 문장에 나온 청중의 생각, 곧 «the conductor is what keeps a group together»(지휘자가 연주단을 하나로 묶어 준다)입니다.",
 "2) 편 정하기: 그러면 무엇이 연주를 맞춰 줍니까. 둘째 문장이 답합니다. «each player is watching the others rather than a baton»(연주자마다 지휘봉이 아니라 서로를 보고 있다). 사중주가 잘 맞는 까닭은 「서로 보기」입니다. 빈칸은 이 「보기」 쪽 말이어야 합니다.",
 "3) 짝꿍 문장: 빈칸 바로 앞 문장입니다. «most players cannot see most others, and the conductor exists to be the one thing everyone can see»(연주자 대부분이 다른 연주자 대부분을 볼 수 없고, 지휘자는 모두가 볼 수 있는 단 하나가 되려고 있다). 아흔 명은 서로 볼 수 없으니, 서로 보는 대신 다 같이 한곳을 보게 한 것입니다.",
 "4) 묶기: 'cannot see most others'(서로 볼 수 없음) + 'the one thing everyone can see'(모두가 보는 하나) = 'a substitute for sightlines'(서로를 보는 시선을 대신하는 것). sightlines는 지문에 없는 낱말입니다. 지문의 watching과 see를 한 낱말로 묶은 것입니다."],
 "빈칸 문장이 버린 박자 쪽을 다시 넣은 선택지(합의된 빠르기의 기록)가 가장 위험합니다. tempo는 time과 같은 편의 낱말이라, 'not A but B'의 A를 말만 바꿔 B 자리에 넣은 셈입니다. 지휘자라고 하면 떠오르는 상식(권위, 힘)으로 고르는 것도 조심합니다. 이 글에서 지휘자가 있는 까닭은 「보이기 위해서」 하나뿐입니다.",
 [("서로를 보는 시선을 대신하는 것", "바로 앞 문장 «the conductor exists to be the one thing everyone can see»가 근거입니다. 사중주는 서로 보면서(watching the others) 맞추는데, 아흔 명은 서로 볼 수 없으므로 모두가 볼 수 있는 지휘봉이 그 시선의 구실을 대신합니다. 지문의 watching, see가 sightlines 한 낱말로 바뀌었습니다."),
  ("지휘자가 가진 힘의 표시", "지휘자는 높은 자리라는 상식으로 고르기 쉬운 선택지입니다. 하지만 글에는 힘이나 권위 이야기가 한 번도 나오지 않습니다. 글이 말한 지휘자의 구실은 모두가 볼 수 있는 단 하나(the one thing everyone can see)가 되는 것뿐입니다. 상식으로는 그럴듯하지만 지문에 근거가 없습니다."),
  ("합의된 빠르기의 기록", "tempo(빠르기)가 time(박자)과 통해서 끌립니다. 그런데 빈칸 문장은 'not a source of time'으로 박자 쪽을 이미 버렸습니다. 버린 쪽을 말만 바꿔 다시 넣은 선택지입니다. 또 기록(record)은 미리 정해 둔 것인데, 글은 연주하는 동안 서로 보며 바로잡는(a slip by one is corrected by three) 이야기입니다."),
  ("연습에 대한 보상", "지문에 없는 이야기입니다. 첫 문장의 precise(정확한)를 보고 「연습을 많이 해서 정확하다」고 넘겨짚으면 고르게 됩니다. 하지만 글은 정확함의 까닭을 연습이 아니라 서로 보는 데서 찾았습니다. 연습도 보상도 지문에 나오지 않습니다."),
  ("사람들이 듣는 별도의 악기", "오케스트라 글이라 악기를 떠올리기 쉽고, 듣는다는 말도 지문('before the audience hears it')에 있습니다. 하지만 글은 처음부터 끝까지 듣기가 아니라 보기(watching, see)를 말합니다. 지휘봉은 소리를 내지 않습니다. 낱말만 빌려 왔고 방향이 다릅니다.")])

# ---------- 2번째: 충실한 번역이란 서로 다른 손실 가운데서 고르는 일 ----------
mk(1, 2, [
 "1) 빈칸 문장: 빈칸은 'which suggests that'(이는 ~을 시사한다) 뒤에 있습니다. which는 바로 앞의 내용 전체를 받으므로, 빈칸은 앞 절을 한 번 더 정리하는 자리입니다. 묻는 것은 「이런 경우 충실성(fidelity)이란 무엇인가」입니다.",
 "2) 짝꿍 문장: 같은 문장 안, which 바로 앞에 있습니다. «not as finding the correct rendering but as deciding which distortion to accept»(올바른 번역을 찾는 일이 아니라, 어떤 왜곡을 받아들일지 정하는 일). 'not A but B' 틀입니다. 버리는 쪽은 「올바른 번역 찾기」, 남는 쪽은 「왜곡 고르기」입니다.",
 "3) 되풀이: 같은 생각이 앞에서 두 번 더 나옵니다. «a choice that has no neutral resolution»(중립적인 해결책이 없는 선택) → «Neither option preserves the relationship the original encoded»(어느 쪽도 원문이 담은 관계를 지키지 못한다). 그대로 옮기면 굽신거리는 말이 되고, 빼면 무뚝뚝한 말이 됩니다. 어느 쪽이든 잃고, 잃는 것이 서로 다릅니다.",
 "4) 묶기: 'deciding which … to accept'(어느 것을 받아들일지 정하기) = 'choosing among'(~ 가운데서 고르기). 'distortion'(왜곡) = 'losses'(잃는 것). 굽신거림과 무뚝뚝함처럼 잃는 것이 서로 다르다 = 'unequal'(같지 않은)."],
 "셋째 문장의 'reads naturally'(자연스럽게 읽힌다)를 보고 「그래도 읽기 쉬운 쪽이 낫다」고 정리한 선택지(충실성은 읽기 쉬움보다 덜 중요하다)가 가장 위험합니다. 글은 자연스럽게 읽히는 문장도 화자를 원문보다 무뚝뚝하게 만든다고 했습니다. 그것도 왜곡입니다. 글은 어느 쪽이 더 중요한지 순위를 매기지 않습니다. 「낱말을 더 잘 고르면 된다」는 선택지는 글이 버린 쪽('finding the correct rendering')입니다.",
 [("낱말을 더 신중하게 고르면 이룰 수 있는 것", "방향이 거꾸로입니다. 번역은 알맞은 낱말을 찾는 일이라는 상식 때문에 끌립니다. 하지만 글은 번역가의 일이 올바른 번역을 찾는 것이 아니라고('not as finding the correct rendering') 했습니다. 그 관계를 나타내는 체계가 도착어에 아예 없으므로('a system the target language does not have'), 낱말을 아무리 잘 골라도 이룰 수 없습니다."),
  ("저자의 도움 없이는 평가할 수 없는 것", "지문에 없는 이야기입니다. 'the original'(원문)이 여러 번 나와 원문을 쓴 사람을 떠올리기 쉽지만, 저자는 한 번도 나오지 않습니다. 글의 문제는 충실한지 아닌지를 「평가할 수 없다」는 것이 아니라, 어느 쪽을 골라도 무엇인가를 잃는다는 것입니다."),
  ("같지 않은 손실들 가운데서 고르는 문제", "바로 앞의 «deciding which distortion to accept»를 바꿔 쓴 것입니다. 'deciding which … to accept'가 'choosing among'으로, 'distortion'이 'losses'로 바뀌었습니다. 굽신거리게 들리는 것과 무뚝뚝하게 들리는 것은 서로 다른 손실이므로 'unequal'입니다. 첫 문장의 «a choice that has no neutral resolution»과도 짝을 이룹니다."),
  ("번역가의 모국어에 따라 정해지는 것", "language라는 낱말만 빌려 온 선택지입니다. 지문에는 출발어('source language')와 도착어('target language')만 나오고, 번역가의 모국어는 나오지 않습니다. 어려움은 번역가가 누구냐에서 오지 않고, 두 언어의 공손함 체계('politeness systems')가 다르다는 데서 옵니다."),
  ("독자를 위한 읽기 쉬움보다 덜 중요한 것", "셋째 문장의 'reads naturally'(자연스럽게 읽힌다)에서 끌립니다. 하지만 글은 자연스럽게 읽히는 문장도 화자를 원문보다 무뚝뚝하게(blunter) 만든다고 했습니다. 읽기 쉬운 쪽도 왜곡의 하나일 뿐입니다. 충실성과 읽기 쉬움 가운데 어느 것이 더 중요한지는 글이 견주지 않았습니다.")])

# ---------- 3번째: 스스로 결과를 만드는 예측은 좋은 모델과 영향력 큰 모델을 가를 수 없다 ----------
mk(2, 4, [
 "1) 빈칸 문장: 'Where …'(~하는 경우에는)로 시작하는 맺음 문장이고, 빈칸은 동사 자리입니다. 「예측 성공을 재는 보통의 척도」가 그런 경우에 어떻게 되는지를 묻습니다. 조건인 «a prediction participates in producing its own outcome»(예측이 자기 결과를 만드는 데 끼어든다)은 첫 문장의 «can alter the behavior they were meant to describe»(그리려던 행동을 바꿔 놓을 수 있다)를 다시 말한 것입니다.",
 "2) 편 정하기: 글은 이 예측을 비 예보와 견줍니다. 맞히면 «the same statistics that would apply to a forecast of rainfall»(비 예보에 쓰는 것과 같은 통계)로 정확하다고 보고합니다. 그런데 «The difference is that rain does not read the forecast.»(차이는 비는 예보를 읽지 않는다는 것이다.) 척도는 같은데 재는 대상이 다릅니다. 그러니 빈칸은 「척도가 제구실을 못 한다」는 쪽입니다.",
 "3) 짝꿍 문장: 빈칸 바로 앞 문장입니다. «this one cannot be wrong at all once it is consulted widely enough»(이 모델은 충분히 널리 참조되고 나면 아예 틀릴 수가 없다). 맞히는 까닭이 모델을 잘 만들어서가 아니라 사람들이 널리 읽어서라는 뜻입니다.",
 "4) 묶기: 'credited with accuracy'(정확하다고 인정받는) 모델 = 'a good model'(좋은 모델). 'consulted widely'(널리 참조되는), 'influences'(영향을 미친다) = 'an influential one'(영향력 있는 모델). 'cannot be wrong at all'(아예 틀릴 수 없다) → 맞혔다는 것만으로는 둘을 가를 수 없다 = 'stop distinguishing'(가려내지 못하게 된다)."],
 "통계 상식에 기대는 두 선택지가 위험합니다. 「표본이 커질수록 더 믿을 만해진다」는 평소에는 맞는 말이지만, 이 글에서는 방향이 거꾸로입니다. 널리 참조될수록 오히려 척도가 쓸모없어집니다. 「상관관계의 세기를 잰다」도 통계 용어라 그럴듯하지만 상관관계라는 말은 지문에 없습니다. 빈칸은 척도가 「무엇을 재는가」가 아니라 「무엇을 못 하게 되는가」를 묻습니다.",
 [("공공 기관이 만든 예보에만 적용된다", "지문에 없는 구분입니다. 비 예보나 보고서(report)에서 공공 기관을 떠올리면 고르게 됩니다. 하지만 글이 예측을 둘로 가르는 기준은 누가 만들었느냐가 아니라, 예측이 결과에 끼어드느냐('participates in producing its own outcome')입니다."),
  ("밑에 깔린 상관관계의 세기를 잰다", "통계 용어라 그럴듯하고, 예측과 결과가 맞는다(matches)는 말에서 상관관계를 떠올리기 쉽습니다. 하지만 상관관계라는 말은 지문에 없습니다. 그리고 빈칸은 척도가 무엇을 재는지가 아니라 이런 경우에 무엇을 못 하게 되는지를 묻습니다. 상식으로 고르면 걸립니다."),
  ("표본 크기가 커질수록 더 믿을 만해진다", "방향이 거꾸로입니다. 표본이 클수록 믿을 만하다는 것은 평소의 통계 상식이지만, 글은 모델이 널리 참조될수록('consulted widely enough') 아예 틀릴 수 없게 된다고 했습니다. 자료가 쌓일수록 척도는 더 쓸모없어집니다. 빈칸에는 척도가 제구실을 못 한다는 말이 와야 합니다."),
  ("발표 뒤 지난 시간에 맞춘 조정이 필요하다", "보고서가 읽힌 뒤에 행동이 바뀐다는 순서에서 시간을 떠올릴 수 있습니다. 하지만 글의 문제는 시간이 아니라 예측이 읽힌다는 사실 자체입니다. 또 글은 문제를 짚을 뿐, 조정하면 된다는 해결책을 내놓지 않습니다. 진단을 해결책으로 바꾼 선택지입니다."),
  ("좋은 모델과 영향력 있는 모델을 가려내지 못하게 된다", "바로 앞 문장 «this one cannot be wrong at all once it is consulted widely enough»가 근거입니다. 널리 읽히기만 하면 맞히게 되므로, 맞혔다는 사실만으로는 모델이 좋아서인지 영향력이 커서인지 알 수 없습니다. 'credited with accuracy'가 'a good model'로, 'consulted widely'가 'influential'로 바뀌었습니다.")])

# ---------- 4번째: 기록의 쓸모는 채집자가 무엇을 적어 두었느냐에 달려 있다 ----------
mk(3, 1, [
 "1) 빈칸 문장: 'less A than B'(A보다는 B) 틀입니다. 기록의 쓸모가 A보다는 B에 달려 있다고 합니다. A는 'what was preserved'(무엇이 보존되었는가)이고 빈칸이 B입니다. 과학 기록의 쓸모를 정말로 정하는 것이 무엇인지를 묻습니다. A는 버리는 쪽입니다.",
 "2) 편 정하기: 글은 정보를 둘로 나눕니다. 첫째는 생물 자체의 정보로, «The first survives indefinitely»(첫째는 끝없이 남는다)라고 했습니다. 이것이 A, 곧 「보존된 것」의 편입니다. 둘째는 채집할 때의 사정(어디서, 언제, 누가)입니다. 빈칸은 이 둘째 편입니다.",
 "3) 짝꿍 문장: «The second exists only in whatever was written on the label»(둘째는 라벨에 적힌 것 안에만 있다). 그리고 빈칸 문장의 앞머리가 까닭을 알려 줍니다. «when the second kind of information seemed unimportant»(둘째 종류의 정보가 중요해 보이지 않던 때). 적느냐 마느냐는 그때 사람이 그것을 중요하게 여겼느냐에 달려 있었습니다.",
 "4) 묶기: 'whatever was written on the label'(라벨에 적힌 것) = 'recording'(적어 두기). 'seemed unimportant'(중요해 보이지 않았다)를 뒤집으면 'thought worth'(~할 만하다고 여겼다). 라벨을 적는 사람 = 'the collector'(채집자)."],
 "instruments(기기)와 collector(채집자)가 지문에 함께 나와서 「그때 쓸 수 있었던 기기」가 끌립니다. 하지만 글은 표본을 나중의 기기로 얼마든지 다시 조사할 수 있다고 했습니다. 방향이 거꾸로입니다. 「얼마나 꼼꼼히 보관했는가」는 preserved와 같은 편의 말입니다. 'less A than B'에서 버린 A를 말만 바꿔 다시 넣은 선택지입니다.",
 [("그 종이 그 뒤로 매우 드물어졌는지", "지문에 없는 이야기입니다. 박물관 표본과 'about change'(변화에 관해)라는 말에서 사라져 가는 생물을 떠올리면 고르게 됩니다. 하지만 글에서 change는 날짜 없는 표본이 답하지 못하는 물음의 예일 뿐입니다. 종이 드물어졌는지가 기록의 쓸모를 정한다는 말은 없습니다."),
  ("채집자가 적어 둘 만하다고 여긴 것", "«The second exists only in whatever was written on the label»이 근거입니다. 채집 사정은 라벨에 적은 만큼만 남고, 무엇을 적을지는 그때 채집자가 무엇을 중요하게 여겼느냐에 달려 있었습니다. 'written on the label'이 'recording'으로, 'seemed unimportant'가 뒤집혀 'thought worth'로 바뀌었습니다."),
  ("소장품이 가진 표본의 수", "빈칸 문장의 'rich in'(~이 풍부한)을 보고 「많을수록 쓸모 있다」고 넘겨짚기 쉽습니다. 하지만 글은 그런 소장품이 나중의 물음이 쓸 수 없는('cannot use') 자료로 풍부하다고 했습니다. 표본이 많아도 라벨에 날짜가 없으면 쓸 수 없습니다. 수는 쓸모를 정하지 못합니다."),
  ("표본을 얼마나 꼼꼼히 보관했는가", "preserved(보존된)와 같은 편의 말이라 끌립니다. 그런데 빈칸 문장은 「무엇이 보존되었는가보다는」이라고 그쪽을 이미 버렸습니다. 버린 쪽을 말만 바꿔 다시 넣은 선택지입니다. 아무리 잘 보관해도 라벨이 짧거나 없으면 채집 사정은 어떤 기술로도 되찾지 못합니다('no technique recovers it')."),
  ("그때 쓸 수 있었던 기기", "instruments가 지문 낱말 그대로라 끌리지만 방향이 거꾸로입니다. 글은 표본을 채집자가 상상도 못 한 기기로 다시 조사할 수 있다('can be re-examined')고 했습니다. 그때 기기가 모자랐던 것은 나중에 메울 수 있습니다. 메울 수 없는 것은 그때 적어 두지 않은 기록입니다.")])

# ---------- 5번째: 같은 사건을 같게 다루라는 요구는 '무엇이 같은가'의 기준을 먼저 깔고 있다 ----------
mk(4, 0, [
 "1) 빈칸 문장: therefore(따라서)로 맺는 결론입니다. 'The demand for like treatment'(같게 다루라는 요구)는 첫 문장의 요구를 다시 말한 것이고, presupposes는 「~을 먼저 깔고 있다」는 뜻입니다. 이 요구가 서려면 그보다 먼저 있어야 하는 것이 무엇인지를 묻습니다.",
 "2) 꺾이는 곳: 둘째 문장의 however입니다. 첫 문장은 이 요구가 «seems to demand nothing more than consistency»(일관성 말고는 아무것도 요구하지 않는 것처럼 보인다)라고 했습니다. seems는 겉보기라는 신호입니다. however 뒤가 글쓴이의 생각입니다. «requires deciding which features of a case make it similar to another»(사건의 어떤 특징이 다른 사건과 비슷하게 만드는지를 정해야 한다).",
 "3) 짝꿍 문장: 빈칸 바로 앞 문장입니다. «it is applying a view about which differences matter, and that view arrived from somewhere outside the rule»(법원은 어떤 차이가 중요한지에 대한 견해를 적용하고 있으며, 그 견해는 규칙 바깥 어딘가에서 왔다). 규칙보다 먼저, 규칙 바깥에 견해가 있어야 한다는 말입니다.",
 "4) 묶기: 'a view'(견해) = 'account'(설명). 'which differences matter'(어떤 차이가 중요한가) = 'relevant similarity'(따져야 할 비슷함). 'from somewhere outside the rule'(규칙 바깥에서)과 presupposes = 'prior'(먼저 있는). relevant는 지문에 없는 낱말로, matter를 바꾼 것입니다."],
 "법 하면 떠오르는 상식, 곧 앞선 판결을 따른다는 생각으로 「끊기지 않고 이어진 앞선 판결들」을 고르기 쉽습니다. 하지만 앞선 판결이 아무리 많아도, 지금 사건이 그 가운데 어느 것과 비슷한지는 따로 정해야 합니다. 글이 말한 순환(circularity)이 바로 이것입니다. consistency에서 「판사들의 합의」를 떠올리는 것도 조심합니다. 글이 말하는 것은 결과가 아니라 결과보다 앞선 판단입니다.",
 [("따져야 할 비슷함이 무엇인지에 대한 앞선 설명", "바로 앞 문장 «that view arrived from somewhere outside the rule»이 근거입니다. 같은 사건을 같게 다루려면 무엇이 「같은」 것인지를 먼저 정해야 하고, 그 기준은 규칙 안에 없습니다. 'a view about which differences matter'가 'account of relevant similarity'로, 'outside the rule'이 'prior'로 바뀌었습니다."),
  ("끊기지 않고 이어진 앞선 판결들", "법은 앞선 판결을 따른다는 상식과 'similar cases'(비슷한 사건)라는 말 때문에 끌립니다. 하지만 앞선 판결이 아무리 쌓여 있어도, 지금 사건이 어느 판결과 비슷한지를 정하는 기준은 따로 있어야 합니다. 글은 그 판단이 일관성에 기대서는 순환에 빠진다('without circularity')고 했습니다."),
  ("앞선 당사자들이 어떻게 대응했는지에 대한 기록", "parties(당사자)라는 낱말만 빌려 온 선택지입니다. 지문에서 당사자는 두 사건이 서로 다를 수 있는 점의 예('the sophistication of the parties')로 한 번 나올 뿐입니다. 당사자가 어떻게 대응했는지, 그 기록이 있는지는 지문에 없는 이야기입니다."),
  ("사건의 갈래마다 뜻을 정해 주는 법률", "'outside the rule'(규칙 바깥)을 보고 다른 법률을 떠올리면 고르게 됩니다. 하지만 글이 규칙 바깥에서 왔다고 한 것은 견해('a view')이지 법률이 아닙니다. 또 계약 분쟁이라는 같은 갈래에 든 두 사건도 서로 다를 수 있다('may differ')고 했으므로, 갈래를 정해 주는 것만으로는 모자랍니다."),
  ("결과에 대한 판사들의 합의", "consistency(일관성)에서 「판사들의 뜻이 같아야 한다」를 떠올리기 쉽습니다. 하지만 글이 말하는 것은 판결의 결과가 아니라, 결과를 내기 전에 어떤 차이를 중요하게 볼지 정하는 판단입니다. 결과에 대한 합의는 판결 뒤의 일이라 presupposes(먼저 깔고 있다)와 차례가 맞지 않습니다.")])

# ---------- 6번째: 품질이 안 보이는 시장에서는 보이는 것으로 수익이 흘러간다 ----------
mk(5, 4, [
 "1) 빈칸 문장: 'over time'(시간이 지나면)이 있는 맺음 문장으로, 결과를 말합니다. 'their reliance'(그들의 의존)는 앞 문장의 «Buyers who rely on such signals»(그런 신호에 기대는 구매자)를 받습니다. 투자한 보람이 어디로 흘러가는 시장이 되는지를 묻습니다.",
 "2) 짝꿍 문장: 첫 문장입니다. 처음과 끝이 이어지는 글입니다. «tend to reward sellers who invest in signals rather than in the quality itself»(품질 자체가 아니라 신호에 투자하는 판매자에게 보상하는 경향이 있다). reward(보상하다)가 끝 문장에서 'the returns … flow toward'(수익이 ~로 흘러간다)로 바뀌었습니다. 빈칸은 signals 편이고, 버리는 쪽은 'the quality itself'입니다.",
 "3) 왜 신호인가: «quality is difficult to observe before purchase»(품질은 사기 전에 살펴보기 어렵다). 포장, 보증, 광고는 사기 전에 눈에 보입니다. 구매자는 «they have nothing better available»(더 나은 것이 없다)이므로 보이는 것에 기댑니다.",
 "4) 묶기: 'signals'(신호) = 사기 전에 눈에 보이는 것 = 'whatever buyers can observe before purchase'. 첫 문장의 'observe before purchase'가 선택지에 그대로 돌아왔습니다. 다만 첫 문장에서는 「살펴보기 어려운 것」(품질)이었고, 선택지에서는 「살펴볼 수 있는 것」(신호)입니다. 낱말이 같아서가 아니라 signals 편이라서 고릅니다."],
 "quality가 들어 있는 선택지(품질을 재기 가장 쉬운 제품)가 가장 위험합니다. observe와 measure가 비슷해 보여서 더 끌립니다. 하지만 이 글의 시장은 처음부터 품질을 살펴보기 어려운 시장이고, 수익이 가는 곳은 품질이 아니라 신호입니다. 첫 문장이 'rather than'으로 버린 쪽을 넣은 선택지입니다. 「오래된 회사」도 상식으로는 믿음직하지만 지문에 근거가 없습니다.",
 [("가능한 한 가장 낮은 값을 매기는 판매자", "cheaper, cheap이 나와서 값 이야기로 읽기 쉽습니다. 하지만 지문의 cheap은 물건값이 아니라 신호를 보내는 데 드는 비용입니다. 글은 오히려 비싼 광고('expensive advertising')에 돈을 쓰는 회사가 보상받는다고 합니다. 낱말만 빌려 왔고 뜻이 다릅니다."),
  ("규제 장벽이 가장 적은 산업", "지문에 없는 이야기입니다. 시장, 투자 같은 낱말에서 경제 상식으로 규제를 떠올리면 고르게 됩니다. 글은 산업끼리 견주지 않습니다. 한 시장 안에서 판매자가 품질과 신호 가운데 어디에 돈을 쓰게 되는지를 말할 뿐입니다."),
  ("품질을 재기 가장 쉬운 제품", "quality가 들어 있고 observe와 measure가 비슷해 가장 끌립니다. 하지만 이 글의 시장은 품질을 살펴보기 어려운('difficult to observe') 시장입니다. 수익이 흘러가는 곳은 품질이 아니라 신호입니다. 첫 문장이 'rather than in the quality itself'로 버린 쪽을 다시 넣은 선택지입니다."),
  ("영업해 온 기간이 가장 긴 회사", "셋째 문장에서 끌립니다. 보증을 청구할 때쯤 이미 문을 닫았을 회사 이야기를 읽고 「그러니 오래된 회사가 이긴다」고 넘겨짚는 것입니다. 하지만 글의 요점은 그런 회사도 보증을 싸게 내걸 수 있어서('cheap to offer') 구매자가 가려내지 못한다는 것입니다. 오래된 회사에 수익이 간다는 말은 없습니다."),
  ("구매자가 사기 전에 살펴볼 수 있는 것은 무엇이든", "첫 문장 «reward sellers who invest in signals rather than in the quality itself»가 근거입니다. 품질은 사기 전에 보이지 않고 포장, 보증, 광고는 보이므로, 구매자는 보이는 것에 기대고 수익도 그리로 갑니다. 'signals'를 풀어 쓴 말이 이 선택지입니다.")])

# ---------- 7번째: 정밀도는 잰 양이 알고 싶은 양인지는 말해 주지 않는다 ----------
mk(6, 3, [
 "1) 빈칸 문장: 정밀도가 A는 말해 주고(describes) B에 대해서는 아무 말도 하지 않는다('says nothing about')는 틀입니다. A는 «the confidence with which a quantity has been measured»(어떤 양을 얼마나 확실하게 쟀는가)이고 빈칸이 B입니다. 부정하는 말 nothing이 있으므로, 빈칸은 정밀도가 「못 하는 일」입니다.",
 "2) 짝꿍 문장 하나: 둘째 문장입니다. «accurate about the measurement and silent about a step that precedes it»(측정에 대해서는 정확하고, 그에 앞서는 한 단계에 대해서는 말이 없다). 'silent about'이 끝 문장에서 'says nothing about'으로 돌아옵니다. 처음과 끝이 이어지는 글입니다. 빈칸은 「측정에 앞서는 단계」입니다.",
 "3) 짝꿍 문장 둘: 그 단계가 무엇인지는 가운데에 있습니다. «tells us when the tree died, not when the fire was lit»(나무가 언제 죽었는지를 알려 줄 뿐, 불을 언제 피웠는지는 알려 주지 않는다). 그리고 «the property it measures belongs to the material rather than to the event»(재는 성질은 사건이 아니라 재료의 것이다). 잰 것과 알고 싶은 것이 서로 다릅니다.",
 "4) 묶기: 'when the tree died'(나무가 죽은 때) = 잰 양 = 'that quantity'. 'when the fire was lit'(불을 피운 때), 'the event'(사건) = 알고 싶은 양 = 'the one of interest'. 둘이 같은지 다른지 = 'whether'."],
 "시간 간격을 말하는 선택지(그 재료가 얼마나 오래 묻혀 있었는가)가 가장 위험합니다. 지문에 'four centuries'(400년), 'The gap'(간극)이 나오고 고고학 글이라 「묻혀 있던 기간」이 그럴듯해 보입니다. 하지만 글의 간극은 나무가 죽은 때와 불을 피운 때 사이입니다. 묻혔다는 말은 지문에 없습니다. 표본 수나 장비처럼 측정을 더 잘하는 방법을 말하는 선택지는 모두 A(측정) 편이라 빈칸에 올 수 없습니다.",
 [("그 재료가 얼마나 오래 묻혀 있었는가", "'four centuries'(400년)와 'The gap'(간극)에서 끌립니다. 고고학 글이라 묻혀 있던 기간을 떠올리기도 쉽습니다. 하지만 글의 간극은 나무가 죽은 때와 불을 피운 때 사이입니다. 400년도 타기 전에 땅 위에 놓여 있던('lie on the ground') 시간입니다. 묻혔다는 말은 지문에 없습니다."),
  ("분석할 표본을 어떻게 골랐는가", "sample이 지문('any single sample')에 있고, 표본 고르기는 연구에서 늘 따지는 것이라 상식으로 그럴듯합니다. 하지만 글은 표본을 잘못 골랐다고 하지 않습니다. 어떤 표본을 골라도 재는 성질이 재료의 것('belongs to the material')이라는 점이 문제입니다."),
  ("유적 전체에서 뜬 표본의 수", "«cannot be measured for any single sample»(표본 하나로는 잴 수 없다)을 보고 「그러면 여러 개를 재면 된다」고 넘겨짚으면 고르게 됩니다. 하지만 표본을 늘려도 하나하나는 여전히 나무가 죽은 때만 알려 줍니다. 글이 짚은 문제를 해결책으로 바꾼 선택지이고, 그 해결책은 지문에 없습니다."),
  ("그 양이 우리가 알고자 하는 바로 그 양인지", "«the property it measures belongs to the material rather than to the event»가 근거입니다. 재는 것은 나무가 죽은 때이고 알고 싶은 것은 불을 피운 때입니다. 정밀도는 앞의 것을 얼마나 확실히 쟀는지만 알려 줍니다. 둘째 문장의 'a step that precedes it'(측정에 앞서는 단계)이 바로 이 물음입니다."),
  ("측정하는 데 쓴 장비", "정밀도라고 하면 장비를 떠올리는 상식 때문에 끌립니다. 하지만 장비는 측정(measurement) 쪽의 일입니다. 빈칸 문장에서 정밀도가 이미 말해 주는 쪽, 곧 A 편입니다. 빈칸에는 정밀도가 말해 주지 못하는 것, 측정에 앞서는 단계가 와야 합니다.")])

# ---------- 8번째: 살아남은 회사의 교훈은 까닭이 아니라 특징을 적은 것 ----------
mk(7, 3, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론이고, 빈칸은 'which means'(이는 ~라는 뜻이다) 뒤에 있습니다. they는 Lessons(교훈)입니다. which 앞의 어려운 말을 쉬운 말로 다시 정리하는 자리입니다. 그런 교훈이 정말로 그려 내는 것이 무엇인지를 묻습니다.",
 "2) 짝꿍 문장: 같은 문장 안, which 앞입니다. «a sample whose composition was determined by the outcome being explained»(설명하려는 바로 그 결과가 구성을 정해 버린 표본). 「살아남았다」는 결과로 표본을 골랐으니, 표본 안에는 살아남은 회사만 있습니다.",
 "3) 빠진 것: «Firms that made similar decisions and did not survive are unavailable for the comparison»(비슷한 결정을 내리고도 살아남지 못한 회사는 견줄 수 없다). 같은 결정을 하고 망한 회사가 있다면, 그 결정은 살아남은 까닭이 아닐 수 있습니다. 그런데 그 회사들은 «left no memoir, no case study»(회고록도 사례 연구도 남기지 않았다)라서 확인할 길이 없습니다.",
 "4) 묶기: 살아남은 회사만 모인 표본에서 알 수 있는 것 = 'the characteristics of survivors'(살아남은 쪽의 특징). 견줄 상대가 없어서 알 수 없는 것 = 'the causes of survival'(살아남은 까닭). 첫 문장의 「그 결정이 옳았다」는 결론은 까닭을 말한 것처럼 보이지만, 실은 특징을 적은 것일 뿐입니다."],
 "꼴이 'A rather than B'로 같은 선택지(행동이 아니라 경영자들의 의견)가 가장 위험합니다. 둘째 문장에 「결정을 내린 당사자들이 내린 결론」이라는 말이 있어 더 끌립니다. 하지만 교훈이 다루는 것은 실제로 내린 결정이고, 글이 문제 삼는 것은 누가 말했느냐가 아니라 망한 회사가 표본에 없다는 점입니다. record, memoir에서 「잘 기록된 결정」을 떠올리는 것도 조심합니다.",
 [("보기보다 덜 심각했던 위기", "「살아남았으니 위기가 별것 아니었겠지」라고 넘겨짚으면 고르게 됩니다. 하지만 글은 위기가 얼마나 심했는지를 따지지 않습니다. 오히려 같은 일을 하고도 망한(failed) 회사가 있다고 했으므로, 위기가 가벼웠다는 말과는 맞지 않습니다. 지문에 없는 이야기입니다."),
  ("실제로 한 행동이 아니라 경영자들의 의견", "꼴이 'A rather than B'로 같고, 결론을 내린 사람이 결정을 내린 당사자들('the parties who made the decisions')이라는 말이 있어 끌립니다. 하지만 교훈이 다루는 것은 의견이 아니라 실제로 내린 결정입니다. 글이 짚는 문제는 견줄 상대인 망한 회사가 표본에 없다는 점입니다."),
  ("뜻있는 일반화를 하기에는 너무 짧은 기간", "sample(표본)이라는 말에서 「표본이 모자라다」는 통계 상식을 떠올리면 끌립니다. 하지만 글이 말하는 표본의 문제는 기간이나 크기가 아니라 구성(composition)입니다. 결과를 보고 표본을 골랐다는 것입니다. 기간이 짧다는 이야기는 지문에 없습니다."),
  ("살아남은 까닭이 아니라 살아남은 쪽의 특징", "which 앞의 «a sample whose composition was determined by the outcome being explained»가 근거입니다. 살아남은 회사만 모은 표본에서는 살아남은 회사가 어떠했는지만 알 수 있습니다. 같은 결정을 하고 망한 회사와 견주지 못하므로, 그 결정이 살아남은 까닭인지는 알 수 없습니다."),
  ("그때 유난히 잘 기록된 결정", "record, memoir, 'case study' 같은 낱말에서 끌립니다. 하지만 지문에서 이 낱말들은 「망한 회사는 기록을 남기지 못했다」는 뜻으로 쓰였습니다. 표본을 가른 것은 기록을 얼마나 잘했느냐가 아니라 살아남았느냐입니다. 낱말만 빌려 온 선택지입니다.")])

# ---------- 9번째: 정확하다는 것만으로는 사진이 무엇을 보여 주는지 정해지지 않는다 ----------
mk(8, 2, [
 "1) 빈칸 문장: 'not A but B'(A가 아니라 B) 틀입니다. A는 «whether the image is accurate»(이미지가 정확한가)이고 빈칸이 B, 곧 진짜 쟁점입니다. 바로 앞 문장도 같은 말을 합니다. 사람들은 정직의 문제로 다투지만 그것은 «which misdescribes the difficulty»(어려움을 잘못 짚은 것)입니다. 정확함, 정직함 쪽은 버립니다.",
 "2) 되풀이: 「둘 다 거짓이 아니다」가 세 번 나옵니다. «neither image is falsified»(어느 이미지도 조작되지 않았다) → «both will be vindicated»(둘 다 옳다고 밝혀질 것이다) → «Both photographs record what was in front of the lens»(두 사진 모두 렌즈 앞에 있던 것을 기록한다). 그런데 한 장은 많아 보이고 한 장은 적어 보입니다.",
 "3) 짝꿍 문장: «the evidence that would settle it lies outside the image by definition»(그것을 가려 줄 증거는 처음부터 이미지 바깥에 있다). 사진이 아무리 정확해도, 사진 안만 보아서는 그것이 무엇을 보여 주는지가 정해지지 않는다는 말입니다.",
 "4) 묶기: 'neither image is falsified'(조작되지 않았다) = 'accuracy'(정확함). 둘 다 정확한데 다르게 보인다 + 증거는 이미지 바깥에 있다 = 'alone does not determine what an image shows'(정확함만으로는 이미지가 무엇을 보여 주는지 정해지지 않는다)."],
 "「사진으로는 군중 규모를 어림할 수 없다」가 가장 위험합니다. 보는 사람이 어느 구도인지 알 길이 없다는 말과 닮았기 때문입니다. 하지만 글은 위쪽 뒤에서 잡은 구도가 한계를 드러낸다('reveals the limits')고 했습니다. 사진으로 규모를 아예 알 수 없다는 것은 지나치게 넓힌 말입니다. 또 빈칸은 'whether the image is accurate'와 짝을 이루는 자리라, 정확함이 무엇을 못 하는지를 말해야 합니다. 「속이려 했는지」는 글이 버린 정직 쪽입니다.",
 [("사진가가 처음부터 보는 사람을 속이려 했는지", "글이 버린 쪽입니다. 속일 뜻이 있었는지는 정직의 문제인데, 글은 이런 다툼을 정직의 문제로 벌이는 것이 어려움을 잘못 짚은 것('misdescribes the difficulty')이라고 했습니다. 'not A but B'의 A와 같은 편을 B 자리에 넣은 선택지입니다."),
  ("사진으로는 군중 규모를 어림할 수 없다는 것", "가장 끌리는 선택지입니다. 보는 사람이 어느 구도가 쓰였는지 알 길이 없다는 말과 닮았습니다. 하지만 지나치게 넓힌 말입니다. 위쪽 뒤에서 잡은 구도는 한계를 드러낸다('reveals the limits')고 했으므로 사진으로 규모를 아예 알 수 없는 것은 아닙니다. 글의 요점은 규모가 아니라 「둘 다 정확한데 다르게 보인다」입니다."),
  ("정확함만으로는 이미지가 무엇을 보여 주는지 정해지지 않는다는 것", "세 번 되풀이된 「둘 다 거짓이 아니다」와 «the evidence that would settle it lies outside the image by definition»이 근거입니다. 두 사진 모두 정확한데 하나는 많아 보이고 하나는 적어 보입니다. 정확한지를 따져서는 다툼이 끝나지 않습니다. 'neither image is falsified'가 'accuracy'로 묶였습니다."),
  ("두 판 가운데 어느 것이 먼저 실렸는지", "지문에 없는 이야기입니다. 사진 두 장과 다툼(Disputes)에서 신문 보도를 떠올리면 고르게 됩니다. 하지만 실렸다는 말도, 먼저와 나중도 지문에 나오지 않습니다. 어느 사진이 먼저 실렸는지 밝혀져도 글이 말한 어려움은 그대로 남습니다."),
  ("찍은 뒤에 이미지를 어떻게 손보았는지", "방향이 거꾸로입니다. 첫 문장부터 어느 이미지도 조작되지 않았다('neither image is falsified')고 했고, 두 사진가가 원판(negatives)을 내놓아도 떳떳하다고 했습니다. 손보지 않았는데도 다르게 보인다는 것이 이 글의 출발점입니다.")])

# ---------- 10번째: 빈곤 수치는 기준선 가까이의 움직임만 쳐준다 ----------
mk(9, 4, [
 "1) 빈칸 문장: 짧은 맺음 문장입니다. 'The measure'(그 척도)는 첫머리에 나온, 기준선 아래 가구를 세는 방식입니다. rewards는 「~을 쳐준다, ~에 좋은 점수를 준다」는 뜻입니다. 이 수치로 정책을 평가하면 어떤 것이 좋은 점수를 받게 되는지를 묻습니다.",
 "2) 꺾이는 곳: 셋째 문장의 however입니다. 기준선은 죽 이어진 분포를 한 점에서 자를 뿐이어서, 선 바로 위 가구와 바로 아래 가구의 차이는 «too small to matter in any respect except the classification»(분류 말고는 어떤 면에서도 뜻이 없을 만큼 작다)입니다.",
 "3) 짝꿍 문장: therefore가 있는 다섯째 문장입니다. 선을 조금 넘기는 사업은 «large changes in the reported figure and small changes in circumstances»(보고되는 수치는 크게, 형편은 조금)를 만들고, 가장 가난한 이들을 크게 돕는 사업은 «may leave the figure untouched»(수치를 전혀 건드리지 못할 수 있다)입니다. while을 사이에 두고 두 사업이 맞서 있습니다.",
 "4) 묶기: 'move households across the line by small increments'(가구를 조금씩 선 너머로 옮기기) = 'movement near the threshold'(기준선 가까이에서의 움직임). 'substantially improve the position of the very poorest'(가장 가난한 이들의 처지를 크게 낫게 하기) = 'improvement elsewhere'(다른 곳에서의 나아짐). 수치가 움직이는 쪽만 점수를 받는다 = 'rewards … over …'(~보다 ~을 쳐준다)."],
 "꼴이 'X over Y'로 같은 선택지(짧은 개입보다 긴 계획)가 위험합니다. 가장 가난한 이들을 크게 돕는 일이 긴 계획처럼 느껴져서 끌립니다. 하지만 글이 견준 두 사업의 차이는 기간이 아니라 자리, 곧 선 가까이냐 맨 아래냐입니다. 게다가 척도가 쳐주는 쪽은 조금씩 옮기는 사업입니다. 「효과를 빨리 잴 수 있는 사업」도 measure, programs가 들어 있어 끌리지만, 빠르기 이야기는 지문에 없습니다.",
 [("소득을 정확하게 알리는 가구", "reported(보고되는)와 'without being informed'(알려 주지 않으면)에서 「알리다」를 떠올리면 끌립니다. 하지만 지문의 reported는 수치가 발표된다는 뜻입니다. 가구가 소득을 바르게 알리는지는 지문에 없는 이야기입니다. 또 이 척도가 점수를 매기는 대상은 가구가 아니라 사업(programs)입니다."),
  ("가난한 가구가 가장 많은 지역", "count, number 같은 낱말에서 「수가 많은 곳」을 떠올리면 끌립니다. 하지만 글은 지역끼리 견주지 않습니다. 정책은 그 수가 줄어드는지('whether that number falls')로 평가되므로, 척도가 쳐주는 것은 수가 많은 곳이 아니라 수를 줄이는 사업입니다."),
  ("모든 지역에서 짧은 개입보다 긴 계획", "꼴이 'X over Y'라 끌리고, 가장 가난한 이들을 크게 돕는 일이 긴 계획처럼 느껴집니다. 하지만 글이 견준 두 사업의 차이는 기간이 아니라 자리입니다. 선 가까이냐, 맨 아래냐입니다. 게다가 이 척도가 쳐주는 쪽은 조금씩 선을 넘기는 사업이므로 방향도 맞지 않습니다."),
  ("효과를 빨리 잴 수 있는 사업", "measure, programs가 지문 낱말이고, 'small increments'(작은 폭)에서 「금방 나타나는 효과」를 떠올리면 끌립니다. 하지만 빠르기 이야기는 지문에 없습니다. 수치가 움직이느냐는 얼마나 빨리 재느냐가 아니라, 가구가 선을 넘느냐에 달려 있습니다."),
  ("다른 곳에서의 나아짐보다 기준선 가까이에서의 움직임", "다섯째 문장 «large changes in the reported figure and small changes in circumstances»가 근거입니다. 선을 조금 넘기면 형편은 거의 그대로인데 수치는 크게 줄고, 가장 가난한 이들을 크게 도와도 선을 넘지 못하면 수치는 그대로입니다. 'across the line'이 'near the threshold'로, 'the very poorest'가 'elsewhere'로 바뀌었습니다.")])

# ---------- 11번째: 다시 보아도 같은 범주로 본다 ----------
mk(10, 4, [
 "1) 빈칸 문장: 'cannot be settled'(풀릴 수 없다) 뒤에 since(~이기 때문에)가 오고, 그 뒤가 빈칸입니다. 빈칸은 까닭 자리입니다. 두 사람에게 다시 보라고 해도 왜 풀리지 않는지를 묻습니다. 부정하는 말 cannot이 있으므로, 빈칸에는 「다시 보기가 소용없는 까닭」이 와야 합니다.",
 "2) 꺾이는 곳: 이 글에는 but이 없습니다. 대신 둘째 문장 «Studies of expert observation suggest something else.»(전문가의 관찰을 다룬 연구는 다른 것을 시사한다.)가 꺾는 문장입니다. 첫 문장의 통념, 곧 의견이 갈리는 것은 «a failure of attention»(주의가 모자란 탓)이라는 생각을 버립니다. 「다시 보라」는 것은 이 통념 쪽 해결책입니다.",
 "3) 짝꿍 문장: 셋째 문장입니다. «those categories determine which features are registered as events and which pass as background»(그 범주가 어떤 특징이 사건으로 잡히고 어떤 것이 배경으로 지나가는지를 정한다). 그리고 범주는 «they arrive with the perception»(지각과 함께 온다)이라고 했습니다. 볼 때마다 범주가 따라온다는 뜻입니다.",
 "4) 묶기: 'the categories their training supplied'(훈련이 준 범주) = 'the same categories'(바로 그 범주). 'different arrangements'(서로 다른 배열)를 본다 = 'produced the difference'(차이를 만들어 냈다). 볼 때마다 함께 온다 = 'employs'(쓴다). 다시 보아도 같은 범주로 보니 같은 차이가 다시 나옵니다."],
 "'Asked afterwards'(나중에 물으면)를 보고 기억의 문제로 읽은 선택지(잘못 기억할 위험)가 위험합니다. 글은 두 사람 다 충실하고 정직하게 말한다고 했습니다. 기억이 틀려서 갈리는 것이 아닙니다. 「더 오래 걸린다」도 조심합니다. 더 오래, 더 꼼꼼히 보면 된다는 것은 글이 둘째 문장에서 버린 통념(주의가 모자란 탓)과 같은 편입니다.",
 [("사건을 잘못 기억할 위험을 끌어들인다", "여섯째 문장의 'Asked afterwards'(나중에 물으면)에서 기억을 떠올리면 끌립니다. 하지만 글은 두 사람 모두 충실하고 정직한 설명('a full and honest account')을 한다고 했습니다. 설명이 갈리는 까닭은 기억이 흐려져서가 아니라 처음부터 다르게 보았기 때문입니다."),
  ("다시 되풀이되지 않을 조건에 달려 있다", "실험은 조건이 같아야 한다는 상식 때문에 끌립니다. 하지만 글은 같은 실험, 같은 초원('the same meadow')을 보고도 다르게 본다고 했습니다. 조건이 똑같아도 차이가 납니다. 차이를 만드는 것은 조건이 아니라 보는 사람이 지닌 범주입니다."),
  ("그때는 쓸 수 없었던 장비가 필요하다", "지문에 없는 이야기입니다. 실험과 관찰이라는 말에서 장비를 떠올리면 고르게 됩니다. 하지만 장비 이야기는 한 번도 나오지 않습니다. 글에서 보는 것을 정하는 것은 도구가 아니라 훈련이 준 범주('the categories their training supplied')입니다."),
  ("대부분의 관찰이 허락하는 것보다 더 오래 걸린다", "'more or less carefully'(더 꼼꼼히 또는 덜 꼼꼼히)에서 시간과 정성의 문제로 읽으면 끌립니다. 하지만 글은 바로 그 문장에서 꼼꼼함의 차이가 아니라고 했습니다. 시간을 더 들여 보아도 같은 범주로 봅니다. 글이 버린 통념(주의가 모자란 탓)과 같은 편의 선택지입니다."),
  ("그 차이를 만들어 낸 바로 그 범주를 쓴다", "셋째 문장 «those categories determine which features are registered as events and which pass as background»가 근거입니다. 무엇이 눈에 들어오는지를 범주가 정하고, 그 범주는 볼 때마다 지각과 함께 옵니다. 그래서 다시 보아도 같은 범주가 같은 차이를 만듭니다. 'different arrangements'가 'the difference'로 묶였습니다.")])

# ---------- 12번째: 아무도 까닭을 댈 수 없고 아무도 없애지 않는 코드 ----------
mk(11, 1, [
 "1) 빈칸 문장: therefore(따라서)가 있는 맺음 문장입니다. 빈칸은 'components that'(~한 구성 요소) 뒤에 있습니다. 'such decisions'(그런 결정들)는 코드를 그대로 두기로 하는 결정입니다. 그런 결정이 쌓여서 만들어진 시스템이 어떤 구성 요소에 기대게 되는지를 묻습니다. components는 첫 문장의 code를 바꾼 말입니다.",
 "2) 짝꿍 문장: 첫 문장입니다. 처음과 끝이 이어지는 글입니다. «code that no one understands and no one dares remove»(아무도 이해하지 못하고 아무도 감히 없애지 못하는 코드). 'no one … and no one …'으로 두 가지를 겹쳐 말했습니다.",
 "3) 가운데는 그 두 가지의 까닭입니다. 이해하지 못하는 까닭: «written for conditions that may no longer obtain, by people who have left»(이제는 없을지도 모르는 조건에 맞춰, 떠난 사람들이 썼다). 없애지 못하는 까닭: «Removing it risks an outcome that will be attributed to whoever removed it»(없애면 그 결과가 없앤 사람 탓이 될 위험이 있다), 반대로 «leaving it costs nothing identifiable»(그대로 두면 눈에 띄는 비용이 없다).",
 "4) 묶기: 'no one understands'(아무도 이해하지 못한다) = 'nobody can justify'(아무도 왜 있어야 하는지 댈 수 없다). 'no one dares remove'(아무도 감히 없애지 못한다) = 'nobody will eliminate'(아무도 없애려 하지 않는다). 선택지도 'nobody … and nobody …' 두 겹 꼴입니다. 첫 문장의 꼴이 그대로 돌아온 것입니다."],
 "「나머지보다 덜 꼼꼼하게 테스트되었다」가 가장 위험합니다. 셋째 문장에 따르면 테스트는 누군가 이해한 경로만 다루므로, 이 말은 지문과 어긋나지 않습니다. 하지만 빈칸 문장은 「그대로 두는 결정이 쌓여서」 생기는 결과를 묻습니다. 테스트가 덜 된 것은 그 결정의 결과가 아닙니다. 지문에 있는 내용이라도 빈칸 자리가 묻는 것이 아니면 답이 될 수 없습니다. 오래된 코드는 잘 고장 난다는 상식도 조심합니다.",
 [("자원을 지나치게 많이 차지한다", "cost, costs가 나오고, 오래된 코드는 무겁다는 상식이 있어 끌립니다. 하지만 지문의 cost는 컴퓨터 자원이 아니라 나중에 누군가 치르게 될 대가입니다. 글은 오히려 그대로 두는 데에는 눈에 띄는 비용이 없다('costs nothing identifiable')고 했습니다."),
  ("아무도 까닭을 댈 수 없고 아무도 없애려 하지 않는", "첫 문장 «code that no one understands and no one dares remove»를 바꿔 쓴 것입니다. 이해하지 못하니 왜 있어야 하는지 댈 수 없고(justify), 없앴다가 탈이 나면 자기 탓이 되니 없애지 않습니다(eliminate). 그대로 두는 결정이 쌓이면 시스템은 바로 그런 코드에 기대게 됩니다."),
  ("다른 프로그래밍 언어에 맞춰 설계되었다", "'written for conditions'(어떤 조건에 맞춰 쓰였다)를 보고 「다른 언어로 쓰였다」고 넘겨짚으면 고르게 됩니다. 하지만 conditions는 그때의 사정이지 언어가 아닙니다. 프로그래밍 언어 이야기는 지문에 없습니다."),
  ("새 구성 요소보다 더 자주 고장 난다", "오래된 것은 잘 고장 난다는 상식으로 고르기 쉽습니다. 하지만 글은 그 코드가 탈을 내는 날이 앞으로 십 년 동안 오지 않을 수도 있다('for another decade')고 했습니다. 좀처럼 탈이 나지 않으니 그대로 두게 된다는 글입니다. 방향이 거꾸로입니다."),
  ("나머지보다 덜 꼼꼼하게 테스트되었다", "가장 끌리는 선택지입니다. 셋째 문장에서 테스트는 누군가 이해한 경로만 다룬다고 했으므로 지문과 어긋나는 말은 아닙니다. 하지만 빈칸 문장은 그대로 두는 결정('such decisions')이 쌓여 생기는 결과를 묻습니다. 테스트가 덜 된 것은 그 결정의 결과가 아닙니다. 한 문장의 내용만 옮긴 선택지입니다.")])

# ---------- 13번째: 다시 들여와도 예전 체계가 아니라 새 짜임이 생긴다 ----------
mk(12, 2, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론이고 'not A but B'(A가 아니라 B) 틀입니다. A는 'the earlier system'(예전의 체계)입니다. 첫 문장의 «a return to a prior state»(이전 상태로 돌아감)와 같은 편이고, 버리는 쪽입니다. 빈칸 B는 이런 사업이 정말로 만들어 내는 것입니다.",
 "2) 꺾이는 곳: 둘째 문장의 however입니다. 첫 문장의 'is often described as'(흔히 ~라고 불린다)는 남들의 말을 소개한 것입니다. however 뒤가 글쓴이의 생각입니다. 생태계는 «do not hold still while a species is absent»(어떤 종이 없는 동안 가만히 있지 않는다).",
 "3) 짝꿍 문장: 다섯째 문장입니다. «enters a community that has arranged itself around its absence, and the arrangement does not dissolve on its arrival»(자기가 없는 것을 중심으로 짜인 군집에 들어가며, 그 짜임은 돌아왔다고 풀리지 않는다). 앞뒤 문장에는 「전에는 없던 것」이 두 번 나옵니다. «a wood that was not there before»(전에는 없던 숲), «competitors that were not there before»(전에는 없던 경쟁자).",
 "4) 묶기: 'arranged itself', 'the arrangement'(짜임) = 'configuration'(짜임새). 'not there before'(전에는 없던) = 'new'(새로운). 돌아온 동물은 예전에 살던 그 종이다 = 'a familiar species'(낯익은 종). 종은 낯익지만 짜임은 새것입니다."],
 "「종 다양성이 줄어든 원래의 군집」이 가장 위험합니다. 'the original community'는 'the earlier system'을 말만 바꾼 것입니다. 'not A but B'에서 버린 A를 조금 고쳐 B 자리에 넣은 셈입니다. 반대로 너무 멀리 나간 선택지(다시 들여온 생물에게 맞지 않는 서식지)도 틀립니다. 글은 돌아온 동물의 행동이 바뀐다고 했을 뿐, 살 수 없다고 하지 않았습니다.",
 [("십 년 안에 가라앉는 일시적 교란", "'thirty years', 'fifty years' 같은 햇수와, 「잠깐 흔들리다가 제자리로 돌아간다」는 생각 때문에 끌립니다. 하지만 방향이 거꾸로입니다. 글은 바뀐 짜임이 풀리지 않는다('does not dissolve')고 했습니다. 제자리로 돌아간다는 것은 글이 버린 쪽입니다."),
  ("다시 들여온 생물에게 맞지 않는 서식지", "너무 멀리 나간 선택지입니다. 먹이와 숨을 곳이 달라지고 경쟁자가 생겼다는 말에서 끌립니다. 하지만 글은 그 동물의 행동이 그에 맞춰 바뀐다('changes accordingly')고 했습니다. 살 수 없다거나 맞지 않는다는 말은 지문에 없습니다."),
  ("낯익은 종이 들어 있는 새로운 짜임", "다섯째 문장 «the arrangement does not dissolve on its arrival»이 근거입니다. 종이 없는 동안 생태계는 새로 짜였고, 그 짜임은 종이 돌아와도 그대로입니다. 'the arrangement'가 'configuration'으로, 'not there before'가 'new'로 바뀌었습니다. 돌아온 종만 예전 그대로라서 'a familiar species'입니다."),
  ("풀어 준 개체 수에 따라 정해지는 결과", "지문에 없는 이야기입니다. 재도입 사업이라고 하면 몇 마리를 풀었는지를 떠올리는 상식으로 고르게 됩니다. 하지만 글에서 결과를 정하는 것은 풀어 준 수가 아니라, 그 종이 없는 동안 달라진 생태계입니다."),
  ("종 다양성이 줄어든 원래의 군집", "'the original community'(원래의 군집)는 빈칸 문장이 버린 'the earlier system'(예전의 체계)과 같은 말입니다. 버린 쪽을 조금 고쳐 다시 넣은 선택지입니다. 다양성이 줄었다는 말도 지문에 없습니다. 글은 오히려 전에 없던 숲과 경쟁자가 생겼다고 했습니다.")])

# ---------- 14번째: 두 판단이 함께 보고되면 거절의 까닭을 가려낼 수 없다 ----------
mk(13, 0, [
 "1) 빈칸 문장: 빈칸은 'which means'(이는 ~라는 뜻이다) 뒤에 있습니다. which 앞은 «The two are reported together»(그 둘은 함께 보고된다)입니다. 'The two'는 타당성 판단과 중요성 판단입니다. 둘이 함께 보고되면 거절 결정이 어떤 것이 되는지를 묻습니다.",
 "2) 편 정하기: 글은 두 판단을 맞세웁니다. 결론이 자료에서 따라 나오는가는 «can be answered from the text in front of them»(눈앞의 본문으로 답할 수 있다). 연구가 중요한가는 «cannot be answered from the text at all»(본문으로는 전혀 답할 수 없다). 하나는 확인할 수 있고 하나는 확인할 수 없습니다.",
 "3) 짝꿍 문장: 빈칸 바로 앞 문장입니다. «the judgments carry weight because they arrive attached to the assessment of validity»(그 판단은 타당성 평가에 붙어서 오기 때문에 무게를 갖는다). 확인할 수 없는 판단이 확인할 수 있는 판단에 붙어 한 덩어리로 옵니다.",
 "4) 묶기: 'attached'(붙어서), 'reported together'(함께 보고된다) → 둘을 떼어 볼 수 없다 = 'rarely traceable'(거슬러 찾기 어렵다). 두 판단 가운데 하나 = 'the component'(한 부분). 거절을 낳은 쪽 = 'that produced it'. 거절이 타당성 때문인지 중요성 때문인지 알 수 없다는 말입니다."],
 "'their own position in the field'(분야 안에서 자기가 선 자리)를 「소속 기관」으로 읽은 선택지가 가장 위험합니다. position은 심사자가 그 분야에서 무엇을 알고 무엇을 중요하게 보는가를 뜻합니다. 소속 기관 이야기는 지문에 없습니다. 또 빈칸은 「함께 보고된다」의 결과를 묻는 자리이므로, 두 판단이 섞인다는 말이 와야 합니다.",
 [("그것을 낳은 부분을 거슬러 찾기 어려운", "바로 앞 문장 «they arrive attached to the assessment of validity»와 which 앞의 «The two are reported together»가 근거입니다. 확인할 수 있는 판단과 확인할 수 없는 판단이 한 덩어리로 보고되므로, 거절이 어느 쪽에서 나왔는지 가려낼 수 없습니다. 'attached', 'together'가 'rarely traceable'로 바뀌었습니다."),
  ("학술지가 공개한 기준에 근거한", "방향이 거꾸로입니다. 심사에는 정해진 기준이 있을 것이라는 상식으로 고르기 쉽습니다. 하지만 글은 중요성 판단이 덜 드러나게('less explicitly') 기대된다고 했습니다. 공개된 기준에 따른다는 말은 지문에 없습니다."),
  ("저자들이 이의를 제기할 가능성이 더 큰", "거절이라는 말에서 이의 제기를 떠올리면 끌립니다. 하지만 저자들이 어떻게 대응하는지는 지문에 없는 이야기입니다. 글이 말하는 것은 거절 뒤의 일이 아니라, 거절의 까닭이 드러나느냐입니다."),
  ("심사자의 소속 기관에 영향을 받는", "'their own position in the field'에서 끌립니다. 하지만 이 말은 심사자가 분야 안에서 선 자리, 곧 무엇을 알고 무엇을 중요하게 보는가를 뜻합니다. 소속 기관이 아닙니다. 또 빈칸은 두 판단이 함께 보고된다는 것의 결과를 묻습니다. 낱말을 다른 뜻으로 읽은 선택지입니다."),
  ("받아들이는 결정보다 훨씬 빨리 내려지는", "지문에 없는 이야기입니다. 거절과 수락을 견주는 꼴이라 그럴듯해 보입니다. 하지만 결정이 빠른지 느린지는 한 번도 나오지 않습니다. 글이 견주는 것은 거절과 수락이 아니라 타당성 판단과 중요성 판단입니다.")])

# ---------- 15번째: 화자 수는 누가 말하느냐만큼 어떻게 물었느냐를 보여 준다 ----------
mk(14, 4, [
 "1) 빈칸 문장: 빈칸은 'which indicates that'(이는 ~을 보여 준다) 뒤에 있습니다. which 앞은 «The resulting figures vary with the survey instrument»(그렇게 나온 수치는 조사 도구에 따라 달라진다)입니다. 보존 자원을 나누는 데 쓰는 그 숫자가 정말로 그려 내는 것이 무엇인지를 묻습니다.",
 "2) 꺾이는 곳: 둘째 문장의 however입니다. 화자 수는 스스로 답한 것을 모은 것이고, 그 답은 «shaped by what respondents believe the question means»(응답자가 그 물음이 무슨 뜻이라고 믿느냐에 따라 달라진다)입니다.",
 "3) 짝꿍 문장: 「묻는 방식에 따라 달라진다」가 세 번 나옵니다. «depending on how the item is worded»(문항을 어떻게 적었느냐에 따라) → «asking in slightly different words»(조금 다른 말로 물어서) → 'vary with the survey instrument'(조사 도구에 따라 달라진다). 같은 공동체에서 수치가 세 배나 달랐습니다.",
 "4) 묶기: 'how the item is worded', 'the survey instrument' = 'how the question was asked'(물음을 어떻게 던졌는가). 'the number of speakers'(화자 수) = 'who speaks'(누가 말하는가). 'as much as'(~만큼이나)는 숫자에 화자 수도 들어 있지만 묻는 방식도 그만큼 섞여 있다는 뜻입니다."],
 "꼴이 'A rather than B'인 선택지(응답자의 능력이 아니라 의도)가 가장 위험합니다. 낙인과 위신에 따라 다르게 답한다는 말에서 끌립니다. 하지만 글이 말한 것은 응답자가 물음의 뜻을 어떻게 받아들이느냐이지, 일부러 그렇게 답하려는 의도가 아닙니다. 또 'rather than'으로 능력을 아예 빼 버리면 지나칩니다. 답은 'as much as'로 둘 다 살려 둡니다. 빈칸 바로 앞의 근거도 조사 도구입니다.",
 [("화자에게 연락하기 가장 쉬운 언어", "조사라고 하면 닿기 쉬운 사람만 조사된다는 상식을 떠올려 고르기 쉽습니다. 하지만 지문에 없는 이야기입니다. 글의 문제는 누구에게 물었느냐가 아니라 어떻게 물었느냐('how the item is worded')입니다."),
  ("화자 수가 아니라 그 지역의 인구", "꼴이 'A rather than B'라 그럴듯하고 community라는 말에서 인구를 떠올리기 쉽습니다. 하지만 같은 공동체를 한 해 안에 두 번 조사했는데 수치가 세 배 달랐습니다. 인구는 그대로인데 수치만 달라졌으므로, 그 숫자는 인구를 그린 것이 아닙니다."),
  ("응답자의 능력이 아니라 의도", "가장 끌리는 선택지입니다. 낙인(stigma)과 위신(prestige)에 따라 다르게 답한다는 말에서 끌립니다. 하지만 글이 말한 것은 응답자가 물음의 뜻을 어떻게 받아들이느냐('what respondents believe the question means')입니다. 일부러 그렇게 답하려는 의도가 아닙니다. 능력을 아예 빼 버린 것도 지나칩니다."),
  ("가장 최근의 감소가 일어나기 전의 이전 시기", "endangered(소멸 위기)에서 줄어드는 화자 수를 떠올리고 「수치가 옛것이다」라고 넘겨짚으면 고르게 됩니다. 하지만 한 해 안에 두 번 조사한 수치가 세 배 달랐습니다. 문제는 조사한 때가 아니라 묻는 말입니다. 시기 이야기는 지문에 없습니다."),
  ("누가 말하느냐만큼이나 물음을 어떻게 던졌는가", "which 앞의 «The resulting figures vary with the survey instrument»가 근거입니다. 묻는 말이 조금만 달라도 수치가 세 배 달라지고 언어의 순위가 뒤집힙니다. 그러니 숫자에는 묻는 방식이 섞여 있습니다. 'how the item is worded'가 'how the question was asked'로 바뀌었습니다.")])

# ---------- 16번째: 도로 확장의 성패는 늘어난 통행을 이득으로 세느냐에 달려 있다 ----------
mk(15, 0, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론이고, 빈칸은 'depends on'(~에 달려 있다) 뒤에 있습니다. 도로 확장 사업이 성공했는지가 무엇에 달려 있는지를 묻습니다.",
 "2) 꺾이는 곳: 이 글에는 but이 없습니다. 둘째 문장의 뒤쪽이 꺾는 곳입니다. 혼잡이 돌아왔으니 확장은 소용없다는 통념을 소개한 뒤, «which is a conclusion the evidence does not support»(그것은 그 증거가 뒷받침하지 않는 결론이다)라고 버립니다.",
 "3) 짝꿍 문장: 빈칸 바로 앞 문장입니다. «Those are journeys somebody wanted to make and could not, which is a benefit, and it appears in no traffic count.»(그것은 누군가 하고 싶었지만 하지 못했던 이동이며, 이는 이득인데, 어떤 교통량 집계에도 나타나지 않는다.) 이득은 있는데 세는 표에는 없습니다.",
 "4) 묶기: 'trips that were previously suppressed'(전에는 억눌려 있던 통행), 'journeys somebody wanted to make'(누군가 하고 싶었던 이동) = 'those additional trips'(그 늘어난 통행). 'which is a benefit' + 'appears in no traffic count' = 'whether … are counted as a benefit'(이득으로 셈에 넣느냐). 셈에 넣으면 성공이고, 넣지 않으면 실패로 보입니다."],
 "「혼잡이 얼마나 빨리 돌아왔는가」가 가장 위험합니다. 첫 문장의 'within a few years'(몇 해 안에)와 닮았기 때문입니다. 하지만 혼잡이 돌아온 것으로 성패를 따지는 것은 글이 둘째 문장에서 버린 생각입니다. cost가 들어 있는 선택지(다른 방법과 견준 확장 비용)도 조심합니다. 지문의 cost는 공사비가 아니라 이동에 드는 시간입니다.",
 [("그 늘어난 통행을 이득으로 셈에 넣느냐", "바로 앞 문장 «which is a benefit, and it appears in no traffic count»가 근거입니다. 늘어난 통행은 전에는 하지 못했던 이동이라 이득인데, 교통량 집계에는 잡히지 않습니다. 이것을 셈에 넣느냐에 따라 같은 사업이 성공도 되고 실패도 됩니다. 'appears in no traffic count'가 'counted'로 돌아왔습니다."),
  ("나란히 난 다른 길의 교통량", "'traffic count'(교통량 집계)라는 말과, 다른 길의 차가 옮겨 왔을 것이라는 교통 상식 때문에 끌립니다. 하지만 글은 늘어난 통행이 전에는 아예 하지 못하던 이동('previously suppressed')이라고 했습니다. 다른 길 이야기는 지문에 없습니다."),
  ("도로 포장이 얼마나 오래갈 것으로 보이는가", "지문에 없는 이야기입니다. 도로 공사라는 말에서 포장의 수명을 떠올리면 고르게 됩니다. 글이 따지는 것은 도로가 얼마나 오래 버티느냐가 아니라, 넓힌 도로를 사람들이 어떻게 쓰느냐입니다."),
  ("다른 방법과 견준 확장 비용", "cost가 지문에 있고, 사업은 비용으로 따진다는 상식이 있어 끌립니다. 하지만 지문의 cost는 공사비가 아니라 이동에 드는 시간 비용('the time cost of a journey')입니다. 다른 방법과 견주는 이야기도 없습니다. 낱말만 빌려 왔고 뜻이 다릅니다."),
  ("공사가 끝난 뒤 혼잡이 얼마나 빨리 돌아왔는가", "첫 문장의 'within a few years'에서 끌립니다. 하지만 글이 버린 쪽입니다. 혼잡이 돌아온 것을 실패의 증거로 삼는 것은 «a conclusion the evidence does not support»라고 했습니다. 글대로라면 도로가 다시 차는 것은 도로가 더 쓸모 있어졌다('it has become more useful')는 표시입니다.")])

# ---------- 17번째: 볼 수는 있게 하되 읽을 힘은 주지 않는 투명성 ----------
mk(16, 1, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론이고 동사는 distributes(나누어 준다)입니다. 'in this way'(이런 식으로)는 내부용 문서를 그대로 공개하는 방식을 가리킵니다. 그런 투명성이 무엇을 나누어 주는지를 묻습니다.",
 "2) 편 정하기: 주는 것과 주지 않는 것이 while을 사이에 두고 맞서 있습니다. «satisfies every formal requirement while transferring to outsiders a body of material they cannot evaluate»(형식 요건은 모두 채우면서, 바깥 사람들에게 그들이 평가할 수 없는 자료 덩어리를 넘긴다). 주는 것은 문서이고, 주지 않는 것은 그것을 평가할 힘입니다.",
 "3) 짝꿍 문장: 넷째 문장입니다. «the new audience lacks the background that made the documents intelligible to the original one»(새 독자에게는 원래 독자가 그 문서를 알아볼 수 있게 해 주던 배경이 없다). 문서는 넘어갔지만 배경은 넘어가지 않았습니다.",
 "4) 묶기: 'publishing the documents'(문서 공개), 'the availability of documents'(문서를 볼 수 있음) = 'access'(볼 수 있게 함). 'lacks the background'(배경이 없다), 'cannot evaluate'(평가할 수 없다) = 'without … the capacity to use it'(그것을 쓸 힘은 없이)."],
 "투명성이라고 하면 떠오르는 상식, 곧 감춘 것을 드러낸다는 생각으로 「기관이 감추고 싶어 할 정보」를 고르기 쉽습니다. 하지만 이 글의 문서는 기관이 이미 만들고 있던 것이고, 글은 기관의 태도를 옹호할 만하다(defensible)고까지 합니다. 문제는 감춤이 아니라 읽을 수 없음입니다. 'transferring to outsiders'(바깥 사람들에게 넘긴다)에서 「책임을 넘긴다」를 떠올리는 것도 조심합니다. 넘어간 것은 자료입니다.",
 [("그것을 질 수 없는 쪽에 책임을", "'transferring to outsiders'(바깥 사람들에게 넘긴다)와 cannot이라는 말이 지문과 닮아 끌립니다. 하지만 지문에서 넘어간 것은 책임이 아니라 자료('a body of material')입니다. 누가 책임을 지는지는 지문에 없는 이야기입니다."),
  ("그것을 쓸 힘은 나누어 주지 않으면서 볼 수 있게 함을", "넷째 문장 «the new audience lacks the background that made the documents intelligible to the original one»이 근거입니다. 문서는 공개되어 누구나 볼 수 있지만, 그것을 읽어 낼 배경은 넘어가지 않았습니다. 'the availability of documents'가 'access'로, 'cannot evaluate'가 뒤집혀 'the capacity to use it'으로 바뀌었습니다."),
  ("영향받는 사람들에게 고르지 않게 비용을", "distributes(나누어 준다)라는 동사에서 비용을 나눈다는 말을 떠올리면 끌립니다. 하지만 비용 이야기는 지문에 한 번도 나오지 않습니다. 글에서 고르지 않게 나뉜 것은 비용이 아니라 문서를 읽어 낼 배경입니다."),
  ("기관이 감추고 싶어 할 정보를", "투명성은 감춘 것을 드러내는 일이라는 상식으로 고르기 쉽습니다. 하지만 공개되는 것은 기관이 이미 만들고 있던 문서('the documents they already produce')입니다. 감추려 한다는 말은 없고, 글은 기관의 태도를 옹호할 만하다고 했습니다. 문제는 감춤이 아니라 읽을 수 없음입니다."),
  ("요구보다 느리게 문서를", "documents가 지문 낱말이고 Requests(요청)도 나와서 끌립니다. 하지만 빠르기 이야기는 지문에 없습니다. 문서는 이미 공개되었습니다. 거절된 것은 문서가 아니라 쉽게 풀어 쓴 요약입니다.")])

# ---------- 18번째: '결정적 증거'는 다툼이 끝난 뒤에 붙는 이름 ----------
mk(17, 1, [
 "1) 빈칸 문장: 빈칸은 'which suggests that'(이는 ~을 시사한다) 뒤에 있습니다. which 앞은 «What settled the matter was the gradual departure of those who held the older position»(일을 매듭지은 것은 옛 입장을 지닌 사람들이 차츰 떠난 것이었다)입니다. 「결정적 증거」라는 것이 흔히 무엇인지를 묻습니다.",
 "2) 꺾이는 곳: 이 글에는 but이 없습니다. 첫 문장과 둘째 문장이 맞섭니다. 역사 서술은 증거가 결정적이 된 순간을 짚어 내지만, 그때의 편지를 살펴보면 «rarely locates the moment»(그 순간을 좀처럼 찾지 못한다). 첫 문장은 버리는 쪽입니다.",
 "3) 짝꿍 문장: 셋째 문장입니다. «Participants continued to disagree after the experiment that later accounts treat as conclusive»(나중의 서술이 결정적이라고 다루는 그 실험 뒤에도 참여자들은 계속 의견이 달랐다). 그 실험을 결정적이라고 부르는 것은 그때 사람들이 아니라 나중의 서술입니다.",
 "4) 묶기: 'later accounts treat as conclusive'(나중의 서술이 결정적이라고 다룬다) = 'a description applied'(붙여진 이름). 옛 입장 사람들이 떠나고 난 뒤, 곧 'later' = 'after the disagreement has ended'(다툼이 끝난 뒤에). 증거가 다툼을 끝낸 것이 아니라, 다툼이 끝난 뒤에 그 증거가 결정적이라고 불립니다."],
 "「참여자들이 알아본 것보다 더 일찍 있었던」이 가장 위험합니다. 실험 뒤에도 다툼이 이어졌다는 말을 「증거는 벌써 있었는데 알아보지 못했다」로 읽으면 고르게 됩니다. 하지만 참여자들은 수치를 모두 받아들였습니다. 알아보지 못한 것이 아니라, 알고도 다툼이 끝나지 않았습니다. 사람들이 떠나서 끝났다는 말에서 「증거보다 평판」으로 넘어가는 것도 지나칩니다.",
 [("결국 연구자의 평판보다 덜 중요한", "다툼이 사람들이 떠나서 끝났다는 말에서 「증거보다 사람이 중요하다」로 넘겨짚으면 끌립니다. 하지만 너무 멀리 나간 선택지입니다. 평판 이야기는 지문에 없습니다. 글은 증거와 다른 것의 무게를 견주지 않고, 결정적이라는 이름이 언제 붙는지를 말합니다."),
  ("다툼이 끝난 뒤에 붙여진 이름", "셋째 문장 «the experiment that later accounts treat as conclusive»가 근거입니다. 그 실험 뒤에도 다툼은 이어졌고, 다툼을 끝낸 것은 옛 입장 사람들이 떠난 일이었습니다. 결정적이라는 말은 나중의 서술이 붙인 것입니다. 'later accounts treat as'가 'a description applied after'로 바뀌었습니다."),
  ("참여자들이 알아본 것보다 더 일찍 있었던", "가장 끌리는 선택지입니다. 실험 뒤에도 다툼이 이어졌다는 말을 「증거는 이미 있었는데 알아보지 못했다」로 읽은 것입니다. 하지만 글은 «Nobody disputed the numbers.»라고 했습니다. 모두 수치를 받아들이고도 다툼이 끝나지 않았습니다. 그 증거는 그때 결정적이지 않았습니다."),
  ("다른 목적으로 개발된 기기로 만들어진", "지문에 없는 이야기입니다. measurement, readings 같은 낱말에서 측정 기기를 떠올리면 고르게 됩니다. 하지만 기기가 어떻게 만들어졌는지는 한 번도 나오지 않습니다. 글은 측정값 자체가 아니라 그 값을 어떻게 읽느냐를 말합니다."),
  ("그 분야 바깥의 과학자들이 먼저 알아본", "'later accounts'(나중의 서술)에서 「바깥 사람이 먼저 알아본다」를 떠올리면 끌립니다. 하지만 분야 바깥의 과학자는 지문에 나오지 않습니다. 나중의 서술은 역사를 적은 글이고, 누가 먼저 알아보았느냐는 지문에 없는 이야기입니다.")])

# ---------- 19번째: 효율 예측은 절감분을 아무도 쓰지 않는 것처럼 다룬다 ----------
mk(18, 0, [
 "1) 빈칸 문장: 'as though'(마치 ~인 것처럼)가 있습니다. as though 뒤에는 사실과 다른 말이 옵니다. 'Predictions that ignore this'(이것을 무시하는 예측)의 this는 바로 앞 문장의 내용입니다. 그러니 빈칸에는 글쓴이의 생각이 아니라, 틀린 예측이 깔고 있는 가정이 들어갑니다. 방향을 뒤집어야 하는 빈칸입니다.",
 "2) 편 정하기: 글쓴이의 생각은 다섯째 문장에 있습니다. 설계가 가져다주는 절감분은 «partly taken as improved comfort rather than as reduced consumption»(일부는 소비 감소가 아니라 더 나은 쾌적함으로 쓰인다). 예측은 그 반대, 곧 절감분이 고스란히 소비 감소로 남는다고 봅니다.",
 "3) 짝꿍 문장: 빈칸 바로 앞 문장입니다. «They are spending a windfall on being warm, which is what anyone does with a windfall.»(그들은 뜻밖의 이득을 따뜻하게 지내는 데 쓰고 있으며, 그것은 누구나 뜻밖의 이득으로 하는 일이다.) 이것을 무시한다는 것은 거주자가 그 이득을 쓰지 않는다고 본다는 뜻입니다.",
 "4) 묶기: 'The saving that the design delivers'(설계가 가져다주는 절감분), 'a windfall'(뜻밖의 이득) = 'savings'(절감분). 'spending a windfall'(뜻밖의 이득을 쓴다)을 뒤집으면 'have no opportunity to spend'(쓸 기회가 없다). 뒤집으라는 신호가 'as though'입니다."],
 "이 문항의 가장 큰 함정은 오답이 아니라 답 쪽에 있습니다. 답은 지문 내용과 반대라서, 'as though'를 놓치면 「글과 맞지 않는다」고 지워 버리게 됩니다. 글은 거주자가 절감분을 쓴다고 했고, 틀린 예측은 쓰지 않는다고 봅니다. 나머지 선택지는 cost, construction, comfort처럼 지문 낱말에서 떠올릴 수 있는 이야기(건축업자, 이용자, 기후, 확인 시점)로 만들어졌습니다.",
 [("거주자가 쓸 기회가 없는 절감분", "바로 앞 문장 «They are spending a windfall on being warm, which is what anyone does with a windfall.»이 근거입니다. 글은 거주자가 절감분을 따뜻하게 지내는 데 쓴다고 했습니다. 이것을 무시하는 예측은 절감분을 아무도 쓰지 않고 고스란히 남는 것처럼 다룹니다. 'as though' 뒤라서 지문과 반대되는 말이 맞습니다."),
  ("전부 건축업자에게 떨어지는 비용", "cost와 construction이 지문에 있어 끌립니다. 하지만 지문의 cost는 난방에 드는 비용이고, construction은 원인이 시공의 결함이 아니라는('not a defect in construction') 말에 나옵니다. 건축업자가 비용을 진다는 이야기는 지문에 없습니다."),
  ("건물을 쓰는 모든 이에게 고르게 돌아가는 이득", "occupants(거주자)와 comfort(쾌적함)에서 이득이 나뉜다는 말을 떠올리면 끌립니다. 하지만 누가 더 받고 덜 받는지는 지문에 없는 이야기입니다. 예측이 놓친 것은 이득의 나눔이 아니라, 절감분이 쓰인다는 사실입니다."),
  ("그 지역 기후와 상관없는 결과", "heat, temperature, warm 같은 낱말에서 기후를 떠올리면 고르게 됩니다. 하지만 기후 이야기는 지문에 없습니다. 예측이 무시한 것(this)은 기후가 아니라 거주자의 행동입니다."),
  ("설치하고 몇 해가 지나야만 확인할 수 있는 결과", "계량기가 모델과 어긋난다('the meter disagrees with the model')는 말에서 「써 봐야 안다」를 떠올리면 끌립니다. 하지만 몇 해가 지나야 안다는 말은 지문에 없습니다. 예측이 틀리는 까닭은 확인하는 때가 아니라, 거주자가 절감분을 쓴다는 점을 뺐기 때문입니다.")])

# ---------- 20번째: 합의가 먼저, 까닭은 나중 ----------
mk(19, 4, [
 "1) 빈칸 문장: and를 사이에 두고 두 쪽으로 나뉩니다. 앞쪽은 인정입니다. «genuine in the sense that everyone agrees at the end»(끝에 가서 모두가 동의한다는 뜻에서는 진짜다). 뒤쪽이 글쓴이가 하려는 말이고, 빈칸은 'a process in which'(~한 과정) 뒤에 있습니다. 그 합의가 어떤 과정에서 나왔는지를 묻습니다.",
 "2) 꺾이는 곳: 첫 문장은 위원회가 스스로 하는 말입니다. «their deliberation produced a consensus»(심의가 합의를 만들어 냈다). 둘째 문장의 연구가 이것을 뒤집습니다. 받아들여진 입장은 «the one favored by a majority before discussion began»(논의가 시작되기 전에 다수가 좋아하던 것)이고, 논의는 «to supply reasons for it rather than to test it»(그것을 따져 보기보다 그것에 까닭을 대 주는) 일을 합니다.",
 "3) 짝꿍 문장: 「차례가 거꾸로다」가 세 번 나옵니다. 'before discussion began'(논의가 시작되기 전에) → «they were assembled after the conclusion»(까닭은 결론 뒤에 모아졌다) → «an agreement that was reached before anyone spoke»(누가 말하기도 전에 이른 합의).",
 "4) 묶기: «an agreement that was reached before anyone spoke» + «they were assembled after the conclusion» = 'agreement was reached before the reasons were assembled'(까닭이 모아지기 전에 합의에 이르렀다). 이 문항은 답에 지문 낱말이 그대로 들어 있습니다. 두 짝꿍 문장을 한 줄로 합친 것입니다. 낱말이 같아서가 아니라 세 번 되풀이된 생각이라서 고릅니다."],
 "회의가 잘못되는 흔한 까닭(시간이 모자랐다, 의장이 밀어붙였다, 정보가 모자랐다)을 말하는 선택지들이 상식으로 그럴듯합니다. 특히 'the discussion moves on and does not come back'(논의가 넘어가서 돌아오지 않는다)에서 시간이 모자랐다고 읽기 쉽습니다. 하지만 글은 누구의 잘못도 말하지 않습니다. 아무도 소수 의견을 막지 않았습니다. 글이 짚는 것은 오직 차례입니다.",
 [("위원들이 비슷한 배경 때문에 뽑힌", "select라는 낱말과, 다들 비슷하면 금방 합의한다는 상식 때문에 끌립니다. 하지만 지문의 select는 위원회가 후보를 뽑는다는 뜻입니다. 위원들의 배경은 지문에 없는 이야기입니다. 오히려 위원 가운데 소수 의견('minority views')을 가진 사람이 있었습니다."),
  ("집단이 가진 정보가 온전하지 못한", "결정이 잘못되는 것은 정보가 모자라서라는 상식으로 고르기 쉽습니다. 하지만 정보 이야기는 지문에 없습니다. 글은 나온 까닭들이 좋은 까닭('good reasons')이라고까지 했습니다. 문제는 정보가 아니라 결론과 까닭의 차례입니다."),
  ("의장이 다른 위원보다 더 큰 영향을 미친", "회의라고 하면 누군가 밀어붙였을 것이라는 상식으로 고르기 쉽습니다. 하지만 의장은 지문에 나오지 않습니다. 글은 «Nobody rules them out»(아무도 그것을 배제하지 않는다)이라고 했습니다. 누가 힘으로 누른 것이 아닙니다."),
  ("충분히 토론하기에는 주어진 시간이 모자란", "'the discussion moves on and does not come back'(논의가 넘어가서 돌아오지 않는다)에서 시간이 모자랐다고 읽으면 끌립니다. 하지만 시간 이야기는 지문에 없습니다. 결론이 먼저 정해져 있으면 시간이 더 있어도 논의는 까닭을 대는 일만 합니다."),
  ("까닭이 모아지기 전에 합의에 이른", "셋째 문장 «they were assembled after the conclusion»과 다섯째 문장 «an agreement that was reached before anyone spoke»가 근거입니다. 결론이 먼저 있었고 까닭은 그 뒤에 모았습니다. 두 문장을 한 줄로 합친 선택지입니다. 둘째 문장의 'before discussion began'까지, 같은 생각이 세 번 나옵니다.")])

# ---------- 21번째: 운항 횟수만으로 짠 청소 일정은 필요를 잘못 알려 준다 (한 낱말 빈칸) ----------
mk(20, 3, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론이고, 빈칸은 한 낱말입니다. 'a schedule built on movements alone'(운항 횟수만으로 짠 일정)이 어떤 일정인지를 묻습니다. alone(~만으로)은 「그것만으로는 모자라다」는 신호입니다. 그러니 빈칸에는 그 일정의 문제점을 말하는 낱말이 와야 합니다.",
 "2) 편 정하기: 셋째 문장은 교통량으로 정한 일정을 «a reasonable proxy and not a measurement»(그럴듯한 대용 지표이지 측정값은 아니다)라고 했습니다. 넷째 문장은 'not A but B' 틀입니다. 쌓임을 정하는 것은 «not the number of landings but their concentration»(착륙 횟수가 아니라 착륙이 몰린 정도)입니다. 횟수는 버리는 쪽입니다. 'traffic volume', 'the number of landings', 'movements'는 모두 같은 것(횟수)을 가리킵니다.",
 "3) 짝꿍 문장: 빈칸 문장의 앞 절입니다. «Two airports reporting identical movements can need cleaning at intervals that differ by a factor of two»(운항 횟수가 똑같다고 보고하는 두 공항이 두 배나 다른 간격으로 청소가 필요할 수 있다). 횟수가 같아도 필요는 다릅니다.",
 "4) 묶기: 'not a measurement'(측정값이 아니다) + 'differ by a factor of two'(두 배나 다르다) = 'misleading'(잘못 알게 하는). 횟수는 고무가 쌓인 양을 직접 잰 것이 아닙니다. 그래서 횟수만 믿으면 청소가 언제 필요한지를 틀리게 알게 됩니다."],
 "'standardized'(표준화된)가 가장 위험합니다. 횟수 하나로 모든 공항에 같은 잣대를 대는 일정이니 그럴듯해 보입니다. 하지만 빈칸 앞에는 therefore가 있습니다. 「두 배나 다르다」는 사실에서 따라 나오는 말이어야 하고, alone이 알려 주듯 문제점을 말해야 합니다. 'conservative'(넉넉하게 잡은)도 조심합니다. 안전 이야기라 끌리지만, 활주로가 하나인 공항에는 이 일정이 오히려 모자랍니다.",
 [("조심스럽게 넉넉히 잡은", "안전을 다루는 글이라 「넉넉하게 잡은 일정」이 그럴듯해 보입니다. 하지만 운항 횟수가 같은 두 공항의 필요가 두 배나 다르다고 했습니다. 활주로가 둘인 공항에는 넉넉해도, 하나인 공항에는 모자랍니다. 늘 넉넉한 쪽이라고 할 수 없습니다."),
  ("비용이 많이 드는", "고압수로 씻어 내는 일이라 비용을 떠올리기 쉽습니다. 하지만 비용 이야기는 지문에 없습니다. 글이 내린 결론은 돈이 든다는 것이 아니라, 횟수만으로는 청소가 언제 필요한지 제대로 알 수 없다는 것입니다."),
  ("표준화된", "가장 끌리는 선택지입니다. 횟수 하나로 모든 공항에 같은 잣대를 대는 일정이니 틀린 말은 아닙니다. 하지만 빈칸 앞의 therefore는 「필요가 두 배나 다르다」에서 따라 나오는 말을 요구합니다. alone이 알려 주듯, 빈칸은 그런 일정의 문제점을 말하는 자리입니다."),
  ("잘못 알게 하는", "빈칸 문장의 앞 절 «Two airports reporting identical movements can need cleaning at intervals that differ by a factor of two»가 근거입니다. 횟수가 같아도 필요가 두 배 다르므로, 횟수만 보고 짠 일정은 필요를 틀리게 알려 줍니다. 셋째 문장의 «a reasonable proxy and not a measurement»도 같은 말입니다."),
  ("피할 수 없는", "셋째 문장의 'a reasonable proxy'(그럴듯한 대용 지표)를 「어쩔 수 없이 쓰는 것」으로 읽으면 끌립니다. 하지만 방향이 거꾸로입니다. 글은 쌓임을 정하는 것이 착륙이 몰린 정도라고 밝혔습니다. 더 나은 기준이 있다는 뜻이므로 피할 수 없는 일정이 아닙니다.")])

# ---------- 22번째: 어느 쪽이 더 자유로운지는 연주의 어느 면을 보느냐에 달려 있다 ----------
mk(21, 3, [
 "1) 빈칸 문장: 빈칸은 'depends on'(~에 달려 있다) 뒤에 있습니다. 'Which practice'(어느 쪽 방식)는 즉흥 연주와 악보 연주입니다. latitude는 여지, 곧 자유입니다. 어느 쪽이 더 자유로운지가 무엇에 달려 있는지를 묻습니다. 「~에 달려 있다」는 한마디로 답할 수 없다는 뜻입니다.",
 "2) 꺾이는 곳: 둘째 문장입니다. 첫 문장의 'are often described as'(흔히 ~라고 불린다)는 남들의 말입니다. 즉흥은 자유롭고 악보는 묶여 있다는 통념입니다. 둘째 문장이 이것을 버립니다. «The contrast does not survive examination of what improvisers actually do.»(이 대비는 즉흥 연주자가 실제로 하는 일을 살펴보면 버티지 못한다.)",
 "3) 짝꿍 문장: 두 쪽에 하나씩 있습니다. 즉흥 연주는 «a set of expectations about harmony, phrasing, and form that are not written down and are not optional»(화성, 프레이징, 형식에 관한, 적혀 있지 않지만 마음대로 할 수도 없는 기대) 안에 있습니다. 악보는 «leaves unspecified almost everything that determines how a performance sounds»(연주가 어떻게 들릴지를 정하는 거의 모든 것을 정하지 않고 남겨 둔다). 한쪽은 이 면에서 묶이고, 다른 쪽은 저 면에서 풀려 있습니다.",
 "4) 묶기: 'harmony, phrasing, and form'(즉흥이 묶이는 면), 'Tempo, dynamics, phrasing'(악보가 풀어 주는 면) = 'dimensions of the performance'(연주의 여러 면). 어느 면을 보느냐에 따라 답이 달라진다 = 'which … are being considered'. dimensions는 지문에 없는 낱말입니다. 늘어놓은 것들을 한 낱말로 묶은 것입니다."],
 "「연주자가 받은 훈련의 수준」이 가장 위험합니다. 여섯째 문장의 «a conductor spends a career learning»(지휘자가 평생을 들여 배운다)에서 끌립니다. 하지만 그 말은 악보 연주에도 적혀 있지 않은 한계가 있다는 보기일 뿐입니다. 글이 견주는 것은 연주자 한 사람 한 사람이 아니라 두 방식입니다. tradition이 들어 있는 선택지(청중이 그 전통에 익숙한지)도 낱말만 빌려 온 것입니다.",
 [("연주 공간의 음향 특성", "sounds, balance 같은 낱말에서 음향을 떠올리면 고르게 됩니다. 하지만 지문에 없는 이야기입니다. 연주하는 곳이 어떤지는 한 번도 나오지 않습니다. 글이 견주는 것은 두 연주 방식이 무엇을 정해 두고 무엇을 남겨 두느냐입니다."),
  ("청중이 그 전통에 익숙한지", "tradition이 지문 낱말이고, 'heard as mistakes'(실수로 들린다)에서 듣는 사람을 떠올리면 끌립니다. 하지만 글은 그 기대가 마음대로 할 수 없는 것('not optional')이라고 했습니다. 청중에 따라 달라진다는 말은 없습니다. 낱말만 빌려 온 선택지입니다."),
  ("연주자가 받은 훈련의 수준", "가장 끌리는 선택지입니다. «a conductor spends a career learning»에서 끌립니다. 하지만 그 말은 악보 연주에도 적혀 있지 않은 한계가 있다는 보기입니다. 훈련을 많이 받으면 더 자유롭다는 말은 없습니다. 글이 견주는 것은 연주자가 아니라 두 방식입니다."),
  ("연주의 어느 면을 살펴보고 있는지", "두 짝꿍 문장이 근거입니다. 즉흥 연주는 화성, 프레이징, 형식에서 묶여 있고, 악보는 «leaves unspecified almost everything that determines how a performance sounds»라고 했습니다. 어느 면을 보느냐에 따라 더 자유로운 쪽이 바뀝니다. 늘어놓은 화성, 형식, 빠르기, 셈여림이 'dimensions' 한 낱말로 묶였습니다."),
  ("그 곡이 연주 목록에 들어 있은 기간", "tradition(전통)에서 오래된 곡을 떠올리면 고르게 됩니다. 하지만 곡이 얼마나 오래되었는지는 지문에 없는 이야기입니다. 글은 곡이 아니라 연주하는 방식 두 가지를 견줍니다.")])

# ---------- 23번째: 돈은 행동뿐 아니라 행동하는 이유까지 바꾸어 놓는다 ----------
mk(22, 0, [
 "1) 빈칸 문장: 빈칸은 'which means'(이는 ~라는 뜻이다) 뒤에 있습니다. which 앞은 «the displaced motive does not automatically return»(밀려난 동기는 저절로 돌아오지 않는다)입니다. 그 사업이 무엇을 바꾸어 놓았는지를 묻습니다.",
 "2) 편 정하기: 첫 문장에 실마리가 있습니다. 돈을 주는 동안에는 행동이 바뀌지만 끊으면 사라지고, «the loss is often larger than the initial gain»(잃는 것이 처음 얻은 것보다 큰 경우가 많다). 둘째 문장에서는 참여가 처음보다도 낮아졌습니다(«participation below the level measured before»). 행동만 바뀌었다면 돈을 끊었을 때 처음으로 돌아가야 합니다. 처음보다 낮아졌으니 행동 말고 다른 것도 바뀐 것입니다.",
 "3) 짝꿍 문장: 넷째 문장입니다. «participants who previously acted from other motives are supplied with a reason that displaces them»(전에는 다른 동기로 행동하던 참여자들에게 그 동기를 밀어내는 이유가 주어진다). 돈이라는 이유가 들어오면서 원래의 이유가 밀려났습니다.",
 "4) 묶기: 'other motives'(다른 동기), 'a reason of their own'(자기 나름의 이유) = 'the reasons for acting'(행동하는 이유). 'the change'(행동의 변화) = 'the acting itself'(행동 자체). 'as well as'(~뿐만 아니라)는 둘 다 바뀌었다는 뜻입니다."],
 "「다른 선택과 견준 그 행동의 비용」이 가장 위험합니다. 'the activity acquires a price'(그 활동에 값이 붙는다)에서 끌리고, 돈을 주면 비용이 달라진다는 경제 상식과도 맞습니다. 하지만 비용만 바뀐 것이라면 돈을 끊었을 때 처음으로 돌아가야 합니다. 처음보다 낮아진 것은 비용으로 풀리지 않습니다. 글에서 「값이 붙는다」는 행동하는 이유가 돈으로 바뀐다는 뜻입니다.",
 [("행동 자체뿐만 아니라 행동하는 이유", "which 앞의 «the displaced motive does not automatically return»이 근거입니다. 돈이 들어오면서 원래의 동기가 밀려났고, 돈을 끊어도 그 동기는 돌아오지 않습니다. 그래서 참여가 처음보다도 낮아집니다. 'other motives', 'a reason of their own'이 'the reasons for acting'으로 바뀌었습니다."),
  ("참여자들이 시작할 때 가지고 있던 정보", "사업이라고 하면 무엇인가를 알려 준다는 상식으로 고르기 쉽습니다. 하지만 지문에 없는 이야기입니다. 글에서 바뀐 것은 참여자가 아는 것이 아니라 참여자가 행동하는 까닭입니다."),
  ("효과를 재야 하는 기간", "'after a year'(한 해 뒤), measured(잰) 같은 말에서 끌립니다. 하지만 재는 기간은 연구하는 사람이 정하는 것이지 사업이 바꾸어 놓은 것이 아닙니다. 글이 말하는 변화는 참여자 안에서 일어난 것입니다."),
  ("스스로 참여하기로 하는 사람들의 집단", "participation과 'a reason of their own'(자기 나름의 이유)에서 끌립니다. 하지만 글은 참여하는 사람이 다른 사람으로 바뀌었다고 하지 않습니다. 같은 사람들 안에서 동기가 바뀌었다고 합니다. 낱말만 빌려 온 선택지입니다."),
  ("다른 선택과 견준 그 행동의 비용", "가장 끌리는 선택지입니다. 'the activity acquires a price'(그 활동에 값이 붙는다)에서 끌립니다. 하지만 비용만 바뀐 것이라면 돈을 끊었을 때 처음으로 돌아가야 합니다. 글은 참여가 처음보다도 낮아졌다고 했습니다. 「값이 붙는다」는 행동하는 이유가 돈으로 바뀐다는 뜻입니다.")])

# ---------- 24번째: 일반 지도에서는 빠진 것이 빠졌다는 흔적을 남기지 않는다 ----------
mk(23, 2, [
 "1) 빈칸 문장: 'Difficulty arises with'(어려움은 ~에서 생긴다)로 시작하는 긴 문장입니다. where가 두 번 나옵니다. 첫 where는 「고른 사람의 목적이 밝혀져 있지 않다」이고, 빈칸은 둘째인 'and where what has been left out'(그리고 빠진 것이 ~) 뒤에 있습니다. 빈칸은 어려움의 둘째 조건이므로 나쁜 쪽 말이어야 합니다.",
 "2) 편 정하기: 바로 앞 문장과 맞서 있습니다. «Users generally understand this for maps whose purpose is announced.»(목적이 밝혀진 지도에 대해서는 이용자들이 대체로 이것을 이해한다.) this는 「모든 지도는 골라 담은 것」이라는 사실입니다. 도로 지도에 높낮이가 없으면 누구나 빠졌다는 것을 압니다. 목적이 밝혀지지 않은 지도는 그 반대입니다.",
 "3) 짝꿍 문장: 빈칸 문장 안의 첫 where 절입니다. «whose purposes are not stated and are frequently inherited»(목적이 밝혀져 있지 않고 흔히 물려받은 것이다). 목적을 모르면 무엇을 뺐는지도 알 길이 없습니다. 'not stated'(밝혀져 있지 않다)가 빈칸에서 다른 말로 한 번 더 나옵니다.",
 "4) 묶기: 'not stated'(밝혀져 있지 않다) → 뺐다는 사실도 드러나지 않는다 = 'leaves no trace'(흔적을 남기지 않는다). 'what has been left out'(빠진 것) = 'anything was left out'(무엇인가 빠졌다는 것). 앞 문장의 understand(이해한다)를 뒤집은 말입니다."],
 "지도 상식에 기대는 선택지들이 위험합니다. 「인쇄된 범례로 되살려 낼 수 있다」와 「뒤의 판에서 되살려진다」는 둘 다 문제가 풀린다는 말입니다. 그런데 빈칸은 「어려움이 생긴다」의 조건입니다. 풀리는 말은 올 수 없습니다. 「축척에 따라 달라진다」는 지도에 대해 맞는 말이지만, 축척은 지문에 나오지 않습니다. 상식으로 맞는 말과 지문에 근거가 있는 말은 다릅니다.",
 [("인쇄 과정의 기술적 한계를 반영한다", "첫 문장에서 모든 것을 담은 지도는 쓸 수 없다고 한 것을 「기술의 한계」로 읽으면 끌립니다. 하지만 글에서 무엇이 빠지는지를 정하는 것은 인쇄 기술이 아니라 목적입니다('the selection reflects a purpose'). 인쇄 이야기는 지문에 없습니다."),
  ("골라 잡은 축척에 따라 달라진다", "지도 상식으로는 맞는 말이라 끌립니다. 하지만 축척은 지문에 나오지 않습니다. 글은 무엇이 빠지는지를 목적이 정한다고 했고, 일반 지도에서는 그 목적이 드러나지 않는다는 점을 문제 삼습니다. 상식으로는 맞지만 지문에 근거가 없습니다."),
  ("무엇인가 빠졌다는 흔적을 남기지 않는다", "빈칸 문장 안의 «whose purposes are not stated and are frequently inherited»가 근거입니다. 목적이 밝혀진 지도에서는 무엇이 빠졌는지 짐작할 수 있지만, 목적이 밝혀지지 않은 지도에서는 빠졌다는 사실조차 알 수 없습니다. 'not stated'가 'leaves no trace'로 바뀌었습니다."),
  ("인쇄된 범례로 되살려 낼 수 있다", "방향이 거꾸로입니다. 지도에는 범례가 있다는 상식으로 고르기 쉽습니다. 하지만 빈칸은 'Difficulty arises'(어려움이 생긴다)의 조건입니다. 빠진 것을 되살려 낼 수 있다면 어려움이 아닙니다. 범례 이야기도 지문에 없습니다."),
  ("대개 뒤의 판에서 되살려진다", "'has always shown'(늘 보여 온)에서 판을 거듭한다는 것을 떠올리면 끌립니다. 하지만 방향이 거꾸로입니다. 글은 국가 지도책이 늘 보여 온 것을 그대로 보여 준다고 했습니다. 빠진 것은 판이 바뀌어도 계속 빠져 있다는 뜻입니다.")])

# ---------- 25번째: 위기 때 만나는 상관 구조는 포트폴리오를 지을 때의 것과 다르다 ----------
mk(24, 1, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론입니다. 주어는 «A portfolio assembled to be robust under measured historical correlations»(지난날 잰 상관관계 아래에서 튼튼하도록 짠 포트폴리오)이고, 그것이 'at the moment of stress'(위기의 순간에) 어떤 상관 구조를 만나는지를 묻습니다. 「지난날 잰 것」과 「위기의 순간」이 한 문장 안에서 맞서 있습니다.",
 "2) 편 정하기: 셋째 문장이 방향을 정합니다. 분산의 바탕이 된 관찰은 «holds under ordinary conditions and weakens precisely when it is most needed»(평소 조건에서는 들어맞고, 가장 필요한 바로 그때 약해진다). 평소와 위기가 다르다는 쪽입니다.",
 "3) 짝꿍 문장: 두 문장이 짝을 이룹니다. 지을 때의 상관은 «estimated over years in which nothing much happened»(별일 없던 해들에 걸쳐 어림한) 것입니다. 위기 때에는 «correlations across asset classes rise»(자산군 사이의 상관이 올라간다). 지을 때 본 것과 위기 때 만나는 것이 다릅니다.",
 "4) 묶기: 'a covariance matrix', 'measured historical correlations'(지난날 잰 상관관계) = 'the one on which it was constructed'(그것을 지을 때 바탕으로 삼은 것). 상관이 올라간다, 약해진다 = 'different from'(~와 다른)."],
 "historical과 통하는 선택지(지난 수십 년 동안 관찰된 것과 똑같은)가 위험합니다. 지문 낱말과 닮았지만 방향이 거꾸로입니다. 같다면 분산이 그대로 통했을 것입니다. 「몇 거래일 안에 뒤집히는」도 조심합니다. 위기는 금방 지나간다는 상식으로 그럴듯하지만, 얼마나 오래가는지는 지문에 없습니다. 글의 요점은 가장 필요한 때에 달라진다는 것입니다.",
 [("지난 수십 년 동안 관찰된 것과 똑같은", "방향이 거꾸로입니다. historical(지난날의)과 통해서 끌립니다. 하지만 글은 심한 하락 때 자산군 사이의 상관이 올라간다고 했습니다. 지난날과 달라진다는 뜻입니다. 똑같다면 분산은 위기 때에도 그대로 통했을 것입니다."),
  ("그것을 지을 때 바탕으로 삼은 것과 다른", "«estimated over years in which nothing much happened»와 «correlations across asset classes rise»가 근거입니다. 별일 없던 해의 상관을 보고 지었는데, 위기 때에는 상관이 올라갑니다. 셋째 문장의 'weakens precisely when it is most needed'도 같은 말입니다. 'measured historical correlations'가 'the one on which it was constructed'로 바뀌었습니다."),
  ("주로 보유 규모에 따라 정해지는", "Holdings, holders 같은 낱말에서 끌립니다. 하지만 글에서 상관을 올리는 것은 보유 규모가 아닙니다. 하락을 일으킨 사건이 모든 자산에 영향을 미치고, 현금이 필요한 사람들이 팔 수 있는 것을 다 팔기 때문입니다. 낱말만 빌려 온 선택지입니다."),
  ("몇 거래일 안에 뒤집히는", "위기는 금방 지나가고 제자리로 돌아온다는 상식으로 고르기 쉽습니다. 하지만 달라진 상관이 얼마나 오래가는지는 지문에 없는 이야기입니다. 글의 요점은 기간이 아니라, 분산이 가장 필요한 때에 상관이 달라진다는 것입니다."),
  ("개별 투자자의 선호를 반영하는", "보유자들이 판다는 말에서 투자자의 선택을 떠올리면 끌립니다. 하지만 글의 보유자들은 좋아서 파는 것이 아니라 어쩔 수 없이('forced to raise cash') 팝니다. 선호가 아니라 몰린 처지입니다. 선호 이야기는 지문에 없습니다.")])

# ---------- 26번째: 법정이 보는 확신은 지목 뒤에 일어난 일들이 빚은 것 ----------
mk(25, 3, [
 "1) 빈칸 문장: 빈칸은 'which means'(이는 ~라는 뜻이다) 뒤에 있습니다. which 앞은 «their confidence has been shaped by everything that happened since»(그들의 확신은 그 뒤에 일어난 모든 일로 빚어져 있다)입니다. 'the quantity the court observes'(법정이 보는 양)는 증언할 때의 확신입니다. 그것이 정말로 무엇인지를 묻습니다.",
 "2) 꺾이는 곳: 첫 문장의 'seems reasonable'(그럴듯해 보인다)에서 seems는 겉보기라는 신호입니다. 둘째 문장의 연구가 이것을 흔듭니다. 지목 바로 뒤에 잰 확신은 정확성과 어느 정도 맞지만, «confidence measured later correlates with accuracy hardly at all»(나중에 잰 확신은 정확성과 거의 맞지 않는다).",
 "3) 짝꿍 문장: 넷째 문장입니다. «confidence rises with rehearsal, with confirming feedback, and with the passage of time»(확신은 되풀이해 떠올릴수록, 맞다고 해 주는 반응을 받을수록, 시간이 지날수록 올라간다). 셋 다 지목 뒤의 일입니다. 그리고 «none of which affects whether the original identification was correct»(그 어느 것도 처음의 지목이 옳았는지와는 상관이 없다).",
 "4) 묶기: 'shaped by'(~로 빚어진) = 'a product of'(~의 산물). 'everything that happened since'(그 뒤에 일어난 모든 일) = 'events after the identification'(지목 뒤의 일들). largely(대체로)가 붙은 것은 지목 바로 뒤의 확신도 조금은 남아 있기 때문입니다."],
 "「목격자가 그 장면을 얼마나 잘 떠올리는지에 따라 정해지는」이 가장 위험합니다. 확신이 크면 기억이 또렷할 것이라는 상식과 맞기 때문입니다. 하지만 그것이 바로 글이 흔드는 생각입니다. 나중에 잰 확신은 정확성과 거의 맞지 않습니다. 「처음의 확신을 그대로 비춘 것」도 방향이 거꾸로입니다. 글은 두 확신이 전혀 같은 양이 아니라고 했습니다.",
 [("가까이에서 본 사건일 때 가장 믿을 만한", "목격이라고 하면 가까이에서 보았는지를 따지는 상식으로 고르기 쉽습니다. 하지만 거리 이야기는 지문에 없습니다. 글이 가르는 기준은 얼마나 가까이에서 보았느냐가 아니라, 확신을 언제 쟀느냐입니다."),
  ("목격자가 처음에 가졌던 확신을 그대로 비춘 것", "방향이 거꾸로입니다. 확신은 처음부터 끝까지 같을 것이라는 생각으로 고르기 쉽습니다. 하지만 글은 지목 바로 뒤의 확신과 나중의 확신이 «are not the same quantity at all»(전혀 같은 양이 아니다)이라고 했습니다. 법정이 보는 것은 나중의 확신입니다."),
  ("지목이 어떻게 이루어졌는지와 상관없는", "'none of which affects'(그 어느 것도 영향을 주지 않는다)와 꼴이 닮아 끌립니다. 하지만 그 말은 되풀이나 시간이 지목의 옳고 그름에 영향을 주지 않는다는 뜻입니다. 지목 절차와 확신이 상관없다는 말은 지문에 없습니다. 꼴만 빌려 온 선택지입니다."),
  ("대체로 지목 뒤에 일어난 일들의 산물", "which 앞의 «their confidence has been shaped by everything that happened since»가 근거입니다. 확신은 되풀이, 맞다는 반응, 시간으로 올라가는데 이것들은 모두 지목 뒤의 일이고 정확성과는 상관이 없습니다. 'shaped by'가 'a product of'로, 'everything that happened since'가 'events after the identification'으로 바뀌었습니다."),
  ("목격자가 그 장면을 얼마나 잘 떠올리는지에 따라 정해지는", "가장 끌리는 선택지입니다. 확신이 크면 기억이 또렷하다는 상식과 맞습니다. 하지만 그것이 글이 흔드는 생각입니다. 나중에 잰 확신은 정확성과 거의 맞지 않는다고 했습니다. 확신을 올리는 것은 되풀이와 반응과 시간이지, 장면을 잘 떠올리느냐가 아닙니다.")])

# ---------- 27번째: 재입원율만으로 질을 재려면 '피한 재입원은 모두 좋은 것'이라고 가정해야 한다 ----------
mk(26, 1, [
 "1) 빈칸 문장: 'this figure alone'(이 수치만으로)과 'requires assuming'(~라고 가정해야 한다)이 있습니다. alone은 「그것만으로는 모자라다」는 신호입니다. 그러니 빈칸에는 글쓴이가 받아들이지 않는 가정이 들어갑니다. 글의 내용을 뒤집은 말이 답이 되는, 방향을 뒤집는 빈칸입니다.",
 "2) 편 정하기: 글쓴이의 생각은 둘째 문장에 있습니다. 이 척도는 돌아온 환자를 세는데 «it counts them regardless of why they returned»(왜 돌아왔는지와 상관없이 센다). 예정된 둘째 시술 때문에 돌아온 환자와 첫 시술이 실패해서 돌아온 환자를 똑같이 셉니다.",
 "3) 짝꿍 문장: 다섯째 문장입니다. 재입원율을 낮춘 사업은 더 나은 관리 덕일 수도 있고 «outcomes that no one intended to encourage»(아무도 부추기려 하지 않았던 결과) 때문일 수도 있는데, «the measure does not separate them»(그 척도는 그것들을 가르지 못한다). 넷째 문장의 보기처럼, 퇴원 뒤 곧 숨지는 환자가 많은 병원도 재입원이 적습니다.",
 "4) 묶기: 글의 말은 「줄어든 재입원에는 좋은 것도 나쁜 것도 섞여 있다」입니다. 이것을 뒤집으면 「줄어든 재입원은 하나하나가 다 좋은 것이다」 = 'every avoided readmission represents a patient helped'(피한 재입원 하나하나가 도움받은 환자 한 사람을 뜻한다). every(하나도 빠짐없이)가 'does not separate'(가르지 못한다)를 뒤집은 낱말입니다."],
 "나머지 선택지는 모두 「수치를 바르게 세려면 필요한 가정」입니다(기록 기준이 같다, 기간이 알맞다, 환자 집단이 그대로다, 같은 병원으로 돌아온다). 연구 방법의 상식으로는 다 그럴듯합니다. 하지만 글이 문제 삼는 것은 세는 방법이 아닙니다. 바르게 세어도 그 수가 좋은 치료를 뜻하지 않는다는 것입니다. 특히 「환자 집단이 달라지지 않는다」는 여섯째 문장의 populations와 닮아 끌리지만, 글이 말한 것은 병원마다 환자가 다르다는 것이지 시간이 지나며 달라진다는 것이 아닙니다.",
 [("병원들이 같은 기준으로 재입원을 기록한다는 것", "수치를 견주려면 기준이 같아야 한다는 상식으로 고르기 쉽습니다. 하지만 글은 병원마다 기록 기준이 다르다고 하지 않았습니다. 기준이 같아도 문제는 남습니다. 왜 돌아왔는지를 가리지 않고 세기 때문입니다. 지문에 없는 이야기입니다."),
  ("피한 재입원 하나하나가 도움받은 환자 한 사람을 뜻한다는 것", "다섯째 문장 «the measure does not separate them»이 근거입니다. 재입원이 줄어든 까닭에는 더 나은 관리도 있고 아무도 바라지 않은 결과도 있는데, 척도는 이를 가르지 못합니다. 그런데도 이 수치만으로 질을 재려면, 줄어든 재입원이 모두 좋은 것이라고 가정해야 합니다. 글의 내용을 뒤집은 말이 답입니다."),
  ("고른 기간이 회복 과정과 맞는다는 것", "'a specified window'(정해진 기간)가 지문에 있어 끌립니다. 하지만 그 기간이 알맞은지는 글이 따지지 않았습니다. 기간을 아무리 잘 잡아도 환자가 왜 돌아왔는지는 가려지지 않습니다. 낱말만 빌려 온 선택지입니다."),
  ("맡은 환자 집단이 시간이 지나도 달라지지 않는다는 것", "여섯째 문장의 'the sickest populations'(가장 아픈 환자 집단)와 첫 문장의 'before and after'(앞과 뒤)에서 끌립니다. 하지만 글이 말한 것은 병원마다 환자가 다르다는 것입니다. 한 병원의 환자가 시간이 지나며 달라진다는 이야기는 지문에 없습니다."),
  ("환자들이 치료받았던 바로 그 병원으로 돌아온다는 것", "return(돌아오다)이 지문 낱말이고, 다른 병원으로 가면 세어지지 않는다는 생각이 그럴듯해 끌립니다. 하지만 환자가 어느 병원으로 돌아오는지는 지문에 없는 이야기입니다. 글의 문제는 어디로 돌아왔느냐가 아니라 왜 돌아왔느냐입니다.")])

# ---------- 28번째: 까다로운 개정 절차가 지키는 것은 글자이지 그 글자가 세우는 짜임이 아니다 ----------
mk(27, 2, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론입니다. 주어는 «The protection afforded by a difficult amendment process»(까다로운 개정 절차가 주는 보호)이고 동사는 covers(~을 감싼다, 지켜 준다)입니다. 그 보호가 정말로 지켜 주는 것이 무엇인지를 묻습니다.",
 "2) 꺾이는 곳: 셋째 문장입니다. 첫 문장은 절차를 어렵게 만든 까닭을 말했습니다. «fundamental arrangements should not shift with temporary opinion»(근본이 되는 짜임이 한때의 여론에 따라 바뀌어서는 안 된다). 셋째 문장이 이것을 꺾습니다. «The reasoning applies to formal amendment and not to the whole of constitutional change.»(그 논리는 정식 개정에는 들어맞지만, 헌법이 바뀌는 일 전체에는 들어맞지 않는다.)",
 "3) 짝꿍 문장: 넷째 문장입니다. «Courts interpreting a text alter what it requires without altering a word»(본문을 해석하는 법원은 한 낱말도 바꾸지 않으면서 그것이 요구하는 바를 바꾼다). 글자는 그대로이고 내용이 바뀝니다. 그리고 «no step triggers the heightened procedure»(어느 걸음도 그 높은 절차를 건드리지 않는다).",
 "4) 묶기: 'without altering a word'(한 낱말도 바꾸지 않고) = 'the text'(글자)는 지켜진다. 'what it requires'(그것이 요구하는 바), 'the effective constitution'(실제로 통하는 헌법), 첫 문장의 'fundamental arrangements' = 'the arrangements it establishes'(그 글이 세우는 짜임)는 지켜지지 않는다. 지키려던 것은 짜임이었는데 지켜지는 것은 글자뿐입니다."],
 "「법원이 아니라 의회가 내놓은 변화」가 가장 위험합니다. 뒷부분('rather than by courts')은 지문과 맞습니다. 법원의 해석은 개정 절차를 거치지 않습니다. 하지만 의회는 지문에 한 번도 나오지 않습니다. 그리고 글이 가른 것은 누가 바꾸느냐가 아니라 무엇이 바뀌느냐입니다. 글자냐, 그 글자가 요구하는 바냐입니다. 첫 문장의 arrangements가 끝에서 돌아온다는 점도 답을 가리킵니다.",
 [("헌법을 만든 이들이 내다본 것보다 훨씬 짧은 기간", "'two decades'(스무 해), temporary(한때의) 같은 말에서 기간을 떠올리면 끌립니다. 하지만 빈칸은 보호가 얼마 동안 이어지는지가 아니라 무엇을 지켜 주는지를 묻습니다. 만든 이들이 무엇을 내다보았는지는 지문에 없는 이야기입니다."),
  ("헌법을 세운 이들이 미리 내다본 문제들만", "헌법은 만든 이들이 생각하지 못한 문제를 만난다는 상식으로 고르기 쉽습니다. 하지만 세운 이들이 무엇을 내다보았는지는 지문에 없습니다. 글이 말하는 것은 새 문제가 아니라, 글자를 그대로 둔 채 해석으로 내용이 바뀌는 일입니다."),
  ("그 글이 세우는 짜임이 아니라 글자", "넷째 문장 «Courts interpreting a text alter what it requires without altering a word»가 근거입니다. 개정 절차는 글자를 바꾸는 일만 막습니다. 해석은 글자를 건드리지 않으므로 그 절차에 걸리지 않습니다. 'a word'가 'the text'로, 'what it requires'와 첫 문장의 'fundamental arrangements'가 'the arrangements it establishes'로 바뀌었습니다."),
  ("법원이 아니라 의회가 내놓은 변화", "가장 끌리는 선택지입니다. 법원의 해석이 개정 절차를 거치지 않는다는 점에서 뒷부분은 지문과 맞습니다. 하지만 의회는 지문에 나오지 않습니다. 글이 가른 것은 누가 바꾸느냐가 아니라 무엇이 바뀌느냐입니다. 글자('a word')냐, 그것이 요구하는 바('what it requires')냐입니다."),
  ("분명한 말로 적힌 조항", "text, word와 통하는 말이라 끌립니다. 하지만 글은 법원이 글자를 바꾸지 않고도 그 글자가 요구하는 바를 바꾼다고 했습니다. 분명하게 적힌 조항도 해석으로 달라질 수 있습니다. 분명하게 적혔는지에 따라 가르는 이야기는 지문에 없습니다.")])

# ---------- 29번째: 씨앗을 부수는 것은 빠르기가 아니라 무게 ----------
mk(28, 2, [
 "1) 빈칸 문장: accordingly(그래서)와 because(~이기 때문에)가 있습니다. 빈칸은 까닭 자리입니다. 방앗간 주인들이 가장 무거운 돌을 고르고 느린 회전을 받아들인 까닭, 곧 'what breaks the seed'(씨앗을 부수는 것)가 무엇인지를 묻습니다.",
 "2) 짝꿍 문장: 첫 문장입니다. 처음과 끝이 이어지는 글입니다. «the work is done by mass rather than by motion»(일은 움직임이 아니라 무게가 한다). 'A rather than B' 틀이고, 남는 쪽은 mass(무게), 버리는 쪽은 motion(움직임)입니다.",
 "3) 되풀이: 「빠르기는 상관없다」가 두 번 나옵니다. «nothing about the crushing depends on speed»(으깨는 일의 어느 것도 빠르기에 달려 있지 않다) → «A faster circuit grinds no more seed»(더 빨리 돌아도 씨앗을 더 갈지 못한다). 그래서 주인들은 «chose the heaviest stone the yoke could move»(멍에가 움직일 수 있는 가장 무거운 돌을 골랐다).",
 "4) 묶기: mass(무게), 'the heaviest stone'(가장 무거운 돌) = 'weight'(무게). crushes, 'the crushing'(으깨는 일) = 'does the crushing'(으깨는 일을 한다). 버리는 쪽은 motion, speed, circuit입니다. 빠르기와 거리를 말하는 선택지는 모두 이쪽입니다."],
 "「바퀴가 한 시간에 가는 거리」가 가장 위험합니다. speed라는 낱말이 없어서 다른 이야기처럼 보이지만, 한 시간에 가는 거리는 빠르기를 다르게 말한 것입니다. 글이 'rather than by motion'으로 버린 쪽입니다. 「돌 아래의 바닥」은 첫 문장의 'what lies beneath it'(그 아래 놓인 것)에서 낱말을 빌려 왔습니다. 아래에 있는 것은 으깨어지는 쪽이지 으깨는 쪽이 아닙니다.",
 [("그것을 끌도록 고른 동물", "ox, animal이 지문에 있어 끌립니다. 하지만 글은 천천히 걷는 소가 «produces the same result as a faster animal»(더 빠른 동물과 같은 결과를 낸다)이라고 했습니다. 어떤 동물이 끄는지는 결과를 바꾸지 않습니다. 낱말만 빌려 온 선택지입니다."),
  ("바퀴가 한 시간에 가는 거리", "가장 조심할 선택지입니다. 한 시간에 가는 거리는 빠르기를 다르게 말한 것입니다. speed라는 낱말을 피했을 뿐, 첫 문장이 'rather than by motion'으로 버린 쪽입니다. 글은 더 빨리 돌아도 씨앗을 더 갈지 못한다고 했습니다."),
  ("으깨는 일을 하는 무게", "첫 문장 «the work is done by mass rather than by motion»이 근거입니다. 빠르기는 상관없고 무게가 일을 하므로, 주인들은 가장 무거운 돌을 고르고 느린 회전을 받아들였습니다. mass와 'the heaviest stone'이 'weight'로 바뀌었습니다. 첫 문장의 말이 끝 문장 빈칸으로 돌아옵니다."),
  ("바퀴가 도는 빠르기", "방향이 거꾸로입니다. speed가 지문 낱말이라 눈에 띄지만, 글은 «nothing about the crushing depends on speed»(으깨는 일의 어느 것도 빠르기에 달려 있지 않다)라고 했습니다. 주인들이 느린 회전을 받아들인 까닭을 묻는 자리에 빠르기가 올 수 없습니다."),
  ("돌 아래의 바닥", "첫 문장의 'what lies beneath it'(그 아래 놓인 것)과 bed(받침)에서 낱말을 빌려 왔습니다. 하지만 돌 아래에 있는 것은 으깨어지는 쪽입니다. 으깨는 쪽은 돌의 무게입니다. 바닥이 씨앗을 부순다는 말은 지문에 없습니다.")])

# ---------- 30번째: 안전등의 전부는 불꽃을 둘레와 갈라 놓은 것 ----------
mk(29, 3, [
 "1) 빈칸 문장: therefore(따라서)가 있는 결론이고, 빈칸은 'the whole invention consists of'(그 발명의 전부는 ~이다) 뒤에 있습니다. 안전등이라는 발명의 알맹이가 무엇인지를 한 줄로 묻습니다.",
 "2) 편 정하기: 첫 문장이 아닌 것부터 지워 줍니다. 안전등은 «did not prevent explosions by burning cooler or by giving less light»(더 차갑게 타거나 빛을 덜 내서 폭발을 막은 것이 아니다). 불꽃 자체는 그대로입니다. «It burned as an open flame burns»(그것은 열린 불꽃이 타듯이 탔다). 불꽃을 바꾼 발명이 아닙니다.",
 "3) 짝꿍 문장: 셋째 문장입니다. 철망 덕분에 «the gas outside never reaches its ignition point, while the gas that enters burns harmlessly within»(바깥의 가스는 불붙는 온도에 이르지 못하고, 안으로 들어온 가스는 안에서 탈 없이 탄다). 철망이 불꽃의 안과 밖을 갈라 놓습니다.",
 "4) 묶기: 'A cylinder of fine wire gauze around the flame'(불꽃을 둘러싼 촘촘한 철망 통) = 'kept from'(~에서 떼어 놓은). 'the gas outside'(바깥의 가스), 'an atmosphere'(둘레의 공기) = 'what surrounds it'(그것을 둘러싼 것). 불꽃은 그대로 두고 둘레와 갈라 놓았을 뿐입니다."],
 "flame이 들어 있는 다른 선택지(꺼뜨릴 수 없는 불꽃)가 위험합니다. 안전등이라는 이름에서 「꺼지지 않는 등」을 떠올리기 쉽습니다. 하지만 글이 말하는 위험은 불이 꺼지는 것이 아니라 불이 바깥 가스에 옮겨 붙는 것입니다. 「일할 수 있을 만큼 밝은 빛」은 방향이 거꾸로입니다. 안전등은 열린 불꽃보다 빛을 덜 냈습니다.",
 [("한 번 일하는 동안 내내 타는 등", "광부가 일하는 동안 쓰는 등이라는 상식으로 고르기 쉽습니다. 하지만 등이 얼마나 오래 타는지는 지문에 없는 이야기입니다. 글이 설명하는 것은 타는 시간이 아니라 폭발을 막는 원리입니다."),
  ("어느 광부나 고칠 수 있는 설계", "'a dented gauze'(찌그러진 철망)에서 고쳐 쓴다는 것을 떠올리면 끌립니다. 하지만 글은 철망이 찌그러진 등이 등이 없는 것보다 더 위험하다고 했을 뿐입니다. 고치는 이야기는 지문에 없습니다."),
  ("꺼뜨릴 수 없는 불꽃", "flame이 지문 낱말이고, 안전등이라는 이름에서 꺼지지 않는 불을 떠올리기 쉬워 끌립니다. 하지만 글이 말하는 위험은 불이 꺼지는 것이 아닙니다. 불이 바깥 가스에 옮겨 붙는 것입니다. 꺼지느냐 마느냐는 지문에 없는 이야기입니다."),
  ("둘레의 것에서 떼어 놓은 불꽃", "셋째 문장 «the gas outside never reaches its ignition point, while the gas that enters burns harmlessly within»이 근거입니다. 불꽃은 열린 불꽃과 똑같이 타는데, 철망이 그 불꽃을 바깥 가스와 갈라 놓습니다. 'the gas outside'와 'an atmosphere'가 'what surrounds it'으로 묶였습니다."),
  ("일할 수 있을 만큼 밝은 빛", "방향이 거꾸로입니다. 등이니 밝아야 한다는 상식으로 고르기 쉽습니다. 하지만 글은 안전등이 열린 불꽃보다 빛을 덜 냈다(«gave rather less light than one»)고 했습니다. 밝기는 이 발명의 알맹이가 아닙니다.")])
