# -*- coding: utf-8 -*-
# 38-39번(문장 삽입) 두텁게 — 자체 엄격 검사 (220번에 다시 만듦)   python3 zcheck3839.py [레벨, 기본 8]
import re, sys, statistics as st; sys.path.insert(0, '.')
from lib import *
from lowstyle import has_nida
from z5common import seg, CIRC, JOSA, HEADS, low, ending, cnhead, TIP, TIP3
LV = sys.argv[1] if len(sys.argv) > 1 else '8'
KO_ONLY = {('4', 7), ('4', 11), ('4', 17), ('4', 20)}   # 276번: 본문 해석만 바로잡은 문항
ITEM_FIX = {('8', n) for n in (3, 5, 6, 8, 11, 13, 15, 16, 17, 20, 21, 24, 25, 26, 27, 28)} | {('7', n) for n in (1, 2, 7, 10, 11, 16, 18, 22, 23, 26, 27)} | {('6', n) for n in (1, 2, 3, 8, 11, 14, 16, 21, 24, 25)} | {('4', 1), ('4', 29)} | {('3', n) for n in (0, 1, 3, 4, 5, 6, 7, 8, 9, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29)} | {('5', n) for n in (0, 1, 2, 3, 4, 7, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 19, 20, 22, 26)}   # 지문을 고친 문항(인계문서에 적은 것만): (레벨, 몇째-1) — 220번: 4·6·7·9 / 221번: 12·14·16·17·18 / 222번: 21·22·25·26·27·28·29번째
s, tb, te = load('out/index.html'); s0, tb0, te0 = load()
T = '38_39'; done = 0; soft = []; wl = []; cl = []
OKW = set('but yet and or so not if'.split())
for n in range(30):
    it = tb[T][LV][n]; ex = te[T][LV][n]; P = it['text']; a = it['answer']; w = ex['walk']
    if '【이 문제에 적용】' not in w: continue
    done += 1; ins, S = seg(P)
    for tx in [w] + ex['cn']:
        assert '«' not in tx and '»' not in tx, (n, '꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"') % 2 == 0, (n, line)
            for q in re.findall(r'"([^"]*)"', line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"' % (n + 1, q))
                if len(q) < 12: print('!! 짧은 큰따옴표: %d번째 "%s"' % (n + 1, q))
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])", tx):
            if re.search(r'[가-힣]', q) or not re.search(r'[A-Za-z]{3,}', q): continue
            if any(p.strip(' .,').lower() not in P.lower() for p in re.split(r'…|\.\.\.', q) if p.strip(' .,')): soft.append((n + 1, q))
        tx2 = tx.split('【이 문제에 적용】')[-1]   # 공통 요령 네 줄에 든 this·however 따위는 보지 않음
        plain = re.sub(r'"[^"]*"', '', tx2); plain = re.sub(r"'[^'\n]*'", '', plain)
        for wd in set(re.findall(r'[A-Za-z]{3,}', plain)):
            if wd.lower() not in P.lower() and wd.lower() not in OKW: print('!! %d번째: 따옴표 없는 영어 낱말 %s — 지문에 없음' % (n + 1, wd))
    body = w.split('【이 문제에 적용】')[1]
    assert w.startswith('【문장 삽입 요령】') and w.count('【') == 3 and '【헷갈리는 곳】' in w, (n, '세 단락 꼴')
    assert all(('\n' + h) in w for h in HEADS), (n, '적용 꼴')
    ans = re.findall(r'([①②③④⑤])(?:이|가) ' + ending(LV)[:-1], w); assert ans == [CIRC[a]], (n, '풀이가 말한 답', ans)
    assert w.startswith(TIP3 if low(LV) else TIP), (n, '요령의 말끝이 레벨과 다름')
    if low(LV): assert not has_nida(w.split('【이 문제에 적용】')[1]) and not any(has_nida(c) for c in ex['cn']), (n, '레벨1~3인데 「~니다」 말끝')
    assert '정답' not in body, (n, '풀이에 정답이라는 말')
    for k in range(5):
        head = CIRC[k] + cnhead(LV, k == a)
        assert ex['cn'][k].startswith(head), (n, k, '머리말'); assert ex['cn'][k].count('정답') == (1 if k == a else 0), (n, k)
        assert not re.search('[①②③④⑤]', ex['cn'][k][1:]), (n, k, '자리 해설에 다른 번호')
        # 자리 해설이 「앞 문장의 X」「뒤 문장의 X」「삽입 문장의 X」라고 지목한 영어가 실제로 그 문장에 있는지
        for who, wd in re.findall(r"(앞 문장|뒤 문장|삽입 문장)의 '([^'\n]+)'", ex['cn'][k]):
            src = {'앞 문장': S[k], '뒤 문장': S[k + 1], '삽입 문장': ins}[who]
            if any(p.strip(' .,').lower() not in src.lower() for p in re.split(r'…', wd) if p.strip(' .,')): soft.append((n + 1, '%s번 해설: %s의 %s — 그 문장에 없음' % (CIRC[k], who, wd)))
    # 풀이의 「삽입 문장의 X」
    for wd in re.findall(r"삽입 문장의 '([^'\n]+)'", w):
        if any(p.strip(' .,').lower() not in ins.lower() for p in re.split(r'…', wd) if p.strip(' .,')): soft.append((n + 1, '풀이: 삽입 문장의 %s — 삽입 문장에 없음' % wd))
    b0 = tb0[T][LV][n]
    if (LV, n) in ITEM_FIX: assert it['answer'] == b0['answer'] and it['choices'] == b0['choices'], (n, '정답·선택지 변동')
    else: assert it == b0 and ex['ko'] == te0[T][LV][n]['ko'], (n, '문항·해석 변동')
    wl.append(len(w)); cl += [len(c) for c in ex['cn']]
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']:
        e1 = dict(te[T][LV][n]); e0 = dict(te0[T][LV][n])
        if (LV, n) in KO_ONLY: e1['ko'] = e0['ko'] = ''   # 해석만 바로잡은 문항(인계문서에 적은 것만)
        assert tb[T][LV][n] == tb0[T][LV][n] and e1 == e0, (n, '안 쓴 문항이 바뀜')
print('두텁게 쓴 문항:', done, '/ 30')
if wl: print('풀이 평균 %d자(최소 %d, 최대 %d) / 자리별 해설 평균 %d자(최소 %d, 최대 %d)' % (st.mean(wl), min(wl), max(wl), st.mean(cl), min(cl), max(cl)))
for x in soft: print('  눈으로 볼 것: %d번째 %s' % x)
