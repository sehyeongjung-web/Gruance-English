# -*- coding: utf-8 -*-
# 41번(장문 — 제목) 레벨9 해설 두텁게 — 공통 도우미 (199번~)
#   mk = maker(E)
#   mk(n, 정답 자리(0~4), [적용 네 줄], 끌리는 오답, [(제목 해석, 까닭) × 5])
# - 23번(주제) 때의 꼴을 장문 제목에 맞춘 것: 요령 네 줄이 장문 제목용, 적용 줄 머리말은 「1) 되풀이: / 2) 꺾이는 곳: / 3) 끝 문장: / 4) 묶기:」
# - 선택지 영어(제목)는 문항에서 자동으로 가져오고, 정답 자리에는 "정답입니다."를 붙임
# - 원고의 «…»는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜
import sys; sys.path.insert(0, '.')
from lib import load as _load
_tb = _load()[1]
TIP = ("【장문 제목 요령】\n"
       "첫째, 글이 길어도 찾을 것은 하나, 글 전체를 꿰는 생각입니다. 같은 생각이 모양만 바꿔 되풀이되는 곳을 찾습니다.\n"
       "둘째, 흐름이 꺾이는 말(but, yet, not A but B, What makes … unusual) 뒤가 글쓴이의 생각입니다. 긴 글은 앞쪽이 바탕 이야기이고 가운데에서 꺾이는 일이 많습니다.\n"
       "셋째, 끝 문장까지 읽습니다. 긴 글은 끝에서 글 전체를 한 줄로 못 박는 일이 많습니다.\n"
       "넷째, 제목은 그 생각을 짧게 바꿔 말한 것입니다. 글의 한 대목만 담은 제목, 글보다 넓은 제목, 글이 하지 않은 센 주장(must, should, never, entirely)을 담은 제목, 지문에 없는 이야기를 담은 제목을 버립니다.")
HEADS = ('1) 되풀이:', '2) 꺾이는 곳:', '3) 끝 문장:', '4) 묶기:')
def _q(x): return x.replace('«', '"').replace('»', '"')
def W(steps, traps):
    return TIP + "\n\n【이 문제에 적용】\n" + "\n".join(steps) + "\n\n【끌리는 오답】\n" + traps
def maker(E, t='41', lv='9'):
    def mk(n, ans, steps, traps, cn, ch=None):
        # ch: 같은 수정안에서 오답 제목을 바꾸는 문항이면 {자리: '새 제목'}
        it = dict(_tb[t][lv][n]); it['choices'] = list(it['choices'])
        for kk, vv in (ch or {}).items():
            assert kk != ans, (n, '정답 제목은 바꾸지 않음'); it['choices'][kk] = vv
        assert it['answer'] == ans, ('원고의 정답 자리가 문항과 다름', t, n, it['answer'], ans)
        assert len(cn) == 5 and len(steps) == 4, (n, '개수')
        assert all(s.startswith(h) for s, h in zip(steps, HEADS)), (n, '적용 줄의 머리말')
        out = {}
        for k, (ko, why) in enumerate(cn):
            assert '정답' not in why and '정답' not in ko, (n, k, '까닭에 "정답"이라는 말')
            out[k] = ("정답입니다. " if k == ans else "") + "'%s' (%s) — %s" % (it['choices'][k], ko, _q(why))
        assert (t, lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(t, lv, n)] = {'walk': W([_q(x) for x in steps], _q(traps)), 'cn': out}
        if ch: E[(t, lv, n)]['ch'] = dict(ch)
    return mk
