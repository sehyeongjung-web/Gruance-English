# -*- coding: utf-8 -*-
# 43번(글의 순서) 레벨1 원고 도구 — 36-37번 z3637draft.py를 (B)(C)(D)로 옮긴 것 (368번)
#   python3 z43draft.py match <원고 모듈 경로(.py 빼고)>
#     원고 모듈: I[n] = dict(g=…, P={'B': […], 'C': […], 'D': […]}, locks=…) · 정답 차례는 draft/plan85.txt
#   「낱말만 맞추는 학생」이 고를 순서: 통째(앞 글 전체와 뒤 글 전체가 겹치는 낱말) / 맞물림(앞 글의 끝 문장과 뒤 글의 첫 문장이 겹치는 낱말)
#   다섯 선택지(B-C-D는 선택지에 없음) 가운데 점수가 혼자 가장 높은 것이 답과 같으면 「낱말 맞추기로 풀림」
import sys, re, os, importlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from z3637draft import words
CH = ['BDC', 'CBD', 'CDB', 'DBC', 'DCB']
def lay(g, P): return g + "\n\n" + "\n".join("(%s) %s" % (k, " ".join(P[k])) for k in 'BCD')
def score(g, P, o, whole):
    seq = [[g]] + [P[k] for k in o]; t = 0
    for a, b in zip(seq, seq[1:]):
        t += len(words(' '.join(a)) & words(' '.join(b))) if whole else len(words(a[-1]) & words(b[0]))
    return t
def plan_orders():
    R = {}
    for l in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'draft/plan85.txt'), encoding='utf-8'):
        if l.strip() and not l.startswith('#'): a = l.split('|')[0].split(); R[int(a[0])] = a[2]
    return R
def match(mod):
    d, name = os.path.split(mod)
    if d: sys.path.insert(0, d)
    M = importlib.import_module(name); OR = plan_orders(); texts = {}; w1 = w2 = 0; firstfail = 0
    for n, it in sorted(M.I.items()):
        g, P, a = it['g'], it['P'], OR[n]; res = []
        for whole in (True, False):
            sc = [score(g, P, o, whole) for o in CH]; m = max(sc); top = [CH[i] for i in range(5) if sc[i] == m]
            res.append((sc, top))
        u1 = res[0][1] == [a]; u2 = res[1][1] == [a]; w1 += u1; w2 += u2
        first = max('BCD', key=lambda k: len(words(g) & words(' '.join(P[k]))))
        firstfail += (first != a[0])
        texts[n] = (lay(g, P), '(%s)-(%s)-(%s)' % tuple(a))
    N = len(M.I)
    print('낱말 맞추기만으로 답이 혼자 나오는 문항: 통째 %d/%d · 맞물림 %d/%d · 주어진 글과 가장 많이 겹치는 글이 정답 첫 덩이가 아닌 문항 %d/%d  (선택지 차례: %s)' % (w1, N, w2, N, firstfail, N, ' '.join(CH)))
if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == 'match': match(a[1])
    else: print('쓰는 법은 파일 머리의 주석을 볼 것')
