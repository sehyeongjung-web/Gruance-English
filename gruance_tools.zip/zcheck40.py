# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨9 두텁게 — 자체 엄격 검사 (zcheck31.py를 40번 꼴에 맞춘 것)
#   python3 zcheck40.py
# 다른 점: 머리말이 【요약문 완성 요령】, 적용 줄이 「1) 요약문: / 2) (A) 찾기: / 3) (B) 찾기: / 4) 묶기:」,
#          「몇째 문장」 자리는 요약문을 뺀 지문에서 셈(지문과 요약문은 빈 줄로 나뉨)
import re, sys; sys.path.insert(0, '.')
from lib import *
T = sys.argv[1] if len(sys.argv) > 1 else '40'
LV = sys.argv[2] if len(sys.argv) > 2 else '9'   # 232번: 레벨 인자 — python3 zcheck40.py 40 8
s, tb, te = load('out/index.html'); s0, tb0, te0 = load()
KO_FIX = {}
ITEM_FIX9 = {('40', 0), ('40', 6), ('40', 13), ('40', 14), ('40', 19), ('40', 20), ('40', 23)}   # 196번: 1·7번째 / 197번: 14·15·20번째 / 198번: 21·24번째 — 넣어 읽으면 말이 깨지던 오답의 꼴, 답으로도 읽히던 오답의 한쪽
ITEM_FIX8 = {('40', 0), ('40', 6), ('40', 12), ('40', 18), ('40', 26), ('40', 29)}   # 레벨8에서 지문·오답을 고친 문항(인계문서에 적은 것만)
ITEM_FIX7 = {('40', 23), ('40', 27)}   # 레벨7에서 지문·선택지를 고친 문항(인계문서에 적은 것만)
ITEM_FIX6 = {('40', k) for k in (3, 5, 7, 8, 9, 10, 11, 12, 14, 15, 16, 23, 26, 27)}   # 261번: 레벨6 검토에서 고친 문항
ITEM_FIX5 = {('40', k) for k in (5, 9, 15, 16, 23, 26, 27)}   # 272번: 레벨5 검토에서 고친 문항
ITEM_FIX = {'9': ITEM_FIX9, '8': ITEM_FIX8, '7': ITEM_FIX7, '6': ITEM_FIX6, '5': ITEM_FIX5}.get(LV, set())
ANS_FIX9 = {('40', 23): 'rhythm - brightness'}   # 200번: 선생님 승인("이것도 수정해") — 24번째 정답 문구 'identity - brightness' → 'rhythm - brightness'
ANS_FIX8 = {('40', 0): 'consolidating - invisible', ('40', 12): 'less - paywalls'}   # 232번: 레벨8 1번째 — 정답의 (B) weaker가 지문의 'invisible at the time'과 맞지 않아 고침
ANS_FIX7 = {}
ANS_FIX6 = {('40', 7): 'turnover - capacity', ('40', 9): 'finishing - borrowed', ('40', 10): 'queuing - kitchen', ('40', 23): 'reliability - speed'}   # 261번
ANS_FIX5 = {('40', 16): 'first - ignore'}   # 272번
ANS_FIX = {'9': ANS_FIX9, '8': ANS_FIX8, '6': ANS_FIX6, '5': ANS_FIX5}.get(LV, ANS_FIX7 if LV == '7' else {})
FRAMES = ('not A but B', 'A rather than B', 'less A than B', 'X over Y')   # 틀을 가리키는 말(지문에 없어도 됨)
ORD = {'첫': 1, '둘째': 2, '셋째': 3, '넷째': 4, '다섯째': 5, '여섯째': 6, '일곱째': 7, '여덟째': 8}
MINOR = {('6', '40', 29), ('5', '40', 3), ('5', '40', 6)}   # 261번: 30번째 — 'raked weekly'를 「갈아 준」으로 옮긴 것을 「갈퀴로 골라 준」으로(해석·풀이·해설)
done = 0; soft = []; bare = []; lens_w = []; lens_c = []
for n in range(30):
    it = tb[T][LV][n]; ex = te[T][LV][n]; P = it['text']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done += 1; lens_w.append(len(ex['walk'])); lens_c += [len(c) for c in ex['cn']]
    src = (P + ' || ' + ' || '.join(it['choices'])).lower()
    assert P.count('\n\n') == 1 and '(A) ______' in P.split('\n\n')[1] and '(B) ______' in P.split('\n\n')[1], (n, '지문/요약문 꼴')
    sents = re.split(r'(?<=[.?]) ', P.split('\n\n')[0])
    for tx in [ex['walk']] + ex['cn']:
        assert '«' not in tx and '»' not in tx, (n, '꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"') % 2 == 0, (n, line)
            for q in re.findall(r'"([^"]*)"', line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"' % (n + 1, q))
                if len(q) < 12: print('!! 짧은 큰따옴표: %d번째 "%s"' % (n + 1, q))
        # 작은따옴표 속 영어가 지문·선택지 어디에도 없으면 눈으로 볼 목록에(틀은 빼고)
        body = tx
        for c in it['choices']: body = body.replace("'" + c + "'", '')
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])", body):
            if re.search(r'[가-힣]', q) or not re.search(r'[A-Za-z]{3,}', q): continue
            if any(f in q for f in FRAMES) or re.search(r'\b[AB]\b', q): continue
            parts = [p.strip() for p in re.split(r'…', q) if p.strip()]
            if not all(p.lower().strip('.,') in src for p in parts): soft.append((n + 1, q))
        # 따옴표 없이 쓴 영어 낱말(4자 이상)이 지문에 없으면 목록에: 「지문에 없는 말」이라고 한 것만 남아야 함
        plain = re.sub(r'"[^"]*"|\'[^\'\n]*\'', ' ', body.split('【이 문제에 적용】')[-1])   # 요령 네 줄(공통)은 빼고 봄
        for w in set(re.findall(r'[A-Za-z]{4,}', plain)):
            if w.lower() not in P.lower(): bare.append((n + 1, w, w.lower() in src))
        # "몇째 문장"이라고 한 자리 뒤에 바로 온 인용이 그 문장에 있는지
        for m in re.finditer(r'(첫|둘째|셋째|넷째|다섯째|여섯째|일곱째|여덟째) 문장[^.\n]{0,25}?[\'"]([^\'"\n]+)[\'"]', tx):
            k = ORD[m.group(1)]; q = m.group(2)
            if re.search(r'[A-Za-z]{3,}', q) and not any(f in q for f in FRAMES):
                ok = k <= len(sents) and all(p.strip().lower() in sents[k - 1].lower() for p in q.split('…') if p.strip())
                if not ok: print('!! 문장 자리 어긋남: %d번째 「%s 문장」 — %s' % (n + 1, m.group(1), q))
    for k, c in enumerate(it['choices']):
        assert ex['cn'][k].startswith(("정답입니다. " if k == it['answer'] else "") + "'" + c + "' ("), (n, k, '선택지 인용 꼴')
        assert ex['cn'][k].count('정답') == (1 if k == it['answer'] else 0), (n, k, '정답이라는 말')
    w = ex['walk']
    assert not re.search(r'[①②③④⑤]|\d번', w), (n, '풀이에 번호')
    assert '정답' not in w, (n, '풀이에 "정답"')
    assert w.startswith('【요약문 완성 요령】') and w.count('【') == 3 and '【끌리는 오답】' in w, (n, '세 단락 꼴')
    assert all(h in w for h in ('\n1) 요약문:', '\n2) (A) 찾기:', '\n3) (B) 찾기:', '\n4) 묶기:')) and '짝꿍 문장' in w.split('【이 문제에 적용】')[1], (n, '적용 꼴')
    b0 = tb0[T][LV][n]
    if (T, n) in ITEM_FIX:   # 지문·오답을 고친 문항(인계문서에 적은 것만): 정답 번호·정답 문구·발문은 그대로여야 함
        assert it['answer'] == b0['answer'] and it.get('q') == b0.get('q') and ((T, n) in ANS_FIX or it['choices'][it['answer']] == b0['choices'][b0['answer']]), (n, '정답 변동')
        if (T, n) in ANS_FIX: assert it['choices'][it['answer']] == ANS_FIX[(T, n)], (n, '승인 문구와 다름')
    else: assert it['text'] == b0['text'] and it['answer'] == b0['answer'] and it.get('q') == b0.get('q') and it['choices'] == b0['choices'], (n, '문항 변동')
    if (T, n) in ITEM_FIX and (T, n) not in KO_FIX: pass   # 지문을 늘린 문항은 해석도 함께 늘어남
    elif (T, n) in KO_FIX:   # 해석의 틀린 낱말 하나를 바로잡은 문항(인계문서에 적은 것만)
        a, b = KO_FIX[(T, n)]; assert te0[T][LV][n]['ko'].count(a) == 1 and ex['ko'] == te0[T][LV][n]['ko'].replace(a, b), (n, '해석 변동(허용한 것과 다름)')
    else: assert ex['ko'] == te0[T][LV][n]['ko'], (n, '해석 변동')
# 손대지 않은 문항은 바탕과 같아야 함
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']:
        if (LV, T, n) in MINOR: assert tb[T][LV][n] == tb0[T][LV][n], (n, '문항 변동'); continue   # 해석·해설의 낱말만 바로잡은 문항
        assert te[T][LV][n] == te0[T][LV][n] and tb[T][LV][n] == tb0[T][LV][n], (n, '안 쓴 문항이 바뀜')
print('두텁게 쓴 문항: %d / 30' % done)
if lens_w: print('풀이 평균 %d자(최소 %d, 최대 %d) / 선택지 해설 평균 %d자(최소 %d, 최대 %d)' % (sum(lens_w) / len(lens_w), min(lens_w), max(lens_w), sum(lens_c) / len(lens_c), min(lens_c), max(lens_c)))
for x in soft: print("  눈으로 볼 것(작은따옴표 영어가 지문·선택지에 없음): %d번째 '%s'" % x)
for x in sorted(set(bare)): print('  눈으로 볼 것(따옴표 없는 영어가 지문에 없음): %d번째 %s %s' % (x[0], x[1], '(선택지에는 있음)' if x[2] else '(선택지에도 없음)'))
