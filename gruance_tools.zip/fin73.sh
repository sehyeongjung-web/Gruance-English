#!/bin/bash
# 356번: 32번 레벨1(단문 · 정답 낱말이 글에 그대로 나오는 꼴) — 원고에서 수정안 만들기 → 조사 → 빌드 (바탕 52750ec 위에 X72만)
cd /home/claude/work
python3 draft/gen72.py a && python3 draft/gen72.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X72a.py pending/edits_X72b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X72a,edits_X72b out/index.html | tail -3
