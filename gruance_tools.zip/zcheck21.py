# 21번(함축 의미) 두텁게 — 자체 엄격 검사   python3 zcheck21.py [레벨, 기본 1]
# 36-37번 검사(zcheck3637.py)를 본떠, 밑줄 친 말이 풀이 1)에 있는지 · 풀이 4)가 정답 선택지를 말하는지 · 큰따옴표 인용이 지문에 있는지
# · 정답 번호 불변 · 손대지 않은 문항 불변 · 말끝 「~요」 · 선택지 길이 순위를 본다
import re, sys; sys.path.insert(0, '.')
from lib import *
from lowstyle import has_nida
LV = sys.argv[1] if len(sys.argv) > 1 else '1'
s, tb, te = load('out/index.html'); s0, tb0, te0 = load()
ITEM_FIX = {('1', n) for n in range(30)}
T = '21'; done = 0; soft = []; wl = []; cl = []; ranks = []
def plain(t): return re.sub(r'</?u>', '', t)
for n in range(30):
    it = tb[T][LV][n]; ex = te[T][LV][n]; P = plain(it['text']); a = it['answer']; ch = it['choices']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done += 1
    us = re.findall(r'<u>(.*?)</u>', it['text']); assert len(us) == 1, (n, '밑줄 하나')
    for tx in [ex['walk']] + ex['cn']:
        assert '«' not in tx and '»' not in tx, (n, '꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"') % 2 == 0, (n, line)
            for q in re.findall(r'"([^"]*)"', line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"' % (n + 1, q))
        t2 = tx.replace("school's", 'school§s')
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])", t2):
            if re.search(r'[가-힣]', q) or not re.search(r'[A-Za-z]{3,}', q): continue
            q = q.replace('§', "'")
            if q.lower().strip('.,') not in P.lower() and q not in ch: soft.append((n + 1, q))
    w = ex['walk']; walk4 = w.split('【이 문제에 적용】')[1]
    if LV in '123': assert not has_nida(walk4) and not any(has_nida(c) for c in ex['cn']), (n, '레벨1~3인데 「~니다」 말끝')
    assert not re.search(r'[①②③④⑤]|\d번', w), (n, '번호')
    assert w.count('【') == 3 and all(('\n%d) ' % i) in w for i in (1, 2, 3, 4)), (n, '꼴')
    assert ("'%s'" % us[0]) in w.split('\n1) ')[1].split('\n2) ')[0], (n, '풀이 1)에 밑줄 친 말')
    assert ("'%s'" % ch[a]) in w.split('\n4) ')[1].split('\n\n')[0], (n, '풀이 4)에 정답 선택지')
    assert w.split('\n4) ')[1].split('\n\n')[0].rstrip().endswith('예요.') or w.split('\n4) ')[1].split('\n\n')[0].rstrip().endswith('이에요.'), (n, '풀이 끝')
    gl = []
    for k, c in enumerate(ch):
        head = ("정답이에요! " if k == a else "") + "'" + c + "' ("
        assert ex['cn'][k].startswith(head), (n, k, '머리말')
        m = re.match(re.escape(head) + r'([^)]+)\) — ', ex['cn'][k]); assert m, (n, k, '우리말 풀이 괄호')
        assert ex['cn'][k].count('정답') == (1 if k == a else 0), (n, k, '정답이라는 말')
        for j, cj in enumerate(ch):
            if j != k and cj in ex['cn'][k]: print('!! %d번째 %d번 해설에 다른 선택지 문구가 있음: %s' % (n + 1, k + 1, cj))
    b0 = tb0[T][LV][n]
    assert it['answer'] == b0['answer'] and it.get('q') == b0.get('q'), (n, '정답·발문 변동')
    assert re.split(r'(?<=[.!?])\s+', plain(it['text'])) and len(re.findall(r'<u>', it['text'])) == 1
    L = [len(c) for c in ch]; ranks.append(sorted(L).index(len(ch[a])) + 1)
    assert not any(abs(len(c) - len(ch[a])) <= 1 for k, c in enumerate(ch) if k != a), (n, '정답과 길이가 한 글자 안팎인 오답')
    wl.append(len(w)); cl += [len(c) for c in ex['cn']]
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']:
        assert tb[T][LV][n] == tb0[T][LV][n] and te[T][LV][n] == te0[T][LV][n], (n, '안 쓴 문항이 바뀜')
print('두텁게 쓴 문항:', done, '/ 30')
import statistics as st
if done:
    w0 = [len(e['walk']) for e in te0[T][LV]]; c0 = [len(c) for e in te0[T][LV] for c in e['cn']]
    print('풀이 평균 %d자 → %d자 (최소 %d, 최대 %d) / 선택지 해설 평균 %d자 → %d자' % (st.mean(w0), st.mean(wl), min(wl), max(wl), st.mean(c0), st.mean(cl)))
    from collections import Counter
    print('정답 선택지의 길이 순위(1=가장 짧음):', sorted(Counter(ranks).items()))
for x in soft: print("  눈으로 볼 것: %d번째 '%s'" % x)
