# -*- coding: utf-8 -*-
# 314번: 25유형 × 레벨1~9를 「레벨 기준」(LEVEL_GUIDE.md = 측정기준표의 언어축)에 대어 재는 도구
#   levelgauge.py(307번)는 글자 모양으로 찾아서 지시어 that·전치사 after 따위를 잘못 걸었음 →
#   이 도구는 문장을 구문 분석(spaCy en_core_web_trf, 없으면 en_core_web_lg — lg는 짧은 문장에서 품사를 자주 틀림)해서 절의 종류를 가림. 그래도 틀릴 수 있으니 마지막은 읽어서 확인할 것.
# 준비: pip install spacy wordfreq cefrpy --break-system-packages
#       pip install --break-system-packages "spacy-curated-transformers>=0.3,<0.4"   (버전을 꼭 이렇게 — 최신판은 설치가 안 됨)
#       pip install --break-system-packages https://github.com/explosion/spacy-models/releases/download/en_core_web_trf-3.8.0/en_core_web_trf-3.8.0-py3-none-any.whl
# 쓰는 법: python3 levelgauge2.py            → 전 유형·전 레벨을 재서 gauge_all.json에 적음
#          python3 levelgauge2.py 35 4       → 그 칸의 문항별 값과 걸린 문장을 보여 줌
import re, sys, json, os, statistics as st
HERE = os.path.dirname(os.path.abspath(__file__))
_nlp = None
def nlp():
    global _nlp
    if _nlp is None:
        import spacy
        try: _nlp = spacy.load('en_core_web_trf', disable=['ner'])     # 더 정확함(314번에서 이것으로 잼)
        except Exception: _nlp = spacy.load('en_core_web_lg', disable=['ner'])
    return _nlp

# ── 낱말 목록 (wordlists.json: NGSL 2,800 · AWL 570족 · NAWL 963) ──
_WL = None
def wl():
    global _WL
    if _WL is None:
        d = json.load(open(os.path.join(HERE, 'wordlists.json'), encoding='utf-8'))
        _WL = {k: set(v) for k, v in d.items()}
    return _WL
try:
    from wordfreq import zipf_frequency as _zipf
except Exception:
    _zipf = None
_cefr = None
def cefr(word):
    global _cefr
    if _cefr is None:
        try:
            from cefrpy import CEFRAnalyzer; _cefr = CEFRAnalyzer()
        except Exception: _cefr = False
    if not _cefr: return None
    try: return _cefr.get_average_word_level_float(word)
    except Exception: return None

# ── 지문 다듬기: 기호를 걷고, 빈칸에는 정답을 넣어 온전한 문장으로 만듦 ──
CIRC = '①②③④⑤'
def clean(T, it):
    t = it['text']
    ans = it['choices'][it['answer']]
    if T in ('31', '32', '33', '34'):
        t = t.replace('______', ans)
    elif T == '40':
        parts = re.split(r'\s+[-–—]\s+', ans)
        if len(parts) == 2:
            t = re.sub(r'\(A\)\s*_{3,}', parts[0], t); t = re.sub(r'\(B\)\s*_{3,}', parts[1], t)
    t = re.sub(r'</?u>', '', t)
    t = t.replace('[삽입할 문장]', '')
    t = re.sub(r'\(\s*[%s]\s*\)' % CIRC, ' ', t)
    t = re.sub(r'[%s]' % CIRC, ' ', t)
    t = re.sub(r'\(([a-eA-E])\)\s?', '', t)
    t = re.sub(r'_{3,}', 'something', t)
    lines = [l.strip() for l in t.split('\n')]
    out = []
    for l in lines:
        if not l: continue
        if T == '25':
            # 자료 줄(숫자 표)은 문장이 아니므로 뺌
            if re.match(r'^\[?\d{4} vs', l) or re.search(r'\d+\s*[-–]\s*\d+\s*/', l) or re.match(r'^[^.]{1,25}(—|:)\s*(\w+\s*:?\s*)?\d', l): continue
        if T == '18':
            if re.match(r'^(Dear|To)\b[^.]{0,60},?$', l): continue
            if re.match(r'^(Yours|Sincerely|Best|Kind|Regards|Love|Thank you|Thanks|With|Warm)\b[^.]{0,40},?$', l): continue
            l = re.sub(r'^Dear [^,]{1,40},\s*', '', l)
        if T == '27_28' and l.startswith('•'):
            l = l.lstrip('• ').strip()
        l = re.sub(r'\s+', ' ', l).strip(); l = re.sub(r'\s+([,.;:!?])', r'\1', l)
        if l: out.append(l)
    return out   # 줄 목록 (줄은 문장 경계로 봄)

ABBR = re.compile(r"\b(Mr|Mrs|Ms|Dr|Prof|St|Mt|vs|etc|No|Jr|Sr|a\.m|p\.m|e\.g|i\.e|approx|Co|Ltd|Inc)\.$")
def raw_sentences(line):
    """마침표·물음표·느낌표 뒤의 빈칸에서 끊음(levelgauge.py와 같은 약속). Mr.·a.m. 같은 줄임말에서는 끊지 않음"""
    parts = re.split(r'(?<=[.!?])\s+(?=["\'(\[]?[A-Z0-9])', line)
    out = []
    for p in parts:
        if out and ABBR.search(out[-1]): out[-1] += ' ' + p
        else: out.append(p)
    return [x.strip() for x in out if len(re.findall(r"[A-Za-z']+", x)) >= 2]
def split_sentences(lines):
    texts = [x for l in lines for x in raw_sentences(l)]
    return [d[:] for d in nlp().pipe(texts)]

FIN = {'VBD', 'VBP', 'VBZ', 'MD'}
RELW = {'which', 'who', 'whom', 'whose', 'that', 'where', 'when', 'why'}
COORD = {'and', 'but', 'so', 'or', 'yet', 'nor', 'for'}
PART = {'up', 'out', 'down', 'off', 'over', 'away', 'back', 'in', 'on', 'apart', 'aside', 'along', 'through', 'around', 'together', 'ahead', 'forward', 'by', 'about', 'across'}
NEG_FRONT = re.compile(r"^(Rarely|Seldom|Never|Hardly|Scarcely|Little|Nor|Neither|Not only|Not until|Only (when|after|by|then|if|in|with|through|once|later|recently)|No sooner|Nowhere|Under no|At no|In no|On no|So \w+ (is|was|are|were)|Such (is|was|are|were)|Had|Were|Should)\b")

def finite(tok):
    if tok.tag_ in FIN: return True
    if any(c.dep_ in ('aux', 'auxpass') and c.tag_ in FIN for c in tok.children): return True
    kids = list(tok.children)
    if any(c.dep_ in ('nsubj', 'nsubjpass') for c in kids) and any(c.dep_ == 'mark' and c.lower_ == 'that' for c in kids) and not any(c.lower_ == 'to' and c.dep_ == 'aux' for c in kids): return True
    return False
def has_to(tok): return any(c.lower_ == 'to' and c.dep_ == 'aux' for c in tok.children) or any(c.lower_ == 'to' for c in tok.children if c.dep_ in ('aux',)) or any(g.lower_ == 'to' for c in tok.children if c.dep_ == 'auxpass' for g in tok.children if g.dep_ == 'aux')
def which_led(tok, s):
    """절의 맨 앞이 ', which'·'전치사 + which(whom·whose)'이면 관계사절"""
    left = sorted([x for x in tok.subtree if x.i <= tok.i], key=lambda x: x.i)
    for x in left[:4]:
        if x.lower_ in ('which', 'whom', 'whose') and x.i > s.start and (x.nbor(-1).text == ',' or x.nbor(-1).pos_ == 'ADP'): return x.lower_
        if x.lower_ == 'who' and x.i > s.start and x.nbor(-1).text == ',': return 'who'
    return None
def has_subj(tok):
    return any(c.dep_ in ('nsubj', 'nsubjpass', 'expl', 'csubj', 'csubjpass') for c in tok.children)
def marker(tok):
    for c in tok.children:
        if c.dep_ == 'mark' or (c.dep_ == 'advmod' and c.tag_ == 'WRB' and c.i < tok.i): return c.lower_
    return None

def analyze_sentence(s):
    """문장 하나에서 절의 종류를 가려 냄. 돌려주는 값: dict(이름 → 걸린 낱말 목록)"""
    r = {'coord': [], 'pred': [], 'sub': [], 'noun': [], 'rel': [], 'rel0': [], 'ptc': [], 'pmod': [], 'inv': [], 'pv': [], 'depth': 0}
    toks = list(s)
    # ', so' 로 이은 문장: 분석기가 앞 절을 ccomp로(또는 뒤 절을 ccomp·advcl로), so를 advmod로 붙이므로 따로 잡음
    so_first = set(); relfix = set()
    for t in toks:
        if t.lower_ == 'so' and t.i > s.start and t.nbor(-1).text in (',', ';') and t.i + 1 < s.end and t.nbor(1).lower_ != 'that' and t.dep_ in ('advmod', 'mark', 'cc', 'dep', 'prep'):   # 317번: 분석기가 so를 dep로 붙이는 때도 있음
            h = t.head
            if h.pos_ in ('VERB', 'AUX') and h.i > t.i and finite(h) and has_subj(h):
                r['coord'].append('so')
                so_first.update(c.i for c in h.children if c.dep_ in ('ccomp', 'advcl', 'dep', 'parataxis') and c.i < t.i and finite(c))
                if h.dep_ in ('ccomp', 'advcl', 'parataxis', 'dep', 'conj'): so_first.add(h.i)
    for t in toks:
        d = t.dep_
        if t.i in so_first: continue
        if t.pos_ in ('VERB', 'AUX') or d in ('relcl', 'advcl', 'ccomp', 'csubj', 'csubjpass', 'acl'):
            fin = finite(t)
            # 이은 문장: 주어를 따로 가진 정동사 절이 and·but·so·or로 이어짐
            if d == 'conj' and fin and t.head.pos_ in ('VERB', 'AUX'):
                ccs = [c.lower_ for c in t.head.children if c.dep_ == 'cc' and c.i < t.i] + [c.lower_ for c in t.children if c.dep_ == 'cc']
                between = [x for x in toks if t.head.i < x.i < t.i and x.dep_ == 'cc']
                cc = (ccs or [x.lower_ for x in between] or [''])[-1]
                if has_subj(t): r['coord'].append(cc or ';')
                else: r['pred'].append(cc or ',')
            elif d == 'advcl':
                m = marker(t); marks = [c.lower_ for c in t.children if c.dep_ == 'mark']
                if fin:
                    w = which_led(t, s) if not m or m in ('which', 'who') else None
                    if w: r['rel'].append(w + '~'); relfix.update(x.i for x in t.subtree)
                    elif m == 'so' and 'that' not in marks and re.search(r'[,;]\s+so\b', s.text): r['coord'].append('so')   # 쉼표 없는 so(~하도록)는 종속절
                    elif marks == ['that']: r['noun'].append('that')
                    else: r['sub'].append(m or '?')
                elif t.tag_ in ('VBG', 'VBN') and not has_to(t):
                    r['ptc'].append((m + '+' if m else '') + t.text)
            elif d == 'relcl' and fin:
                left = [x for x in t.subtree if x.i < t.i]
                rw = [x.lower_ for x in left if x.tag_ in ('WDT', 'WP', 'WP$', 'WRB') or (x.lower_ == 'that' and x.head.i == t.i and x.dep_ not in ('det',))]
                if rw: r['rel'].append(rw[0])
                else: r['rel0'].append(t.text)
            elif d in ('ccomp', 'csubj', 'csubjpass') and fin and which_led(t, s):
                r['rel'].append(which_led(t, s) + '~'); relfix.update(x.i for x in t.subtree)
            elif d in ('ccomp', 'csubj', 'csubjpass') and fin:
                r['noun'].append(marker(t) or next((x.lower_ for x in t.subtree if x.i < t.i and x.tag_ in ('WDT', 'WP', 'WRB')), '(that)'))
            elif d == 'acl':
                if fin: r['noun'].append('동격 that')
                elif t.tag_ in ('VBG', 'VBN') and not has_to(t):
                    prev = t.nbor(-1) if t.i > s.start else None
                    # 쉼표 뒤의 -ing/-ed 덩어리가 문장 끝에 붙은 것은 분사구문으로 봄
                    if prev is not None and prev.text == ',': r['ptc'].append(t.text)
                    else: r['pmod'].append(t.text)
            elif d == 'pcomp' and fin:
                r['noun'].append('전치사+절')
        if d == 'prt' and t.head.pos_ == 'VERB': r['pv'].append(t.head.lemma_ + ' ' + t.lower_)
        elif d == 'advmod' and t.lower_ in PART and t.head.pos_ == 'VERB' and 0 < t.i - t.head.i <= 3 and t.lower_ in ('apart', 'aside', 'away', 'back', 'together', 'ahead', 'forward'):
            r['pv'].append(t.head.lemma_ + ' ' + t.lower_)
    # 분석기가 relcl로 못 붙인 ', which …'·'전치사 + which'·', who …'를 보충
    if True:
        covered = set()
        for t in toks:
            if t.dep_ == 'relcl' and finite(t): covered.update(x.i for x in t.subtree)
        covered |= relfix
        for t in toks:
            if t.i in covered or t.i == s.start: continue
            pv_ = t.nbor(-1)
            if (t.lower_ in ('which', 'whom', 'whose') and (pv_.text == ',' or pv_.pos_ == 'ADP' or pv_.lower_ == 'of')) or (t.lower_ == 'who' and pv_.text == ','):
                r['rel'].append(t.lower_ + '*')
    # 도치: 부정·제한의 말이 앞에 오고 조동사가 주어 앞에 섬 (물음표로 끝나는 문장은 뺌)
    txt = s.text.strip()
    if not txt.endswith('?') and NEG_FRONT.match(txt):
        for t in toks:
            if t.dep_ in ('nsubj', 'nsubjpass') and t.head.pos_ in ('VERB', 'AUX'):
                auxs = [c for c in t.head.children if c.dep_ in ('aux', 'auxpass')] + ([t.head] if t.head.pos_ == 'AUX' or t.head.lemma_ == 'be' else [])
                if any(a.i < t.i for a in auxs) and t.head.dep_ in ('ROOT', 'conj', 'advcl'):
                    r['inv'].append(txt[:30]); break
    # 절이 겹친 깊이
    subs = [t for t in toks if (t.dep_ in ('advcl', 'relcl', 'ccomp', 'csubj', 'csubjpass', 'acl', 'pcomp') and finite(t)) and t.i not in so_first]
    for t in subs:
        dep = 1; h = t.head
        while h is not None and h.dep_ != 'ROOT' and h.i != h.head.i:
            if h in subs: dep += 1
            h = h.head
        r['depth'] = max(r['depth'], dep)
    r['nsub'] = len(subs)
    return r

def vocab(sents):
    W = wl(); con = []; out_basic = []; acad = []; lv = []; zs = []
    for s in sents:
        for t in s:
            if t.pos_ not in ('NOUN', 'VERB', 'ADJ', 'ADV') or not t.is_alpha or len(t.text) < 3: continue
            if t.text[0].isupper() and t.i != s.start and t.pos_ != 'ADJ': continue   # 고유명사로 보이는 것
            f, l = t.lower_, t.lemma_.lower()
            con.append(l)
            if f not in W['ngsl'] and l not in W['ngsl']: out_basic.append(l)
            if f in W['acad'] or l in W['acad']: acad.append(l)
            c = cefr(l) or cefr(f)
            if c: lv.append(c)
            if _zipf: zs.append(max(_zipf(l, 'en'), _zipf(f, 'en')))
    return con, out_basic, acad, lv, zs

def gauge_item(T, it):
    sents = split_sentences(clean(T, it))
    rows = []
    for s in sents:
        a = analyze_sentence(s); a['n'] = len(re.findall(r"[A-Za-z']+", s.text)); a['text'] = s.text.strip(); rows.append(a)
    con, ob, ac, lv, zs = vocab(sents)
    return {'sents': rows, 'ncon': len(con), 'out_basic': ob, 'acad': ac, 'cefr': lv, 'zipf': [round(z, 2) for z in zs]}

def kind(a):
    """문장 한 개의 짜임 이름"""
    k = []
    if a['coord']: k.append('이은')
    if a['sub']: k.append('종속')
    if a['noun']: k.append('명사절')
    if a['rel'] or a['rel0']: k.append('관계')
    if a['ptc']: k.append('분사구문')
    return k or ['단문']

def summarize(items):
    S = [a for it in items for a in it['sents']]
    n = len(S) or 1
    ns = [a['n'] for a in S]
    ncon = sum(it['ncon'] for it in items) or 1
    words = sum(ns)
    def pct(f): return round(100 * sum(1 for a in S if f(a)) / n)
    def itm(f): return sum(1 for it in items if any(f(a) for a in it['sents']))
    cef = [x for it in items for x in it['cefr']]
    return {
        'items': len(items), 'sent_n': len(S), 'sent_per_item': round(len(S) / len(items), 1),
        'words_per_item': round(words / len(items)), 'wps': round(st.mean(ns), 1) if ns else 0,
        'p10_15': pct(lambda a: 10 <= a['n'] <= 15), 'p_lt8': pct(lambda a: a['n'] < 8), 'p25': pct(lambda a: a['n'] >= 25),
        'simple': pct(lambda a: kind(a) == ['단문']), 'coord': pct(lambda a: a['coord']), 'sub': pct(lambda a: a['sub']),
        'noun': pct(lambda a: a['noun']), 'rel': pct(lambda a: a['rel'] or a['rel0']), 'ptc': pct(lambda a: a['ptc']),
        'it_rel': itm(lambda a: a['rel']), 'it_rel_any': itm(lambda a: a['rel'] or a['rel0']), 'it_rel0': itm(lambda a: a['rel0']),
        'it_ptc': itm(lambda a: a['ptc']), 'it_sub': itm(lambda a: a['sub']), 'it_coord': itm(lambda a: a['coord']),
        'it_pv': itm(lambda a: a['pv']), 'it_inv': itm(lambda a: a['inv']), 'it_pmod': itm(lambda a: a['pmod']),
        'clauses': round(1 + sum(a['nsub'] + len(a['coord']) for a in S) / n, 2),
        'deep2': pct(lambda a: a['depth'] >= 2),
        'out_basic': round(100 * sum(len(it['out_basic']) for it in items) / ncon, 1),
        'acad_per_sent': round(sum(len(it['acad']) for it in items) / n, 2),
        'acad_per_100': round(100 * sum(len(it['acad']) for it in items) / (words or 1), 1),
        'it_acad1': sum(1 for it in items if len(it['acad']) >= 1), 'it_acad3': sum(1 for it in items if len(set(it['acad'])) >= 3),
        'zipf_lt4': round(100 * sum(1 for it in items for z in it['zipf'] if z < 4.0) / (sum(len(it['zipf']) for it in items) or 1), 1),
        'zipf_lt35': round(100 * sum(1 for it in items for z in it['zipf'] if z < 3.5) / (sum(len(it['zipf']) for it in items) or 1), 1),
        'it_acad2': sum(1 for it in items if len(set(it['acad'])) >= 2),
        'mix3': sum(1 for it in items if sum(1 for f in (lambda a: a['ptc'], lambda a: a['rel'], lambda a: a['rel0'], lambda a: a['sub'] or a['noun']) if any(f(a) for a in it['sents'])) >= 3),
        'cefr': round(st.mean(cef), 2) if cef else 0, 'cefr_b2': round(100 * sum(1 for x in cef if x >= 4) / (len(cef) or 1), 1),
    }

ORDER = ['18', '19', '20', '21', '22', '23', '24', '25', '26', '27_28', '29', '30', '31', '32', '33', '34', '35', '36_37', '38_39', '40', '41', '42', '43', '44', '45']
if __name__ == '__main__':
    sys.path.insert(0, HERE); from lib import load
    _, tb, _te = load(os.path.join(HERE, 'out/index.html'))
    if len(sys.argv) >= 3:
        T, LV = sys.argv[1], sys.argv[2]
        items = [gauge_item(T, it) for it in tb[T][LV]]
        for n, it in enumerate(items):
            print('── %d번째' % (n + 1))
            for a in it['sents']:
                tags = '/'.join(kind(a)); ext = []
                for k in ('coord', 'sub', 'noun', 'rel', 'rel0', 'ptc', 'pmod', 'inv', 'pv'):
                    if a[k]: ext.append('%s=%s' % (k, ','.join(a[k])))
                print('  [%2d낱말 %s] %s   {%s}' % (a['n'], tags, a['text'], ' '.join(ext)))
            print('  기초 밖:', ', '.join(sorted(set(it['out_basic']))), '| 학술:', ', '.join(sorted(set(it['acad']))))
        print(json.dumps(summarize(items), ensure_ascii=False))
    else:
        res = {}; allitems = {}
        for T in ORDER:
            res[T] = {}
            for LV in '123456789':
                items = [gauge_item(T, it) for it in tb[T][LV]]
                res[T][LV] = summarize(items); allitems.setdefault(T, {})[LV] = items
                print(T, LV, res[T][LV]['wps'], file=sys.stderr, flush=True)
        json.dump(res, open(os.path.join(HERE, 'gauge_all.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        json.dump(allitems, open(os.path.join(HERE, 'gauge_items.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        print('gauge_all.json(칸별) · gauge_items.json(문항·문장별)에 적음')
