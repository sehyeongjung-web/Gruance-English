# -*- coding: utf-8 -*-
# 점검 출력 줄이기 (366번~ 절약 방식): 전체 출력은 파일에 두고, 화면에는 문제 줄과 마지막 줄만 보여 준다.
#   python3 qr.py 이름 -- 명령 인자들...
#   예) python3 qr.py chk -- python3 draft/chk82.py draft/d82_1.py
#   전체를 보고 싶을 때: 같은 명령에서 QR_FULL=1 을 앞에 붙이거나, 화면 끝에 적힌 로그 파일을 연다.
# 왜: 글쓴이가 점검 결과를 열 번 넘게 통째로 읽으면 그때마다 맥락이 커져 값이 늘어남(365번 재어 본 값).
import os, re, subprocess, sys

KEY = re.compile(r'!!|\[bad\]|오류|실패|경고|Traceback|Error|ERROR|FAIL|걸린 것|통과|없음|assert', re.I)
MAXKEY = 14       # 문제 줄은 이만큼까지만
MAXLEN = 220      # 줄 하나는 이 글자 수까지만

def main():
    a = sys.argv[1:]
    if '--' not in a or a.index('--') == 0 or a.index('--') == len(a) - 1:
        print('쓰는 법: python3 qr.py 이름 -- 명령 인자들...   (예: python3 qr.py chk -- python3 draft/chk82.py draft/d82_1.py)'); sys.exit(2)
    k = a.index('--'); name = a[0]; cmd = a[k + 1:]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors='replace')
    out = p.stdout; lines = out.splitlines()
    d = os.environ.get('QR_DIR', '/tmp/qr_logs'); os.makedirs(d, exist_ok=True)
    path = os.path.join(d, re.sub(r'[^0-9A-Za-z가-힣_.-]', '_', name) + '.log')
    open(path, 'w', encoding='utf-8').write(out)
    if os.environ.get('QR_FULL'):
        print(out); sys.exit(p.returncode)
    hits = [l for l in lines if KEY.search(l)]
    bad = [l for l in hits if re.search(r'!!|\[bad\]|오류|실패|경고|Traceback|Error|ERROR|FAIL|assert|걸린 것\s*[1-9]', l, re.I)]
    print('[qr] %s · 종료 %d · 전체 %d줄 · 문제 줄 %d' % (name, p.returncode, len(lines), len(bad)))
    show = bad if bad else hits
    for l in show[:MAXKEY]: print('  ' + (l if len(l) <= MAXLEN else l[:MAXLEN] + '…'))
    if len(show) > MAXKEY: print('  … 그 밖 %d줄은 로그에서' % (len(show) - MAXKEY))
    if lines and lines[-1] not in show[:MAXKEY]: print('  마지막 줄: ' + lines[-1][:MAXLEN])
    verdict = '통과' if (p.returncode == 0 and not bad) else '확인 필요'
    print('[qr] %s · 전체 로그: %s' % (verdict, path))
    sys.exit(p.returncode)

if __name__ == '__main__': main()
