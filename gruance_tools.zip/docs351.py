# -*- coding: utf-8 -*-
# 350·351번 문서 갱신(일회용): LEVEL_GUIDE · README · DEFERRED · 인계문서 · 측정표 페이지 템플릿
import json, re
AUD = json.load(open('/home/claude/work/audit_table.json'))
NM = {'31': '빈칸 추론', '32': '빈칸(낱말)', '33': '빈칸(구)', '34': '빈칸(긴 구)', '40': '요약문'}
def rd(p): return open(p, encoding='utf-8').read()
def wr(p, s): open(p, 'w', encoding='utf-8').write(s)
def rep(s, old, new, cnt=1):
    assert s.count(old) == cnt, (old[:60], s.count(old))
    return s.replace(old, new)

# ---------- 감사표 (마크다운) ----------
rows = ['| 유형 | ' + ' | '.join('L%d' % l for l in range(1, 10)) + ' |', '|---|' + '---|' * 9]
for T in ('31', '32', '33', '34', '40'):
    r = AUD[T]
    rows.append('| %s번 %s | ' % (T, NM[T]) + ' | '.join('%d(%d)' % (r[str(l)][1], r[str(l)][2]) for l in range(1, 10)) + ' |')
AUDIT_MD = '\n'.join(rows)
tot = sum(r[str(l)][1] for r in AUD.values() for l in range(1, 10))

# ================= LEVEL_GUIDE.md =================
g = rd('/home/claude/work/LEVEL_GUIDE.md')
top = '''## 정답 문장만으로 풀리면 고친다 (349·350번 — 2026-10-11 선생님 결정)
- **계기**: 32번 레벨2를 마치고 「마지막 문장만 보여 주면 서른 문항 모두 풀림」이라고 적자 선생님이 물으심 — 「마지막 문장를 주고 풀게 했더니 모두 맞추었다면 수정 대상 아닌가?」 → 맞음. 그것을 「과학 글감의 한계」라 적은 것은 잘못이었음. 이어 선생님: 「그렇게 맞추면 안됩니다. 전부 수정하는게 좋을것 같네요. 혹시 다른 문제도 그런 식으로 풀리는 것이 있으면 **내 허락이 없어도 앞으로는 전부 수정하는 걸로** 정합시다.」
- **상시 규칙**: 정답이 걸린 문장(빈칸 문장 · 밑줄 문장 · 요약문) 하나와 보기만 보여 주고 풀게 했을 때 풀리는 문항은 **수정 대상이고, 허락을 구하지 않고 고친다.** 고친 뒤 무엇을 고쳤는지 보고한다. 적용은 유형별로 판단: 29번(어법)은 본래 한 문장 안의 문법이라 제외. 30 · 21 · 36-37 · 38-39번은 그 칸을 할 때 같은 시험을 돌려 보고 정함. **레벨1은 대상이 아님**(레벨1은 글에 있는 말을 그대로 확인하는 층 — 바탕의 레벨 기준표에도 「한 가지를 조금 다른 말로 바꾸기」는 레벨2부터)
- **시험법**: 풀이꾼(정답을 모름)에게 그 문장 하나 + 보기 다섯만 보여 주고 고르게 함 → 맞힌 수와 「확신(sure)」으로 답한 수를 셈. 코드: `solve69.py <폴더> d69`(last.txt) · `score69.py <폴더>`. 시험 때 key 파일이 같은 폴더에 있으면 안 됨(감사표를 만들 때 `audit_key.json`을 바깥으로 옮기고 네 시트를 다시 풀려 같은 결과를 확인함)
- **통과선(제안 — 선생님 확인 전)**: 맞힌 수 **16/30 이하**이고 확신 **3 이하**. 반대말 둘 가운데 고르는 빈칸은 찍어도 반이 맞으므로 이 선이 너무 느슨하거나 빡빡할 수 있음
- **전 칸 감사(350번)**: 31 · 32 · 33 · 34 · 40번 × 레벨1~9, 칸마다 서른 문항 = 1,350문항에 위 시험을 돌림(맞힌 수와 괄호 안은 확신 수):

''' + AUDIT_MD + '''

  합계 %d/1,350(%.1f%%). 맞힌 수가 25 이하인 칸은 31번 레벨3(25) · 33번 레벨1(26) 둘뿐 — **칸 대부분이 정답 문장만으로 풀림**. 32번 레벨2는 351번에서 다시 써서 **14/30**(이 표에 있던 30은 옛 판의 값). 이 표의 값은 풀이꾼 한 판이며 1~2문항의 차이에는 뜻이 없음
- **새 꼴 (351번에서 검증)**: 글 안에 **A/B 두 조건**(두 상자 · 두 시점 · 두 경우)을 세우고, 셋째 문장이 관찰을 정답과 다른 말로 한 번 바꾸어 알려 주며, **빈칸 문장은 그 결과를 견주는 한 문장**(「half B is ______ than half A」 · 「the one real difference between ball A and ball B is the ______」). 오답은 빈칸 문장만으로는 그럴듯하되 글의 문장으로 가려지게 함. 반대말 둘 중 하나만 고르는 빈칸(faster/slower)은 찍어서 반이 맞으므로 **상태 · 대상 · 이름을 묻는 빈칸을 섞음**
- **앞으로의 순서**: 31번 레벨2(다시 쓰기) → 31 · 32 · 33 · 34 · 40번 레벨1은 상시 규칙의 대상이 아니므로 그대로 → 레벨2 줄을 33번부터 이어 가되 **칸마다 이 시험을 통과 기준에 넣음** → 레벨3 이후도 같은 시험. 칸 수가 많아 한 방에서 다 못 함(칸당 1~2시간 · 감사표 기준으로 레벨2 이상 40여 칸)

'''
g = rep(g, '## 레벨1~3 (지금 쓰는 기준)', top + '## 레벨1~3 (지금 쓰는 기준)')

# 32번 레벨2 절을 새 꼴로 바꿈
i = g.index('## 32번(빈칸 — 낱말) 레벨2의 꼴')
new32 = '''## 32번(빈칸 — 낱말) 레벨2의 꼴 (350번 — 새 꼴을 정함 · 351번 — 서른 문항 다시 씀)
※ 347·348번의 첫 판(과학 상식 한 글감 + 단서 문장 꼴)은 **마지막 문장만 보여 주면 30/30**이라 버리고 351번에 이 꼴로 다시 씀. 첫 판의 기록은 인계문서 347·348번에 남김(`pending/edits_X68a|b.py`는 빌드에 넣지 말 것)
- 틀: **네 문장 · 50~58낱말(평균 55) · 문장당 10~15낱말(평균 13.7)**. 빈칸은 넷째 문장의 **낱말 하나**. 문장 짜임은 **단문 + and · but · so · or로 이은 문장**(`zlevel.py` `RULE['2']` — 종속절 · 관계사절 · 명사절 · 분사 0, `draft/chk69.py` 걸린 것 0, `regauge.py 32 2` 판정 맞음).
- **글의 꼴**: 첫 두 문장이 **A와 B 두 조건**을 세움(같은 것 둘에 하나만 다르게 함: 레몬즙을 바른 반쪽/안 바른 반쪽 · 층이 둘인 병/하나인 병 · 얇은 가죽/느슨한 가죽). 셋째 문장이 **관찰**을 정답과 다른 말로 알려 줌(「has turned brown」 → darker · 「presses and folds」 → kneading · 「layers around the soup」 → walls). 넷째 문장은 **그 결과를 견주는 한 곳**이라 빈칸 문장만으로는 상식으로 그럴듯한 오답이 여럿 남음.
- 정답 번호는 바탕 그대로(정답 자리 ①~⑤ 각 6개). 정답 낱말 서른: darker · kneading · slower · fewer · water · hear · walls · drier · drier · white · direction · ears · more · faster · paint · tired · heat · harder · cooler · faster · stickier · size · older · direction · soap · wilder · circle · softer · longer · outside. 반대말 둘 중 하나인 비교어(faster · slower · more · fewer · longer 등)가 절반쯤이라, 나머지는 상태 · 대상(ears · walls · water · paint · soap · direction · size …)을 묻게 섞음.
- 해설은 두터운 꼴(`z8common.maker(E,'32',lv='2')`): 요령 → 「이 문제에 적용」 네 줄(1 빈칸 문장 · 2 짝꿍 문장[단서가 있는 문장의 서수 + «인용» + 한 번 바꾼 말] · 3 확인[A와 B가 어떻게 다른지, 방향] · 4 묶기) → 끌리는 오답 → 선택지별 `'낱말'(뜻) — 까닭`. 틀린 보기는 **글의 문장(서수 + 인용)** 으로 가려냄(바깥 상식으로 가리지 않음). 「~어요」 말끝. 검사: 영어 `draft/chk69.py draft/d69.py` · 한글 `draft/zk69.py draft/k69_N.py`(서수-인용 일치 · «» 인용이 지문에 그대로 있음 · 12자 미만 인용은 작은따옴표 · 「정답」 낱말 금지 · 길이 480~900자) · 한 번에 돌리기 `./fin69.sh`(gen69 a/b → zjosa2 → 빌드 → `zcheck31.py 32 2`).
- **이번에 배운 것**
  - **정답 낱말이 글에 같은 꼴로 나오면 「바꾸어 말하기」가 아님**: walls ← 글에 wall이 있으면 같은 낱말 찾기 → 「layers around the soup」로 바꿈. grow ↔ larger가 겹치면 「to live」로 · 「the green coat」(옷으로 읽힘) → 「a green layer」 → paint
  - **가리키는 말이 둘을 가리키면 고침**: 「it carries heat away」(물인가 천인가) → 한 주어에 동사 둘 · 연필의 it · 거미줄의 its legs/feet → 「off the thread」를 붙임
  - **빈칸 문장에 굳은 짝말을 만들지 말 것**: 「points in a different direction」는 그 자체로 정답을 줌 → 「shows a different ______」. 단어 둘이 한 짝으로 굳으면 마지막 문장 시험이 올라감
  - **모든 보기가 글의 문장으로 가려져야 함**: 감사꾼이 찾은 것 — 보온병의 lid/wall(→ 「same lid」), 거위의 공기(→ 날개 끝 상승기류), 씨앗의 「B has not changed」(→ 「no roots yet」), 거미줄의 oil(→ stickier로 빈칸을 바꿈), 비누의 oil(→ sugar를 오답으로) · 비누 「pans in bowls」(→ forks), 이슬은 「On clear summer nights」로 낮춤, 가지가 「in a jar」(→ on a table), 북의 「높은 음 = 1초당 떨림이 많다」 연결을 글에 넣음
  - **사실은 맞거나 낮추어 씀**: 「Both sounds are equally loud」(1마일 밖) → 「start equally loud」 · 거위의 「rest its wings」 → 「flap less」 · 나방의 달 각도 → 「may keep the faraway moon on one side」 · 식물의 얼음은 「mostly forms」(해설도 「대부분」을 살림)
  - **번역**: 1초마다 → 1초 동안(each second) · patch → 그늘 · Magnetic north → 자북(나침반 바늘이 가리키는 북쪽) · the same old compass → 바로 그 오래된 나침반 · sounds + 형용사 자리의 보기 뜻은 형용사형(더 큰 · 더 작은) · 불확실한 may 뒤에 「그래서」를 바로 붙이지 않음
- 독립 풀이: **마지막 문장만 푸는 풀이꾼 14/30(확신 2, 둘 다 맞음)** — 첫 시도들 16/30 · 최종 14/30. **지문 전체를 보는 풀이꾼 30/30**(전부 high). 감사꾼(정답을 앎) 열여섯 문항 지적: 대부분 낱말 난이도(1~2) → 열다섯 문항의 영어를 고치고 다시 풀림(14/30 · 30/30 유지). 교정꾼 둘(번역 18건 · 논리 5건, 심각도 3 없음)을 모두 고쳤고, 고친 줄만 따로 한 번 더 확인함(0건)
- **남은 한계(숨기지 않고)**: ① 마지막 문장만 주어도 14문항은 맞음(반대말 둘 중 하나, 또는 상식) — 통과선은 내가 제안한 숫자 ② kneading은 중학 기초 낱말이 아니나, 나머지 보기(stirring · baking · weighing · salting)를 글에서 가려내는 방식으로도 풀림 ③ 기초 밖 낱말이 지문의 14%쯤(stiff · cotton · loaf · tortoise · compass …, 구체적인 사물 이름) ④ 글감이 31번 레벨2 · 32번 레벨1과 일부 겹침(사과 · 꿀 · 보온병 · 거미 · 거북 …) ⑤ 학생이 실제로 푼 결과는 없음(풀이꾼은 모두 같은 종류의 모델)
'''
g = g[:i] + new32
wr('/home/claude/work/LEVEL_GUIDE.md', g)

# ================= README.md =================
r = rd('/home/claude/work/README.md')
lines = r.split('\n')
for k, l in enumerate(lines):
    if l.startswith('| `pending/edits_X68a.py`'):
        lines[k] = '| `pending/edits_X68a.py` | **(버림 — 349번)** 32번 레벨2 첫 판 앞 절반. 마지막 문장만 보면 30/30 풀려 351번에 `edits_X69a.py`로 대체됨. 빌드에 넣지 말 것 |'
    if l.startswith('| `pending/edits_X68b.py`'):
        lines[k] = ('| `pending/edits_X68b.py` | **(버림 — 349번)** 32번 레벨2 첫 판 뒤 절반. `edits_X69b.py`로 대체됨 |\n'
                    '| `pending/edits_X69a.py` | **32번(빈칸 — 낱말) 레벨2 앞 절반(351번 — 1~15번째), A/B 두 조건 꼴.** 꼴은 `edits_X67a.py`와 같음(`rw(n, 정답 번호, 지문(네 문장), 해석, [풀이 1)~4)], 끌리는 오답, [(선택지 뜻, 까닭)×5], ch={…})`, `z8common.maker(E,\'32\',lv=\'2\')`). 영어는 `draft/d69.py`(서른 문항 한 파일), 한글은 `draft/k69_1.py`~`k69_6.py`(다섯 문항씩) → `python3 draft/gen69.py a` |\n'
                    '| `pending/edits_X69b.py` | **32번 레벨2 뒤 절반(351번 — 16~30번째).** 만든 법: `python3 draft/gen69.py b` |')
r = '\n'.join(lines)
r = rep(r, '- 32번(빈칸 — 낱말)을 레벨2로 다시 쓸 때(347·348번):', '- 32번(빈칸 — 낱말)을 레벨2로 **A/B 꼴**로 다시 쓸 때(351번): 영어 `python3 draft/chk69.py draft/d69.py` · 한글 `python3 draft/zk69.py draft/k69_N.py` · 한 번에 `./fin69.sh`(gen69 a/b → zjosa2 → 빌드 → 빌드는 `edits_X67a,edits_X67b,edits_X69a,edits_X69b`), 그다음 `python3 zcheck31.py 32 2` · `check_all.py` · `regauge.py 32 2`. 마지막 문장만 푸는 시험: `python3 solve69.py <폴더> d69`(blind.txt · last.txt · audit.txt) → 풀이꾼 답 `ans_*.txt` → `python3 score69.py <폴더>`. 교정용 문제지는 빌드한 out/index.html에서 뽑음(인계문서 351번). (아래는 버린 첫 판의 도구) 347·348번:')
wr('/home/claude/work/README.md', r)

# ================= DEFERRED.md =================
d = rd('/home/claude/work/DEFERRED.md')
d = rep(d, '→ 32번(빈칸 — 낱말) 레벨2 서른 문항을 마침(○) — 네 문장', '→ [※ 349번에서 취소 — 마지막 문장만 보면 30/30 풀림, 351번에 다시 씀] 32번(빈칸 — 낱말) 레벨2 서른 문항을 마침 — 네 문장')
d = rep(d, '→ 31번(빈칸 추론) 레벨2 서른 문항을 마침(○) — 네 문장', '→ 31번(빈칸 추론) 레벨2 서른 문항을 마침[※ 349번: 마지막 문장만 보면 30/30 풀려 **다시 쓸 것**] — 네 문장')
tail = ''' · **349~351번: 선생님 지적(「마지막 문장을 주고 풀게 했더니 모두 맞추었다면 수정 대상 아닌가?」)과 결정(「내 허락이 없어도 앞으로는 전부 수정하는 걸로」)** — ① 상시 규칙(LEVEL_GUIDE 맨 위 「정답 문장만으로 풀리면 고친다」): 정답 문장 하나로 풀리는 문항은 허락 없이 고치고 보고함(29번 어법은 제외, 레벨1은 대상 아님) ② 전 칸 감사(31 · 32 · 33 · 34 · 40번 × 레벨1~9 = 1,350문항): **%d문항(%.1f%%)이 정답 문장만으로 풀림** — 표는 LEVEL_GUIDE ③ **32번 레벨2를 A/B 두 조건 꼴로 다시 씀(351번)**: 마지막 문장만 푸는 풀이꾼 14/30(확신 2) · 지문 전체 30/30 · 교정꾼 23건 반영. `pending/edits_X69a|b.py`(빌드는 `edits_X67a,edits_X67b,edits_X69a,edits_X69b` — X68은 버림). **남은 일(순서)**: 31번 레벨2를 같은 꼴로 다시 씀 → 레벨2 줄을 33번부터 이어 가되 칸마다 「마지막 문장만 푸는 시험」을 통과 기준에 넣음(통과선 16/30 이하 · 확신 3 이하는 제안이며 선생님 확인 전) → 레벨3 이후도 같은 시험. 레벨1이 「맞음」이 아닌 나머지 약 열네 유형 처리는 아직 여쭙지 않음''' % (tot, 100.0 * tot / 1350)
# item 7은 한 줄 — 줄 끝에 덧붙임
lines = d.split('\n')
k = [i for i, l in enumerate(lines) if l.startswith('7. **[하는 중')][0]
lines[k] = lines[k].rstrip() + tail
wr('/home/claude/work/DEFERRED.md', '\n'.join(lines))
print('LEVEL_GUIDE, README, DEFERRED 완료', tot)
