# -*- coding: utf-8 -*-
# 36-37번(글의 순서) 레벨 기준으로 다시 쓸 때의 원고 도구 (333번)
#   python3 z3637draft.py match <원고 모듈 경로(.py 빼고)> [문장 수=7]
#     원고 모듈: I[n] = (주어진 글, {'A': [문장…], 'B': […], 'C': […]}, 'CAB' 같은 정답 순서)
#   ① 재기(zlevel) ② 「낱말만 맞추는 학생」이 고를 순서 — 두 가지로 셈
#        통째: 앞 글 전체와 뒤 글 전체가 겹치는 낱말 / 맞물림: 앞 글의 끝 문장과 뒤 글의 첫 문장이 겹치는 낱말
#      다섯 선택지(A-B-C는 선택지에 없음) 가운데 점수가 혼자 가장 높은 것이 답과 같으면 「낱말 맞추기로 풀림」
#   ③ 꼴로 찍기: 첫 글의 첫머리(때를 말하는 말 · 이름) · 마지막 글의 꼴(These days · Now · 다른 주어)
import sys, re, os, importlib, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
STOP = set('a an the and or but of to in on at by for from with without into onto up down out off over under after before between next his her him she he it its they them their this that these those was were is are be been had has have did do does not no so as than then there here very one two also only even all some any every each last first new old few more most much many little now still again just such both too own however because soon later'.split())
def stem(w):
    for suf in ('ing', 'ed', 'es', 's'):
        if w.endswith(suf) and len(w) - len(suf) >= 3: return w[:-len(suf)]
    return w
def words(s): return {stem(w) for w in re.findall(r"[a-z]+", s.lower().replace("'s", "")) if w not in STOP and len(w) > 2}
CH = ['ACB', 'BAC', 'BCA', 'CAB', 'CBA']
def lay(g, P): return g + "\n\n" + "\n".join("(%s) %s" % (k, " ".join(P[k])) for k in 'ABC')
def score(g, P, o, whole):
    seq = [[g]] + [P[k] for k in o]; t = 0
    for a, b in zip(seq, seq[1:]):
        t += len(words(' '.join(a)) & words(' '.join(b))) if whole else len(words(a[-1]) & words(b[0]))
    return t
def match(mod, nsent=7):
    d, name = os.path.split(mod)
    if d: sys.path.insert(0, d)
    M = importlib.import_module(name); texts = {}; w1 = w2 = 0
    if hasattr(M, 'I'): I = M.I
    else:   # 수정안 모듈(E의 rewrite)에서 읽음: PYTHONPATH=pending python3 z3637draft.py match edits_X62a
        from lib import load
        _, tb, _ = load(); I = {}
        for (t, lv, n), ed in M.E.items():
            m = re.match(r'^(.*?)\n\n\(A\) (.*?)\n\(B\) (.*?)\n\(C\) (.*)$', ed['rewrite']['text'], re.S); it = tb[t][lv][n]
            I[n] = (m.group(1), {k: re.split(r'(?<=[.?!])\s+', m.group(i + 2)) for i, k in enumerate('ABC')}, ''.join(re.findall(r'\(([ABC])\)', it['choices'][it['answer']])))
    for n, (g, P, a) in sorted(I.items()):
        res = []
        for whole in (True, False):
            sc = [score(g, P, o, whole) for o in CH]; m = max(sc); top = [CH[i] for i in range(5) if sc[i] == m]
            res.append((sc, top))
        u1 = res[0][1] == [a]; u2 = res[1][1] == [a]; w1 += u1; w2 += u2
        first = max('ABC', key=lambda k: len(words(g) & words(' '.join(P[k]))))
        print('%2d번째 답 %s · 통째 %s → %s%s · 맞물림 %s → %s%s · 주어진 글과 가장 많이 겹치는 글 (%s)' % (n + 1, a, res[0][0], '/'.join(res[0][1]), ' ←답' if u1 else '', res[1][0], '/'.join(res[1][1]), ' ←답' if u2 else '', first))
        texts[n] = (lay(g, P), '(%s)-(%s)-(%s)' % tuple(a))
    print('낱말 맞추기만으로 답이 혼자 나오는 문항: 통째 %d/%d · 맞물림 %d/%d   (선택지 차례: %s)' % (w1, len(I), w2, len(I), ' '.join(CH)))
    from zlevel import check_texts
    check_texts('36_37', '1', texts, nsent)
if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == 'match': match(a[1], int(a[2]) if len(a) > 2 else 7)
    else: print('쓰는 법은 파일 머리의 주석을 볼 것')
