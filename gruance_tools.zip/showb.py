# -*- coding: utf-8 -*-
# 빈칸·주제·제목처럼 선택지가 다섯인 유형을 간추려 읽기: python3 showb.py 33 6 0 30
import sys; sys.path.insert(0, '.')
from lib import *
T, lv, a, b = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
s, tb, te = load('out/index.html')
for n in range(a, b):
    it = tb[T][lv][n]
    print('=====', n + 1, 'ans', it['answer']); print(it['text'].replace('\n\n', ' // '))
    for k, c in enumerate(it['choices']): print('   %s%d %s' % ('*' if k == it['answer'] else ' ', k, c))
