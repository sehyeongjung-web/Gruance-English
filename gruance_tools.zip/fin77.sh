#!/bin/bash
# 360번: 18번 레벨1(편지 네 문장 · 목적 문장 + 곁가지) — 원고에서 수정안 만들기 → 조사 → 빌드 (바탕 3735e9a 위에 X76만)
cd /home/claude/work
python3 draft/gen77.py a && python3 draft/gen77.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X76a.py pending/edits_X76b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X76a,edits_X76b out/index.html | tail -3
