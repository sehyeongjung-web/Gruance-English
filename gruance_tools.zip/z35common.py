# -*- coding: utf-8 -*-
# 35번(무관한 문장) 해설 두텁게 — 레벨을 받는 공통 도우미 (212번~, 레벨9 때(177번)의 도우미에 레벨 인자를 단 것)
#   mk = maker(E, lv='8')
#   mk(n, [적용 네 줄], 헷갈리는 곳, [번호 문장 다섯 개의 설명])
# - "①번은 흐름에 맞습니다." / "②번이 정답입니다." 머리말은 자동. 3)이 정답 번호로 시작하지 않으면 멈춤
# - 원고의 «…»는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜
import sys; sys.path.insert(0, '.')
from lib import load as _load
_tb = _load()[1]
CIRC = '①②③④⑤'
TIP = ("【무관한 문장 찾기 요령】\n"
       "첫째, 번호 없는 첫 문장에서 글이 하려는 말(주제)을 먼저 잡습니다.\n"
       "둘째, 번호 문장마다 「무엇에 대해 말하는가」를 한 줄로 줄여, 주제와 이어지는지 봅니다.\n"
       "셋째, 낱말이 겹쳐도 방심하지 않습니다. 소재는 같은데 말하는 방향이 다른 문장이 답입니다.\n"
       "넷째, 그 문장을 빼고 앞뒤를 이어 읽습니다. 가리키는 말과 이어 주는 말이 매끄럽게 이어지면 맞게 고른 것입니다.")
HEADS = ('1) 주제:', '2) 문장마다 한 줄:', '3) 어긋나는 문장:', '4) 빼고 읽기:')
def _q(x): return x.replace('«', '"').replace('»', '"')
def maker(E, lv='8'):
    def mk(n, steps, confuse, cn):
        it = _tb['35'][lv][n]; a = it['answer']
        assert len(cn) == 5 and len(steps) == 4, n
        assert all(s.startswith(h) for s, h in zip(steps, HEADS)), (n, '적용 줄의 머리말')
        assert steps[2].startswith('3) 어긋나는 문장: %s' % CIRC[a]), (n, '정답 번호와 풀이가 다름')
        out = {}
        for k, body in enumerate(cn):
            assert '정답' not in body, (n, k, '설명에 "정답"이라는 말')
            out[k] = CIRC[k] + ("번이 정답입니다. " if k == a else "번은 흐름에 맞습니다. ") + _q(body)
        assert ('35', lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[('35', lv, n)] = {'walk': TIP + "\n\n【이 문제에 적용】\n" + "\n".join(_q(x) for x in steps) + "\n\n【헷갈리는 곳】\n" + _q(confuse), 'cn': out}
    return mk
