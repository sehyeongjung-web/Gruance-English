# 길이 점검표(A·B·C) 도우미: python3 lenfix.py <유형> <레벨>  → 고칠 후보 문항을 보여 줌 (out/index.html 기준)
import sys, importlib.util
sys.path.insert(0,'/home/claude/work')
sp=importlib.util.spec_from_file_location('v','/home/claude/Gruance-English/verify.py'); v=importlib.util.module_from_spec(sp); sp.loader.exec_module(v)
from lib import load
T,L=sys.argv[1],sys.argv[2]
_,tb,_=load('/home/claude/work/out/index.html')
items=tb[T][L]; print(T,L,v.length_cell(items))
for n,it in enumerate(items):
    ch=it['choices']; k=it['answer']; Lk=len(ch[k]); r=1+sum(len(x)>Lk for i,x in enumerate(ch) if i!=k)
    ls=sorted((len(x) for x in ch),reverse=True); b=ls[1] and ls[0]/ls[1]>=1.3
    med=(ls[2]+ls[3])/2; c=med and ls[0]/med>=1.4 and ls[0]-med>=5
    tag=('R%d'%r)+(' B' if b else '')+(' C' if c else '')
    print('%2d %-6s key=%-12s %s'%(n,tag,ch[k],' '.join('%s(%d)'%(x,len(x)) for x in ch)))
