# -*- coding: utf-8 -*-
# 314번: gauge_all.json·gauge_items.json을 읽어 칸마다 판정을 내리고 표에 쓸 자료(page_data.json)를 만듦
import json, statistics as st
R = json.load(open('gauge_all.json', encoding='utf-8'))
I = json.load(open('gauge_items.json', encoding='utf-8'))
ORDER = ['18','19','20','21','22','23','24','25','26','27_28','29','30','31','32','33','34','35','36_37','38_39','40','41','42','43','44','45']
NAME = {'18':'목적','19':'심경','20':'주장','21':'함축 의미','22':'요지','23':'주제','24':'제목','25':'도표','26':'인물 일치','27_28':'안내문','29':'어법','30':'어휘','31':'빈칸(낱말)','32':'빈칸(구)','33':'빈칸(절)','34':'빈칸(절)','35':'무관한 문장','36_37':'글의 순서','38_39':'문장 삽입','40':'요약문','41':'장문 제목','42':'장문 어휘','43':'장문 순서','44':'장문 지칭','45':'장문 일치'}
GROUP = {}
for T in ['20','21','22','23','24','29','30','31','32','33','34','35','36_37','38_39','40','41','42']: GROUP[T] = 'expo'
for T in ['18','19','26','43','44','45']: GROUP[T] = 'narr'
for T in ['25','27_28']: GROUP[T] = 'form'
def kinds(a):
    k = []
    if a['coord']: k.append('이은 문장')
    if a['sub']: k.append('종속절')
    if a['noun']: k.append('명사절')
    if a['rel']: k.append('관계사절')
    if a['rel0']: k.append('관계사 생략')
    if a['ptc']: k.append('분사구문')
    return k
def extra(T, L):
    items = I[T][L]; S = [a for it in items for a in it['sents']]; n = len(S) or 1
    hi2 = sum(1 for a in S if a['sub'] or a['noun'] or a['rel'] or a['rel0'] or a['ptc'])      # 레벨2에서 볼 '윗레벨 짜임'
    hi3 = sum(1 for a in S if a['rel'] or a['rel0'])
    ell = sum(1 for it in items if any(a['rel0'] or any('+' in p for p in a['ptc']) for a in it['sents']))
    acad1 = sum(1 for it in items if len(it['acad']) >= 1)
    return {'hi2': round(100 * hi2 / n), 'hi3': round(100 * hi3 / n), 'it_ell': ell, 'it_acad1': acad1}
def judge(T, L):
    r = dict(R[T][L]); r.update(extra(T, L)); g = GROUP[T]; fails = []; notes = []
    if g == 'form': return r, 'na', ['글의 꼴이 달라 문장 기준을 그대로 대기 어려움']
    lv = int(L)
    if lv <= 3:
        if r['wps'] < 9.5: fails.append('len'); notes.append('문장이 짧음(문장당 %.1f낱말)' % r['wps'])
        elif r['wps'] > 15.5: fails.append('len'); notes.append('문장이 김(문장당 %.1f낱말)' % r['wps'])
    if lv == 1:
        if r['simple'] < 85: fails.append('st'); notes.append('단문이 %d%%뿐 — 종속절·관계사절 따위가 섞임' % r['simple'])
    elif lv == 2:
        if r['it_coord'] < 24: fails.append('own'); notes.append('이은 문장이 든 문항 %d/30' % r['it_coord'])
        if r['hi2'] > 15: fails.append('over'); notes.append('윗레벨 짜임이 든 문장 %d%%' % r['hi2'])
    elif lv == 3:
        if r['it_sub'] < 24: fails.append('own'); notes.append('종속절이 든 문항 %d/30' % r['it_sub'])
        if r['hi3'] > 10: fails.append('over'); notes.append('관계사절이 든 문장 %d%%' % r['hi3'])
    elif lv == 4:
        if r['it_rel'] < 15: fails += ['own', 'own2']
        elif r['it_rel'] < 24: fails.append('own')
        if r['it_rel'] < 24: notes.append('관계사절이 든 문항 %d/30' % r['it_rel'])
    elif lv == 5:
        if r['it_ptc'] < 15: fails += ['own', 'own2']
        elif r['it_ptc'] < 24: fails.append('own')
        if r['it_ptc'] < 24: notes.append('분사구문이 든 문항 %d/30' % r['it_ptc'])
    elif lv == 6:
        if r['it_ptc'] < 24: fails.append('own'); notes.append('분사구문이 든 문항 %d/30' % r['it_ptc'])
        if g == 'expo' and r['it_acad1'] < 24: fails.append('voc'); notes.append('학술 낱말이 든 문항 %d/30' % r['it_acad1'])
    elif lv == 7:
        if r['it_ell'] < 24: fails.append('own'); notes.append('생략이 든 문항 %d/30' % r['it_ell'])
        if g == 'expo' and r['it_acad2'] < 24: fails.append('voc'); notes.append('학술 낱말 2가지 이상인 문항 %d/30' % r['it_acad2'])
    elif lv == 8:
        if r['mix3'] < 24: fails.append('own'); notes.append('분사구문·관계사·생략·종속절 가운데 셋 이상 섞인 문항 %d/30' % r['mix3'])
        if g == 'expo' and r['it_acad3'] < 24: fails.append('voc'); notes.append('학술 낱말 3가지 이상인 문항 %d/30' % r['it_acad3'])
    elif lv == 9:
        if r['wps'] < 20: fails += ['len', 'len2']
        elif r['wps'] < 24.5: fails.append('len')
        if r['wps'] < 24.5: notes.append('문장당 %.1f낱말(기준표 25 이상)' % r['wps'])
        if g == 'expo' and r['it_acad3'] < 24: fails.append('voc'); notes.append('학술 낱말 3가지 이상인 문항 %d/30' % r['it_acad3'])
    v = 'ok' if not fails else ('part' if len(fails) == 1 else 'off')
    return r, v, notes
if __name__ == '__main__':
    V = {}
    for T in ORDER:
        V[T] = {}
        for L in '123456789':
            r, v, notes = judge(T, L); V[T][L] = v
    sym = {'ok': '✅', 'part': '△', 'off': '✗', 'na': '—'}
    print('유형      ' + '  '.join('L%s' % l for l in '123456789'))
    for T in ORDER: print('%-6s %-6s' % (T, GROUP[T]) + '  '.join(' ' + sym[V[T][l]] for l in '123456789'))
    from collections import Counter
    for l in '123456789': print('L' + l, dict(Counter(V[T][l] for T in ORDER)))
    print(dict(Counter(V[T][l] for T in ORDER for l in '123456789')))
