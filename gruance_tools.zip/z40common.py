# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨9 해설 두텁게 — 공통 도우미 (196번~)
#   mk = maker(E)
#   mk(n, 정답 자리(0~4), [적용 네 줄], 끌리는 오답, [(선택지 해석, 까닭) × 5])
# - 31~34번의 z8common.py와 같은 꼴. 다른 점: 요령 네 줄이 요약문용이고, 적용 줄의 머리말이 「1) 요약문: / 2) (A) 찾기: / 3) (B) 찾기: / 4) 묶기:」
# - 선택지 영어(낱말 짝)는 문항에서 자동으로 가져오고, 정답 자리에는 "정답입니다."를 붙임
# - 원고의 «…»는 지문·요약문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜
import sys; sys.path.insert(0, '.')
from lib import load as _load
_tb = _load()[1]
TIP = ("【요약문 완성 요령】\n"
       "첫째, 지문보다 요약문을 먼저 읽습니다. 요약문은 글 전체를 한 문장으로 줄인 것입니다. (A)와 (B)가 저마다 무엇을 묻는지 우리말로 정해 둡니다.\n"
       "둘째, 요약문의 틀(rather than, less A than B, so, but, yet, while)로 (A)와 (B)가 어느 편인지 정합니다. 버리는 쪽인지 남는 쪽인지, 까닭인지 결과인지를 봅니다.\n"
       "셋째, 지문에서 (A)의 짝꿍 문장과 (B)의 짝꿍 문장을 따로 찾습니다. 요약문의 차례는 대개 지문의 차례와 같아서, (A)는 앞쪽에 (B)는 뒤쪽에 있는 일이 많습니다.\n"
       "넷째, (A)와 (B)를 따로 정한 뒤 둘 다 맞는 짝을 고릅니다. 한쪽만 맞는 짝이 가장 끌리는 함정입니다. 답은 지문 낱말을 그대로 쓰기도 하고 다른 말로 바꾸기도 합니다.")
# 298번: 레벨1~3은 해설의 말끝이 「~어요」(README) — 요령·머리말을 그 말끝으로
TIP3 = ("【요약문 완성 요령】\n"
        "첫째, 지문보다 요약문을 먼저 읽어요. 요약문은 글 전체를 한 문장으로 줄인 것이에요. (A)와 (B)가 저마다 무엇을 묻는지 우리말로 정해 둬요.\n"
        "둘째, 요약문의 틀(rather than, less A than B, so, but, yet, while)로 (A)와 (B)가 어느 편인지 정해요. 버리는 쪽인지 남는 쪽인지, 까닭인지 결과인지를 봐요.\n"
        "셋째, 지문에서 (A)의 짝꿍 문장과 (B)의 짝꿍 문장을 따로 찾아요. 요약문의 차례는 대개 지문의 차례와 같아서, (A)는 앞쪽에 (B)는 뒤쪽에 있는 일이 많아요.\n"
        "넷째, (A)와 (B)를 따로 정한 뒤 둘 다 맞는 짝을 골라요. 한쪽만 맞는 짝이 가장 끌리는 함정이에요. 답은 지문 낱말을 그대로 쓰기도 하고 다른 말로 바꾸기도 해요.")
def low(lv): return lv in ('1', '2', '3')
HEADS = ('1) 요약문:', '2) (A) 찾기:', '3) (B) 찾기:', '4) 묶기:')
def _q(x): return x.replace('«', '"').replace('»', '"')
def W(steps, traps, lv='9'):
    return (TIP3 if low(lv) else TIP) + "\n\n【이 문제에 적용】\n" + "\n".join(steps) + "\n\n【끌리는 오답】\n" + traps
def maker(E, t='40', lv='9'):
    def mk(n, ans, steps, traps, cn, ch=None, ans_ok=False):
        # ans_ok=True: 정답 선택지의 낱말까지 고치는 문항(인계문서에 까닭을 적은 것만)
        # ch: 같은 수정안에서 오답 선택지를 바꾸는 문항이면 {자리: '새 선택지'}
        it = dict(_tb[t][lv][n]); it['choices'] = list(it['choices'])
        for kk, vv in (ch or {}).items():
            assert kk != ans or ans_ok, (n, '정답 선택지는 바꾸지 않음'); it['choices'][kk] = vv
        assert it['answer'] == ans, ('원고의 정답 자리가 문항과 다름', t, n, it['answer'], ans)
        assert len(cn) == 5 and len(steps) == 4, (n, '개수')
        assert all(s.startswith(h) for s, h in zip(steps, HEADS)), (n, '적용 줄의 머리말')
        assert any('짝꿍 문장' in s for s in steps), (n, '짝꿍 문장이 없음')
        out = {}
        for k, (ko, why) in enumerate(cn):
            assert '정답' not in why and '정답' not in ko, (n, k, '까닭에 "정답"이라는 말')
            assert ' - ' in ko, (n, k, '선택지 해석이 낱말 짝이 아님')
            out[k] = (("정답이에요. " if low(lv) else "정답입니다. ") if k == ans else "") + "'%s' (%s) — %s" % (it['choices'][k], ko, _q(why))
        assert (t, lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(t, lv, n)] = {'walk': W([_q(x) for x in steps], _q(traps), lv), 'cn': out}
        if ch: E[(t, lv, n)]['ch'] = dict(ch)
        if ans_ok: E[(t, lv, n)]['ans_ok'] = True
    return mk
