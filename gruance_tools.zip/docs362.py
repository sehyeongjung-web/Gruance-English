# -*- coding: utf-8 -*-
import os
def rd(p): return open(p, encoding='utf-8').read()
def wr(p, s): open(p, 'w', encoding='utf-8').write(s)
def rep(s, old, new, cnt=1):
    assert s.count(old) == cnt, (old[:70], s.count(old)); return s.replace(old, new)
W = '/home/claude/work/'; SIZE = '{:,}'.format(os.path.getsize(W + 'out/index.html'))
g = rd(W + 'LEVEL_GUIDE.md')
g = rep(g, '18번 레벨1은 360번 · 19번 레벨1은 361번에 마침', '18번 레벨1은 360번 · 19번 레벨1은 361번 · 20번 레벨1은 362번에 마침')
sec = '''## 20번(주장) 레벨1의 꼴 (362번 — 서른 문항 다시 씀)
※ 옛 판은 문장이 짧고 종속절이 섞여 `regauge` 어긋남. 362번에 이 꼴로 다시 씀 → `regauge.py 20 1` **맞음**(단문 100% · 문장당 12.2낱말 · 문항당 49낱말).
- 틀: **네 문장 · 단문 100% · 문장당 10~15낱말**. 주장 문장은 **하나**(명령문이거나 should · must), 자리는 첫째~넷째에 고루(7 · 7 · 8 · 8). 나머지 세 문장은 명령문 · should · must를 쓰지 않음. 「However, …」「Instead, …」로 시작하는 단문은 괜찮음. 보기 다섯은 모두 「~해야 한다」(또는 「~해도 된다」)
- **흔한 조언 대 필자의 방법**: 문항의 절반쯤은 글이 흔한 방법을 먼저 말하고(「Many people wash their hands for twenty seconds. However, … not enough」) 다른 방법을 권함 → 흔한 방법이 끌리는 오답. 나머지는 정답이 흔한 조언이어도 되지만 오답에 똑같이 바람직한 조언 둘을 둠. 서로 반대인 오답 짝(「잠들기 전에」 ↔ 「아침 일찍」)을 두고 정답은 그 짝 밖에
- **오답은 글이 막아야**: 같은 문제를 푸는 다른 방법을 오답으로 쓰려면 글이 그것을 분명히 물리쳐야 함. 글이 까닭 · 좋은 점으로 말한 것을 「~해야 한다」로 바꾼 오답은 쓰지 않음(둘째 답이 됨)
- 보기만 보고 찍기: 첫판 **24 · 24/30(확신 8 · 14)** — 정답이 늘 「가장 흔하고 바람직한 조언」이라 상식으로 찍힘. 감사꾼은 아홉 문항에서 오답도 글로 방어된다고 함 → 위 두 줄로 다시 씀(`brief_d79b.txt`) → 둘째 판 19 · 12 → 셋째 판 **15 · 13/30(확신 0 · 1)**. 지문 전체 30/30
- **배운 것**: 주장 유형의 보기만 찍기는 「정답 = 가장 바람직한 조언」에서 생김 — 필자가 흔한 조언을 물리치게 하면 크게 줄어듦 · often · can · most를 빼고 단정하게 옮기지 말 것(교정꾼 논리 지적의 대부분)
- 원고: 영어 `draft/d79.py`(검사 `draft/chk79.py`, 지침 `brief_d79.txt` · `brief_d79b.txt`), 한글 `draft/k79_1~6.py`(검사 `draft/zk79.py`, 지침 `brief_k79.txt`), 도우미 `z20common.py`, `./fin79.sh` → `pending/edits_X78a|b.py`. 보기 길이: 정답이 가장 긴 2 · 첫째 · 둘째로 긴 12 · B · C · E 0
- 남은 한계: 학생 결과 없음 · `check_all`의 「20번 L1: 평균 49단어(목표 약 22단어)」는 옛 기준

'''
i = g.index('## 20번(주장) 레벨2의 꼴'); g = g[:i] + sec + g[i:]
wr(W + 'LEVEL_GUIDE.md', g)
r = rd(W + 'README.md')
old = "| `pending/edits_X77a.py` · `edits_X77b.py` |"
r = rep(r, old, "| `pending/edits_X78a.py` · `edits_X78b.py` | **20번(주장) 레벨1(362번)** — 네 문장 · 단문 · 주장 문장 하나(명령문 · should · must) + 필자가 흔한 조언을 물리치는 꼴. `z20common.maker(E)`의 `rw(n, 정답 자리, 지문, [보기], 해석, 주장 문장, 해석, 자리, 풀이, 바꾸어 말함, 낱말, [까닭])`. 영어 `draft/d79.py`, 한글 `draft/k79_1~6.py` → `python3 draft/gen79.py a|b` · `./fin79.sh`(바탕 27d580d 위에 X78만) · 검사 `draft/chk79.py` · `draft/zk79.py` · 점수 `python3 score_any.py <폴더> 20 1` |\n" + old)
wr(W + 'README.md', r)
d = rd(W + 'DEFERRED.md')
d = rep(d, '(18번 360번 · 19번 361번에 마침 → 20 ·', '(18번 360번 · 19번 361번 · 20번 362번에 마침 →')
wr(W + 'DEFERRED.md', d)
h = rd(W + 'out/그루앙스_작업인계문서.md').rstrip('\n') + '''

## 362. 20번(주장) 레벨1을 새 꼴로 다시 씀 (2026-10-12, 같은 방)

선생님 「계속」(14:29) → 순서대로 **20번 레벨1**(옛 판 `regauge` 어긋남: 문장이 짧고 종속절). 수정안 `pending/edits_X78a.py` · `edits_X78b.py`.
- 꼴(LEVEL_GUIDE 「20번(주장) 레벨1의 꼴」): 네 문장 · 단문 · 주장 문장 하나(자리 고루) · 절반쯤은 필자가 흔한 조언을 물리치고 다른 방법을 권함. 정답 번호 바탕 그대로
- 영어: 세 opus 초안 → `draft/d79.py`. 시험(보기만): 첫판(`sheets90/`) 24 · 24/30 확신 8 · 14 + 감사꾼 아홉 문항 「오답도 방어됨」 → `brief_d79b.txt`로 다시 씀 → 둘째 판(`sheets91/`) 19 · 12 → 셋째 판(`sheets92/`) **15 · 13/30 확신 0 · 1** · 지문 전체 30/30 · 감사꾼 지적 반영(우유 · 구명조끼 보기, apartment building)
- 한글: 여섯 opus → 교정꾼 둘(번역 10 · 논리 26) → 고침꾼이 36건 반영(often · can · most를 살림 · 「버스에서 내릴 때」 · 「입김」 · spoil = 못 쓰게 만들다 …). 고침꾼이 알린 보기 문구 둘(4번째 「매일」이 빠짐 · 18번째 「돌려 읽어야」가 lend보다 넓음)은 해설로 맞춰 두고 보기는 그대로
- 점검: `chk79.py` 0 · `zk79.py` 0 · `regauge.py 20 1` **맞음** · `check_all.py` 통과(④ 143/144)
- 다음에 시작할 때: 바탕 **25,179,216바이트(`27d580d`)**이면 `PYTHONPATH=pending python3 build.py edits_X78a,edits_X78b out/index.html` → **''' + SIZE + '''바이트**. 다음은 **22번(요지) 레벨1** → 23 → 24 → 26 → 41-42 → 43 → 44 → 45. 새 방 첫 줄: 「인계문서 362번까지 올렸습니다. 22번 레벨1을 봅니다.」
'''
wr(W + 'out/그루앙스_작업인계문서.md', h)
t = rd(W + 'page/template.html')
t = rep(t, '<b style="color:var(--fg)">19번 레벨1</b> (10-12, 인계문서 361번', '<b style="color:var(--fg)">20번 레벨1</b> (10-12, 인계문서 362번 — 주장: 네 문장 · 단문 100% · 주장 문장 하나, 필자가 흔한 조언을 물리치는 꼴로 서른 문항을 다시 씀) · <b style="color:var(--fg)">19번 레벨1</b> (10-12, 인계문서 361번')
wr(W + 'page/template.html', t)
print('docs362', SIZE)
