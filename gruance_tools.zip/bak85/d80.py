I = {}
# 22번(글의 요지) 레벨1 새 원고 — n=0~9 (글감: 동물 · 식물 · 날씨 · 자연)
# R · 요지 셋째 · 정답 ②
I[0] = dict(S=["Many people picture a camel's hump as a big bag of water.",
 'Our class watched a short film about camels in science class yesterday.',
 "In fact, a camel's hump holds fat for long trips without food.",
 'The hump of one thin camel in the film was small and soft.'], pos=2,
 ch={0:'낙타는 물을 한 번에 아주 많이 마셔 둘 수 있다',
     1:'낙타는 먹이가 없는 길에 쓸 힘을 혹에 모아 둔다',
     2:'낙타의 혹 속에는 물이 가득 들어 있다',
     3:'낙타는 더운 낮보다 서늘한 밤에 더 오래 걸어 다닌다',
     4:'혹이 큰 낙타일수록 사막에서 더 빨리 지친다'})
# R · 요지 둘째 · 정답 ②
I[1] = dict(S=['Many picture books show a sunflower turning with the sun all day.',
 'In fact, a grown sunflower faces only the east from morning to night.',
 'Grandpa Seo has a row of tall sunflowers beside his farm house.',
 'Even in the late afternoon, all of his big flowers looked toward the east.'], pos=1,
 ch={0:'해바라기는 해를 따라 하루 종일 고개를 이리저리 돌린다',
     1:'다 자란 해바라기는 온종일 한쪽 방향만 바라본다',
     2:'해바라기는 햇빛이 잘 드는 곳에서 더 크고 튼튼하게 자란다',
     3:'해바라기는 그늘에서 꽃이 더 오래 피어 있다',
     4:'해바라기 씨는 늦은 여름에 가장 많이 여문다'})
# O · 요지 셋째 · 정답 ⑤
I[2] = dict(S=['Two maple trees of the same age stand at the end of our street.',
 'Last November, the tree beside the bright street lamp still had green leaves.',
 "Strong light at night can keep a tree's leaves on its branches longer.",
 'The other tree in the dark corner was already bare by then.'], pos=2,
 ch={0:'가로등 불빛은 밤길을 걷는 사람들을 안전하게 지켜 준다',
     1:'길가의 나무는 여름에 거리의 열기를 식혀 준다',
     2:'단풍나무는 햇빛을 많이 받을수록 더 붉게 물든다',
     3:'가로등 불빛은 나무의 잎을 더 빨리 떨어뜨린다',
     4:'밤에도 밝은 빛을 받는 나무는 잎이 늦게 진다'})
# O · 요지 셋째 · 정답 ④
I[3] = dict(S=['In May, Jiwon listened to the frogs in the rice field near her house.',
 'On cold and dry nights, she heard only a few quiet frogs.',
 'Frogs sing loudest on warm nights after a spring rain.',
 'After one rainy evening, the whole field was loud until midnight.'], pos=2,
 ch={0:'논은 여러 생물이 함께 사는 소중한 곳이다',
     1:'개구리는 해충을 잡아먹어 농사일을 돕는다',
     2:'개구리는 추운 밤에 더 많이 모여 크게 운다',
     3:'봄비가 그친 포근한 밤에 개구리 울음이 가장 커진다',
     4:'개구리는 사람이 가까이 오면 울음을 멈춘다'})
# R · 요지 넷째 · 정답 ③
I[4] = dict(S=['Most people picture penguins only on snow and ice near the South Pole.',
 'Last winter, Yuna saw a TV show about a warm island in the Pacific Ocean.',
 'Little penguins swam there in warm water under a hot sun.',
 'In fact, some kinds of penguins live in very warm places.'], pos=3,
 ch={0:'펭귄은 눈과 얼음이 있는 추운 곳에서만 산다',
     1:'펭귄은 날지 못하지만 물속에서는 아주 빠르다',
     2:'모든 펭귄이 추운 곳에서만 사는 것은 아니다',
     3:'펭귄은 따뜻한 물에서 오래 헤엄치면 쉽게 지친다',
     4:'펭귄은 무리를 지어 새끼를 함께 돌본다'})
# R · 요지 둘째 · 정답 ③
I[5] = dict(S=['Most people picture a chameleon as a master of hiding with its colors.',
 'In fact, a chameleon changes color mostly with its mood and body heat.',
 'At the city zoo, Haneul watched a bright green chameleon on a brown branch.',
 'Later, it turned dark red during a fight with another chameleon.'], pos=1,
 ch={0:'카멜레온은 주위와 같은 색으로 바꾸어 몸을 숨긴다',
     1:'카멜레온은 싸울 때 몸을 크게 부풀려 상대를 쫓는다',
     2:'카멜레온의 색은 주위보다 기분과 체온을 더 따른다',
     3:'카멜레온은 긴 혀로 먼 곳의 벌레를 잡는다',
     4:'카멜레온은 동물원보다 숲에서 색이 더 밝다'})
# O · 요지 넷째 · 정답 ②
I[6] = dict(S=['Seoyun put three pine cones on her window shelf last autumn.',
 'On dry and sunny days, the scales of the cones were wide open.',
 'On a rainy Tuesday, all three cones were tightly closed.',
 'A pine cone opens and closes with the water in the air.'], pos=3,
 ch={0:'솔방울은 집 안을 꾸미는 좋은 장식이 된다',
     1:'솔방울은 날씨가 습한지 건조한지에 따라 열리고 닫힌다',
     2:'솔방울은 씨앗을 멀리 퍼뜨리는 데 도움이 된다',
     3:'솔방울은 햇볕을 오래 받으면 단단하게 닫힌다',
     4:'솔방울은 가을보다 봄에 더 많이 떨어진다'})
# R · 요지 넷째 · 정답 ①
I[7] = dict(S=['An old hiking tip uses moss on a tree as a compass for north.',
 'Last summer, Doha tried this tip on a walk in a deep valley.',
 'Thick moss covered the south side of many trees near a stream.',
 'In fact, moss grows on any wet and shady side of a tree.'], pos=3,
 ch={0:'이끼는 방향과 상관없이 축축하고 그늘진 곳에 자란다',
     1:'나무에 낀 이끼를 보면 어느 쪽이 북쪽인지 쉽게 알 수 있다',
     2:'산길에서는 지도보다 해의 위치가 더 믿을 만하다',
     3:'이끼는 물가보다 햇볕이 드는 마른 바위 위에서 더 잘 자란다',
     4:'이끼는 숲의 흙이 마르지 않게 지켜 준다'})
# O · 요지 넷째 · 정답 ⑤
I[8] = dict(S=['Grandma Choi keeps ten hens in a small yard behind her house.',
 'In June, she found eight or nine eggs in the hen house every morning.',
 'By December, she found only three or four eggs each day.',
 'Hens lay fewer eggs during the short and dark days of winter.'], pos=3,
 ch={0:'닭은 넓은 마당에서 자유롭게 기를 때 더 건강하다',
     1:'갓 낳은 달걀은 그날 바로 거두는 것이 좋다',
     2:'닭은 먹이를 많이 줄수록 알을 더 많이 낳는다',
     3:'여름에는 닭이 더위 때문에 알을 덜 낳는다',
     4:'해가 짧은 철에는 닭이 낳는 알이 줄어든다'})
# R · 요지 첫째 · 정답 ①
I[9] = dict(S=['A sea turtle can swim much faster than most people in the water.',
 'Most people picture a turtle as a very slow animal from old stories.',
 'However, a big sea turtle at the Busan aquarium swam past a diver in seconds.',
 'Even the diver with long fins could not keep up with it.'], pos=0,
 ch={0:'바다거북은 물속에서는 사람보다 훨씬 날쌔다',
     1:'거북은 어디에서나 아주 느리게 움직이는 동물이다',
     2:'바다거북은 알을 낳으러 태어난 바닷가로 돌아온다',
     3:'잠수부는 오리발을 신으면 거북을 따라잡을 수 있다',
     4:'수족관의 거북은 바다의 거북보다 더 오래 산다'})
# 22번(요지) 레벨1 새 원고 — n=10~19 (학교 생활 · 동아리 · 운동 · 놀이 · 친구)
# R꼴 · 요지 둘째 · 숨바꼭질
I[10] = dict(S=['Most children pick a dark and tiny corner for a game of hide-and-seek.',
 'However, an open spot near the seeker often stays safe for the longest time.',
 "Last Friday, Doyun stood still right behind the seeker's tree in the playground.",
 'The seeker searched every dark corner and found Doyun last of all.'], pos=1,
 ch={0:'술래 바로 곁의 눈에 띄는 자리가 오히려 늦게 들킨다',
     1:'어둡고 좁은 구석일수록 술래에게 오래 들키지 않는다',
     2:'혼자 숨는 것보다 둘이 함께 숨을 때 훨씬 더 오래 버틴다',
     3:'둘이 함께 숨으면 소리가 나서 혼자일 때보다 빨리 들킨다',
     4:'술래는 숨은 아이의 발소리를 듣고 가장 쉽게 찾아낸다'})
# O꼴 · 요지 셋째 · 공 없는 쉬는 시간
I[11] = dict(S=['In May, the playground at our school had no balls for a whole week.',
 'On the first day, my classmates just sat on the benches and talked.',
 'Children with fewer toys often make up more new games on their own.',
 'By Friday, our class had a hopping game and a shadow tag game.'], pos=2,
 ch={0:'쉬는 시간에 뛰어노는 아이들이 수업에도 더 잘 집중한다',
     1:'친구들과 어울려 놀다 보면 반 분위기가 한결 밝아진다',
     2:'공놀이는 다른 놀이보다 많은 아이가 함께 즐길 수 있다',
     3:'쉬는 시간에는 친구와 이야기만 나누어도 충분히 즐겁다',
     4:'놀 거리가 적으면 아이들은 새 놀이를 스스로 지어낸다'})
# O꼴 · 요지 셋째 · 종이비행기 대회
I[12] = dict(S=['Our class held a paper plane contest in the gym last Thursday.',
 'Minji folded a small and plain plane from one thin sheet of paper.',
 'A light and simple plane often flies farther than a big and heavy one.',
 'Her plane flew twice as far as the big and colorful planes.'], pos=2,
 ch={0:'종이비행기는 세게 던질수록 더 멀리 날아간다',
     1:'종이비행기는 두꺼운 종이로 접어야 바람에도 잘 버틴다',
     2:'단순하고 가벼운 비행기가 화려한 것보다 멀리 난다',
     3:'종이비행기는 날개 끝을 살짝 올려 접으면 오래 떠 있다',
     4:'종이비행기는 여러 번 날려 보며 고칠 때 실력이 는다'})
# O꼴 · 요지 둘째 · 줄다리기
I[13] = dict(S=['Our class lost the tug-of-war against Class 3 twice in gym class.',
 'In tug-of-war, a shared rhythm matters more than strong arms.',
 "For the third game, all of us pulled together on our captain's call.",
 'With the same players in the same places, we won in ten seconds.'], pos=1,
 ch={0:'줄다리기는 힘센 아이를 맨 앞에 세울 때 이긴다',
     1:'두 번 져도 포기하지 않으면 끝내 이길 수 있다',
     2:'줄다리기는 힘센 아이를 맨 뒤에 세울 때 이긴다',
     3:'줄다리기는 힘보다 모두가 한 박자로 당기는 것이 중요하다',
     4:'경기에 진 뒤에도 서로 탓하지 않는 마음이 팀을 지킨다'})
# R꼴 · 요지 넷째 · 제기차기
I[14] = dict(S=['Most children kick a jegi high into the air for a long game.',
 'But a high kick often sends the jegi far away from the player.',
 'Last week, our PE teacher kept the jegi at knee height for eighty kicks.',
 'In jegichagi, low and soft kicks keep the jegi up much longer.'], pos=3,
 ch={0:'제기를 높이 차 올릴수록 다음 발차기가 쉬워진다',
     1:'제기는 낮고 부드럽게 찰수록 오래 이어 찰 수 있다',
     2:'제기는 한 발보다 두 발을 번갈아 쓸 때 오래 찬다',
     3:'제기는 두 발보다 한 발로만 찰 때 더 오래 찰 수 있다',
     4:'제기차기는 무거운 제기일수록 다루기가 쉽다'})
# R꼴 · 요지 첫째 · 윷놀이
I[15] = dict(S=['In yut nori, the choice of moves matters as much as the throw.',
 'Most people see the game as pure luck with four wooden sticks.',
 "Last New Year's Day, Grandpa got bad throws all through the game.",
 'Still, he used the short paths on the board and won two games.'], pos=0,
 ch={0:'윷놀이의 승패는 윷가락을 던지는 운에 달려 있다',
     1:'윷놀이는 여럿이 편을 나누어 할 때 더 재미있다',
     2:'윷가락은 높이 던질수록 좋은 결과가 나온다',
     3:'윷가락은 낮게 던질수록 좋은 결과가 나온다',
     4:'윷놀이는 던지기 못지않게 말을 어떻게 옮기는지가 중요하다'})
# R꼴 · 요지 둘째 · 피구
I[16] = dict(S=['Most dodgeball players run to the very back of the court for safety.',
 'In fact, the back line is often the most dangerous spot in dodgeball.',
 'Players at the back have no space for a quick side step.',
 "In yesterday's game, all five players at the back line got out first."], pos=1,
 ch={0:'피구에서 코트 맨 뒤는 생각보다 공에 맞기 쉬운 자리다',
     1:'피구에서는 코트 맨 뒤로 물러서야 공에 맞지 않고 오래 살아남는다',
     2:'피구에서는 공을 피하는 아이보다 받아 내는 아이가 오래 남는다',
     3:'피구에서는 혼자 떨어져 있을 때 공을 잘 피한다',
     4:'피구에서는 친구들과 붙어 있을 때 공을 잘 피한다'})
# R꼴 · 요지 넷째 · 단짝과 다른 반
I[17] = dict(S=["Most students hope for a seat in their best friend's class each March.",
 'This year, Seoyeon and Hayun went to different classes for the first time.',
 'By May, the two girls ate lunch together with four new classmates.',
 'In fact, separate classes often bring two old friends many new friends.'], pos=3,
 ch={0:'단짝 친구와 같은 반이 되어야 학교생활이 훨씬 즐겁다',
     1:'반이 갈리면 오랜 친구 사이도 점점 멀어진다',
     2:'새 학기에는 먼저 말을 거는 아이가 친구를 쉽게 사귄다',
     3:'단짝과 반이 갈리면 어울릴 친구가 오히려 늘어난다',
     4:'친구는 많기보다 마음이 맞는 한 명이 더 소중하다'})
# R꼴 · 요지 첫째 · 아래로 던지는 자유투
I[18] = dict(S=['An underhand free throw often goes in more than a normal shot.',
 'Most young players laugh at this old two-hand shot from below.',
 'Last winter, Junho tried the underhand shot in every practice for a month.',
 'His free throws went in eight times out of ten by February.'], pos=0,
 ch={0:'아래에서 던지는 자유투는 낡은 방식이라 잘 들어가지 않는다',
     1:'자유투는 빠르게 던질 때 더 잘 들어간다',
     2:'공을 밑에서 퍼 올리듯 던지면 자유투가 더 잘 들어간다',
     3:'자유투는 천천히 시간을 충분히 들여 던질 때 더 잘 들어간다',
     4:'키가 큰 선수일수록 자유투를 더 잘 넣는다'})
# O꼴 · 요지 둘째 · 배구부 주장
I[19] = dict(S=['Our volleyball team chose Yuna, our quietest player, as captain this spring.',
 'A good captain often listens more and talks less on the court.',
 'Yuna asked every teammate about their worries after each practice.',
 'By June, our team had won five games in a row.'], pos=1,
 ch={0:'좋은 주장은 누구보다 앞장서서 열심히 연습한다',
     1:'좋은 주장은 경기 중 큰 목소리로 팀을 이끈다',
     2:'남의 말을 귀담아듣는 주장이 팀을 잘 이끈다',
     3:'실력이 가장 뛰어난 선수가 주장을 맡아야 팀이 강해진다',
     4:'팀은 오래 함께 뛸수록 경기에서 손발이 잘 맞는다'})
# 22번(요지) 레벨1 새 원고 — n=20~29 (마을 · 가게 · 시장 · 도서관 · 집안일 · 요리 · 오래된 물건 · 가족 행사)
# 20 O 요지 셋째 · 정답 3 — 오래된 물건: 할아버지의 라디오
I[20] = dict(S=['My grandfather has listened to the same small radio for forty years.',
 'Last month, a repair shop in our town fixed its sound for ten dollars.',
 'An old machine with simple parts is often easy to fix.',
 'His new speaker broke last year and went straight into the trash.'], pos=2,
 ch={0:'아끼던 물건은 오래 쓸수록 더 소중해진다', 1:'새로 나온 기계일수록 고장이 덜 나는 편이다', 2:'동네 수리점은 큰 서비스 센터보다 더 친절하다', 3:'짜임이 단순한 옛 기계는 고쳐 쓰기가 쉽다', 4:'고치는 값이 비싸면 새 물건을 사는 편이 낫다'})
# 21 R 요지 첫째 · 정답 4 — 도서관: 책 말고 빌려주는 것
I[21] = dict(S=['A town library today lends much more than books to its visitors.',
 'Most people picture a library as a silent room full of old books.',
 'However, our town library lends board games, tools, and even cake pans.',
 'Last week, my father borrowed a long ladder from the library for the weekend.'], pos=0,
 ch={0:'도서관은 무엇보다 조용히 책을 읽는 곳이다', 1:'책은 빌려 읽기보다 사서 읽어야 오래 남는다', 2:'책은 사서 읽기보다 빌려 읽는 쪽이 돈이 덜 든다', 3:'동네 도서관은 주말보다 평일에 더 붐빈다', 4:'요즘 도서관은 책 말고도 여러 물건을 빌려준다'})
# 22 R 요지 넷째 · 정답 2 — 요리: 토마토와 냉장고
I[22] = dict(S=['Most families keep their tomatoes in the fridge with the other vegetables.',
 'However, my aunt keeps her tomatoes in a bowl on the kitchen table.',
 'Her tomatoes always taste sweeter than the cold ones from our fridge.',
 'In fact, cold air takes away much of the flavor of fresh tomatoes.'], pos=3,
 ch={0:'채소는 냉장고에 넣어 두어야 맛과 신선함이 오래간다', 1:'토마토는 익혀 먹을 때 영양이 더 많아진다', 2:'토마토는 차게 두면 제맛을 많이 잃는다', 3:'토마토는 덜 익은 것을 사서 집에서 익히는 편이 낫다', 4:'토마토는 날로 먹을 때 영양을 가장 많이 얻는다'})
# 23 O 요지 첫째 · 정답 4 — 집안일: 빨래 개기와 다림질
I[23] = dict(S=['A quick fold right after drying saves a lot of ironing later.',
 'My father once left our clean laundry in a basket for three days.',
 'Now he folds the shirts right off the drying rack every evening.',
 'Most of his shirts stay smooth for work without any ironing at all.'], pos=0,
 ch={0:'빨래는 바람이 잘 통하는 곳에 널어야 빨리 마른다', 1:'집안일은 가족이 나누어 맡을 때 덜 힘들다', 2:'옷은 뒤집어서 빨면 색이 덜 바랜다', 3:'빨래는 모아 두었다가 한꺼번에 하는 편이 낫다', 4:'마른 빨래를 바로 개면 다림질할 일이 줄어든다'})
# 24 O 요지 셋째 · 정답 3 — 시장: 문 닫을 무렵
I[24] = dict(S=['My mother and I went to the night market near our home on Friday.',
 'An hour before closing time, many sellers put big sale signs on their fruit.',
 'The last hour of a market is often the cheapest time for shoppers.',
 'We got two boxes of peaches for the price of one box.'], pos=2,
 ch={0:'전통 시장은 대형 마트보다 물건값이 훨씬 싸다', 1:'과일은 아침 일찍 사야 가장 싱싱하다', 2:'시장에서는 상인과 값을 흥정하는 재미가 있다', 3:'시장은 문 닫을 무렵에 물건값이 가장 싸진다', 4:'시장은 주말 낮보다 평일 저녁에 훨씬 덜 붐빈다'})
# 25 O 요지 셋째 · 정답 3 — 가족 행사: 추석 저녁의 카드놀이
I[25] = dict(S=['Our whole family played a simple card game after dinner on Chuseok.',
 'Even my quiet uncle laughed loudly with my little cousins all evening.',
 'An easy game brings old and young people closer than a long talk.',
 'At New Year, my grandmother asked for the same card game again.'], pos=2,
 ch={0:'명절에는 온 가족이 한자리에 모이는 것이 중요하다', 1:'어른과 대화를 많이 나눌수록 서로 사이가 가까워진다', 2:'명절 음식은 온 가족이 함께 만들 때 훨씬 더 맛있다', 3:'쉬운 놀이 하나가 나이 다른 가족을 가깝게 만든다', 4:'어른들은 새로운 놀이보다 옛 놀이를 더 좋아한다'})
# 26 O 요지 첫째 · 정답 1 — 가게: 한 가지만 파는 만두 가게
I[26] = dict(S=['A shop with only one special food can be busier than a big store.',
 'The tiny shop near our apartment sells only one kind of dumpling.',
 'Every afternoon, a long line of buyers waits in front of its window.',
 'The big restaurant across the street has fifty dishes and very few guests.'], pos=0,
 ch={0:'가게는 파는 음식의 종류가 많을수록 손님이 는다', 1:'한 가지 음식에 힘을 쏟은 가게가 더 붐빌 수 있다', 2:'만두는 갓 쪄서 따뜻할 때 가장 맛이 좋다', 3:'손님에게 친절한 가게일수록 단골이 늘어난다', 4:'가게는 값을 낮추어야 손님을 오래 붙잡을 수 있다'})
# 27 O 요지 둘째 · 정답 0 — 요리: 할머니의 손맛
I[27] = dict(S=['My grandmother never uses a measuring cup or spoon in her kitchen.',
 'Years of cooking often teach the hands better than any recipe book.',
 'She adds salt to her bean soup with three fingers every time.',
 'Her soup tastes exactly the same every winter for our whole family.'], pos=1,
 ch={0:'오래 요리한 사람의 손은 요리책보다 정확할 수 있다', 1:'요리를 처음 배울 때는 계량컵으로 재는 편이 안전하다', 2:'국은 소금을 적게 넣을수록 몸에 더 좋다', 3:'요리책대로 하면 누구나 같은 맛을 낼 수 있다', 4:'음식의 맛은 무엇보다 만드는 사람의 정성에서 우러나온다'})
# 28 R 요지 첫째 · 정답 1 — 오래된 물건: 증조할머니의 무쇠 팬
I[28] = dict(S=['An old iron pan often cooks eggs better than a new one.',
 'Many people throw away a pan with a dark and rough surface.',
 'However, that dark layer on an iron pan stops food from sticking.',
 'My mother still fries eggs in my great-grandmother\'s iron pan every morning.'], pos=0,
 ch={0:'겉이 까맣게 변한 프라이팬은 버리는 편이 더 안전하다', 1:'오래 길들인 무쇠 팬이 새 팬보다 요리가 잘 된다', 2:'무쇠 팬은 너무 무거워서 날마다 쓰기에 불편하다', 3:'새 팬은 기름을 조금만 둘러도 음식이 붙지 않는다', 4:'물려받은 물건에는 가족의 추억이 고스란히 담긴다'})
# 29 O 요지 넷째 · 정답 0 — 마을: 아파트 현관의 나눔 탁자
I[29] = dict(S=['Last spring, our apartment put a small table near the front door.',
 'Neighbors leave old toys, books, and pots on it for other families.',
 'Most of these things go to new homes within a day or two.',
 'One small table can give old things a second life in a neighborhood.'], pos=3,
 ch={0:'작은 나눔 자리 하나로 헌 물건이 다시 쓰인다', 1:'이웃과 물건을 나누다 보면 사이가 가까워진다', 2:'쓰지 않는 물건은 바로 버려야 집 안이 깔끔해진다', 3:'헌 물건보다 새 물건이 오래 쓰기에 더 좋다', 4:'물건을 아껴 쓰면 환경을 지키는 데 도움이 된다'})
