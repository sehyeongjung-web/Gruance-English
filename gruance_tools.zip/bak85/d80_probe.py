# 22번(요지) 레벨1 새 꼴 본보기 (꼴만 보고, 글감은 쓰지 말 것). 정답 자리는 바탕 그대로: n=0→1, n=2→4
I = {}
# R꼴: 흔한 생각을 글이 먼저 말하고 물리친 뒤 필자의 요지(셋째 문장)
I[0] = dict(S=['A popular story gives a goldfish a memory of only three seconds.',
 'Our class tested this idea with a small fish tank last spring.',
 'In fact, a goldfish can remember a feeding time for several months.',
 'After two weeks, our fish waited at the same corner every morning.'], pos=2,
 ch={0:'금붕어는 몇 초 지나면 본 것을 모두 잊어버린다', 1:'금붕어도 먹이 시간을 오래 기억할 수 있다', 2:'금붕어는 넓은 어항에서 더 오래 산다', 3:'금붕어는 사람의 얼굴을 알아보고 반긴다', 4:'금붕어는 아침보다 저녁에 먹이를 더 잘 먹는다'})
# O꼴: 겪은 일 · 본 것에서 필자가 끌어낸 요지(다섯째가 아니라 셋째 문장), 오답 가운데 똑같이 그럴듯한 말 둘
I[2] = dict(S=['Our school garden had many weeds and very few vegetables last year.',
 'This year each class took care of one small part of the garden.',
 'A small and clear job gets done much better than a big shared job.',
 'By June, every part of the garden was full of green beans and lettuce.'], pos=2,
 ch={0:'텃밭 가꾸기는 아이들에게 책임감을 길러 준다', 1:'채소는 잡초를 뽑아 주어야 잘 자란다', 2:'여럿이 함께하면 큰일도 빨리 끝낼 수 있다', 3:'텃밭은 봄보다 여름에 손이 더 많이 간다', 4:'일은 작게 나누어 맡기면 더 잘 된다'})
