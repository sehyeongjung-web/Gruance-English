# 22번(요지) 레벨1 여섯째 판 — n=20~29 「같은 틀, 다른 요인」 + 맞수 + 「이야기로 쓸 만한」 오답 둘 (뻔한 오답은 문항에 하나까지)
# 보기 다섯 = 「(요인)이면 (같은 결과)」 — 끝맺음 다섯 같게 · 장면 고유어 없음 · 「~보다」 없음 · 맞서는 짝 없음
# 이야기감 오답 둘 · 맞수 하나 · 나머지 하나 — 감사 흠 21 · 22 · 24 · 29 고침
I = {}
# 20 요지 셋째 · 정답 3 — 가게: 쿠키 병을 문 옆 낮은 선반으로 (감사 21: better spot → more visible spot · 잘 보이는 자리)
I[20] = dict(S=['Sujin sells cookies and bread at a small bakery on our street.',
 'Last month, she moved her cookie jars from a back shelf to the window.',
 'A small move to a more visible spot can raise the sales of a product.',
 'Since then, children on their way home buy twice as many cookies.'], pos=2,
 ch={0:'값을 조금 내려 주면 같은 물건도 더 잘 팔릴 수 있다', 1:'맛보기를 조금씩 나눠 주면 같은 물건도 더 잘 팔릴 수 있다', 2:'이름표를 손글씨로 써 붙이면 같은 물건도 더 잘 팔릴 수 있다', 3:'잘 보이는 자리로 옮기면 같은 물건도 더 잘 팔릴 수 있다', 4:'좋은 냄새가 가게에 가득하게 하면 같은 물건도 더 잘 팔릴 수 있다'})
# 21 요지 첫째 · 정답 4 — 도서관: 갈색 종이로 싼 옛 소설 (감사 22: A few words of mystery → A short mysterious hint)
I[21] = dict(S=['A short mysterious hint can make an old book interesting again.',
 'Our town library had many old novels on its back shelves.',
 'Last spring, a librarian put a short hint about a secret on each one.',
 'Within two weeks, readers took home almost every one of those books.'], pos=0,
 ch={0:'책 속 한 장면을 그림으로 걸어 두면 오래된 책도 다시 읽힐 수 있다', 1:'먼저 읽은 사람의 추천 글을 붙이면 오래된 책도 다시 읽힐 수 있다', 2:'다 읽은 사람에게 도장을 찍어 주면 오래된 책도 다시 읽힐 수 있다', 3:'쓴 사람의 삶을 짧게 소개하면 오래된 책도 다시 읽힐 수 있다', 4:'궁금증을 남기는 한마디를 붙이면 오래된 책도 다시 읽힐 수 있다'})
# 22 요지 넷째 · 정답 2 — 시장: 줄 선 가게와 빈 가게 (감사 23: ④ 끝맺음 맞춤 · 맞서는 짝 없앰)
I[22] = dict(S=['Two stalls at our night market sell the same rice cakes at the same price.',
 "Jiho's stall always has a long line in front of it.",
 'Every evening, new shoppers walk past the empty stall and join that line.',
 'A long line often pulls even more people toward a shop.'], pos=3,
 ch={0:'작은 종을 울려 손님을 부르면 손님이 더 몰려들 때가 많다', 1:'손님 앞에서 직접 만들어 보이면 손님이 더 몰려들 때가 많다', 2:'가게 앞에 사람들이 길게 서 있으면 손님이 더 몰려들 때가 많다', 3:'가게 이름을 재미있게 지으면 손님이 더 몰려들 때가 많다', 4:'맛있다는 소문이 퍼지면 손님이 더 몰려들 때가 많다'})
# 23 요지 첫째 · 정답 4 — 일터: 국숫집 일꾼 넷이 두 시간마다 일을 바꿈 (그대로)
I[23] = dict(S=['A regular change of tasks during the day can help workers make fewer mistakes.',
 'My aunt runs a busy noodle restaurant in our neighborhood.',
 'Before, her four workers did the same jobs all day and made ten mistakes daily.',
 'Now they switch jobs every two hours and make only three mistakes a day.'], pos=0,
 ch={0:'일하는 사람을 한 명 더 두면 일하는 사람의 실수가 줄어들 수 있다', 1:'주문을 큰 소리로 되풀이해 말하면 일하는 사람의 실수가 줄어들 수 있다', 2:'그날의 실수를 끝나고 함께 이야기하면 일하는 사람의 실수가 줄어들 수 있다', 3:'짧게 쉬는 시간을 자주 주면 일하는 사람의 실수가 줄어들 수 있다', 4:'맡은 일을 하루에도 여러 번 바꾸면 일하는 사람의 실수가 줄어들 수 있다'})
# 24 요지 셋째 · 정답 3 — 마을 행사: 운동장 장난감 장터에 그늘 의자 (감사 25: ⑤ 저녁 → 더위와 무관한 요인)
I[24] = dict(S=['Every May, our village has a market for old toys on the school field.',
 'Last year, most families left after only twenty minutes under the hot sun.',
 'A cool place for rest keeps visitors at an event much longer.',
 'This year, with chairs under the trees, most families stayed until the end.'], pos=2,
 ch={0:'물건마다 얽힌 이야기를 적어 두면 사람들이 행사에 훨씬 오래 머문다', 1:'끝날 때 줄 선물을 미리 알리면 사람들이 행사에 훨씬 오래 머문다', 2:'먹을거리 가게를 함께 열면 사람들이 행사에 훨씬 오래 머문다', 3:'시원하게 쉴 자리를 마련하면 사람들이 행사에 훨씬 오래 머문다', 4:'아이를 잠시 맡길 곳을 마련하면 사람들이 행사에 훨씬 오래 머문다'})
# 25 요지 셋째 · 정답 3 — 봉사: 강변길 청소 전후 사진 (감사 26: 지난번 사람들이 다시 왔다는 말)
I[25] = dict(S=["Few volunteers ever came back to clean the river path in Hana's town.",
 'Last month, the leader showed everyone photos of the path before and after the work.',
 'A clear look at the result brings volunteers back for more work.',
 'This month, every helper from last month came back for the cleanup.'], pos=2,
 ch={0:'일마다 짝을 바꿔 가며 하면 사람들이 봉사에 다시 나온다', 1:'일을 마치고 다 같이 밥을 먹으면 사람들이 봉사에 다시 나온다', 2:'고맙다는 인사를 꼭 전하면 사람들이 봉사에 다시 나온다', 3:'해낸 일을 눈으로 보여 주면 사람들이 봉사에 다시 나온다', 4:'맡을 일을 스스로 고르게 하면 사람들이 봉사에 다시 나온다'})
# 26 요지 첫째 · 정답 1 — 가게: 손님을 따라다니던 옷가게 주인 (맞서는 짝 없앰)
I[26] = dict(S=['Shoppers often buy more with a little space from the shop owner.',
 "Jiwoo's aunt runs a small clothing shop near the bus stop.",
 'Before, she followed every visitor around the shop with lots of advice.',
 'Now she stays at the counter and sells more clothes than before.'], pos=0,
 ch={0:'웃는 얼굴로 반갑게 맞이하면 손님이 더 많이 살 때가 많다', 1:'주인이 떨어져서 편히 보게 두면 손님이 더 많이 살 때가 많다', 2:'거울을 곳곳에 여러 개 두면 손님이 더 많이 살 때가 많다', 3:'입어 본 모습을 사진으로 찍어 주면 손님이 더 많이 살 때가 많다', 4:'값을 조금씩 깎아 주면 손님이 더 많이 살 때가 많다'})
# 27 요지 둘째 · 정답 0 — 마을: 쓰레기 쌓이던 회색 벽에 그림 (감사 28: 동네 → 한 곳)
I[27] = dict(S=['People in our town often threw trash next to an old gray wall.',
 'People take much better care of a beautiful place in their town.',
 'Last spring, art students painted flowers and birds all over the wall.',
 'Since then, nobody has left any trash near the wall.'], pos=1,
 ch={0:'한 곳을 아름답게 꾸미면 사람들이 그곳을 더 아끼고 돌본다', 1:'쓰레기통을 가까이 놓아두면 사람들이 그곳을 더 아끼고 돌본다', 2:'정다운 이름을 붙여 부르면 사람들이 그곳을 더 아끼고 돌본다', 3:'그곳에 얽힌 옛이야기를 알려 주면 사람들이 그곳을 더 아끼고 돌본다', 4:'밤에도 불을 환하게 밝히면 사람들이 그곳을 더 아끼고 돌본다'})
# 28 요지 첫째 · 정답 1 — 일터: 회의를 오후로 모은 사무실
I[28] = dict(S=['A quiet morning without meetings helps workers finish hard jobs.',
 'My mother works on a small office team of eight people.',
 'Last month, the team put all their meetings in the afternoon.',
 'Now most of the team finish their biggest jobs before lunch.'], pos=0,
 ch={0:'일하는 자리를 날마다 바꿔 앉으면 어려운 일도 잘 끝내게 된다', 1:'회의 없는 조용한 오전이 있으면 어려운 일도 잘 끝내게 된다', 2:'둘씩 짝을 지어 일을 나누면 어려운 일도 잘 끝내게 된다', 3:'할 일을 전날 미리 정해 두면 어려운 일도 잘 끝내게 된다', 4:'틈틈이 밖에 나가 잠깐 걸으면 어려운 일도 잘 끝내게 된다'})
# 29 요지 넷째 · 정답 0 — 시장: 보라색 당근 옆 수프 요리법 카드
I[29] = dict(S=["Few shoppers bought the purple carrots at Grandpa Choi's market stall.",
 'Last week, he put an easy soup recipe on a card beside them.',
 'By Saturday, every purple carrot on his table was gone.',
 'A new food sells better with a simple idea for its use.'], pos=3,
 ch={0:'쉬운 쓰임새를 알려 주면 낯선 먹거리도 잘 팔린다', 1:'값을 조금 내려 주면 낯선 먹거리도 잘 팔린다', 2:'직접 먹어 보게 하면 낯선 먹거리도 잘 팔린다', 3:'재미있는 이름을 새로 붙이면 낯선 먹거리도 잘 팔린다', 4:'익숙한 먹거리와 묶어 팔면 낯선 먹거리도 잘 팔린다'})
