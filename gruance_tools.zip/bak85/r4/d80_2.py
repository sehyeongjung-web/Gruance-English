# 22번(요지) 레벨1 넷째 판 — n=10~19 (학교 · 반 · 동아리 · 운동부 · 친구 사이 · 놀이)
# 꼴: 「한 장면, 다섯 교훈」 — 지어낸 사람 이야기 + 일반적인 교훈 문장 하나.
# 넷째 판: 「같은 틀, 다른 요인」 — 다섯 보기 모두 「(요인)이면 (같은 결과) 때가 많다」, 장면 고유의 물건 · 이름 · 숫자 없음,
#          「~보다」 없음, 맞서는 짝은 10 · 17 두 문항(정답이 짝의 한쪽). 감사 흠 11 · 14 · 16 · 17번째(n=10 · 13 · 15 · 16) 고침.
I = {}
# 모둠 과제 · 요지 둘째 · 맞서는 짝(덜 친한 ↔ 가장 친한), 정답이 짝의 한쪽
#   흠 11번째: 두 번 다 「group of four」로 넷 대 넷
I[10] = dict(S=['For the first project, Jiho worked in a group of four with his best friends.',
 'Less close classmates often work better together than best friends.',
 'The four boys talked about games all week and missed the due date.',
 'Next time, Jiho and three less close classmates finished their project two days early.'], pos=1,
 ch={0:'덜 친한 친구들과 모둠이 되면 과제가 잘될 때가 많다',
     1:'가장 친한 친구들끼리 모둠을 짜면 과제가 잘될 때가 많다',
     2:'모둠에 다른 반 친구를 한 명 넣으면 과제가 잘될 때가 많다',
     3:'서로 맡은 일을 날마다 바꾸어 보면 과제가 잘될 때가 많다',
     4:'잘하는 친구 한 명이 앞장서 이끌면 과제가 잘될 때가 많다'})
# 마술 동아리 홍보 · 요지 셋째
I[11] = dict(S=['Last spring, our magic club put twenty posters in the main hallway.',
 'Only two first graders joined the club in two weeks.',
 'A short live show often brings in more new members than many posters.',
 "After Seojun's short card trick in the same hallway, fifteen first graders joined the club."], pos=2,
 ch={0:'선배가 한 사람씩 찾아가 권하면 새 회원이 늘 때가 많다',
     1:'가입한 학생에게 작은 선물을 주면 새 회원이 늘 때가 많다',
     2:'가입하는 방법을 간단하게 하면 새 회원이 늘 때가 많다',
     3:'첫 모임을 쉽고 짧게 꾸며 두면 새 회원이 늘 때가 많다',
     4:'하는 일을 눈앞에서 짧게 보여 주면 새 회원이 늘 때가 많다'})
# 반 축구팀 골키퍼 · 요지 셋째
I[12] = dict(S=['Our class soccer team often blamed our goalkeeper Hyunwoo for every goal against us.',
 'Last month, every player took a turn in the goal for one game.',
 "Players often stop blaming a teammate after a turn in the teammate's position.",
 'Since then, nobody on our team has blamed Hyunwoo for a goal.'], pos=2,
 ch={0:'경기 뒤에 함께 장면을 돌려 보면 친구를 덜 탓할 때가 많다',
     1:'경기에서 자주 이기기 시작하면 친구를 덜 탓할 때가 많다',
     2:'그 친구의 자리를 한 번 맡아 보면 친구를 덜 탓할 때가 많다',
     3:'실수한 뒤에 다 함께 손뼉을 쳐 주면 친구를 덜 탓할 때가 많다',
     4:'서로의 좋은 점을 말해 보면 친구를 덜 탓할 때가 많다'})
# 다툰 두 친구 · 요지 둘째
#   흠 14번째: 쪽지뿐 아니라 말로 한 사과도 안 통했다고 고침
I[13] = dict(S=['Last Monday, Yuri and Sena had a big fight over a pink pen.',
 'A small job together often fixes a fight better than an apology.',
 "For three days, Yuri's apologies in notes and in words did not fix anything.",
 'After an hour of washing paint brushes together, the two girls were friends again.'], pos=1,
 ch={0:'다른 친구가 둘 사이에 들어 주면 다툰 사이가 풀릴 때가 많다',
     1:'며칠 동안 서로 떨어져 지내 보면 다툰 사이가 풀릴 때가 많다',
     2:'다툰 일을 우스운 그림으로 그려 보면 다툰 사이가 풀릴 때가 많다',
     3:'작은 일을 둘이 함께 해 보면 다툰 사이가 풀릴 때가 많다',
     4:'먼저 진심을 담아 사과하면 다툰 사이가 풀릴 때가 많다'})
# 쉬는 시간 술래잡기 · 요지 넷째
I[14] = dict(S=["At recess, the third graders never joined the sixth graders' tag game.",
 'Last week, the sixth graders gave the younger children two safe spots.',
 'Now about thirty children of all ages play the same tag game every day.',
 'A small change in the rules often lets many more children into a game.'], pos=3,
 ch={0:'모두를 반기는 분위기가 생기면 놀이에 끼는 아이가 늘 때가 많다',
     1:'놀이의 규칙을 조금 바꾸면 놀이에 끼는 아이가 늘 때가 많다',
     2:'놀이 자리를 넓은 곳으로 옮기면 놀이에 끼는 아이가 늘 때가 많다',
     3:'선생님이 함께 뛰어 주면 놀이에 끼는 아이가 늘 때가 많다',
     4:'큰 아이와 작은 아이가 짝을 지으면 놀이에 끼는 아이가 늘 때가 많다'})
# 야구부 연패 · 요지 첫째
#   흠 16번째: 추가 연습을 그만두고 진 경기마다 이야기했다고 씀
I[15] = dict(S=['A short talk about each loss often helps a team more than extra practice.',
 'Last fall, our baseball team practiced an extra hour daily and still lost four games.',
 'Then the team dropped the extra hour and talked about each loss instead.',
 'After that, the team won six of its next eight games.'], pos=0,
 ch={0:'날마다 연습 시간을 늘려 가면 팀의 성적이 오를 때가 많다',
     1:'경기에 나서는 선수를 새로 바꾸면 팀의 성적이 오를 때가 많다',
     2:'상대 팀의 경기를 미리 살펴 두면 팀의 성적이 오를 때가 많다',
     3:'코치가 더 엄하게 가르쳐 주면 팀의 성적이 오를 때가 많다',
     4:'진 경기마다 짧게 함께 돌아보면 팀의 성적이 오를 때가 많다'})
# 수줍은 전학생 · 요지 둘째
#   흠 17번째: kind words → praise(우리말 「칭찬」과 맞춤)
I[16] = dict(S=['Our new classmate Ara hardly spoke a word for her first month.',
 'A chance to teach others often builds more confidence than praise.',
 'Praise from the teacher and classmates did not change Ara much.',
 'After her short lesson on paper flowers for the class, Ara chatted with everyone.'], pos=1,
 ch={0:'남을 가르쳐 볼 기회가 생기면 수줍은 아이가 자신감을 얻을 때가 많다',
     1:'주위에서 칭찬을 자주 해 주면 수줍은 아이가 자신감을 얻을 때가 많다',
     2:'어린 동생들을 돌보는 일을 맡으면 수줍은 아이가 자신감을 얻을 때가 많다',
     3:'반에서 기록하는 일을 맡으면 수줍은 아이가 자신감을 얻을 때가 많다',
     4:'시간이 넉넉히 흐르면 수줍은 아이가 자신감을 얻을 때가 많다'})
# 독서 동아리 모임 · 요지 넷째 · 맞서는 짝(짧게 매주 ↔ 길게 달마다), 정답이 짝의 한쪽
I[17] = dict(S=['Last year, our book club met for twenty minutes every Friday.',
 'Most members finished only one book in the whole year.',
 'With one two-hour meeting each month this year, most members finished eight books.',
 'For a book club, a long monthly meeting often works better than short weekly ones.'], pos=3,
 ch={0:'짧게라도 자주 모이면 회원들이 끝내는 책이 늘 때가 많다',
     1:'읽을 책을 다 함께 고르면 회원들이 끝내는 책이 늘 때가 많다',
     2:'모임마다 간식 당번을 정하면 회원들이 끝내는 책이 늘 때가 많다',
     3:'한 달에 한 번 길게 모이면 회원들이 끝내는 책이 늘 때가 많다',
     4:'읽은 쪽수를 날마다 적어 두면 회원들이 끝내는 책이 늘 때가 많다'})
# 운동회 달리기 응원 · 요지 첫째
I[18] = dict(S=["A cheer with a runner's own name often gives more strength than loud shouting.",
 'On sports day, our whole class shouted loudly for Eunji in the long race.',
 'Eunji heard only noise and stayed in fifth place for two laps.',
 'On the last lap, Eunji heard her name from two friends and passed three runners.'], pos=0,
 ch={0:'응원하는 글을 크게 적어 들어 주면 달리는 친구가 힘을 낼 때가 많다',
     1:'출발 직전에 손을 꼭 잡아 주면 달리는 친구가 힘을 낼 때가 많다',
     2:'그 친구의 이름을 불러 응원하면 달리는 친구가 힘을 낼 때가 많다',
     3:'결승선 가까이에 서서 기다려 주면 달리는 친구가 힘을 낼 때가 많다',
     4:'반 전체가 한목소리로 응원하면 달리는 친구가 힘을 낼 때가 많다'})
# 교실 자리 바꾸기 · 요지 둘째
I[19] = dict(S=['Last year, Junha sat in the same seat for the whole school year.',
 'A new seat every month often brings a student many more friends in class.',
 'Back then, Junha became close with only his desk partner, Siwoo.',
 'With a new seat every month this year, Junha has eight close friends.'], pos=1,
 ch={0:'먼저 다가가 말을 걸어 보면 반에서 친구가 늘 때가 많다',
     1:'교실 한가운데 자리에 앉으면 반에서 친구가 늘 때가 많다',
     2:'앉는 자리를 자주 바꾸어 보면 반에서 친구가 늘 때가 많다',
     3:'맡은 일이 하나 생기면 반에서 친구가 늘 때가 많다',
     4:'모둠 활동을 자주 하게 되면 반에서 친구가 늘 때가 많다'})
