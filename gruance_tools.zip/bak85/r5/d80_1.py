# 22번(글의 요지) 레벨1 새 원고 다섯째 판 (맞수 오답) — n=0~9 (글감: 가족 · 친척 · 이웃 · 집안 행사)
# 꼴: 「같은 틀, 다른 요인」 — 다섯 보기 모두 「(요인)하면 (같은 결과)」, 장면 고유의 물건 · 이름 · 숫자 · 「~보다」 없음
I = {}
# 김장 날 노래 · 요지 셋째 · 정답 ②
I[0] = dict(S=["Every November, my aunts make kimchi for the whole year at Grandma's house.",
 'This year, the whole family sang old songs together during the long work.',
 'Singing together can make a long and hard job feel much shorter.',
 'To our surprise, the eight hours of work passed like one short morning.'], pos=2,
 ch={0:'재미있는 이야기를 나누며 하면 길고 힘든 일도 짧게 느껴질 수 있다',
     1:'다 함께 노래를 부르며 하면 길고 힘든 일도 짧게 느껴질 수 있다',
     2:'끝나는 시각을 미리 정해 두면 길고 힘든 일도 짧게 느껴질 수 있다',
     3:'일을 잘게 나누어 맡으면 길고 힘든 일도 짧게 느껴질 수 있다',
     4:'중간중간 쉬어 가며 하면 길고 힘든 일도 짧게 느껴질 수 있다'})
# 윗집 소음 · 요지 둘째 · 정답 ②
I[1] = dict(S=["Last spring, Minji's family left a polite note about noise on the upstairs door.",
 'A short talk in person solves a problem better than a note on paper.',
 'The note did not stop the loud footsteps at night for weeks.',
 "After a short talk between Minji's mom and the upstairs family, the noise soon stopped."], pos=1,
 ch={0:'관리하는 분께 대신 말해 달라고 하면 문제가 잘 풀린다',
     1:'얼굴을 마주하고 짧게 이야기하면 문제가 잘 풀린다',
     2:'서두르지 않고 며칠 지켜보면 문제가 잘 풀린다',
     3:'서로 한 발씩 물러서면 문제가 잘 풀린다',
     4:'상대의 처지를 먼저 헤아려 보면 문제가 잘 풀린다'})
# 신발 끈 배우기 · 요지 셋째 · 정답 ⑤
I[2] = dict(S=['For a week, Mom tried to teach my brother Siwoo to tie his shoes.',
 'Six-year-old Siwoo gave up every day with tears in his eyes.',
 'Young children often learn a new skill faster from a slightly older child.',
 'In one afternoon, Siwoo learned it from his eight-year-old cousin Yejin.'], pos=2,
 ch={0:'순서를 그림으로 그려 보여 주면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     1:'날마다 조금씩 연습하게 하면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     2:'노래에 맞춰 순서를 외우게 하면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     3:'잘한 점을 듬뿍 칭찬해 주면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     4:'조금 큰 아이가 가르쳐 주면 어린아이가 새 기술을 빨리 익힐 때가 많다'})
# 가족 여행 계획 · 요지 셋째 · 정답 ④ (감사 흠 4: 지난 여행과 견주는 말을 넷째 문장에)
I[3] = dict(S=['For years, Dad planned every part of our summer trip by himself.',
 'This year, my sister and I picked two places for the trip ourselves.',
 'Children enjoy a trip more with a say in the places to visit.',
 'For both of us, it was the most fun of all our summer trips.'], pos=2,
 ch={0:'몸으로 해 보는 체험을 일정에 넣으면 아이들이 여행을 더 즐긴다',
     1:'일정을 느슨하게 짜서 쉴 틈을 주면 아이들이 여행을 더 즐긴다',
     2:'친하게 지내는 가족과 함께 떠나면 아이들이 여행을 더 즐긴다',
     3:'가 볼 곳을 고르는 데 함께하게 하면 아이들이 여행을 더 즐긴다',
     4:'붐비지 않는 때를 골라 떠나면 아이들이 여행을 더 즐긴다'})
# 옆집 사다리 · 요지 넷째 · 정답 ③ (감사 흠 5: 「작은 부탁」 → 「작은 도움을 주고받으면」)
I[4] = dict(S=["Last spring, the man next door borrowed Dad's ladder for a day.",
 'He brought it back the next morning with a big smile and thanks.',
 'Now the two families chat in the hall and share dinner once a month.',
 'A small favor between neighbors can be the start of a close friendship.'], pos=3,
 ch={0:'같은 취미를 함께 즐기면 이웃과 가까운 사이가 될 수 있다',
     1:'아이들끼리 자주 어울려 놀면 이웃과 가까운 사이가 될 수 있다',
     2:'작은 부탁을 기꺼이 들어주면 이웃과 가까운 사이가 될 수 있다',
     3:'오가며 인사를 꼬박꼬박 나누면 이웃과 가까운 사이가 될 수 있다',
     4:'반가운 마음에 작은 선물을 건네면 이웃과 가까운 사이가 될 수 있다'})
# 할머니 생신의 옛 사진 · 요지 둘째 · 정답 ③
I[5] = dict(S=["At Grandma's seventieth birthday party, we put old family photos on the big TV.",
 'Old photos can bring out many stories from older family members.',
 'Grandma told a long story about each photo until late at night.',
 'Even our uncles heard many of her stories for the first time.'], pos=1,
 ch={0:'자라신 고향을 함께 찾아가면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     1:'손주가 먼저 이것저것 여쭈면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     2:'옛 가족사진을 함께 보면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     3:'옛날에 즐겨 듣던 노래를 함께 들으면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     4:'좋아하시는 음식을 차리면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다'})
# 명절 게임 다툼 · 요지 넷째 · 정답 ②
I[6] = dict(S=["Every Chuseok, my four young cousins fought over Grandpa's old video game.",
 'This year, Uncle Jinho set a kitchen timer for fifteen minutes per player.',
 'There was not a single fight during the whole holiday.',
 'A clear rule about turns can stop most fights among children.'], pos=3,
 ch={0:'다 함께 하는 놀이로 바꿔 주면 아이들의 다툼을 대부분 막을 수 있다',
     1:'차례를 분명하게 정해 주면 아이들의 다툼을 대부분 막을 수 있다',
     2:'서로 양보하는 법을 가르치면 아이들의 다툼을 대부분 막을 수 있다',
     3:'어른이 곁에서 지켜보면 아이들의 다툼을 대부분 막을 수 있다',
     4:'놀잇감을 하나 더 마련해 주면 아이들의 다툼을 대부분 막을 수 있다'})
# 할아버지 영상 통화 · 요지 넷째 · 정답 ①
I[7] = dict(S=['Last winter, I showed Grandpa the steps for a video call on his phone.',
 'By the next morning, Grandpa forgot every step of my long explanation.',
 'Now, with my small card of steps in big letters, he calls us every Sunday.',
 'For older people, steps on paper work better than a long explanation.'], pos=3,
 ch={0:'쓰는 순서를 종이에 적어 드리면 어르신들도 새 기능을 잘 익히신다',
     1:'여러 번 되풀이해 보여 드리면 어르신들도 새 기능을 잘 익히신다',
     2:'또래 친구분과 함께 배우시게 하면 어르신들도 새 기능을 잘 익히신다',
     3:'쓸 일을 날마다 만들어 드리면 어르신들도 새 기능을 잘 익히신다',
     4:'손수 눌러 보시도록 기다려 드리면 어르신들도 새 기능을 잘 익히신다'})
# 여행 간 사이 빈집 · 요지 넷째 · 정답 ⑤
I[8] = dict(S=["Last August, Hayun's family went to Jeju Island for a week.",
 'Before the trip, they told Grandma Choi next door their travel dates.',
 'On the third day, she noticed water under their front door and called them.',
 'A neighbor with your travel dates can protect your empty house from trouble.'], pos=3,
 ch={0:'문단속을 몇 번이고 확인해 두면 빈집에 생기는 탈을 막을 수 있다',
     1:'방마다 불을 몇 개 켜 두고 떠나면 빈집에 생기는 탈을 막을 수 있다',
     2:'오는 우편물을 미리 멈춰 두면 빈집에 생기는 탈을 막을 수 있다',
     3:'밖에서도 집 안을 살필 수 있게 해 두면 빈집에 생기는 탈을 막을 수 있다',
     4:'집 비우는 날을 이웃에게 알려 두면 빈집에 생기는 탈을 막을 수 있다'})
# 사촌 결혼식 · 요지 첫째 · 정답 ①
I[9] = dict(S=['Even at a long event, a child with a small job rarely gets bored.',
 "At my cousin's wedding last spring, the ceremony went on for two hours.",
 'Our aunt gave my little sister Yeseo a small camera for photos of the guests.',
 'Yeseo took photos with a big smile until the very end of the ceremony.'], pos=0,
 ch={0:'작은 일을 하나 맡겨 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     1:'좋아하는 간식을 넉넉히 챙겨 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     2:'행사 순서를 미리 알려 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     3:'그림책을 한 권 쥐여 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     4:'또래 친구와 나란히 앉혀 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다'})
