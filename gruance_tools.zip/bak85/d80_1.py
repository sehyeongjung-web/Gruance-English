# 22번(글의 요지) 레벨1 새 원고 둘째 판 — n=0~9 (글감: 가족 · 친척 · 이웃 · 집안 행사)
# 꼴: 「한 장면, 다섯 교훈」 — 겪은 일 세 문장 + 요지 문장 하나, 보기 다섯은 같은 장면에서 끌어낼 법한 교훈
I = {}
# 김장 날 노래 · 요지 셋째 · 정답 ②
I[0] = dict(S=["Every November, my aunts make kimchi for the whole year at Grandma's house.",
 'This year, the whole family sang old songs together during the long work.',
 'Singing together can make a long and hard job feel much shorter.',
 'To our surprise, the eight hours of work passed like one short morning.'], pos=2,
 ch={0:'일을 작게 나누어 맡으면 훨씬 빨리 끝난다',
     1:'함께 노래를 부르면 긴 일도 짧게 느껴진다',
     2:'좋은 도구를 갖추면 힘든 일도 한결 쉬워진다',
     3:'아침 일찍 시작하면 일을 여유 있게 마친다',
     4:'일이 끝난 뒤의 기쁨을 떠올리면 힘이 난다'})
# 윗집 소음 · 요지 둘째 · 정답 ② (맞서는 짝: 쪽지 ↔ 직접 — 정답이 한쪽)
I[1] = dict(S=["Last spring, Minji's family left a polite note about noise on the upstairs door.",
 'A short talk in person solves a problem better than a note on paper.',
 'The note did not stop the loud footsteps at night for weeks.',
 "After a short talk with Minji's mom at their door, the noise soon stopped."], pos=1,
 ch={0:'쪽지로 차분히 알리면 얼굴 붉힐 일 없이 풀린다',
     1:'쪽지보다 직접 만나 말할 때 문제가 잘 풀린다',
     2:'관리실에 알리면 이웃 사이의 문제가 쉽게 풀린다',
     3:'평소에 인사를 자주 나누면 이웃과 다툴 일이 적다',
     4:'서로 조금씩 참으면 이웃과 사이좋게 지낼 수 있다'})
# 신발 끈 배우기 · 요지 셋째 · 정답 ⑤ (맞서는 짝: 어른 ↔ 조금 큰 아이 — 정답이 한쪽)
I[2] = dict(S=['For a week, Mom tried to teach my brother Siwoo to tie his shoes.',
 'Six-year-old Siwoo gave up every day with tears in his eyes.',
 'Young children often learn a new skill faster from a slightly older child.',
 'In one afternoon, Siwoo learned it from his eight-year-old cousin Yejin.'], pos=2,
 ch={0:'어른이 차근차근 가르쳐야 아이가 제대로 배운다',
     1:'날마다 조금씩 연습하면 결국 혼자 해낼 수 있다',
     2:'칭찬을 자주 해 주면 아이가 더 빨리 배운다',
     3:'그림으로 순서를 보여 주면 아이가 쉽게 익힌다',
     4:'아이는 조금 큰 아이에게서 더 빨리 배운다'})
# 가족 여행 계획 · 요지 셋째 · 정답 ④ (맞서는 짝: 가까운 곳 ↔ 먼 곳 — 둘 다 오답)
I[3] = dict(S=['For years, Dad planned every part of our summer trip by himself.',
 'This year, my sister and I picked two places for the trip ourselves.',
 'A trip is more fun for children with their own choices in the plan.',
 'We talked about our two places for weeks and loved every minute there.'], pos=2,
 ch={0:'가까운 곳으로 떠나는 여행이 덜 지치고 즐겁다',
     1:'멀리 떠난 여행일수록 더 오래 기억에 남는다',
     2:'여행 날짜를 미리 정해 두면 돈이 덜 든다',
     3:'계획을 직접 고른 아이는 여행을 더 즐긴다',
     4:'사진을 많이 찍어 두면 여행이 오래 기억된다'})
# 옆집 사다리 · 요지 넷째 · 정답 ③ (맞서는 짝: 오래 산 이웃 ↔ 새로 온 이웃 — 둘 다 오답)
I[4] = dict(S=["Last month, the man next door borrowed Dad's ladder for one afternoon.",
 'He brought it back the next morning with a big smile and thanks.',
 'Now the two families chat in the hall and share dinner once a month.',
 'A small favor between neighbors can be the start of a close friendship.'], pos=3,
 ch={0:'한 동네에 오래 살아야 이웃과 정이 든다',
     1:'새로 이사 온 사람일수록 이웃과 쉽게 친해진다',
     2:'작은 부탁이 이웃과 친해지는 첫걸음이 된다',
     3:'아이들이 함께 놀다 보면 어른들도 가까워진다',
     4:'취미가 같은 이웃과는 금방 친구가 될 수 있다'})
# 할머니 생신의 옛 사진 · 요지 둘째 · 정답 ③
I[5] = dict(S=["At Grandma's seventieth birthday party, we put old family photos on the big TV.",
 'Old photos can bring out many stories from older family members.',
 'Grandma told a long story about each photo until late at night.',
 'Even our uncles heard many of her stories for the first time.'], pos=1,
 ch={0:'비싼 선물보다 정성 어린 선물이 더 큰 기쁨을 준다',
     1:'생일잔치는 온 가족이 모이기 쉬운 주말이 좋다',
     2:'옛날 사진은 어른들의 지난 이야기를 끌어낸다',
     3:'맛있는 음식이 있으면 잔치 분위기가 밝아진다',
     4:'어른들은 손주들이 곁에 있을 때 가장 행복하다'})
# 명절 게임 다툼 · 요지 넷째 · 정답 ②
I[6] = dict(S=["Every Chuseok, my four young cousins fought over Grandpa's only video game.",
 'This year, Uncle Jinho set a kitchen timer for fifteen minutes per player.',
 'There was not a single fight during the whole holiday.',
 'A clear rule about turns can stop most fights among children.'], pos=3,
 ch={0:'장난감을 하나 더 마련하면 다툼이 금방 사라진다',
     1:'차례를 분명히 정해 주면 아이들 다툼이 줄어든다',
     2:'아이들끼리 스스로 풀게 두면 다툼은 저절로 끝난다',
     3:'밖에서 뛰어놀게 하면 아이들이 다툴 일이 줄어든다',
     4:'형이 동생에게 먼저 양보하면 집안이 화목해진다'})
# 할아버지 영상 통화 · 요지 넷째 · 정답 ①
I[7] = dict(S=['Last winter, I showed Grandpa the steps for a video call on his phone.',
 'By the next morning, Grandpa forgot every step of my long explanation.',
 'Now, with my small card of steps in big letters, he calls us every Sunday.',
 'For older people, steps on paper work better than a long explanation.'], pos=3,
 ch={0:'어른들께는 긴 설명보다 종이에 적은 순서가 낫다',
     1:'여러 번 되풀이해 보여 드리면 결국 익히신다',
     2:'또래 친구에게 배우면 어른들도 편하게 익히신다',
     3:'쉬운 기계부터 써 보시면 새 기계에도 익숙해진다',
     4:'서두르지 않고 기다려 드리면 스스로 해내신다'})
# 여행 간 사이 빈집 · 요지 넷째 · 정답 ⑤
I[8] = dict(S=["Last August, Hayun's family went to Jeju Island for a week.",
 'Before the trip, they told Grandma Choi next door their travel dates.',
 'On the third day, she noticed water under their front door and called them.',
 'A neighbor with your travel dates can protect your empty house from trouble.'], pos=3,
 ch={0:'비싼 잠금장치를 달면 빈집도 마음 놓고 비울 수 있다',
     1:'여행은 짧게 다녀오면 집 걱정이 줄어든다',
     2:'열쇠를 가족 모두가 가지면 급할 때 편하다',
     3:'빈집에 불을 켜 두면 도둑 걱정을 덜 수 있다',
     4:'일정을 알려 둔 이웃이 빈집을 지켜 줄 수 있다'})
# 사촌 결혼식 · 요지 첫째 · 정답 ①
I[9] = dict(S=['Even at a long event, a child with a small job rarely gets bored.',
 "At my cousin's wedding last spring, the ceremony went on for two hours.",
 'Our aunt asked my little sister Yeseo to hand out flowers at the door.',
 'Yeseo smiled and worked happily until the very end of the ceremony.'], pos=0,
 ch={0:'맡은 일이 있는 아이는 긴 행사도 지루해하지 않는다',
     1:'아이들은 짧은 행사에만 데려가야 덜 힘들어한다',
     2:'간식을 챙겨 가면 아이가 오래 얌전히 기다린다',
     3:'또래 친구가 곁에 있으면 아이가 덜 심심해한다',
     4:'행사 순서를 미리 알려 주면 아이가 차분히 따른다'})
