I = {}
# 22번(글의 요지) 레벨1 새 원고 일곱째 판 (정답 맞바꾸기: n=0·2·4·5·8) — n=0~9 (글감: 가족 · 친척 · 이웃 · 집안 행사)
# 꼴: 「같은 틀, 다른 요인」 — 다섯 보기 모두 「(요인)하면 (같은 결과)」, 장면 고유의 물건 · 이름 · 숫자 · 「~보다」 없음
# 김장 날 맡은 일 바꾸기 · 요지 셋째 · 정답 ② (일곱째 판 맞바꿈: 옛 정답 「노래」 → ①)
I[0] = dict(S=["Every November, my aunts make kimchi for the whole year at Grandma's house.",
 'This year, each of us took a different task every hour during the long day.',
 'A new task every hour can make a long and hard job feel much shorter.',
 'To our surprise, the eight hours of work passed like one short morning.'], pos=2,
 ch={0:'다 함께 신나는 노래를 크게 부르며 하면 길고 힘든 일도 짧게 느껴질 수 있다',
     1:'일을 한 시간마다 바꿔 맡으며 하면 길고 힘든 일도 짧게 느껴질 수 있다',
     2:'재미있는 옛이야기를 서로 나누며 하면 길고 힘든 일도 짧게 느껴질 수 있다',
     3:'편을 나누어 겨루며 하면 길고 힘든 일도 짧게 느껴질 수 있다',
     4:'끝나는 시각을 정해 두면 길고 힘든 일도 짧게 느껴질 수 있다'})
# 윗집 소음 · 요지 둘째 · 정답 ②
I[1] = dict(S=["Last spring, Minji's family left a polite note about noise on the upstairs door.",
 'A short talk in person solves a problem better than a note on paper.',
 'The note did not stop the loud footsteps at night for weeks.',
 "After a short talk between Minji's mom and the upstairs family, the noise soon stopped."], pos=1,
 ch={0:'소리가 난 때를 날마다 적어 두면 문제가 잘 풀린다',
     1:'얼굴을 마주하고 짧게 이야기하면 문제가 잘 풀린다',
     2:'아이들끼리 먼저 사귀게 하면 문제가 잘 풀린다',
     3:'관리하는 분께 말해 두면 문제가 잘 풀린다',
     4:'상대의 처지를 헤아려 보면 문제가 잘 풀린다'})
# 신발 끈 배우기(인형에게 가르치기) · 요지 셋째 · 정답 ⑤ (일곱째 판 맞바꿈: 옛 정답 「조금 큰 아이」 → ①)
I[2] = dict(S=['For a week, Mom tried to teach my brother Siwoo to tie his shoes.',
 'Six-year-old Siwoo gave up every day with tears in his eyes.',
 'Young children often learn a new skill faster with a toy as their student.',
 'Then Siwoo showed the steps to his teddy bear and learned them in one afternoon.'], pos=2,
 ch={0:'조금 큰 아이가 가르쳐 주면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     1:'날마다 조금씩 연습하게 하면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     2:'노래에 맞춰 순서를 하나씩 외우게 하면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     3:'순서를 그림으로 보여 주면 어린아이가 새 기술을 빨리 익힐 때가 많다',
     4:'인형에게 직접 가르쳐 보게 하면 어린아이가 새 기술을 빨리 익힐 때가 많다'})
# 가족 여행 계획 · 요지 셋째 · 정답 ④
I[3] = dict(S=['For years, Dad planned every part of our summer trip by himself.',
 'This year, my sister and I picked two places for the trip ourselves.',
 'Children enjoy a trip more with a say in the places to visit.',
 'For both of us, it was the most fun of all our summer trips.'], pos=2,
 ch={0:'몸으로 해 보는 체험을 넣으면 아이들이 여행을 더 즐긴다',
     1:'지도를 들고 길 안내를 맡기면 아이들이 여행을 더 즐긴다',
     2:'용돈을 맡겨 직접 쓰게 하면 아이들이 여행을 더 즐긴다',
     3:'가 볼 곳을 고르는 데 함께하게 하면 아이들이 여행을 더 즐긴다',
     4:'붐비지 않는 때에 떠나면 아이들이 여행을 더 즐긴다'})
# 옆집과 옥상 텃밭 · 요지 넷째 · 정답 ③ (일곱째 판 맞바꿈: 옛 정답 「작은 부탁」 → ④, 글에 부탁이 없어 favor 방향 흠도 사라짐)
I[4] = dict(S=['Last spring, Dad and the man next door started a small vegetable garden together.',
 'All summer, the two men watered the plants on the roof every evening.',
 'Now the two families eat dinner together at least once a month.',
 'Time together in a small garden can turn neighbors into close friends.'], pos=3,
 ch={0:'반상회에 빠짐없이 나가면 이웃과 가까운 사이가 될 수 있다',
     1:'아이들끼리 자주 어울려 놀면 이웃과 가까운 사이가 될 수 있다',
     2:'작은 텃밭을 함께 가꾸면 이웃과 가까운 사이가 될 수 있다',
     3:'작은 부탁 하나를 들어주면 이웃과 가까운 사이가 될 수 있다',
     4:'오가며 인사를 꼬박꼬박 나누면 이웃과 가까운 사이가 될 수 있다'})
# 할머니 고향 찾기 · 요지 둘째 · 정답 ③ (일곱째 판 맞바꿈: 옛 정답 「옛 사진」 → ①)
I[5] = dict(S=["For Grandma's seventieth birthday, the whole family visited her small hometown by the sea.",
 'A visit to an old hometown can bring out many stories from older family members.',
 'Grandma told a long story about each street and house until late at night.',
 'Even our uncles heard many of her stories for the first time.'], pos=1,
 ch={0:'옛 가족사진을 함께 보면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     1:'손주가 먼저 여쭈면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     2:'자라신 고향을 함께 찾아가면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     3:'어릴 적 놀이를 함께 해 보면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다',
     4:'옛 노래를 함께 들으면 집안 어른들이 지난 이야기를 많이 꺼낼 수 있다'})
# 명절 게임 다툼 · 요지 넷째 · 정답 ②
I[6] = dict(S=["Every Chuseok, my four young cousins fought over Grandpa's old video game.",
 'This year, Uncle Jinho set a kitchen timer for fifteen minutes per player.',
 'There was not a single fight during the whole holiday.',
 'A clear rule about turns can stop most fights among children.'], pos=3,
 ch={0:'맏이에게 심판을 맡기면 아이들의 다툼을 대부분 막을 수 있다',
     1:'차례를 분명하게 정해 주면 아이들의 다툼을 대부분 막을 수 있다',
     2:'서로 양보하는 법을 가르치면 아이들의 다툼을 대부분 막을 수 있다',
     3:'다투면 그날 놀이를 멈추게 하면 아이들의 다툼을 대부분 막을 수 있다',
     4:'놀잇감을 하나 더 마련하면 아이들의 다툼을 대부분 막을 수 있다'})
# 할아버지 영상 통화 · 요지 넷째 · 정답 ①
I[7] = dict(S=['Last winter, I showed Grandpa the steps for a video call on his phone.',
 'By the next morning, Grandpa forgot every step of my long explanation.',
 'Now, with my small card of steps in big letters, he calls us every Sunday.',
 'For older people, steps on paper work better than a long explanation.'], pos=3,
 ch={0:'쓰는 순서를 종이에 적어 드리면 어르신들도 새 기능을 잘 익히신다',
     1:'여러 번 되풀이해 보여 드리면 어르신들도 새 기능을 잘 익히신다',
     2:'또래 친구분과 함께 배우시게 하면 어르신들도 새 기능을 잘 익히신다',
     3:'쓸 일을 날마다 만들어 드리면 어르신들도 새 기능을 잘 익히신다',
     4:'손수 눌러 보시도록 기다려 드리면 어르신들도 새 기능을 잘 익히신다'})
# 여행 간 사이 빈집(부엌 카메라) · 요지 넷째 · 정답 ⑤ (일곱째 판 맞바꿈: 옛 정답 「이웃에게 날짜 알리기」 → ④ · 감사 흠 9: 「He watched … every evening」 단문으로 연결)
I[8] = dict(S=["Before a trip to Jeju last August, Hayun's dad put a camera in the kitchen.",
 'He watched the kitchen on his phone every evening of the trip.',
 'On the third evening, he saw water on the floor and called the building manager.',
 'A view into your home from far away can protect an empty house from trouble.'], pos=3,
 ch={0:'문단속을 몇 번이고 확인해 두면 빈집에 생기는 탈을 막을 수 있다',
     1:'떠나기 전에 방마다 불을 한두 개씩 켜 두면 빈집에 생기는 탈을 막을 수 있다',
     2:'오는 우편물을 미리 멈춰 두면 빈집에 생기는 탈을 막을 수 있다',
     3:'집 비우는 날짜를 옆집에 미리 알려 두면 빈집에 생기는 탈을 막을 수 있다',
     4:'밖에서도 집 안을 볼 수 있게 해 두면 빈집에 생기는 탈을 막을 수 있다'})
# 사촌 결혼식 · 요지 첫째 · 정답 ①
I[9] = dict(S=['Even at a long event, a child with a small job rarely gets bored.',
 "At my cousin's wedding last spring, the ceremony went on for two hours.",
 'Our aunt gave my little sister Yeseo a small camera for photos of the guests.',
 'Yeseo took photos with a big smile until the very end of the ceremony.'], pos=0,
 ch={0:'작은 일을 하나 맡겨 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     1:'미리 실컷 뛰어놀게 하면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     2:'행사 순서를 알려 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     3:'그림책을 한 권 쥐여 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다',
     4:'맨 앞자리에 앉혀 주면 아이가 긴 행사도 좀처럼 지루해하지 않는다'})
# 22번(요지) 레벨1 다섯째 판 — n=10~19 (학교 · 반 · 동아리 · 운동부 · 친구 사이 · 놀이)
# 꼴: 「한 장면, 다섯 교훈」 — 지어낸 사람 이야기 + 일반적인 교훈 문장 하나.
# 넷째 판: 「같은 틀, 다른 요인」 — 다섯 보기 모두 「(요인)이면 (같은 결과) 때가 많다」, 장면 고유의 물건 · 이름 · 숫자 없음,
#          「~보다」 없음, 맞서는 짝은 10 · 17 두 문항(정답이 짝의 한쪽). 감사 흠 11 · 14 · 16 · 17번째(n=10 · 13 · 15 · 16) 고침.
# 다섯째 판: 「맞수」 오답(정답만큼 널리 알려진 교훈) — n=10 · 12 · 13 · 15 · 16 · 18. 맞서는 짝은 17 하나(정답 반대쪽이 더 흔한 상식).
#          감사 흠 14 · 15 · 17 · 18번째(n=13 · 14 · 16 · 17) 고침.
# 여섯째 판: 「이야기로 쓸 만한」 오답 둘 + 맞수 + 나머지 — n=10 · 12 · 13 · 14 · 15 · 18. 감사 흠 18번째(n=17): 두 해를 같은 길이로.
# 일곱째 판: 「정답 맞바꾸기」 — n=12 · 13 · 15(가장 먼저 떠오르는 교훈을 오답으로 내리고, 덜 먼저 떠오르는 요인을 새 정답으로, 글을 새로 씀).
#          감사 흠 12번째(n=11): 카드 마술 뒤에도 「in two weeks」 · 20번째(n=19): Back then → That year.
# 모둠 과제 · 요지 둘째 · 다섯째 판: 짝(가장 친한) 없애고 맞수 「맡을 일을 똑같이 나누면」
#   흠 11번째: 두 번 다 「group of four」로 넷 대 넷
I[10] = dict(S=['For the first project, Jiho worked in a group of four with his best friends.',
 'Less close classmates often work better together than best friends.',
 'The four boys talked about games all week and missed the due date.',
 'Next time, Jiho and three less close classmates finished their project two days early.'], pos=1,
 ch={0:'덜 친한 친구들과 모둠이 되면 과제가 잘될 때가 많다',
     1:'맡을 일을 처음부터 똑같이 나누면 과제가 잘될 때가 많다',
     2:'모둠 회의를 서서 짧게 해 보면 과제가 잘될 때가 많다',
     3:'다 된 모습을 먼저 그려 놓고 하면 과제가 잘될 때가 많다',
     4:'잘하는 친구 한 명이 앞장서 이끌면 과제가 잘될 때가 많다'})
# 마술 동아리 홍보 · 요지 셋째
I[11] = dict(S=['Last spring, our magic club put twenty posters in the main hallway.',
 'Only two first graders joined the club in two weeks.',
 'A short live show often brings in more new members than many posters.',
 "After Seojun's short card trick in the hallway, fifteen first graders joined in two weeks."], pos=2,
 ch={0:'선배가 한 사람씩 찾아가 권하면 새 회원이 늘 때가 많다',
     1:'가입한 학생에게 작은 선물을 주면 새 회원이 늘 때가 많다',
     2:'가입하는 방법을 간단하게 하면 새 회원이 늘 때가 많다',
     3:'첫 모임을 쉽고 짧게 꾸며 두면 새 회원이 늘 때가 많다',
     4:'하는 일을 눈앞에서 짧게 보여 주면 새 회원이 늘 때가 많다'})
# 반 축구팀 골키퍼 · 요지 셋째 · 다섯째 판: 맞수 「이야기를 끝까지 들어 보면」(글에 이야기 장면 없음)
#   일곱째 판 맞바꿈: 옛 정답 「자리를 한 번 맡아 보면」 → ④ 오답 · 새 정답 「실수한 뒤에 다 함께 손뼉을 쳐 주면」
I[12] = dict(S=['Our class soccer team often blamed our goalkeeper Hyunwoo for every goal against us.',
 'Last month, our team gave Hyunwoo a loud clap after every goal against us.',
 'A team clap after a mistake often stops players from blaming a teammate.',
 'Since then, nobody on our team has blamed Hyunwoo for a goal.'], pos=2,
 ch={0:'그 친구의 이야기를 끝까지 귀담아들어 보면 친구를 덜 탓할 때가 많다',
     1:'경기에서 자주 이기기 시작하면 친구를 덜 탓할 때가 많다',
     2:'실수한 뒤에 다 함께 손뼉을 쳐 주면 친구를 덜 탓할 때가 많다',
     3:'그 친구의 자리를 한 번 직접 맡아 보면 친구를 덜 탓할 때가 많다',
     4:'탓하는 말에 작은 벌칙을 정해 두면 친구를 덜 탓할 때가 많다'})
# 다툰 두 친구 · 요지 둘째
#   흠 14번째: 쪽지뿐 아니라 말로 한 사과도 안 통했다고 고침 · 다섯째 판: fixes → ends, 맞수 「함께 나누어 먹으면」
#   일곱째 판 맞바꿈: 옛 정답 「작은 일을 둘이 함께 해 보면」 → ① 오답 · 새 정답 「서로의 자리를 하루 바꿔 앉으면」
#   (연극은 「함께 한 일」로도 읽혀 옛 정답을 받쳐 주므로 새 정답으로 쓰지 않음)
I[13] = dict(S=['Last Monday, Yuri and Sena had a big fight over a pink pen.',
 "A day in each other's seats often ends a fight better than an apology.",
 "For three days, Yuri's apologies in notes and in words did not fix anything.",
 "On Thursday, the girls sat in each other's seats all day and became friends again."], pos=1,
 ch={0:'작은 일을 둘이 함께 해 보면 다툰 사이가 풀릴 때가 많다',
     1:'며칠 동안 서로 떨어져 지내 보면 다툰 사이가 풀릴 때가 많다',
     2:'다툰 일을 짧은 연극으로 꾸며 보면 다툰 사이가 풀릴 때가 많다',
     3:'서로의 자리를 하루 바꿔 앉으면 다툰 사이가 풀릴 때가 많다',
     4:'먼저 진심을 담아 사과하면 다툰 사이가 풀릴 때가 많다'})
# 쉬는 시간 술래잡기 · 요지 넷째 · 다섯째 판(흠 15번째): ① 포괄적 「반기는 분위기」 → 구체 요인 · all ages → from both grades
I[14] = dict(S=["At recess, the third graders never joined the sixth graders' tag game.",
 'Last week, the sixth graders gave the younger children two safe spots.',
 'Now about thirty children from both grades play the same tag game every day.',
 'A small change in the rules often lets many more children into a game.'], pos=3,
 ch={0:'먼저 함께 놀자고 불러 주면 놀이에 끼는 아이가 늘 때가 많다',
     1:'놀이의 규칙을 조금 바꾸면 놀이에 끼는 아이가 늘 때가 많다',
     2:'놀이 자리를 넓은 곳으로 옮기면 놀이에 끼는 아이가 늘 때가 많다',
     3:'놀이 이름을 새로 지어 붙이면 놀이에 끼는 아이가 늘 때가 많다',
     4:'큰 아이와 작은 아이가 짝을 지으면 놀이에 끼는 아이가 늘 때가 많다'})
# 야구부 연패 · 요지 첫째
#   흠 16번째: 추가 연습을 그만두고 진 경기마다 이야기했다고 씀 · 다섯째 판: 맞수 「서로 믿고 응원해 주면」
#   일곱째 판 맞바꿈: 옛 정답 「진 경기마다 짧게 함께 돌아보면」 → ② 오답 · 새 정답 「선수들이 하루씩 감독을 맡아 보면」
I[15] = dict(S=['A turn as coach for every player often helps a team more than extra practice.',
 'Last fall, our baseball team practiced an extra hour daily and still lost four games.',
 'Then the team dropped the extra hour and gave each player a day as coach.',
 'After that, the team won six of its next eight games.'], pos=0,
 ch={0:'날마다 연습 시간을 늘려 가면 팀의 성적이 오를 때가 많다',
     1:'진 경기마다 짧게 함께 돌아보면 팀의 성적이 오를 때가 많다',
     2:'경기 전에 다 같이 같은 노래를 들으면 팀의 성적이 오를 때가 많다',
     3:'선수들이 서로 믿고 응원해 주면 팀의 성적이 오를 때가 많다',
     4:'선수들이 하루씩 감독을 맡아 보면 팀의 성적이 오를 때가 많다'})
# 수줍은 전학생 · 요지 둘째
#   흠 17번째: kind words → praise(우리말 「칭찬」과 맞춤) · 다섯째 판: 글에 shy, 맞수 「마음이 맞는 친구가 생기면」
I[16] = dict(S=['Our shy new classmate Ara hardly spoke a word for her first month.',
 'A chance to teach others often builds more confidence than praise.',
 'Praise from the teacher and classmates did not change Ara much.',
 'After her short lesson on paper flowers for the class, Ara chatted with everyone.'], pos=1,
 ch={0:'남을 가르쳐 볼 기회가 생기면 수줍은 아이가 자신감을 얻을 때가 많다',
     1:'주위에서 칭찬을 자주 해 주면 수줍은 아이가 자신감을 얻을 때가 많다',
     2:'어린 동생들을 돌보는 일을 맡으면 수줍은 아이가 자신감을 얻을 때가 많다',
     3:'마음이 맞는 친구가 한 명 생기면 수줍은 아이가 자신감을 얻을 때가 많다',
     4:'시간이 넉넉히 흐르면 수줍은 아이가 자신감을 얻을 때가 많다'})
# 독서 동아리 모임 · 요지 넷째 · 맞서는 짝(짧게 매주 ↔ 길게 달마다), 정답이 짝의 한쪽
#   다섯째 판(흠 18번째): 매달 두 시간 → 90분(한 해 총 시간을 맞춤)
I[17] = dict(S=['In its first year, our book club met for twenty minutes every Friday.',
 'Most members finished only one book in that whole year.',
 'In its second year, one ninety-minute monthly meeting helped most members finish eight books.',
 'For a book club, a long monthly meeting often works better than short weekly ones.'], pos=3,
 ch={0:'짧게라도 자주 모이면 회원들이 끝내는 책이 늘 때가 많다',
     1:'읽을 책을 다 함께 고르면 회원들이 끝내는 책이 늘 때가 많다',
     2:'모임마다 간식 당번을 정하면 회원들이 끝내는 책이 늘 때가 많다',
     3:'한 달에 한 번 길게 모이면 회원들이 끝내는 책이 늘 때가 많다',
     4:'읽은 쪽수를 날마다 적어 두면 회원들이 끝내는 책이 늘 때가 많다'})
# 운동회 달리기 응원 · 요지 첫째 · 다섯째 판: 맞수 「가족이 와서 지켜봐 주면」
I[18] = dict(S=["A cheer with a runner's own name often gives more strength than loud shouting.",
 'On sports day, our whole class shouted loudly for Eunji in the long race.',
 'Eunji heard only noise and stayed in fifth place for two laps.',
 'On the last lap, Eunji heard her name from two friends and passed three runners.'], pos=0,
 ch={0:'응원하는 말을 큰 글씨로 적어 들면 달리는 친구가 힘을 낼 때가 많다',
     1:'가족이 함께 와서 지켜봐 주면 달리는 친구가 힘을 낼 때가 많다',
     2:'그 친구의 이름을 불러 응원하면 달리는 친구가 힘을 낼 때가 많다',
     3:'좋아하는 노래를 크게 틀어 주면 달리는 친구가 힘을 낼 때가 많다',
     4:'반 전체가 한목소리로 응원하면 달리는 친구가 힘을 낼 때가 많다'})
# 교실 자리 바꾸기 · 요지 둘째
I[19] = dict(S=['Last year, Junha sat in the same seat for the whole school year.',
 'A new seat every month often brings a student many more friends in class.',
 'That year, Junha became close with only his desk partner, Siwoo.',
 'With a new seat every month this year, Junha has eight close friends.'], pos=1,
 ch={0:'먼저 다가가 말을 걸어 보면 반에서 친구가 늘 때가 많다',
     1:'교실 한가운데 자리에 앉으면 반에서 친구가 늘 때가 많다',
     2:'앉는 자리를 자주 바꾸어 보면 반에서 친구가 늘 때가 많다',
     3:'맡은 일이 하나 생기면 반에서 친구가 늘 때가 많다',
     4:'모둠 활동을 자주 하게 되면 반에서 친구가 늘 때가 많다'})
# 22번(요지) 레벨1 일곱째 판(정답 맞바꾸기: n=21 · 22 · 26) ← 여섯째 판 — n=20~29 「같은 틀, 다른 요인」 + 맞수 + 「이야기로 쓸 만한」 오답 둘 (뻔한 오답은 문항에 하나까지)
# 보기 다섯 = 「(요인)이면 (같은 결과)」 — 끝맺음 다섯 같게 · 장면 고유어 없음 · 「~보다」 없음 · 맞서는 짝 없음
# 이야기감 오답 둘 · 맞수 하나 · 나머지 하나 — 감사 흠 21 · 22 · 24 · 29 고침
# 20 요지 셋째 · 정답 3 — 가게: 쿠키 병을 문 옆 낮은 선반으로 (감사 21: better spot → more visible spot · 잘 보이는 자리)
I[20] = dict(S=['Sujin sells cookies and bread at a small bakery on our street.',
 'Last month, she moved her cookie jars from a back shelf to the window.',
 'A small move to a more visible spot can raise the sales of a product.',
 'Since then, children on their way home buy twice as many cookies.'], pos=2,
 ch={0:'값을 조금 내려 주면 같은 물건도 더 잘 팔릴 수 있다', 1:'맛보기를 조금씩 나눠 주면 같은 물건도 더 잘 팔릴 수 있다', 2:'이름표를 손글씨로 써 붙이면 같은 물건도 더 잘 팔릴 수 있다', 3:'잘 보이는 자리로 옮기면 같은 물건도 더 잘 팔릴 수 있다', 4:'좋은 냄새가 가게에 가득하게 하면 같은 물건도 더 잘 팔릴 수 있다'})
# 21 요지 첫째 · 정답 4 — 도서관: 옛 소설 곁에 한 장면 그림 (일곱째 판 맞바꿈: 옛 정답 「궁금증 한마디」 → ① 오답)
I[21] = dict(S=['A picture of one scene from the story can make an old book popular again.',
 'Our town library had many old novels on its back shelves.',
 'Last spring, a librarian hung a picture of one scene beside each of them.',
 'Within two weeks, readers took home almost every one of those books.'], pos=0,
 ch={0:'궁금증을 남기는 한마디를 붙이면 오래된 책도 다시 읽힐 수 있다', 1:'먼저 읽은 사람의 추천 글을 붙이면 오래된 책도 다시 읽힐 수 있다', 2:'다 읽은 사람에게 도장을 찍어 주면 오래된 책도 다시 읽힐 수 있다', 3:'쓴 사람의 삶을 짧게 소개하면 오래된 책도 다시 읽힐 수 있다', 4:'줄거리 속 한 장면을 그림으로 보여 주면 오래된 책도 다시 읽힐 수 있다'})
# 22 요지 넷째 · 정답 2 — 시장: 손님 앞에서 떡을 굽는 가게 (일곱째 판 맞바꿈: 옛 정답 「긴 줄」 → ② 오답)
I[22] = dict(S=['Two stalls at our night market sell the same rice cakes at the same price.',
 'Only Jiho cooks his rice cakes on a hot pan in front of shoppers.',
 'Every evening, new shoppers walk past the other stall and buy from Jiho.',
 'Cooking in front of people often pulls more shoppers toward a stall.'], pos=3,
 ch={0:'작은 종을 울려 손님을 부르면 손님이 더 몰려들 때가 많다', 1:'가게 앞에 사람들이 길게 서 있으면 손님이 더 몰려들 때가 많다', 2:'만드는 모습을 눈앞에서 보여 주면 손님이 더 몰려들 때가 많다', 3:'가게 이름을 재미있게 지으면 손님이 더 몰려들 때가 많다', 4:'맛있다는 소문이 퍼지면 손님이 더 몰려들 때가 많다'})
# 23 요지 첫째 · 정답 4 — 일터: 국숫집 일꾼 넷이 두 시간마다 일을 바꿈 (그대로)
I[23] = dict(S=['A regular change of tasks during the day can help workers make fewer mistakes.',
 'My aunt runs a busy noodle restaurant in our neighborhood.',
 'Before, her four workers did the same jobs all day and made ten mistakes daily.',
 'Now they switch jobs every two hours and make only three mistakes a day.'], pos=0,
 ch={0:'일하는 사람을 한 명 더 두면 일하는 사람의 실수가 줄어들 수 있다', 1:'주문을 큰 소리로 되풀이해 말하면 일하는 사람의 실수가 줄어들 수 있다', 2:'그날의 실수를 끝나고 함께 이야기하면 일하는 사람의 실수가 줄어들 수 있다', 3:'짧게 쉬는 시간을 자주 주면 일하는 사람의 실수가 줄어들 수 있다', 4:'맡은 일을 하루에도 여러 번 바꾸면 일하는 사람의 실수가 줄어들 수 있다'})
# 24 요지 셋째 · 정답 3 — 마을 행사: 운동장 장난감 장터에 그늘 의자 (감사 25: ⑤ 저녁 → 더위와 무관한 요인)
I[24] = dict(S=['Every May, our village has a market for old toys on the school field.',
 'Last year, most families left after only twenty minutes under the hot sun.',
 'A cool place for rest keeps visitors at an event much longer.',
 'This year, with chairs under the trees, most families stayed until the end.'], pos=2,
 ch={0:'물건마다 얽힌 이야기를 적어 두면 사람들이 행사에 훨씬 오래 머문다', 1:'끝날 때 줄 선물을 미리 알리면 사람들이 행사에 훨씬 오래 머문다', 2:'먹을거리 가게를 함께 열면 사람들이 행사에 훨씬 오래 머문다', 3:'시원하게 쉴 자리를 마련하면 사람들이 행사에 훨씬 오래 머문다', 4:'아이를 잠시 맡길 곳을 마련하면 사람들이 행사에 훨씬 오래 머문다'})
# 25 요지 셋째 · 정답 3 — 봉사: 강변길 청소 전후 사진 (감사 26: 지난번 사람들이 다시 왔다는 말)
I[25] = dict(S=["Few volunteers ever came back to clean the river path in Hana's town.",
 'Last month, the leader showed everyone photos of the path before and after the work.',
 'A clear look at the result brings volunteers back for more work.',
 'This month, every helper from last month came back for the cleanup.'], pos=2,
 ch={0:'일마다 짝을 바꿔 가며 하면 사람들이 봉사에 다시 나온다', 1:'일을 마치고 다 같이 밥을 먹으면 사람들이 봉사에 다시 나온다', 2:'고맙다는 인사를 꼭 전하면 사람들이 봉사에 다시 나온다', 3:'해낸 일을 눈으로 보여 주면 사람들이 봉사에 다시 나온다', 4:'맡을 일을 스스로 고르게 하면 사람들이 봉사에 다시 나온다'})
# 26 요지 첫째 · 정답 1 — 가게: 옷가게 벽마다 큰 거울 (일곱째 판 맞바꿈: 옛 정답 「주인이 떨어져 두기」 → ③ 오답 · 감사 27: customer · almost twice as many)
I[26] = dict(S=['Shoppers often buy more clothes with plenty of mirrors around the shop.',
 "Before, Jiwoo's aunt had only one small mirror for customers in her clothing shop.",
 'Last month, she hung big mirrors on every wall of the shop.',
 'Now she sells almost twice as many clothes as before.'], pos=0,
 ch={0:'웃는 얼굴로 반갑게 맞이하면 손님이 더 많이 살 때가 많다', 1:'옷을 비춰 볼 거울을 넉넉히 두면 손님이 더 많이 살 때가 많다', 2:'주인이 떨어져서 편히 보게 두면 손님이 더 많이 살 때가 많다', 3:'입어 본 모습을 사진으로 찍어 주면 손님이 더 많이 살 때가 많다', 4:'값을 조금씩 깎아 주면 손님이 더 많이 살 때가 많다'})
# 27 요지 둘째 · 정답 0 — 마을: 쓰레기 쌓이던 회색 벽에 그림 (감사 28: 동네 → 한 곳)
I[27] = dict(S=['People in our town often threw trash next to an old gray wall.',
 'People take much better care of a beautiful place in their town.',
 'Last spring, art students painted flowers and birds all over the wall.',
 'Since then, nobody has left any trash near the wall.'], pos=1,
 ch={0:'한 곳을 아름답게 꾸미면 사람들이 그곳을 더 아끼고 돌본다', 1:'쓰레기통을 가까이 놓아두면 사람들이 그곳을 더 아끼고 돌본다', 2:'정다운 이름을 붙여 부르면 사람들이 그곳을 더 아끼고 돌본다', 3:'그곳에 얽힌 옛이야기를 알려 주면 사람들이 그곳을 더 아끼고 돌본다', 4:'밤에도 불을 환하게 밝히면 사람들이 그곳을 더 아끼고 돌본다'})
# 28 요지 첫째 · 정답 1 — 일터: 회의를 오후로 모은 사무실 (감사 29: 이전 상태 한 문장)
I[28] = dict(S=['A quiet morning without meetings helps workers finish hard jobs.',
 "Before, my mother's office team of eight often finished their biggest jobs late at night.",
 'Last month, the team moved all their morning meetings to the afternoon.',
 'Now most of the team finish their biggest jobs before lunch.'], pos=0,
 ch={0:'일하는 자리를 날마다 바꿔 앉으면 어려운 일도 잘 끝내게 된다', 1:'회의 없는 조용한 오전이 있으면 어려운 일도 잘 끝내게 된다', 2:'둘씩 짝을 지어 일을 나누면 어려운 일도 잘 끝내게 된다', 3:'할 일을 전날 미리 정해 두면 어려운 일도 잘 끝내게 된다', 4:'틈틈이 밖에 나가 잠깐 걸으면 어려운 일도 잘 끝내게 된다'})
# 29 요지 넷째 · 정답 0 — 시장: 보라색 당근 옆 수프 요리법 카드
I[29] = dict(S=["Few shoppers bought the purple carrots at Grandpa Choi's market stall.",
 'Last week, he put an easy soup recipe on a card beside them.',
 'By Saturday, every purple carrot on his table was gone.',
 'A new food sells better with a simple idea for its use.'], pos=3,
 ch={0:'쉬운 쓰임새를 알려 주면 낯선 먹거리도 잘 팔린다', 1:'값을 조금 내려 주면 낯선 먹거리도 잘 팔린다', 2:'직접 먹어 보게 하면 낯선 먹거리도 잘 팔린다', 3:'재미있는 이름을 새로 붙이면 낯선 먹거리도 잘 팔린다', 4:'익숙한 먹거리와 묶어 팔면 낯선 먹거리도 잘 팔린다'})
