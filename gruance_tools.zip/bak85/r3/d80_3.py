# 22번(요지) 레벨1 셋째 판 — n=20~29 「한 장면, 다섯 교훈」 (가게 · 시장 · 마을 · 도서관 · 일터 · 마을 행사 · 봉사)
I = {}
# 20 요지 셋째 · 정답 3 — 가게: 쿠키 병을 문 옆 낮은 선반으로
I[20] = dict(S=['Sujin sells cookies and bread at a small bakery on our street.',
 'Last month, she moved her cookie jars to a low shelf near the door.',
 'A small change in the place of a product can raise its sales.',
 'Since then, children on their way home buy twice as many cookies.'], pos=2,
 ch={0:'값을 조금 내리면 찾아오는 손님이 크게 늘어난다', 1:'갓 구운 빵 냄새가 문밖까지 퍼지면 손님이 들어온다', 2:'쿠키를 재미있는 모양으로 구우면 아이들이 더 산다', 3:'물건을 어디에 두느냐에 따라 팔리는 양이 달라진다', 4:'쿠키를 하나씩 낱개로 팔면 아이들이 더 자주 사 간다'})
# 21 요지 첫째 · 정답 4 — 도서관: 갈색 종이로 싼 옛 소설
I[21] = dict(S=['A few words of mystery can make an old book interesting again.',
 'Our town library had many old novels on its back shelves.',
 'Last spring, a librarian wrapped them in brown paper with one short hint.',
 'Within two weeks, readers took home almost every one of those books.'], pos=0,
 ch={0:'새 책을 자주 들여오면 도서관을 찾는 사람이 늘어난다', 1:'앞부분을 소리 내어 읽어 주면 사람들이 그 책을 빌려 간다', 2:'방학 동안 빌리는 기간을 늘려 주면 책이 더 많이 나간다', 3:'오래된 책을 정리해야 새 책이 더 눈에 잘 띈다', 4:'궁금증을 일으키는 한마디가 오래된 책을 다시 읽히게 한다'})
# 22 요지 넷째 · 정답 2 — 시장: 줄 선 떡볶이 가게와 빈 가게 (맞서는 짝 2↔3, 정답이 한쪽)
I[22] = dict(S=['Two stalls at our night market sell the same rice cakes at the same price.',
 "Jiho's stall always has a long line in front of it.",
 'Every evening, new shoppers walk past the empty stall and join that line.',
 'A long line often pulls even more people toward a shop.'], pos=3,
 ch={0:'가게 앞에 밝은 등을 달면 밤 손님이 늘어난다', 1:'손님 앞에서 떡을 볶아 보이면 지나던 사람이 멈춰 선다', 2:'줄이 길게 늘어선 가게일수록 사람들이 더 몰려든다', 3:'오래 기다리게 하면 손님은 다른 가게로 간다', 4:'맛있다는 소문이 나면 손님이 저절로 모인다'})
# 23 요지 첫째 · 정답 4 — 일터: 국숫집 일꾼 넷이 두 시간마다 일을 바꿈
I[23] = dict(S=['A regular change of tasks during the day helps workers make fewer mistakes.',
 'My aunt runs a busy noodle restaurant with four workers.',
 'Before, each of the four workers did the same job all day.',
 'Now they switch jobs every two hours and make fewer mistakes.'], pos=0,
 ch={0:'국수 삶는 일은 가장 오래 일한 사람이 맡아야 맛이 고르다', 1:'일하는 순서를 미리 정해 두면 실수가 줄어든다', 2:'일꾼끼리 점심을 함께 먹으면 손발이 더 잘 맞는다', 3:'사장이 칭찬을 자주 하면 일하는 사람이 힘을 낸다', 4:'하루에도 맡은 일을 몇 번씩 바꾸면 실수가 줄어든다'})
# 24 요지 셋째 · 정답 3 — 마을 행사: 운동장 장난감 장터에 그늘 의자 
I[24] = dict(S=['Every May, our village has a market for old toys on the school field.',
 'Last year, most families left after only twenty minutes under the hot sun.',
 'A cool place for rest keeps visitors at an event much longer.',
 'This year, with chairs under the trees, most families stayed until the end.'], pos=2,
 ch={0:'행사를 미리 널리 알리면 찾아오는 사람이 늘어난다', 1:'재미있는 놀이가 있으면 아이들이 더 오래 놀다 간다', 2:'끝날 때 작은 선물을 나눠 주면 가족들이 끝까지 남는다', 3:'그늘에 쉴 자리가 있으면 사람들이 행사장에 오래 머문다', 4:'아이들이 직접 장난감 값을 매기게 하면 장터가 붐빈다'})
# 25 요지 셋째 · 정답 3 — 봉사: 강변길 청소 전후 사진
I[25] = dict(S=["Every month, a small group cleans the path along the river in Hana's town.",
 'Last month, the leader showed everyone photos of the path before and after the work.',
 'A clear look at the result brings volunteers back for more work.',
 'This month, almost twice as many people came to the cleanup.'], pos=2,
 ch={0:'친한 친구와 함께하면 봉사가 더 즐거워진다', 1:'청소를 마치고 강가에서 함께 점심을 먹으면 다음에도 온다', 2:'집게와 장갑을 넉넉히 두면 처음 온 사람도 쉽게 돕는다', 3:'해낸 일을 눈으로 확인하면 사람들이 다시 오고 싶어진다', 4:'남을 돕는 마음이 있어야 봉사를 오래 이어 간다'})
# 26 요지 첫째 · 정답 1 — 가게: 손님을 따라다니던 옷가게 주인 (맞서는 짝 0↔1, 정답이 한쪽)
I[26] = dict(S=['Shoppers often buy more with a little space from the shop owner.',
 "Jiwoo's aunt runs a small clothing shop near the bus stop.",
 'Before, she followed every visitor around the shop with lots of advice.',
 'Now she stays at the counter and sells more clothes than before.'], pos=0,
 ch={0:'주인이 먼저 다가가 말을 건네면 손님이 더 많이 산다', 1:'손님이 혼자 편히 둘러보게 두면 더 많이 사 간다', 2:'거울을 문 가까이 두면 손님이 옷을 더 많이 입어 본다', 3:'버스를 기다리는 사람에게 할인 쪽지를 주면 손님이 는다', 4:'값을 깎아 주면 손님이 다시 찾아온다'})
# 27 요지 둘째 · 정답 0 — 마을: 쓰레기 쌓이던 회색 벽에 그림
I[27] = dict(S=['People in our town often threw trash next to an old gray wall.',
 'People take better care of a place with a beautiful look.',
 'Last spring, art students painted flowers and birds all over the wall.',
 'Since then, nobody has left any trash near the wall.'], pos=1,
 ch={0:'보기 좋게 꾸민 곳은 사람들이 더 아끼게 된다', 1:'쓰레기통을 곳곳에 두면 거리가 깨끗해진다', 2:'벽 앞에 밤새 불을 밝혀 두면 몰래 버리는 사람이 준다', 3:'학생들이 날마다 벽 앞을 쓸면 이웃들도 따라 치운다', 4:'벌금을 매기면 쓰레기를 함부로 버리지 않는다'})
# 28 요지 첫째 · 정답 1 — 일터: 회의를 오후로 모은 사무실 
I[28] = dict(S=['A quiet morning without meetings helps workers finish hard jobs.',
 'My mother works at a small office with seven other people.',
 'Last month, her team put all their meetings in the afternoon.',
 'Now most of them finish their biggest jobs before lunch.'], pos=0,
 ch={0:'쉬는 시간을 자주 가지면 오후에도 힘이 난다', 1:'방해 없는 오전이 있으면 어려운 일도 잘 끝낸다', 2:'회의를 서서 하면 짧게 끝나 일할 시간이 늘어난다', 3:'점심 전에 잠깐 걸으면 오후 회의에서 생각이 잘 난다', 4:'일하는 자리가 넓고 밝으면 힘이 덜 든다'})
# 29 요지 넷째 · 정답 0 — 시장: 보라색 당근 옆 수프 요리법 카드
I[29] = dict(S=["Few shoppers bought the purple carrots at Grandpa Choi's market stall.",
 'Last week, he put an easy soup recipe on a card beside them.',
 'By Saturday, every purple carrot on his table was gone.',
 'A new food sells better with a simple idea for its use.'], pos=3,
 ch={0:'쓰임새를 알려 주면 낯선 먹거리도 잘 팔린다', 1:'값을 깎아 주면 처음 보는 채소도 잘 팔린다', 2:'보라색 당근을 주황색 당근과 함께 묶으면 잘 나간다', 3:'끓인 수프를 한 숟갈씩 맛보게 하면 손님이 산다', 4:'오래 장사한 사람을 손님은 더 믿고 찾는다'})
