# 22번(요지) 레벨1 셋째 판 — n=10~19 (학교 · 반 · 동아리 · 운동부 · 친구 사이 · 놀이)
# 꼴: 「한 장면, 다섯 교훈」 — 지어낸 사람 이야기 + 일반적인 교훈 문장 하나.
# 셋째 판: 오답 가운데 둘 이상은 정답만큼 의외 · 구체적(그 장면의 사물 · 사람 · 때)이고 글이 받쳐 주지 않음.
#          맞서는 짝은 정답이 한쪽일 때만(10 · 17). 같은 앞말 되풀이를 없앰.
I = {}
# 모둠 과제 · 요지 둘째 · 맞서는 짝(덜 친한 ↔ 가장 친한), 정답이 짝의 한쪽
#   구체 오답: 마감 날짜를 벽에 붙임(글에 없음) · 넷에서 셋으로(글은 두 번 다 넷)
I[10] = dict(S=['For the first class project, Jiho worked with his three best friends.',
 'Less close classmates often work better together than best friends.',
 'The four boys talked about games all week and missed the due date.',
 'With three less close classmates, Jiho finished his next project two days early.'], pos=1,
 ch={0:'아주 친한 친구보다 덜 친한 친구들과 함께할 때 과제가 잘 된다',
     1:'가장 친한 친구들끼리 모둠을 짜면 과제가 더 빨리 끝난다',
     2:'마감 날짜를 교실 벽에 크게 붙여 두면 모둠 과제가 늦어지지 않는다',
     3:'모둠 사람 수를 넷에서 셋으로 줄이면 과제를 더 일찍 마칠 수 있다',
     4:'잘하는 친구 한 명이 앞장서 이끌어 줄 때 모둠 과제가 더 잘 된다'})
# 마술 동아리 홍보 · 요지 셋째 (흠 12번째: 포스터 쪽도 「가입」으로 잣대를 맞춤)
#   구체 오답: 포스터에 마술 사진(글에 없음) · 복도 대신 교실 문(글: 둘 다 같은 복도) · 친한 선배가 권함(글에 없음)
I[11] = dict(S=['Last spring, our magic club put twenty posters in the main hallway.',
 'Only two first graders joined the club in two weeks.',
 'A short live show often brings in more new members than many posters.',
 "After Seojun's short card trick in the same hallway, fifteen first graders joined the club."], pos=2,
 ch={0:'포스터에 마술 장면 사진을 크게 넣으면 새 회원이 훨씬 늘어난다',
     1:'친한 선배가 직접 권하면 1학년이 동아리에 더 많이 들어온다',
     2:'포스터를 복도 대신 교실 문마다 붙이면 찾아오는 학생이 많아진다',
     3:'작은 선물을 함께 나눠 주면 동아리를 알리는 효과가 커진다',
     4:'눈앞에서 짧게 보여 주는 홍보가 포스터보다 사람을 더 모은다'})
# 반 축구팀 골키퍼 · 요지 셋째
#   구체 오답: 실점 장면을 함께 돌려 봄(글에 없음) · 골키퍼를 바꿈(글: 현우가 그대로 골문을 지킴)
I[12] = dict(S=['Our class soccer team often blamed our goalkeeper Hyunwoo for every goal against us.',
 'Last month, every player took a turn in the goal for one game.',
 "Players often stop blaming a teammate after a turn in the teammate's position.",
 'Since then, nobody on our team has blamed Hyunwoo for a goal.'], pos=2,
 ch={0:'경기가 끝난 뒤 실점 장면을 함께 돌려 보면 골키퍼를 덜 탓하게 된다',
     1:'경기에서 자주 이기기 시작하면 팀 안에서 서로 탓하는 말이 사라진다',
     2:'남이 맡던 자리에 한 번 서 보면 그 친구를 쉽게 탓하지 않게 된다',
     3:'골키퍼를 키가 큰 친구로 바꾸어 세우면 팀 안의 다툼이 줄어든다',
     4:'주장이 먼저 나서서 말리면 팀 친구를 원망하는 일이 줄어든다'})
# 다툰 두 친구 · 요지 둘째
#   구체 오답: 쪽지 대신 얼굴 보고 사과(글에 없음) · 펜을 하나 더 사 줌(글에 없음)
I[13] = dict(S=['Last Monday, Yuri and Sena had a big fight over a pink pen.',
 'A small job together often fixes a fight better than an apology.',
 "For three days, Yuri's apology notes did not fix anything.",
 'After an hour of washing paint brushes together, the two girls were friends again.'], pos=1,
 ch={0:'쪽지보다 얼굴을 마주 보고 사과할 때 다툰 친구와 금방 풀린다',
     1:'다른 친구가 둘 사이에 들어 주면 다툰 사이가 쉽게 풀린다',
     2:'다툼거리가 된 물건을 하나 더 사 주면 친구와 쉽게 화해한다',
     3:'사과하는 말보다 함께 작은 일을 하는 것이 다툰 사이를 더 잘 푼다',
     4:'며칠 서로 떨어져 지내다 보면 다툰 친구와 저절로 가까워진다'})
# 쉬는 시간 술래잡기 · 요지 넷째
#   구체 오답: 6학년이 동생과 짝지어 뜀(글에 없음) · 운동장 한가운데로 옮김(글에 없음)
I[14] = dict(S=["At recess, the third graders never joined the sixth graders' tag game.",
 'Last week, the sixth graders gave the younger children two safe spots.',
 'Now about thirty children of all ages play the same tag game every day.',
 'A small change in the rules often lets many more children into a game.'], pos=3,
 ch={0:'쉬는 시간이 길어지면 여러 학년이 한데 어울려 놀 수 있다',
     1:'놀이 규칙을 조금만 바꾸어도 함께 노는 아이가 크게 늘어난다',
     2:'6학년이 3학년 동생과 짝을 지어 뛰면 놀이에 끼는 아이가 늘어난다',
     3:'놀이 자리를 운동장 한가운데로 옮기면 더 많은 아이가 모여든다',
     4:'선생님이 함께 뛰어 주면 학년이 다른 아이들도 같이 놀게 된다'})
# 야구부 연패 · 요지 첫째 (흠 16번째: 글을 「each loss를 두고 이야기함」으로, 정답도 그에 맞춤) · 맞서는 짝 없앰
#   구체 오답: 선발 선수를 바꿈(글에 없음) · 상대 팀 영상이 연습보다 낫다(글에 영상 없음)
I[15] = dict(S=['A short talk about each loss often helps a team more than extra practice.',
 'Last fall, our school baseball team lost four games in a row.',
 'An extra hour of practice every day did not help the team at all.',
 'Then the team talked about each loss and won six of its next eight games.'], pos=0,
 ch={0:'날마다 연습을 한 시간씩 늘리면 운동부의 성적이 눈에 띄게 오른다',
     1:'선발 선수를 새 얼굴로 바꾸어 내보내면 연패의 흐름이 끊긴다',
     2:'상대 팀 영상을 함께 보는 것이 연습을 늘리는 것보다 더 도움이 된다',
     3:'코치가 더 엄하게 가르칠수록 운동부의 성적이 오른다',
     4:'진 경기를 두고 짧게 이야기하는 편이 연습을 늘리기보다 낫다'})
# 수줍은 전학생 · 요지 둘째
#   구체 오답: 반장이 일주일 짝(글에 없음) · 큰 모둠보다 단짝 한 명(글에 없음)
I[16] = dict(S=['Our new classmate Ara hardly spoke a word for her first month.',
 'A chance to teach others often builds more confidence than kind words.',
 'Kind words from the teacher and classmates did not change Ara much.',
 'After her short lesson on paper flowers for the class, Ara chatted with everyone.'], pos=1,
 ch={0:'남에게 무언가를 가르쳐 보는 일이 칭찬보다 자신감을 더 키운다',
     1:'선생님과 친구들이 따뜻하게 칭찬해 줄 때 수줍은 아이가 마음을 연다',
     2:'반장이 일주일 동안 짝이 되어 주면 전학생이 금방 반에 녹아든다',
     3:'시간이 충분히 지나면 수줍은 아이도 저절로 말이 많아진다',
     4:'전학생은 큰 모둠보다 단짝 한 명이 생길 때 먼저 말문이 트인다'})
# 독서 동아리 모임 · 요지 넷째 · 맞서는 짝(짧게 매주 ↔ 길게 달마다), 정답이 짝의 한쪽
#   구체 오답: 간식 당번(글에 없음) · 읽은 쪽수를 벽에 적음(글에 없음)
I[17] = dict(S=['Last year, our book club met for twenty minutes every Friday.',
 'Most members finished only one book in the whole year.',
 'With one two-hour meeting each month this year, most members finished eight books.',
 'For a book club, a long monthly meeting often works better than short weekly ones.'], pos=3,
 ch={0:'짧은 모임이라도 매주 여는 독서 동아리가 책을 더 많이 읽는다',
     1:'읽을 책을 회원들이 다 함께 고를 때 독서 모임이 더 알차진다',
     2:'모임마다 간식 당번을 정해 두면 회원들이 책을 끝까지 읽는다',
     3:'한 달에 한 번 길게 모이는 독서 동아리가 책을 더 많이 끝낸다',
     4:'읽은 쪽수를 교실 벽에 날마다 적어 두면 회원들이 더 많은 책을 마친다'})
# 운동회 달리기 응원 · 요지 첫째 · 맞서는 짝 없앰(정답 밖 짝이었음)
#   구체 오답: 손팻말이 목소리보다(글에 손팻말 없음) · 출발 직전 손을 잡아 줌(글에 없음)
I[18] = dict(S=["A cheer with a runner's own name often gives more strength than loud shouting.",
 'On sports day, our whole class shouted loudly for Eunji in the long race.',
 'Eunji heard only noise and stayed in fifth place for two laps.',
 'On the last lap, Eunji heard her name from two friends and passed three runners.'], pos=0,
 ch={0:'반 전체가 큰 소리로 함께 외칠 때 달리는 친구가 더 힘을 낸다',
     1:'응원 글을 적은 손팻말이 목소리보다 선수에게 더 잘 가 닿는다',
     2:'이름을 불러 주는 응원이 큰 함성보다 선수에게 더 힘이 된다',
     3:'출발 직전에 손을 꼭 잡아 주면 달리는 친구가 더 힘을 얻는다',
     4:'응원은 경기 처음부터 끝까지 이어 갈 때 더 큰 힘이 된다'})
# 교실 자리 바꾸기 · 요지 둘째
#   구체 오답: 창가보다 한가운데 자리(글에 없음) · 짝 한 명과 깊이(글에 없음)
I[19] = dict(S=['Last year, Junha sat in the same seat for the whole school year.',
 'A new seat every month often brings a student many more friends in class.',
 'Back then, Junha became close with only his desk partner, Siwoo.',
 'With a new seat every month this year, Junha has eight close friends.'], pos=1,
 ch={0:'먼저 다가가 말을 걸면 반 친구들과 두루 가까워질 수 있다',
     1:'창가보다 교실 한가운데에 앉는 학생이 친구를 더 많이 사귄다',
     2:'앉는 자리가 자주 바뀌면 한 해 동안 사귀는 친구도 많아진다',
     3:'짝 한 명과 깊이 사귀는 편이 여러 친구를 두는 것보다 즐겁다',
     4:'반에서 맡은 일이 하나씩 생기면 친구들과 두루 가까워진다'})
