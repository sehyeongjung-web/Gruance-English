# 22번(요지) 레벨1 둘째 판 — n=10~19 (학교 · 반 · 동아리 · 운동부 · 친구 사이 · 놀이)
# 꼴: 「한 장면, 다섯 교훈」 — 지어낸 사람 이야기 + 일반적인 교훈 문장 하나. 보기 다섯은 같은 장면에서 끌어낼 법한 교훈.
I = {}
# 모둠 과제 · 요지 둘째 · 맞서는 짝(덜 친한 ↔ 친한), 정답이 짝의 한쪽
I[10] = dict(S=['For the first class project, Jiho worked with his three best friends.',
 'Less close classmates often work better together than best friends.',
 'The four boys talked about games all week and missed the due date.',
 'With three less close classmates, Jiho finished his next project two days early.'], pos=1,
 ch={0:'모둠 과제는 덜 친한 친구들끼리 할 때 더 잘 된다',
     1:'모둠 과제는 가장 친한 친구들끼리 할 때 더 잘 된다',
     2:'모둠 과제는 할 일을 미리 나누어 둘 때 더 잘 된다',
     3:'모둠 과제는 날마다 조금씩 해 나갈 때 더 잘 된다',
     4:'모둠 과제는 잘하는 친구가 이끌어 줄 때 더 잘 된다'})
# 마술 동아리 홍보 · 요지 셋째
I[11] = dict(S=['Last spring, our magic club put twenty posters in the main hallway.',
 'Only two first graders visited the club room in two weeks.',
 'A short live show often brings in more new members than many posters.',
 "After Seojun's two-minute card trick in the same hallway, fifteen students joined the club."], pos=2,
 ch={0:'동아리 홍보는 새 학기 첫 주에 할 때 효과가 크다',
     1:'동아리 홍보는 친한 친구들을 통해 알릴 때 효과가 크다',
     2:'동아리 홍보는 포스터를 넉넉히 붙일 때 효과가 크다',
     3:'동아리 홍보는 작은 선물을 함께 나눠 줄 때 효과가 크다',
     4:'동아리 홍보는 눈앞에서 직접 보여 줄 때 효과가 크다'})
# 반 축구팀 골키퍼 · 요지 셋째
I[12] = dict(S=['Our class soccer team often blamed our goalkeeper Hyunwoo for every goal against us.',
 'Last month, every player took a turn in the goal for one game.',
 "Players often stop blaming a teammate after a turn in the teammate's position.",
 'Since then, nobody on our team has blamed Hyunwoo for a goal.'], pos=2,
 ch={0:'팀 친구를 탓하는 일은 주장이 나서서 말리면 줄어든다',
     1:'팀 친구를 탓하는 일은 경기에서 더 자주 이기면 줄어든다',
     2:'팀 친구를 탓하는 일은 그 자리를 맡아 보면 줄어든다',
     3:'팀 친구를 탓하는 일은 함께 어울려 친해지면 줄어든다',
     4:'팀 친구를 탓하는 일은 연습을 더 많이 하면 줄어든다'})
# 다툰 두 친구 · 요지 둘째
I[13] = dict(S=['Last Monday, Yuri and Sena had a big fight over a pink pen.',
 'A small job together often fixes a fight better than an apology.',
 "For three days, Yuri's apology notes did not fix anything.",
 'After an hour of washing paint brushes together, the two girls were friends again.'], pos=1,
 ch={0:'다툰 친구와는 진심을 담아 사과하면 쉽게 풀린다',
     1:'다툰 친구와는 다른 친구가 사이에 들면 쉽게 풀린다',
     2:'다툰 친구와는 작은 선물을 건네면 쉽게 풀린다',
     3:'다툰 친구와는 함께 일을 하다 보면 쉽게 풀린다',
     4:'다툰 친구와는 먼저 웃으며 인사하면 쉽게 풀린다'})
# 쉬는 시간 술래잡기 · 요지 넷째
I[14] = dict(S=["At recess, the third graders never joined the sixth graders' tag game.",
 'Last week, the sixth graders gave the younger children two safe spots.',
 'Now about thirty children of all ages play the same tag game every day.',
 'A small change in the rules often lets many more children into a game.'], pos=3,
 ch={0:'쉬는 시간이 길어지면 더 많은 아이가 함께 놀 수 있다',
     1:'규칙을 살짝 고치면 더 많은 아이가 함께 놀 수 있다',
     2:'선생님이 함께 뛰면 더 많은 아이가 함께 놀 수 있다',
     3:'더 넓은 곳으로 옮기면 더 많은 아이가 함께 놀 수 있다',
     4:'쉬운 놀이를 고르면 더 많은 아이가 함께 놀 수 있다'})
# 야구부 연패 · 요지 첫째 · 맞서는 짝(연습 늘림 ↔ 줄임), 정답은 짝 밖
I[15] = dict(S=['A short talk after each loss often helps a team more than extra practice.',
 'Last fall, our school baseball team lost four games in a row.',
 'An extra hour of practice every day did not help the team at all.',
 'With short talks after each loss, the team won six of its next eight games.'], pos=0,
 ch={0:'운동부는 연습 시간을 늘릴수록 성적이 오른다',
     1:'운동부는 연습을 줄이고 푹 쉴수록 성적이 오른다',
     2:'운동부는 코치가 엄하게 가르칠수록 성적이 오른다',
     3:'운동부는 강한 팀과 자주 겨룰수록 성적이 오른다',
     4:'운동부는 진 경기를 함께 되짚을수록 성적이 오른다'})
# 수줍은 전학생 · 요지 둘째
I[16] = dict(S=['Our new classmate Ara hardly spoke a word for her first month.',
 'A chance to teach others often builds more confidence than kind words.',
 'Kind words from the teacher and classmates did not change Ara much.',
 'After her short lesson on paper flowers for the class, Ara chatted with everyone.'], pos=1,
 ch={0:'수줍은 아이는 남을 가르쳐 볼 때 자신감이 붙는다',
     1:'수줍은 아이는 따뜻한 칭찬을 들을 때 자신감이 붙는다',
     2:'수줍은 아이는 마음 맞는 짝이 생길 때 자신감이 붙는다',
     3:'수줍은 아이는 시간이 충분히 지날 때 자신감이 붙는다',
     4:'수줍은 아이는 좋아하는 동아리에 들 때 자신감이 붙는다'})
# 독서 동아리 모임 · 요지 넷째 · 맞서는 짝(짧게 자주 ↔ 길게 가끔), 정답이 짝의 한쪽
I[17] = dict(S=['Last year, our book club met for twenty minutes every Friday.',
 'Most members finished only one book in the whole year.',
 'With one two-hour meeting each month this year, most members finished eight books.',
 'For a book club, a long monthly meeting often works better than short weekly ones.'], pos=3,
 ch={0:'독서 동아리는 짧은 모임을 매주 열 때 더 알차다',
     1:'독서 동아리는 읽을 책을 다 함께 고를 때 더 알차다',
     2:'독서 동아리는 회원 수를 적게 둘 때 더 알차다',
     3:'독서 동아리는 긴 모임을 달마다 열 때 더 알차다',
     4:'독서 동아리는 읽고 나서 짧은 글을 남길 때 더 알차다'})
# 운동회 달리기 응원 · 요지 첫째 · 맞서는 짝(크게 외침 ↔ 조용히 지켜봄), 정답은 짝 밖
I[18] = dict(S=["A cheer with a runner's own name often gives more strength than loud shouting.",
 'On sports day, our whole class shouted loudly for Eunji in the long race.',
 'Eunji heard only noise and stayed in fifth place for two laps.',
 'On the last lap, Eunji heard her name from two friends and passed three runners.'], pos=0,
 ch={0:'응원은 큰 소리로 힘껏 외칠 때 더 힘이 된다',
     1:'응원은 조용히 곁에서 지켜볼 때 더 힘이 된다',
     2:'응원은 선수의 이름을 불러 줄 때 더 힘이 된다',
     3:'응원은 경기 처음부터 이어 갈 때 더 힘이 된다',
     4:'응원은 많은 친구가 함께할 때 더 힘이 된다'})
# 교실 자리 바꾸기 · 요지 둘째
I[19] = dict(S=['Last year, Junha sat in the same seat for the whole school year.',
 'A new seat every month often brings a student many more friends in class.',
 'Back then, Junha became close with only his desk partner, Siwoo.',
 'With a new seat every month this year, Junha has eight close friends.'], pos=1,
 ch={0:'먼저 다가가 말을 걸면 반 친구들과 두루 가까워진다',
     1:'모둠 활동을 자주 하면 반 친구들과 두루 가까워진다',
     2:'앉는 자리를 자주 옮기면 반 친구들과 두루 가까워진다',
     3:'점심을 함께 먹으면 반 친구들과 두루 가까워진다',
     4:'반에서 맡은 일이 하나씩 생기면 반 친구들과 두루 가까워진다'})
