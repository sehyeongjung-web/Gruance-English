#!/bin/bash
# 그루앙스 작업 도구 설치 — 새 방을 열었을 때 한 번 실행
#   git clone https://github.com/sehyeongjung-web/Gruance-English.git /home/claude/Gruance-English
#   unzip -o /home/claude/Gruance-English/gruance_tools.zip -d /home/claude/work
#   bash /home/claude/work/setup.sh
set -e
REPO=/home/claude/Gruance-English
WORK=/home/claude/work
[ -d "$REPO/.git" ] || git clone -q https://github.com/sehyeongjung-web/Gruance-English.git "$REPO"
cd "$REPO" && git fetch -q && git reset -q --hard origin/main
mkdir -p "$WORK/out" && cd "$WORK"
cp "$REPO/index.html" out/index.html
cp "$REPO/그루앙스_작업인계문서.md" out/
cp "$REPO/verify_explain.py" out/
echo "GitHub 최신 커밋: $(git -C "$REPO" log -1 --format='%h %ci')"
echo "index.html: $(wc -c < "$REPO/index.html")바이트"
echo "인계문서 마지막 항목: $(grep '^## [0-9]*\.' "$REPO/그루앙스_작업인계문서.md" | tail -1 | cut -c1-60)"
python3 "$REPO/verify.py" "$REPO/index.html" | grep -E '^전체|검증' || true
python3 "$REPO/verify_explain.py" "$REPO/index.html" | tail -1
pip install -q cmudict --break-system-packages 2>/dev/null || echo "※ cmudict 설치 실패 — zjosa2.py의 영어 앞 낱말 판단이 꺼짐(pip install cmudict --break-system-packages)"
echo "도구 준비 끝: $WORK (README.md 참고)"
# 미뤄 둔 일: 방이 바뀌어도 잊지 않도록 시작할 때마다 보여 줌
if [ -f "$WORK/DEFERRED.md" ]; then echo; echo "================ 미뤄 둔 일 (차례가 왔는지 먼저 볼 것) ================"; cat "$WORK/DEFERRED.md"; fi
# 절약 방식(366번~): 레벨 1~2 칸은 이 순서로 — 시작할 때마다 보여 줌
if [ -f "$WORK/절약방식.md" ]; then echo; echo "================ 절약 방식 (레벨 1~2 칸은 이 순서로) ================"; cat "$WORK/절약방식.md"; fi
