# 23번 레벨9 두텁게 — 자체 엄격 검사 (verify_explain보다 엄함)
import re,sys; sys.path.insert(0,'.')
from lib import *
s,tb,te=load('out/index.html'); s0,tb0,te0=load()
done=0; soft=[]
for n in range(30):
    it=tb['23']['9'][n]; ex=te['23']['9'][n]; P=it['text']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done+=1
    for tx in [ex['walk']]+ex['cn']:
        assert '«' not in tx and '»' not in tx, (n,'꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"')%2==0, (n,line)
            for q in re.findall(r'"([^"]*)"',line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"'%(n+1,q))
                if len(q)<12: print('!! 짧은 큰따옴표: %d번째 "%s"'%(n+1,q))
        # 작은따옴표 속 영어가 지문·선택지 어디에도 없으면 눈으로 볼 목록에
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])",tx):
            if re.search(r'[가-힣]',q) or not re.search(r'[A-Za-z]{3,}',q): continue
            parts=[p.strip() for p in re.split(r'…',q) if p.strip()]
            src=(P+' || '+' || '.join(it['choices'])).lower()
            if not all(p.lower().strip('.,') in src for p in parts): soft.append((n+1,q))
    for k,c in enumerate(it['choices']):
        assert ("'"+c+"' (") in ex['cn'][k], (n,k,'선택지 인용 없음')
        assert ('정답입니다' in ex['cn'][k])==(k==it['answer']), (n,k,'정답 표시')
        assert ex['cn'][k].count('정답')==(1 if k==it['answer'] else 0), (n,k,'정답이라는 말이 오답 해설에 있음')
    assert not re.search(r'[①②③④⑤]|\d번', ex['walk']), (n,'번호')
    # 승인받은 문항 수정만 예외: (문항 번호, 선택지 자리) -> 새 문구
    APPROVED={(17,4):'why disclosing complex information can simulate accountability without producing it'}
    b0=tb0['23']['9'][n]
    assert it['text']==b0['text'] and it['answer']==b0['answer'] and it.get('q')==b0.get('q'), (n,'지문·정답 번호 변동')
    for k in range(5):
        if (n,k) in APPROVED: assert it['choices'][k]==APPROVED[(n,k)], (n,k,'승인 문구와 다름')
        else: assert it['choices'][k]==b0['choices'][k], (n,k,'선택지 변동')
    assert ex['ko']==te0['23']['9'][n]['ko'], (n,'해석 변동')
    w=ex['walk']; assert w.count('【')==3 and all(('%d) '%i) in w for i in (1,2,3,4)), (n,'꼴')
print('두텁게 쓴 문항:',done,'/ 30')
for x in soft: print('  눈으로 볼 것(작은따옴표 영어가 지문·선택지에 없음): %d번째 \'%s\''%x)
