# -*- coding: utf-8 -*-
# 317번: 20번(주장) 레벨2 다시 쓴 문항의 자체 검사   PYTHONPATH=pending python3 zcheck20.py [레벨, 기본 2] [다시 쓴 범위, 기본 0-14]
import re, sys; sys.path.insert(0, '/home/claude/work')
from lib import load
from lowstyle import has_nida
T = '20'; LV = sys.argv[1] if len(sys.argv) > 1 else '2'
a, b = (sys.argv[2] if len(sys.argv) > 2 else '0-14').split('-'); DONE = set(range(int(a), int(b) + 1))
s, tb, te = load('/home/claude/work/out/index.html'); s0, tb0, te0 = load()
soft = []; lw = []; lc = []
for n in range(30):
    it = tb[T][LV][n]; ex = te[T][LV][n]; b0 = tb0[T][LV][n]
    if n not in DONE:
        assert it == b0 and ex == te0[T][LV][n], (n, '안 쓴 문항이 바뀜'); continue
    P = it['text']; an = it['answer']; ch = it['choices']
    assert an == b0['answer'] and it.get('q') == b0.get('q'), (n, '정답 번호·발문 변동')
    sents = re.split(r'(?<=[.?!])\s+', P); assert len(sents) == 5, (n, '문장 수')
    assert all(c.endswith('야 한다') for c in ch), (n, '선택지 끝말')
    w = ex['walk']; lw.append(len(w)); lc += [len(c) for c in ex['cn']]
    assert w.startswith('① ') and '\n② ' in w and '\n③ 그러니까 필자의 주장은 \'%s\'는 거예요.' % ch[an] in w and '\n📌 낱말: ' in w, (n, '풀이의 꼴')
    assert not re.search(r'[①②③④⑤]번|정답', w), (n, '풀이에 번호·정답')
    for k in range(5):
        c = ex['cn'][k]
        assert c.startswith(("정답이에요! " if k == an else "") + "'" + ch[k] + "' — "), (n, k, '해설 머리')
        assert c.count('정답') == (1 if k == an else 0), (n, k, '정답이라는 말')
        assert len(c) >= len(ch[k]) + 25, (n, k, '해설이 너무 짧음')
    for tx in [w] + ex['cn']:
        assert not has_nida(tx.replace('해야 한다', '')), (n, '「~니다」 말끝', tx[:40])
        for q in re.findall(r'"([^"\n]*)"', tx):
            assert q in P, (n, '지문에 없는 큰따옴표 인용', q)
        body = tx
        for c in ch: body = body.replace("'" + c + "'", '')
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])", body):
            if re.search(r'[가-힣]', q) or not re.search(r'[A-Za-z]{3,}', q): continue
            parts = [p.strip() for p in q.split('…') if p.strip()]
            if not all(p.lower() in P.lower() for p in parts): soft.append((n + 1, q))
    # 주장 문장(큰따옴표 인용)이 지문의 한 문장과 똑같은지
    q = re.findall(r'"([^"\n]*)"', w); assert q and q[0] in sents, (n, '주장 문장 인용')
print('다시 쓴 문항: %d / 30 · 풀이 평균 %d자(%d~%d) · 선택지 해설 평균 %d자(%d~%d)' % (len(DONE), sum(lw) / len(lw), min(lw), max(lw), sum(lc) / len(lc), min(lc), max(lc)))
for x in soft: print("  눈으로 볼 것(작은따옴표 영어가 지문에 없음): %d번째 '%s'" % x)
