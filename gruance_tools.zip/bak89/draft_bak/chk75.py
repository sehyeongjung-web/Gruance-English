# 40번 레벨1 새 원고(d75 꼴: I[n] = dict(S=[지문 네 문장], SM=요약문, ch={0..4: 'a - b'})) 검사: python3 draft/chk75.py draft/d75_N.py
import sys, re, importlib.util
sys.path.insert(0,'/home/claude/work'); sys.path.insert(0,'/home/claude/work/draft')
from lib import load
from zlevel import check_texts
_, tb, _ = load('/home/claude/Gruance-English/index.html')
p = sys.argv[1]
spec = importlib.util.spec_from_file_location('dd', p); d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
texts = {}; bad = 0
for n, it in sorted(d.I.items()):
    ch = it['ch']; assert sorted(ch.keys()) == [0,1,2,3,4], (n, 'need five choices 0..4')
    a = tb['40']['1'][n]['answer']; key = ch[a]
    assert len(it['S']) == 4 and all(s.endswith('.') for s in it['S']), (n, 'need 4 sentences')
    SM = it['SM']; assert SM.count('(A) ______') == 1 and SM.count('(B) ______') == 1 and SM.index('(A)') < SM.index('(B)'), (n, 'summary blanks (A) before (B)')
    assert len(set(ch.values())) == 5 and all(re.fullmatch(r"[a-z' ]+ - [a-z' ]+", c) for c in ch.values()), (n, 'choices "a - b", distinct')
    A, B = key.split(' - '); P = ' '.join(it['S']).lower()
    for w in (A, B):
        if not re.search(r'\b' + re.escape(w.lower()), P): print('  !! n=%d 정답 낱말 「%s」이 지문에 그대로 없음' % (n, w)); bad += 1
    As = {c.split(' - ')[0] for c in ch.values()}; Bs = {c.split(' - ')[1] for c in ch.values()}
    if len(As) < 2 or len(Bs) < 2: print('  !! n=%d (A)나 (B)의 낱말이 하나뿐' % n); bad += 1
    texts[n] = (' '.join(it['S']) + '\n\n' + SM, key)
    print('n=%d key@%d=%s' % (n, a, key))
bad += check_texts('40', '1', texts, 5)
print('추가 검사 포함 걸린 것', bad)
