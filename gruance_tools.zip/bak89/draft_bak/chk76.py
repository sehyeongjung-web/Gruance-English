# 18번(글의 목적) 레벨1 새 원고 검사: python3 draft/chk76.py draft/d76_N.py
#   I[n] = dict(to='Dear …,', S=[본문 네 문장], sign='Sincerely,', name='한 낱말 이름', key=목적 문장 자리(0~3), ch={0..4: '~하려고'})
import sys, re, importlib.util
sys.path.insert(0,'/home/claude/work'); sys.path.insert(0,'/home/claude/work/draft')
from lib import load
from zlevel import check_texts
_, tb, _ = load('/home/claude/Gruance-English/index.html')
p = sys.argv[1]
spec = importlib.util.spec_from_file_location('dd', p); d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
def text_of(it): return '%s\n\n%s\n\n%s\n%s' % (it['to'], ' '.join(it['S']), it['sign'], it['name'])
texts = {}; bad = 0
def warn(n, m):
    global bad; bad += 1; print('  !! n=%d %s' % (n, m))
for n, it in sorted(d.I.items()):
    ch = it['ch']; assert sorted(ch.keys()) == [0,1,2,3,4], (n, 'need five choices 0..4')
    a = tb['18']['1'][n]['answer']
    if len(it['S']) != 4: warn(n, '본문은 네 문장')
    if not re.fullmatch(r"(Dear|To) [^,]{1,40},", it['to']): warn(n, "to는 'Dear …,' 꼴")
    if not re.fullmatch(r"(Yours sincerely|Sincerely|Best wishes|Thank you|Thanks|Love|Best regards|Kind regards|Regards),", it['sign']): warn(n, 'sign 꼴')
    if not re.fullmatch(r"[A-Z][a-z]+", it['name']): warn(n, 'name은 한 낱말')
    if not (0 <= it['key'] <= 3): warn(n, 'key는 0~3')
    if len(set(ch.values())) != 5: warn(n, '보기가 겹침')
    if not all(c.endswith('려고') for c in ch.values()): warn(n, '보기는 「~하려고」로 끝남')
    if any(re.search(r'[A-Za-z]', c) for c in ch.values()): warn(n, '보기에 영어')
    texts[n] = (text_of(it), 'x')
    print('n=%d key@%d=%s | 목적 문장=%d째' % (n, a, ch[a], it['key'] + 1))
bad += check_texts('18', '1', texts, 4)
print('추가 검사 포함 걸린 것', bad)
