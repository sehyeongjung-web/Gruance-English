# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 한글 (d74.py I[10]~I[14]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[10] = dict(
 ko="주말마다, 도윤은 옆집에 있는 할머니 댁에서 아침 식사를 한다. 토요일에는, 할머니는 항상 그에게 고구마 두 개와 따뜻한 우유를 준다. 일요일에는, 그녀는 대신 그에게 꿀을 조금 곁들인 떡을 준다. 그래서 토요일에는, 할머니는 항상 도윤에게 ______ 준다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Saturdays, Grandma always gives Doyun»(그래서 토요일에는, 할머니는 항상 도윤에게 … 준다) 뒤가 비어 있어요. 토요일에 할머니가 도윤에게 무엇을 주는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On Saturdays, Grandma always gives him two sweet potatoes and warm milk.»(토요일에는, 할머니는 항상 그에게 고구마 두 개와 따뜻한 우유를 준다.) 'two sweet potatoes and warm milk'(고구마 두 개와 따뜻한 우유)가 그대로 나와요. 'him'(그)는 도윤이고, 빈칸 문장과 같은 토요일의 이야기예요.",
 "3) 확인: 셋째 문장 «On Sundays, she gives him rice cakes with a little honey instead.»(일요일에는, 그녀는 대신 그에게 꿀을 조금 곁들인 떡을 준다.) 'rice cakes with a little honey'(꿀을 조금 곁들인 떡)은 'On Sundays'(일요일에는) 주는 음식이에요. 토요일의 일이 아니니, 떡은 빠져요.",
 "4) 묶기: 토요일에 할머니가 도윤에게 주는 것 = 'two sweet potatoes and warm milk'(고구마 두 개와 따뜻한 우유)."],
 traps="「꿀을 조금 곁들인 떡」이 끌릴 수 있어요. 셋째 문장에 'rice cakes with a little honey'(꿀을 조금 곁들인 떡)이 그대로 나오고, 빈칸 문장만 보면 할머니가 떡을 준다는 말도 자연스럽거든요. 하지만 그것은 'On Sundays'(일요일에는) 주는 것이고, 둘째 문장은 토요일에는 할머니가 'always'(항상) 고구마 두 개와 따뜻한 우유를 준다고 해요.",
 cn=[("달걀 두 개와 오렌지 주스 한 잔을", "달걀과 오렌지 주스는 글에 나오지 않아요. 둘째 문장 «On Saturdays, Grandma always gives him two sweet potatoes and warm milk.»에서 토요일에 할머니가 항상 주는 것은 고구마 두 개와 따뜻한 우유예요."),
     ("꿀을 조금 곁들인 떡을", "셋째 문장 «On Sundays, she gives him rice cakes with a little honey instead.»에서 꿀을 조금 곁들인 떡은 일요일에 주는 것이에요. 토요일에는 둘째 문장대로 'two sweet potatoes and warm milk'(고구마 두 개와 따뜻한 우유)를 줘요."),
     ("생선을 조금 곁들인 밥 한 그릇을", "밥과 생선은 글에 나오지 않아요. 둘째 문장 «On Saturdays, Grandma always gives him two sweet potatoes and warm milk.»에서 토요일에 할머니가 'always'(항상) 주는 것은 고구마 두 개와 따뜻한 우유예요."),
     ("빵 두 조각과 치즈 약간을", "빵과 치즈는 글에 나오지 않아요. 둘째 문장에서 토요일에 할머니가 'always'(항상) 주는 것은 'two sweet potatoes and warm milk'(고구마 두 개와 따뜻한 우유)예요."),
     ("고구마 두 개와 따뜻한 우유를", "둘째 문장 «On Saturdays, Grandma always gives him two sweet potatoes and warm milk.»이 근거예요. 토요일에는 할머니가 항상 도윤에게 고구마 두 개와 따뜻한 우유를 주니, 빈칸 문장의 토요일에 주는 것도 고구마 두 개와 따뜻한 우유예요.")])
K[11] = dict(
 ko="주원의 학교 컴퓨터실은 점심시간과 방과 후에 열려 있다. 점심시간에는, 학생들은 오직 컴퓨터로 수학 게임을 할 수 있다. 방과 후에는, 학생들은 오직 숙제를 위해 컴퓨터를 쓸 수 있다. 그래서 점심시간에, 주원은 오직 ______ 수 있다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So at lunch, Juwon may only»(그래서 점심시간에, 주원은 오직 … 수 있다) 뒤가 비어 있어요. 점심시간에 주원이 오직 무엇을 할 수 있는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «At lunch, students may only play math games on the computers.»(점심시간에는, 학생들은 오직 컴퓨터로 수학 게임을 할 수 있다.) 'play math games on the computers'(컴퓨터로 수학 게임을 하다)가 그대로 나와요. 빈칸 문장과 같은 점심시간의 규칙이고, 빈칸 문장의 'only'(오직)도 이 'only'(오직)이 받쳐요.",
 "3) 확인: 셋째 문장 «After school, students may only use the computers for homework.»(방과 후에는, 학생들은 오직 숙제를 위해 컴퓨터를 쓸 수 있다.) 'use the computers for homework'(숙제를 위해 컴퓨터를 쓰다)는 'After school'(방과 후에는) 지키는 규칙이에요. 빈칸 문장이 묻는 때는 점심시간이고, 둘째 문장의 'only'(오직)이 점심시간에 할 수 있는 일을 컴퓨터로 수학 게임을 하는 것 하나로 정하니, 숙제는 빠져요.",
 "4) 묶기: 점심시간에 주원이 할 수 있는 일 = 'play math games on the computers'(컴퓨터로 수학 게임을 하다)."],
 traps="「숙제를 위해 컴퓨터를 쓸」 수 있다는 보기가 끌릴 수 있어요. 셋째 문장에 그 말이 그대로 나오고, 빈칸 문장만 보면 숙제를 한다는 말도 자연스럽거든요. 하지만 그것은 방과 후의 규칙이고, 둘째 문장은 점심시간에는 학생들이 오직 컴퓨터로 수학 게임을 할 수 있다고 해요.",
 cn=[("컴퓨터로 수학 게임을 할", "둘째 문장 «At lunch, students may only play math games on the computers.»이 근거예요. 점심시간에는 학생들이 오직 컴퓨터로 수학 게임을 할 수 있으니, 점심시간의 주원도 오직 수학 게임을 할 수 있어요."),
     ("숙제를 위해 컴퓨터를 쓸", "셋째 문장 «After school, students may only use the computers for homework.»에서 숙제를 위해 컴퓨터를 쓰는 것은 방과 후의 규칙이에요. 점심시간에는 둘째 문장대로 'play math games on the computers'(컴퓨터로 수학 게임을 하다)만 할 수 있어요."),
     ("헤드폰을 끼고 과학 영상을 볼", "과학 영상은 글에 나오지 않아요. 둘째 문장 «At lunch, students may only play math games on the computers.»에서 점심시간에 할 수 있는 일은 'only'(오직) 컴퓨터로 수학 게임을 하는 것이에요."),
     ("컴퓨터로 뉴스를 읽을", "뉴스는 글에 나오지 않아요. 둘째 문장 «At lunch, students may only play math games on the computers.»에서 점심시간에 컴퓨터로 할 수 있는 일은 오직 수학 게임이에요."),
     ("자기 선생님들께 이메일을 보낼", "선생님께 이메일을 보낸다는 이야기는 글에 나오지 않아요. 둘째 문장은 점심시간에 학생들이 'may only play math games on the computers'(오직 컴퓨터로 수학 게임을 할 수 있다)라고 해요.")])
K[12] = dict(
 ko="민재와 그의 육상팀은 매일 오후 학교 운동장에서 모인다. 연습 전에는, 코치는 그들에게 함께 천천히 두 바퀴를 조깅하게 한다. 경주 전에는, 코치는 그들에게 오직 부드러운 잔디 위에서 스트레칭하는 것만 허락한다. 그래서 경주 전에, 코치는 민재에게 오직 ______ 것만 허락한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So before a race, the coach only lets Minjae»(그래서 경주 전에, 코치는 민재에게 오직 … 것만 허락한다) 뒤가 비어 있어요. 경주 전에 코치가 민재에게 무엇을 허락하는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Before a race, the coach only lets them stretch on the soft grass.»(경주 전에는, 코치는 그들에게 오직 부드러운 잔디 위에서 스트레칭하는 것만 허락한다.) 'stretch on the soft grass'(부드러운 잔디 위에서 스트레칭하다)가 그대로 나와요. 'them'(그들)은 민재와 그의 육상팀이고, 빈칸 문장의 'only'(오직)도 이 'only'(오직)이 받쳐요.",
 "3) 확인: 둘째 문장 «Before practice, the coach has them jog two slow laps together.»(연습 전에는, 코치는 그들에게 함께 천천히 두 바퀴를 조깅하게 한다.) 'jog two slow laps together'(함께 천천히 두 바퀴를 조깅하다)는 'Before practice'(연습 전에는) 하는 일이에요. 빈칸 문장의 때는 경주 전이고, 셋째 문장의 'only'(오직)이 경주 전에 허락되는 일을 잔디 위 스트레칭 하나로 정하니, 조깅은 빠져요.",
 "4) 묶기: 경주 전에 민재에게 허락된 일 = 'stretch on the soft grass'(부드러운 잔디 위에서 스트레칭하다)."],
 traps="「함께 천천히 두 바퀴를 조깅하는」 것이 끌릴 수 있어요. 둘째 문장에 같은 구가 그대로 나오고, 빈칸 문장만 보면 경주 전 조깅도 자연스럽거든요. 하지만 그것은 연습 전에 하는 일이고, 셋째 문장은 경주 전에는 오직 잔디 위 스트레칭만 허락한다고 해요.",
 cn=[("함께 천천히 두 바퀴를 조깅하는", "둘째 문장 «Before practice, the coach has them jog two slow laps together.»에서 두 바퀴 조깅은 연습 전에 하는 일이에요. 경주 전에는 셋째 문장대로 오직 부드러운 잔디 위에서 스트레칭하는 것만 허락돼요."),
     ("울타리 옆에서 열 차례 점프하는", "점프와 울타리는 글에 나오지 않아요. 셋째 문장 «Before a race, the coach only lets them stretch on the soft grass.»에서 경주 전에 코치가 허락하는 일은 'only'(오직) 부드러운 잔디 위에서 스트레칭하는 것 하나예요."),
     ("부드러운 잔디 위에서 스트레칭하는", "셋째 문장 «Before a race, the coach only lets them stretch on the soft grass.»이 근거예요. 경주 전에 코치는 민재와 그의 육상팀에게 오직 잔디 위 스트레칭만 허락하니, 빈칸 문장의 민재에게 허락하는 일도 부드러운 잔디 위에서 스트레칭하는 것이에요."),
     ("팀과 함께 한 바퀴를 걷는", "한 바퀴를 걷는다는 이야기는 글에 나오지 않아요. 셋째 문장 «Before a race, the coach only lets them stretch on the soft grass.»에서 경주 전에 코치가 허락하는 일은 'only'(오직) 부드러운 잔디 위에서 스트레칭하는 것 하나예요."),
     ("체육관 옆 그늘에서 쉬는", "그늘과 체육관은 글에 나오지 않아요. 셋째 문장 «Before a race, the coach only lets them stretch on the soft grass.»에서 경주 전에 허락되는 일은 'only'(오직) 부드러운 잔디 위에서 스트레칭하는 것 하나예요.")])
K[13] = dict(
 ko="매주 토요일, 가은은 기차역 근처에 있는 이모의 빵집을 찾아간다. 오전에는, 그녀는 오직 빵을 종이봉투에 담으러 그곳에 간다. 오후에는, 그녀의 일은 탁자와 바닥을 청소하는 것이다. 그래서 토요일 오전마다, 가은은 오직 ______ 그 빵집을 찾아간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Saturday mornings, Gaeun visits the bakery only»(그래서 토요일 오전마다, 가은은 오직 … 그 빵집을 찾아간다) 뒤가 비어 있어요. 가은이 무엇을 하러 가는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «In the morning, she goes there only to pack bread into paper bags.»(오전에는, 그녀는 오직 빵을 종이봉투에 담으러 그곳에 간다.) 'to pack bread into paper bags'(빵을 종이봉투에 담으러)가 그대로 나와요. 빈칸 문장과 같은 오전의 일이고, 이 문장의 'only'(오직)가 빈칸 문장의 'only'를 받쳐요.",
 "3) 확인: 셋째 문장 «In the afternoon, her job is to clean the tables and floor.»(오후에는, 그녀의 일은 탁자와 바닥을 청소하는 것이다.) 'to clean the tables and floor'(탁자와 바닥을 청소하는 것)은 'In the afternoon'(오후에는) 하는 일이에요. 빈칸 문장이 묻는 때는 오전이고, 둘째 문장의 'only'(오직)가 오전에 가는 목적을 빵을 종이봉투에 담는 것 하나로 정하니, 청소는 빠져요.",
 "4) 묶기: 토요일 오전에 빵집에 가는 목적 = 'to pack bread into paper bags'(빵을 종이봉투에 담으러)."],
 traps="「탁자와 바닥을 청소하러」가 끌릴 수 있어요. 셋째 문장에 그 말이 그대로 나오고, 빈칸 문장만 보면 청소하러 간다는 말도 자연스럽거든요. 하지만 그것은 오후에 하는 일이고, 둘째 문장은 오전에 그녀가 오직 빵을 종이봉투에 담으러 간다고 해요.",
 cn=[("앞 계산대에서 케이크를 팔러", "케이크를 판다는 이야기는 글에 나오지 않아요. 둘째 문장 «In the morning, she goes there only to pack bread into paper bags.»에서 오전에 가은은 오직 빵을 종이봉투에 담으러 그곳에 가요."),
     ("탁자와 바닥을 청소하러", "셋째 문장 «In the afternoon, her job is to clean the tables and floor.»에서 탁자와 바닥 청소는 오후의 일이에요. 오전에는 둘째 문장대로 오직 'to pack bread into paper bags'(빵을 종이봉투에 담으러) 가요."),
     ("작은 카드에 가격을 적으러", "가격 카드는 글에 나오지 않아요. 둘째 문장 «In the morning, she goes there only to pack bread into paper bags.»에서 오전에 가은은 오직 빵을 종이봉투에 담으러 그곳에 가요."),
     ("빵을 종이봉투에 담으러", "둘째 문장 «In the morning, she goes there only to pack bread into paper bags.»이 근거예요. 오전에 가은은 오직 빵을 종이봉투에 담으러 빵집에 가니, 토요일 오전에 빵집에 가는 목적은 그 일 하나예요."),
     ("이모와 함께 빵을 구우러", "이모와 함께 빵을 굽는다는 이야기는 글에 나오지 않아요. 첫째 문장은 가은이 이모의 'bakery'(빵집)를 찾아간다고 하고, 둘째 문장에서 오전에 가은은 오직 빵을 종이봉투에 담으러 그곳에 가요.")])
K[14] = dict(
 ko="서윤의 과학 동아리는 매주 목요일 큰 과학실에서 모인다. 기존 회원들은 항상 창가의 긴 탁자에서 작업한다. 서윤 같은 신입 회원들은 항상 문 근처의 둥근 탁자에서 작업한다. 그래서 신입 회원으로서, 서윤은 항상 ______ 작업한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So as a new member, Seoyun always works»(그래서 신입 회원으로서, 서윤은 항상 … 작업한다) 뒤가 비어 있어요. 신입 회원인 서윤이 어디에서 작업하는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «New members like Seoyun always work at the round table near the door.»(서윤 같은 신입 회원들은 항상 문 근처의 둥근 탁자에서 작업한다.) 'at the round table near the door'(문 근처의 둥근 탁자에서)가 그대로 나와요. 빈칸 문장과 같은 신입 회원의 이야기예요.",
 "3) 확인: 둘째 문장 «The older members always work at the long table by the window.»(기존 회원들은 항상 창가의 긴 탁자에서 작업한다.) 'at the long table by the window'(창가의 긴 탁자에서)는 'The older members'(기존 회원들)의 자리예요. 셋째 문장대로 서윤은 'New members'(신입 회원들) 쪽이니, 긴 탁자는 빠져요.",
 "4) 묶기: 신입 회원인 서윤이 작업하는 곳 = 'at the round table near the door'(문 근처의 둥근 탁자에서)."],
 traps="「창가의 긴 탁자에서」가 끌릴 수 있어요. 둘째 문장에 'at the long table by the window'(창가의 긴 탁자에서)가 그대로 나오고, 'always'(항상)까지 빈칸 문장과 같아서 헷갈리기 쉽거든요. 하지만 그것은 'The older members'(기존 회원들)의 자리이고, 셋째 문장은 서윤 같은 신입 회원들이 항상 문 근처의 둥근 탁자에서 작업한다고 해요.",
 cn=[("창가의 긴 탁자에서", "둘째 문장 «The older members always work at the long table by the window.»에서 창가의 긴 탁자는 기존 회원들이 작업하는 곳이에요. 서윤 같은 신입 회원들은 셋째 문장대로 'at the round table near the door'(문 근처의 둥근 탁자에서) 작업해요."),
     ("문 근처의 둥근 탁자에서", "셋째 문장 «New members like Seoyun always work at the round table near the door.»이 근거예요. 서윤 같은 신입 회원들은 항상 문 근처의 둥근 탁자에서 작업하니, 신입 회원인 서윤이 작업하는 곳도 그 둥근 탁자예요."),
     ("뒤쪽의 작은 책상에서", "작은 책상은 글에 나오지 않아요. 셋째 문장 «New members like Seoyun always work at the round table near the door.»에서 서윤 같은 신입 회원들이 'always'(항상) 작업하는 곳은 문 근처의 둥근 탁자예요."),
     ("칠판 옆의 큰 책상에서", "칠판과 큰 책상은 글에 나오지 않아요. 첫째 문장의 'big'(큰)은 과학실이 크다는 말이고, 셋째 문장 «New members like Seoyun always work at the round table near the door.»에서 서윤 같은 신입 회원들은 'always'(항상) 문 근처의 둥근 탁자에서 작업해요."),
     ("바로 옆의 작은 방에서", "옆에 있는 작은 방은 글에 나오지 않아요. 첫째 문장 «Seoyun's science club meets in the big science room every Thursday.»에서 동아리가 모이는 곳은 큰 과학실이고, 셋째 문장 «New members like Seoyun always work at the round table near the door.»에서 신입 회원들이 'always'(항상) 작업하는 곳은 문 근처의 둥근 탁자예요.")])
