# -*- coding: utf-8 -*-
# 31번(빈칸 추론) 레벨1 다시 쓰기(354번) 영어 원고 전체. 단문 네 문장 · 정답 낱말이 글에 그대로 나오되 빈칸 문장만으로는 정해지지 않는 꼴.
I = {}
I[0] = dict(S=['Yuna had a birthday party at her house last Sunday afternoon.',
 'Her aunt baked a big strawberry cake for the party in the morning.',
 'Her mother and her uncle brought fruit and juice from the market.',
 "So every guest thanked Yuna's ______ for the sweet strawberry cake."],
 ch={0: 'aunt', 1: 'mother', 2: 'cousin', 3: 'uncle', 4: 'sister'})
I[1] = dict(S=["Ben's little dog ran away from home during a storm last night.",
 'Ben and his dad did not find the dog at the park or the school.',
 'In the morning, a neighbor found the dog asleep in her yard.',
 "So the little dog slept in a ______ near Ben's house that night."],
 ch={0: 'park', 1: 'school', 2: 'kitchen', 3: 'yard', 4: 'forest'})
I[2] = dict(S=['Jun stayed with his grandmother in the country for the winter vacation.',
 'On the first day, she gave him a warm red hat.',
 'His mother also put a wool scarf in his bag before the trip.',
 'On the cold train home, Jun wore the ______ from his grandmother.'],
 ch={0: 'coat', 1: 'scarf', 2: 'sweater', 3: 'hat', 4: 'jacket'})
I[3] = dict(S=['Sora wanted to learn to swim at the city pool this spring.',
 'All the classes on Monday were already full of other children.',
 'The teacher still had one open place in the class on Thursday.',
 'So Sora will go to her first class at the pool next ______.'],
 ch={0: 'Monday', 1: 'Tuesday', 2: 'Wednesday', 3: 'Friday', 4: 'Thursday'})
I[4] = dict(S=["Heavy snow fell on Sam's small town early on Tuesday morning.",
 'His father still got to the family bakery through the snow at six.',
 "There, the big oven in the kitchen did not work until ten o'clock.",
 "So Sam's father opened the shop very late that day because of the ______."],
 ch={0: 'snow', 1: 'oven', 2: 'rain', 3: 'ice', 4: 'wind'})
I[5] = dict(S=["Jin's family drove to Green Lake for a picnic on a sunny Sunday.", 'The water near the shore was clean and not very deep.', 'Jin put his feet in the water and found it very cold.', 'So Jin did not swim in the ______ lake water during the picnic.'],
 ch={0: 'warm', 1: 'deep', 2: 'cold', 3: 'dirty', 4: 'dark'})
I[6] = dict(S=["Daniel's old car did not start on Monday morning in May.", 'His bike behind the house also had a flat tire.', 'He walked to his office for forty minutes in the warm sun.', 'So on Monday morning, Daniel ______ all the way to his office.'],
 ch={0: 'drove', 1: 'walked', 2: 'rode', 3: 'ran', 4: 'jogged'})
I[7] = dict(S=['Last year, Leo sometimes missed breakfast on his busy school mornings.',
 'In March, he started to get up thirty minutes earlier on school days.',
 'Now he always has toast, an egg and milk at home before school.',
 'So these days, Leo ______ eats breakfast at home on school days.'],
 ch={0: 'never', 1: 'rarely', 2: 'sometimes', 3: 'quickly', 4: 'always'})
I[8] = dict(S=['Minsu wanted a red school bag for the new school year in March.', 'The shop near his house had only black and blue bags.', 'He chose the blue one with many big pockets on the front.', 'So Minsu carried a new ______ bag to school on the first day.'],
 ch={0: 'red', 1: 'black', 2: 'green', 3: 'brown', 4: 'blue'})
I[9] = dict(S=['The students in Class 2-B chose a new class leader on Friday.', 'Mina and Junho both wanted the job of class leader very much.', 'In the end, Yeji got the most votes from the students.', 'So ______ will lead Class 2-B for the rest of the year.'],
 ch={0: 'Mina', 1: 'Yeji', 2: 'Junho', 3: 'Sumi', 4: 'Daeho'})
I[10] = dict(S=['Ryan ran in a long city race on a hot Sunday in July.',
 'His coach and his brother waited for him at the finish line.',
 'Near the river, a police officer gave Ryan a cold bottle of water.',
 'So during the race, Ryan got some cold water from the ______.'],
 ch={0: 'coach', 1: 'brother', 2: 'officer', 3: 'doctor', 4: 'neighbor'})
I[11] = dict(S=['Minho flew to Jeju with his new camera on a busy Friday.',
 'At the hotel, he searched his room for the camera and found nothing.',
 "Later, a worker at Jeju airport found Minho's camera on a chair.",
 'So Minho had left his new camera at the ______ in Jeju.'],
 ch={0: 'hotel', 1: 'airport', 2: 'beach', 3: 'hospital', 4: 'station'})
I[12] = dict(S=['On Tuesday evening, Chef Park made a big pizza for a family of four.',
 'He put tomato sauce, cheese, ham and a few onions on the pizza.',
 'After one bite, the two children asked for more ham on their slices.',
 'So the children in the family wanted more ______ on their pizza.'],
 ch={0: 'ham', 1: 'cheese', 2: 'sauce', 3: 'corn', 4: 'pepper'})
I[13] = dict(S=["Mina's tennis club planned a big match with another club for Saturday.",
 'On Friday night, two players of the other club became very sick.',
 'So the two clubs played the match on Sunday afternoon instead.',
 'In the end, Mina played in her big tennis match on ______.'],
 ch={0: 'Sunday', 1: 'Saturday', 2: 'Friday', 3: 'Monday', 4: 'Thursday'})
I[14] = dict(S=["Grandpa Oh's dog Toby barked in the yard all Tuesday night.",
 'The night was dark and calm, with no moon, wind or thunder.',
 'With a flashlight, Grandpa Oh found only a small fox in the bushes.',
 'So all night long, Toby was barking at the ______.'],
 ch={0: 'wind', 1: 'moon', 2: 'stranger', 3: 'fox', 4: 'thunder'})
I[15] = dict(S=['On a spring morning, Ara and her dad planned an afternoon picnic in the park.',
 'All day, the air stayed warm, with no clouds, rain or fog.',
 'At noon, the weather in the park suddenly became very windy.',
 'So in the afternoon, the weather was too ______ for a picnic.'],
 ch={0: 'rainy', 1: 'cold', 2: 'foggy', 3: 'cloudy', 4: 'windy'})
I[16] = dict(S=["Hana's young dog Bori goes to a dog school every Saturday morning.",
 "Bori already knows how to sit and bark at the teacher's call.",
 'Last Saturday, Bori learned to jump over a low bar for a treat.',
 "So Bori's newest trick at dog school is to ______ for a treat."],
 ch={0: 'sit', 1: 'bark', 2: 'dance', 3: 'jump', 4: 'wave'})
I[17] = dict(S=["Coach Kang's runners usually run fast around the track on Mondays.",
 'This Monday, the air over the track was very hot.',
 'At noon, the coach told the runners to run slowly for twenty minutes.',
 'So on this Monday, the runners ran around the track ______.'],
 ch={0: 'slowly', 1: 'fast', 2: 'happily', 3: 'hard', 4: 'early'})
I[18] = dict(S=["Jina's family went camping near a lake in the mountains last summer.",
 'Her dad packed the tent, lamps, chairs, cups and bottles in the car.',
 'At the lake, Jina found no blankets in the car or the bags.',
 'So on their first night at the lake, the family had no ______.'],
 ch={0: 'lamps', 1: 'chairs', 2: 'blankets', 3: 'cups', 4: 'bottles'})
I[19] = dict(S=['Farmer Go grows red apples on a small farm near Daegu.', 'Every year, his apples become big and sweet in late September.', 'Then he picks all the apples in the first week of October.', 'So every year, Farmer Go picks his sweet apples in ______.'],
 ch={0: 'September', 1: 'October', 2: 'August', 3: 'November', 4: 'July'})
I[20] = dict(S=["Every spring, a pair of birds builds a nest near Haeun's house.",
 'Last year they made their nest in the old tree by the gate.',
 'This year Haeun found their new nest in an old box by the back door.',
 'So this spring, the birds are living in their new nest in the ______.'],
 ch={0: 'tree', 1: 'garden', 2: 'roof', 3: 'grass', 4: 'box'})
I[21] = dict(S=['Minho took his guitar to the park on a warm Saturday morning.',
 'An old man with a dog asked Minho for a song about dogs.',
 'Later, a little girl on the grass asked for a song about the sea.',
 'So that morning, Minho played a happy song about dogs for the ______.'],
 ch={0: 'girl', 1: 'boy', 2: 'woman', 3: 'man', 4: 'baby'})
I[22] = dict(S=["Jiho and his sister wanted special presents for their mom's birthday in May.",
 "At the market, Jiho bought a small clock for Mom's kitchen wall.",
 'His sister bought a soft pink scarf for Mom at the same market.',
 'So on the big day, Mom got a new ______ from her son Jiho.'],
 ch={0: 'scarf', 1: 'cup', 2: 'bag', 3: 'ring', 4: 'clock'})
I[23] = dict(S=["Hyejin's aunt lives on Jeju Island with her husband and two dogs.",
 "Every summer, Hyejin's aunt comes to Seoul in August for a week.",
 'This year, the aunt came in October instead because of her busy job.',
 'So this year, Hyejin met her aunt from Jeju in ______.'],
 ch={0: 'August', 1: 'October', 2: 'July', 3: 'September', 4: 'December'})
I[24] = dict(S=["Junho's family and their quiet dog camped by a mountain lake in July.",
 'The night was warm, calm and dry under a sky full of stars.',
 'Then a group in the next tent played loud music until two in the morning.',
 "So nobody in Junho's family slept well that night because of the ______."],
 ch={0: 'rain', 1: 'wind', 2: 'dog', 3: 'music', 4: 'cold'})
I[25] = dict(S=['Dami and her dad built a small wooden house for their dog Coco.',
 'At the store, her little brother asked for a can of red paint.',
 'In the end, Dami painted the little house yellow like the sun.',
 'So Coco now sleeps in a bright ______ house in the garden.'],
 ch={0: 'yellow', 1: 'red', 2: 'blue', 3: 'white', 4: 'brown'})
I[26] = dict(S=["Last Sunday, Taemin's family spent a hot summer afternoon at the beach.",
 'Mom read a thick book under a big umbrella on the warm sand.',
 'Dad swam in the cool blue sea with Taemin for three hours.',
 'So that day, Dad ______ with his son Taemin for most of the afternoon.'],
 ch={0: 'slept', 1: 'read', 2: 'swam', 3: 'walked', 4: 'fished'})
I[27] = dict(S=['Every Saturday, Seojun and his friend Taeho fish together at the river near their town.',
 'This Saturday, Taeho had a bad cold and stayed in bed at home.',
 'Seojun went to the river alone in the afternoon with some bread.',
 'So this Saturday, Seojun caught three small fish ______ at the river.'],
 ch={0: 'together', 1: 'early', 2: 'alone', 3: 'quickly', 4: 'easily'})
I[28] = dict(S=['In June, Grandma put a big net over her strawberries to keep the birds away.',
 'Even so, a few strawberries disappeared from under the net every day.',
 'Then she saw a mouse under the net with a strawberry in its mouth.',
 "So in the end, Grandma's sweet strawberries became food for a little ______."],
 ch={0: 'mouse', 1: 'bird', 2: 'rabbit', 3: 'chicken', 4: 'dog'})
I[29] = dict(S=["In January, Eunbi's family went on a two-day ski trip to the mountains.",
 'On the first day, the mountain sky was clear from morning to evening.',
 'On the second day, the sky over the mountain stayed dark and gray.',
 "So Eunbi's ski photos from the first day all show a ______ sky."],
 ch={0: 'dark', 1: 'gray', 2: 'clear', 3: 'white', 4: 'pink'})
