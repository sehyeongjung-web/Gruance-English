# -*- coding: utf-8 -*-
# 원고(d78.I)와 한글(k78_1~6.K)을 합쳐 pending/edits_X77x.py를 만든다.  python3 draft/gen78.py a|b
import sys, pprint, importlib
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
D = importlib.import_module('d78'); KO = {}
for _i in range(1, 7): KO.update(importlib.import_module('k78_%d' % _i).K)
ns = list(range(0, 15) if tag == 'a' else range(15, 30))
from lib import load
_tb = load()[1]
out = ['# -*- coding: utf-8 -*-',
       '# 361번: 19번(심경 변화) 레벨1 %s 절반 — 네 문장(단문 · 문장당 10~15낱말) · 주인공의 처음 · 나중 마음 낱말이 글에 그대로 + 다른 사람의 마음 낱말(미끼). 정답 번호는 바탕 그대로' % ('앞' if tag == 'a' else '뒤'),
       'AUTO_SYNC = False', 'E = {}', 'from z19common import maker', "rw = maker(E, '19', '1')", '']
for n in ns:
    I = D.I[n]; k = KO[n]; a = _tb['19']['1'][n]['answer']; CH = [I['ch'][x] for x in range(5)]
    out.append('# %d번째 (정답 %s)' % (n + 1, '①②③④⑤'[a]))
    out.append('rw(%d, %d,\n   %r,\n   %s,\n   %r,\n   %r, %r, %r,\n   %r, %r, %r,\n   %s,\n   %r,\n   %s)\n' % (n, a, ' '.join(I['S']), pprint.pformat(CH, width=200), k['ko'], I['S'][k['s1']], k['k1'], k['w1'], I['S'][k['s2']], k['k2'], k['w2'], pprint.pformat(k['gl'], width=200), k['words'], pprint.pformat(k['cn'], width=200)))
open('/home/claude/work/pending/edits_X77%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X77%s.py (%d문항)' % (tag, len(ns)))
