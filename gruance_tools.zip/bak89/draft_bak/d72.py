# -*- coding: utf-8 -*-
# 32번(빈칸 — 낱말) 레벨1 다시 쓰기(356번) 영어 원고 전체. 네 문장 · 단문 · 정답 낱말이 글에 그대로 · 빈칸 문장만으로는 정해지지 않는 꼴
I = {}
I[0] = dict(S=['Mina poured water into a star tray, a heart tray and a fish tray.', 'She put the three trays into the freezer at four in the afternoon.', 'At six, only the small star tray had hard ice in it.', 'So the water froze the fastest in the ______ tray.'],
 ch={0: 'star', 1: 'heart', 2: 'fish', 3: 'moon', 4: 'flower'})
I[1] = dict(S=['Grandma planted potatoes, corn and beans in her garden in April.',
 'In the fall, the corn and the beans gave her one basket each.',
 'The potato plants gave her four full baskets of food.',
 'So Grandma got the most food that year from her ______ plants.'],
 ch={0: 'corn', 1: 'potato', 2: 'bean', 3: 'pumpkin', 4: 'onion'})
I[2] = dict(S=['Sora looked at the sky from her window for four mornings last week.',
 'From Monday to Wednesday, she saw only a few small white clouds.',
 'On Thursday, big dark clouds covered the whole sky over her town.',
 'So the darkest sky of those four mornings came on ______.'],
 ch={0: 'Monday', 1: 'Tuesday', 2: 'Friday', 3: 'Thursday', 4: 'Wednesday'})
I[3] = dict(S=['Jiho watched a white duck at the pond in the park for an hour.',
 'For most of the hour, the duck swam and ate grass by the water.',
 "At four o'clock, it flew over the trees and landed near the river.",
 "So the duck ______ from the pond to the river at four o'clock."],
 ch={0: 'swam', 1: 'walked', 2: 'flew', 3: 'ran', 4: 'hopped'})
I[4] = dict(S=['Dami dropped a coin, a key and a spoon on the floor one by one.',
 'Her younger brother Taeho named each thing by its sound alone.',
 'He got the coin and the spoon right and called the key a coin.',
 'So Taeho made a mistake only with the sound of the ______.'],
 ch={0: 'coin', 1: 'spoon', 2: 'pen', 3: 'cup', 4: 'key'})
I[5] = dict(S=['Yuna put her toy bear on a chair in her dark bedroom.',
 'She stood behind the chair and pointed a flashlight at the bear.',
 'A big shadow of the bear appeared on the door in front of the chair.',
 'So Yuna saw the dark shape of her bear on the ______.'],
 ch={0: 'wall', 1: 'chair', 2: 'door', 3: 'bed', 4: 'window'})
I[6] = dict(S=['Minho and his younger sister Sena each cooked noodles in hot water for lunch.',
 "After three minutes in the pot, Minho's noodles were still a little hard.",
 "Sena's noodles stayed in the pot for ten minutes and got very soft.",
 "So in the end, the noodles in Sena's bowl were very ______."],
 ch={0: 'hard', 1: 'soft', 2: 'salty', 3: 'dry', 4: 'spicy'})
I[7] = dict(S=['Eunji had a red magnet, a blue magnet and a black magnet for her fridge.',
 'She tried to hold five sheets of paper on the fridge with each one.',
 'Only the black magnet held all five sheets in place on the fridge.',
 "So the strongest magnet on Eunji's fridge was the ______ one."],
 ch={0: 'red', 1: 'blue', 2: 'silver', 3: 'white', 4: 'black'})
I[8] = dict(S=["Jun's class dug a hole for a new tree in the school garden.", 'The soil near the top was soft and full of small roots.', 'Half a meter down, the children hit a big gray rock.', 'So the class stopped digging there because of the big ______.'],
 ch={0: 'rock', 1: 'root', 2: 'pipe', 3: 'puddle', 4: 'branch'})
I[9] = dict(S=['Nari, Hoon and Ara closed their eyes for a taste test at school.',
 'Their teacher gave them apple juice, grape juice and orange juice in paper cups.',
 'Only Nari named all three juices right by taste alone.',
 'So the child with the best sense of taste was ______.'],
 ch={0: 'Nari', 1: 'Hoon', 2: 'Ara', 3: 'Minji', 4: 'Yuri'})
I[10] = dict(S=['On a cloudy October night, Jae looked for the moon at eight, ten and twelve.',
 'At eight and at twelve, thick gray clouds hid the moon from him.',
 "At ten o'clock, he saw a bright round moon above the dark hill.",
 "So that night, Jae saw the moon only at ______ o'clock."],
 ch={0: 'ten', 1: 'eight', 2: 'twelve', 3: 'nine', 4: 'eleven'})
I[11] = dict(S=['Yeri put some bread, an apple slice and some cheese near an ant hill.',
 'After twenty minutes, many ants were all over the small piece of cheese.',
 'Only a few ants walked onto the bread and the apple slice.',
 'So out of the three foods, the ants liked the ______ the most.'],
 ch={0: 'bread', 1: 'apple', 2: 'cookie', 3: 'cheese', 4: 'candy'})
I[12] = dict(S=['One morning on the beach, Yuri found a small crab beside a big rock.',
 'The crab ran quickly across the wet sand to an old boat.',
 'Then it hid under the old boat for the rest of the morning.',
 'So in the end, the little crab stayed under the ______.'],
 ch={0: 'rock', 1: 'sand', 2: 'boat', 3: 'shell', 4: 'net'})
I[13] = dict(S=['On a windy afternoon, Sujin blew on a white dandelion in her yard.',
 'The wind carried its seeds over the fence and across the road.',
 'Most of the seeds came down in a big field of grass.',
 "So most of Sujin's dandelion seeds landed in the ______."],
 ch={0: 'yard', 1: 'road', 2: 'garden', 3: 'field', 4: 'forest'})
I[14] = dict(S=["On the first night of her trip, Minji's old flashlight gave no light.",
 'Two new batteries and a new bulb did not help the flashlight at all.',
 'The next day, a new switch made the old flashlight bright again.',
 'So the flashlight did not work because of a bad ______.'],
 ch={0: 'battery', 1: 'bulb', 2: 'wire', 3: 'spring', 4: 'switch'})
I[15] = dict(S=['Taeho blew up a red, a green and a yellow balloon for the party.',
 'The next morning, the red and the green balloons were still big and round.',
 'Only the yellow balloon lay small and soft on the floor.',
 'So the ______ balloon lost the most air during the night.'],
 ch={0: 'red', 1: 'green', 2: 'blue', 3: 'yellow', 4: 'pink'})
I[16] = dict(S=['Jia dropped a small piece of bread into the pond at the park.',
 'A big orange fish swam over and touched the bread with its mouth.',
 'Then the fish left the bread on the water and swam away.',
 "So in the end, the big orange fish ______ Jia's bread."],
 ch={0: 'ate', 1: 'left', 2: 'took', 3: 'pulled', 4: 'carried'})
I[17] = dict(S=['Early on Monday, Dami found small tracks in the new snow in her yard.',
 'Her cat and her dog were inside the house all night.',
 'At the end of the tracks, she saw a gray mouse under the back steps.',
 "So the tracks in the snow in Dami's yard came from a ______."],
 ch={0: 'cat', 1: 'dog', 2: 'rabbit', 3: 'chicken', 4: 'mouse'})
I[18] = dict(S=["Jun's school put a round mirror at a corner of the long hall.",
 'On Monday, Jun stood next to his teacher at the classroom door.',
 'In the mirror, Jun saw the school nurse near the stairs around the corner.',
 'So the mirror showed Jun the ______ around the corner.'],
 ch={0: 'teacher', 1: 'nurse', 2: 'cook', 3: 'coach', 4: 'doctor'})
I[19] = dict(S=['Sumi weighed an onion, a potato and a carrot on the kitchen scale.',
 'The onion and the carrot each weighed about one hundred grams.',
 'The big potato weighed almost two hundred grams on the same scale.',
 "So the heaviest of the three vegetables on Sumi's scale was the ______."],
 ch={0: 'onion', 1: 'potato', 2: 'carrot', 3: 'cucumber', 4: 'eggplant'})
I[20] = dict(S=['One afternoon, Dana sat under the big oak tree in her yard with a book.',
 'There was no wind at all in the yard that afternoon.',
 'Suddenly, a big black bird landed on a low branch and shook the leaves.',
 "So the leaves above Dana's head moved because of the ______."],
 ch={0: 'wind', 1: 'rain', 2: 'bird', 3: 'storm', 4: 'mouse'})
I[21] = dict(S=['Grandpa grew apple, pear and orange trees on his small farm in Jeju.',
 'One warm spring morning, Seoyun counted the bees on each kind of tree.',
 'There were many bees on the orange trees and only a few on the others.',
 "So the bees on Grandpa's farm liked the ______ trees best that morning."],
 ch={0: 'apple', 1: 'pear', 2: 'peach', 3: 'orange', 4: 'lemon'})
I[22] = dict(S=['After a heavy rain on Sunday, Minho saw three puddles on his street.',
 'There was one by the bank, one by the library and one by the church.',
 'On Tuesday morning, only the puddle by the church still had some water.',
 'So the puddle near the ______ lasted the longest after the rain.'],
 ch={0: 'bank', 1: 'library', 2: 'park', 3: 'school', 4: 'church'})
I[23] = dict(S=['Jiho, Mina and their dad each heated a pot of water on the stove.',
 'Mina used the smallest pot with only one cup of water in it.',
 'Her water boiled two minutes before the water in the other pots.',
 "So the water in ______'s pot boiled first on the stove."],
 ch={0: 'Jiho', 1: 'Dad', 2: 'Mina', 3: 'Sujin', 4: 'Mom'})
I[24] = dict(S=['Our teacher put a heavy box of books on the classroom floor.',
 "Ben's hard push from behind did not move the box at all.",
 'Then three children pulled the box across the floor with a long rope.',
 'So the children finally moved the heavy box by ______ it.'],
 ch={0: 'pushing', 1: 'lifting', 2: 'kicking', 3: 'carrying', 4: 'pulling'})
I[25] = dict(S=["In April, the cherry trees in Bora's town were full of pink flowers.",
 'On the cold mountain near the town, the cherry trees still had small buds.',
 'In early May, the cherry trees on the mountain finally opened their pink flowers.',
 'So the cherry trees on the mountain bloomed in ______ that year.'],
 ch={0: 'March', 1: 'April', 2: 'May', 3: 'June', 4: 'July'})
I[26] = dict(S=['Grandpa put a small camera near the forest behind his house for one night.',
 "At ten o'clock at night, a fox walked past the camera.",
 'At two in the morning, a gray cat sat in front of the camera.',
 "So the animal on Grandpa's camera at two in the morning was a ______."],
 ch={0: 'cat', 1: 'mouse', 2: 'deer', 3: 'fox', 4: 'dog'})
I[27] = dict(S=['Mom filled a green jar and a blue jar with milk and a little yogurt.',
 'The milk in the blue jar stayed sweet overnight in the cold fridge.',
 'The milk in the green jar on the warm table became thick and sour.',
 'So the next morning, the ______ jar had thick, sour milk.'],
 ch={0: 'green', 1: 'blue', 2: 'yellow', 3: 'white', 4: 'purple'})
I[28] = dict(S=['At low tide, Jisu and her dad walked along the wet sand for an hour.',
 'Jisu picked up twelve shells, three round stones and one small crab.',
 'She put all of them into her red bucket with some sea water.',
 "So most of the things in Jisu's bucket that day were ______."],
 ch={0: 'stones', 1: 'crabs', 2: 'fish', 3: 'shells', 4: 'bottles'})
I[29] = dict(S=['For one windy week in May, Jiwoo checked the grass in her yard each morning.',
 'Every day at six, she touched the grass with her fingers.',
 'Her fingers never got wet from any dew on the grass that week.',
 "So that week, the grass in Jiwoo's yard was ______ wet with dew at six."],
 ch={0: 'always', 1: 'never', 2: 'sometimes', 3: 'often', 4: 'usually'})
