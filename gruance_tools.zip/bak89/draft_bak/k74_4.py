# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 한글 (d74.py I[15]~I[19]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[15] = dict(
 ko="태리는 여가 시간에 종이학과 다른 종이 동물들을 접는다. 평일에는, 그녀는 오직 자기 휴대폰으로 영상을 보는 것으로만 새 모양을 배운다. 주말에는, 그녀는 이모를 한 단계씩 따라 하는 것으로 새 모양을 배운다. 그래서 평일에, 태리는 오직 ______ 새 모양을 배운다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on weekdays, Taeri learns new shapes only by»(그래서 평일에, 태리는 오직 … 새 모양을 배운다) 뒤가 비어 있어요. 평일에 태리가 새 모양을 배우는 방법을 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On weekdays, she learns new shapes only by watching videos on her phone.»(평일에는, 그녀는 오직 자기 휴대폰으로 영상을 보는 것으로만 새 모양을 배운다.) 'watching videos on her phone'(자기 휴대폰으로 영상을 보는 것)이 그대로 나와요. 빈칸 문장과 같은 평일의 이야기이고 'only'(오직)도 같으니, 평일에 배우는 방법은 휴대폰 영상 보기 하나예요.",
 "3) 확인: 셋째 문장 «On weekends, she learns new shapes by copying her aunt step by step.»(주말에는, 그녀는 이모를 한 단계씩 따라 하는 것으로 새 모양을 배운다.) 'copying her aunt step by step'(이모를 한 단계씩 따라 하는 것)은 'On weekends'(주말에는)의 방법이에요. 평일의 방법이 아니에요.",
 "4) 묶기: 평일에 태리가 새 모양을 배우는 방법 = 'watching videos on her phone'(자기 휴대폰으로 영상을 보는 것)."],
 traps="「이모를 한 단계씩 따라 하는 것으로만」이 끌릴 수 있어요. 셋째 문장에 그 말이 그대로 나오고, 이모를 따라 하며 배운다는 말도 자연스럽거든요. 하지만 그것은 주말의 방법이고, 둘째 문장은 평일에는 'only by watching videos on her phone'(오직 자기 휴대폰으로 영상을 보는 것으로만) 배운다고 해요.",
 cn=[("책에 있는 그림을 보는 것으로만", "책은 글에 나오지 않아요. 둘째 문장 «On weekdays, she learns new shapes only by watching videos on her phone.»에서 평일에 태리가 새 모양을 배우는 방법은 오직 자기 휴대폰으로 영상을 보는 것이에요."),
     ("자기 휴대폰으로 영상을 보는 것으로만", "둘째 문장 «On weekdays, she learns new shapes only by watching videos on her phone.»이 근거예요. 평일에 태리는 오직 자기 휴대폰으로 영상을 보는 것으로만 새 모양을 배우니, 빈칸 문장의 평일 배우는 방법도 이것이에요."),
     ("이모를 한 단계씩 따라 하는 것으로만", "셋째 문장 «On weekends, she learns new shapes by copying her aunt step by step.»에서 이모를 따라 하는 것은 주말의 방법이에요. 평일에는 둘째 문장대로 'only by watching videos on her phone'(오직 자기 휴대폰으로 영상을 보는 것으로만) 배워요."),
     ("학교 미술 선생님께 여쭤보는 것으로만", "미술 선생님은 글에 나오지 않아요. 둘째 문장 «On weekdays, she learns new shapes only by watching videos on her phone.»에서 'only by'(오직 …으로만)라고 하니, 평일에 태리가 새 모양을 배우는 방법은 휴대폰으로 영상을 보는 것 하나뿐이에요."),
     ("헌 종이로 새 접기를 해 보는 것으로만", "헌 종이는 글에 나오지 않아요. 첫째 문장의 'paper cranes and other paper animals'(종이학과 다른 종이 동물들) 때문에 종이 접기로 끌릴 수 있지만, 둘째 문장에서 평일에는 'only by watching videos on her phone'(오직 자기 휴대폰으로 영상을 보는 것으로만) 새 모양을 배워요.")])
K[16] = dict(
 ko="우진이는 매주 금요일 오후에 자기 학교 체스 동아리에서 체스를 둔다. 매 경기가 끝난 뒤, 이긴 사람은 항상 벽에 붙은 기록표에 점수를 적어야 한다. 진 사람은 항상 말들을 상자에 다시 넣어야 한다. 그래서 이긴 뒤에, 우진이는 항상 ______ 한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So after a win, Woojin must always»(그래서 이긴 뒤에, 우진이는 항상 … 해야 한다) 뒤가 비어 있어요. 이긴 뒤에 우진이가 항상 해야 하는 일을 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «After each game, the winner must always write the score on the wall chart.»(매 경기가 끝난 뒤, 이긴 사람은 항상 벽에 붙은 기록표에 점수를 적어야 한다.) 'write the score on the wall chart'(벽에 붙은 기록표에 점수를 적다)가 그대로 나와요. 'the winner'(이긴 사람)의 규칙이고 'must always'(항상 ~해야 한다)도 빈칸 문장과 같으니, 이긴 우진이가 할 일이에요.",
 "3) 확인: 셋째 문장 «The loser must always put the pieces back in the box.»(진 사람은 항상 말들을 상자에 다시 넣어야 한다.) 'put the pieces back in the box'(말들을 상자에 다시 넣다)는 'The loser'(진 사람)의 규칙이에요. 빈칸 문장은 이긴 뒤의 일을 물으니, 이 일은 빠져요.",
 "4) 묶기: 이긴 뒤 우진이가 항상 해야 하는 일 = 'write the score on the wall chart'(벽에 붙은 기록표에 점수를 적다)."],
 traps="「말들을 상자에 다시 넣어야」가 끌릴 수 있어요. 셋째 문장에 그 표현이 그대로 나오고, 'must always'(항상 ~해야 한다)도 빈칸 문장과 똑같아서 경기 뒤의 일로 자연스럽거든요. 하지만 그것은 진 사람의 규칙이고, 둘째 문장은 'the winner'(이긴 사람)가 항상 벽에 붙은 기록표에 점수를 적어야 한다고 해요.",
 cn=[("선생님을 상대로 다음 경기를 해야", "선생님과의 경기는 글에 나오지 않아요. 둘째 문장 «After each game, the winner must always write the score on the wall chart.»에서 이긴 사람이 항상 해야 하는 일은 벽에 붙은 기록표에 점수를 적는 것이에요."),
     ("말들을 상자에 다시 넣어야", "셋째 문장 «The loser must always put the pieces back in the box.»에서 말들을 상자에 다시 넣는 것은 진 사람의 일이에요. 이긴 사람은 둘째 문장대로 항상 벽에 붙은 기록표에 점수를 적어야 해요."),
     ("부드러운 천으로 체스판을 닦아야", "체스판을 닦는 일은 글에 나오지 않아요. 둘째 문장에서 'the winner'(이긴 사람)가 할 일은 점수를 적는 것이고, 셋째 문장에서 'The loser'(진 사람)가 할 일은 말들을 상자에 다시 넣는 것이에요."),
     ("벽에 붙은 기록표에 점수를 적어야", "둘째 문장 «After each game, the winner must always write the score on the wall chart.»이 근거예요. 경기가 끝나면 이긴 사람은 항상 벽에 붙은 기록표에 점수를 적어야 하니, 이긴 뒤의 우진이도 그 일을 해야 해요."),
     ("더 어린 부원에게 새로운 수를 가르쳐야", "어린 부원을 가르친다는 이야기는 글에 나오지 않아요. 둘째 문장에서 'the winner'(이긴 사람)가 항상 해야 하는 일은 벽에 붙은 기록표에 점수를 적는 것이에요.")])
K[17] = dict(
 ko="매주 일요일, 채윤이와 엄마는 소풍을 하러 작은 언덕에 오른다. 엄마는 항상 큰 바구니를 샌드위치와 차가운 우유로 채운다. 채윤이는 자기만의 작은 바구니를 오렌지와 물 한 병으로 채운다. 그래서 일요일마다, 채윤이만의 바구니에 든 것은 ______이다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Sundays, Chaeyun's own basket holds»(그래서 일요일마다, 채윤이만의 바구니에 든 것은 …) 뒤가 비어 있어요. 채윤이만의 바구니에 무엇이 들어 있는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Chaeyun fills her own small basket with oranges and a bottle of water.»(채윤이는 자기만의 작은 바구니를 오렌지와 물 한 병으로 채운다.) 'oranges and a bottle of water'(오렌지와 물 한 병)가 그대로 나와요. 'her own'(자기만의) 바구니 이야기이니, 빈칸 문장이 묻는 채윤이만의 바구니와 같아요.",
 "3) 확인: 둘째 문장 «Mom always fills the big basket with sandwiches and cold milk.»(엄마는 항상 큰 바구니를 샌드위치와 차가운 우유로 채운다.) 'sandwiches and cold milk'(샌드위치와 차가운 우유)는 엄마가 채우는 'the big basket'(큰 바구니)에 든 것이에요. 'always'(항상)도 엄마의 큰 바구니에 걸린 말이에요.",
 "4) 묶기: 채윤이만의 바구니에 든 것 = 'oranges and a bottle of water'(오렌지와 물 한 병)."],
 traps="「샌드위치와 차가운 우유」가 끌릴 수 있어요. 둘째 문장에 그 말이 그대로 나오고, 'always'(항상)까지 있어서 일요일 소풍 바구니에 늘 드는 것처럼 보이거든요. 하지만 그것은 엄마가 채우는 큰 바구니이고, 셋째 문장은 채윤이가 'her own small basket'(자기만의 작은 바구니)을 오렌지와 물 한 병으로 채운다고 해요.",
 cn=[("샌드위치와 차가운 우유", "둘째 문장 «Mom always fills the big basket with sandwiches and cold milk.»에서 샌드위치와 차가운 우유는 엄마가 채우는 큰 바구니에 들어요. 채윤이만의 바구니에는 셋째 문장대로 'oranges and a bottle of water'(오렌지와 물 한 병)가 들어요."),
     ("쿠키와 딸기 우유", "쿠키와 딸기 우유는 글에 나오지 않아요. 둘째 문장의 'cold milk'(차가운 우유) 때문에 끌릴 수 있지만 그것은 엄마의 큰 바구니에 드는 것이고, 셋째 문장 «Chaeyun fills her own small basket with oranges and a bottle of water.»에서 채윤이가 자기만의 바구니에 채우는 것은 오렌지와 물 한 병이에요."),
     ("포도와 차가운 주스 두 캔", "포도와 주스는 글에 나오지 않아요. 셋째 문장 «Chaeyun fills her own small basket with oranges and a bottle of water.»에서 채윤이가 자기만의 바구니에 채우는 것은 오렌지와 물 한 병이에요."),
     ("주먹밥과 약간의 녹차", "주먹밥과 녹차는 글에 나오지 않아요. 둘째 문장에서 엄마는 큰 바구니를 샌드위치와 차가운 우유로 채우고, 셋째 문장에서 채윤이는 'her own small basket'(자기만의 작은 바구니)을 오렌지와 물 한 병으로 채워요."),
     ("오렌지와 물 한 병", "셋째 문장 «Chaeyun fills her own small basket with oranges and a bottle of water.»이 근거예요. 채윤이는 자기만의 작은 바구니를 오렌지와 물 한 병으로 채우니, 일요일마다 채윤이만의 바구니에 든 것도 오렌지와 물 한 병이에요.")])
K[18] = dict(
 ko="효빈이와 그녀의 오빠는 매주 토요일 동물 보호소에서 일을 돕는다. 그녀의 오빠는 강을 따라 개들을 산책시키러 그곳에 간다. 효빈이는 오직 작은 토끼 우리들을 청소하러 그곳에 간다. 그래서 매주 토요일, 효빈이는 오직 ______ 보호소에 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every Saturday, Hyobin goes to the shelter only»(그래서 매주 토요일, 효빈이는 오직 … 보호소에 간다) 뒤가 비어 있어요. 효빈이가 무엇을 하러 보호소에 가는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Hyobin goes there only to clean the small rabbit cages.»(효빈이는 오직 작은 토끼 우리들을 청소하러 그곳에 간다.) 'to clean the small rabbit cages'(작은 토끼 우리들을 청소하러)가 그대로 나와요. 이 문장의 'only'(오직)이 빈칸 문장의 'only'(오직)을 받쳐 주니, 효빈이가 보호소에 가는 목적은 토끼 우리 청소 하나예요.",
 "3) 확인: 둘째 문장 «Her older brother goes there to walk the dogs along the river.»(그녀의 오빠는 강을 따라 개들을 산책시키러 그곳에 간다.) 'to walk the dogs along the river'(강을 따라 개들을 산책시키러)는 'Her older brother'(그녀의 오빠)가 가는 목적이에요. 효빈이는 셋째 문장대로 오직 토끼 우리를 청소하러 가니, 산책은 빠져요.",
 "4) 묶기: 효빈이가 보호소에 가는 목적 = 'to clean the small rabbit cages'(작은 토끼 우리들을 청소하러)."],
 traps="「강을 따라 개들을 산책시키러」가 끌릴 수 있어요. 둘째 문장에 그 말이 그대로 나오고, 빈칸 문장만 보면 보호소에 개를 산책시키러 간다는 말이 아주 자연스럽거든요. 하지만 그것은 오빠가 가는 목적이고, 셋째 문장은 효빈이가 'only'(오직) 작은 토끼 우리들을 청소하러 간다고 해요.",
 cn=[("마당에서 강아지들을 씻기러", "강아지를 씻긴다는 이야기는 글에 나오지 않아요. 셋째 문장 «Hyobin goes there only to clean the small rabbit cages.»에서 효빈이는 'only'(오직) 작은 토끼 우리들을 청소하러 보호소에 가요."),
     ("작은 토끼 우리들을 청소하러", "셋째 문장 «Hyobin goes there only to clean the small rabbit cages.»이 근거예요. 효빈이는 오직 작은 토끼 우리들을 청소하러 보호소에 가니, 토요일마다 보호소에 가는 목적도 오직 그것이에요."),
     ("강을 따라 개들을 산책시키러", "둘째 문장 «Her older brother goes there to walk the dogs along the river.»에서 개들을 산책시키러 가는 사람은 효빈이의 오빠예요. 효빈이는 셋째 문장 «Hyobin goes there only to clean the small rabbit cages.»의 'only'(오직)대로 작은 토끼 우리들을 청소하러만 가요."),
     ("작은 새끼 고양이들과 놀러", "새끼 고양이는 글에 나오지 않아요. 둘째 문장에서 오빠는 개들을 산책시키러 가고, 셋째 문장에서 효빈이는 'only'(오직) 작은 토끼 우리들을 청소하러 가요."),
     ("마당의 낡은 울타리를 고치러", "울타리는 글에 나오지 않아요. 셋째 문장에서 효빈이는 'only to clean the small rabbit cages'(오직 작은 토끼 우리들을 청소하러) 보호소에 가요.")])
K[19] = dict(
 ko="시호는 매일 저녁 작은 일기장에 날씨에 대해 쓴다. 그 일기장은 또한 엄마가 빨래하기에 가장 좋은 날을 고르는 것을 도와준다. 할아버지에게는, 그 일기장이 오직 알맞은 날에 정원에 물을 주는 것만 도와준다. 그래서 할아버지에게는, 시호의 날씨 일기장이 오직 ______만 도와준다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So Siho's weather diary only helps Grandpa»(그래서 할아버지에게는, 시호의 날씨 일기장이 오직 …만 도와준다) 뒤가 비어 있어요. 일기장이 할아버지를 돕는 단 하나의 일을 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The diary only helps Grandpa water his garden on the right days.»(할아버지에게는, 그 일기장이 오직 알맞은 날에 정원에 물을 주는 것만 도와준다.) 'water his garden on the right days'(알맞은 날에 정원에 물을 주는 것)가 그대로 나와요. 이 'only'(오직)는 빈칸 문장처럼 할아버지가 받는 도움에 걸리니, 할아버지 쪽 일은 정원에 물 주기 하나예요.",
 "3) 확인: 둘째 문장 «The diary also helps Mom choose the best days for the laundry.»(그 일기장은 또한 엄마가 빨래하기에 가장 좋은 날을 고르는 것을 도와준다.) 'choose the best days for the laundry'(빨래하기에 가장 좋은 날을 고르는 것)는 'Mom'(엄마)이 받는 도움이에요. 'also'(또한)는 엄마 쪽의 말이고, 할아버지가 받는 도움이 아니에요.",
 "4) 묶기: 일기장이 할아버지를 돕는 일 = 'water his garden on the right days'(알맞은 날에 정원에 물을 주는 것)."],
 traps="「빨래하기에 가장 좋은 날을 고르는 것」이 끌릴 수 있어요. 둘째 문장에 그 말이 그대로 나오고, 날씨 일기장이 도울 일로 자연스럽거든요. 하지만 그것은 엄마가 받는 도움이고, 셋째 문장은 할아버지에게는 일기장이 'only'(오직) 정원에 물을 주는 것만 도와준다고 해요.",
 cn=[("공원에서 할 긴 산책을 계획하는 것", "산책은 글에 나오지 않아요. 셋째 문장 «The diary only helps Grandpa water his garden on the right days.»에서 일기장이 할아버지를 돕는 일은 오직 알맞은 날에 정원에 물을 주는 것이에요."),
     ("빨래하기에 가장 좋은 날을 고르는 것", "둘째 문장 «The diary also helps Mom choose the best days for the laundry.»에서 빨래하기에 가장 좋은 날을 고르는 것은 일기장이 엄마를 돕는 일이에요. 할아버지에게는 셋째 문장 «The diary only helps Grandpa water his garden on the right days.»대로 'only'(오직) 알맞은 날에 정원에 물을 주는 것만 도와줘요."),
     ("큰 폭풍이 오기 전에 지붕을 고치는 것", "지붕과 폭풍은 글에 나오지 않아요. 셋째 문장에서 일기장이 할아버지를 돕는 일은 오직 'water his garden on the right days'(알맞은 날에 정원에 물을 주는 것)예요."),
     ("알맞은 날에 정원에 물을 주는 것", "셋째 문장 «The diary only helps Grandpa water his garden on the right days.»이 근거예요. 할아버지에게는 일기장이 오직 알맞은 날에 정원에 물을 주는 것만 도와주니, 빈칸 문장이 묻는 할아버지 쪽의 도움도 이것이에요."),
     ("교회에 입고 갈 알맞은 외투를 고르는 것", "외투는 글에 나오지 않아요. 둘째 문장에서 일기장이 엄마를 돕는 일은 빨래하기에 가장 좋은 날을 고르는 것이고, 셋째 문장에서 할아버지를 돕는 일은 오직 'water his garden on the right days'(알맞은 날에 정원에 물을 주는 것)예요.")])
