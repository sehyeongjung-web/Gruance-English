# -*- coding: utf-8 -*-
# 19번(심경 변화) 레벨1 새 원고 n=0~9 — I[n] = dict(S=[네 문장], ch={0..4: 'a → b'})
I = {}
I[0] = dict(S=['Before her first piano recital, Harin felt scared of the big stage.',
 'Her piano teacher in the front row looked calm and gave her a smile.',
 'Harin played her song without a single mistake in front of everyone.',
 'At the end, Harin felt very proud and bowed to her family.'],
 ch={0:'scared → proud', 1:'calm → proud', 2:'scared → upset', 3:'calm → upset', 4:'excited → upset'})
I[1] = dict(S=['On a windy hill, Doha felt very excited about his new red kite.',
 'His younger brother looked bored on a bench under a tall tree.',
 'Suddenly, a strong wind broke the string and carried the kite away.',
 'Doha felt very sad on the long walk home without his kite.'],
 ch={0:'bored → sad', 1:'excited → angry', 2:'bored → angry', 3:'excited → sad', 4:'curious → angry'})
I[2] = dict(S=['On Saturday, Seri felt bored in her room during the heavy rain.',
 'Her older brother was happy with his new video game in the living room.',
 'On Sunday, her best friend Yuna canceled their plans for a movie.',
 'Seri felt very lonely by the window for the rest of the day.'],
 ch={0:'happy → lonely', 1:'bored → upset', 2:'happy → upset', 3:'tired → upset', 4:'bored → lonely'})
I[3] = dict(S=['On Sunday morning, Eunho was curious about a loud knock at the door.',
 'His uncle from Jeju stood at the door and looked tired after the long trip.',
 "Eunho's mother looked surprised at the sight of her younger brother.",
 'All day long, Eunho felt very happy with his funny uncle.'],
 ch={0:'curious → happy', 1:'surprised → happy', 2:'curious → tired', 3:'surprised → tired', 4:'scared → tired'})
I[4] = dict(S=['Gyuri gave a speech for class president in front of her whole class.',
 'Before the speech, Gyuri felt very nervous and held her notes tightly.',
 'Her best friend Dabin in the front row looked calm and gave her a smile.',
 'After the speech, Gyuri felt relieved at the loud cheers from her classmates.'],
 ch={0:'calm → relieved', 1:'nervous → disappointed', 2:'calm → disappointed', 3:'nervous → relieved', 4:'bored → disappointed'})
I[5] = dict(S=['Siwan felt excited about his first trip to a baseball stadium with his dad.',
 'On Saturday morning, the stadium canceled the game because of heavy rain.',
 'Siwan was very disappointed and stayed in his room until lunch.',
 'His younger sister felt relieved about a quiet day at home with her dolls.'],
 ch={0:'curious → disappointed', 1:'excited → relieved', 2:'curious → relieved', 3:'nervous → relieved', 4:'excited → disappointed'})
I[6] = dict(S=['On Monday, Yeseul felt worried about the new route of her school bus.',
 'The bus driver looked a little tired on the first morning of the route.',
 'The new route went past a beautiful lake with many white birds.',
 'Yeseul was glad about the new view from her window seat.'],
 ch={0:'tired → glad', 1:'worried → bored', 2:'worried → glad', 3:'tired → bored', 4:'scared → bored'})
I[7] = dict(S=['Minha was very happy with her new phone from her parents.',
 'Her older sister looked curious about the new phone at dinner.',
 'On Friday, the phone fell from her hand and broke on the bus floor.',
 'Minha felt very upset and cried quietly all the way home from school.'],
 ch={0:'curious → upset', 1:'happy → angry', 2:'curious → angry', 3:'happy → upset', 4:'excited → angry'})
I[8] = dict(S=["On Sunday morning, Taerin's little puppy Coco was not in the yard.",
 'Taerin felt very scared and looked for Coco all over town.',
 'Her older brother looked calm and put up posters on every street.',
 'By night, Taerin was very sad without any news of her puppy.'],
 ch={0:'calm → sad', 1:'scared → relieved', 2:'scared → sad', 3:'calm → relieved', 4:'tired → relieved'})
I[9] = dict(S=['Jaeyun was excited about the school cooking contest on Friday afternoon.',
 'His partner Sohyun looked nervous in front of the three judges.',
 'The two friends made spicy kimchi soup together for the judges.',
 'With the first prize in his hands, Jaeyun felt very proud of their soup.'],
 ch={0:'nervous → proud', 1:'excited → proud', 2:'excited → lonely', 3:'nervous → lonely', 4:'bored → lonely'})
