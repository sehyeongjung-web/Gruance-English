# -*- coding: utf-8 -*-
# 40번 레벨1 한글 원고 자체 검사.  python3 draft/zk75.py <k파일> [<d파일: 기본 draft/d75.py>]
#   K[n] = dict(kop=지문 해석, kosm=요약문 해석((A) ______ · (B) ______), steps=[4줄], trap=끌리는 오답, reasons=[선택지별 까닭 5], gl=['뜻 - 뜻' ×5], words='낱말 줄')
import sys, re, importlib.util
sys.path.insert(0, '/home/claude/work')
def load(p, nm):
    spec = importlib.util.spec_from_file_location(nm, p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
kf = load(sys.argv[1], 'kk'); df = load(sys.argv[2] if len(sys.argv) > 2 else '/home/claude/work/draft/d75.py', 'dd')
from z40rw import maker
from z40common import HEADS
bad = 0
def warn(n, msg):
    global bad; bad += 1; print('!! n=%d  %s' % (n, msg))
for n, K in sorted(kf.K.items()):
    I = df.I[n]; P = I['S']; SM = I['SM']; CH = [I['ch'][k] for k in range(5)]
    full = ' '.join(P) + ' ' + SM
    words = set(re.findall(r"[A-Za-z']+", full.lower())) | set(w for c in CH for w in re.findall(r"[a-z']+", c))
    try:
        E = {}; maker(E, '1')(n, P, SM, CH, K['kop'], K['kosm'], K['steps'], K['trap'], K['reasons'], K['gl'], K.get('words'))
    except AssertionError as e:
        warn(n, 'z40rw 거절: %s' % (e,)); continue
    if K['kop'].count('______'): warn(n, '지문 해석(kop)에 빈칸이 있음')
    if K['kosm'].count('(A) ______') != 1 or K['kosm'].count('(B) ______') != 1: warn(n, '요약문 해석에 (A) ______ · (B) ______ 하나씩')
    allk = ' '.join(K['steps']) + ' ' + K['trap'] + ' ' + ' '.join(K['reasons']) + ' ' + ' '.join(K['gl'])
    if re.search(r'니다[\.\s]', allk) or re.search(r'니다$', allk): warn(n, '「~니다」 말끝 금지(~어요)')
    if '"' in allk: warn(n, '큰따옴표 대신 «» 를 쓸 것')
    for q in re.findall(r"(?<![A-Za-z])'([A-Za-z][^'»]*?)'(?![A-Za-z])", allk):
        toks = re.findall(r"[A-Za-z]+", q.lower())
        if any(t not in words for t in toks): warn(n, "'%s' 지문·요약문·선택지에 없는 영어 낱말" % q)
    if re.search(r'\d+번', allk): warn(n, '숫자 + 「번」은 풀이에 쓰지 말 것(문항 번호로 읽힘)')
    L = sum(len(s) for s in K['steps']) + len(K['trap'])
    if not (480 <= L <= 900): warn(n, '풀이+끌리는 오답 길이 %d자(480~900자)' % L)
    for k, g in enumerate(K['gl']):
        if len(g.split(' - ')) != 2: warn(n, 'gl[%d] 「뜻 - 뜻」 꼴' % k)
print('검사 끝 — 걸린 것 %d' % bad)
