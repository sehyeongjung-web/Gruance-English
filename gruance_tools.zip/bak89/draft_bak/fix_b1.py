import sys,os; sys.path.insert(0,'/home/claude/work/draft'); os.chdir('/home/claude/work')
from fixlib import *
k=load('draft/k68b.py')
k=erep(k,'K',15,[
 ("날개를 조금 쉴 수 있다.","날개를 조금 쉬게 할 수 있다.",2),
 ("날개를 조금 쉴 수 있다고 했어요.","날개를 조금 쉬게 할 수 있다고 했어요."),
 ("뒤의 새들은 날개를 쉴 수 있어요.","뒤의 새들은 날개를 쉬게 할 수 있어요."),
])
k=erep(k,'K',16,[
 ("공기는 가득하고 젖은 것이 없다는 점이에요. 빛은 나오지 않아요.","공기는 가득하고 젖은 것이 없다는 점이에요. 셋째 문장에서 씨앗을 깨우는 것은 젖은 따뜻한 흙이에요. 흙에 놓으면 빛이 더해진다는 말은 없어요."),
 ('("빛", "지문에 없는 이야기예요. 빛 이야기는 글에 나오지 않아요. 씨앗에게 없는 것은 젖은 것이에요.")','("빛", "셋째 문장에서 씨앗을 깨우는 것은 젖은 따뜻한 흙이고, 빛을 더해 준다는 말은 없어요. 씨앗에게 없는 것은 젖은 것이에요.")'),
])
k=erep(k,'K',19,[
 ("물에는 작은 부분이 서로 가까이 많이 있지만, 공기에는 훨씬 적다. 한 부분에 가해진 힘은 다음 부분에 거의 곧바로 닿는다.","물은 눌러서 줄이기가 아주 어렵지만, 공기는 눌러서 줄이기가 쉽다. 물의 한 부분에 가해진 힘은 다음 부분에 거의 곧바로 닿는다."),
 ("«A push on one part reaches the next part almost at once.»(한 부분에 가해진 힘은 다음 부분에 거의 곧바로 닿는다.)","«A push on one part of water reaches the next part almost at once.»(물의 한 부분에 가해진 힘은 다음 부분에 거의 곧바로 닿는다.)"),
 ("«A push on one part reaches the next part almost at once.»가 근거예요.","«A push on one part of water reaches the next part almost at once.»가 근거예요."),
 ("«Water has many tiny parts close together, but air has far fewer.»(물에는 작은 부분이 서로 가까이 많이 있지만, 공기에는 훨씬 적다.) 물속에는 힘을 전해 줄 부분이 많이 붙어 있어요.","«Water is very hard to squeeze, but air is easy to squeeze.»(물은 눌러서 줄이기가 아주 어렵지만, 공기는 눌러서 줄이기가 쉽다.) 물과 공기가 서로 다르다는 말이에요."),
 ("'faster'(더 빠르다)","'faster'(더 빠르게)"),
 ("노래가 물속에서 공기 속과 견주어 어떻게 움직이는지를 물어요.","노래가 물속에서 공기 속과 견주어 얼마나 빠르게 움직이는지를 물어요."),
 ("「더 느린」이 끌릴 수 있어요. 물이 공기보다 빽빽해서 느릴 것 같거든요. 하지만 셋째 문장은 힘이 다음 부분에 거의 곧바로 닿는다고 했어요.","「더 느리게」가 끌릴 수 있어요. 물속에서는 움직임이 더 느릴 것 같거든요. 하지만 셋째 문장은 힘이 다음 부분에 거의 곧바로 닿는다고 했어요. 「더 낮게」는 첫 문장의 'low song'(낮은 노래)만 본 것이에요. 낮은 것은 노래의 소리 높이이고, 빈칸은 움직이는 빠르기를 말해요."),
 ('("더 부드러운",','("더 부드럽게",'),
 ('("더 느린",','("더 느리게",'),
 ('("더 약한", "지문에 없는 이야기예요. 소리의 세기는 글에 나오지 않아요.")','("더 낮게", "첫 문장의 낮은 노래만 본 것이에요. 빈칸은 움직이는 빠르기를 물어요. 노래가 물속에서 더 낮아진다는 말은 없어요.")'),
 ('("더 늦은",','("더 늦게",'),
 ('("더 빠른",','("더 빠르게",'),
])
k=erep(k,'K',20,[
 ("곤충과 맞서는 거미의 모습을 물어요.","곤충과 대비되는 거미의 모습을 물어요."),
 ("거미는 접착제가 없는 가닥 위를 걸어요. 'no glue'","거미는 주로 접착제가 없는 가닥 위를 걸어요. 'no glue'"),
 ("접착제 없는 가닥 위를 걸어 어려움이 없다 =","주로 접착제 없는 가닥 위를 걸어 어려움이 없다 ="),
 ("거미는 접착제 없는 가닥 위를 걸어요.","거미는 주로 접착제 없는 가닥 위를 걸어요."),
 ("거미는 접착제가 없는 가닥 위를 걸어서","거미는 주로 접착제가 없는 가닥 위를 걸어서"),
])
save('draft/k68b.py',k)
d=load('draft/d68b.py')
def rp(s,old,new):
    assert s.count(old)==1,old; return s.replace(old,new)
d=rp(d,"Water has many tiny parts close together, but air has far fewer.","Water is very hard to squeeze, but air is easy to squeeze.")
d=rp(d,"A push on one part reaches the next part almost at once.","A push on one part of water reaches the next part almost at once.")
d=rp(d,"ch={0: 'softer', 1: 'slower', 2: 'weaker', 3: 'later', 4: 'faster'}","ch={0: 'softer', 1: 'slower', 2: 'lower', 3: 'later', 4: 'faster'}")
save('draft/d68b.py',d)
print('ok')
