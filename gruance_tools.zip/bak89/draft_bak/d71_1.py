I = {}
I[0] = dict(S=['Yuna had a birthday party at her house last Sunday afternoon.',
 'Her aunt baked a big strawberry cake for the party in the morning.',
 'Her mother and her uncle brought fruit and juice from the market.',
 "So every guest thanked Yuna's ______ for the sweet strawberry cake."],
 ch={0:'aunt',1:'mother',2:'grandmother',3:'uncle',4:'sister'})
I[1] = dict(S=["Ben's little dog ran away from home during a storm last night.",
 'Ben and his dad looked for the dog at the park and the school.',
 'In the morning, a neighbor found the dog asleep in her yard.',
 "So the little dog slept in a ______ near Ben's house that night."],
 ch={0:'park',1:'school',2:'kitchen',3:'yard',4:'forest'})
I[2] = dict(S=['Jun stayed with his grandmother in the country for the winter vacation.',
 'On the first day, she gave him a warm red hat.',
 'His mother also put a wool scarf in his bag before the trip.',
 'On the cold train home, Jun wore the ______ from his grandmother.'],
 ch={0:'coat',1:'scarf',2:'sweater',3:'hat',4:'jacket'})
I[3] = dict(S=['Sora wanted to learn swimming at the city pool this spring.',
 'All the classes on Monday were already full of other children.',
 'The teacher still had one open place in the class on Thursday.',
 'So Sora will go to her first class at the pool next ______.'],
 ch={0:'Monday',1:'Tuesday',2:'Saturday',3:'Friday',4:'Thursday'})
I[4] = dict(S=["Heavy snow fell on Mr. Park's small town early on Tuesday morning.",
 'He still got to his bakery through the snow at six as usual.',
 'There, the big oven in the kitchen did not work until ten o\'clock.',
 'So Mr. Park opened his shop very late on Tuesday because of the ______.'],
 ch={0:'snow',1:'oven',2:'rain',3:'traffic',4:'wind'})
I[5] = dict(S=["Jin's family drove to Green Lake for a picnic on a sunny Sunday.",
 'The water near the shore was clean and not very deep.',
 'Jin put his feet in the water and found it very cold.',
 'So Jin did not swim in the ______ lake water during the picnic.'],
 ch={0:'warm',1:'deep',2:'cold',3:'dirty',4:'dark'})
I[6] = dict(S=["Mr. Cho's old car did not start on Monday morning in May.",
 'His bike behind the house also had a flat tire.',
 'He walked to his office for forty minutes in the warm sun.',
 'So on Monday morning, Mr. Cho ______ all the way to his office.'],
 ch={0:'drove',1:'walked',2:'rode',3:'ran',4:'jogged'})
I[7] = dict(S=['Last year, Leo sometimes missed breakfast on his busy school mornings.',
 'In March, he started to get up thirty minutes earlier on school days.',
 'Now he always has toast, an egg and milk at home before school.',
 'So these days, Leo ______ eats breakfast at home on school days.'],
 ch={0:'never',1:'rarely',2:'sometimes',3:'seldom',4:'always'})
I[8] = dict(S=['Minsu wanted a red school bag for the new school year in March.',
 'The shop near his house had only black and blue bags.',
 'He chose the blue one with many big pockets on the front.',
 'So Minsu carried a new ______ bag to school on the first day.'],
 ch={0:'red',1:'black',2:'green',3:'brown',4:'blue'})
I[9] = dict(S=["Mr. Han's class chose a new class leader on Friday afternoon.",
 'Mina and Junho both wanted the job of class leader very much.',
 'In the end, Yeji got the most votes from the students.',
 "So ______ will lead Mr. Han's class for the rest of the year."],
 ch={0:'Mina',1:'Yeji',2:'Junho',3:'Sumi',4:'Daeho'})
