# -*- coding: utf-8 -*-
# 원고(d68x.I)와 한글(k68x.K)을 합쳐 pending/edits_X68x.py를 만든다.  python3 draft/gen67.py a   (뒷 절반은 b)
import sys, pprint, importlib
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
d = importlib.import_module('d68' + tag); k = importlib.import_module('k68' + tag)
ns = sorted(d.I)
assert sorted(k.K) == ns, (sorted(k.K), ns)
head = '앞' if tag == 'a' else '뒤'
from lib import load
_, tb, _ = load('/home/claude/work/out/index.html')
out = ['# -*- coding: utf-8 -*-',
       '# %s번: 32번(빈칸) 레벨2 %s 절반 — 네 문장 · 평균 52낱말쯤 · 문장당 10~15낱말 · and·but·so·or로 단문을 이음. 정답 번호는 바탕 그대로, 지문·해석·풀이·해설을 통째로 다시 씀' % ('347' if tag == 'a' else '348', head),
       'AUTO_SYNC = False', 'E = {}',
       'from z8common import maker, _tb', "T, LV = '32', '2'", 'mk = maker(E, T, lv=LV)',
       'def rw(n, ans, text, ko, steps, traps, cn, ch=None):',
       '    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=bool(ch and ans in ch)); e = E.pop((T, LV, n))',
       "    choices = list(_tb[T][LV][n]['choices'])",
       '    for kk, vv in (ch or {}).items(): choices[kk] = vv',
       "    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(choices)) == 5, n",
       "    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,",
       "                     'rewrite': {'text': text, 'choices': choices, 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][kk] for kk in range(5)]}}", '']
for n in ns:
    I = d.I[n]; K = k.K[n]; ans = tb['32']['2'][n]['answer']
    text = ' '.join(I['S'])
    ch = I.get('ch')
    out.append('# %d번째' % (n + 1))
    out.append('rw(%d, %d,\n   %r,\n   %r,\n   %s,\n   %r,\n   %s%s)\n' % (n, ans, text, K['ko'], pprint.pformat(K['steps'], width=200), K['traps'], pprint.pformat(K['cn'], width=200), (',\n   ch=%r' % ch) if ch else ''))
open('/home/claude/work/pending/edits_X68%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X68%s.py (%d문항)' % (tag, len(ns)))
