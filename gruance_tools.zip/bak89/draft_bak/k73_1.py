# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 한글 (d73.py I[0]~I[4]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[0] = dict(
 ko="지수는 자기 방의 큰 상자 안에 작은 갈색 토끼 한 마리를 키운다. 학교 가는 날에는, 그녀는 오직 저녁 식사 뒤에만 그 상자를 청소한다. 토요일마다, 그녀는 아빠의 도움을 받아 아침 식사 뒤에 그것을 청소한다. 그래서 학교 가는 날에, 지수는 자기 토끼의 상자를 ______ 청소한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on school days, Jisu cleans her rabbit's box»(그래서 학교 가는 날에, 지수는 자기 토끼의 상자를 … 청소한다) 뒤가 비어 있어요. 지수가 학교 가는 날 상자를 언제 청소하는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On school days, she cleans the box only after her dinner.»(학교 가는 날에는, 그녀는 오직 저녁 식사 뒤에만 그 상자를 청소한다.) 'after her dinner'(저녁 식사 뒤에)가 그대로 나와요. 빈칸 문장과 같은 학교 가는 날의 이야기이니, 청소하는 때는 저녁 식사 뒤예요.",
 "3) 확인: 셋째 문장 «On Saturdays, she cleans it after breakfast with help from her dad.»(토요일마다, 그녀는 아빠의 도움을 받아 아침 식사 뒤에 그것을 청소한다.) 'after breakfast'(아침 식사 뒤에)는 'On Saturdays'(토요일마다) 하는 일이에요. 둘째 문장의 'only'(오직)이 학교 가는 날의 청소 때를 저녁 식사 뒤 하나로 정해요.",
 "4) 묶기: 학교 가는 날 지수가 토끼 상자를 청소하는 때 = 'after her dinner'(저녁 식사 뒤에)."],
 traps="「아침 식사 뒤에」가 끌릴 수 있어요. 셋째 문장에 'after breakfast'(아침 식사 뒤에)가 그대로 나오고, 빈칸 문장만 보면 아침 청소도 자연스럽거든요. 하지만 그것은 'On Saturdays'(토요일마다) 아빠와 함께 하는 일이고, 둘째 문장은 학교 가는 날에는 'only after her dinner'(오직 저녁 식사 뒤에만) 청소한다고 해요. 「학교 가기 전에」도 끌리지만, 같은 둘째 문장이 막아요.",
 cn=[("학교 가기 전에", "학교 가기 전에 청소한다는 이야기는 글에 나오지 않아요. 둘째 문장 «On school days, she cleans the box only after her dinner.»에서 학교 가는 날에는 오직 저녁 식사 뒤에만 상자를 청소한다고 했어요."),
     ("아침 식사 뒤에", "셋째 문장 «On Saturdays, she cleans it after breakfast with help from her dad.»에서 아침 식사 뒤에 청소하는 것은 토요일의 일이에요. 학교 가는 날에는 둘째 문장대로 'only after her dinner'(오직 저녁 식사 뒤에만) 청소해요."),
     ("저녁 식사 뒤에", "둘째 문장 «On school days, she cleans the box only after her dinner.»이 근거예요. 학교 가는 날에는 오직 저녁 식사 뒤에만 상자를 청소하니, 빈칸 문장의 학교 가는 날 청소 때도 저녁 식사 뒤예요."),
     ("점심시간에", "점심시간은 글에 나오지 않아요. 둘째 문장이 말하는 학교 가는 날의 청소 때는 'after her dinner'(저녁 식사 뒤에)이고, 셋째 문장이 말하는 토요일의 청소 때는 'after breakfast'(아침 식사 뒤에)예요."),
     ("집에 가는 길에", "집에 가는 길은 글에 나오지 않아요. 첫째 문장에서 토끼 상자는 'in her room'(자기 방에) 있고, 둘째 문장에서 학교 가는 날에는 'only after her dinner'(오직 저녁 식사 뒤에만) 그 상자를 청소해요.")])
K[1] = dict(
 ko="대호는 친구 세 명과 함께 작은 밴드에서 드럼을 연주한다. 평일 저녁에는, 그는 학교의 음악실에서 혼자 연습한다. 일요일 오후에는, 밴드 전체가 그의 삼촌네 차고에서 연습한다. 그래서 평일 저녁에, 대호는 보통 ______ 자기 드럼을 연주한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on weekday evenings, Daeho usually plays his drums»(그래서 평일 저녁에, 대호는 보통 … 자기 드럼을 연주한다) 뒤가 비어 있어요. 평일 저녁에 대호가 보통 어디에서 드럼을 연주하는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On weekday evenings, he practices alone in the music room at school.»(평일 저녁에는, 그는 학교의 음악실에서 혼자 연습한다.) 'in the music room'(음악실에서)가 그대로 나와요. 빈칸 문장과 같은 평일 저녁의 이야기이니, 대호가 드럼을 연주하는 곳은 음악실이에요.",
 "3) 확인: 셋째 문장 «On Sunday afternoons, the whole band practices in his uncle's garage.»(일요일 오후에는, 밴드 전체가 그의 삼촌네 차고에서 연습한다.) 'garage'(차고)는 'On Sunday afternoons'(일요일 오후에는) 밴드 전체가 연습하는 곳이에요. 평일 저녁의 연습 장소가 아니에요.",
 "4) 묶기: 평일 저녁에 대호가 드럼을 연주하는 곳 = 'in the music room'(음악실에서)."],
 traps="「삼촌네 차고에서」가 끌릴 수 있어요. 셋째 문장에 'garage'(차고)가 나오고, 빈칸 문장만 보면 차고에서 드럼을 연주한다는 말도 자연스럽거든요. 하지만 그것은 'On Sunday afternoons'(일요일 오후에는) 밴드 전체가 연습하는 곳이고, 둘째 문장은 평일 저녁에 대호가 'alone'(혼자) 음악실에서 연습한다고 해요. 「자기 작은 침실에서」도 끌리지만, 둘째 문장이 말하는 평일 저녁의 장소는 음악실이에요.",
 cn=[("음악실에서", "둘째 문장 «On weekday evenings, he practices alone in the music room at school.»이 근거예요. 평일 저녁에 대호는 학교의 음악실에서 혼자 연습하니, 평일 저녁에 보통 드럼을 연주하는 곳도 음악실이에요."),
     ("삼촌네 차고에서", "셋째 문장 «On Sunday afternoons, the whole band practices in his uncle's garage.»에서 삼촌네 차고는 일요일 오후에 밴드 전체가 연습하는 곳이에요. 평일 저녁에는 둘째 문장대로 'in the music room'(음악실에서) 연습해요."),
     ("자기 작은 침실에서", "대호의 침실은 글에 나오지 않아요. 둘째 문장이 말하는 평일 저녁의 연습 장소는 'the music room at school'(학교의 음악실)이에요."),
     ("교회 강당에서", "교회 강당은 글에 나오지 않아요. 둘째 문장에서 평일 저녁에 대호가 연습하는 곳은 학교의 음악실이고, 셋째 문장에서 일요일 오후에 밴드가 연습하는 곳은 그의 삼촌네 차고예요."),
     ("거실에서", "거실은 글에 나오지 않아요. 둘째 문장은 평일 저녁에 대호가 'alone in the music room'(음악실에서 혼자) 연습한다고 해요.")])
K[2] = dict(
 ko="소라는 매주 일요일 아침에 한 시간쯤 배드민턴을 친다. 봄부터 가을까지, 그녀는 가장 친한 친구 아라와 함께 공원에서 친다. 겨울에는, 그녀는 할아버지와 함께 학교 체육관에서 친다. 그래서 봄부터 가을까지, 소라는 매주 일요일 ______ 배드민턴을 친다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So from spring to fall, Sora plays badminton every Sunday»(그래서 봄부터 가을까지, 소라는 매주 일요일 … 배드민턴을 친다) 뒤가 비어 있어요. 봄부터 가을까지 소라가 일요일마다 누구와 함께 배드민턴을 치는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «From spring to fall, she plays at the park with her best friend Ara.»(봄부터 가을까지, 그녀는 가장 친한 친구 아라와 함께 공원에서 친다.) 'with her best friend'(가장 친한 친구와 함께)가 그대로 나와요. 빈칸 문장과 같은 봄부터 가을까지의 이야기이니, 함께 치는 사람은 가장 친한 친구 아라예요.",
 "3) 확인: 셋째 문장 «In winter, she plays in the school gym with her grandfather.»(겨울에는, 그녀는 할아버지와 함께 학교 체육관에서 친다.) 'with her grandfather'(할아버지와 함께)는 'In winter'(겨울에는)의 이야기예요. 빈칸 문장이 묻는 때는 봄부터 가을까지이니, 할아버지는 빠져요.",
 "4) 묶기: 봄부터 가을까지 소라가 함께 배드민턴을 치는 사람 = 'with her best friend'(가장 친한 친구와 함께)."],
 traps="「할아버지와 함께」가 끌릴 수 있어요. 셋째 문장에 'with her grandfather'(할아버지와 함께)가 그대로 나오고, 빈칸 문장만 보면 할아버지와 친다는 말도 자연스럽거든요. 하지만 그것은 'In winter'(겨울에는) 학교 체육관에서의 일이고, 둘째 문장은 봄부터 가을까지 소라가 가장 친한 친구 아라와 함께 친다고 해요.",
 cn=[("할아버지와 함께", "셋째 문장 «In winter, she plays in the school gym with her grandfather.»에서 할아버지와 함께 치는 것은 겨울의 일이에요. 봄부터 가을까지는 둘째 문장대로 'with her best friend Ara'(가장 친한 친구 아라와 함께) 쳐요."),
     ("여동생과 함께", "여동생은 글에 나오지 않아요. 둘째 문장에서 봄부터 가을까지 소라와 함께 치는 사람은 가장 친한 친구 아라이고, 셋째 문장에서 겨울에 함께 치는 사람은 할아버지예요."),
     ("가장 친한 친구와 함께", "둘째 문장 «From spring to fall, she plays at the park with her best friend Ara.»이 근거예요. 봄부터 가을까지 소라는 가장 친한 친구 아라와 함께 공원에서 치니, 빈칸 문장의 일요일 배드민턴도 가장 친한 친구와 함께예요."),
     ("학교 코치와 함께", "학교 코치는 글에 나오지 않아요. 셋째 문장에 'school gym'(학교 체육관)이 나오지만, 그곳에서 겨울에 함께 치는 사람은 할아버지예요. 봄부터 가을까지는 둘째 문장대로 가장 친한 친구 아라와 함께 쳐요."),
     ("자기보다 나이 많은 사촌과 함께", "사촌은 글에 나오지 않아요. 둘째 문장이 말하는 봄부터 가을까지의 상대는 'her best friend Ara'(가장 친한 친구 아라)예요.")])
K[3] = dict(
 ko="매주 토요일 아침에, 유나는 엄마와 함께 시장까지 걸어간다. 그녀의 엄마는 싱싱한 생선을 좀 사러 매주 그곳에 간다. 유나는 오직 작은 가게에서 따뜻한 떡을 사러 따라간다. 그래서 매주 토요일 아침에, 유나는 ______ 시장에 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every Saturday morning, Yuna goes to the market»(그래서 매주 토요일 아침에, 유나는 … 시장에 간다) 뒤가 비어 있어요. 유나가 무엇을 하러 시장에 가는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Yuna goes along only to get warm rice cakes at a small shop.»(유나는 오직 작은 가게에서 따뜻한 떡을 사러 따라간다.) 'to get warm rice cakes'(따뜻한 떡을 사러)가 그대로 나와요. 첫째 문장대로 유나는 토요일 아침마다 엄마를 따라 시장에 가니, 유나가 시장에 가는 목적은 따뜻한 떡을 사는 것이에요.",
 "3) 확인: 둘째 문장 «Her mom goes there every week to buy some fresh fish.»(그녀의 엄마는 싱싱한 생선을 좀 사러 매주 그곳에 간다.) 'to buy some fresh fish'(싱싱한 생선을 좀 사러)는 'Her mom'(그녀의 엄마)가 가는 목적이에요. 그다음 셋째 문장의 'only'(오직)이 유나의 목적을 따뜻한 떡 하나로 정해요.",
 "4) 묶기: 유나가 시장에 가는 목적 = 'to get warm rice cakes'(따뜻한 떡을 사러)."],
 traps="「싱싱한 생선을 좀 사러」가 끌릴 수 있어요. 둘째 문장에 'to buy some fresh fish'(싱싱한 생선을 좀 사러)가 그대로 나오고, 빈칸 문장만 보면 시장에 생선을 사러 간다는 말이 아주 자연스럽거든요. 하지만 생선은 'Her mom'(그녀의 엄마)가 사러 가는 것이고, 셋째 문장은 유나가 'only to get warm rice cakes'(오직 따뜻한 떡을 사러) 따라간다고 해요.",
 cn=[("싱싱한 생선을 좀 사러", "둘째 문장 «Her mom goes there every week to buy some fresh fish.»에서 생선을 사러 가는 사람은 엄마예요. 유나는 셋째 문장대로 'only to get warm rice cakes'(오직 따뜻한 떡을 사러) 따라가요."),
     ("따뜻한 떡을 사러", "셋째 문장 «Yuna goes along only to get warm rice cakes at a small shop.»이 근거예요. 유나는 토요일 아침마다 엄마를 따라 시장에 가는데, 그 목적은 오직 작은 가게에서 따뜻한 떡을 사는 것이에요."),
     ("학교 친구들을 만나러", "학교 친구들은 글에 나오지 않아요. 첫째 문장에서 유나는 엄마와 함께 시장에 가고, 셋째 문장에서 유나가 따라가는 목적은 'only to get warm rice cakes'(오직 따뜻한 떡을 사러)예요."),
     ("오래된 장난감을 팔러", "장난감을 판다는 이야기는 글에 나오지 않아요. 셋째 문장이 말하는 유나의 목적은 작은 가게에서 'warm rice cakes'(따뜻한 떡)를 사는 것 하나예요."),
     ("할머니를 뵈러", "할머니는 글에 나오지 않아요. 첫째 문장에서 유나가 함께 가는 사람은 'her mom'(그녀의 엄마)이고, 셋째 문장에서 유나가 시장에 따라가는 목적은 따뜻한 떡을 사는 것이에요.")])
K[4] = dict(
 ko="매주 수요일, 시우는 마지막 수업 뒤에 한 시간의 자유 시간이 있다. 맑은 수요일에는, 그는 반 친구들과 함께 밖에서 축구를 한다. 비 오는 수요일에는, 그는 미술실에 머물며 웃긴 그림을 그린다. 그래서 비 오는 수요일에, 시우는 보통 ______ 자기 자유 시간을 보낸다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on rainy Wednesdays, Siwoo usually spends his free hour»(그래서 비 오는 수요일에, 시우는 보통 … 자기 자유 시간을 보낸다) 뒤가 비어 있어요. 비 오는 수요일에 시우가 무엇을 하면서 자유 시간을 보내는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On rainy Wednesdays, he stays in the art room and draws funny pictures.»(비 오는 수요일에는, 그는 미술실에 머물며 웃긴 그림을 그린다.) 'draws funny pictures'(웃긴 그림을 그린다)가 나와요. 보기와 모양만 다른 같은 일이고, 빈칸 문장과 같은 비 오는 수요일의 이야기예요.",
 "3) 확인: 둘째 문장 «On sunny Wednesdays, he plays soccer outside with his classmates.»(맑은 수요일에는, 그는 반 친구들과 함께 밖에서 축구를 한다.) 'plays soccer outside'(밖에서 축구를 한다)는 'On sunny Wednesdays'(맑은 수요일에는) 하는 일이에요. 비 오는 수요일의 일이 아니에요.",
 "4) 묶기: 비 오는 수요일의 자유 시간 = 'draws funny pictures'(웃긴 그림을 그린다), 곧 「웃긴 그림을 그리면서」."],
 traps="「밖에서 축구를 하면서」가 끌릴 수 있어요. 둘째 문장에 'plays soccer outside'(밖에서 축구를 한다)가 나오고, 빈칸 문장만 보면 자유 시간의 축구도 자연스럽거든요. 하지만 그것은 'On sunny Wednesdays'(맑은 수요일에는) 하는 일이고, 셋째 문장은 비 오는 수요일에 시우가 미술실에 머물며 웃긴 그림을 그린다고 해요.",
 cn=[("만화책을 읽으면서", "만화책은 글에 나오지 않아요. 셋째 문장에서 비 오는 수요일에 시우가 미술실에서 하는 일은 'draws funny pictures'(웃긴 그림을 그린다)예요."),
     ("밖에서 축구를 하면서", "둘째 문장 «On sunny Wednesdays, he plays soccer outside with his classmates.»에서 밖에서 축구를 하는 것은 맑은 수요일의 일이에요. 비 오는 수요일에는 셋째 문장대로 미술실에 머물며 웃긴 그림을 그려요."),
     ("수학 숙제를 하면서", "수학 숙제는 글에 나오지 않아요. 셋째 문장이 말하는 비 오는 수요일의 일은 'stays in the art room and draws funny pictures'(미술실에 머물며 웃긴 그림을 그린다)예요."),
     ("웃긴 그림을 그리면서", "셋째 문장 «On rainy Wednesdays, he stays in the art room and draws funny pictures.»이 근거예요. 비 오는 수요일에 시우는 미술실에 머물며 웃긴 그림을 그리니, 그날의 자유 시간도 웃긴 그림을 그리면서 보내요."),
     ("피아노를 연습하면서", "피아노는 글에 나오지 않아요. 셋째 문장에서 비 오는 수요일에 시우는 'the art room'(미술실)에 머물며 웃긴 그림을 그려요.")])
