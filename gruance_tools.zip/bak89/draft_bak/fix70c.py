# -*- coding: utf-8 -*-
# 31번 레벨2 새 판 — 감사꾼(sheets70a) 지적 반영: d70.py 의 문장 몇 곳을 고친다.
import importlib.util, pprint
spec = importlib.util.spec_from_file_location('d', '/home/claude/work/draft/d70.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
I = m.I
F = {
 0:  ({0: "On nights A and B, Sora does the same homework at one desk and chair."}, None),
 2:  ({}, {0:'clean',1:'dirty',2:'muddy',3:'dusty',4:'cloudy'}),
 5:  ({1: "River A runs past fields of loose dirt, but river B runs between big rocks."}, None),
 8:  ({1: "One autumn night, a strong wind moved all the leaves in the yard.", 2: "In the morning, most leaves lay against fence A, and few lay near fence B.", 3: "So that night, the wind pushed most leaves toward the ______."}, {0:'east',1:'west',2:'north',3:'south',4:'middle'}),
 9:  ({1: "Both castles are the same size, but she wets only A's sand."}, None),
 12: ({0: "Mina puts the same cold water in two pots, A and B, of one size."}, None),
 13: ({0: "Lizards A and B, of the same size and age, sleep by one rock.", 2: "An hour later, A runs fast after small bugs, but B still moves very slowly."}, None),
 14: ({1: "He keeps A by a sunny window, but he keeps B in a dark box."}, None),
 16: ({1: "On day A he rides early at eight, and on day B at one o'clock."}, None),
 19: ({0: "Ben folds two paper boats, A and B, from the same kind of paper."}, None),
 24: ({2: "Yuna plays an hour on each of four days, but Leo plays four hours once."}, None),
 25: ({2: "After a year, box A is full of coins, but box B holds very few."}, None),
 28: ({}, {0:'bright',1:'dark',2:'empty',3:'white',4:'small'}),
 29: ({0: "Teams A and B, with eleven players each, play one match on one field."}, {0:'field',1:'passing',2:'weather',3:'ball',4:'number'}),
}
for n, (d, ch) in F.items():
    for i, new in d.items():
        print(n, i, '\n   OLD', I[n]['S'][i], '\n   NEW', new); I[n]['S'][i] = new
    if ch: I[n]['ch'] = ch
out = ['# -*- coding: utf-8 -*-', '# 31번(빈칸 추론) 레벨2 다시 쓰기(352번 이후) 영어 원고 전체. A/B 두 조건 + 결과를 견주는 빈칸 문장.', 'I = {}']
for n in range(30): out.append('I[%d] = dict(S=%s,\n ch=%s)' % (n, pprint.pformat(I[n]['S'], width=120), repr(I[n]['ch'])))
open('/home/claude/work/draft/d70.py', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
