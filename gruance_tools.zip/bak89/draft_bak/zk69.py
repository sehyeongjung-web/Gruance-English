# -*- coding: utf-8 -*-
# 한글 원고(K) 자체 검사.  python3 draft/zk69.py <k파일> [<d파일: 기본 draft/d69.py>]
import sys, re, importlib.util
def load(p, nm):
    spec = importlib.util.spec_from_file_location(nm, p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
kf = load(sys.argv[1], 'kk'); df = load(sys.argv[2] if len(sys.argv) > 2 else '/home/claude/work/draft/d69.py', 'dd')
bad = 0
def warn(n, msg):
    global bad; bad += 1; print('!! n=%d  %s' % (n, msg))
for n, K in sorted(kf.K.items()):
    I = df.I[n]; passage = ' '.join(I['S']); words = set(re.findall(r"[A-Za-z']+", passage.lower())) | set(w.lower() for w in I['ch'].values())
    if K['ko'].count('______') != 1: warn(n, 'ko에 ______ 가 정확히 하나여야 함')
    if len(K['steps']) != 4: warn(n, 'steps는 4개')
    else:
        for i, s in enumerate(K['steps']):
            if not s.startswith('%d) ' % (i + 1)): warn(n, 'steps[%d]는 "%d) "로 시작' % (i, i + 1))
    if len(K['cn']) != 5: warn(n, 'cn은 5개')
    allk = ' '.join(K['steps']) + ' ' + K['traps'] + ' ' + ' '.join(a + ' ' + b for a, b in K['cn'])
    if '정답' in allk: warn(n, '「정답」이라는 낱말을 쓰지 말 것(맞는 선택지에는 시스템이 「정답이에요.」를 붙임)')
    if re.search(r'니다[\.\s]', allk) or re.search(r'니다$', allk): warn(n, '「~니다」 말끝 금지(~어요)')
    if '"' in allk: warn(n, '큰따옴표 대신 «» 를 쓸 것')
    for q in re.findall(r'«([^»]+)»', allk):
        if q not in passage: warn(n, '«%s» 가 지문에 그대로 없음' % q)
        if len(q) < 12: warn(n, '«%s» 12자 미만 — 짧은 조각은 작은따옴표로' % q)
    for q in re.findall(r"(?<![A-Za-z])'([A-Za-z][^'»]*?)'(?![A-Za-z])", allk):
        toks = re.findall(r"[A-Za-z]+", q.lower())
        if any(t not in words for t in toks): warn(n, "'%s' 지문·선택지에 없는 영어 낱말" % q)
    for q in re.findall(r"'([A-Za-z][^']*)'", ' '.join(K['steps'])):
        pass
    # 서수 문장 확인: 「첫째/둘째/셋째/넷째 문장」 바로 뒤의 « » 인용이 그 문장과 맞는지
    for m in re.finditer(r'(첫째|둘째|셋째|넷째) 문장[^«]{0,12}«([^»]+)»', allk):
        idx = ['첫째', '둘째', '셋째', '넷째'].index(m.group(1))
        if m.group(2).strip() not in I['S'][idx]: warn(n, '%s 문장 인용이 맞지 않음: «%s»' % (m.group(1), m.group(2)))
    if len(K['steps']) == 4 and not (480 <= sum(len(s) for s in K['steps']) + len(K['traps']) <= 900): warn(n, '풀이+끌리는 오답 길이 %d자(480~900자 권장)' % (sum(len(s) for s in K['steps']) + len(K['traps'])))
print('검사 끝 — 걸린 것 %d' % bad)
