# -*- coding: utf-8 -*-
# 32번(빈칸 — 낱말) 레벨2 다시 쓰기(349번 이후) 영어 원고 전체. A/B 두 조건을 세우고 빈칸 문장은 그 결과를 견주는 꼴.
# I[n] = dict(S=[네 문장 — 빈칸은 넷째 문장], ch={0..4: 선택지})
I = {}
I[0] = dict(S=['Mia cuts an apple into two equal halves, and she puts them on a plate.',
 'She puts lemon juice on half A, but she puts nothing on half B.',
 'One hour later, half B has turned brown, but half A is still mostly pale.',
 'So at this point, half B is ______ than half A.'],
 ch={0: 'paler', 1: 'darker', 2: 'wetter', 3: 'smaller', 4: 'sourer'})
I[1] = dict(S=['Jake mixes two dough balls, A and B, from exactly the same things.',
 'He presses and folds A by hand for ten minutes, but he leaves B alone.',
 'An hour later, A is tall and full of bubbles, but B is lower.',
 'So the one real difference between ball A and ball B is the ______.'],
 ch={0: 'stirring', 1: 'kneading', 2: 'baking', 3: 'weighing', 4: 'salting'})
I[2] = dict(S=['Ice is lighter than water of the same size, so ice floats on a pond.',
 'Last week, the open pond water cooled a lot on each cold night.',
 'This week, a sheet of ice covers the pond, and the water cools very little.',
 'So this week, the pond water loses its heat ______ than last week.'],
 ch={0: 'faster', 1: 'harder', 2: 'higher', 3: 'louder', 4: 'slower'})
I[3] = dict(S=['Nora rolls a bar magnet in a box of iron pins of the same size.',
 'She calls one end of the magnet A, and she calls its middle B.',
 'A thick bunch of pins hangs on A, but two or three hang on B.',
 'So the magnet pulls ______ pins to spot B than to spot A.'],
 ch={0: 'more', 1: 'smaller', 2: 'heavier', 3: 'fewer', 4: 'larger'})
I[4] = dict(S=['Two equal pieces of meat lie side by side in a cool, dark room.',
 'Dad covers piece A with lots of salt, but he leaves piece B plain.',
 'After a week, A is hard and dry, but B is full of bacteria.',
 'So piece A gives the bacteria much less ______ than piece B.'],
 ch={0: 'food', 1: 'water', 2: 'salt', 3: 'warmth', 4: 'light'})
I[5] = dict(S=['At a bird show, Kim shuts her eyes, and two birds fly high above her.',
 'Bird A is an owl with comb-like wing edges, and B is a pigeon.',
 "B's wings beat with a loud noise, but A's wings make almost no sound.",
 'So Kim can easily ______ bird B, but she misses bird A.'],
 ch={0: 'see', 1: 'hear', 2: 'touch', 3: 'catch', 4: 'feed'})
I[6] = dict(S=['Dan pours the same hot soup into two red bottles, A and B.',
 "Both are the same size, with the same lid, but A's wall has two layers.",
 "B's wall has one layer, and after six hours its soup is cooler than A's.",
 'So the one real difference between the two bottles is their ______.'],
 ch={0: 'sizes', 1: 'colors', 2: 'lids', 3: 'walls', 4: 'soups'})
I[7] = dict(S=["Spot A in Leo's yard is open, but spot B is under a big tree.",
 "On clear summer nights, A's grass gets colder than the air, but B's does not.",
 'Water vapor turns into many drops at A, but into very few at B.',
 "So in the morning, B's grass feels ______ than A's under Leo's feet."],
 ch={0: 'wetter', 1: 'icier', 2: 'drier', 3: 'muddier', 4: 'frostier'})
I[8] = dict(S=['A cut branch in the air gets no new water, but its leaves lose some.',
 'Sam leaves two equal branches on a table, and he picks the leaves off B.',
 "A day later, A's tips are soft and hang down, but B looks fresh.",
 'So after one day, branch A is ______ than branch B.'],
 ch={0: 'wetter', 1: 'firmer', 2: 'younger', 3: 'drier', 4: 'straighter'})
I[9] = dict(S=['Yuna puts a clear ice cube in cup A, and she can see through it.',
 'She crushes another cube into tiny bits, and she puts them in cup B.',
 'Most light bounces off the tiny bits, and the mixed colors look like milk.',
 'So the crushed ice in cup B looks ______ to Yuna now.'],
 ch={0: 'white', 1: 'clear', 2: 'dark', 3: 'blue', 4: 'green'})
I[10] = dict(S=['Sam puts a straight pencil in each of two glasses, A and B.',
 'Glass A is empty, and glass B is half full of water.',
 'Light from the wet part bends at the water line, so the pencil looks broken.',
 'So the water changes the ______ of the light, not the pencil.'],
 ch={0: 'color', 1: 'direction', 2: 'brightness', 3: 'size', 4: 'weight'})
I[11] = dict(S=['Two moths of the same size, shape and color fly near a bat.',
 "They fly at the same speed, but only moth A can hear the bat's calls.",
 'Moth A drops to the grass, but the bat catches moth B in the air.',
 'So the one real difference between the two moths is their ______.'],
 ch={0: 'ears', 1: 'size', 2: 'shape', 3: 'color', 4: 'speed'})
I[12] = dict(S=['Cup A holds pure honey, and cup B holds honey mixed with lots of water.',
 'Germs need water to grow, and pure honey has very little water.',
 'A week later, cup B is sour and bubbly, but cup A is still sweet.',
 'So cup B now has ______ living germs than cup A.'],
 ch={0: 'more', 1: 'fewer', 2: 'larger', 3: 'sweeter', 4: 'sourer'})
I[13] = dict(S=['Tom hits two drums of the same size with the same force.',
 'More shakes in each second give a drum a higher note.',
 'A has a tight skin and B has a loose one, and A sounds higher.',
 'So the skin of drum A shakes ______ than the skin of drum B.'],
 ch={0: 'slower', 1: 'longer', 2: 'harder', 3: 'later', 4: 'faster'})
I[14] = dict(S=['Two iron nails of the same size sit outside in the same air and rain.',
 'Dad brushes a green coat over nail A, but nail B stays bare.',
 'A year later, nail B is red-brown and rough, but nail A looks smooth.',
 'So the ______ makes the one real difference between nail A and nail B.'],
 ch={0: 'rain', 1: 'air', 2: 'iron', 3: 'size', 4: 'paint'})
I[15] = dict(S=['On a calm, safe day, two geese fly south on their usual path.',
 'Goose A flies at the front and pushes hard, and goose B flies behind it.',
 "The air by A's wingtip lifts B a little, so B can rest its wings.",
 'So after an hour, goose A feels more ______ than goose B.'],
 ch={0: 'lonely', 1: 'afraid', 2: 'tired', 3: 'lost', 4: 'rested'})
I[16] = dict(S=['Mia puts bean seeds on wet cotton in two cups, A and B.',
 'Both cups sit in the same dim room, but A is on a warm shelf.',
 "Five days later, A's seeds have small roots, but B's seeds have no roots yet.",
 'So the seeds in cup B need more ______ to wake up.'],
 ch={0: 'heat', 1: 'water', 2: 'light', 3: 'air', 4: 'soil'})
I[17] = dict(S=['Jin cuts two slices from one fresh loaf and wraps each in a plastic bag.',
 'He puts slice A in the cold fridge and leaves slice B on the table.',
 'Two days later, slice A feels stiff and dry, but slice B is still soft.',
 'So in the end, slice A is ______ than slice B.'],
 ch={0: 'harder', 1: 'softer', 2: 'wetter', 3: 'warmer', 4: 'fresher'})
I[18] = dict(S=['On a hot day, Ann puts a clean cloth on each arm in the shade.',
 'Her left cloth is wet with water, but her right cloth is dry.',
 'The water slowly leaves the left cloth, and it carries heat away from her skin.',
 'So for a while, her left arm feels ______ than her right arm.'],
 ch={0: 'warmer', 1: 'drier', 2: 'cooler', 3: 'dirtier', 4: 'hotter'})
I[19] = dict(S=['Ray hits pot A in the air and pot B under lake water at once.',
 'A mile away, Kim has a microphone in the air and one in the lake.',
 "Both sounds are equally loud, but pot B's sound arrives a few seconds earlier.",
 'So the sound of pot B moves ______ than the sound of pot A.'],
 ch={0: 'slower', 1: 'later', 2: 'higher', 3: 'softer', 4: 'faster'})
I[20] = dict(S=['Amy finds a web with two kinds of threads, and they look almost the same.',
 'A fly touches the first kind, and it cannot pull its legs off.',
 'The spider runs mostly over the second kind, and its feet come off easily.',
 'So the first kind is ______ than the second kind.'],
 ch={0: 'smoother', 1: 'thinner', 2: 'darker', 3: 'stickier', 4: 'longer'})
I[21] = dict(S=["Five years ago, Sam's baby tortoise had a shell as small as a cookie.",
 'The tortoise still has the same shell, and the shell is part of its body.',
 'Today the shell is as big as a plate, with the same color and pattern.',
 'So the one real change in this shell is its ______.'],
 ch={0: 'color', 1: 'pattern', 2: 'owner', 3: 'place', 4: 'size'})
I[22] = dict(S=['Mina drops two eggs of the same size into a glass of water.',
 'An egg loses water over time, and the air inside then lifts it.',
 'In the glass, egg A lies on the bottom, but egg B floats.',
 'So egg B is probably the ______ egg of the two.'],
 ch={0: 'fresher', 1: 'bigger', 2: 'heavier', 3: 'darker', 4: 'older'})
I[23] = dict(S=["Sixty years ago, Jake's grandfather checked his compass on top of Bell Hill.",
 'Today Jake stands on the same hill, and he uses the same old compass.',
 'Magnetic north has moved over the years, and the needle points a bit farther left.',
 'So on Bell Hill, the old needle now has a different ______.'],
 ch={0: 'color', 1: 'shape', 2: 'direction', 3: 'length', 4: 'weight'})
I[24] = dict(S=['Leo puts two greasy forks into two bowls of warm water, A and B.',
 'He adds a few drops of dish liquid to bowl B and nothing else.',
 'Soon yellow oil drops float on top in A, but B looks cloudy all through.',
 'So bowl B has ______ in its water, but bowl A does not.'],
 ch={0: 'salt', 1: 'soap', 2: 'sand', 3: 'ice', 4: 'sugar'})
I[25] = dict(S=['Ana and Ben fly two kites of the same size and weight on a hill.',
 "Ben ties a long strip of cloth below his kite, but Ana's kite has none.",
 "In the same wind, Ana's kite spins around and falls, but Ben's stays up.",
 "So in this wind, Ana's kite is much ______ than Ben's kite."],
 ch={0: 'higher', 1: 'steadier', 2: 'wilder', 3: 'heavier', 4: 'bigger'})
I[26] = dict(S=['On a calm night, Kim watches a moth fly across a field under the moon.',
 'The moth may keep the faraway moon at one angle, and it flies straight.',
 'Then it meets a porch lamp, and it goes round and round the light.',
 'So on this part of its trip, the moth flies in a ______.'],
 ch={0: 'line', 1: 'zigzag', 2: 'wave', 3: 'circle', 4: 'square'})
I[27] = dict(S=['Our teacher puts two bells of the same kind into jars A and B.',
 "Jar A keeps its air, but she pumps most of jar B's air out.",
 'Both bells shake hard, but jar B has little air to pass the shaking on.',
 'So to the class, bell B sounds much ______ than bell A.'],
 ch={0: 'louder', 1: 'higher', 2: 'clearer', 3: 'softer', 4: 'deeper'})
I[28] = dict(S=['Mia takes two photos of the same tree on the same sunny day.',
 'In photo A, the high sun makes a small dark patch under the tree.',
 'In photo B, the sun is low, and the shadow reaches far across the grass.',
 "So the tree's shadow in photo B is ______ than in photo A."],
 ch={0: 'longer', 1: 'shorter', 2: 'darker', 3: 'wetter', 4: 'rounder'})
I[29] = dict(S=['On a frosty night, Dan has two small plants, A and B, in his garden.',
 'Plant A moves water out of its cells, and the water freezes in the gaps.',
 "At sunrise, B's leaves are soft and black, but A's leaves look fine.",
 'So in plant A, the ice mostly forms ______ the cells.'],
 ch={0: 'inside', 1: 'under', 2: 'outside', 3: 'above', 4: 'through'})
