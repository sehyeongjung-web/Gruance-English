# -*- coding: utf-8 -*-
# 18번 레벨1 한글 원고 자체 검사.  python3 draft/zk76.py <k파일> [<d파일: 기본 draft/d76.py>]
#   K[n] = dict(ko=편지 해석(줄마다), purpose_ko=목적 문장 해석, why=풀이 ②, words='낱말 줄', cn=[선택지별 까닭 다섯])
import sys, re, importlib.util
sys.path.insert(0, '/home/claude/work')
def load(p, nm):
    spec = importlib.util.spec_from_file_location(nm, p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
kf = load(sys.argv[1], 'kk'); df = load(sys.argv[2] if len(sys.argv) > 2 else '/home/claude/work/draft/d76.py', 'dd')
from z18common import maker
from lib import load as L
_tb = L()[1]
bad = 0
def warn(n, msg):
    global bad; bad += 1; print('!! n=%d  %s' % (n, msg))
def text_of(it): return '%s\n\n%s\n\n%s\n%s' % (it['to'], ' '.join(it['S']), it['sign'], it['name'])
for n, K in sorted(kf.K.items()):
    I = df.I[n]; text = text_of(I); a = _tb['18']['1'][n]['answer']; CH = [I['ch'][k] for k in range(5)]
    words = set(re.findall(r"[A-Za-z']+", text.lower()))
    try:
        E = {}; maker(E)(n, a, text, CH, K['ko'], I['S'][I['key']], K['purpose_ko'], I['key'] + 1, K['why'], K['words'], K['cn'])
    except AssertionError as e:
        warn(n, 'z18common 거절: %s' % (e,)); continue
    allk = K['why'] + ' ' + ' '.join(K['cn'])
    if re.search(r'니다[\.\s]', allk) or re.search(r'니다$', allk): warn(n, '「~니다」 말끝 금지(~어요)')
    if '"' in allk: warn(n, '큰따옴표 대신 «» 를 쓸 것')
    for q in re.findall(r'«([^»]+)»', allk):
        if len(q) < 12: warn(n, '«%s» 12자 미만 — 짧은 조각은 작은따옴표로' % q)
    for q in re.findall(r"(?<![A-Za-z])'([A-Za-z][^'»]*?)'(?![A-Za-z])", allk):
        if any(t not in words for t in re.findall(r"[A-Za-z]+", q.lower())): warn(n, "'%s' 편지에 없는 영어 낱말" % q)
    if re.search(r'\d+번', allk): warn(n, '숫자 + 「번」 금지')
    if not (120 <= len(K['why']) <= 450): warn(n, '풀이 ② 길이 %d자(120~450자)' % len(K['why']))
    if len(K['ko'].split('\n')) < 6: warn(n, 'ko는 받는 이 줄 · 본문 네 문장(한 줄씩) · 끝맺음 줄로')
    if not re.search(r'(둘째|셋째|넷째|첫째) 문장', K['why']): warn(n, '풀이 ②에 곁가지 문장(서수)을 짚을 것')
print('검사 끝 — 걸린 것 %d' % bad)
