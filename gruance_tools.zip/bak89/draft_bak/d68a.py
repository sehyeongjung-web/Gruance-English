# -*- coding: utf-8 -*-
# 32번(빈칸) 레벨2 앞 절반 영어 원고 (347번). I[n] = dict(S=[네 문장 — 빈칸은 넷째 문장], ch={자리: 선택지} — 다섯 자리 모두)
# 레벨2 꼴: 네 문장·50낱말쯤·문장당 10~15낱말 · and·but·so·or로 단문을 이음(종속절·관계사절·명사절·분사 없음)
#   첫 문장 = 하는 일 / 둘째 = 그 모습 / 셋째 = 단서(정답을 조금 다른 말로 바꾸어 말함) / 넷째 = 빈칸 문장(글 속 말을 가리키는 말 the net · this gas로 받아 빈칸 문장만으로는 풀리지 않게)
I = {}
I[0] = dict(S=[
 "A cut apple turns brown after a few minutes in the air.",
 "A slice with lemon juice on it stays pale for much longer.",
 "The air still touches the slice, but the change takes much more time.",
 "In short, the sour juice ______ the browning of the cut apple."],
 ch={0: 'starts', 1: 'slows', 2: 'ends', 3: 'speeds', 4: 'hides'})
I[1] = dict(S=[
 "Yeast eats the sugar in the dough and makes many gas bubbles.",
 "Kneading makes the dough stretchy and strong, like a thin rubber bag.",
 "Most bubbles cannot break through it, so the gas stays inside.",
 "So the dough ______ the bubbles, and it slowly gets bigger."],
 ch={0: 'loses', 1: 'holds', 2: 'eats', 3: 'frees', 4: 'makes'})
I[2] = dict(S=[
 "Ice is lighter than water, so ice floats on a lake.",
 "On a cold night, the air cools the water at the top first.",
 "The new ice stays on top like a lid, and heat gets out only slowly.",
 "So under the ice, the deep water stays ______ than the air above."],
 ch={0: 'colder', 1: 'harder', 2: 'drier', 3: 'icier', 4: 'warmer'})
I[3] = dict(S=[
 "A bar magnet pulls small iron pins toward itself with a hidden force.",
 "Roll the magnet in a box of pins, and then lift it up.",
 "Many pins hang on the two ends, but only a few hang on the middle.",
 "So the pull is ______ at the two ends than in the middle."],
 ch={0: 'weaker', 1: 'slower', 2: 'softer', 3: 'stronger', 4: 'later'})
I[4] = dict(S=[
 "People put a lot of salt on meat to keep it for months.",
 "The salt pulls the liquid out of the meat, and the meat becomes dry.",
 "Bacteria need liquid to live, but dry meat has very little for them.",
 "So the salt takes the bacteria's ______ away from them."],
 ch={0: 'food', 1: 'water', 2: 'air', 3: 'warmth', 4: 'light'})
I[5] = dict(S=[
 "An owl flies down toward a mouse, and its wings make almost no sound.",
 "The front edge of each wing has tiny teeth, like a comb.",
 "The teeth cut the air into small parts, so there is almost no noise.",
 "So the mouse can hardly ______ the owl, and it has little time to run."],
 ch={0: 'smell', 1: 'hear', 2: 'trust', 3: 'chase', 4: 'call'})
I[6] = dict(S=[
 "A thermos bottle has two walls with a thin gap between them.",
 "Workers take almost all the air out of the gap.",
 "Most warmth needs air or something else to pass along, but the gap has little.",
 "So the gap lets very little ______ escape from the hot drink."],
 ch={0: 'water', 1: 'sound', 2: 'light', 3: 'heat', 4: 'air'})
I[7] = dict(S=[
 "At night, the grass becomes colder than the air around it.",
 "The air holds some water in the form of an invisible gas.",
 "Next to the cold grass, this gas loses heat and forms small drops.",
 "So the gas changes into ______ and wets the leaves."],
 ch={0: 'snow', 1: 'powder', 2: 'liquid', 3: 'metal', 4: 'ice'})
I[8] = dict(S=[
 "A leaf keeps letting water out into the air all day.",
 "In summer, the roots send up new water, so the tree stays fine.",
 "In winter, the ground is often cold and hard, and roots get very little water.",
 "So a tree with all its wide leaves would soon become ______ and weak."],
 ch={0: 'heavy', 1: 'green', 2: 'warm', 3: 'dry', 4: 'wet'})
I[9] = dict(S=[
 "A block of ice can be clear, and you can see through it.",
 "Snow has many tiny pieces of ice, and light bounces off each of them.",
 "Sunlight has every colour in it, and the snow sends all of them back.",
 "So all the colours reach your eyes together, and snow looks ______."],
 ch={0: 'white', 1: 'clear', 2: 'dark', 3: 'blue', 4: 'green'})
I[10] = dict(S=[
 "A pencil in a glass of water looks broken at the water's surface.",
 "The pencil is straight, and it does not change at all.",
 "Light is slower in water than in air, so its path changes at the surface.",
 "So the light from the pencil ______ at the surface of the water."],
 ch={0: 'stops', 1: 'bends', 2: 'sinks', 3: 'warms', 4: 'shines'})
I[11] = dict(S=[
 "A bat makes a high shout, and the sound hits an insect.",
 "The sound bounces back to the bat, and the bat finds the insect.",
 "Some moths hear the shout, and they fold their wings and go down fast.",
 "So the moth ______ out of the sky, and the bat misses it."],
 ch={0: 'drops', 1: 'climbs', 2: 'jumps', 3: 'rises', 4: 'flies'})
I[12] = dict(S=[
 "Honey can stay good for many years in a kitchen cupboard.",
 "It has very little water in it, and it is a little sour.",
 "Tiny living things need water to live, but honey gives them almost none.",
 "So most bacteria ______ in the honey, and the honey does not spoil."],
 ch={0: 'die', 1: 'grow', 2: 'eat', 3: 'spread', 4: 'live'})
I[13] = dict(S=[
 "A drum has a thin skin, and a player hits the top with a stick.",
 "The skin shakes up and down, and the speed of the shaking makes the note.",
 "A tight skin springs back with great speed, but a loose skin is slow.",
 "So the tight skin of a drum shakes more ______ than the loose one."],
 ch={0: 'slowly', 1: 'softly', 2: 'heavily', 3: 'widely', 4: 'quickly'})
I[14] = dict(S=[
 "Iron slowly turns into rust, and this needs both air and water.",
 "Take away the water, and the iron stays safe from rust.",
 "So workers paint iron bridges, and the paint keeps water and air away.",
 "In other words, the paint ______ the iron for a long time."],
 ch={0: 'wets', 1: 'breaks', 2: 'rusts', 3: 'feeds', 4: 'protects'})
