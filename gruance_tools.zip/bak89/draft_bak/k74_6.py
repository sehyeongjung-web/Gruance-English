# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 한글 (d74.py I[25]~I[29]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[25] = dict(
 ko="서아는 일주일에 두 번 자기 아파트 근처의 작은 도서관에 간다. 수요일에는, 그녀는 오직 학교 시험공부를 하러 그곳에 간다. 토요일에는, 그녀는 오직 어린아이들에게 이야기를 읽어 주러 그곳에 간다. 그래서 토요일에, 서아는 오직 ______ 도서관에 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Saturdays, Seoa goes to the library only»(그래서 토요일에, 서아는 오직 … 도서관에 간다) 뒤가 비어 있어요. 토요일에 서아가 무엇을 하러 도서관에 가는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On Saturdays, she goes there only to read stories to little kids.»(토요일에는, 그녀는 오직 어린아이들에게 이야기를 읽어 주러 그곳에 간다.) 'to read stories to little kids'(어린아이들에게 이야기를 읽어 주러)가 그대로 나와요. 빈칸 문장과 같은 토요일의 일이고, 빈칸 문장의 'only'(오직)도 이 문장의 'only'가 받쳐요.",
 "3) 확인: 둘째 문장 «On Wednesdays, she goes there only to study for her school tests.»(수요일에는, 그녀는 오직 학교 시험공부를 하러 그곳에 간다.) 'to study for her school tests'(학교 시험공부를 하러)는 'On Wednesdays'(수요일에는) 도서관에 가는 목적이에요.",
 "4) 묶기: 토요일에 서아가 도서관에 가는 목적 = 'to read stories to little kids'(어린아이들에게 이야기를 읽어 주러)."],
 traps="「학교 시험공부를 하러」가 끌릴 수 있어요. 둘째 문장에 'to study for her school tests'(학교 시험공부를 하러)가 그대로 나오고, 빈칸 문장만 보면 공부하러 간다는 말도 자연스럽거든요. 하지만 그것은 'On Wednesdays'(수요일에는)의 일이고, 셋째 문장은 토요일에는 오직 어린아이들에게 이야기를 읽어 주러 간다고 해요.",
 cn=[("학교 시험공부를 하러", "둘째 문장 «On Wednesdays, she goes there only to study for her school tests.»에서 시험공부를 하러 가는 것은 수요일의 일이에요. 토요일에는 셋째 문장대로 'only to read stories to little kids'(오직 어린아이들에게 이야기를 읽어 주러) 도서관에 가요."),
     ("학교 친구들을 만나러", "친구들을 만난다는 내용은 글에 나오지 않아요. 둘째 문장의 'school'(학교)은 수요일의 시험공부에 나오는 말이고, 셋째 문장 «On Saturdays, she goes there only to read stories to little kids.»에서 'only'(오직)라고 하니, 토요일에 서아가 도서관에 가는 목적은 어린아이들에게 이야기를 읽어 주는 것 하나뿐이에요."),
     ("어린아이들에게 이야기를 읽어 주러", "셋째 문장 «On Saturdays, she goes there only to read stories to little kids.»이 근거예요. 토요일에 서아는 오직 어린아이들에게 이야기를 읽어 주러 도서관에 가니, 빈칸 문장의 토요일 목적도 이것이에요."),
     ("숙제를 위해 컴퓨터를 쓰러", "컴퓨터는 글에 나오지 않아요. 셋째 문장 «On Saturdays, she goes there only to read stories to little kids.»에서 'only'(오직)라고 하니, 토요일에 서아가 도서관에 가는 목적은 어린아이들에게 이야기를 읽어 주는 것 하나뿐이에요."),
     ("자기가 볼 만화책을 빌리러", "만화책을 빌린다는 내용은 글에 나오지 않아요. 셋째 문장에서 토요일에 서아는 'only'(오직) 어린아이들에게 이야기를 읽어 주러 도서관에 가요.")])
K[26] = dict(
 ko="임 할머니는 매일 오후 네 시에 차 한 잔을 마신다. 평일에는, 그녀는 항상 창문 옆 의자에서 차를 마신다. 주말에는, 그녀는 손주들과 함께 마당의 벤치에서 차를 마신다. 그래서 평일에, 임 할머니는 항상 ______ 차를 마신다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on weekdays, Grandma Lim always has her tea»(그래서 평일에, 임 할머니는 항상 … 차를 마신다) 뒤가 비어 있어요. 평일에 임 할머니가 어디에서 차를 마시는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On weekdays, she always drinks her tea in the chair by the window.»(평일에는, 그녀는 항상 창문 옆 의자에서 차를 마신다.) 'in the chair by the window'(창문 옆 의자에서)가 그대로 나와요. 빈칸 문장과 같은 평일의 이야기이고, 빈칸 문장의 'always'(항상)도 이 문장의 'always'가 받쳐요.",
 "3) 확인: 셋째 문장 «On weekends, she drinks it with her grandchildren on the bench in the yard.»(주말에는, 그녀는 손주들과 함께 마당의 벤치에서 차를 마신다.) 'on the bench in the yard'(마당의 벤치에서)는 'On weekends'(주말에는) 손주들과 함께 차를 마시는 곳이에요. 평일의 자리가 아니에요.",
 "4) 묶기: 평일에 임 할머니가 차를 마시는 곳 = 'in the chair by the window'(창문 옆 의자에서)."],
 traps="「마당의 벤치에서」가 끌릴 수 있어요. 셋째 문장에 'on the bench in the yard'(마당의 벤치에서)가 그대로 나오고, 빈칸 문장만 보면 벤치에서 차를 마신다는 말도 자연스럽거든요. 하지만 그것은 'On weekends'(주말에는) 손주들과 함께하는 일이고, 둘째 문장은 평일에 할머니가 'always'(항상) 창문 옆 의자에서 차를 마신다고 해요.",
 cn=[("부엌의 식탁에서", "부엌의 식탁은 글에 나오지 않아요. 둘째 문장에서 평일에 할머니가 차를 마시는 곳은 'the chair by the window'(창문 옆 의자)이고, 셋째 문장에서 주말에 마시는 곳은 'the bench in the yard'(마당의 벤치)예요."),
     ("창문 옆 의자에서", "둘째 문장 «On weekdays, she always drinks her tea in the chair by the window.»이 근거예요. 평일에 임 할머니는 항상 창문 옆 의자에서 차를 마시니, 빈칸 문장의 평일 자리도 창문 옆 의자예요."),
     ("마당의 벤치에서", "셋째 문장 «On weekends, she drinks it with her grandchildren on the bench in the yard.»에서 마당의 벤치는 주말에 손주들과 함께 차를 마시는 곳이에요. 평일에는 둘째 문장대로 'always'(항상) 창문 옆 의자에서 마셔요."),
     ("자기 침실의 책상에서", "침실의 책상은 글에 나오지 않아요. 둘째 문장이 말하는 평일의 자리는 'in the chair by the window'(창문 옆 의자에서)예요."),
     ("현관문 옆 계단에서", "현관문 옆 계단은 글에 나오지 않아요. 둘째 문장에서 평일에 할머니는 'always'(항상) 창문 옆 의자에서 차를 마시고, 셋째 문장에서 주말에는 손주들과 함께 마당의 벤치에서 마셔요.")])
K[27] = dict(
 ko="세원은 거의 매일 자기 흰 운동화를 신고 학교에 간다. 금요일에는, 그는 그것을 오직 젖은 수건으로 닦는 것으로만 깨끗이 한다. 일요일에는, 그는 그것을 오직 따뜻한 물에 대고 솔질하는 것으로만 깨끗이 한다. 그래서 일요일에, 세원은 자기 운동화를 오직 ______ 깨끗이 한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Sundays, Sewon cleans his sneakers only by»(그래서 일요일에, 세원은 자기 운동화를 오직 … 깨끗이 한다) 뒤가 비어 있어요. 일요일에 세원이 어떤 방법으로 운동화를 깨끗이 하는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On Sundays, he cleans them only by brushing them under warm water.»(일요일에는, 그는 그것을 오직 따뜻한 물에 대고 솔질하는 것으로만 깨끗이 한다.) 'brushing them under warm water'(따뜻한 물에 대고 솔질하는 것)가 그대로 나와요. 빈칸 문장과 같은 일요일의 이야기이고, 빈칸 문장의 'only by'(오직 …으로만)도 이 문장의 'only by'가 받쳐요.",
 "3) 확인: 둘째 문장 «On Fridays, he cleans them only by wiping them with a wet towel.»(금요일에는, 그는 그것을 오직 젖은 수건으로 닦는 것으로만 깨끗이 한다.) 'wiping them with a wet towel'(젖은 수건으로 닦는 것)은 'On Fridays'(금요일에는)의 방법이에요.",
 "4) 묶기: 일요일에 세원이 운동화를 깨끗이 하는 방법 = 'brushing them under warm water'(따뜻한 물에 대고 솔질하는 것)."],
 traps="「젖은 수건으로 닦는 것으로만」이 끌릴 수 있어요. 둘째 문장에 'wiping them with a wet towel'(젖은 수건으로 닦는 것)이 그대로 나오고, 빈칸 문장만 보면 수건으로 운동화를 닦는다는 말도 자연스럽거든요. 하지만 그것은 'On Fridays'(금요일에는)의 방법이고, 셋째 문장은 일요일에는 오직 따뜻한 물에 대고 솔질한다고 해요.",
 cn=[("따뜻한 물에 대고 솔질하는 것으로만", "셋째 문장 «On Sundays, he cleans them only by brushing them under warm water.»이 근거예요. 일요일에 세원은 운동화를 오직 따뜻한 물에 대고 솔질하는 것으로만 깨끗이 하니, 빈칸 문장의 일요일 방법도 이것이에요."),
     ("젖은 수건으로 닦는 것으로만", "둘째 문장 «On Fridays, he cleans them only by wiping them with a wet towel.»에서 젖은 수건으로 닦는 것은 금요일의 방법이에요. 일요일에는 셋째 문장대로 'only by brushing them under warm water'(오직 따뜻한 물에 대고 솔질하는 것으로만) 깨끗이 해요."),
     ("욕조에서 빠는 것으로만", "욕조에서 빤다는 이야기는 글에 나오지 않아요. 셋째 문장 «On Sundays, he cleans them only by brushing them under warm water.»에 'warm water'(따뜻한 물)가 나오지만, 'only by'(오직 …으로만)라고 하니 일요일에 세원이 운동화를 깨끗이 하는 방법은 그 물에 대고 솔질하는 것 하나뿐이에요."),
     ("부드러운 지우개로 문지르는 것으로만", "지우개는 글에 나오지 않아요. 셋째 문장 «On Sundays, he cleans them only by brushing them under warm water.»에서 'only by'(오직 …으로만)라고 하니, 일요일에 세원이 운동화를 깨끗이 하는 방법은 따뜻한 물에 대고 솔질하는 것 하나뿐이에요."),
     ("세탁기에 넣는 것으로만", "세탁기는 글에 나오지 않아요. 셋째 문장에서 일요일에 세원은 운동화를 'only by brushing them under warm water'(오직 따뜻한 물에 대고 솔질하는 것으로만) 깨끗이 해요.")])
K[28] = dict(
 ko="매년 가을, 지율이네 반은 학교 축제에서 작은 간식 판매대를 연다. 첫날에는, 그 반은 오직 봉지에 든 달콤한 팝콘만 판다. 둘째 날에는, 그 반은 오직 컵에 든 뜨거운 떡만 판다. 그래서 둘째 날에, 지율이네 반은 오직 ______만 판다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on the second day, Jiyul's class sells only»(그래서 둘째 날에, 지율이네 반은 오직 …만 판다) 뒤가 비어 있어요. 둘째 날에 지율이네 반이 무엇을 파는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On the second day, the class sells only cups of hot rice cakes.»(둘째 날에는, 그 반은 오직 컵에 든 뜨거운 떡만 판다.) 'cups of hot rice cakes'(컵에 든 뜨거운 떡)가 그대로 나와요. 빈칸 문장과 같은 둘째 날의 이야기이고, 빈칸 문장의 'only'(오직)도 이 문장의 'only'가 받쳐요.",
 "3) 확인: 둘째 문장 «On the first day, the class sells only bags of sweet popcorn.»(첫날에는, 그 반은 오직 봉지에 든 달콤한 팝콘만 판다.) 'bags of sweet popcorn'(봉지에 든 달콤한 팝콘)은 'On the first day'(첫날에는) 파는 것이에요.",
 "4) 묶기: 둘째 날에 지율이네 반이 파는 것 = 'cups of hot rice cakes'(컵에 든 뜨거운 떡)."],
 traps="「봉지에 든 달콤한 팝콘」이 끌릴 수 있어요. 둘째 문장에 'bags of sweet popcorn'(봉지에 든 달콤한 팝콘)이 그대로 나오고, 빈칸 문장만 보면 축제에서 팝콘을 판다는 말도 자연스럽거든요. 하지만 그것은 'On the first day'(첫날에는) 파는 것이에요. 「컵에 든 신선한 레모네이드」도 'cups'(컵)가 같아 끌리지만, 셋째 문장은 둘째 날에 'only cups of hot rice cakes'(오직 컵에 든 뜨거운 떡만) 판다고 하니 둘 다 답이 아니에요.",
 cn=[("봉지에 든 달콤한 팝콘", "둘째 문장 «On the first day, the class sells only bags of sweet popcorn.»에서 달콤한 팝콘은 첫날에 파는 것이에요. 둘째 날에는 셋째 문장대로 'only cups of hot rice cakes'(오직 컵에 든 뜨거운 떡만) 팔아요."),
     ("치즈 피자 조각", "피자는 글에 나오지 않아요. 셋째 문장 «On the second day, the class sells only cups of hot rice cakes.»에서 'only'(오직)라고 하니, 둘째 날에 그 반이 파는 것은 컵에 든 뜨거운 떡뿐이에요."),
     ("그릇에 든 차가운 국수", "국수는 글에 나오지 않아요. 셋째 문장 «On the second day, the class sells only cups of hot rice cakes.»에서 'only'(오직)라고 하니, 둘째 날에 그 반이 파는 것은 컵에 든 뜨거운 떡뿐이에요."),
     ("컵에 든 신선한 레모네이드", "레모네이드는 글에 나오지 않아요. 셋째 문장 «On the second day, the class sells only cups of hot rice cakes.»에 'cups'(컵)가 나오지만, 'only'(오직)라고 하니 둘째 날에 파는 것은 컵에 든 뜨거운 떡뿐이에요."),
     ("컵에 든 뜨거운 떡", "셋째 문장 «On the second day, the class sells only cups of hot rice cakes.»이 근거예요. 둘째 날에 지율이네 반은 오직 컵에 든 뜨거운 떡만 파니, 빈칸 문장의 둘째 날에 파는 것도 이것이에요.")])
K[29] = dict(
 ko="예림은 시립 박물관 어린이 클럽의 새 회원이다. 그 클럽에서, 새 회원들은 오직 오래된 항아리 그림을 그릴 수 있다. 작년에 들어온 회원들은 어린 방문객들에게 짧은 관람 안내를 해 줄 수 있다. 그래서 새 회원으로서, 예림은 오직 ______ 수 있다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So as a new member, Yerim may only»(그래서 새 회원으로서, 예림은 오직 … 수 있다) 뒤가 비어 있어요. 새 회원인 예림이 무엇을 할 수 있는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «In the club, new members may only draw pictures of the old pots.»(그 클럽에서, 새 회원들은 오직 오래된 항아리 그림을 그릴 수 있다.) 'draw pictures of the old pots'(오래된 항아리 그림을 그리다)가 그대로 나와요. 첫째 문장에서 예림은 'a new member'(새 회원)이니, 이 문장의 'only'(오직)가 예림에게도 그대로 걸려요.",
 "3) 확인: 셋째 문장 «Members from last year may give short tours to young visitors.»(작년에 들어온 회원들은 어린 방문객들에게 짧은 관람 안내를 해 줄 수 있다.) 'give short tours'(짧은 관람 안내를 해 주다)는 'Members from last year'(작년에 들어온 회원들)의 일이에요. 새 회원인 예림의 일이 아니에요.",
 "4) 묶기: 새 회원인 예림이 할 수 있는 일 = 'draw pictures of the old pots'(오래된 항아리 그림을 그리다)."],
 traps="「어린 방문객들에게 짧은 관람 안내를 해 줄」이 끌릴 수 있어요. 셋째 문장에 이 말이 그대로 나오고, 빈칸 문장만 보면 안내를 한다는 말도 자연스럽거든요. 하지만 그것은 'Members from last year'(작년에 들어온 회원들)가 할 수 있는 일이고, 둘째 문장은 새 회원들은 오직 오래된 항아리 그림을 그릴 수 있다고 해요.",
 cn=[("어린 방문객들에게 짧은 관람 안내를 해 줄", "셋째 문장 «Members from last year may give short tours to young visitors.»에서 관람 안내를 해 줄 수 있는 사람은 작년에 들어온 회원들이에요. 새 회원인 예림은 둘째 문장 «In the club, new members may only draw pictures of the old pots.»대로 'only'(오직) 오래된 항아리 그림을 그릴 수 있어요."),
     ("공룡 뼈 사진을 찍을", "공룡 뼈는 글에 나오지 않아요. 둘째 문장 «In the club, new members may only draw pictures of the old pots.»에서 'only'(오직)라고 하니, 새 회원인 예림이 할 수 있는 일은 오래된 항아리 그림을 그리는 것 하나뿐이에요."),
     ("오래된 지도에 관한 메모를 쓸", "오래된 지도는 글에 나오지 않아요. 둘째 문장에 'old'(오래된)가 나오지만, 그것은 'the old pots'(오래된 항아리)의 이야기이고, 둘째 문장의 'may only'(오직 …할 수 있다)대로 새 회원들은 그 항아리 그림만 그릴 수 있어요."),
     ("오래된 항아리 그림을 그릴", "둘째 문장 «In the club, new members may only draw pictures of the old pots.»이 근거예요. 첫째 문장에서 예림은 클럽의 새 회원이니, 예림도 오직 오래된 항아리 그림을 그릴 수 있어요."),
     ("작은 홀에서 짧은 영화를 볼", "영화는 글에 나오지 않아요. 셋째 문장에 'short'(짧은)가 나오지만, 그것은 작년에 들어온 회원들이 하는 짧은 관람 안내이고, 새 회원들은 둘째 문장 «In the club, new members may only draw pictures of the old pots.»대로 'only'(오직) 오래된 항아리 그림을 그릴 수 있어요.")])
