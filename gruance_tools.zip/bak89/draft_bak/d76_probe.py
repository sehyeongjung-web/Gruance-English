# 18번 레벨1 새 꼴 본보기 (꼴만 보고, 글감은 쓰지 말 것). 정답 자리는 바탕 그대로: n=0→2, n=1→4
I = {}
I[0] = dict(to='Dear Coach Park,',
 S=['Thank you for teaching our football team every Saturday this spring.',
    'My younger brother Minho wants to join your club next month.',
    'Could you tell me the date of the next test for new players?',
    'He is very excited about playing with the older boys.'],
 sign='Sincerely,', name='Jina', key=2,
 ch={0:'동생의 입단 테스트 결과를 물으려고', 1:'코치에게 봄 동안의 지도에 감사하려고', 2:'새 선수 테스트 날짜를 물으려고', 3:'토요일 연습 시간을 바꿔 달라고 하려고', 4:'동생을 연습에 데려가도 되는지 물으려고'})
I[1] = dict(to='Dear Neighbors,',
 S=['Our family moved into the house at the end of this street last week.',
    'We are having a small party in our garden this Saturday afternoon.',
    'We want to meet all of you and share some homemade food.',
    'Please come to our garden at three o\'clock with your family.'],
 sign='Best wishes,', name='Sora', key=3,
 ch={0:'이사 온 것을 알리고 사과하려고', 1:'정원 일을 도와 달라고 부탁하려고', 2:'집에서 만든 음식을 팔려고', 3:'파티 때문에 시끄러울 것을 미리 알리려고', 4:'이웃들을 정원 파티에 초대하려고'})
