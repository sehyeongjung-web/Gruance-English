# 19번 레벨1 새 꼴 본보기 (꼴만 보고, 글감은 쓰지 말 것). 정답 자리는 바탕 그대로: n=0→0, n=1→3
I = {}
I[0] = dict(S=['Jimin stood at the start line of his first swimming race.',
 'His little sister in the stands looked excited about the big race.',
 'Jimin himself felt very nervous and could not stop shaking his hands.',
 'After the race, he saw his best time and felt proud of himself.'],
 ch={0:'nervous → proud', 1:'excited → proud', 2:'nervous → worried', 3:'excited → worried', 4:'bored → worried'})
I[1] = dict(S=['Sujin waited all morning for a letter from her best friend in Busan.',
 'At first, she was happy and checked the mailbox every hour.',
 'By evening, Sujin felt very lonely next to the empty mailbox.',
 'Her mother looked worried about her at dinner that night.'],
 ch={0:'happy → worried', 1:'bored → worried', 2:'worried → lonely', 3:'happy → lonely', 4:'angry → lonely'})
