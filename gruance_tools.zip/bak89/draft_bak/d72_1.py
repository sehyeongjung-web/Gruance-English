# -*- coding: utf-8 -*-
# 32번(빈칸 — 낱말) 레벨1 다시 쓰기 — 번호 0~9 (n1~n10: 얼음·물 / 식물 키우기 / 날씨·구름 / 새 / 소리 / 빛·그림자 / 열·요리 / 자석 / 흙·돌 / 몸·감각)
I = {}
I[0] = dict(S=['Mina poured water into a star tray, a heart tray and a fish tray.',
 'She put the three trays into the freezer at four in the afternoon.',
 'At six, only the small star tray had hard ice in it.',
 'So the water froze the fastest in the ______ tray.'],
 ch={0: 'star', 1: 'heart', 2: 'fish', 3: 'moon', 4: 'flower'})
I[1] = dict(S=['Grandma planted potatoes, corn and beans in her garden in April.',
 'In the fall, the corn and the beans gave her one basket each.',
 'The potato plants gave her four full baskets of food.',
 'So Grandma got the most food that year from her ______ plants.'],
 ch={0: 'corn', 1: 'potato', 2: 'bean', 3: 'pumpkin', 4: 'onion'})
I[2] = dict(S=['Sora looked at the sky from her window for four mornings last week.',
 'From Monday to Wednesday, she saw only a few small white clouds.',
 'On Thursday, big dark clouds covered the whole sky over her town.',
 'So the darkest sky of those four mornings came on ______.'],
 ch={0: 'Monday', 1: 'Tuesday', 2: 'Friday', 3: 'Thursday', 4: 'Wednesday'})
I[3] = dict(S=['Jiho watched a white duck at the pond in the park for an hour.',
 'For most of the hour, the duck swam and ate grass by the water.',
 'At four o\'clock, it flew over the trees and landed near the river.',
 'So the duck ______ from the pond to the river at four o\'clock.'],
 ch={0: 'swam', 1: 'walked', 2: 'flew', 3: 'ran', 4: 'hopped'})
I[4] = dict(S=['Dami dropped a coin, a key and a spoon on the floor one by one.',
 'Her brother Taeho named each thing by its sound alone.',
 'He got the coin and the spoon right and called the key a coin.',
 'So Taeho made a mistake only with the sound of the ______.'],
 ch={0: 'coin', 1: 'spoon', 2: 'pen', 3: 'cup', 4: 'key'})
I[5] = dict(S=['Yuna put her toy bear on a chair in her dark bedroom.',
 'She stood behind the chair and pointed a flashlight at the bear.',
 'A big shadow of the bear appeared on the door in front of the chair.',
 'So Yuna saw the dark shape of her bear on the ______.'],
 ch={0: 'wall', 1: 'chair', 2: 'door', 3: 'bed', 4: 'window'})
I[6] = dict(S=['Minho and his sister Hana each cooked noodles in hot water for lunch.',
 "After three minutes in the pot, Minho's noodles were still a little hard.",
 "Hana's noodles stayed in the pot for ten minutes and got very soft.",
 "So the noodles in Hana's bowl were too ______ for her."],
 ch={0: 'hard', 1: 'soft', 2: 'salty', 3: 'dry', 4: 'spicy'})
I[7] = dict(S=['Eunji had a red magnet, a blue magnet and a black magnet for her fridge.',
 'She tried to hold five sheets of paper on the fridge with each one.',
 'Only the black magnet held all five sheets in place on the fridge.',
 "So the strongest magnet on Eunji's fridge was the ______ one."],
 ch={0: 'red', 1: 'blue', 2: 'silver', 3: 'white', 4: 'black'})
I[8] = dict(S=["Jun's class dug a hole for a new tree in the school garden.",
 'The soil near the top was soft and full of small roots.',
 'Half a meter down, the children hit a big gray rock.',
 'So the class stopped digging there because of the big ______.'],
 ch={0: 'rock', 1: 'root', 2: 'pipe', 3: 'puddle', 4: 'branch'})
I[9] = dict(S=['Nari, Hoon and Ara closed their eyes for a taste test at school.',
 'Their teacher gave them apple juice, grape juice and orange juice in paper cups.',
 'Only Nari named all three juices right by taste alone.',
 'So the child with the best sense of taste was ______.'],
 ch={0: 'Nari', 1: 'Hoon', 2: 'Ara', 3: 'Minji', 4: 'Yuri'})
