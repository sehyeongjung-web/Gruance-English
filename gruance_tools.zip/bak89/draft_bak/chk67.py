import sys, importlib
sys.path.insert(0,'/home/claude/work'); sys.path.insert(0,'/home/claude/work/draft')
from lib import load
from zlevel import check_texts
_, tb, _ = load('/home/claude/work/out/index.html')
tag = sys.argv[1]; d = importlib.import_module('d67'+tag)
texts = {}
for n, it in sorted(d.I.items()):
    ch = list(tb['31']['2'][n]['choices'])
    for k, v in it.get('ch', {}).items(): ch[k] = v
    a = ch[tb['31']['2'][n]['answer']]
    texts[n] = (' '.join(it['S']), a)
    assert texts[n][0].count('______') == 1, n
check_texts('31', '2', texts, 4)
