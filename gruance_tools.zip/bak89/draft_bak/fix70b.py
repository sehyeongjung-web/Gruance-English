# -*- coding: utf-8 -*-
# 31번 레벨2 새 판 — 감사꾼(sheets70a) 지적 반영: d70.py 의 문장 몇 곳을 고친다.
import importlib.util, pprint
spec = importlib.util.spec_from_file_location('d', '/home/claude/work/draft/d70.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
I = m.I
F = {
 2:  ({0: "Leo fills two bowls, A and B, with rain water and puts them outside.", 1: "He covers bowl B with a plate, but he leaves bowl A open."}, {0:'clean',1:'dirty',2:'muddy',3:'salty',4:'green'}),
 3:  ({2: "On Monday, Ben gives book A to the librarian, but he keeps book B."}, None),
 4:  ({3: "So on day B, the ______ makes his bus ride thirty minutes longer."}, None),
 5:  ({2: "On Tuesday, both rivers are full, but only river A is brown and thick."}, None),
 8:  ({0: "Amy's yard has two fences, A on the east and B on the west."}, None),
 12: ({0: "Mina puts the same amount of cold water in two pots, A and B."}, None),
 16: ({0: "Jun takes bus 7 to the library on two sunny Saturdays, A and B."}, {0:'morning',1:'evening',2:'night',3:'midnight',4:'afternoon'}),
 22: ({2: "Trip A takes four hours, but trip B takes seven, and snow falls all day."}, None),
 23: ({2: "That day, the beach will be warm, but the mountain top will be very cold.", 3: "So for plan B, Sora should put a ______ in her bag."}, None),
 24: ({1: "Both of them practice for four hours in total each week.", 2: "Yuna plays one hour on four days, but Leo plays four hours on Sunday."}, None),
 26: ({2: "The library is open nine to six on Fridays, but only until noon on Saturdays."}, None),
 27: ({1: "Both strings are ten meters long, but only string A is pulled straight."}, None),
 28: ({3: "So at six in the morning, room B is ______, but A is not."}, None),
 29: ({0: "Teams A and B, with eleven players each, play on one field for ninety minutes."}, {0:'field',1:'passing',2:'weather',3:'minutes',4:'number'}),
}
for n, (d, ch) in F.items():
    for i, new in d.items():
        print(n, i, '\n   OLD', I[n]['S'][i], '\n   NEW', new); I[n]['S'][i] = new
    if ch: I[n]['ch'] = ch
out = ['# -*- coding: utf-8 -*-', '# 31번(빈칸 추론) 레벨2 다시 쓰기(352번 이후) 영어 원고 전체. A/B 두 조건 + 결과를 견주는 빈칸 문장.', 'I = {}']
for n in range(30): out.append('I[%d] = dict(S=%s,\n ch=%s)' % (n, pprint.pformat(I[n]['S'], width=120), repr(I[n]['ch'])))
open('/home/claude/work/draft/d70.py', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
