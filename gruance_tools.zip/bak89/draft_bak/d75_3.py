# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨1 다시 쓰기 — 맡은 열 문항 n=20~29 (두 경우를 맞세우는 꼴)
I = {}
I[20] = dict(S=['Last Tuesday, Jaeyun and his older sister stayed home for a snow day.',
 'Jaeyun had his online classes on the computer in his bedroom.',
 'His older sister had her online classes on her phone in the kitchen.',
 'After the classes, the two children played in the snow in the yard.'],
 SM="On the snow day, Jaeyun's older sister took classes in the (A) ______ on her (B) ______.",
 ch={0: 'bedroom - phone', 1: 'kitchen - computer', 2: 'bedroom - computer', 3: 'office - computer', 4: 'kitchen - phone'})
I[21] = dict(S=["Arin's class took a big bus to the science museum for a school trip.",
 'On the way to the museum, Arin sat by the door in the front row.',
 'On the way home, she sat by the window in the back row.',
 'The teacher counted the students twice at the museum gate.'],
 SM="On the ride home, Arin's seat was by the (A) ______ in the (B) ______ row.",
 ch={0: 'door - back', 1: 'window - front', 2: 'driver - front', 3: 'door - front', 4: 'window - back'})
I[22] = dict(S=['Seorin and her older brother went to a kite festival by the river.',
 'Seorin flew a red kite on the grass near the old bridge.',
 'Her older brother flew a yellow kite on top of a small hill.',
 'Their father took many pictures of the two kites in the sky.'],
 SM="At the kite festival, Seorin's older brother flew a (A) ______ kite from the (B) ______.",
 ch={0: 'yellow - hill', 1: 'red - bridge', 2: 'green - bridge', 3: 'red - hill', 4: 'yellow - bridge'})
I[23] = dict(S=["Yejun's dance class is getting ready for a show at the town hall.",
 'In the first dance, Yejun waves a fan on the left side.',
 'In the second dance, he waves a flag on the right side.',
 'The class practices the two dances every Friday after school.'],
 SM='During the first dance of the show, Yejun holds a (A) ______ on the (B) ______ side.',
 ch={0: 'fan - left', 1: 'flag - left', 2: 'stick - right', 3: 'fan - right', 4: 'flag - right'})
I[24] = dict(S=["In Chaerin's class, each student has a small job for the classroom.",
 'Chaerin cleans the windows with a soft towel every morning.',
 'Her friend Minseok cleans the desks with a wet cloth every afternoon.',
 'Their teacher gives them a sticker for good work each Friday.'],
 SM="Every day, Minseok's job is to clean the (A) ______ in the (B) ______.",
 ch={0: 'windows - afternoon', 1: 'desks - morning', 2: 'chairs - morning', 3: 'windows - morning', 4: 'desks - afternoon'})
I[25] = dict(S=["On rainy days, Eunseo's aunt and uncle often visit her family for games.",
 'Eunseo always plays card games with her uncle in the living room.',
 'Her younger brother always plays word games with their aunt at the kitchen table.',
 'Everyone has hot tea and rice cakes in the evening.'],
 SM="On rainy days, Eunseo's younger brother enjoys (A) ______ games with his (B) ______.",
 ch={0: 'card - aunt', 1: 'word - uncle', 2: 'number - uncle', 3: 'word - aunt', 4: 'card - uncle'})
I[26] = dict(S=["Gyumin's family spends every Friday evening at the night market by the river.",
 'At seven, Gyumin always buys sweet bread from a small cart.',
 'At nine, his father always buys hot potatoes from a food truck.',
 'The family eats the food together on a bench by the water.'],
 SM="On Friday nights, Gyumin's father gets (A) ______ at the market at (B) ______.",
 ch={0: 'bread - nine', 1: 'potatoes - seven', 2: 'potatoes - nine', 3: 'chicken - seven', 4: 'bread - seven'})
I[27] = dict(S=["Daon's family plays board games at home every Saturday night.",
 'Last Saturday, his aunt won the game and chose fish for Sunday lunch.',
 'This Saturday, his uncle won the game and chose chicken for Sunday lunch.',
 "Daon wants his own first win at next week's game night."],
 SM="This weekend, Daon's (A) ______ won the board game and picked (B) ______ for lunch.",
 ch={0: 'uncle - chicken', 1: 'aunt - fish', 2: 'cousin - fish', 3: 'aunt - chicken', 4: 'uncle - fish'})
I[28] = dict(S=['Last summer, Hayul spent two days on a small island with her uncle.',
 'On the first day, they rode to a quiet beach by bike.',
 'On the second day, they went to a big lake by bus.',
 'Hayul sent photos of the trip to her parents every night.'],
 SM='On day two of her island trip, Hayul traveled to the (A) ______ by (B) ______.',
 ch={0: 'lake - bus', 1: 'beach - bike', 2: 'farm - bike', 3: 'lake - bike', 4: 'beach - bus'})
I[29] = dict(S=["Last Saturday, the students at Sejin's school picked up trash on the beach.",
 "Sejin's class put plastic bottles into big blue bags near the rocks.",
 'The class next door put empty cans into big yellow bags.',
 'A big truck took all the bags away in the afternoon.'],
 SM="At the beach, Sejin's class collected (A) ______ in big (B) ______ bags.",
 ch={0: 'cans - blue', 1: 'bottles - blue', 2: 'cans - yellow', 3: 'cups - yellow', 4: 'bottles - yellow'})
