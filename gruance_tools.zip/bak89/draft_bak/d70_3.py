# -*- coding: utf-8 -*-
# 31번(빈칸 추론) 레벨2 새 판 n=20~29. A/B 두 조건 + 셋째 문장의 바꾸어 말하기 + 견주는 빈칸 문장.
I = {}
I[20] = dict(S=["Last month, Jun sat in the back row, and he missed words on the board.",
 "This month, Jun still has the same class, teacher, glasses and books.",
 "But now he sits two meters from the board, and he misses nothing.",
 "So this month, Jun can read the board thanks to his new ______."],
 ch={0: 'glasses', 1: 'seat', 2: 'teacher', 3: 'books', 4: 'class'})
I[21] = dict(S=["Last year, the sign on the door of Room 3 said 'Science Club' in big letters.",
 "This year, the same students and teacher still meet in that room on Tuesdays.",
 "But the sign on the door now says 'Robot Club' in big letters.",
 "So this year, the one new thing about the club is its ______."],
 ch={0: 'room', 1: 'teacher', 2: 'name', 3: 'members', 4: 'day'})
I[22] = dict(S=["Dan's family drives to Busan twice, trip A in October and trip B in January.",
 "Both times, Dad drives the same car on the same quiet road.",
 "Trip A takes four hours, but on trip B, thick snow falls all day long.",
 "So trip B takes three more hours because of the ______."],
 ch={0: 'traffic', 1: 'car', 2: 'driver', 3: 'map', 4: 'weather'})
I[23] = dict(S=["Sora's class trip has two plans, A at the beach and B on a mountain.",
 "Both plans are for the same clear, dry day in early May.",
 "That day, the beach will be hot, but the mountain top will feel like winter.",
 "So for plan B, Sora must put a ______ in her bag."],
 ch={0: 'swimsuit', 1: 'fan', 2: 'umbrella', 3: 'coat', 4: 'towel'})
I[24] = dict(S=["Yuna and Leo learn the same piano song from the same teacher and book.",
 "Yuna plays for an hour on Monday, Wednesday, Friday and Saturday every week.",
 "Leo plays for four hours on Sunday, and he plays at no other time.",
 "So each week, Yuna has more piano ______ than Leo."],
 ch={0: 'hours', 1: 'songs', 2: 'teachers', 3: 'days', 4: 'books'})
I[25] = dict(S=["Jae has two small coin boxes, A and B, on his desk.",
 "He puts a coin in each every day, but he buys candy with B's coins.",
 "After a year, Jae shakes both boxes, and only box A makes a loud sound.",
 "So Jae ______ the coins in box A, but not the coins in box B."],
 ch={0: 'spends', 1: 'saves', 2: 'shakes', 3: 'loses', 4: 'uses'})
I[26] = dict(S=["Mina must return a library book by Monday, and she makes plans A and B.",
 "Plan A is Friday at four, and plan B is Saturday at three.",
 "The library is open from nine to six on Fridays, but until twelve on Saturdays.",
 "So in plan B, the library will be ______ at three o'clock."],
 ch={0: 'open', 1: 'busy', 2: 'noisy', 3: 'closed', 4: 'full'})
I[27] = dict(S=["Ken and Amy make cup phones A and B with the same cups and string.",
 "Both strings are ten meters long, but string B hangs down in a big curve.",
 "Through A, Amy hears Ken's quiet words, but through B she hears almost nothing.",
 "So string B is too ______ to carry Ken's words to Amy."],
 ch={0: 'thin', 1: 'long', 2: 'short', 3: 'old', 4: 'loose'})
I[28] = dict(S=["Sora's house has two bedrooms, A and B, of the same size with east windows.",
 "Room A has thin white curtains, but room B has thick black curtains.",
 "At six, bright sun fills room A, but almost no light gets through B's curtains.",
 "So at seven in the morning, room B is ______, but A is not."],
 ch={0: 'bright', 1: 'dark', 2: 'warm', 3: 'white', 4: 'small'})
I[29] = dict(S=["Ben buys two chocolate bars, A and B, of the same kind and size.",
 "He leaves A in the hot car, and he puts B in the fridge.",
 "Two hours later, A bends easily, but B breaks into two clean pieces.",
 "So after those two hours, chocolate bar A is much ______ than chocolate bar B."],
 ch={0: 'harder', 1: 'softer', 2: 'colder', 3: 'smaller', 4: 'sweeter'})
