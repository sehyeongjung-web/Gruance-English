# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 다시 쓰기 영어 원고 — 문항 10~19. 네 문장 · 단문 · 정답 구가 앞 세 문장에 그대로 · 빈칸 문장만으로는 정해지지 않는 꼴
I = {}
I[10] = dict(S=["Jun's cat Nabi sleeps at the end of his bed every night.",
 'On school days, Nabi wakes Jun up at six by sitting on his chest.',
 'On weekends, his little sister wakes him up by pulling his blanket.',
 "So on school days, the cat starts Jun's morning by ______."],
 ch={0: 'licking his nose softly', 1: 'pulling his blanket', 2: 'meowing next to his ear', 3: 'biting his toes', 4: 'sitting on his chest'})
I[11] = dict(S=['Every Tuesday, Minsu has a taekwondo class at a gym near his school.',
 'At the end of each class, his teacher lets him kick the big black bag.',
 'The younger children stretch on the mats at that time.',
 'So at the end of each class, Minsu can ______.'],
 ch={0: 'stretch on the mats', 1: 'kick the big black bag', 2: 'break a wooden board', 3: 'choose the next game', 4: 'run around the gym'})
I[12] = dict(S=["Junho's family puts cans, bottles and paper into three boxes in the kitchen.",
 'His older sister takes the food waste out on Friday mornings.',
 'Junho carries the full boxes down to the street on Tuesday evenings.',
 'So every week, Junho takes the three boxes outside ______.'],
 ch={0: 'on Friday mornings', 1: 'on Sunday afternoons', 2: 'on Saturday mornings', 3: 'after dinner on Mondays', 4: 'on Tuesday evenings'})
I[13] = dict(S=["Sunwoo's dad comes home from work at about seven every evening.",
 'At the door, he always puts his car keys in the blue bowl.',
 'Then his phone goes on the kitchen shelf next to the radio.',
 "So every evening after work, Sunwoo's dad leaves his car keys ______."],
 ch={0: 'in the blue bowl', 1: 'on the kitchen shelf', 2: 'in his coat pocket', 3: 'on the shoe rack', 4: 'in a desk drawer'})
I[14] = dict(S=['Seojin lives about two kilometers away from her middle school.',
 "On most mornings, she rides to school on her brother's old bike.",
 'On rainy days, she gets there on the green city bus instead.',
 'So on most mornings, Seojin makes the trip to school ______.'],
 ch={0: "on her brother's old bike", 1: 'on the green city bus', 2: "in her mother's small car", 3: 'on the yellow school bus', 4: 'on foot with her friends'})
I[15] = dict(S=['Every morning at seven, Grandma Yoon walks to the small park near her house.',
 'She goes there early to feed the birds by the pond.',
 'In the afternoon, she goes back there to meet her friends.',
 'So at seven every morning, Grandma Yoon goes to the park ______.'],
 ch={0: 'to meet her friends', 1: 'to feed the birds', 2: 'to walk her dog', 3: 'to pick up trash', 4: 'to read the paper'})
I[16] = dict(S=["Every Saturday morning, Hojin's dad makes pancakes for the whole family.",
 "Hojin's little sister sets the table with forks, plates and cups.",
 'In the kitchen, Hojin always helps his dad by cracking the eggs.',
 'So every Saturday morning, Hojin helps with the pancakes by ______.'],
 ch={0: 'mixing the flour', 1: 'setting the table', 2: 'cracking the eggs', 3: 'washing the big bowl', 4: 'pouring in the milk'})
I[17] = dict(S=['Jisu goes to the school newspaper club every Wednesday after lunch.',
 'Her best friend Mina writes the sports news for the back page.',
 'In the club, Jisu always takes the pictures for each new school paper.',
 'So at every Wednesday meeting, the club leader lets Jisu ______.'],
 ch={0: 'write the sports news', 1: 'check the spelling', 2: 'draw the cartoons', 3: 'pick the top stories', 4: 'take the pictures'})
I[18] = dict(S=["Hana's family has an old piano in their small living room.",
 'On school days, Hana practices on it for an hour after dinner.',
 'On Sundays, she plays the piano for her grandmother before lunch.',
 'So from Monday to Friday, Hana sits at the old piano ______.'],
 ch={0: 'after dinner', 1: 'before lunch', 2: 'before school', 3: 'at lunchtime', 4: 'in the morning'})
I[19] = dict(S=['Every Sunday afternoon, Jaemin plays a long game of chess with his grandpa.',
 "In warm weather, they play on the front steps of Grandpa's house.",
 'On cold days, they play in the warm kitchen instead.',
 'So on warm Sundays, Jaemin and his grandpa play chess ______.'],
 ch={0: 'in the warm kitchen', 1: 'under a big tree', 2: 'on the front steps', 3: 'on a park bench', 4: 'in the living room'})
