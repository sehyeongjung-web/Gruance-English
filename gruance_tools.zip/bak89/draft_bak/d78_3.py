# -*- coding: utf-8 -*-
# 19번(심경 변화) 레벨1 새 원고 n=20~29 — I[n] = dict(S=[네 문장], ch={0..4: 'a → b'})
I = {}
I[20] = dict(S=['Dohun felt very tired on the long bike ride to the beach.',
 'His older sister Yena looked excited about the ride from the very start.',
 'Near the end, Dad looked proud of his two kids on the last hill.',
 'At the sight of the sea, Dohun felt happy and ran into the water.'],
 ch={0:'excited → proud', 1:'tired → happy', 2:'excited → happy', 3:'bored → proud', 4:'tired → proud'})
I[21] = dict(S=["Eunji felt excited about her mom's birthday cake from the bakery.",
 'Her little brother Juno looked curious about the big white box on the table.',
 'On the way to the table, Eunji dropped the cake on the kitchen floor.',
 'Eunji felt very sad and sat on the floor next to the cake.'],
 ch={0:'curious → sad', 1:'excited → angry', 2:'calm → angry', 3:'excited → sad', 4:'curious → angry'})
I[22] = dict(S=['Gunwoo felt worried about the time on the slow bus to the station.',
 "At the station, he missed the train to his grandmother's town by two minutes.",
 'His father stayed calm and bought tickets for the next train.',
 'Gunwoo still felt disappointed on a cold bench for the next hour.'],
 ch={0:'worried → disappointed', 1:'calm → disappointed', 2:'worried → relieved', 3:'calm → relieved', 4:'excited → relieved'})
I[23] = dict(S=['Yeseo was curious about the other projects at the school science fair.',
 'Her best friend Mina looked nervous next to her own small robot.',
 'In the afternoon, the judges gave Yeseo the second prize for her robot.',
 'Yeseo felt very proud and showed the prize to her parents at home.'],
 ch={0:'nervous → proud', 1:'curious → proud', 2:'bored → disappointed', 3:'curious → disappointed', 4:'nervous → disappointed'})
I[24] = dict(S=['Siyun felt scared of the big audience before the school play.',
 'Her drama teacher looked calm in the dark corner of the stage.',
 'Siyun said all her lines in the play without a single mistake.',
 'After the play, Siyun felt relieved and laughed with her friends backstage.'],
 ch={0:'scared → relieved', 1:'calm → relieved', 2:'scared → proud', 3:'calm → proud', 4:'bored → proud'})
I[25] = dict(S=['Hyunjin was happy about the hike to the top of Mount Seorak.',
 'His uncle looked tired after the first hour on the steep path.',
 'At the top, thick gray fog covered the whole view of the valley.',
 'Hyunjin felt upset and put his new camera back into his bag.'],
 ch={0:'tired → upset', 1:'tired → angry', 2:'happy → upset', 3:'happy → angry', 4:'excited → angry'})
I[26] = dict(S=['Chaerin felt bored at the start of her first painting class.',
 'Her best friend Dain looked happy with her bright yellow sunflower picture.',
 'Then the teacher showed Chaerin a new way to paint the night sky.',
 'Chaerin felt excited and painted a big blue sky full of stars.'],
 ch={0:'happy → excited', 1:'bored → excited', 2:'bored → thankful', 3:'happy → thankful', 4:'tired → thankful'})
I[27] = dict(S=['Juwon felt calm at the start of the class relay on sports day.',
 'His teammate Seungho looked very nervous at the start line.',
 'In the middle of the race, Juwon dropped the baton on the track.',
 'Juwon felt upset about his mistake for the rest of the day.'],
 ch={0:'nervous → upset', 1:'nervous → lonely', 2:'calm → upset', 3:'calm → lonely', 4:'happy → lonely'})
I[28] = dict(S=['Seyeon felt scared in the dark living room during the power cut.',
 'Her older brother Jiho stayed calm and lit two candles on the table.',
 'The power did not come back for the next three hours.',
 'By ten o\'clock, Seyeon felt bored without her phone or the TV.'],
 ch={0:'calm → bored', 1:'scared → relieved', 2:'calm → relieved', 3:'happy → relieved', 4:'scared → bored'})
I[29] = dict(S=['Hayul felt curious about the old houses in Hahoe Village.',
 'Her younger brother looked bored on the long walk between the houses.',
 'An old woman in the village gave the two children some warm rice cakes.',
 'Hayul felt thankful for her kindness and said goodbye with a big smile.'],
 ch={0:'curious → thankful', 1:'bored → thankful', 2:'curious → tired', 3:'bored → tired', 4:'disappointed → tired'})
