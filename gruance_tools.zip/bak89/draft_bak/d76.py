# -*- coding: utf-8 -*-
# 18번(글의 목적) 레벨1 다시 쓰기(360번) — I[n] = dict(to, S=[본문 네 문장], sign, name, key=목적 문장 자리, ch={0..4: "~하려고"})
I = {}
I[0] = dict(to='Dear Librarian,',
 S=['I am in the second grade and visit the library almost every day.', 'Thank you for the new comic books on the shelf by the window.', 'Could you save one copy of the new space book for me next week?', 'Other students have all three copies of it at the moment.'],
 sign='Thank you,', name='Yerin', key=2,
 ch={0: '우주 책의 반납 날짜를 물으려고', 1: '새로 들어온 만화책에 감사하려고', 2: '우주 책 한 권을 예약해 달라고 하려고', 3: '빌린 우주 책을 늦게 돌려준다고 알리려고', 4: '새 우주 책을 더 사 달라고 하려고'})
I[1] = dict(to='Dear Neighbor,',
 S=['My family lives in the blue house across the street from you.', 'Thank you for the sweet apples from your garden last week.', 'My grandparents are coming to our house for dinner this Saturday.', 'Could they park their car in your empty parking space on Saturday?'],
 sign='Best wishes,', name='Jiho', key=3,
 ch={0: '정원에서 딴 사과에 감사하려고', 1: '토요일 저녁 식사에 이웃을 초대하려고', 2: '토요일 저녁에 이웃의 차를 빌리려고', 3: '토요일 저녁에 시끄러울 것을 미리 알리려고', 4: '토요일 저녁에 주차 자리를 빌리려고'})
I[2] = dict(to='Dear Center Manager,',
 S=['I signed up my son Junu for your Saturday hip-hop class in May.', 'Please take his name off the list for this class.', 'He broke his left arm in a soccer game last weekend.', 'Thank you for the fun trial class for Junu last month.'],
 sign='Sincerely,', name='Eunha', key=1,
 ch={0: '아들의 춤 수업을 다른 요일로 옮기려고', 1: '지난달 체험 수업에 감사하려고', 2: '아들의 춤 수업 신청을 취소하려고', 3: '춤 수업의 수업료를 돌려 달라고 하려고', 4: '토요일 춤 수업의 시간을 물으려고'})
I[3] = dict(to='Dear Uncle Minsu,',
 S=['Please send me some photos of your new farm in New Zealand.', 'My class has a special day about other countries next Friday.', 'Your birthday gift of a wool hat arrived at our house yesterday.', 'I want to show my friends the sheep on your farm.'],
 sign='Love,', name='Taeo', key=0,
 ch={0: '삼촌에게 뉴질랜드 엽서를 부탁하려고', 1: '생일 선물이 잘 도착했다고 알리려고', 2: '삼촌에게 우리 반 사진을 보내 주려고', 3: '삼촌에게 농장 사진을 부탁하려고', 4: '삼촌의 농장에 놀러 가도 되는지 물으려고'})
I[4] = dict(to='Dear Homeroom Teacher,',
 S=['I am the mother of Doha, a student in your class.', 'Thank you for your kind words about his science report last week.', 'He has a high fever and a bad cough this morning.', 'He will miss school and stay home today and tomorrow.'],
 sign='Sincerely,', name='Yujin', key=3,
 ch={0: '과학 보고서 칭찬에 감사하려고', 1: '아들이 오늘 늦게 등교한다고 알리려고', 2: '아들이 일찍 집에 가도 되는지 물으려고', 3: '이틀 동안의 숙제를 물으려고', 4: '아들이 이틀 동안 결석한다고 알리려고'})
I[5] = dict(to='Dear Bike Shop Owner,',
 S=['I left my red bike at your shop on Monday afternoon.', 'Thank you for checking my brakes for free last time.', 'Which day will my bike be ready after the repair?', 'I need it for a long ride with my club on Saturday.'],
 sign='Thanks,', name='Gyumin', key=2,
 ch={0: '브레이크를 무료로 봐 준 데 감사하려고', 1: '자전거 수리비가 얼마인지 물으려고', 2: '자전거 타이어를 새로 갈아 달라고 하려고', 3: '자전거 수리가 언제 끝나는지 물으려고', 4: '빨간 자전거를 고쳐 달라고 맡기려고'})
I[6] = dict(to='Dear Park Office,',
 S=['I walk my dog in Green Park almost every evening.', 'One leg of the bench near the big pond fell off yesterday.', 'Small children often sit on that bench with their parents.', 'Thank you for the new flowers along the path this spring.'],
 sign='Best regards,', name='Hyewon', key=1,
 ch={0: '연못 근처에 벤치를 더 놓아 달라고 하려고', 1: '산책로에 꽃을 심어 준 데 감사하려고', 2: '연못 옆 산책로 전등이 꺼졌다고 알리려고', 3: '연못 옆 벤치가 망가졌다고 알리려고', 4: '아이들이 벤치를 망가뜨린다고 알리려고'})
I[7] = dict(to='Dear Aunt Jiyoung,',
 S=['Our family is planning a visit to your house in Busan next Saturday.', 'Thank you for the big box of kimchi last month.', 'My younger sister has a piano contest on that Saturday morning.', 'Could we come to your house one week later on the twentieth?'],
 sign='Love,', name='Seyun', key=3,
 ch={0: '김치를 보내 준 이모에게 감사하려고', 1: '이모 댁에 가는 날을 한 주 미루려고', 2: '이모를 동생의 피아노 대회에 초대하려고', 3: '부산 이모 댁 방문을 취소한다고 알리려고', 4: '이모에게 우리 집에 와 달라고 하려고'})
I[8] = dict(to='Dear Choir Leader,',
 S=['I am a first-year student and sing in the church choir on Sundays.', 'Your choir sang beautifully at the school festival last month.', 'Please let me join your choir as a new member this year.', 'I can come to every practice after school on Tuesdays and Thursdays.'],
 sign='Sincerely,', name='Nayun', key=2,
 ch={0: '합창단의 연습 요일을 물으려고', 1: '교회 합창단 공연에 초대하려고', 2: '합창단 연습 시간을 바꿔 달라고 하려고', 3: '학교 합창단에 들어가겠다고 신청하려고', 4: '축제 공연이 멋졌다고 칭찬하려고'})
I[9] = dict(to='Dear Flower Shop Owner,',
 S=['Please make a basket of pink roses for my grandmother this Sunday.', 'She will have her seventieth birthday party at a restaurant near your shop.', 'Your yellow tulips for my mom last spring were really lovely.', 'I will come to your shop for the basket at noon on Sunday.'],
 sign='Thank you,', name='Doyeon', key=0,
 ch={0: '지난봄의 노란 튤립에 감사하려고', 1: '할머니께 드릴 꽃바구니를 주문하려고', 2: '꽃바구니를 식당으로 보내 달라고 하려고', 3: '엄마께 드릴 꽃바구니를 주문하려고', 4: '꽃집이 일요일에도 문을 여는지 물으려고'})
I[10] = dict(to='Dear Museum Guide,',
 S=['I am the leader of the history club at Hanbit Middle School.', 'Thank you for the fun tour of the dinosaur room last spring.', 'Our twelve club members want to see the new space room next month.', "Could we book a group tour for Friday, May tenth, at ten o'clock?"],
 sign='Sincerely,', name='Yerin', key=3,
 ch={0: '지난봄의 공룡관 안내에 감사하려고', 1: '우주 전시가 열리는 날짜를 물으려고', 2: '박물관 단체 관람 예약을 하루 앞당기려고', 3: '단체 관람 예약을 취소하려고', 4: '박물관 단체 관람을 예약하려고'})
I[11] = dict(to='Dear Apartment Manager,',
 S=['I live with my family on the ninth floor of Building C.', 'Please send someone to check the elevator in our building this week.', 'It makes a loud noise between the fifth and sixth floors at night.', 'Thank you again for fixing the lights in the parking lot last month.'],
 sign='Thank you,', name='Minjun', key=1,
 ch={0: '주차장 전등을 고쳐 주어 감사하려고', 1: '엘리베이터 소음의 까닭을 물으려고', 2: '밤에 이웃이 시끄럽다고 알리려고', 3: '주차장 전등 점검을 부탁하려고', 4: '엘리베이터를 살펴봐 달라고 하려고'})
I[12] = dict(to="Dear Jiho's Parents,",
 S=["I was at Jiho's birthday party at your house last Saturday.", 'Thank you for the delicious pizza and the fun games in the yard.', 'Could you send me the photos from the party by email?', 'I want to show them to my grandma in Busan.'],
 sign='Best wishes,', name='Seoyeon', key=2,
 ch={0: '파티 사진을 보내 달라고 하려고', 1: '생일 파티에 불러 주어 감사하려고', 2: '파티에서 찍은 사진을 보내 주려고', 3: '맛있던 피자 가게 이름을 물으려고', 4: '다음 생일 파티에 초대하려고'})
I[13] = dict(to='Dear Art Teacher,',
 S=['What is the date of the city art contest this year?', "I want to enter the contest with a picture of my grandma's garden.", 'My older sister won second prize in the same contest last year.', 'I will need about three weeks to finish the picture at home.'],
 sign='Sincerely,', name='Jieun', key=0,
 ch={0: '그림 대회가 열리는 날을 물으려고', 1: '언니가 받은 상을 자랑하려고', 2: '그림 대회에 낼 그림의 크기를 물으려고', 3: '할머니 정원 그림을 봐 달라고 하려고', 4: '그림 대회에 나가지 않겠다고 알리려고'})
I[14] = dict(to='Dear Bus Company,',
 S=['I rode your green bus from the train station to the city park yesterday.', 'The driver was very kind to my grandma with her heavy bags.', 'Please help me find my blue umbrella from that bus.', 'I left it under my seat near the back door.'],
 sign='Thank you,', name='Hyunjin', key=2,
 ch={0: '친절한 버스 기사에게 감사하려고', 1: '공원으로 가는 버스 시간을 물으려고', 2: '버스 의자 밑이 더러웠다고 알리려고', 3: '버스에 두고 내린 지갑을 찾으려고', 4: '버스에 두고 내린 우산을 찾으려고'})
I[15] = dict(to='Dear Cafeteria Staff,',
 S=['I am in the second grade at Saebit Middle School.', 'Thank you for the hot soup on those cold days last winter.', 'Many students in my class love fresh fruit after lunch.', 'Please add fruit salad to the lunch menu on Fridays.'],
 sign='Best wishes,', name='Yoonseo', key=3,
 ch={0: '겨울 동안의 따뜻한 국에 감사하려고', 1: '급식에 과일 샐러드를 넣자고 하려고', 2: '금요일 점심 시간을 바꿔 달라고 하려고', 3: '급식에 아이스크림을 넣자고 하려고', 4: '급식에서 국을 빼 달라고 하려고'})
I[16] = dict(to='Dear Grandpa,',
 S=['Our summer vacation starts on the twentieth of July this year.', 'Mom and I are going to stay at your farm for five days.', 'Thank you for the box of sweet corn last month.', 'We will arrive by train on Saturday morning before lunch.'],
 sign='Love,', name='Taeyoon', key=1,
 ch={0: '여름에 찾아뵐 계획을 알리려고', 1: '보내 주신 옥수수에 감사하려고', 2: '농장에 친구와 함께 가도 되는지 물으려고', 3: '여름 방문을 미루겠다고 알리려고', 4: '겨울에 찾아뵐 계획을 알리려고'})
I[17] = dict(to='Dear Camp Leader,',
 S=['What should I bring to the science camp next weekend?', 'My mom put my name on the list for the camp last Monday.', 'I am very excited about the night walk in the forest.', 'I already have a warm blanket and a flashlight from my uncle.'],
 sign='Thank you,', name='Dongha', key=0,
 ch={0: '숲속 밤 산책이 기대된다고 전하려고', 1: '캠프 신청이 잘 되었는지 물으려고', 2: '캠프에 챙겨 갈 것을 물으려고', 3: '캠프가 열리는 곳을 물으려고', 4: '캠프에 가지 못한다고 알리려고'})
I[18] = dict(to='Dear Doctor Han,',
 S=['I have an appointment for my teeth on Thursday at four.', 'Thank you for fixing my bad tooth so gently last month.', 'My school has a music test at that time on Thursday.', 'Can I come on Friday at the same time instead?'],
 sign='Sincerely,', name='Subin', key=3,
 ch={0: '지난달의 치료에 감사하려고', 1: '치과 예약을 다른 날로 옮기려고', 2: '목요일 치과 예약을 취소하려고', 3: '이가 다시 아프다고 알리려고', 4: '동생의 치과 예약을 다른 날로 옮기려고'})
I[19] = dict(to='Dear School Radio Club,',
 S=['I listen to your lunch radio show in my classroom every day.', 'Thank you for playing my favorite song for our class on Monday.', 'Please tell a story about the new school library on your show.', 'Many students still do not know about the quiet reading rooms there.'],
 sign='Best wishes,', name='Chaerin', key=2,
 ch={0: '도서관 소식을 방송해 달라고 하려고', 1: '좋아하는 노래를 틀어 주어 감사하려고', 2: '점심 방송에 신청곡을 보내려고', 3: '방송반에 들어가는 방법을 물으려고', 4: '점심 방송 소리가 작다고 알리려고'})
I[20] = dict(to='Dear Zoo Manager,',
 S=['My class visited your zoo on a school trip last Friday afternoon.', 'Please add my name to your list of summer volunteers for this year.', 'The baby elephants were my favorite part of the whole trip.', 'I can help at the zoo every Saturday morning in July and August.'],
 sign='Sincerely,', name='Yerin', key=1,
 ch={0: '여름 방학 동물원 캠프에 신청하려고', 1: '아기 코끼리가 견학에서 가장 좋았다고 전하려고', 2: '여름 동안 동물원 일을 돕겠다고 신청하려고', 3: '토요일 오전의 견학 예약을 바꾸려고', 4: '여름 자원봉사자 모집 기간을 물으려고'})
I[21] = dict(to='Dear Piano Teacher,',
 S=['My daughter Seyeon took piano lessons from you for three years in elementary school.', 'Thank you again for your kind and patient lessons in those years.', 'Seyeon will have her first piano concert at the city hall on May tenth.', 'We want to invite you to her concert as our special guest.'],
 sign='Best wishes,', name='Minji', key=3,
 ch={0: '그동안 딸을 가르쳐 준 것에 감사하려고', 1: '딸의 피아노 수업을 다시 부탁하려고', 2: '딸의 첫 연주회에 선생님을 모시려고', 3: '딸의 졸업식에 선생님을 모시려고', 4: '연주회에서 칠 곡을 골라 달라고 하려고'})
I[22] = dict(to='Dear Theater Manager,',
 S=['Could you tell me the price of group tickets for twenty students?', 'Our English club wants to see an animal movie together next Friday.', 'Your theater was very clean and comfortable on my last visit.', 'Most of our members are in the first and second grades.'],
 sign='Thank you,', name='Junseo', key=0,
 ch={0: '학생 단체 관람권의 값을 물으려고', 1: '지난번에 가 본 극장이 깨끗했다고 칭찬하려고', 2: '단체 관람 날짜를 금요일로 바꾸려고', 3: '동아리가 볼 동물 영화를 추천받으려고', 4: '단체 관람 때 앞쪽 좌석을 부탁하려고'})
I[23] = dict(to='Dear Taeyun,',
 S=['You lent me your science book for the test two weeks ago.', 'Your notes in the book helped me a lot with the hard questions.', 'I am really sorry for giving the book back to you so late.', "I left it at my grandma's house for the whole week by mistake."],
 sign='Thanks,', name='Hyunjin', key=2,
 ch={0: '빌린 과학책을 며칠 더 빌려 달라고 하려고', 1: '책을 늦게 돌려준 일을 사과하려고', 2: '책에 적힌 메모 덕분에 고맙다고 하려고', 3: '시험 공부를 함께 하자고 하려고', 4: '할머니 댁에 둔 책을 찾아 달라고 하려고'})
I[24] = dict(to='Dear Farm Owner,',
 S=['My family watched a TV show about your strawberry farm last week.', 'Your strawberries looked very big and sweet on the screen.', 'We want to pick strawberries at your farm with our three young children.', 'Please save five places for us this Saturday at ten in the morning.'],
 sign='Sincerely,', name='Kyungho', key=3,
 ch={0: '일요일 딸기 따기 자리를 예약하려고', 1: '방송에서 본 딸기가 크고 달았다고 전하려고', 2: '어린아이들도 딸기를 따도 되는지 물으려고', 3: '토요일 딸기 따기 예약을 취소하려고', 4: '토요일 딸기 따기 자리를 예약하려고'})
I[25] = dict(to='Dear Community Center,',
 S=['My grandmother moved to this town from Gwangju last month.', 'Do you have any free computer classes for older people this fall?', 'She wants to send photos to her grandchildren on her new phone.', 'Your new library on the first floor looks very nice.'],
 sign='Thank you,', name='Sungmin', key=1,
 ch={0: '어린이를 위한 무료 강좌가 있는지 물으려고', 1: '어르신을 위한 무료 강좌가 있는지 물으려고', 2: '센터의 새 도서관이 좋다고 칭찬하려고', 3: '가을 컴퓨터 강좌의 날짜를 바꿔 달라고 하려고', 4: '할머니가 이 동네로 이사 온 것을 알리려고'})
I[26] = dict(to='Dear School Nurse,',
 S=['My son Jiho has a bad cold and a sore throat this week.', 'Thank you for taking care of him in your office last Monday.', 'Please keep his medicine in your office and give it to him after lunch.', 'He will bring the medicine to you in a small white bag.'],
 sign='Sincerely,', name='Eunhee', key=2,
 ch={0: '아들이 월요일에 결석한 까닭을 알리려고', 1: '월요일에 아들을 돌봐 준 것에 감사하려고', 2: '아들의 약을 맡아서 먹여 달라고 하려고', 3: '아들을 점심 뒤에 일찍 보내 달라고 하려고', 4: '아들을 보건실에서 쉬게 해 달라고 하려고'})
I[27] = dict(to='Dear Radio Host,',
 S=["Please play my mom's favorite song, Blue Sky, on your Friday morning show.", 'My mom listens to your show every morning in her small kitchen.', 'This Friday will be her fiftieth birthday after a long and busy year.', 'Your funny stories always make our mornings bright and happy.'],
 sign='Best wishes,', name='Dowon', key=0,
 ch={0: '엄마의 생일 축하 글을 읽어 달라고 하려고', 1: '진행자의 재미있는 이야기에 고마워하려고', 2: '엄마에게 생일 선물을 보내 달라고 하려고', 3: '엄마를 위해 노래를 틀어 달라고 하려고', 4: '엄마가 좋아하는 노래의 제목을 물으려고'})
I[28] = dict(to='Dear Hotel Manager,',
 S=['My family is staying in Room 305 at your hotel for three nights.', 'The breakfast at your hotel was very fresh and delicious this morning.', 'Our room is right next to the noisy elevator on the third floor.', 'Please move us to a quiet room on a higher floor tonight.'],
 sign='Thank you,', name='Sangwoo', key=3,
 ch={0: '오늘 밤 조용한 방으로 옮겨 달라고 하려고', 1: '신선하고 맛있는 아침 식사에 감사하려고', 2: '엘리베이터 소리를 고쳐 달라고 부탁하려고', 3: '오늘 밤 더 넓은 방으로 옮겨 달라고 하려고', 4: '아침 식사 시간을 바꿔 달라고 하려고'})
I[29] = dict(to='Dear Chess Club Members,',
 S=['Our school chess tournament was on the calendar for Saturday, November 8.', 'The tournament will now take place on Saturday, November 15 instead.', 'The school gym has a big basketball game on the eighth.', 'Thank you for your hard practice every Friday after school.'],
 sign='Best wishes,', name='Jaewon', key=1,
 ch={0: '대회가 한 주 앞당겨진 것을 알리려고', 1: '금요일 방과 후의 연습에 감사하려고', 2: '대회 장소가 체육관으로 바뀐 것을 알리려고', 3: '대회가 한 주 뒤로 미뤄진 것을 알리려고', 4: '대회 날짜를 바꿀 수 있는지 물으려고'})
