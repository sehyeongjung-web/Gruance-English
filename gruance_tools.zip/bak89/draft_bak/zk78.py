# -*- coding: utf-8 -*-
# 19번 레벨1 한글 원고 자체 검사.  python3 draft/zk78.py <k파일> [<d파일: 기본 draft/d78.py>]
#   K[n] = dict(ko=해석, s1=처음 문장 자리(0~3), k1=그 해석, w1=처음 풀이, s2=나중 문장 자리, k2=그 해석, w2=나중 풀이, gl=['뜻 → 뜻'×5], words=낱말, cn=[까닭×5])
import sys, re, importlib.util
sys.path.insert(0, '/home/claude/work')
def load(p, nm):
    spec = importlib.util.spec_from_file_location(nm, p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
kf = load(sys.argv[1], 'kk'); df = load(sys.argv[2] if len(sys.argv) > 2 else '/home/claude/work/draft/d78.py', 'dd')
from z19common import maker
from lib import load as L
_tb = L()[1]
bad = 0
def warn(n, msg):
    global bad; bad += 1; print('!! n=%d  %s' % (n, msg))
for n, K in sorted(kf.K.items()):
    I = df.I[n]; text = ' '.join(I['S']); a = _tb['19']['1'][n]['answer']; CH = [I['ch'][k] for k in range(5)]
    words = set(re.findall(r"[A-Za-z']+", text.lower())) | {w for c in CH for w in re.findall(r'[a-z]+', c)}
    try:
        E = {}; maker(E)(n, a, text, CH, K['ko'], I['S'][K['s1']], K['k1'], K['w1'], I['S'][K['s2']], K['k2'], K['w2'], K['gl'], K['words'], K['cn'])
    except AssertionError as e:
        warn(n, 'z19common 거절: %s' % (e,)); continue
    allk = K['w1'] + ' ' + K['w2'] + ' ' + ' '.join(K['cn'])
    if re.search(r'니다[\.\s]', allk) or re.search(r'니다$', allk): warn(n, '「~니다」 말끝 금지(~어요)')
    if '"' in allk: warn(n, '큰따옴표 대신 «» 를 쓸 것')
    for q in re.findall(r'«([^»]+)»', allk):
        if len(q) < 12: warn(n, '«%s» 12자 미만 — 짧은 조각은 작은따옴표로' % q)
    for q in re.findall(r"(?<![A-Za-z])'([A-Za-z][^'»]*?)'(?![A-Za-z])", allk):
        if any(t not in words for t in re.findall(r"[A-Za-z]+", q.lower())): warn(n, "'%s' 지문 · 보기에 없는 영어 낱말" % q)
    if re.search(r'\d+번', allk): warn(n, '숫자 + 「번」 금지')
    for f in ('w1', 'w2'):
        if not (50 <= len(K[f]) <= 320): warn(n, '%s 길이 %d자(50~320자)' % (f, len(K[f])))
    if not re.search(r'(첫째|둘째|셋째|넷째) 문장', K['w1'] + K['w2']): warn(n, '풀이에 미끼 낱말(다른 사람의 마음)이 나오는 문장을 서수로 짚을 것')
print('검사 끝 — 걸린 것 %d' % bad)
