# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 한글 (d73.py I[15]~I[19]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[15] = dict(
 ko="매일 아침 일곱 시에, 강 할머니는 자기 집 근처의 작은 공원까지 걸어간다. 그녀는 연못가의 새들에게 먹이를 주러 일찍 그곳에 간다. 오후에는, 그녀는 친구들을 만나러 그곳에 다시 간다. 그래서 매일 아침 일곱 시에, 강 할머니는 ______ 공원에 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So at seven every morning, Grandma Kang goes to the park»(그래서 매일 아침 일곱 시에, 강 할머니는 … 공원에 간다) 뒤가 비어 있어요. 매일 아침 일곱 시에 무엇을 하러 공원에 가는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «She goes there early to feed the birds by the pond.»(그녀는 연못가의 새들에게 먹이를 주러 일찍 그곳에 간다.) 'to feed the birds'(새들에게 먹이를 주러)가 그대로 나와요. 첫째 문장의 'Every morning at seven'(매일 아침 일곱 시에)이 곧 둘째 문장의 'early'(일찍)이니, 가는 까닭이 바로 이것이에요.",
 "3) 확인: 셋째 문장 «In the afternoon, she goes back there to meet her friends.»(오후에는, 그녀는 친구들을 만나러 그곳에 다시 간다.) 'to meet her friends'(친구들을 만나러)도 그대로 나오지만, 이것은 'In the afternoon'(오후에는) 공원에 다시 가서 하는 일이라 아침 일곱 시의 일이 아니에요.",
 "4) 묶기: 매일 아침 일곱 시에 공원에 가는 까닭 = 'to feed the birds'(새들에게 먹이를 주러)."],
 traps="「친구들을 만나러」가 끌릴 수 있어요. 셋째 문장에 'to meet her friends'(친구들을 만나러)가 그대로 나오고, 빈칸 문장만 보면 자연스럽거든요. 하지만 그것은 'In the afternoon'(오후에는)의 일이에요. 「개를 산책시키러」도 첫째 문장의 'walks'(걸어간다) 때문에 끌리지만, 일찍 가는 까닭은 'to feed the birds'(새들에게 먹이를 주러)예요.",
 cn=[("친구들을 만나러", "셋째 문장 «In the afternoon, she goes back there to meet her friends.»에서 친구들을 만나는 것은 오후에 공원에 다시 가서 하는 일이에요. 아침 일곱 시에 일찍 가는 까닭은 둘째 문장의 'to feed the birds'(새들에게 먹이를 주러)예요."),
     ("새들에게 먹이를 주러", "둘째 문장 «She goes there early to feed the birds by the pond.»이 근거예요. 첫째 문장에서 할머니는 매일 아침 일곱 시에 공원에 가고, 그렇게 일찍 가는 까닭이 연못가의 새들에게 먹이를 주는 것이니, 할머니는 새들에게 먹이를 주러 공원에 가요."),
     ("개를 산책시키러", "개를 산책시키는 일은 글에 나오지 않아요. 첫째 문장에서 할머니는 공원까지 'walks'(걸어간다)라고만 하고, 둘째 문장에서 일찍 공원에 가는 까닭은 'to feed the birds'(새들에게 먹이를 주러)예요."),
     ("쓰레기를 주우러", "쓰레기를 줍는 일은 글에 나오지 않아요. 둘째 문장에서 할머니가 일찍 공원에 가는 까닭은 'to feed the birds'(새들에게 먹이를 주러)이고, 셋째 문장의 'to meet her friends'(친구들을 만나러)는 오후의 일이에요."),
     ("신문을 읽으러", "신문을 읽는 일은 글에 나오지 않아요. 둘째 문장에서 할머니가 일찍 공원에 가는 까닭은 'to feed the birds by the pond'(연못가의 새들에게 먹이를 주러)예요.")])
K[16] = dict(
 ko="매주 토요일 아침, 호진이의 아빠는 온 가족을 위해 팬케이크를 만든다. 호진이의 여동생은 포크, 접시, 컵으로 식탁을 차린다. 부엌에서, 호진이는 달걀을 깨는 것으로만 아빠를 돕는다. 그래서 매주 토요일 아침, 호진이는 오직 ______ 팬케이크 만들기를 돕는다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every Saturday morning, Hojin helps with the pancakes only by»(그래서 매주 토요일 아침, 호진이는 오직 … 팬케이크 만들기를 돕는다) 뒤가 비어 있어요. 호진이가 오직 무엇으로 팬케이크 만들기를 돕는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «In the kitchen, Hojin helps his dad only by cracking the eggs.»(부엌에서, 호진이는 달걀을 깨는 것으로만 아빠를 돕는다.) 'cracking the eggs'(달걀을 깨는 것)이 그대로 나와요. 이것이 호진이가 팬케이크 만들기를 돕는 방법이에요.",
 "3) 확인: 둘째 문장 «Hojin's little sister sets the table with forks, plates and cups.»(호진이의 여동생은 포크, 접시, 컵으로 식탁을 차린다.) 'sets the table'(식탁을 차린다)은 호진이가 아니라 여동생의 일이에요. 셋째 문장이 'only by'(~로만)라고 하니 호진이가 돕는 방법은 'cracking the eggs'(달걀을 깨는 것) 하나뿐이고, 빈칸 문장의 'only'(오직)와도 맞아요.",
 "4) 묶기: 호진이가 팬케이크 만들기를 돕는 방법 = 'cracking the eggs'(달걀을 깨는 것)."],
 traps="「식탁을 차리는 것으로」가 끌릴 수 있어요. 둘째 문장에 'sets the table'(식탁을 차린다)이 나오고, 빈칸 문장만 보면 그 말도 자연스럽거든요. 하지만 둘째 문장에서 식탁을 차리는 사람은 'Hojin's little sister'(호진이의 여동생)예요. 「밀가루를 섞는 것으로」도 끌리지만, 셋째 문장의 'only by'(~로만)가 막아요.",
 cn=[("밀가루를 섞는 것으로", "밀가루를 섞는 일은 글에 나오지 않아요. 셋째 문장이 'only by cracking the eggs'(달걀을 깨는 것으로만)라고 하니, 호진이가 아빠를 돕는 방법은 달걀을 깨는 것 하나뿐이에요."),
     ("식탁을 차리는 것으로", "둘째 문장 «Hojin's little sister sets the table with forks, plates and cups.»에서 식탁을 차리는 사람은 호진이가 아니라 여동생이에요. 호진이가 하는 일은 셋째 문장의 'cracking the eggs'(달걀을 깨는 것)예요."),
     ("달걀을 깨는 것으로", "셋째 문장 «In the kitchen, Hojin helps his dad only by cracking the eggs.»이 근거예요. 첫째 문장에서 매주 토요일 아침 팬케이크를 만드는 사람은 아빠이고, 호진이는 부엌에서 달걀을 깨는 것으로만 아빠를 도와요. 'only by'(~로만) 때문에 호진이가 돕는 방법은 이것 하나뿐이에요."),
     ("큰 그릇을 씻는 것으로", "큰 그릇을 씻는 일은 글에 나오지 않아요. 셋째 문장 «In the kitchen, Hojin helps his dad only by cracking the eggs.»에서 'only by'(~로만)라고 하니, 호진이가 아빠를 돕는 방법은 달걀을 깨는 것 하나뿐이에요."),
     ("우유를 붓는 것으로", "우유를 붓는 일은 글에 나오지 않아요. 셋째 문장이 'only by'(~로만)라고 하니, 호진이가 돕는 방법은 'cracking the eggs'(달걀을 깨는 것) 하나뿐이에요.")])
K[17] = dict(
 ko="혜리는 매주 수요일 점심 식사 후에 학교 신문 동아리에 간다. 그녀의 가장 친한 친구 미나는 맨 뒷면에 실을 스포츠 소식을 쓴다. 동아리에서, 혜리는 새 학교 신문마다 실을 사진만 찍는다. 그래서 매주 수요일 모임마다, 혜리의 유일한 일은 ______이다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So at every Wednesday meeting, Hyeri's only job is to»(그래서 매주 수요일 모임마다, 혜리의 유일한 일은 …이다) 뒤가 비어 있어요. 수요일 모임에서 혜리가 하는 하나뿐인 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «In the club, Hyeri only takes the pictures for each new school paper.»(동아리에서, 혜리는 새 학교 신문마다 실을 사진만 찍는다.) 'takes the pictures'(사진을 찍는다)가 그대로 나와요.",
 "3) 확인: 둘째 문장 «Her best friend Mina writes the sports news for the back page.»(그녀의 가장 친한 친구 미나는 맨 뒷면에 실을 스포츠 소식을 쓴다.) 'writes the sports news'(스포츠 소식을 쓴다)가 나오지만, 이것은 혜리가 아니라 'Mina'(미나)가 하는 일이에요. 셋째 문장이 'only takes the pictures'(사진만 찍는다)라고 하니 혜리의 일은 'takes the pictures'(사진을 찍는다) 하나뿐이고, 빈칸 문장의 'only'(유일한)와도 맞아요.",
 "4) 묶기: 수요일 모임에서 혜리의 유일한 일 = 'takes the pictures'(사진을 찍는다)."],
 traps="「스포츠 소식을 쓰는 것」이 끌릴 수 있어요. 둘째 문장에 'writes the sports news'(스포츠 소식을 쓴다)가 나오고, 빈칸 문장만 보면 자연스럽거든요. 하지만 둘째 문장에서 스포츠 소식을 쓰는 사람은 혜리의 친구 'Mina'(미나)예요. 「만화를 그리는 것」도 끌리지만, 셋째 문장의 'only takes the pictures'(사진만 찍는다)가 막아요.",
 cn=[("스포츠 소식을 쓰는 것", "둘째 문장 «Her best friend Mina writes the sports news for the back page.»에서 스포츠 소식을 쓰는 사람은 혜리가 아니라 친구 미나예요. 셋째 문장에서 혜리가 동아리에서 하는 일은 사진을 찍는 거예요."),
     ("맞춤법을 확인하는 것", "맞춤법을 확인하는 일은 글에 나오지 않아요. 셋째 문장이 'only takes the pictures'(사진만 찍는다)라고 하니, 동아리에서 혜리의 일은 사진을 찍는 것 하나뿐이에요."),
     ("만화를 그리는 것", "만화를 그리는 일은 글에 나오지 않아요. 셋째 문장 «In the club, Hyeri only takes the pictures for each new school paper.»에서 'only takes the pictures'(사진만 찍는다)라고 하니, 혜리의 일은 사진을 찍는 것 하나뿐이에요."),
     ("주요 기사를 고르는 것", "주요 기사를 고르는 일은 글에 나오지 않아요. 셋째 문장이 'only takes the pictures'(사진만 찍는다)라고 하니, 혜리의 일은 'takes the pictures'(사진을 찍는다) 하나뿐이에요."),
     ("사진을 찍는 것", "셋째 문장 «In the club, Hyeri only takes the pictures for each new school paper.»이 근거예요. 첫째 문장에서 혜리는 매주 수요일 이 신문 동아리에 가고, 동아리에서 하는 일이 사진을 찍는 것뿐이에요. 'only takes the pictures'(사진만 찍는다) 때문에 혜리의 일은 이것 하나뿐이에요.")])
K[18] = dict(
 ko="다혜네 가족은 작은 거실에 오래된 피아노 한 대가 있다. 학교 가는 날에는, 다혜는 저녁 식사 후에 한 시간 동안 그 피아노로 연습한다. 일요일에는, 그녀는 점심 식사 전에 할머니를 위해 피아노를 친다. 그래서 월요일부터 금요일까지, 다혜는 ______ 그 오래된 피아노 앞에 앉는다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So from Monday to Friday, Dahye sits at the old piano»(그래서 월요일부터 금요일까지, 다혜는 … 그 오래된 피아노 앞에 앉는다) 뒤가 비어 있어요. 월요일부터 금요일까지 다혜가 언제 피아노 앞에 앉는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On school days, Dahye practices on it for an hour after dinner.»(학교 가는 날에는, 다혜는 저녁 식사 후에 한 시간 동안 그 피아노로 연습한다.) 'after dinner'(저녁 식사 후에)가 그대로 나와요. 'On school days'(학교 가는 날에는)는 월요일부터 금요일까지에 맞는 날들이에요.",
 "3) 확인: 셋째 문장 «On Sundays, she plays the piano for her grandmother before lunch.»(일요일에는, 그녀는 점심 식사 전에 할머니를 위해 피아노를 친다.) 'before lunch'(점심 식사 전에)도 그대로 나오지만, 이것은 'On Sundays'(일요일에는) 하는 일이에요. 일요일은 월요일부터 금요일까지에 들지 않아요.",
 "4) 묶기: 월요일부터 금요일까지 다혜가 피아노 앞에 앉는 때 = 'after dinner'(저녁 식사 후에)."],
 traps="「점심 식사 전에」가 끌릴 수 있어요. 셋째 문장에 'before lunch'(점심 식사 전에)가 그대로 나오고, 빈칸 문장만 보면 그 말도 자연스럽거든요. 하지만 셋째 문장의 이 일은 'On Sundays'(일요일에는) 할머니를 위해 피아노를 치는 거예요. 「학교 가기 전에」도 끌리지만, 둘째 문장에서 학교 가는 날의 연습은 'after dinner'(저녁 식사 후에)예요.",
 cn=[("저녁 식사 후에", "둘째 문장 «On school days, Dahye practices on it for an hour after dinner.»이 근거예요. 학교 가는 날, 곧 월요일부터 금요일까지 다혜는 저녁 식사 후에 한 시간 동안 그 피아노로 연습하니, 그때 피아노 앞에 앉아요."),
     ("점심 식사 전에", "셋째 문장 «On Sundays, she plays the piano for her grandmother before lunch.»에서 점심 식사 전에 피아노를 치는 것은 일요일의 일이에요. 월요일부터 금요일까지의 때는 둘째 문장의 'after dinner'(저녁 식사 후에)예요."),
     ("학교 가기 전에", "학교 가기 전에 피아노를 친다는 이야기는 글에 나오지 않아요. 둘째 문장에서 'On school days'(학교 가는 날에는) 다혜가 연습하는 때는 'after dinner'(저녁 식사 후에)예요."),
     ("점심시간에", "점심시간에 피아노를 친다는 이야기는 글에 나오지 않아요. 셋째 문장의 'before lunch'(점심 식사 전에)는 일요일의 일이고, 둘째 문장에서 학교 가는 날 다혜가 연습하는 때는 저녁 식사 후예요."),
     ("아침에", "아침에 피아노를 친다는 이야기는 글에 나오지 않아요. 둘째 문장에서 학교 가는 날 다혜가 그 피아노로 연습하는 때는 'after dinner'(저녁 식사 후에)예요.")])
K[19] = dict(
 ko="매주 일요일 오후, 재민이는 할아버지와 긴 체스 한 판을 둔다. 따뜻한 날씨에는, 그들은 할아버지 집의 현관 앞 계단에서 둔다. 추운 날에는, 그들은 대신 따뜻한 부엌에서 둔다. 그래서 따뜻한 일요일에는, 재민이와 할아버지는 ______ 체스를 둔다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on warm Sundays, Jaemin and his grandpa play chess»(그래서 따뜻한 일요일에는, 재민이와 할아버지는 … 체스를 둔다) 뒤가 비어 있어요. 따뜻한 일요일에 두 사람이 어디에서 체스를 두는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «In warm weather, they play on the front steps of Grandpa's house.»(따뜻한 날씨에는, 그들은 할아버지 집의 현관 앞 계단에서 둔다.) 'on the front steps'(현관 앞 계단에서)가 그대로 나와요. 'In warm weather'(따뜻한 날씨에는)가 빈칸 문장의 'warm Sundays'(따뜻한 일요일)와 맞으니, 두 사람이 체스를 두는 곳은 현관 앞 계단이에요.",
 "3) 확인: 셋째 문장 «On cold days, they play in the warm kitchen instead.»(추운 날에는, 그들은 대신 따뜻한 부엌에서 둔다.) 'warm'(따뜻한)이 들어간 'in the warm kitchen'(따뜻한 부엌에서)이 나오지만, 이것은 'On cold days'(추운 날에는) 두는 곳이에요.",
 "4) 묶기: 따뜻한 일요일에 체스를 두는 곳 = 'on the front steps'(현관 앞 계단에서)."],
 traps="「따뜻한 부엌에서」가 끌릴 수 있어요. 셋째 문장에 'in the warm kitchen'(따뜻한 부엌에서)이 그대로 나오고, 빈칸 문장의 'warm'(따뜻한)과 같은 낱말이 들어 있거든요. 하지만 셋째 문장의 부엌은 'On cold days'(추운 날에는) 두는 곳이에요. 「거실에서」도 끌리지만, 글에 거실은 나오지 않고 따뜻한 날씨에 두는 곳은 둘째 문장의 현관 앞 계단이에요.",
 cn=[("따뜻한 부엌에서", "셋째 문장 «On cold days, they play in the warm kitchen instead.»에서 따뜻한 부엌은 추운 날에 체스를 두는 곳이에요. 빈칸 문장은 따뜻한 일요일을 묻고, 따뜻한 날씨에 두는 곳은 둘째 문장의 'on the front steps'(현관 앞 계단에서)예요."),
     ("큰 나무 아래에서", "큰 나무 아래는 글에 나오지 않아요. 둘째 문장에서 따뜻한 날씨에 두 사람이 체스를 두는 곳은 'on the front steps'(현관 앞 계단에서)예요."),
     ("현관 앞 계단에서", "둘째 문장 «In warm weather, they play on the front steps of Grandpa's house.»이 근거예요. 따뜻한 날씨에는 재민이와 할아버지가 할아버지 집의 현관 앞 계단에서 체스를 두니, 따뜻한 일요일에도 그곳에서 둬요."),
     ("공원 벤치에서", "공원 벤치는 글에 나오지 않아요. 둘째 문장에서 따뜻한 날씨에 체스를 두는 곳은 할아버지 집의 'front steps'(현관 앞 계단)이에요."),
     ("거실에서", "거실은 글에 나오지 않아요. 셋째 문장에서 집 안의 'warm kitchen'(따뜻한 부엌)은 추운 날에 두는 곳이고, 따뜻한 날씨에는 둘째 문장의 'on the front steps'(현관 앞 계단에서) 둬요.")])
