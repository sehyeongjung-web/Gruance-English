# 19번 레벨1 새 원고 n=10~19 — I[n] = dict(S=[네 문장], ch={0..4: 'a → b'})
I = {}
I[10] = dict(S=['On her first day at a new school, Seyeon felt very nervous in the hallway.',
 'Her mother at the school gate looked worried about her shy daughter.',
 'At lunch, her new desk partner looked excited about sharing snacks with Seyeon.',
 'By the end of the day, Seyeon was happy with her new school.'],
 ch={0:'worried → happy', 1:'nervous → excited', 2:'worried → excited', 3:'scared → excited', 4:'nervous → happy'})
I[11] = dict(S=['Before the soccer game, Jaeha was excited about his new red shoes.',
 'In the heavy rain, he slipped in the mud and missed an easy goal.',
 'After the game, Jaeha felt very disappointed and sat alone on the bench.',
 'His coach looked worried about him and gave him a dry towel.'],
 ch={0:'nervous → disappointed', 1:'excited → worried', 2:'excited → disappointed', 3:'nervous → worried', 4:'proud → worried'})
I[12] = dict(S=['In the waiting room at the dentist, Woobin felt scared of the loud drill.',
 'His older sister next to him looked calm and read a comic book.',
 'The dentist found two holes in his teeth and gave him a shot.',
 'On the way home, Woobin was upset about a month with no candy.'],
 ch={0:'calm → upset', 1:'scared → relieved', 2:'calm → relieved', 3:'bored → relieved', 4:'scared → upset'})
I[13] = dict(S=['On Saturday morning, Nayun was excited about building a birdhouse with her dad.',
 'Her little brother stayed home with a cold and felt lonely in his room.',
 'Nayun and her dad built a small birdhouse in the yard before lunch.',
 'In the evening, Nayun felt proud of their new birdhouse on the old tree.'],
 ch={0:'lonely → proud', 1:'excited → tired', 2:'lonely → tired', 3:'thankful → tired', 4:'excited → proud'})
I[14] = dict(S=['Hayul was worried about the big math test on Friday morning.',
 'Her best friend Yewon was calm about the test and smiled at her.',
 'In the test, Hayul solved every problem with the tips from her teacher.',
 'On Monday, Hayul got a perfect score and felt very relieved.'],
 ch={0:'calm → relieved', 1:'worried → relieved', 2:'worried → disappointed', 3:'calm → disappointed', 4:'scared → disappointed'})
I[15] = dict(S=['On the boat ride across the big lake, Juha was happy about the sunny day.',
 'His little sister on the bench looked tired after the long drive.',
 'Suddenly, a strong wind blew his new hat into the cold water.',
 'Juha felt very upset about the hat for the rest of the day.'],
 ch={0:'tired → upset', 1:'happy → upset', 2:'happy → bored', 3:'tired → bored', 4:'curious → bored'})
I[16] = dict(S=['In the long line for the big roller coaster, Yuchan felt very scared.',
 'His older cousin next to him was excited about the first big drop.',
 'The fast ride went up and down the tall tracks for two minutes.',
 'At the exit, Yuchan felt proud of himself and wanted another ride.'],
 ch={0:'scared → proud', 1:'excited → proud', 2:'scared → sad', 3:'excited → sad', 4:'bored → sad'})
I[17] = dict(S=["On Friday, Doha was happy about a sleepover at her best friend's house.",
 'That night, her friend Hyewon told Doha about her move to Canada.',
 'Hyewon looked curious about her new school and a big house in Toronto.',
 'Doha felt sad in her bed for the rest of the night.'],
 ch={0:'curious → sad', 1:'happy → angry', 2:'curious → angry', 3:'happy → sad', 4:'calm → angry'})
I[18] = dict(S=['At the bank with his mom, Gunwoo was bored in the long line.',
 'His mom looked worried about the time and checked her watch.',
 'After forty minutes, a worker closed the window right in front of them.',
 'Gunwoo felt very angry and wanted to go home with his mom.'],
 ch={0:'worried → angry', 1:'bored → tired', 2:'worried → tired', 3:'bored → angry', 4:'lonely → tired'})
I[19] = dict(S=['Yebin felt curious about her first fireworks show by the river.',
 'Her little brother was scared of the loud noise and covered his ears.',
 'At nine, hundreds of bright flowers of fire filled the night sky.',
 'Yebin felt excited and clapped her hands for every big flower.'],
 ch={0:'scared → excited', 1:'curious → disappointed', 2:'curious → excited', 3:'scared → disappointed', 4:'calm → disappointed'})
