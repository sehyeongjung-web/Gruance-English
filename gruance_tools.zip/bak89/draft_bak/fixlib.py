# -*- coding: utf-8 -*-
import re
def load(p): return open(p,encoding='utf-8').read()
def save(p,s): open(p,'w',encoding='utf-8').write(s)
def entry_span(src, tag, n):
    m=re.search(r'(?m)^%s\[%d\] = dict\('%(tag,n),src)
    assert m,(tag,n)
    m2=re.search(r'(?m)^%s\[\d+\] = dict\('%tag,src[m.end():])
    end=m.end()+m2.start() if m2 else len(src)
    return m.start(),end
def erep(src, tag, n, pairs):
    a,b=entry_span(src,tag,n)
    e=src[a:b]
    for old,new,*cnt in pairs:
        c=cnt[0] if cnt else 1
        assert e.count(old)==c,(tag,n,old,e.count(old))
        e=e.replace(old,new)
    return src[:a]+e+src[b:]
