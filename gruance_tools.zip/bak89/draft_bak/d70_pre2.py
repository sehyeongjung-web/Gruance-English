# -*- coding: utf-8 -*-
# 31번(빈칸 추론) 레벨2 다시 쓰기(352번 이후) 영어 원고 전체. A/B 두 조건 + 결과를 견주는 빈칸 문장.
I = {}
I[0] = dict(S=['On nights A and B, Sora does the same amount of homework at her desk.',
 'Her phone is off both nights, but a neighbor plays loud songs on night A.',
 'She needs two hours on night A, but only one hour on night B.',
 'So on night A, the real trouble for Sora is probably the ______.'],
 ch={0: 'phone', 1: 'homework', 2: 'desk', 3: 'chair', 4: 'noise'})
I[1] = dict(S=['Noodle shops A and B sit side by side, and both are open every day.',
 'Both sell the same noodles until nine at night, but shop B opens at noon.',
 "At breakfast, shop A is full of workers, but shop B's door is locked.",
 'So shop B never gets any of the ______ customers on this street.'],
 ch={0: 'lunch', 1: 'dinner', 2: 'weekend', 3: 'holiday', 4: 'morning'})
I[2] = dict(S=['Leo puts two empty bowls, A and B, out in the spring rain.',
 'The next day, he covers bowl B, but he leaves bowl A open.',
 'After a week, bowl A holds dust, leaves and bugs, but bowl B holds none.',
 'So at the end of the week, the water in bowl B is ______.'],
 ch={0: 'clean', 1: 'dirty', 2: 'frozen', 3: 'sweet', 4: 'hot'})
I[3] = dict(S=['On Friday afternoon, Ben borrows two books, A and B, from the school library.',
 'He reads every page of both books at home over the weekend.',
 'On Monday, book A is on the library shelf again, but book B is not.',
 'So by Monday, Ben has ______ book A, but not book B.'],
 ch={0: 'read', 1: 'lost', 2: 'returned', 3: 'bought', 4: 'opened'})
I[4] = dict(S=['On days A and B, Tom wakes up at seven and leaves home at eight.',
 'Both days are sunny, but on day B, his road is full of cars.',
 'His bus ride takes ten minutes on day A, but forty minutes on day B.',
 'So on day B, the ______ makes Tom late for school.'],
 ch={0: 'alarm', 1: 'traffic', 2: 'weather', 3: 'breakfast', 4: 'homework'})
I[5] = dict(S=['Rivers A and B are the same size, and both get heavy rain on Monday.',
 'River A runs past open farm fields, but river B runs between big rocks.',
 'On Tuesday, both rivers run high, but only river A looks like chocolate milk.',
 'So after the rain, river A is carrying a lot more ______.'],
 ch={0: 'water', 1: 'fish', 2: 'ice', 3: 'soil', 4: 'salt'})
I[6] = dict(S=['At the market, Jun fills two paper bags of the same size, A and B.',
 'Bag A holds chips and paper cups, and bag B holds four bottles of milk.',
 'Jun lifts bag A with one finger, but he needs both arms for bag B.',
 'So for Jun, bag B is much ______ than bag A.'],
 ch={0: 'bigger', 1: 'lighter', 2: 'smaller', 3: 'heavier', 4: 'newer'})
I[7] = dict(S=['Every night, Grandpa reads a book, and he leaves his glasses next to it.',
 'He reads in the kitchen on night A, but in bed on night B.',
 'On the morning after night B, the kitchen table has no glasses on it.',
 'So that morning, Grandpa should look for his glasses in his ______.'],
 ch={0: 'kitchen', 1: 'car', 2: 'bedroom', 3: 'pocket', 4: 'garden'})
I[8] = dict(S=["Amy's yard has two fences, A on the east and B on the other side.",
 'One autumn night, a strong wind moves all the leaves in the yard.',
 'In the morning, most leaves lie against fence A, and few lie near fence B.',
 'So that night, the wind probably comes from the ______.'],
 ch={0: 'west', 1: 'east', 2: 'north', 3: 'south', 4: 'sea'})
I[9] = dict(S=['On a calm day, Mia builds castles A and B from the same beach sand.',
 "Both castles are equally tall, but she wets only A's sand, and B's stays dry.",
 'An hour later, castle A still stands, but castle B is a flat pile.',
 'So the one real difference between the two castles is the ______.'],
 ch={0: 'size', 1: 'water', 2: 'sand', 3: 'wind', 4: 'maker'})
I[10] = dict(S=["Mr. Han's ice cream shops, A and B, have the same menu, prices and size.",
 'Shop A stands by a school gate, but shop B is on a quiet street.',
 'On a hot day, A has a long line, but B is almost empty.',
 'So the real reason for the long line at shop A is its ______.'],
 ch={0: 'price', 1: 'menu', 2: 'owner', 3: 'place', 4: 'size'})
I[11] = dict(S=['Ann takes two chocolate bars, A and B, of the same kind to school.',
 'She keeps bar A in her pocket, but bar B stays in her bag.',
 'At lunch, A is soft and hangs over her finger, but B stays straight.',
 'So by lunch, bar A has started to ______, but bar B has not.'],
 ch={0: 'harden', 1: 'freeze', 2: 'crack', 3: 'break', 4: 'bend'})
I[12] = dict(S=['Mina puts the same amount of cold water in equal pots A and B.',
 'Both sit on one stove at one heat, and only A gets a metal top.',
 'Pot A bubbles hard in six minutes, but pot B needs about nine minutes.',
 'So the one real difference between pot A and pot B is the ______.'],
 ch={0: 'cover', 1: 'stove', 2: 'water', 3: 'size', 4: 'heat'})
I[13] = dict(S=['Lizards A and B, of the same size and age, sleep on one rock.',
 'In the morning, the sun shines on A, but B stays in the cool shade.',
 'An hour later, A runs fast after flies, but B still moves very slowly.',
 "So at this point, lizard A's body is ______ than lizard B's body."],
 ch={0: 'warmer', 1: 'colder', 2: 'longer', 3: 'older', 4: 'smaller'})
I[14] = dict(S=['Jun gives two young plants, A and B, the same soil and the same water.',
 'He keeps A by a sunny window, but he keeps B in a dark closet.',
 "Two weeks later, A's leaves are deep green, but B's are thin and light yellow.",
 'So these days, the leaves on plant B look ______.'],
 ch={0: 'green', 1: 'dark', 2: 'pale', 3: 'thick', 4: 'brown'})
I[15] = dict(S=['Jin makes two cups of lemonade, A and B, with the same lemons and water.',
 'He stirs two spoons of a white powder into cup A, but nothing into B.',
 'Cup A tastes sweet and nice, but cup B is too sour to drink.',
 "So Jin's cup A has some ______ in it, unlike cup B."],
 ch={0: 'salt', 1: 'honey', 2: 'sugar', 3: 'water', 4: 'lemon'})
I[16] = dict(S=['Jun takes bus 7 to the library on two sunny school days, A and B.',
 'On day A he gets on early at eight, and on day B after lunch.',
 "Day A's bus is half empty, but on day B Jun stands all the way.",
 "So of Jun's two rides, the busy one is in the ______."],
 ch={0: 'morning', 1: 'evening', 2: 'night', 3: 'rain', 4: 'afternoon'})
I[17] = dict(S=['Ken has two soccer balls, A and B, of the same color and age.',
 'He fills ball A with lots of air, but ball B gets only a little.',
 "Ken's thumb sinks deep into B, but A pushes his thumb right back.",
 'So at this point, ball B is ______ than ball A.'],
 ch={0: 'softer', 1: 'harder', 2: 'darker', 3: 'older', 4: 'newer'})
I[18] = dict(S=['Tanks A and B have the same size, water, light, food and number of fish.',
 'Tank A has a small pump with bubbles, but tank B has no pump.',
 'In tank B, the fish stay near the top and open their mouths fast.',
 'So right now, the fish in tank B probably need more ______.'],
 ch={0: 'air', 1: 'water', 2: 'light', 3: 'food', 4: 'space'})
I[19] = dict(S=['Ben folds two paper boats, A and B, from the same sheet of paper.',
 'He covers boat B with clear tape, and he leaves boat A plain.',
 'In the bath, A soon drops to the bottom, but B stays up.',
 'So at this moment, boat A is ______ the water in the tub.'],
 ch={0: 'on', 1: 'above', 2: 'under', 3: 'outside', 4: 'beside'})
I[20] = dict(S=['Last month, Jun sat in the back row, and he missed words on the board.',
 'This month, Jun still has the same class, teacher, glasses and books.',
 'But now he sits two meters from the board, and he misses nothing.',
 'So this month, Jun can read the board thanks to his new ______.'],
 ch={0: 'glasses', 1: 'seat', 2: 'teacher', 3: 'books', 4: 'class'})
I[21] = dict(S=["Last year, the sign on the door of Room 3 said 'Science Club' in big letters.",
 'This year, the same students and teacher still meet in that room on Tuesdays.',
 "But the sign on the door now says 'Robot Club' in big letters.",
 'So this year, the one new thing about the club is its ______.'],
 ch={0: 'room', 1: 'teacher', 2: 'name', 3: 'members', 4: 'day'})
I[22] = dict(S=["Dan's family drives to Busan twice, trip A in October and trip B in January.",
 'Both times, Dad drives the same car on the same quiet road.',
 'Trip A takes four hours, but on trip B, thick snow falls all day long.',
 'So trip B takes three more hours because of the ______.'],
 ch={0: 'traffic', 1: 'car', 2: 'driver', 3: 'map', 4: 'weather'})
I[23] = dict(S=["Sora's class trip has two plans, A at the beach and B on a mountain.",
 'Both plans are for the same clear, dry day in early May.',
 'That day, the beach will be hot, but the mountain top will feel like winter.',
 'So for plan B, Sora must put a ______ in her bag.'],
 ch={0: 'swimsuit', 1: 'fan', 2: 'umbrella', 3: 'coat', 4: 'towel'})
I[24] = dict(S=['Yuna and Leo learn the same piano song from the same teacher and book.',
 'Yuna plays for an hour on Monday, Wednesday, Friday and Saturday every week.',
 'Leo plays for four hours on Sunday, and he plays at no other time.',
 'So each week, Yuna has more piano ______ than Leo.'],
 ch={0: 'hours', 1: 'songs', 2: 'teachers', 3: 'days', 4: 'books'})
I[25] = dict(S=['Jae has two small coin boxes, A and B, on his desk.',
 "He puts a coin in each every day, but he buys candy with B's coins.",
 'After a year, Jae shakes both boxes, and only box A makes a loud sound.',
 'So Jae ______ the coins in box A, but not the coins in box B.'],
 ch={0: 'spends', 1: 'saves', 2: 'shakes', 3: 'loses', 4: 'uses'})
I[26] = dict(S=['Mina must return a library book by Monday, and she makes plans A and B.',
 'Plan A is Friday at four, and plan B is Saturday at three.',
 'The library is open from nine to six on Fridays, but until twelve on Saturdays.',
 "So in plan B, the library will be ______ at three o'clock."],
 ch={0: 'open', 1: 'busy', 2: 'noisy', 3: 'closed', 4: 'full'})
I[27] = dict(S=['Ken and Amy make cup phones A and B with the same cups and string.',
 'Both strings are ten meters long, but string B hangs down in a big curve.',
 "Through A, Amy hears Ken's quiet words, but through B she hears almost nothing.",
 "So string B is too ______ to carry Ken's words to Amy."],
 ch={0: 'thin', 1: 'long', 2: 'short', 3: 'old', 4: 'loose'})
I[28] = dict(S=["Sora's house has two bedrooms, A and B, of the same size with east windows.",
 'Room A has thin white curtains, but room B has thick black curtains.',
 "At six, bright sun fills room A, but almost no light gets through B's curtains.",
 'So at seven in the morning, room B is ______, but A is not.'],
 ch={0: 'bright', 1: 'dark', 2: 'warm', 3: 'white', 4: 'small'})
I[29] = dict(S=['Teams A and B play on one field with one ball for ninety minutes.',
 "Team A's players kick the ball to each other, but team B's players run alone.",
 'In the end, team A has five goals, but team B has only one.',
 'So the one real difference between the two teams is their ______.'],
 ch={0: 'field', 1: 'passing', 2: 'ball', 3: 'minutes', 4: 'speed'})
