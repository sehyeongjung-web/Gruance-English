# -*- coding: utf-8 -*-
# 31번(빈칸) 레벨2 앞 절반 영어 원고 (345번). I[n] = dict(S=[네 문장 — 빈칸은 넷째 문장], ch={자리: 바꾼 선택지})
# 레벨2 꼴: 네 문장·50낱말쯤·문장당 10~15낱말 · and·but·so·or로 단문을 이음(종속절·관계사절·명사절·분사 없음)
#   첫 문장 = 하는 일 / 둘째 = 그 모습 / 셋째 = 단서(정답을 조금 다른 말로 바꾸어 말함) / 넷째 = 빈칸 문장
I = {}
I[0] = dict(S=[
 "Yeast is a tiny living thing, and it lives inside bread dough.",
 "It eats the sugar in the dough, and it makes many small bubbles.",
 "The bubbles are light and airy, and they slowly push the dough up.",
 "Flour and water alone make a flat paste, but yeast adds ______ to it."],
 ch={1: 'sugar'})
I[1] = dict(S=[
 "A steel boat is very heavy, but it floats on the sea.",
 "A solid steel block with the same weight sinks to the bottom at once.",
 "The boat is wide and empty inside, so it pushes a lot of water aside.",
 "So for floating, the ______ of the boat's body is the most important thing."],
 ch={3: 'age'})
I[2] = dict(S=[
 "Sound is a kind of shaking, and it needs something to carry it along.",
 "Air, water and walls can all do this job well.",
 "Space is empty, so there is nothing there to carry a shaking.",
 "In space, a sound has no ______ to travel through, so it cannot be heard."])
I[3] = dict(S=[
 "Your shadow is long in the early morning, but short at noon.",
 "The sun itself keeps its colour and brightness, and it does not come nearer.",
 "In the morning it sits low in the sky, but at noon it stands high.",
 "So only the ______ of the sun changes the shadow."])
I[4] = dict(S=[
 "Ice floats on water, and a big iceberg floats on the sea like a boat.",
 "A block of ice weighs less than a block of water of the same size.",
 "Ice is made of water too, but it takes up more room.",
 "So size for size, ice is ______ than the water around it."],
 ch={0: 'darker', 1: 'lighter', 2: 'wetter', 3: 'heavier', 4: 'smaller'})
I[5] = dict(S=[
 "A magnet has two ends, a north end and a south end.",
 "Cut the magnet in half, and you get two smaller magnets.",
 "Each new piece has both ends too, just like the first big magnet.",
 "You can keep cutting, and each piece has the ______ two ends."])
I[6] = dict(S=[
 "Leaves look green in summer, and the green comes from a material inside them.",
 "In autumn this green material breaks down and slowly goes away.",
 "Then yellow and red begin to show up in the leaves of the tree.",
 "The tree is the same as before, but now we see other ______ in it."])
I[7] = dict(S=[
 "A thermos bottle has two walls, and the space between them has no air.",
 "Heat cannot move well through empty space, so it stays inside the drink.",
 "A hot drink in a thermos stays hot for many hours.",
 "In a thermos, a hot drink loses its warmth very ______."])
I[8] = dict(S=[
 "Plain water turns to ice at zero degrees, but salty water needs a lower temperature.",
 "People put salt on icy roads, and the ice melts.",
 "The salt does not warm the road, and the weather stays just as cold.",
 "Salt only changes the freezing ______ of the water on the road."])
I[9] = dict(S=[
 "A candle burns well in an open room, but it goes out under a jar.",
 "The flame needs one special gas from the air to keep burning.",
 "The jar holds little air, so there is soon too little of this gas.",
 "So under the jar, the flame cannot get enough ______."])
I[10] = dict(S=[
 "Bats hunt at night, and complete darkness is no problem for them.",
 "A bat shouts, and the shout hits an insect and bounces back.",
 "The bat listens carefully, and soon it finds the insect in the dark.",
 "In short, the bat hears an ______ from the insect and finds its food."])
I[11] = dict(S=[
 "A pencil in a glass of water looks bent at the surface.",
 "The pencil is straight, but light moves more slowly in water than in air.",
 "At the surface the light turns a little to one side.",
 "So the light changes its ______ there, and the pencil looks bent."])
I[12] = dict(S=[
 "A plant on a window sill slowly turns its leaves toward the light.",
 "The cells on the dark side of the stem grow longer than the other cells.",
 "This makes the stem bend, but no part of it moves back and forth.",
 "So the plant turns toward the light by growing and not by ______."],
 ch={0: 'swinging', 3: 'bending'})
I[13] = dict(S=[
 "Tighten the skin of a drum, and the sound gets higher, but not louder.",
 "A tight skin shakes fast, but a loose skin shakes slowly.",
 "Fast shaking makes a high sound, and slow shaking makes a low sound.",
 "So the speed of the shaking decides the ______ of the sound."],
 ch={3: 'weight'})
I[14] = dict(S=[
 "Iron turns to rust slowly, and it needs two things: air and water.",
 "A tool in a dry room has plenty of air, but it does not rust.",
 "The dry room gives the iron only one of the two things.",
 "So in the dry room, the second thing, water, is ______."])
