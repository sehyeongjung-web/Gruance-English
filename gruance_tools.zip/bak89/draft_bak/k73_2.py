# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 한글 (d73.py I[5]~I[9]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[5] = dict(
 ko="미라의 부모님은 집에서 화면 보는 시간에 대해 엄격한 규칙을 가지고 있다. 학교 가기 전날 밤에는, 부모님은 숙제 후에 그녀가 TV 프로그램 하나를 보게 해 준다. 금요일 밤에는, 부모님은 그녀가 열 시까지 컴퓨터 게임을 하게 해 준다. 그래서 학교 가기 전날 밤 숙제 후에, 그녀의 부모님은 그녀에게 오직 ______만 하게 해 준다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So after homework on school nights, her parents only let her»(그래서 학교 가기 전날 밤 숙제 후에, 그녀의 부모님은 그녀에게 오직 …만 하게 해 준다) 뒤가 비어 있어요. 오직 무엇만 하게 해 주는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On school nights, they let her watch one TV show after homework.»(학교 가기 전날 밤에는, 부모님은 숙제 후에 그녀가 TV 프로그램 하나를 보게 해 준다.) 'watch one TV show'(TV 프로그램 하나 보기)가 그대로 나와요.",
 "3) 확인: 셋째 문장 «On Friday nights, they let her play computer games until ten o'clock.»(금요일 밤에는, 부모님은 그녀가 열 시까지 컴퓨터 게임을 하게 해 준다.) 'play computer games'(컴퓨터 게임 하기)는 'Friday nights'(금요일 밤)의 이야기예요. 넷째 문장의 'only'(오직)는 둘째 문장의 것 하나만 남겨요.",
 "4) 묶기: 학교 가기 전날 밤 숙제 후에 하게 해 주는 것 = 'watch one TV show'(TV 프로그램 하나 보기)."],
 traps="「컴퓨터 게임 하기」가 끌릴 수 있어요. 셋째 문장에 'play computer games'(컴퓨터 게임 하기)가 그대로 나오고, 빈칸 문장만 보면 자연스럽거든요. 하지만 셋째 문장은 'Friday nights'(금요일 밤)의 이야기예요. 「긴 영화 한 편 보기」도 'watch'(보기)가 같아서 끌리지만, 둘째 문장에서 보게 해 주는 것은 'one TV show'(TV 프로그램 하나)이고, 넷째 문장의 'only'(오직)가 그것 하나만 남겨요.",
 cn=[("휴대폰 가지고 놀기", "휴대폰 가지고 놀기는 글에 나오지 않아요. 둘째 문장에서 학교 가기 전날 밤 숙제 후에 부모님이 하게 해 주는 것은 'watch one TV show'(TV 프로그램 하나 보기)이고, 넷째 문장의 'only'(오직)가 그것 하나만 남겨요."),
     ("TV 프로그램 하나 보기", "둘째 문장 «On school nights, they let her watch one TV show after homework.»이 근거예요. 학교 가기 전날 밤 숙제 후에 부모님이 하게 해 주는 일로 둘째 문장이 말하는 것은 TV 프로그램 하나 보기이니, 넷째 문장의 'only'(오직) 뒤에 들어갈 것도 이것이에요."),
     ("긴 영화 한 편 보기", "긴 영화 보기는 글에 나오지 않아요. 'watch'(보기)는 같지만, 둘째 문장에서 학교 가기 전날 밤에 보게 해 주는 것은 'one TV show'(TV 프로그램 하나)이고, 넷째 문장의 'only'(오직)가 그것만 남겨요."),
     ("컴퓨터 게임 하기", "셋째 문장 «On Friday nights, they let her play computer games until ten o'clock.»에서 컴퓨터 게임은 금요일 밤의 이야기예요. 학교 가기 전날 밤 숙제 후의 이야기는 둘째 문장의 'watch one TV show'(TV 프로그램 하나 보기)예요."),
     ("새 태블릿 쓰기", "새 태블릿 쓰기는 글에 나오지 않아요. 둘째 문장에서 학교 가기 전날 밤 숙제 후에 하게 해 주는 것은 'watch one TV show'(TV 프로그램 하나 보기)이고, 넷째 문장의 'only'(오직)가 그것 하나만 남겨요.")])
K[6] = dict(
 ko="준호네 가족은 모두 매주 집에서 작은 일을 하나씩 맡고 있다. 준호는 목요일 밤에 온 가족을 위해 쓰레기를 내다 버린다. 그의 누나 은지는 토요일 아침에 빨래를 한다. 그래서 매주, 준호는 가족의 쓰레기를 ______ 내다 버린다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every week, Junho takes out the family's trash»(그래서 매주, 준호는 가족의 쓰레기를 … 내다 버린다) 뒤가 비어 있어요. 준호가 언제 가족의 쓰레기를 내다 버리는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Junho takes out the trash for the whole family on Thursday nights.»(준호는 목요일 밤에 온 가족을 위해 쓰레기를 내다 버린다.) 'on Thursday nights'(목요일 밤에)가 그대로 나와요. 빈칸 문장과 같은 준호의 쓰레기 버리기 이야기이니, 그때는 'on Thursday nights'(목요일 밤에)예요.",
 "3) 확인: 셋째 문장 «His older sister Eunji does the laundry on Saturday mornings.»(그의 누나 은지는 토요일 아침에 빨래를 한다.) 'on Saturday mornings'(토요일 아침에)도 때를 나타내는 구로 나와요. 하지만 이것은 누나 은지가 'the laundry'(빨래)를 하는 때예요. 쓰레기를 내다 버리는 사람이 준호이고 그때가 목요일 밤이라는 것은 둘째 문장이 말해요.",
 "4) 묶기: 준호가 매주 가족의 쓰레기를 내다 버리는 때 = 'on Thursday nights'(목요일 밤에)."],
 traps="「토요일 아침에」가 끌릴 수 있어요. 셋째 문장에 'on Saturday mornings'(토요일 아침에)가 그대로 나오고, 빈칸 문장만 보면 어느 때든 들어갈 수 있거든요. 하지만 셋째 문장은 누나 은지가 빨래를 하는 때를 말해요. 준호의 쓰레기 이야기가 아니에요. 준호가 온 가족을 위해 쓰레기를 내다 버리는 때는 둘째 문장의 'on Thursday nights'(목요일 밤에)예요.",
 cn=[("목요일 밤에", "둘째 문장 «Junho takes out the trash for the whole family on Thursday nights.»이 근거예요. 준호가 온 가족을 위해 쓰레기를 내다 버리는 때가 목요일 밤이니, 준호는 매주 목요일 밤에 가족의 쓰레기를 내다 버려요."),
     ("토요일 아침에", "셋째 문장 «His older sister Eunji does the laundry on Saturday mornings.»에서 토요일 아침은 누나 은지가 빨래를 하는 때예요. 준호가 쓰레기를 내다 버리는 때는 둘째 문장의 'on Thursday nights'(목요일 밤에)예요."),
     ("월요일 아침에", "월요일 아침은 글에 나오지 않아요. 둘째 문장에서 준호가 쓰레기를 내다 버리는 때는 'on Thursday nights'(목요일 밤에)예요."),
     ("일요일 저녁에", "일요일 저녁은 글에 나오지 않아요. 둘째 문장은 준호가 'Thursday nights'(목요일 밤)에 쓰레기를 내다 버린다고 하고, 셋째 문장의 토요일 아침은 누나의 빨래 이야기예요."),
     ("금요일 오후에", "금요일 오후는 글에 나오지 않아요. 둘째 문장의 'takes out the trash'(쓰레기를 내다 버린다)는 'on Thursday nights'(목요일 밤에) 하는 일이에요.")])
K[7] = dict(
 ko="매년 봄, 윤 할아버지는 자기 집에 토마토와 고추를 심는다. 그는 평평한 지붕 위의 큰 화분에서 토마토를 기른다. 그는 고추를 뒷문 옆의 긴 상자에 둔다. 그래서 매년 여름, 윤 할아버지는 ______ 신선한 빨간 토마토를 딴다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every summer, Grandpa Yoon picks fresh red tomatoes»(그래서 매년 여름, 윤 할아버지는 … 신선한 빨간 토마토를 딴다) 뒤가 비어 있어요. 윤 할아버지가 토마토를 어디에서 따는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «He grows the tomatoes in big pots on the flat roof.»(그는 평평한 지붕 위의 큰 화분에서 토마토를 기른다.) 'on the flat roof'(평평한 지붕 위에서)가 그대로 나와요. 토마토를 기르는 곳이 평평한 지붕 위이니, 여름에 토마토를 따는 곳도 'on the flat roof'(평평한 지붕 위에서)예요.",
 "3) 확인: 셋째 문장 «He keeps the peppers in a long box by the back door.»(그는 고추를 뒷문 옆의 긴 상자에 둔다.) 'by the back door'(뒷문 옆에서)도 곳을 나타내는 구로 나와요. 하지만 뒷문 옆의 긴 상자에 두는 것은 'the peppers'(고추)예요. 토마토를 기르는 곳은 둘째 문장의 평평한 지붕 위예요.",
 "4) 묶기: 윤 할아버지가 토마토를 따는 곳 = 'on the flat roof'(평평한 지붕 위에서)."],
 traps="「뒷문 옆에서」가 끌릴 수 있어요. 셋째 문장에 'by the back door'(뒷문 옆에서)가 그대로 나오고, 빈칸 문장만 보면 어느 곳이든 들어갈 수 있거든요. 하지만 셋째 문장에서 뒷문 옆의 긴 상자에 두는 것은 고추이고, 토마토가 아니에요. 둘째 문장에서 'the tomatoes'(토마토)를 기르는 곳은 'on the flat roof'(평평한 지붕 위)예요.",
 cn=[("앞마당에서", "앞마당은 글에 나오지 않아요. 둘째 문장에서 토마토를 기르는 곳은 'on the flat roof'(평평한 지붕 위)이고, 셋째 문장의 뒷문 옆은 고추를 두는 곳이에요."),
     ("뒷문 옆에서", "셋째 문장 «He keeps the peppers in a long box by the back door.»에서 뒷문 옆의 긴 상자에 두는 것은 고추예요. 토마토는 둘째 문장에서 평평한 지붕 위의 큰 화분에서 길러요."),
     ("평평한 지붕 위에서", "둘째 문장 «He grows the tomatoes in big pots on the flat roof.»이 근거예요. 윤 할아버지가 토마토를 기르는 곳이 평평한 지붕 위이니, 여름에 신선한 빨간 토마토를 따는 곳도 평평한 지붕 위예요."),
     ("차고 뒤에서", "차고 뒤는 글에 나오지 않아요. 둘째 문장에서 'the tomatoes'(토마토)를 기르는 곳은 평평한 지붕 위의 'big pots'(큰 화분)예요."),
     ("대문 옆에서", "대문 옆은 글에 나오지 않아요. 글에 나오는 문은 셋째 문장의 'the back door'(뒷문)인데, 그 옆의 긴 상자에 두는 것은 고추예요. 토마토는 둘째 문장에서 'on the flat roof'(평평한 지붕 위)에서 길러요.")])
K[8] = dict(
 ko="한 달에 한 번, 태양이네 가족은 작은 마을에 사시는 할머니를 찾아간다. 여름철에는, 가족은 아빠의 낡은 차를 타고 그곳에 간다. 겨울에는, 가족은 그 대신 느린 기차를 타고 그곳에 간다. 그래서 겨울에, 태양이네 가족은 ______ 할머니가 사시는 마을로 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So in winter, Taeyang's family travels to Grandma's town»(그래서 겨울에, 태양이네 가족은 … 할머니가 사시는 마을로 간다) 뒤가 비어 있어요. 겨울에 가족이 무엇을 타고 할머니가 사시는 마을로 가는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «In winter, the family rides there on the slow train instead.»(겨울에는, 가족은 그 대신 느린 기차를 타고 그곳에 간다.) 'on the slow train'(느린 기차를 타고)이 그대로 나와요. 빈칸 문장과 같은 'winter'(겨울)의 이야기이니, 겨울에 가족이 가는 방법은 이것이에요.",
 "3) 확인: 둘째 문장 «In the summer months, they drive there in Dad's old car.»(여름철에는, 가족은 아빠의 낡은 차를 타고 그곳에 간다.) 아빠의 낡은 차는 'summer months'(여름철)의 이야기예요. 겨울에는 그다음 셋째 문장처럼 'instead'(그 대신) 느린 기차를 타요.",
 "4) 묶기: 겨울에 할머니가 사시는 마을로 가는 방법 = 'on the slow train'(느린 기차를 타고)."],
 traps="「아빠의 낡은 차를 타고」가 끌릴 수 있어요. 둘째 문장에 «in Dad's old car»(아빠의 낡은 차를 타고)가 그대로 나오고, 빈칸 문장만 보면 차를 타고 간다는 말도 자연스럽거든요. 하지만 둘째 문장은 'summer months'(여름철)의 이야기예요. 셋째 문장은 'In winter'(겨울에는) 가족이 'instead'(그 대신) 'on the slow train'(느린 기차를 타고) 간다고 해요.",
 cn=[("아빠의 낡은 차를 타고", "둘째 문장 «In the summer months, they drive there in Dad's old car.»에서 아빠의 낡은 차를 타고 가는 것은 여름철의 이야기예요. 셋째 문장에서 겨울에는 그 대신 느린 기차를 타요."),
     ("빌린 차를 타고", "빌린 차는 글에 나오지 않아요. 글에 나오는 차는 둘째 문장에서 여름철에 타는 아빠의 낡은 차이고, 셋째 문장에서 겨울에는 'on the slow train'(느린 기차를 타고) 가요."),
     ("고속버스를 타고", "고속버스는 글에 나오지 않아요. 셋째 문장에서 겨울에 가족이 타고 가는 것은 버스가 아니라 'the slow train'(느린 기차)이에요."),
     ("느린 기차를 타고", "셋째 문장 «In winter, the family rides there on the slow train instead.»이 근거예요. 겨울에는 가족이 그 대신 느린 기차를 타고 할머니가 사시는 마을에 가요."),
     ("삼촌의 트럭을 타고", "삼촌의 트럭은 글에 나오지 않아요. 둘째 문장에서 여름철에 타는 것은 아빠의 낡은 차이고, 셋째 문장에서 겨울에 타는 것은 'the slow train'(느린 기차)이에요.")])
K[9] = dict(
 ko="예지는 매일 아침 일곱 시 반에 학교에 도착한다. 그녀의 반에서 많은 남자아이들이 탁구를 치려고 일찍 온다. 예지는 자기의 조용한 책상에서 영어 단어를 공부하려고 일찍 온다. 그래서 매일 아침, 예지는 ______ 학교에 일찍 도착한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every morning, Yeji arrives at her school early»(그래서 매일 아침, 예지는 … 학교에 일찍 도착한다) 뒤가 비어 있어요. 예지가 무엇을 하려고 학교에 일찍 도착하는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Yeji comes early to study English words at her quiet desk.»(예지는 자기의 조용한 책상에서 영어 단어를 공부하려고 일찍 온다.) 'to study English words'(영어 단어를 공부하려고)가 그대로 나와요. 예지가 무엇을 하려고 일찍 오는지 말하는 문장이에요.",
 "3) 확인: 둘째 문장 «Many boys in her class come early to play table tennis.»(그녀의 반에서 많은 남자아이들이 탁구를 치려고 일찍 온다.) 'to play table tennis'(탁구를 치려고)도 'come early'(일찍 온다) 뒤에 나와요. 하지만 이것은 'Many boys'(많은 남자아이들)가 일찍 오는 까닭이에요. 예지가 일찍 오는 까닭은 그다음 셋째 문장의 영어 단어 공부예요.",
 "4) 묶기: 예지가 매일 아침 학교에 일찍 도착하는 까닭 = 'to study English words'(영어 단어를 공부하려고)."],
 traps="「탁구를 치려고」가 끌릴 수 있어요. 둘째 문장에 'to play table tennis'(탁구를 치려고)가 그대로 나오고, 빈칸 문장만 보면 탁구를 치려고 일찍 온다는 말도 자연스럽거든요. 하지만 둘째 문장에서 탁구를 치려고 일찍 오는 것은 예지 반의 'Many boys'(많은 남자아이들)예요. 셋째 문장은 예지가 'to study English words'(영어 단어를 공부하려고) 일찍 온다고 해요.",
 cn=[("아침을 빨리 먹으려고", "아침을 먹는 이야기는 글에 나오지 않아요. 셋째 문장에서 예지는 'to study English words'(영어 단어를 공부하려고) 일찍 와요."),
     ("탁구를 치려고", "둘째 문장 «Many boys in her class come early to play table tennis.»에서 탁구를 치려고 일찍 오는 것은 반의 많은 남자아이들이에요. 예지가 일찍 오는 까닭은 셋째 문장의 영어 단어 공부예요."),
     ("교실을 청소하려고", "교실 청소는 글에 나오지 않아요. 셋째 문장에서 예지는 'at her quiet desk'(자기의 조용한 책상에서) 영어 단어를 공부하려고 일찍 와요."),
     ("영어 단어를 공부하려고", "셋째 문장 «Yeji comes early to study English words at her quiet desk.»이 근거예요. 예지가 일찍 오는 까닭이 영어 단어 공부이니, 예지는 매일 아침 영어 단어를 공부하려고 학교에 일찍 도착해요."),
     ("친구들과 이야기하려고", "친구들과 이야기하는 것은 글에 나오지 않아요. 셋째 문장에서 예지는 'her quiet desk'(자기의 조용한 책상)에서 영어 단어를 공부하려고 일찍 와요.")])
