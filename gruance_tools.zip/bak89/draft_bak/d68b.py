# -*- coding: utf-8 -*-
# 32번(빈칸) 레벨2 뒤 절반 영어 원고 (348번). 꼴은 d68a.py와 같음
I = {}
I[15] = dict(S=[
 "Geese fly far south in a V shape, with one bird at the front.",
 "The front bird pushes through the air, and its wings work very hard.",
 "The birds behind find the air easier, and they can rest their wings a little.",
 "So the front bird gets ______ first, and another bird takes its place."],
 ch={0: 'lost', 1: 'afraid', 2: 'tired', 3: 'happy', 4: 'angry'})
I[16] = dict(S=[
 "A seed can sleep for years in a dry paper bag.",
 "The bag is full of air, but the seed gets nothing wet.",
 "Put the seed in wet, warm soil, and it wakes up and starts to grow.",
 "So the seed in the bag has no ______, and it stays asleep."],
 ch={0: 'water', 1: 'light', 2: 'sound', 3: 'air', 4: 'time'})
I[17] = dict(S=[
 "Fresh bread is soft, but in a few days it loses its softness.",
 "Many people put bread in the fridge to keep it fresh.",
 "But the cold air in the fridge makes this change happen faster.",
 "So bread in the fridge becomes ______ sooner than bread on the table."],
 ch={0: 'hard', 1: 'soft', 2: 'wet', 3: 'fresh', 4: 'warm'})
I[18] = dict(S=[
 "A wet cloth on your arm feels nice on a hot day.",
 "The water in the cloth slowly goes into the air around it.",
 "To leave, the water takes some heat from your skin.",
 "The water leaves, and your skin loses heat and feels ______ for a while."],
 ch={0: 'warmer', 1: 'softer', 2: 'cooler', 3: 'heavier', 4: 'dirtier'})
I[19] = dict(S=[
 "A whale sings a low song deep under the sea.",
 "Water is very hard to squeeze, but air is easy to squeeze.",
 "A push on one part of water reaches the next part almost at once.",
 "So the song of a whale moves ______ through water than through air."],
 ch={0: 'softer', 1: 'slower', 2: 'lower', 3: 'later', 4: 'faster'})
I[20] = dict(S=[
 "A spider walks across its web every day without any trouble.",
 "Some threads of the web are sticky, and they catch insects.",
 "Other threads have no glue on them, and the spider walks mostly on those.",
 "So the spider stays ______ on its own web, but an insect gets stuck."],
 ch={0: 'wet', 1: 'heavy', 2: 'lost', 3: 'safe', 4: 'sticky'})
I[21] = dict(S=[
 "A baby tortoise has a small shell, and an old tortoise has a big one.",
 "The tortoise never leaves its shell to find a new one.",
 "The shell stays on the tortoise for life, and they get bigger together.",
 "So the shell ______ with the tortoise, and it is a part of the body."],
 ch={0: 'shrinks', 1: 'breaks', 2: 'falls', 3: 'dries', 4: 'grows'})
I[22] = dict(S=[
 "A fresh egg lies on the bottom of a glass of water.",
 "An older egg stands on one end at the bottom.",
 "Day after day, the shell lets a little air in and a little water out.",
 "The egg gets lighter inside, so in water a very old egg ______."],
 ch={0: 'sinks', 1: 'melts', 2: 'drops', 3: 'breaks', 4: 'floats'})
I[23] = dict(S=[
 "A compass needle points to magnetic north, not to the true north pole.",
 "The magnetic point is not fixed, and it moves every year.",
 "So the gap between the two norths changes from year to year.",
 "Therefore the gap shown on an old map is often ______ today."],
 ch={0: 'correct', 1: 'early', 2: 'wrong', 3: 'exact', 4: 'new'})
I[24] = dict(S=[
 "Grease and water stay apart, like oil and water in a glass.",
 "One end of each soap part holds grease, and the other end holds water.",
 "So soap grabs grease with one end and water with the other end.",
 "Soap lets grease and water ______ a little, and the plate comes clean."],
 ch={0: 'split', 1: 'mix', 2: 'burn', 3: 'cool', 4: 'sink'})
I[25] = dict(S=[
 "A simple kite with no tail often spins in the wind and may fall.",
 "A long tail of cloth hangs below the kite and moves in the wind.",
 "The tail holds the kite in one direction, so it does not easily turn over.",
 "So the tail keeps the kite ______ in the air."],
 ch={0: 'wild', 1: 'loose', 2: 'steady', 3: 'dizzy', 4: 'noisy'})
I[26] = dict(S=[
 "Some moths may use the moon to fly in a straight line.",
 "The moon is far away, so its light comes at almost one angle.",
 "A lamp is near, so its light comes at a new angle all the time.",
 "So near a lamp, the moth keeps turning one way and flies in a ______."],
 ch={0: 'line', 1: 'zigzag', 2: 'row', 3: 'circle', 4: 'triangle'})
I[27] = dict(S=[
 "Sound is a shaking, and it moves from place to place.",
 "Air, water and walls can all pass the shaking along from part to part.",
 "Space has almost nothing in it, so the shaking soon stops there.",
 "Space has almost nothing to ______ a sound, so no one can hear it."],
 ch={0: 'hide', 1: 'cut', 2: 'bend', 3: 'carry', 4: 'stop'})
I[28] = dict(S=[
 "At noon, the sun is high in the sky, and your shadow is short.",
 "Then the sun moves across the sky and slowly gets lower.",
 "A low sun sends its light across the ground at a flat angle.",
 "So late in the day, your shadow on the ground grows ______."],
 ch={0: 'longer', 1: 'shorter', 2: 'darker', 3: 'wider', 4: 'thinner'})
I[29] = dict(S=[
 "Ice takes up more room than water, and it can tear a plant cell.",
 "On a cold night, some plants move water out of their cells.",
 "The water now sits in the gaps around the cells, and the ice grows there.",
 "So the ice forms ______ the cells, and the cells stay whole."],
 ch={0: 'inside', 1: 'under', 2: 'outside', 3: 'above', 4: 'through'})
