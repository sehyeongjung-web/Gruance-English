# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 다시 쓰기 · 문항 0~9. 네 문장 · 단문 · 정답 구가 첫 세 문장에 그대로 · 빈칸 문장만으로는 정해지지 않는 꼴
I = {}
# 0 때 전치사구 · 반려동물(토끼 상자 청소)
I[0] = dict(S=['Jisu keeps a small brown rabbit in a big box in her room.',
 'On school days, she cleans the box after her dinner.',
 'On Saturdays, she cleans it after breakfast with help from her dad.',
 "So on school days, Jisu cleans her rabbit's box ______."],
 ch={0: 'before her bedtime', 1: 'after breakfast', 2: 'after her dinner', 3: 'after her bath', 4: 'before her homework'})
# 1 장소 전치사구 · 음악(드럼 연습)
I[1] = dict(S=['Daeho plays the drums in a small band with three friends.',
 'On weekday evenings, he practices alone in the music room at school.',
 "On Sunday afternoons, the whole band practices in his uncle's garage.",
 'So on weekday evenings, Daeho usually plays his drums ______.'],
 ch={0: 'in the music room', 1: "in his uncle's garage", 2: 'in his small bedroom', 3: 'in the church hall', 4: 'in the living room'})
# 2 함께하는 사람 전치사구 · 운동(배드민턴)
I[2] = dict(S=['Sena plays badminton for about an hour every Sunday morning.',
 'From spring to fall, she plays at the park with her best friend Ara.',
 'In winter, she plays in the school gym with her grandfather.',
 'So from spring to fall, Sena plays badminton every Sunday ______.'],
 ch={0: 'with her grandfather', 1: 'with her little sister', 2: 'with her best friend', 3: 'with her school coach', 4: 'with her older cousin'})
# 3 목적 to부정사구 · 시장(엄마와 장보기)
I[3] = dict(S=['Every Saturday morning, Yuna walks to the market with her mom.',
 'Her mom goes there every week to buy some fresh fish.',
 'Yuna goes along to get warm rice cakes at a small shop.',
 'So every Saturday morning, Yuna goes to the market ______.'],
 ch={0: 'to buy some fresh fish', 1: 'to get warm rice cakes', 2: 'to meet her school friends', 3: 'to sell her old toys', 4: 'to visit her grandma'})
# 4 -ing구 · 학교 취미(빈 시간에 만화 그리기)
I[4] = dict(S=['Every Wednesday, Siwoo has a free hour after his last class.',
 'On sunny Wednesdays, he plays soccer outside with his classmates.',
 'On rainy Wednesdays, he stays in the art room and draws funny pictures.',
 'So on rainy Wednesdays, Siwoo usually spends his free hour ______.'],
 ch={0: 'reading comic books', 1: 'playing soccer outside', 2: 'doing his math homework', 3: 'drawing funny pictures', 4: 'practicing the piano'})
# 5 동사구(can 뒤 원형) · 가족 규칙(TV와 게임)
I[5] = dict(S=["Hana's parents have a simple rule for TV and games at home.",
 'On school nights, she can watch one TV show after her homework.',
 "On Friday nights, she can play computer games until ten o'clock.",
 'So after her homework on school nights, Hana can ______.'],
 ch={0: 'read a comic book', 1: 'watch one TV show', 2: 'eat some ice cream', 3: 'play computer games', 4: 'call her best friend'})
# 6 때 전치사구 · 집안일(쓰레기 내놓기)
I[6] = dict(S=["Everyone in Junho's family has a small job at home each week.",
 'Junho takes out the trash for the whole family on Thursday nights.',
 'His older sister Eunji does the laundry on Saturday mornings.',
 "So every week, Junho takes out the family's trash ______."],
 ch={0: 'on Thursday nights', 1: 'on Saturday mornings', 2: 'on Monday mornings', 3: 'on Sunday evenings', 4: 'on Friday afternoons'})
# 7 장소 전치사구 · 정원(옥상 토마토)
I[7] = dict(S=['Every spring, Grandpa Yoon plants tomatoes and peppers at his house.',
 'He grows the tomatoes in big pots on the flat roof.',
 'He keeps the peppers in a long box by the back door.',
 'So every summer, Grandpa Yoon picks fresh red tomatoes ______.'],
 ch={0: 'in the front yard', 1: 'by the back door', 2: 'on the flat roof', 3: 'behind the garage', 4: 'next to the gate'})
# 8 수단 전치사구 · 가족 여행(할머니 댁 가기)
I[8] = dict(S=["Once a month, Taeyang's family visits Grandma in a small town.",
 "In the summer months, they drive there in Dad's old car.",
 'In winter, the family rides there on the slow train instead.',
 "So in winter, Taeyang's family travels to Grandma's town ______."],
 ch={0: "in Dad's old car", 1: 'in a rental car', 2: 'on the express bus', 3: 'on the slow train', 4: "in Uncle's truck"})
# 9 목적 to부정사구 · 학교(일찍 등교해 공부)
I[9] = dict(S=['Yeji gets to school at half past seven every morning.',
 'Many boys in her class come early to play table tennis.',
 'Yeji comes early to study English words at her quiet desk.',
 'So every morning, Yeji arrives at her school early ______.'],
 ch={0: 'to eat a quick breakfast', 1: 'to play table tennis', 2: 'to clean the classroom', 3: 'to study English words', 4: 'to talk with her friends'})
