I = {}
I[0] = dict(S=['Dan could not find his gym shoes before class on Monday.',
 'He looked in his bag, under his bed and behind the door.',
 'At last his sister found the shoes in the garden.',
 'So the shoes had been in the ______ for the whole weekend.'],
 ch={0:'garden',1:'bag',2:'bed',3:'door',4:'closet'})
I[1] = dict(S=['Mia lost her key on the way home from school.',
 'A kind boy on the bus picked it up from the floor.',
 'He gave the key to the bus driver at the next stop.',
 'So Mia got her key back from the ______ the next day.'],
 ch={0:'teacher',1:'boy',2:'mother',3:'neighbor',4:'driver'})
I[2] = dict(S=['Lena kept her bike outside in the rain for a week.',
 'The metal chain turned brown and made a loud sound.',
 'Her father looked at the chain and found a lot of rust.',
 'So the real problem with Lena\'s bike was ______ on the chain.'],
 ch={0:'dust',1:'mud',2:'oil',3:'rust',4:'paint'})
