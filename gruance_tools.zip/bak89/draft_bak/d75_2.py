# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨1 다시 쓰기 — 맡은 문항 n=10~19 (두 경우를 맞세우는 꼴)
I = {}
I[10] = dict(S=['Two new members, Jiho and Sena, joined the school band in March.',
 "Last year, Jiho's older sister taught him the piano at home.",
 "Last year, Sena's uncle gave her guitar lessons at his music shop.",
 'Now the two friends practice with the band every Friday after school.'],
 SM="Last year, Sena's (A) ______ taught her to play the (B) ______.",
 ch={0:'uncle - guitar',1:'sister - guitar',2:'uncle - piano',3:'aunt - piano',4:'sister - piano'})
I[11] = dict(S=["This spring, Doyun's family took a short camping trip to an island.",
 'Every day, his father cooked potatoes over the fire for lunch.',
 'Every night, his mother cooked chicken over the fire for dinner.',
 'Doyun carried water and wood to the fire for both of them.'],
 SM="On the island, Doyun's father made (A) ______ for (B) ______ each day.",
 ch={0:'chicken - lunch',1:'potatoes - dinner',2:'eggs - dinner',3:'potatoes - lunch',4:'chicken - dinner'})
I[12] = dict(S=['Every Sunday, Ara and her younger brother Juno fold the clean clothes.',
 'Ara folds the shirts on the big table in the kitchen.',
 'Juno folds the jackets on his bed in his own room.',
 'Their mother thanks them with a big bowl of ice cream.'],
 SM="On Sundays, Ara's younger brother folds the (A) ______ on the (B) ______.",
 ch={0:'shirts - bed',1:'jackets - table',2:'sheets - table',3:'shirts - table',4:'jackets - bed'})
I[13] = dict(S=["Last Saturday, Yejun's family spent the whole day at the city aquarium.",
 'A worker fed the sharks at eleven on the second floor.',
 'Another worker fed the penguins at three on the first floor.',
 'Yejun took many photos of the animals with his new phone.'],
 SM='At the aquarium, the penguins got their food at (A) ______ on the (B) ______ floor.',
 ch={0:'eleven - first',1:'four - second',2:'three - second',3:'eleven - second',4:'three - first'})
I[14] = dict(S=["Every year, Jiun's class takes two bus trips to the city museum.",
 'In April, a museum guide teaches them about old maps.',
 'In October, their own teacher tells them about old coins.',
 'After each trip, the students write a short report in class.'],
 SM="On the April trip, Jiun's class learns about old (A) ______ from a (B) ______.",
 ch={0:'coins - teacher',1:'maps - teacher',2:'ships - teacher',3:'maps - guide',4:'coins - guide'})
I[15] = dict(S=["Every winter, Siwon's grandma knits warm things for her two grandchildren.",
 'This year, she knitted a soft brown hat for her grandson Siwon.',
 'She also knitted a red coat for his little cousin Yerin.',
 'Both children wear the warm gifts on cold mornings in January.'],
 SM="This year, Siwon's cousin got a (A) ______ (B) ______ from their grandma.",
 ch={0:'brown - hat',1:'red - hat',2:'red - coat',3:'green - hat',4:'brown - coat'})
I[16] = dict(S=["Next month, Hyerin's class will put on a short play for their parents.",
 'On stage, Hyerin will play a farmer with a small cup in her hand.',
 'Her best friend Taeyun will play a king with a little bell.',
 'The whole class practices the play in the music room after lunch.'],
 SM='In the play for the parents, Taeyun will be a (A) ______ with a (B) ______.',
 ch={0:'farmer - bell',1:'doctor - cup',2:'king - bell',3:'farmer - cup',4:'king - cup'})
I[17] = dict(S=['Every summer, Jiwoo sells lemonade at a small stand on weekends.',
 'On Saturdays, she sells twenty cups near the station with her dad.',
 'On Sundays, she sells fifteen cups near the library with her mom.',
 'Jiwoo saves her share of the money for a new bike.'],
 SM='Near the (A) ______, Jiwoo and her mom sell (B) ______ cups of lemonade a day.',
 ch={0:'station - twenty',1:'library - twenty',2:'library - fifteen',3:'bank - twenty',4:'station - fifteen'})
I[18] = dict(S=["This summer, Minjun's cousin Dain stayed with him for a week.",
 "Every morning, the two cousins played football at the school near Minjun's house.",
 "Every evening, they played tennis in the park with Minjun's father.",
 'Dain went back home to Busan on the last Sunday of July.'],
 SM='At the school, Minjun and his cousin played (A) ______ every (B) ______.',
 ch={0:'tennis - morning',1:'football - evening',2:'cards - evening',3:'football - morning',4:'tennis - evening'})
I[19] = dict(S=["Yechan's school has a small bird club with eight members.",
 'In spring, the members take photos of birds by the river.',
 'In fall, they draw pictures of birds by the lake behind the school.',
 'At the end of the year, the club makes a small bird book.'],
 SM="In (A) ______, Yechan's bird club draws the birds by the (B) ______.",
 ch={0:'spring - lake',1:'fall - lake',2:'winter - river',3:'spring - river',4:'fall - river'})
