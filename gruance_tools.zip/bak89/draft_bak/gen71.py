# -*- coding: utf-8 -*-
# 원고(d71.I)와 한글(k71_1~6.K)을 합쳐 pending/edits_X71x.py를 만든다.  python3 draft/gen70.py a   (뒷 절반은 b)
import sys, pprint, importlib
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
D = importlib.import_module('d71')
K = {}
for _i in range(1, 7): K.update(importlib.import_module('k71_%d' % _i).K)
rng = range(0, 15) if tag == 'a' else range(15, 30)
class _D: pass
d = _D(); d.I = {n: D.I[n] for n in rng}
k = _D(); k.K = {n: K[n] for n in rng}
ns = sorted(d.I)
assert sorted(k.K) == ns, (sorted(k.K), ns)
head = '앞' if tag == 'a' else '뒤'
from lib import load
_, tb, _ = load('/home/claude/work/out/index.html')
out = ['# -*- coding: utf-8 -*-',
       '# %s번: 31번(빈칸 추론) 레벨1 %s 절반 — 네 문장 · 평균 50낱말쯤 · 문장당 10~15낱말 · 단문 · 정답 낱말이 글에 그대로 나오되 빈칸 문장만으로는 정해지지 않는 꼴(354번의 새 꼴). 정답 번호는 바탕 그대로, 지문·해석·풀이·해설을 통째로 다시 씀' % ('354' if tag == 'a' else '354', head),
       'AUTO_SYNC = False', 'E = {}',
       'from z8common import maker, _tb', "T, LV = '31', '1'", 'mk = maker(E, T, lv=LV)',
       'def rw(n, ans, text, ko, steps, traps, cn, ch=None):',
       '    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=bool(ch and ans in ch)); e = E.pop((T, LV, n))',
       "    choices = list(_tb[T][LV][n]['choices'])",
       '    for kk, vv in (ch or {}).items(): choices[kk] = vv',
       "    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(choices)) == 5, n",
       "    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,",
       "                     'rewrite': {'text': text, 'choices': choices, 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][kk] for kk in range(5)]}}", '']
for n in ns:
    I = d.I[n]; K = k.K[n]; ans = tb['31']['1'][n]['answer']
    text = ' '.join(I['S'])
    ch = I.get('ch')
    out.append('# %d번째' % (n + 1))
    out.append('rw(%d, %d,\n   %r,\n   %r,\n   %s,\n   %r,\n   %s%s)\n' % (n, ans, text, K['ko'], pprint.pformat(K['steps'], width=200), K['traps'], pprint.pformat(K['cn'], width=200), (',\n   ch=%r' % ch) if ch else ''))
open('/home/claude/work/pending/edits_X71%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X71%s.py (%d문항)' % (tag, len(ns)))
