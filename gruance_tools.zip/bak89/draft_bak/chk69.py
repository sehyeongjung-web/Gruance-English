import sys, importlib.util
sys.path.insert(0,'/home/claude/work'); sys.path.insert(0,'/home/claude/work/draft')
from lib import load
from zlevel import check_texts
_, tb, _ = load('/home/claude/Gruance-English/index.html')
p = sys.argv[1]
spec = importlib.util.spec_from_file_location('dd', p); d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
texts = {}; bad = 0
for n, it in sorted(d.I.items()):
    ch = it['ch']; assert sorted(ch.keys()) == [0,1,2,3,4], (n, 'need five choices 0..4')
    ans_pos = tb['32']['2'][n]['answer']
    a = ch[ans_pos]
    assert len(it['S']) == 4, (n, 'need 4 sentences')
    t = ' '.join(it['S']); assert t.count('______') == 1 and '______' in it['S'][3], (n, 'one blank in the 4th sentence')
    assert len(set(ch.values())) == 5, (n, 'duplicate choices')
    texts[n] = (t, a)
    print('n=%d key@%d=%s' % (n, ans_pos, a))
check_texts('32', '2', texts, 4)
