# -*- coding: utf-8 -*-
# 최종 풀이꾼·감사꾼(sheets69d) 지적 반영: d69.py 의 문장 몇 곳을 고친다.
import importlib.util, pprint, sys
spec = importlib.util.spec_from_file_location('d', '/home/claude/work/draft/d69.py'); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
I = m.I
F = {
 2:  {0: "Ice floats on water, and it stays on top of a pond."},
 5:  {1: "Bird A is an owl with soft wing feathers, and B is a pigeon.", 3: "So Kim can easily ______ bird B, but she does not notice bird A."},
 6:  {1: "Both have the same size and lid, but A has two layers around the soup.", 2: "B has only one layer, and after six hours B's soup is cooler than A's."},
 7:  {2: "Water in the air makes many drops at A, but very few at B.", 3: "So in the morning, B's grass is ______ than A's grass."},
 12: {1: "Germs need water to live, and pure honey has very little water."},
 13: {0: "Tom hits two drums, A and B, of the same size with the same force."},
 14: {1: "Dad brushes a green layer over nail A, but nail B stays bare.", 3: "So the one real difference between nail A and nail B is the ______."},
 15: {2: "The air by A's wingtip lifts B, so B can flap less."},
 18: {2: "The water slowly leaves the left cloth and carries heat away from her skin."},
 19: {2: "Both sounds start equally loud, but pot B's sound arrives a few seconds earlier."},
 20: {1: "A fly touches the first kind, and it cannot pull its legs off the thread.", 2: "The spider mostly runs on the second kind, and its feet leave the thread easily."},
 21: {1: "The tortoise still lives in Sam's garden, and it still has the same shell."},
 23: {2: "Magnetic north has moved, so the needle points a little more to the left.", 3: "So on Bell Hill, the old needle now shows a different ______."},
 26: {1: "The moth may keep the faraway moon on one side, so it flies straight."},
 29: {1: "Plant A moves water out of its cells, and the water freezes around them."},
}
for n, d in F.items():
    for i, new in d.items():
        print(n, i, '\n   OLD', I[n]['S'][i], '\n   NEW', new)
        I[n]['S'][i] = new
out = ['# -*- coding: utf-8 -*-', '# 32번(빈칸 — 낱말) 레벨2 다시 쓰기(349번 이후) 영어 원고 전체. A/B 두 조건을 세우고 빈칸 문장은 그 결과를 견주는 꼴.', '# I[n] = dict(S=[네 문장 — 빈칸은 넷째 문장], ch={0..4: 선택지})', 'I = {}']
for n in range(30):
    out.append('I[%d] = dict(S=%s,\n ch=%s)' % (n, pprint.pformat(I[n]['S'], width=120), repr(I[n]['ch'])))
open('/home/claude/work/draft/d69.py', 'w', encoding='utf-8').write('\n'.join(out) + '\n')
