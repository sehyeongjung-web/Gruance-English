# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 한글 (d73.py I[20]~I[24]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[20] = dict(
 ko="매일 저녁 식사 후에, 태수는 집 부엌에서 설거지를 한다. 주말에는, 그는 남동생 민우와 함께 이 일을 한다. 학교에 가는 날에는, 그는 누나와 함께 개수대에서 일한다. 그래서 학교에 가는 날에, 태수는 저녁 식사 그릇을 ______ 닦는다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on school days, Taesu cleans the dinner dishes»(그래서 학교에 가는 날에, 태수는 저녁 식사 그릇을 … 닦는다) 뒤가 비어 있어요. 학교에 가는 날 태수가 누구와 함께 설거지를 하는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On school days, he works at the sink with his older sister.»(학교에 가는 날에는, 그는 누나와 함께 개수대에서 일한다.) 'with his older sister'(누나와 함께)가 그대로 나와요. 빈칸 문장과 같은 'On school days'(학교에 가는 날에는)의 이야기이니, 함께 설거지하는 사람은 누나예요.",
 "3) 확인: 둘째 문장 «On weekends, he does this job with his younger brother Minu.»(주말에는, 그는 남동생 민우와 함께 이 일을 한다.) 'with his younger brother'(남동생과 함께)가 나오지만, 이것은 'On weekends'(주말에는)의 이야기예요. 학교에 가는 날은 셋째 문장의 'his older sister'(누나)예요.",
 "4) 묶기: 학교에 가는 날 태수가 설거지를 함께 하는 사람 = 'with his older sister'(누나와 함께)."],
 traps="「남동생과 함께」가 끌릴 수 있어요. 둘째 문장에 'with his younger brother'(남동생과 함께)가 그대로 나오고, 빈칸 문장만 보면 누구든 들어갈 수 있거든요. 하지만 둘째 문장은 'On weekends'(주말에는)의 이야기이고, 학교에 가는 날에 대해서는 셋째 문장이 'with his older sister'(누나와 함께)라고 해요.",
 cn=[("남동생과 함께", "둘째 문장 «On weekends, he does this job with his younger brother Minu.»에서 태수가 남동생 민우와 함께 설거지를 하는 것은 주말이에요. 셋째 문장에서 학교에 가는 날 함께 일하는 사람은 'his older sister'(누나)예요."),
     ("할머니와 함께", "할머니는 글에서 이야기하는 사람이 아니에요. 둘째 문장에서 주말에 함께하는 사람은 남동생 민우이고, 셋째 문장에서 학교에 가는 날 함께하는 사람은 'his older sister'(누나)예요."),
     ("어린 사촌과 함께", "어린 사촌은 글에서 이야기하는 사람이 아니에요. 셋째 문장 «On school days, he works at the sink with his older sister.»에서 학교에 가는 날 태수와 함께 개수대에서 일하는 사람은 누나예요."),
     ("엄마 아빠와 함께", "엄마 아빠와 함께 한다는 것은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 주말에 함께하는 사람은 'his younger brother Minu'(남동생 민우)이고, 셋째 문장에서 학교에 가는 날 함께하는 사람은 'his older sister'(누나)예요."),
     ("누나와 함께", "셋째 문장 «On school days, he works at the sink with his older sister.»이 근거예요. 학교에 가는 날에는 누나와 함께 개수대에서 일하니, 태수는 학교에 가는 날 저녁 식사 그릇을 누나와 함께 닦아요.")])
K[21] = dict(
 ko="학교에 가는 날에는, 민서는 일곱 시 반에 자기 교실에 도착한다. 그녀는 신선한 공기가 들어오게 창문을 열려고 항상 일찍 온다. 그녀의 친구 지아는 반에서 키우는 물고기에게 먹이를 주려고 여덟 시에 온다. 그래서 학교에 가는 날에, 민서는 ______ 학교에 일찍 도착한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on school days, Minseo gets to school early»(그래서 학교에 가는 날에, 민서는 … 학교에 일찍 도착한다) 뒤가 비어 있어요. 민서가 무엇을 하려고 학교에 일찍 도착하는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «She always comes early to open the windows for some fresh air.»(그녀는 신선한 공기가 들어오게 창문을 열려고 항상 일찍 온다.) 'to open the windows'(창문을 열려고)가 그대로 나와요. 'always'(항상)가 있으니, 학교에 가는 날 민서가 일찍 올 때마다 그 목적은 창문을 여는 것이에요.",
 "3) 확인: 셋째 문장 «Her friend Jia comes at eight to feed the class fish.»(그녀의 친구 지아는 반에서 키우는 물고기에게 먹이를 주려고 여덟 시에 온다.) 'to feed the class fish'(반에서 키우는 물고기에게 먹이를 주려고)가 나오지만, 이것은 친구 'Jia'(지아)가 하는 일이에요. 민서가 항상 일찍 오는 목적은 둘째 문장이 말하는 대로 창문을 여는 것이에요.",
 "4) 묶기: 민서가 학교에 일찍 도착하는 목적 = 'to open the windows'(창문을 열려고)."],
 traps="「반에서 키우는 물고기에게 먹이를 주려고」가 끌릴 수 있어요. 셋째 문장에 같은 말이 그대로 나오고, 빈칸 문장만 보면 어떤 목적이든 들어갈 수 있거든요. 하지만 셋째 문장에서 물고기에게 먹이를 주려고 오는 사람은 민서가 아니라 친구 지아예요. 민서가 항상 일찍 오는 목적은 둘째 문장의 'to open the windows'(창문을 열려고)예요.",
 cn=[("반에서 키우는 물고기에게 먹이를 주려고", "셋째 문장 «Her friend Jia comes at eight to feed the class fish.»에서 물고기에게 먹이를 주려고 오는 사람은 친구 지아예요. 민서가 항상 일찍 오는 목적은 둘째 문장의 'to open the windows'(창문을 열려고)예요."),
     ("창문을 열려고", "둘째 문장 «She always comes early to open the windows for some fresh air.»이 근거예요. 민서는 신선한 공기가 들어오게 창문을 열려고 항상 일찍 오니, 학교에 가는 날 민서는 창문을 열려고 학교에 일찍 도착해요."),
     ("칠판을 닦으려고", "칠판을 닦는 일은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 민서가 항상 일찍 오는 목적은 'to open the windows'(창문을 열려고)예요."),
     ("시험공부를 하려고", "시험공부는 글에서 이야기하는 것이 아니에요. 둘째 문장 «She always comes early to open the windows for some fresh air.»에서 민서가 항상 일찍 오는 목적은 창문을 여는 것이에요."),
     ("숙제를 끝내려고", "숙제는 글에서 이야기하는 것이 아니에요. 첫째 문장에서 민서는 'at half past seven'(일곱 시 반에) 교실에 오고, 둘째 문장에서 그렇게 항상 일찍 오는 목적은 'to open the windows'(창문을 열려고)예요.")])
K[22] = dict(
 ko="매년 여름, 시연이의 가족은 전주에 있는 그녀의 삼촌네 농장까지 차를 타고 간다. 그곳으로 가는 길에, 그녀는 아빠와 낱말 놀이를 하면서 그 시간을 보낸다. 집으로 오는 길에는, 그녀는 대부분의 시간 동안 자기 자리에서 잔다. 그래서 전주로 가는 차 안에서, 시연이는 대부분의 시간을 ______ 보낸다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on the drive to Jeonju, Siyeon spends most of her time»(그래서 전주로 가는 차 안에서, 시연이는 대부분의 시간을 … 보낸다) 뒤가 비어 있어요. 전주로 가는 길에 시연이가 무엇을 하는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On the way there, she spends the time playing word games with her dad.»(그곳으로 가는 길에, 그녀는 아빠와 낱말 놀이를 하면서 그 시간을 보낸다.) 'playing word games'(낱말 놀이를 하면서)가 그대로 나와요. 'there'(그곳)는 첫째 문장의 전주 삼촌네 농장이니, 전주로 가는 길의 일이에요.",
 "3) 확인: 셋째 문장 «On the way home, she sleeps in her seat most of the time.»(집으로 오는 길에는, 그녀는 대부분의 시간 동안 자기 자리에서 잔다.) 자리에서 자는 것은 'On the way home'(집으로 오는 길에는)의 일이에요. 전주로 가는 길은 둘째 문장의 'On the way there'(그곳으로 가는 길에)예요.",
 "4) 묶기: 전주로 가는 길에 시연이가 하는 일 = 'playing word games'(낱말 놀이를 하면서)."],
 traps="「자기 자리에서 자면서」가 끌릴 수 있어요. 셋째 문장의 'most of the time'(대부분의 시간 동안)이 빈칸 문장의 'most of her time'(대부분의 시간)과 닮았거든요. 하지만 셋째 문장은 'On the way home'(집으로 오는 길에는)의 이야기이고, 전주로 가는 길의 일은 둘째 문장의 'playing word games'(낱말 놀이를 하면서)예요.",
 cn=[("낱말 놀이를 하면서", "둘째 문장 «On the way there, she spends the time playing word games with her dad.»이 근거예요. 'there'(그곳)는 첫째 문장의 전주에 있는 삼촌네 농장이니, 전주로 가는 길에 시연이는 아빠와 낱말 놀이를 하면서 시간을 보내요."),
     ("자기 자리에서 자면서", "셋째 문장 «On the way home, she sleeps in her seat most of the time.»에서 자리에서 자는 것은 집으로 오는 길의 일이에요. 전주로 가는 길의 일은 둘째 문장의 'playing word games'(낱말 놀이를 하면서)예요."),
     ("만화책을 읽으면서", "만화책은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 전주로 가는 길에 시연이가 하는 일은 'playing word games with her dad'(아빠와 낱말 놀이를 하면서)예요."),
     ("옛날 영화를 보면서", "옛날 영화는 글에서 이야기하는 것이 아니에요. 전주로 가는 길의 일은 둘째 문장의 'playing word games'(낱말 놀이를 하면서)이고, 셋째 문장의 집으로 오는 길에는 시연이가 자기 자리에서 자요."),
     ("엄마와 노래를 부르면서", "엄마와 노래를 부르는 것은 글에서 이야기하는 것이 아니에요. 둘째 문장 «On the way there, she spends the time playing word games with her dad.»에서 전주로 가는 길의 시간을 보내는 일은 아빠와 하는 'playing word games'(낱말 놀이를 하면서)예요.")])
K[23] = dict(
 ko="토요일마다, 예나와 그녀의 아빠, 그리고 그녀의 남자 형제는 가족의 차를 세차한다. 예나는 부드러운 천으로 앞 창문을 조심스럽게 말린다. 그녀의 아빠는 긴 솔로 네 바퀴를 모두 씻는다. 그래서 토요일마다 집에서, 예나 자신의 일은 ______이다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Saturdays at home, Yena's own job is to»(그래서 토요일마다 집에서, 예나 자신의 일은 …이다) 뒤가 비어 있어요. 'own'(자신의)가 있으니, 가족 가운데 예나 자신이 하는 일을 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Yena carefully dries the front windows with a soft cloth.»(예나는 부드러운 천으로 앞 창문을 조심스럽게 말린다.) 'dries the front windows'(앞 창문을 말린다)가 나와요. 빈칸이 'to' 뒤라서 'dries'(말린다)가 원래 꼴로 들어갈 뿐이니, 예나 자신의 일은 앞 창문을 말리는 것이에요.",
 "3) 확인: 셋째 문장 «Her dad washes all four wheels with a long brush.»(그녀의 아빠는 긴 솔로 네 바퀴를 모두 씻는다.) 'washes all four wheels'(네 바퀴를 모두 씻는다)가 나오지만, 이것은 'Her dad'(그녀의 아빠)가 하는 일이에요. 빈칸 문장의 'own'(자신의) 때문에, 묻는 것은 예나의 일이에요.",
 "4) 묶기: 예나 자신의 일 = 'dries the front windows'(앞 창문을 말린다), 곧 앞 창문을 말리는 것."],
 traps="「네 바퀴를 씻는 것」이 끌릴 수 있어요. 셋째 문장에 'four wheels'(네 바퀴)가 그대로 나오고, 빈칸 문장만 보면 세차하는 어떤 일이든 들어갈 수 있거든요. 하지만 셋째 문장에서 네 바퀴를 씻는 사람은 'Her dad'(그녀의 아빠)이고, 예나가 하는 일은 둘째 문장의 'dries the front windows'(앞 창문을 말린다)예요.",
 cn=[("네 바퀴를 씻는 것", "셋째 문장 «Her dad washes all four wheels with a long brush.»에서 네 바퀴를 씻는 사람은 예나의 아빠예요. 예나 자신의 일은 둘째 문장의 'dries the front windows'(앞 창문을 말린다)예요."),
     ("물 양동이를 채우는 것", "물 양동이를 채우는 일은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 예나가 하는 일은 'dries the front windows with a soft cloth'(부드러운 천으로 앞 창문을 말린다)예요."),
     ("앞 창문을 말리는 것", "둘째 문장 «Yena carefully dries the front windows with a soft cloth.»이 근거예요. 함께 세차하는 세 사람 가운데 예나가 하는 일이 앞 창문을 말리는 것이니, 예나 자신의 일은 앞 창문을 말리는 것이에요."),
     ("가죽 의자를 닦는 것", "가죽 의자를 닦는 일은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 예나가 부드러운 천으로 하는 일은 'dries the front windows'(앞 창문을 말린다)예요."),
     ("앞쪽 등을 살펴보는 것", "앞쪽 등을 살펴보는 일은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 예나가 하는 일은 'the front windows'(앞 창문)를 말리는 것이고, 셋째 문장에서 아빠가 하는 일은 네 바퀴를 씻는 것이에요.")])
K[24] = dict(
 ko="민규는 매일 자기의 큰 개 초코를 데리고 공원 둘레를 산책한다. 주말에는, 그 둘은 아침 아홉 시에 산책을 시작한다. 학교에 가는 날에는, 민규는 저녁 일곱 시에 초코를 데리고 나간다. 그래서 학교에 가는 날에, 민규는 자기 개 초코를 ______ 산책시킨다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on school days, Mingyu walks his dog Choco»(그래서 학교에 가는 날에, 민규는 자기 개 초코를 … 산책시킨다) 뒤가 비어 있어요. 학교에 가는 날 민규가 몇 시에 초코를 산책시키는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On school days, Mingyu takes Choco out at seven in the evening.»(학교에 가는 날에는, 민규는 저녁 일곱 시에 초코를 데리고 나간다.) 'at seven in the evening'(저녁 일곱 시에)가 그대로 나와요. 빈칸 문장과 같은 'On school days'(학교에 가는 날에는)의 이야기이고, 'takes Choco out'(초코를 데리고 나간다)는 첫째 문장의 산책이니, 산책 시각은 저녁 일곱 시예요.",
 "3) 확인: 둘째 문장 «On weekends, the two of them start their walk at nine in the morning.»(주말에는, 그 둘은 아침 아홉 시에 산책을 시작한다.) 'at nine in the morning'(아침 아홉 시에)가 나오지만, 이것은 'On weekends'(주말에는)의 시각이에요.",
 "4) 묶기: 학교에 가는 날 초코를 산책시키는 시각 = 'at seven in the evening'(저녁 일곱 시에)."],
 traps="「아침 아홉 시에」가 끌릴 수 있어요. 둘째 문장에 'at nine in the morning'(아침 아홉 시에)가 그대로 나오고, 빈칸 문장만 보면 어느 시각이든 들어갈 수 있거든요. 하지만 그것은 'On weekends'(주말에는)의 시각이고, 학교에 가는 날의 시각은 셋째 문장의 'at seven in the evening'(저녁 일곱 시에)예요.",
 cn=[("아침 여섯 시에", "아침 여섯 시는 글에 나오지 않아요. 글에 나오는 시각은 둘째 문장의 'at nine in the morning'(아침 아홉 시에)와 셋째 문장의 'at seven in the evening'(저녁 일곱 시에)이고, 학교에 가는 날의 시각은 셋째 문장의 저녁 일곱 시예요."),
     ("아침 아홉 시에", "둘째 문장 «On weekends, the two of them start their walk at nine in the morning.»에서 아침 아홉 시는 주말에 산책을 시작하는 시각이에요. 학교에 가는 날의 시각은 셋째 문장의 'at seven in the evening'(저녁 일곱 시에)예요."),
     ("오후 네 시에", "오후 네 시는 글에 나오지 않아요. 셋째 문장 «On school days, Mingyu takes Choco out at seven in the evening.»에서 학교에 가는 날 민규가 초코를 데리고 나가는 시각은 저녁 일곱 시예요."),
     ("저녁 열 시에", "저녁 열 시는 글에 나오지 않아요. 'evening'(저녁)이 같아서 끌릴 수 있지만, 셋째 문장에서 학교에 가는 날 초코를 데리고 나가는 시각은 'seven in the evening'(저녁 일곱 시)이에요."),
     ("저녁 일곱 시에", "셋째 문장 «On school days, Mingyu takes Choco out at seven in the evening.»이 근거예요. 학교에 가는 날에는 저녁 일곱 시에 초코를 데리고 나가니, 민규는 학교에 가는 날 저녁 일곱 시에 초코를 산책시켜요.")])
