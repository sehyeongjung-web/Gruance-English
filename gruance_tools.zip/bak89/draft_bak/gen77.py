# -*- coding: utf-8 -*-
# 원고(d76.I)와 한글(k76_1~6.K)을 합쳐 pending/edits_X76x.py를 만든다.  python3 draft/gen77.py a   (뒷 절반은 b)
import sys, pprint, importlib
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
D = importlib.import_module('d76')
KO = {}
for _i in range(1, 7): KO.update(importlib.import_module('k76_%d' % _i).K)
ns = list(range(0, 15) if tag == 'a' else range(15, 30))
from lib import load
_tb = load()[1]
head = '앞' if tag == 'a' else '뒤'
out = ['# -*- coding: utf-8 -*-',
       '# 360번: 18번(글의 목적) 레벨1 %s 절반 — 편지 본문 네 문장(단문 · 문장당 10~15낱말) · 목적 문장 하나 + 곁가지(감사 · 소식) 하나 · 오답은 같은 받는 이에게 그럴듯한 다른 목적. 정답 번호는 바탕 그대로' % head,
       'AUTO_SYNC = False', 'E = {}', 'from z18common import maker', "rw = maker(E, '18', '1')", '']
for n in ns:
    I = D.I[n]; k = KO[n]; a = _tb['18']['1'][n]['answer']; CH = [I['ch'][x] for x in range(5)]
    text = '%s\n\n%s\n\n%s\n%s' % (I['to'], ' '.join(I['S']), I['sign'], I['name'])
    out.append('# %d번째 (정답 %s)' % (n + 1, '①②③④⑤'[a]))
    out.append('rw(%d, %d,\n   %r,\n   %s,\n   %r,\n   %r,\n   %r,\n   %d,\n   %r,\n   %r,\n   %s)\n' % (n, a, text, pprint.pformat(CH, width=200), k['ko'], I['S'][I['key']], k['purpose_ko'], I['key'] + 1, k['why'], k['words'], pprint.pformat(k['cn'], width=200)))
open('/home/claude/work/pending/edits_X76%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X76%s.py (%d문항)' % (tag, len(ns)))
