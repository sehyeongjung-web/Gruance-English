# -*- coding: utf-8 -*-
# 32번(빈칸 — 낱말) 레벨1 다시 쓰기 원고 셋째 묶음(문항 20~29). 단문 네 문장 · 정답 낱말이 첫째~셋째 문장에 그대로 나오되 빈칸 문장만으로는 정해지지 않는 꼴.
I = {}
# n21 나무·잎 — 까닭(무엇 때문에 잎이 흔들렸나)
I[20] = dict(S=['One afternoon, Hana sat under the big oak tree in her yard with a book.',
 'There was no wind at all in the yard that afternoon.',
 'Suddenly, a big black bird landed on a low branch and shook the leaves.',
 "So the leaves above Hana's head moved because of the ______."],
 ch={0: 'wind', 1: 'rain', 2: 'bird', 3: 'storm', 4: 'mouse'})
# n22 벌·꽃 — 물건(어느 나무의 꽃)
I[21] = dict(S=['Grandpa grew apple, pear and orange trees on his small farm in Jeju.',
 'One warm spring morning, Seoyun counted the bees on each kind of tree.',
 'There were many bees on the orange trees and only a few on the others.',
 "So the bees on Grandpa's farm liked the ______ trees best that morning."],
 ch={0: 'apple', 1: 'pear', 2: 'peach', 3: 'orange', 4: 'lemon'})
# n23 비·물웅덩이 — 곳(어느 웅덩이)
I[22] = dict(S=['After a heavy rain on Sunday, Minho saw three puddles on his street.',
 'There was one by the bank, one by the library and one by the church.',
 'On Tuesday morning, only the puddle by the church still had some water.',
 'So the puddle near the ______ lasted the longest after the rain.'],
 ch={0: 'bank', 1: 'library', 2: 'park', 3: 'school', 4: 'church'})
# n24 끓는 물·김 — 사람(누구의 냄비)
I[23] = dict(S=['Jiho, Mina and their dad each heated a pot of water on the stove.',
 'Mina used the smallest pot with only one cup of water in it.',
 'Her water boiled two minutes before the water in the other pots.',
 "So the water in ______'s pot boiled first on the stove."],
 ch={0: 'Jiho', 1: 'Dad', 2: 'Mina', 3: 'Sujin', 4: 'Mom'})
# n25 공·용수철·움직임 — 동사(동명사: 어떻게 움직였나)
I[24] = dict(S=['Our teacher put a heavy box of books on the classroom floor.',
 "Ben's hard push from behind did not move the box at all.",
 'Then three children pulled the box across the floor with a long rope.',
 'So the children finally moved the heavy box by ______ it.'],
 ch={0: 'pushing', 1: 'lifting', 2: 'kicking', 3: 'carrying', 4: 'pulling'})
# n26 산·기온 — 때(몇 월)
I[25] = dict(S=["In April, the cherry trees in Jun's town were full of pink flowers.",
 'On the cold mountain near the town, the cherry trees still had small buds.',
 'Jun saw pink flowers on the mountain cherry trees in early May.',
 'So the cherry trees on the mountain bloomed in ______ that year.'],
 ch={0: 'March', 1: 'April', 2: 'May', 3: 'June', 4: 'July'})
# n27 밤 동물 — 동물
I[26] = dict(S=['Grandpa put a small camera near the forest behind his house for one night.',
 "At ten o'clock at night, a fox walked past the camera.",
 'At two in the morning, a gray cat sat in front of the camera.',
 "So the animal on Grandpa's camera at two in the morning was a ______."],
 ch={0: 'cat', 1: 'mouse', 2: 'deer', 3: 'fox', 4: 'dog'})
# n28 빵·치즈·발효 — 형용사(색: 어느 병)
I[27] = dict(S=['Mom filled a green jar and a blue jar with milk and a little yogurt.',
 'The milk in the blue jar stayed sweet overnight in the cold fridge.',
 'The milk in the green jar on the warm table became thick and sour.',
 'So the next morning, the ______ jar had thick, sour milk.'],
 ch={0: 'green', 1: 'blue', 2: 'yellow', 3: 'white', 4: 'purple'})
# n29 조개·모래 — 물건(무엇이 가장 많았나)
I[28] = dict(S=['At low tide, Jisu and her dad walked along the wet sand for an hour.',
 'Jisu picked up twelve shells, three round stones and one small crab.',
 'She put all of them into her red bucket with some sea water.',
 "So most of the things in Jisu's bucket that day were ______."],
 ch={0: 'stones', 1: 'crabs', 2: 'fish', 3: 'shells', 4: 'bottles'})
# n30 안개·이슬·온도계 — 부사(얼마나 자주)
I[29] = dict(S=['For one windy week in May, Jiwoo checked the grass in her yard each morning.',
 'Every day at six, she touched the grass with her fingers.',
 'Her fingers never got wet from any dew on the grass that week.',
 "So that week, the grass in Jiwoo's yard was ______ wet at six."],
 ch={0: 'always', 1: 'never', 2: 'sometimes', 3: 'often', 4: 'usually'})
