# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 다시 쓰기 영어 원고 n=0~9. 네 문장 · 단문 · 정답 긴 구가 둘째/셋째 문장에 그대로 · 조건 대비 꼴
I = {}
I[0] = dict(S=['Jiwon reads in bed for a little while every night.',
 'On Saturday nights, her dad lets her read comic books with a flashlight.',
 'On school nights, he only lets her read one chapter of her new book.',
 'So on school nights, Dad only lets Jiwon ______.'],
 ch={0: 'read a short poem to her mom', 1: 'read comic books with a flashlight', 2: 'read one chapter of her new book', 3: 'read one page of her science book', 4: 'read two pages of her English book'})
I[1] = dict(S=['Somin visits the town library once a week with her grandma.',
 'Somin always reads on the second floor of the library.',
 'Her grandma reads the newspaper on the sofa near the front door.',
 'So every week, Somin always reads ______.'],
 ch={0: 'on the second floor of the library', 1: 'on the sofa near the front door', 2: 'in the garden behind the library', 3: 'in the park next to the library', 4: 'on the bench outside the front door'})
I[2] = dict(S=["Every Saturday, Dohyun goes to his grandpa's vegetable stand at the market.",
 'His older sister Yeseul goes there to count the money for Grandpa.',
 "Dohyun's only job there is to put the potatoes in paper bags.",
 'So Dohyun goes to the stand only ______.'],
 ch={0: 'to put the potatoes in paper bags', 1: 'to count the money for Grandpa', 2: 'to carry the heavy boxes of apples', 3: 'to sell fresh corn to the neighbors', 4: 'to wash the carrots in cold water'})
I[3] = dict(S=['Minu is learning to juggle three balls in his free time.',
 'On weekdays, he practices only by throwing two balls over his bed.',
 'On weekends, he learns new tricks by watching his uncle in the yard.',
 'So on weekdays, Minu practices only by ______.'],
 ch={0: 'watching short videos on his phone', 1: 'throwing two balls over his bed', 2: 'watching his uncle in the yard', 3: 'using three soft socks in the hall', 4: 'counting his catches out loud'})
I[4] = dict(S=['Every Saturday, Mom packs lunch boxes for Yujin and her little brother Taeo.',
 "Yujin's lunch box always has two rice balls and some chicken.",
 "Taeo's lunch box always has some cheese bread and an orange.",
 "So on Saturdays, Yujin's lunch box always has ______."],
 ch={0: 'a ham sandwich and some grapes', 1: 'some cheese bread and an orange', 2: 'some kimbap and a small apple', 3: 'two rice balls and some chicken', 4: 'fish cakes and a carton of milk'})
I[5] = dict(S=['The town pool has two rules for children in the summer.',
 'Children under ten may only swim in the small pool with a parent.',
 'Older children may jump into the deep pool from the side.',
 'So children under ten may only ______.'],
 ch={0: 'swim in the small pool with a parent', 1: 'jump into the deep pool from the side', 2: 'swim in the small pool with a teacher', 3: 'play in the water for thirty minutes', 4: 'use the water slide with a life jacket'})
I[6] = dict(S=['Seojun and his mom take care of three street cats near their apartment.',
 'Every evening, Seojun goes outside only to give the cats fresh water.',
 'His mom goes out in the morning to put dry food in a bowl.',
 'So every evening, Seojun goes outside only ______.'],
 ch={0: 'to put dry food in a bowl', 1: 'to brush the cats with a comb', 2: 'to give the cats fresh water', 3: 'to play with the cats for a while', 4: 'to take photos of the little cats'})
I[7] = dict(S=['Hajun does some easy stretches for ten minutes every morning.',
 'On weekdays, a short video only helps him stretch his neck and his shoulders.',
 'On Saturdays, his older sister helps him touch his toes with straight legs.',
 'So on weekdays, the short video only helps Hajun ______.'],
 ch={0: 'touch his toes with straight legs', 1: 'bend his back slowly like a cat', 2: 'stretch his neck and his shoulders', 3: 'stretch his knees and his ankles', 4: 'turn his body to the left and right'})
I[8] = dict(S=['Every week, Ara learns a short poem for her reading club.',
 'At home, she learns the poem only by reading each line to her cat.',
 'On the bus, she learns it by listening to her voice on her phone.',
 'So at home, Ara learns her poem only by ______.'],
 ch={0: 'listening to her voice on her phone', 1: 'writing the poem in her notebook', 2: 'singing the lines like a song', 3: 'drawing a picture for each line', 4: 'reading each line to her cat'})
I[9] = dict(S=['Every Saturday night in summer, Yeonwoo sleeps in a small tent with his dad.',
 'On clear nights, they put the tent in the yard behind the house.',
 'On rainy nights, they always put it on the floor of the living room.',
 'So on rainy nights, the tent always stands ______.'],
 ch={0: 'in the yard behind the house', 1: 'under the roof of the garage', 2: 'in the hall next to his bedroom', 3: 'on the floor of the living room', 4: 'in the small room under the stairs'})
