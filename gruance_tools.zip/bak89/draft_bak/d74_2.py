# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 다시 쓰기 영어 원고 — 10~19번째(n=10..19). 네 문장 · 단문 · 조건 대비 꼴 · 정답 구가 둘째/셋째 문장에 그대로
I = {}
I[10] = dict(S=["Every weekend, Doyun has breakfast at his grandma's house next door.",
 'On Saturdays, Grandma always gives him two sweet potatoes and warm milk.',
 'On Sundays, she gives him rice cakes with a little honey instead.',
 'So on Saturdays, Grandma always gives Doyun ______.'],
 ch={0: 'two eggs and a glass of orange juice', 1: 'rice cakes with a little honey', 2: 'a bowl of rice with some fish', 3: 'two slices of bread and some cheese', 4: 'two sweet potatoes and warm milk'})
I[11] = dict(S=["The computer room at Juwon's school is open at lunch and after school.",
 'At lunch, students may only play math games on the computers.',
 'After school, students may only use the computers for homework.',
 'So at lunch, Juwon may only ______.'],
 ch={0: 'play math games on the computers', 1: 'use the computers for homework', 2: 'watch science videos with headphones', 3: 'read the news on the computers', 4: 'send emails to his teachers'})
I[12] = dict(S=['Minjae and his track team meet at the school field every afternoon.',
 'Before practice, the coach has them jog two slow laps together.',
 'Before a race, the coach only lets them stretch on the soft grass.',
 'So before a race, the coach only lets Minjae ______.'],
 ch={0: 'jog two slow laps together', 1: 'do ten jumps by the fence', 2: 'stretch on the soft grass', 3: 'walk one lap with his team', 4: 'rest in the shade by the gym'})
I[13] = dict(S=["Every Saturday, Gaeun visits her aunt's bakery near the train station.",
 'In the morning, her only job there is to pack bread into paper bags.',
 'In the afternoon, her job is to clean the tables and floor.',
 'So on Saturday mornings, Gaeun visits the bakery only ______.'],
 ch={0: 'to sell cakes at the front counter', 1: 'to clean the tables and floor', 2: 'to write prices on small cards', 3: 'to pack bread into paper bags', 4: 'to bake bread with her aunt'})
I[14] = dict(S=["Seoyun's science club meets in the big science room every Thursday.",
 'The older members always work at the long table by the window.',
 'New members like Seoyun always work at the round table near the door.',
 'So as a new member, Seoyun always works ______.'],
 ch={0: 'at the long table by the window', 1: 'at the round table near the door', 2: 'at the small desk in the back', 3: 'at the big desk next to the board', 4: 'in the small room next door'})
I[15] = dict(S=['Taeri folds paper cranes and other paper animals in her free time.',
 'On weekdays, she learns new shapes only by watching videos on her phone.',
 'On weekends, she learns new shapes by copying her aunt step by step.',
 'So on weekdays, Taeri learns new shapes only by ______.'],
 ch={0: 'looking at pictures in a book', 1: 'watching videos on her phone', 2: 'copying her aunt step by step', 3: 'asking her art teacher at school', 4: 'trying new folds with old paper'})
I[16] = dict(S=['Woojin plays chess in his school chess club every Friday afternoon.',
 'After each game, the winner must always write the score on the wall chart.',
 'The loser must always put the pieces back in the box.',
 'So after a win, Woojin must always ______.'],
 ch={0: 'play the next game against the teacher', 1: 'put the pieces back in the box', 2: 'clean the board with a soft cloth', 3: 'write the score on the wall chart', 4: 'teach a younger member a new move'})
I[17] = dict(S=['Every Sunday, Chaeyun and her mom climb a small hill for a picnic.',
 'Mom always fills the big basket with sandwiches and cold milk.',
 'Chaeyun fills her own small basket with oranges and a bottle of water.',
 "So on Sundays, Chaeyun's own basket holds ______."],
 ch={0: 'sandwiches and cold milk', 1: 'cookies and strawberry milk', 2: 'grapes and two cans of cold juice', 3: 'rice balls and some green tea', 4: 'oranges and a bottle of water'})
I[18] = dict(S=['Hyobin and her older brother help at the animal shelter every Saturday.',
 'Her older brother goes there to walk the dogs along the river.',
 "Hyobin's only job there is to give the cats fresh water.",
 'So every Saturday, Hyobin goes to the shelter only ______.'],
 ch={0: 'to wash the puppies in the yard', 1: 'to give the cats fresh water', 2: 'to walk the dogs along the river', 3: 'to play with the little kittens', 4: 'to fix the old fence in the yard'})
I[19] = dict(S=['Siho writes about the weather in a small diary every evening.',
 'The diary only helps Mom choose the best days for the laundry.',
 'The diary only helps Grandpa water his garden on the right days.',
 "So Siho's weather diary only helps Grandpa ______."],
 ch={0: 'plan his long walks in the park', 1: 'choose the best days for the laundry', 2: 'fix the roof before a big storm', 3: 'water his garden on the right days', 4: 'pick the right coat for church'})
