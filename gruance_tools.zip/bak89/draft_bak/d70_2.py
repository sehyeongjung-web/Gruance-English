# -*- coding: utf-8 -*-
# 31번(빈칸 추론) 레벨2 새 판 — n=10~19. A/B 두 조건을 세우고 빈칸 문장은 그 결과를 견주거나 원인을 묻는 꼴.
# I[n] = dict(S=[네 문장 — 빈칸은 넷째 문장], ch={0..4: 선택지})
I = {}
I[10] = dict(S=["Mr. Han's ice cream shops, A and B, have the same menu, prices and size.",
 'Shop A stands by a school gate, but shop B is on a quiet street.',
 'On a hot day, A has a long line, but B is almost empty.',
 'So the real reason for the long line at shop A is its ______.'],
 ch={0: 'price', 1: 'menu', 2: 'owner', 3: 'place', 4: 'size'})
I[11] = dict(S=['Ann takes two chocolate bars, A and B, of the same kind to school.',
 'She keeps bar A in her pocket, but bar B stays in her bag.',
 'At lunch, A is soft and hangs over her finger, but B stays straight.',
 'So by lunch, bar A has started to ______, but bar B has not.'],
 ch={0: 'harden', 1: 'freeze', 2: 'crack', 3: 'break', 4: 'bend'})
I[12] = dict(S=['Mina puts the same amount of cold water in equal pots A and B.',
 'Both sit on one stove at one heat, and only A gets a metal top.',
 'Pot A bubbles hard in six minutes, but pot B needs about nine minutes.',
 'So the one real difference between pot A and pot B is the ______.'],
 ch={0: 'cover', 1: 'stove', 2: 'water', 3: 'size', 4: 'heat'})
I[13] = dict(S=['Lizards A and B, of the same size and age, sleep on one rock.',
 'In the morning, the sun shines on A, but B stays in the cool shade.',
 'An hour later, A runs fast after flies, but B still moves very slowly.',
 "So at this point, lizard A's body is ______ than lizard B's body."],
 ch={0: 'warmer', 1: 'colder', 2: 'longer', 3: 'older', 4: 'smaller'})
I[14] = dict(S=['Jun gives two young plants, A and B, the same soil and the same water.',
 'He keeps A by a sunny window, but he keeps B in a dark closet.',
 "Two weeks later, A's leaves are deep green, but B's are thin and light yellow.",
 'So these days, the leaves on plant B look ______.'],
 ch={0: 'green', 1: 'dark', 2: 'pale', 3: 'thick', 4: 'brown'})
I[15] = dict(S=['Jin makes two cups of lemonade, A and B, with the same lemons and water.',
 'He stirs two spoons of a white powder into cup A, but nothing into B.',
 'Cup A tastes sweet and nice, but cup B is too sour to drink.',
 "So Jin's cup A has some ______ in it, unlike cup B."],
 ch={0: 'salt', 1: 'honey', 2: 'sugar', 3: 'water', 4: 'lemon'})
I[16] = dict(S=['Jun takes bus 7 to the library on two sunny school days, A and B.',
 'On day A he gets on early at eight, and on day B after lunch.',
 "Day A's bus is half empty, but on day B Jun stands all the way.",
 "So of Jun's two rides, the busy one is in the ______."],
 ch={0: 'morning', 1: 'evening', 2: 'night', 3: 'rain', 4: 'afternoon'})
I[17] = dict(S=['Ken has two soccer balls, A and B, of the same color and age.',
 'He fills ball A with lots of air, but ball B gets only a little.',
 "Ken's thumb sinks deep into B, but A pushes his thumb right back.",
 'So at this point, ball B is ______ than ball A.'],
 ch={0: 'softer', 1: 'harder', 2: 'darker', 3: 'older', 4: 'newer'})
I[18] = dict(S=['Tanks A and B have the same size, water, light, food and number of fish.',
 'Tank A has a small pump with bubbles, but tank B has no pump.',
 'In tank B, the fish stay near the top and open their mouths fast.',
 'So right now, the fish in tank B probably need more ______.'],
 ch={0: 'air', 1: 'water', 2: 'light', 3: 'food', 4: 'space'})
I[19] = dict(S=['Ben folds two paper boats, A and B, from the same sheet of paper.',
 'He covers boat B with clear tape, and he leaves boat A plain.',
 'In the bath, A soon drops to the bottom, but B stays up.',
 'So at this moment, boat A is ______ the water in the tub.'],
 ch={0: 'on', 1: 'above', 2: 'under', 3: 'outside', 4: 'beside'})
