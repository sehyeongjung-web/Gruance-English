# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨1 다시 쓰기(359번) — I[n] = dict(S=[지문 네 문장], SM=요약문, ch={0..4: "a - b"})
I = {}
I[0] = dict(S=["Jiho and his older sister Nayeon spend every August on their grandparents' farm.", 'Every morning, Nayeon feeds the chickens in the field near the big tree.', 'Every evening, Jiho feeds the pigs in the small yard behind the house.', 'Grandma bakes sweet bread for the two hard workers every Sunday.'],
 SM="On his grandparents' farm, Jiho takes care of the (A) ______ every (B) ______.",
 ch={0: 'chickens - evening', 1: 'pigs - morning', 2: 'pigs - evening', 3: 'cows - morning', 4: 'chickens - morning'})
I[1] = dict(S=["Sumin's garden club looks after two small gardens at her school.", 'The garden by the front gate has flowers in four long rows.', 'The garden behind the library has potatoes in six short rows.', 'Every Friday after school, the club members water both gardens together.'],
 SM="Behind the school library, Sumin's club grows (A) ______ in (B) ______ rows.",
 ch={0: 'potatoes - six', 1: 'flowers - four', 2: 'flowers - six', 3: 'trees - four', 4: 'potatoes - four'})
I[2] = dict(S=['Siwoo and Bomi look after Max, the little hamster in their classroom.', 'Siwoo gives Max a few seeds from a paper cup after lunch.', 'Bomi gives Max small pieces of fresh fruit after school every day.', 'Max often sleeps in his little wooden house during class.'],
 SM='In their classroom, Bomi feeds Max some (A) ______ after (B) ______.',
 ch={0: 'seeds - lunch', 1: 'seeds - school', 2: 'rice - lunch', 3: 'fruit - lunch', 4: 'fruit - school'})
I[3] = dict(S=["Seho's family often takes long car trips to the sea on holidays.", 'On these trips, Seho always sits in the back seat with his camera.', 'His older sister Gaeun always sits in the front seat with a book.', 'Their mom drives the whole way with soft music on the radio.'],
 SM='On family car trips, Gaeun rides in the (A) ______ seat with a (B) ______.',
 ch={0: 'back - camera', 1: 'front - book', 2: 'middle - camera', 3: 'back - book', 4: 'front - camera'})
I[4] = dict(S=['Jaeho goes to the morning exercise club at his school twice a week.', "On Tuesdays, Jaeho's English teacher leads the club on the big field.", 'On Fridays, a young coach from the city leads the club on the tennis court.', 'After exercise, the members drink cold water and go to class.'],
 SM="On Friday mornings, Jaeho's club exercises with a (A) ______ on the (B) ______.",
 ch={0: 'teacher - field', 1: 'nurse - field', 2: 'teacher - court', 3: 'coach - court', 4: 'coach - field'})
I[5] = dict(S=['Last weekend, Yujin and her dad painted the old fence around their yard.', 'Near the road, they painted the fence blue with little white birds.', 'Near the house, they painted the fence green with little white stars.', "Yujin's mom took many photos of the new fence for Grandma."],
 SM='The part of the fence near the house is now (A) ______ with white (B) ______.',
 ch={0: 'blue - birds', 1: 'green - stars', 2: 'yellow - birds', 3: 'blue - stars', 4: 'green - birds'})
I[6] = dict(S=["Taemin's apartment has its recycling day every Wednesday behind the main building.", 'In the morning, Taemin carries the cans down in an old box.', 'In the evening, his dad carries the paper down in a big bag.', 'The yard behind the building looks clean and neat on Thursday mornings.'],
 SM="On recycling day, Taemin's dad takes the (A) ______ down in a (B) ______.",
 ch={0: 'cans - bag', 1: 'bottles - box', 2: 'paper - box', 3: 'paper - bag', 4: 'cans - box'})
I[7] = dict(S=["Haeun's apartment has a little free library in the lobby on the first floor.", "Last month, Haeun's aunt put her old novels on the top shelf.", 'A young teacher from the third floor put her magazines on the bottom shelf.', 'Now many neighbors borrow books from the little library every week.'],
 SM="In the lobby library, the (A) ______ from Haeun's aunt sit on the (B) ______ shelf.",
 ch={0: 'magazines - top', 1: 'novels - top', 2: 'poems - bottom', 3: 'magazines - bottom', 4: 'novels - bottom'})
I[8] = dict(S=["Every Saturday morning, Dayeon helps at her uncle's small cafe near the river.", 'Dayeon brings fresh bread from the market to the cafe by bus.', "Dayeon's uncle brings cold milk from a farm to the cafe by bike.", 'At ten, the cafe opens its doors for the first guests.'],
 SM="Every Saturday, Dayeon's uncle takes (A) ______ to the cafe by (B) ______.",
 ch={0: 'bread - bike', 1: 'cheese - bus', 2: 'milk - bike', 3: 'bread - bus', 4: 'milk - bus'})
I[9] = dict(S=["Yeonjun's school has its sports day on a sunny Friday in May.", 'In the morning, the students run a long race with their parents.', 'In the afternoon, the students play a ball game with their teachers.', 'At the end of the day, everyone sings the school song together.'],
 SM='On sports day, Yeonjun joins a (A) ______ with the (B) ______ in the afternoon.',
 ch={0: 'race - teachers', 1: 'game - teachers', 2: 'dance - parents', 3: 'race - parents', 4: 'game - parents'})
I[10] = dict(S=['Two new members, Jiho and Sena, joined the school band in March.', "Last year, Jiho's older sister taught him the piano at home.", "Last year, Sena's uncle gave her guitar lessons at his music shop.", 'Now the two friends practice with the band every Friday after school.'],
 SM="Last year, Sena's (A) ______ taught her to play the (B) ______.",
 ch={0: 'uncle - guitar', 1: 'sister - guitar', 2: 'uncle - piano', 3: 'aunt - piano', 4: 'sister - piano'})
I[11] = dict(S=["This spring, Doyun's family took a short camping trip to an island.", 'Every day, his father cooked potatoes over the fire for lunch.', 'Every night, his mother cooked chicken over the fire for dinner.', 'Doyun carried water and wood to the fire for both of them.'],
 SM="On the island, Doyun's father made (A) ______ for (B) ______ each day.",
 ch={0: 'chicken - lunch', 1: 'potatoes - dinner', 2: 'eggs - dinner', 3: 'potatoes - lunch', 4: 'chicken - dinner'})
I[12] = dict(S=['Every Sunday, Ara and her younger brother Juno fold the clean clothes.', 'Ara folds the shirts on the big table in the kitchen.', 'Juno folds the jackets on his bed in his own room.', 'Their mother thanks them with a big bowl of ice cream.'],
 SM="On Sundays, Ara's younger brother folds the (A) ______ on the (B) ______.",
 ch={0: 'shirts - bed', 1: 'jackets - table', 2: 'sheets - table', 3: 'shirts - table', 4: 'jackets - bed'})
I[13] = dict(S=["Last Saturday, Yejun's family spent the whole day at the city aquarium.", 'A worker fed the sharks at eleven on the second floor.', 'Another worker fed the penguins at three on the first floor.', 'Yejun took many photos of the animals with his new phone.'],
 SM='At the aquarium, the penguins got their food at (A) ______ on the (B) ______ floor.',
 ch={0: 'eleven - first', 1: 'four - second', 2: 'three - second', 3: 'eleven - second', 4: 'three - first'})
I[14] = dict(S=["Every year, Jiun's class takes two bus trips to the city museum.", 'In April, a museum guide teaches them about old maps.', 'In October, their own teacher tells them about old coins.', 'After each trip, the students write a short report in class.'],
 SM="On the April trip, Jiun's class learns about old (A) ______ from a (B) ______.",
 ch={0: 'coins - teacher', 1: 'maps - teacher', 2: 'ships - teacher', 3: 'maps - guide', 4: 'coins - guide'})
I[15] = dict(S=["Every winter, Siwon's grandma knits warm things for her two grandchildren.", 'This year, she knitted a soft brown hat for her grandson Siwon.', 'She also knitted a red coat for his little cousin Yerin.', 'Both children wear the warm gifts on cold mornings in January.'],
 SM="This year, Siwon's cousin got a (A) ______ (B) ______ from their grandma.",
 ch={0: 'brown - hat', 1: 'red - hat', 2: 'red - coat', 3: 'green - hat', 4: 'brown - coat'})
I[16] = dict(S=["Next month, Hyerin's class will put on a short play for their parents.", 'On stage, Hyerin will play a farmer with a small cup in her hand.', 'Her best friend Taeyun will play a king with a little bell.', 'The whole class practices the play in the music room after lunch.'],
 SM='In the play for the parents, Taeyun will be a (A) ______ with a (B) ______.',
 ch={0: 'farmer - bell', 1: 'doctor - cup', 2: 'king - bell', 3: 'farmer - cup', 4: 'king - cup'})
I[17] = dict(S=['Every summer, Jiwoo sells lemonade at a small stand on weekends.', 'On Saturdays, she sells twenty cups near the station with her dad.', 'On Sundays, she sells fifteen cups near the library with her mom.', 'Jiwoo saves her share of the money for a new bike.'],
 SM='Near the (A) ______, Jiwoo and her mom sell (B) ______ cups of lemonade a day.',
 ch={0: 'station - twenty', 1: 'library - twenty', 2: 'library - fifteen', 3: 'bank - twenty', 4: 'station - fifteen'})
I[18] = dict(S=["This summer, Minjun's cousin Dain stayed with him for a week.", "Every morning, the two cousins played football at the school near Minjun's house.", "Every evening, they played tennis in the park with Minjun's father.", 'Dain went back home to Busan on the last Sunday of July.'],
 SM='At the school, Minjun and his cousin played (A) ______ every (B) ______.',
 ch={0: 'tennis - morning', 1: 'football - evening', 2: 'cards - evening', 3: 'football - morning', 4: 'tennis - evening'})
I[19] = dict(S=["Yechan's school has a small bird club with eight members.", 'In spring, the members take photos of birds by the river.', 'In fall, they draw pictures of birds by the lake behind the school.', 'At the end of the year, the club makes a small bird book.'],
 SM="In (A) ______, Yechan's bird club draws the birds by the (B) ______.",
 ch={0: 'spring - lake', 1: 'fall - lake', 2: 'winter - river', 3: 'spring - river', 4: 'fall - river'})
I[20] = dict(S=['Last Tuesday, Jaeyun and his older sister stayed home for a snow day.', 'Jaeyun had his online classes on the computer in his bedroom.', 'His older sister had her online classes on her phone in the kitchen.', 'After the classes, the two children played in the snow in the yard.'],
 SM="On the snow day, Jaeyun's older sister took classes in the (A) ______ on her (B) ______.",
 ch={0: 'bedroom - phone', 1: 'kitchen - computer', 2: 'bedroom - computer', 3: 'office - computer', 4: 'kitchen - phone'})
I[21] = dict(S=["Arin's class took a big bus to the science museum for a school trip.", 'On the way to the museum, Arin sat by the door in the front row.', 'On the way home, she sat by the window in the back row.', 'The teacher counted the students twice at the museum gate.'],
 SM="On the ride home, Arin's seat was by the (A) ______ in the (B) ______ row.",
 ch={0: 'door - back', 1: 'window - front', 2: 'driver - front', 3: 'door - front', 4: 'window - back'})
I[22] = dict(S=['Seorin and her older brother went to a kite festival by the river.', 'Seorin flew a red kite on the grass near the old bridge.', 'Her older brother flew a yellow kite on top of a small hill.', 'Their father took many pictures of the two kites in the sky.'],
 SM="At the kite festival, Seorin's older brother flew a (A) ______ kite from the (B) ______.",
 ch={0: 'yellow - hill', 1: 'red - bridge', 2: 'green - bridge', 3: 'red - hill', 4: 'yellow - bridge'})
I[23] = dict(S=["Yejun's dance class is getting ready for a show at the town hall.", 'In the first dance, Yejun waves a fan on the left side.', 'In the second dance, he waves a flag on the right side.', 'The class practices the two dances every Friday after school.'],
 SM='During the first dance of the show, Yejun holds a (A) ______ on the (B) ______ side.',
 ch={0: 'fan - left', 1: 'flag - left', 2: 'stick - right', 3: 'fan - right', 4: 'flag - right'})
I[24] = dict(S=["In Chaerin's class, each student has a small job for the classroom.", 'Chaerin cleans the windows with a soft towel every morning.', 'Her friend Minseok cleans the desks with a wet cloth every afternoon.', 'Their teacher gives them a sticker for good work each Friday.'],
 SM="Every day, Minseok's job is to clean the (A) ______ in the (B) ______.",
 ch={0: 'windows - afternoon', 1: 'desks - morning', 2: 'chairs - morning', 3: 'windows - morning', 4: 'desks - afternoon'})
I[25] = dict(S=["On rainy days, Eunseo's aunt and uncle often visit her family for games.", 'Eunseo always plays card games with her uncle in the living room.', 'Her younger brother always plays word games with their aunt at the kitchen table.', 'Everyone has hot tea and rice cakes in the evening.'],
 SM="On rainy days, Eunseo's younger brother enjoys (A) ______ games with his (B) ______.",
 ch={0: 'card - aunt', 1: 'word - uncle', 2: 'number - uncle', 3: 'word - aunt', 4: 'card - uncle'})
I[26] = dict(S=["Gyumin's family spends every Friday evening at the night market by the river.", 'At seven, Gyumin always buys sweet bread from a small cart.', 'At nine, his father always buys hot potatoes from a food truck.', 'The family eats the food together on a bench by the water.'],
 SM="On Friday nights, Gyumin's father gets (A) ______ at the market at (B) ______.",
 ch={0: 'bread - nine', 1: 'potatoes - seven', 2: 'potatoes - nine', 3: 'chicken - seven', 4: 'bread - seven'})
I[27] = dict(S=["Daon's family plays board games at home every Saturday night.", 'Last Saturday, his aunt won the game and chose fish for Sunday lunch.', 'This Saturday, his uncle won the game and chose chicken for Sunday lunch.', "Daon wants his own first win at next week's game night."],
 SM="This weekend, Daon's (A) ______ won the board game and picked (B) ______ for lunch.",
 ch={0: 'uncle - chicken', 1: 'aunt - fish', 2: 'cousin - fish', 3: 'aunt - chicken', 4: 'uncle - fish'})
I[28] = dict(S=['Last summer, Hayul spent two days on a small island with her uncle.', 'On the first day, they rode to a quiet beach by bike.', 'On the second day, they went to a big lake by bus.', 'Hayul sent photos of the trip to her parents every night.'],
 SM='On day two of her island trip, Hayul traveled to the (A) ______ by (B) ______.',
 ch={0: 'lake - bus', 1: 'beach - bike', 2: 'farm - bike', 3: 'lake - bike', 4: 'beach - bus'})
I[29] = dict(S=["Last Saturday, the students at Sejin's school picked up trash on the beach.", "Sejin's class put plastic bottles into big blue bags near the rocks.", 'The class next door put empty cans into big yellow bags.', 'A big truck took all the bags away in the afternoon.'],
 SM="At the beach, Sejin's class collected (A) ______ in big (B) ______ bags.",
 ch={0: 'cans - blue', 1: 'bottles - blue', 2: 'cans - yellow', 3: 'cups - yellow', 4: 'bottles - yellow'})
