# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 한글 (d73.py I[25]~I[29]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[25] = dict(
 ko="매일, 재현은 새 트럼펫을 30분쯤 연습한다. 토요일 아침에는, 그는 음악 학원에서 자기 밴드와 함께 그것을 연주한다. 평일 저녁에는, 그는 저녁 식사 후에 거실에서 그것을 연주한다. 그래서 평일 저녁에, 재현은 ______ 새 트럼펫을 연습한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on weekday evenings, Jaehyun practices his new trumpet»(그래서 평일 저녁에, 재현은 … 새 트럼펫을 연습한다) 뒤가 비어 있어요. 평일 저녁에 어디에서 연습하는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On weekday evenings, he plays it in the living room after dinner.»(평일 저녁에는, 그는 저녁 식사 후에 거실에서 그것을 연주한다.) «in the living room»(거실에서)가 그대로 나와요. 첫째 문장대로 재현은 'Every day'(매일) 연습하니, 평일 저녁의 연주가 곧 그 연습이에요.",
 "3) 확인: 둘째 문장 «On Saturday mornings, he plays it at the music school with his band.»(토요일 아침에는, 그는 음악 학원에서 자기 밴드와 함께 그것을 연주한다.) «at the music school»(음악 학원에서)는 'Saturday mornings'(토요일 아침)의 일이에요.",
 "4) 묶기: 평일 저녁에 재현이 트럼펫을 연습하는 곳 = «in the living room»(거실에서)."],
 traps="「음악 학원에서」가 끌릴 수 있어요. 둘째 문장에 «at the music school»(음악 학원에서)가 그대로 나오고, 빈칸 문장만 보면 자연스럽거든요. 하지만 그것은 'Saturday mornings'(토요일 아침)의 일이에요. 「자기의 작은 침실에서」도 집에서 연습하는 곳으로 끌릴 수 있지만, 셋째 문장에서 평일 저녁에 연주하는 곳은 «in the living room»(거실에서)이에요.",
 cn=[("음악 학원에서", "둘째 문장 «On Saturday mornings, he plays it at the music school with his band.»에서 음악 학원은 토요일 아침에 밴드와 함께 연주하는 곳이에요. 평일 저녁에 연주하는 곳은 셋째 문장의 거실이에요."),
     ("자기의 작은 침실에서", "침실은 글에서 이야기하는 곳이 아니에요. 셋째 문장에서 평일 저녁에 재현이 트럼펫을 연주하는 곳은 «in the living room»(거실에서)라고 했어요."),
     ("텅 빈 차고에서", "차고는 글에서 이야기하는 곳이 아니에요. 글에 나오는 연주 장소는 둘째 문장에서 토요일 아침의 «at the music school»(음악 학원에서)과 셋째 문장에서 평일 저녁의 «in the living room»(거실에서)이고, 평일 저녁의 곳은 거실이에요."),
     ("시내 공원에서", "공원은 글에서 이야기하는 곳이 아니에요. 셋째 문장 «On weekday evenings, he plays it in the living room after dinner.»에서 평일 저녁에 연주하는 곳은 거실이에요."),
     ("거실에서", "셋째 문장 «On weekday evenings, he plays it in the living room after dinner.»이 근거예요. 첫째 문장에서 재현은 'Every day'(매일) 트럼펫을 연습하고, 평일 저녁에 그것을 연주하는 곳이 거실이니, 평일 저녁에 연습하는 곳도 거실이에요.")])
K[26] = dict(
 ko="채원은 일주일에 두 번 도시 건너편에 있는 바이올린 수업에 간다. 화요일마다, 그녀는 이모의 작은 차를 타고 그곳에 간다. 목요일마다, 그녀는 엄마와 함께 지하철을 타고 그곳에 간다. 그래서 화요일마다, 채원은 ______ 바이올린 수업에 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Tuesdays, Chaewon goes to her violin lesson»(그래서 화요일마다, 채원은 … 바이올린 수업에 간다) 뒤가 비어 있어요. 화요일마다 채원이 무엇을 타고 바이올린 수업에 가는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On Tuesdays, she goes there in her aunt's small car.»(화요일마다, 그녀는 이모의 작은 차를 타고 그곳에 간다.) «in her aunt's small car»(이모의 작은 차를 타고)가 그대로 나와요. 빈칸 문장과 같은 'Tuesdays'(화요일마다)의 일이에요.",
 "3) 확인: 셋째 문장 «On Thursdays, she goes there by subway with her mom.»(목요일마다, 그녀는 엄마와 함께 지하철을 타고 그곳에 간다.) «by subway with her mom»(엄마와 함께 지하철을 타고)는 'Thursdays'(목요일마다)의 일이에요.",
 "4) 묶기: 화요일마다 채원이 바이올린 수업에 가는 방법 = «in her aunt's small car»(이모의 작은 차를 타고)."],
 traps="「엄마와 함께 지하철을 타고」가 끌릴 수 있어요. 셋째 문장에 «by subway with her mom»(엄마와 함께 지하철을 타고)가 그대로 나오고, 빈칸 문장만 보면 어떤 방법이든 들어갈 수 있거든요. 하지만 셋째 문장의 지하철은 'Thursdays'(목요일마다)의 일이에요. 「시내버스를 타고」나 「커다란 노란 택시를 타고」도 첫째 문장의 'across town'(도시 건너편) 때문에 끌릴 수 있지만, 둘째 문장에서 'Tuesdays'(화요일마다) 타고 가는 것은 «in her aunt's small car»(이모의 작은 차를 타고)예요.",
 cn=[("엄마와 함께 지하철을 타고", "셋째 문장 «On Thursdays, she goes there by subway with her mom.»에서 엄마와 함께 지하철을 타고 가는 것은 목요일마다의 일이에요. 화요일마다는 둘째 문장에서 이모의 작은 차를 타고 가요."),
     ("이모의 작은 차를 타고", "둘째 문장 «On Tuesdays, she goes there in her aunt's small car.»이 근거예요. 화요일마다 채원은 이모의 작은 차를 타고 그곳, 곧 바이올린 수업에 가요."),
     ("시내버스를 타고", "버스는 글에서 이야기하는 것이 아니에요. 둘째 문장에서 화요일마다 채원이 타는 것은 이모의 작은 차이고, 셋째 문장에서 목요일마다 타는 것은 'subway'(지하철)이에요."),
     ("친구의 스쿠터를 타고", "스쿠터는 글에서 이야기하는 것이 아니에요. 둘째 문장이 말하는 화요일마다의 방법은 «in her aunt's small car»(이모의 작은 차를 타고)예요."),
     ("커다란 노란 택시를 타고", "택시는 글에서 이야기하는 것이 아니에요. 글에 나오는 방법은 둘째 문장에서 화요일마다의 «in her aunt's small car»(이모의 작은 차를 타고)와 셋째 문장에서 목요일마다의 «by subway with her mom»(엄마와 함께 지하철을 타고)이고, 화요일마다의 방법은 이모의 작은 차예요.")])
K[27] = dict(
 ko="해마다, 보라의 온 가족은 할아버지 생신에 함께 저녁 식사를 한다. 보라는 항상 할아버지께 겨울용으로 따뜻한 양말 한 켤레를 드린다. 그녀의 부모님은 항상 저녁 식사 때 할아버지께 녹차 한 상자를 드린다. 그래서 해마다 할아버지 생신에, 보라는 할아버지께 ______ 드린다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Grandpa's birthday each year, Bora gives him»(그래서 해마다 할아버지 생신에, 보라는 할아버지께 … 드린다) 뒤가 비어 있어요. 생신에 보라가 무엇을 드리는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Bora always gives him a pair of warm socks for the winter.»(보라는 항상 할아버지께 겨울용으로 따뜻한 양말 한 켤레를 드린다.) «a pair of warm socks»(따뜻한 양말 한 켤레)가 그대로 나와요. 첫째 문장의 해마다 있는 생신에 보라가 'always'(항상) 드리는 것이에요.",
 "3) 확인: 셋째 문장 «Her parents always give him a box of green tea at dinner.»(그녀의 부모님은 항상 저녁 식사 때 할아버지께 녹차 한 상자를 드린다.) «a box of green tea»(녹차 한 상자)는 드리는 사람이 'Her parents'(그녀의 부모님)예요.",
 "4) 묶기: 해마다 할아버지 생신에 보라가 드리는 것 = «a pair of warm socks»(따뜻한 양말 한 켤레)."],
 traps="「녹차 한 상자」가 끌릴 수 있어요. 셋째 문장에 «a box of green tea»(녹차 한 상자)가 그대로 나오고, 빈칸 문장만 보면 어떤 물건이든 들어갈 수 있거든요. 하지만 셋째 문장에서 녹차를 드리는 사람은 'Her parents'(그녀의 부모님)이에요. 「길고 빨간 목도리 하나」도 둘째 문장의 'for the winter'(겨울용으로) 때문에 끌릴 수 있지만, 둘째 문장에서 보라가 겨울용으로 드리는 것은 «a pair of warm socks»(따뜻한 양말 한 켤레)예요.",
 cn=[("녹차 한 상자", "셋째 문장 «Her parents always give him a box of green tea at dinner.»에서 녹차 한 상자를 드리는 사람은 보라의 부모님이에요. 보라가 드리는 것은 둘째 문장의 따뜻한 양말 한 켤레예요."),
     ("빨간 사과 한 바구니", "사과는 글에서 이야기하는 것이 아니에요. 둘째 문장에서 보라가 'always'(항상) 드리는 것은 «a pair of warm socks»(따뜻한 양말 한 켤레)예요."),
     ("커다란 가족사진 한 장", "가족사진은 글에서 이야기하는 것이 아니에요. 첫째 문장의 'whole family'(온 가족) 때문에 끌릴 수 있지만, 둘째 문장 «Bora always gives him a pair of warm socks for the winter.»에서 보라가 'always'(항상) 드리는 것은 따뜻한 양말 한 켤레예요."),
     ("따뜻한 양말 한 켤레", "둘째 문장 «Bora always gives him a pair of warm socks for the winter.»이 근거예요. 해마다 할아버지 생신에 보라는 'always'(항상) 따뜻한 양말 한 켤레를 드려요."),
     ("길고 빨간 목도리 하나", "목도리는 글에서 이야기하는 것이 아니에요. 둘째 문장에서 보라가 겨울용으로 드리는 것은 'warm socks'(따뜻한 양말)이에요.")])
K[28] = dict(
 ko="현우의 가족은 자기네 아파트 근처의 작은 빵집에서 자주 음식을 산다. 일요일마다, 그의 어머니는 같은 빵집에서 딸기 케이크 하나를 산다. 매주 토요일 아침, 현우는 그곳에서 아침 식사용으로 우유빵 한 봉지를 산다. 그래서 매주 토요일 아침, 현우는 빵집에서 ______ 산다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every Saturday morning, Hyunwoo buys»(그래서 매주 토요일 아침, 현우는 … 산다)와 'at the bakery'(빵집에서) 사이가 비어 있어요. 토요일 아침에 현우가 무엇을 사는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Every Saturday morning, Hyunwoo buys a bag of milk bread there for breakfast.»(매주 토요일 아침, 현우는 그곳에서 아침 식사용으로 우유빵 한 봉지를 산다.) «a bag of milk bread»(우유빵 한 봉지)가 그대로 나와요. 빈칸 문장과 같은 'every Saturday morning'(매주 토요일 아침)의 일이에요.",
 "3) 확인: 둘째 문장 «On Sundays, his mother buys a strawberry cake at the same bakery.»(일요일마다, 그의 어머니는 같은 빵집에서 딸기 케이크 하나를 산다.) 딸기 케이크는 'Sundays'(일요일마다) 'his mother'(그의 어머니)가 사는 것이에요. 토요일 아침에 현우가 사는 것은 셋째 문장의 우유빵이에요.",
 "4) 묶기: 매주 토요일 아침 현우가 빵집에서 사는 것 = «a bag of milk bread»(우유빵 한 봉지)."],
 traps="「딸기 케이크 하나」가 끌릴 수 있어요. 둘째 문장에 'a strawberry cake'(딸기 케이크 하나)가 나오고, 같은 빵집에서 사는 것이거든요. 하지만 둘째 문장에서 딸기 케이크를 사는 사람은 현우가 아니라 'his mother'(그의 어머니)이고, 사는 날도 'Sundays'(일요일마다)예요. 셋째 문장에서 토요일 아침에 현우가 사는 것은 우유빵 한 봉지예요.",
 cn=[("딸기 케이크 하나", "둘째 문장 «On Sundays, his mother buys a strawberry cake at the same bakery.»에서 딸기 케이크는 일요일마다 현우의 어머니가 사는 것이에요. 토요일 아침에 현우가 사는 것은 셋째 문장의 우유빵 한 봉지예요."),
     ("버터 쿠키 한 상자", "쿠키는 글에서 이야기하는 것이 아니에요. 셋째 문장에서 'every Saturday morning'(매주 토요일 아침) 현우가 사는 것은 «a bag of milk bread»(우유빵 한 봉지)예요."),
     ("초콜릿 도넛 두 개", "도넛은 글에서 이야기하는 것이 아니에요. 글에 나오는 빵집 물건은 둘째 문장에서 어머니가 일요일마다 사는 «a strawberry cake»(딸기 케이크 하나)와 셋째 문장에서 현우가 매주 토요일 아침 사는 «a bag of milk bread»(우유빵 한 봉지)이고, 토요일 아침에 현우가 사는 것은 우유빵 한 봉지예요."),
     ("우유빵 한 봉지", "셋째 문장 «Every Saturday morning, Hyunwoo buys a bag of milk bread there for breakfast.»이 근거예요. 매주 토요일 아침 현우는 그 빵집에서 아침 식사용으로 우유빵 한 봉지를 사요."),
     ("치즈빵 몇 개", "치즈빵은 글에서 이야기하는 것이 아니에요. 셋째 문장에서 현우가 아침 식사용으로 사는 것은 'milk bread'(우유빵)이에요.")])
K[29] = dict(
 ko="매주 토요일 오후, 예진은 미술 센터에서 그림 수업을 듣는다. 일요일마다 집에서, 그녀는 소파 위에 있는 자기의 작은 회색 고양이를 그린다. 그녀의 토요일 수업에서, 학생들은 항상 싱싱한 과일이 담긴 그릇을 그린다. 그래서 매주 토요일 미술 센터에서, 예진은 ______ 그림을 그린다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every Saturday at the art center, Yejin draws»(그래서 매주 토요일 미술 센터에서, 예진은 … 그림을 그린다) 뒤가 비어 있어요. 토요일 미술 센터에서 예진이 무엇을 그리는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «In her Saturday class, the students always draw a bowl of fresh fruit.»(그녀의 토요일 수업에서, 학생들은 항상 싱싱한 과일이 담긴 그릇을 그린다.) «a bowl of fresh fruit»(싱싱한 과일이 담긴 그릇)이 그대로 나와요. 첫째 문장의 토요일 미술 센터 수업에서 학생들이 'always'(항상) 그리는 것이니, 예진도 이것을 그려요.",
 "3) 확인: 둘째 문장 «At home on Sundays, she draws her little gray cat on the sofa.»(일요일마다 집에서, 그녀는 소파 위에 있는 자기의 작은 회색 고양이를 그린다.) 고양이도 예진이 그리지만, 'At home on Sundays'(일요일마다 집에서)의 일이에요. 토요일 미술 센터에서 그리는 것은 셋째 문장의 과일 그릇이에요.",
 "4) 묶기: 토요일 미술 센터에서 예진이 그리는 것 = «a bowl of fresh fruit»(싱싱한 과일이 담긴 그릇)."],
 traps="「자기의 작은 회색 고양이」가 끌릴 수 있어요. 둘째 문장에서 예진이 직접 'her little gray cat'(자기의 작은 회색 고양이)를 그리거든요. 하지만 둘째 문장에서 고양이를 그리는 것은 'At home on Sundays'(일요일마다 집에서)의 일이에요. 셋째 문장의 토요일 수업에서 'always'(항상) 그리는 것은 과일 그릇이에요.",
 cn=[("자기의 작은 회색 고양이", "둘째 문장 «At home on Sundays, she draws her little gray cat on the sofa.»에서 예진이 고양이를 그리는 것은 일요일마다 집에서의 일이에요. 토요일 미술 센터 수업에서 그리는 것은 셋째 문장의 싱싱한 과일이 담긴 그릇이에요."),
     ("노란 장미가 꽂힌 꽃병", "장미 꽃병은 글에서 이야기하는 것이 아니에요. 셋째 문장에서 토요일 수업의 학생들이 'always'(항상) 그리는 것은 «a bowl of fresh fruit»(싱싱한 과일이 담긴 그릇)이에요."),
     ("공원의 나무들", "공원의 나무들은 글에서 이야기하는 것이 아니에요. 글에서 예진이 그리는 것은 둘째 문장에서 일요일마다 집에서 그리는 'her little gray cat'(자기의 작은 회색 고양이)와 셋째 문장에서 토요일 수업에서 그리는 «a bowl of fresh fruit»(싱싱한 과일이 담긴 그릇)이고, 토요일 미술 센터에서 그리는 것은 과일 그릇이에요."),
     ("싱싱한 과일이 담긴 그릇", "셋째 문장 «In her Saturday class, the students always draw a bowl of fresh fruit.»이 근거예요. 첫째 문장에서 예진은 매주 토요일 미술 센터에서 그림 수업을 듣고, 그 수업의 학생들은 'always'(항상) 싱싱한 과일이 담긴 그릇을 그려요."),
     ("키가 큰 유리병", "유리병은 글에서 이야기하는 것이 아니에요. 셋째 문장에서 토요일 수업의 학생들이 'always'(항상) 그리는 것은 'fresh fruit'(싱싱한 과일)이 담긴 그릇이에요.")])
