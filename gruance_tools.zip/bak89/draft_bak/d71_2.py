# -*- coding: utf-8 -*-
# 31번(빈칸 추론) 레벨1 다시 쓰기 — n=10~19 담당. 정답 낱말이 둘째/셋째 문장에 그대로 나옴.
I = {}
I[10] = dict(S=['Ryan ran in a long city race on a hot Sunday in July.',
 'His coach and his brother waited for him at the finish line.',
 'Near the river, a police officer gave Ryan a cold bottle of water.',
 'So during the race, Ryan got some cold water from the ______.'],
 ch={0: 'coach', 1: 'brother', 2: 'officer', 3: 'doctor', 4: 'nurse'})
I[11] = dict(S=['Minho flew to Jeju with his new camera on a busy Friday.',
 'At the hotel, he searched his room for the camera and found nothing.',
 "Later, an airport worker found Minho's camera on a chair near Gate 3.",
 'So Minho had left his new camera at the ______ in Jeju.'],
 ch={0: 'hotel', 1: 'airport', 2: 'beach', 3: 'market', 4: 'station'})
I[12] = dict(S=['On Tuesday evening, Chef Park made a big pizza for a family of four.',
 'He put tomato sauce, cheese, ham and a few onions on the pizza.',
 'After one bite, the two children asked for more ham on their slices.',
 'So the children in the family wanted more ______ on their pizza.'],
 ch={0: 'ham', 1: 'cheese', 2: 'sauce', 3: 'corn', 4: 'pepper'})
I[13] = dict(S=["Mina's tennis club planned a big match with another club for Saturday.",
 'On Friday night, the coach of the other club became very sick.',
 'So the two clubs played the match on Sunday afternoon instead.',
 'In the end, Mina played in her big tennis match on ______.'],
 ch={0: 'Sunday', 1: 'Saturday', 2: 'Friday', 3: 'Monday', 4: 'Thursday'})
I[14] = dict(S=["Grandpa Oh's dog Toby barked in the yard all Tuesday night.",
 'The night was dark and calm, with no moon, wind or thunder.',
 'With a flashlight, Grandpa Oh found only a small fox in the bushes.',
 'So all night long, Toby was barking at the ______.'],
 ch={0: 'wind', 1: 'moon', 2: 'stranger', 3: 'fox', 4: 'thunder'})
I[15] = dict(S=['On a spring morning, Ara and her dad planned an afternoon picnic in the park.',
 'All day, the air stayed warm, with no clouds, rain or fog.',
 'At noon, the weather in the park suddenly became very windy.',
 'So in the afternoon, the weather was too ______ for a picnic.'],
 ch={0: 'rainy', 1: 'cold', 2: 'foggy', 3: 'cloudy', 4: 'windy'})
I[16] = dict(S=["Hana's young dog Bori goes to a dog school every Saturday morning.",
 "For weeks, Bori did not sit or roll over at the teacher's call.",
 'Last Saturday, Bori learned to jump over a low bar for a treat.',
 'So now Bori can ______ for the teacher at dog school.'],
 ch={0: 'sit', 1: 'roll', 2: 'dance', 3: 'jump', 4: 'wave'})
I[17] = dict(S=["Coach Kang's runners usually run fast laps around the track on Mondays.",
 'This Monday, the air over the track was very hot and heavy.',
 'At noon, the coach told the runners to run slowly for twenty minutes.',
 'So on this Monday, the runners ran their laps ______.'],
 ch={0: 'slowly', 1: 'fast', 2: 'late', 3: 'hard', 4: 'early'})
I[18] = dict(S=["Jina's family went camping near a lake in the mountains last summer.",
 'Her dad packed the tent, lamps, chairs, cups and plates in the car.',
 'At the lake, Jina found no blankets in the car or the bags.',
 'So on their first night at the lake, the family had no ______.'],
 ch={0: 'lamps', 1: 'chairs', 2: 'blankets', 3: 'cups', 4: 'plates'})
I[19] = dict(S=['Farmer Go grows red apples on a small farm near Daegu.',
 'Every year, his apples become big and sweet in late September.',
 'Then he picks all the apples in the first week of October.',
 'So every year, Farmer Go picks his sweet apples in ______.'],
 ch={0: 'September', 1: 'October', 2: 'August', 3: 'November', 4: 'July'})
