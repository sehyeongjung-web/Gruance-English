# 34번 레벨1 새 꼴 본보기 (꼴만 보고, 글감은 쓰지 말 것). 정답 자리는 바탕 그대로: n=0→2, n=1→0, n=2→0
I = {}
I[0] = dict(S=['Dana keeps a small notebook and a pencil beside her bed.',
 'On school mornings, the notebook only helps her remember her funny dreams.',
 'On Sundays, she also draws pictures of them for her little sister.',
 'So on school mornings, the notebook only helps Dana ______.'],
 ch={0:'wake up before her alarm clock',1:'finish her homework on time',2:'remember her funny dreams',3:'fall asleep much faster at night',4:'draw pictures of her dreams'})
I[1] = dict(S=["Mia's family eats dinner together every night of the week.",
 'From Monday to Friday, they eat at the small table in the kitchen.',
 'On Sundays, they eat at the long table in the living room.',
 "So on Sundays, Mia's family has dinner ______."],
 ch={0:'at the long table in the living room',1:'at the small table in the kitchen',2:'at a round table in the garden',3:"on the floor of Grandma's house",4:'at a window seat in a café'})
I[2] = dict(S=['Every Sunday, Leo rides his bike to the lake park.',
 'On the way, he stops at a bakery for fresh bread.',
 'At the lake, his only plan is to feed the ducks and swans.',
 'So Leo goes to the lake park only ______.'],
 ch={0:'to feed the ducks and swans',1:'to buy fresh bread for lunch',2:'to read a book in the shade',3:'to meet his old school friends',4:'to swim with his little cousin'})
