# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 다시 쓰기 원고 셋째 묶음(문항 20~29). 단문 네 문장 · 사람 하나의 되풀이되는 일과 · 정답 구가 첫째~셋째 문장에 그대로 나오되 빈칸 문장만으로는 정해지지 않는 꼴.
I = {}
# n21 집안일·설거지 — 함께하는 사람(누구와)
I[20] = dict(S=['Every evening after dinner, Junho washes the dishes in the family kitchen.',
 'On weekends, he does this job with his younger brother Minu.',
 'On school days, he works at the sink with his older sister.',
 'So on school days, Junho cleans the dinner dishes ______.'],
 ch={0: 'with his younger brother', 1: 'with his grandmother', 2: 'with his little cousin', 3: 'with his mom and dad', 4: 'with his older sister'})
# n22 학교·아침 교실 — 목적(왜 일찍 오나)
I[21] = dict(S=['On school days, Minseo gets to her classroom at half past seven.',
 'She always comes early to open the windows for some fresh air.',
 'Her friend Jia comes at eight to feed the class fish.',
 'So on school days, Minseo gets to school early ______.'],
 ch={0: 'to feed the class fish', 1: 'to open the windows', 2: 'to clean the blackboard', 3: 'to study for a test', 4: 'to finish her homework'})
# n23 가족 여행·차 안 — -ing구(무엇을 하며 보내나)
I[22] = dict(S=["Every summer, Siyeon's family drives to her uncle's farm in Jeonju.",
 'On the way there, she spends the time playing word games with her dad.',
 'On the way home, she sleeps in her seat most of the time.',
 'So on the drive to Jeonju, Siyeon spends most of her time ______.'],
 ch={0: 'playing word games', 1: 'sleeping in her seat', 2: 'reading comic books', 3: 'watching old movies', 4: 'singing with her mom'})
# n24 요리·일요일 팬케이크 — 동사구(help 뒤 원형: 무엇을 돕나)
I[23] = dict(S=["Every Sunday morning, Yena's dad makes pancakes for the whole family.",
 'Her little brother Jun helps him set the kitchen table with forks.',
 'Yena always helps her dad mix the flour and milk in a big bowl.',
 'So on Sunday mornings at home, Yena helps her dad ______.'],
 ch={0: 'set the kitchen table', 1: 'cut up the strawberries', 2: 'mix the flour and milk', 3: 'wash the frying pan', 4: 'pour the orange juice'})
# n25 반려동물·개 산책 — 때(몇 시에)
I[24] = dict(S=['Mingyu takes his big dog Choco for a walk around the park every day.',
 'On weekends, the two of them start their walk at nine in the morning.',
 'On school days, Mingyu takes Choco out at seven in the evening.',
 'So on school days, Mingyu walks his dog Choco ______.'],
 ch={0: 'at six in the morning', 1: 'at nine in the morning', 2: 'at four in the afternoon', 3: 'at ten in the evening', 4: 'at seven in the evening'})
# n26 음악·트럼펫 연습 — 장소(어디서)
I[25] = dict(S=['Every day, Siwoo practices his new trumpet for about thirty minutes.',
 'On Saturday mornings, he plays it at the music school with his band.',
 'On weekday evenings, he plays it in the living room after dinner.',
 'So on weekday evenings, Siwoo practices his new trumpet ______.'],
 ch={0: 'at the music school', 1: 'in his small bedroom', 2: 'in the empty garage', 3: 'in the city park', 4: 'in the living room'})
# n27 운동·태권도 가는 길 — 수단(무엇을 타고)
I[26] = dict(S=['Doyun goes to taekwondo class at a gym across town three times a week.',
 'On Mondays and Wednesdays, he rides there on his old bicycle.',
 "On Fridays, he gets there quickly in his mother's car.",
 'So on Mondays and Wednesdays, Doyun goes to taekwondo ______.'],
 ch={0: "in his mother's car", 1: 'on his old bicycle', 2: 'on the city bus', 3: 'on the subway train', 4: 'on his skateboard'})
# n28 가족 행사·할아버지 생신 — 명사구(무엇을 드리나)
I[27] = dict(S=["Every year, Bora's whole family has dinner together on Grandpa's birthday.",
 'Bora always gives him a pair of warm socks for the winter.',
 'Her parents always give him a box of green tea at dinner.',
 "So on Grandpa's birthday each year, Bora gives him ______."],
 ch={0: 'a box of green tea', 1: 'a basket of red apples', 2: 'a big family photo', 3: 'a pair of warm socks', 4: 'a long red scarf'})
# n29 가게·동네 빵집 — 명사구(무엇을 사나)
I[28] = dict(S=["Hyunwoo's family often buys food at the small bakery near their apartment.",
 'On Sundays, his mother buys a strawberry cake at the same bakery.',
 'Every Saturday morning, Hyunwoo buys a bag of milk bread there for breakfast.',
 'So every Saturday morning, Hyunwoo buys ______ at the bakery.'],
 ch={0: 'a strawberry cake', 1: 'a box of butter cookies', 2: 'two chocolate donuts', 3: 'a bag of milk bread', 4: 'a few cheese buns'})
# n30 취미·그림 교실 — 명사구(무엇을 그리나)
I[29] = dict(S=['Every Saturday afternoon, Yejin takes a drawing class at the art center.',
 'At home on Sundays, she draws her little gray cat on the sofa.',
 'In her Saturday class, the students always draw a bowl of fresh fruit.',
 'So every Saturday at the art center, Yejin draws ______.'],
 ch={0: 'her little gray cat', 1: 'a vase of yellow roses', 2: 'the trees in the park', 3: 'a bowl of fresh fruit', 4: 'a tall glass bottle'})
