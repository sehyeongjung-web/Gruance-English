I = {}
I[20] = dict(S=['Every spring, a pair of birds builds a nest near Haeun\'s house.',
 'Last year they made their nest in the old tree by the gate.',
 'This year Haeun found their new nest in an old box by the back door.',
 'So this spring, the baby birds came out of their eggs in the ______.'],
 ch={0:'tree',1:'garden',2:'roof',3:'grass',4:'box'})
I[21] = dict(S=['Minho took his guitar to the park on a warm Saturday morning.',
 'An old man with a dog asked Minho for a song about dogs.',
 'Later, a little girl on the grass asked for a song about the sea.',
 'So that morning, Minho played a happy song about dogs for the ______.'],
 ch={0:'girl',1:'boy',2:'woman',3:'man',4:'baby'})
I[22] = dict(S=['Jiho and his sister wanted special presents for their mom\'s birthday in May.',
 'At the market, Jiho bought a small clock for Mom\'s kitchen wall.',
 'His sister bought a soft pink scarf for Mom at the same market.',
 'So on the big day, Mom got a new ______ from her son Jiho.'],
 ch={0:'scarf',1:'cup',2:'bag',3:'ring',4:'clock'})
I[23] = dict(S=['Hyejin\'s aunt lives on Jeju Island with her husband and two dogs.',
 'Every summer, Hyejin\'s aunt comes to Seoul in August for a week.',
 'This year, the aunt came in October instead because of her busy job.',
 'So this year, Hyejin met her aunt from Jeju in ______.'],
 ch={0:'August',1:'October',2:'July',3:'September',4:'December'})
I[24] = dict(S=['Junho\'s family and their quiet dog camped by a mountain lake in July.',
 'The night was warm, calm and dry under a sky full of stars.',
 'Then a group in the next tent played loud music until two in the morning.',
 'So nobody in Junho\'s family slept well that night because of the ______.'],
 ch={0:'rain',1:'wind',2:'dog',3:'music',4:'cold'})
I[25] = dict(S=['Dami and her dad built a small wooden house for their dog Coco.',
 'At the store, her little brother asked for a can of red paint.',
 'In the end, Dami painted the little house yellow like the sun.',
 'So Coco now sleeps in a bright ______ house in the garden.'],
 ch={0:'yellow',1:'red',2:'blue',3:'white',4:'brown'})
I[26] = dict(S=['Last Sunday, Taemin\'s family spent a hot summer afternoon at the beach.',
 'Mom read a thick book under a big umbrella on the warm sand.',
 'Dad swam in the cool blue sea with Taemin for three hours.',
 'So that day, Dad ______ with his son Taemin for most of the afternoon.'],
 ch={0:'slept',1:'read',2:'swam',3:'walked',4:'fished'})
I[27] = dict(S=['Every Saturday, Seojun and his friend Taeho fish together at the river near their town.',
 'This Saturday, Taeho had a bad cold and stayed in bed at home.',
 'Seojun went to the river alone in the afternoon with some bread.',
 'So this Saturday, Seojun caught three small fish ______ at the river.'],
 ch={0:'together',1:'early',2:'alone',3:'quickly',4:'easily'})
I[28] = dict(S=['In June, Grandma put a big net over her strawberries to keep the birds away.',
 'Even so, a few strawberries disappeared from under the net every day.',
 'Then she saw a mouse under the net with a strawberry in its mouth.',
 'So in the end, Grandma\'s sweet strawberries became food for a little ______.'],
 ch={0:'mouse',1:'bird',2:'rabbit',3:'chicken',4:'dog'})
I[29] = dict(S=['In January, Eunbi\'s family went on a two-day ski trip to the mountains.',
 'On the first day, the mountain sky was clear from morning to evening.',
 'On the second day, the sky over the mountain stayed dark and gray.',
 'So Eunbi\'s ski photos from the first day all show a ______ sky.'],
 ch={0:'dark',1:'gray',2:'clear',3:'white',4:'pink'})
