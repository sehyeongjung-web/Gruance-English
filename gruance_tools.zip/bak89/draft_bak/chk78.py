# 19번(심경 변화) 레벨1 새 원고 검사: python3 draft/chk78.py draft/d78_N.py
#   I[n] = dict(S=[네 문장], ch={0..4: 'a → b'})  — 정답 낱말 a · b는 지문에 그대로(-ed/-s 정도만 다름)
import sys, re, importlib.util
sys.path.insert(0,'/home/claude/work'); sys.path.insert(0,'/home/claude/work/draft')
from lib import load
from zlevel import check_texts
_, tb, _ = load('/home/claude/Gruance-English/index.html')
spec = importlib.util.spec_from_file_location('dd', sys.argv[1]); d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
texts = {}; bad = 0
def warn(n, m):
    global bad; bad += 1; print('  !! n=%d %s' % (n, m))
for n, it in sorted(d.I.items()):
    ch = it['ch']; assert sorted(ch.keys()) == [0,1,2,3,4], (n, 'five choices')
    a = tb['19']['1'][n]['answer']; key = ch[a]
    if len(it['S']) != 4: warn(n, '네 문장')
    if len(set(ch.values())) != 5 or not all(re.fullmatch(r"[a-z]+ → [a-z]+", c) for c in ch.values()): warn(n, "보기는 'a → b' 꼴, 겹치지 않게")
    A, B = key.split(' → '); P = ' '.join(it['S']).lower()
    for w in (A, B):
        if not re.search(r'\b' + re.escape(w), P): warn(n, '정답 낱말 「%s」이 지문에 그대로 없음' % w)
    if A == B: warn(n, '처음과 나중이 같음')
    texts[n] = (' '.join(it['S']), key)
    print('n=%d key@%d=%s' % (n, a, key))
bad += check_texts('19', '1', texts, 4)
print('추가 검사 포함 걸린 것', bad)
