# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 한글 (d73.py I[10]~I[14]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[10] = dict(
 ko="준의 고양이 나비는 매일 밤 준의 침대 끝에서 잔다. 학교 가는 날에, 나비는 여섯 시에 준의 가슴 위에 앉아서 그를 깨운다. 주말에는, 그의 여동생이 그의 이불을 잡아당겨서 그를 깨운다. 그래서 학교 가는 날에, 그 고양이는 오직 ______ 준을 깨운다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on school days, the cat wakes Jun up only by»(그래서 학교 가는 날에, 그 고양이는 오직 … 준을 깨운다) 뒤가 비어 있어요. 학교 가는 날에 고양이가 무엇을 해서 준을 깨우는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On school days, Nabi wakes Jun at six by sitting on his chest.»(학교 가는 날에, 나비는 여섯 시에 준의 가슴 위에 앉아서 그를 깨운다.) 'sitting on his chest'(가슴 위에 앉아서)가 그대로 나와요. 첫째 문장에서 나비는 준의 고양이이니, 학교 가는 날 고양이가 준을 깨우는 방법은 이것이에요.",
 "3) 확인: 셋째 문장 «On weekends, his little sister wakes him up by pulling his blanket.»(주말에는, 그의 여동생이 그의 이불을 잡아당겨서 그를 깨운다.) 이불을 잡아당기는 것은 'On weekends'(주말에는) 여동생이 하는 일이에요. 빈칸 문장의 'only'(오직)은 둘째 문장의 가슴 위에 앉는 방법 하나만 남겨요.",
 "4) 묶기: 학교 가는 날 고양이가 준을 깨우는 방법 = 'sitting on his chest'(가슴 위에 앉아서)."],
 traps="「이불을 잡아당겨서」가 끌릴 수 있어요. 셋째 문장에 'pulling his blanket'(이불을 잡아당겨서)가 그대로 나오거든요. 하지만 그것은 'On weekends'(주말에는) 'his little sister'(그의 여동생)가 하는 일이고, 빈칸 문장은 학교 가는 날 고양이의 이야기예요. 「귀 옆에서 야옹 하고 울어서」도 끌리지만, 둘째 문장이 말하는 나비의 방법은 가슴 위에 앉는 것이고, 'only'(오직)가 그것 하나만 남겨요.",
 cn=[("코를 부드럽게 핥아서", "코를 핥는 것은 글에서 이야기하는 것이 아니에요. 둘째 문장 «On school days, Nabi wakes Jun at six by sitting on his chest.»에서 학교 가는 날 나비는 준의 가슴 위에 앉아서 그를 깨워요."),
     ("이불을 잡아당겨서", "셋째 문장 «On weekends, his little sister wakes him up by pulling his blanket.»에서 이불을 잡아당겨서 준을 깨우는 것은 주말에 그의 여동생이 하는 일이에요. 학교 가는 날 고양이가 하는 일이 아니에요."),
     ("귀 옆에서 야옹 하고 울어서", "귀 옆에서 우는 것은 글에서 이야기하는 것이 아니에요. 둘째 문장이 학교 가는 날 나비가 준을 깨우는 방법으로 말하는 것은 'sitting on his chest'(가슴 위에 앉아서)이고, 빈칸 문장의 'only'(오직)이 그 하나만 남겨요."),
     ("발가락을 깨물어서", "발가락을 깨무는 것은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 학교 가는 날 나비는 'sitting on his chest'(가슴 위에 앉아서) 준을 깨우고, 빈칸 문장의 'only'(오직)가 그 하나만 남겨요."),
     ("가슴 위에 앉아서", "둘째 문장 «On school days, Nabi wakes Jun at six by sitting on his chest.»이 근거예요. 첫째 문장에서 나비는 준의 고양이이고, 학교 가는 날 나비가 준을 깨우는 방법으로 둘째 문장이 말하는 것은 가슴 위에 앉는 것이니, 빈칸 문장의 'only'(오직) 뒤에 들어갈 것도 이것이에요.")])
K[11] = dict(
 ko="매주 화요일, 민수는 자기 학교 근처의 한 체육관에서 태권도 수업이 있다. 매 수업이 끝날 때, 그의 선생님은 그가 그 크고 검은 샌드백을 차게 해 준다. 더 어린 아이들은 그 시간에 매트 위에서 스트레칭을 한다. 그래서 매 수업이 끝날 때, 민수는 오직 ______만 찬다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So at the end of each class, Minsu kicks only»(그래서 매 수업이 끝날 때, 민수는 오직 …만 찬다) 뒤가 비어 있어요. 수업이 끝날 때 민수가 무엇을 차는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «At the end of each class, his teacher lets him kick the big black bag.»(매 수업이 끝날 때, 그의 선생님은 그가 그 크고 검은 샌드백을 차게 해 준다.) 'the big black bag'(그 크고 검은 샌드백)이 그대로 나와요. 빈칸 문장과 같은 수업 끝의 이야기이니, 민수가 차는 것은 이 샌드백이에요.",
 "3) 확인: 셋째 문장 «The younger children stretch on the mats at that time.»(더 어린 아이들은 그 시간에 매트 위에서 스트레칭을 한다.) 'the mats'(매트)는 더 어린 아이들이 스트레칭을 하는 곳이지, 민수가 차는 것이 아니에요. 빈칸 문장의 'only'(오직)은 둘째 문장의 샌드백 하나만 남겨요.",
 "4) 묶기: 수업이 끝날 때 민수가 차는 것 = 'the big black bag'(그 크고 검은 샌드백)."],
 traps="「바닥에 깔린 매트」가 끌릴 수 있어요. 셋째 문장에 'the mats'(매트)가 나오거든요. 하지만 셋째 문장에서 매트는 'The younger children'(더 어린 아이들)이 'at that time'(그 시간에) 스트레칭을 하는 곳이에요. 「그 낡은 체육관 문」도 첫째 문장의 'a gym'(체육관) 때문에 끌리지만, 둘째 문장에서 민수가 차는 것은 'the big black bag'(그 크고 검은 샌드백)이에요.",
 cn=[("바닥에 깔린 매트", "셋째 문장 «The younger children stretch on the mats at that time.»에서 매트는 더 어린 아이들이 그 시간에 스트레칭을 하는 곳이에요. 민수가 차는 것은 둘째 문장의 'the big black bag'(그 크고 검은 샌드백)이에요."),
     ("그 크고 검은 샌드백", "둘째 문장 «At the end of each class, his teacher lets him kick the big black bag.»이 근거예요. 매 수업이 끝날 때 선생님이 민수에게 차게 해 주는 것으로 둘째 문장이 말하는 것은 그 크고 검은 샌드백이니, 빈칸 문장의 'only'(오직) 뒤에 들어갈 것도 이 샌드백이에요."),
     ("나무 판자", "나무 판자는 글에서 이야기하는 것이 아니에요. 둘째 문장에서 수업이 끝날 때 민수가 차는 것은 'the big black bag'(그 크고 검은 샌드백)이에요."),
     ("작고 빨간 공", "작고 빨간 공은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 선생님이 민수에게 차게 해 주는 것은 'the big black bag'(그 크고 검은 샌드백)이에요."),
     ("그 낡은 체육관 문", "체육관 문은 글에서 이야기하는 것이 아니에요. 첫째 문장의 'a gym'(체육관)은 민수가 태권도 수업이 있는 곳이고, 둘째 문장에서 민수가 차는 것은 'the big black bag'(그 크고 검은 샌드백)이에요.")])
K[12] = dict(
 ko="가람은 매주 캐나다에 있는 자기 펜팔 친구에게 편지를 쓴다. 그의 여동생은 금요일 오후마다 자기 카드를 부친다. 가람은 화요일 저녁마다 자기 편지를 우체국에 가져간다. 그래서 매주, 가람은 ______ 자기 펜팔 친구에게 편지를 부친다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every week, Garam mails his letter to his pen friend»(그래서 매주, 가람은 … 자기 펜팔 친구에게 편지를 부친다) 뒤가 비어 있어요. 가람이 매주 언제 펜팔 친구에게 편지를 부치는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Garam takes his letter to the post office on Tuesday evenings.»(가람은 화요일 저녁마다 자기 편지를 우체국에 가져간다.) 'on Tuesday evenings'(화요일 저녁마다)가 그대로 나와요. 가람이 편지를 'the post office'(우체국)에 가져가는 때이니, 편지를 부치는 때도 이때예요.",
 "3) 확인: 둘째 문장 «His little sister mails her own cards on Friday afternoons.»(그의 여동생은 금요일 오후마다 자기 카드를 부친다.) 'on Friday afternoons'(금요일 오후마다)는 'His little sister'(그의 여동생)가 자기 카드를 부치는 때예요. 가람의 편지 이야기는 셋째 문장에 있어요.",
 "4) 묶기: 가람이 편지를 부치는 때 = 'on Tuesday evenings'(화요일 저녁마다)."],
 traps="「금요일 오후마다」가 끌릴 수 있어요. 둘째 문장에 'on Friday afternoons'(금요일 오후마다)가 그대로 나오고, 빈칸 문장과 같은 'mails'(부친다)도 있거든요. 하지만 둘째 문장에서 그때 부치는 사람은 'His little sister'(그의 여동생)이고, 부치는 것도 그녀의 카드예요. 「목요일 저녁마다」도 같은 저녁이라서 끌리지만, 셋째 문장의 요일은 'Tuesday'(화요일)이에요.",
 cn=[("금요일 오후마다", "둘째 문장 «His little sister mails her own cards on Friday afternoons.»에서 금요일 오후마다 부치는 사람은 가람의 여동생이고, 부치는 것도 그녀의 카드예요. 가람이 편지를 우체국에 가져가는 때는 셋째 문장의 화요일 저녁이에요."),
     ("일요일 아침마다", "일요일 아침은 글에서 이야기하는 때가 아니에요. 셋째 문장에서 가람이 편지를 우체국에 가져가는 때는 'on Tuesday evenings'(화요일 저녁마다)예요."),
     ("월요일 아침마다", "월요일 아침은 글에서 이야기하는 때가 아니에요. 둘째 문장의 금요일 오후는 여동생이 카드를 부치는 때이고, 셋째 문장에서 가람이 편지를 가져가는 때는 'on Tuesday evenings'(화요일 저녁마다)예요."),
     ("목요일 저녁마다", "목요일 저녁은 글에서 이야기하는 때가 아니에요. 셋째 문장에서 가람이 편지를 'the post office'(우체국)에 가져가는 것은 목요일이 아니라 'Tuesday'(화요일) 저녁이에요."),
     ("화요일 저녁마다", "셋째 문장 «Garam takes his letter to the post office on Tuesday evenings.»이 근거예요. 가람은 화요일 저녁마다 편지를 우체국에 가져가니, 매주 화요일 저녁마다 펜팔 친구에게 편지를 부쳐요.")])
K[13] = dict(
 ko="선우의 아빠는 매일 저녁 일곱 시쯤 퇴근해서 집에 온다. 문 앞에서, 그는 항상 자기 자동차 열쇠를 그 파란 그릇 안에 넣는다. 그다음 그의 휴대폰은 라디오 옆 부엌 선반 위에 놓인다. 그래서 매일 저녁 퇴근 후에, 선우의 아빠는 자기 자동차 열쇠를 ______ 둔다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every evening after work, Sunwoo's dad leaves his car keys»(그래서 매일 저녁 퇴근 후에, 선우의 아빠는 자기 자동차 열쇠를 … 둔다) 뒤가 비어 있어요. 아빠가 퇴근 후에 자동차 열쇠를 어디에 두는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «At the door, he always puts his car keys in the blue bowl.»(문 앞에서, 그는 항상 자기 자동차 열쇠를 그 파란 그릇 안에 넣는다.) 'in the blue bowl'(그 파란 그릇 안에)가 그대로 나와요. 퇴근해서 문 앞에서 'always'(항상) 이렇게 하니, 열쇠를 두는 곳은 그 파란 그릇 안이에요.",
 "3) 확인: 셋째 문장 «Then his phone goes on the kitchen shelf next to the radio.»(그다음 그의 휴대폰은 라디오 옆 부엌 선반 위에 놓인다.) 부엌 선반 위에 놓이는 것은 'his phone'(그의 휴대폰)이에요. 열쇠는 그보다 앞선 둘째 문장에서 이미 파란 그릇 안에 들어갔어요.",
 "4) 묶기: 아빠가 자동차 열쇠를 두는 곳 = 'in the blue bowl'(그 파란 그릇 안에)."],
 traps="「부엌 선반 위에」가 끌릴 수 있어요. 셋째 문장에 'on the kitchen shelf'(부엌 선반 위에)가 그대로 나오거든요. 하지만 그 위에 놓이는 것은 'his phone'(그의 휴대폰)이에요. 「신발장 위에」도 'At the door'(문 앞에서)와 어울려 보여 끌리지만, 둘째 문장에서 문 앞에서 열쇠가 들어가는 곳은 'the blue bowl'(그 파란 그릇)이에요.",
 cn=[("그 파란 그릇 안에", "둘째 문장 «At the door, he always puts his car keys in the blue bowl.»이 근거예요. 아빠는 문 앞에서 항상 자동차 열쇠를 그 파란 그릇 안에 넣으니, 매일 저녁 퇴근 후에 열쇠를 그 파란 그릇 안에 둬요."),
     ("부엌 선반 위에", "셋째 문장 «Then his phone goes on the kitchen shelf next to the radio.»에서 부엌 선반 위에 놓이는 것은 아빠의 휴대폰이에요. 자동차 열쇠는 둘째 문장에서 'in the blue bowl'(그 파란 그릇 안에) 들어가요."),
     ("자기 코트 주머니 안에", "코트 주머니는 글에서 이야기하는 곳이 아니에요. 둘째 문장에서 아빠는 문 앞에서 'always'(항상) 자동차 열쇠를 'in the blue bowl'(그 파란 그릇 안에) 넣어요."),
     ("신발장 위에", "신발장은 글에서 이야기하는 곳이 아니에요. 둘째 문장에서 'At the door'(문 앞에서) 아빠가 열쇠를 넣는 곳은 'the blue bowl'(그 파란 그릇)이에요."),
     ("책상 서랍 안에", "책상 서랍은 글에서 이야기하는 곳이 아니에요. 둘째 문장에서 열쇠가 들어가는 곳은 'the blue bowl'(그 파란 그릇)이고, 셋째 문장에서 부엌 선반 위에 놓이는 것은 휴대폰이에요.")])
K[14] = dict(
 ko="서진은 자기 중학교에서 약 2킬로미터 떨어진 곳에 산다. 대부분의 아침에, 그녀는 오빠의 자전거를 타고 학교에 간다. 비 오는 날에는, 그녀는 대신 초록색 시내버스를 타고 그곳에 간다. 그래서 대부분의 아침에, 서진은 ______ 학교에 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on most mornings, Seojin makes the trip to school»(그래서 대부분의 아침에, 서진은 … 학교에 간다) 뒤가 비어 있어요. 대부분의 아침에 서진이 어떻게 학교에 가는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On most mornings, she rides to school on her older brother's bike.»(대부분의 아침에, 그녀는 오빠의 자전거를 타고 학교에 간다.) 'on her older brother's bike'(오빠의 자전거를 타고)가 그대로 나와요. 빈칸 문장과 같은 'On most mornings'(대부분의 아침에)의 이야기예요.",
 "3) 확인: 셋째 문장 «On rainy days, she gets there on the green city bus instead.»(비 오는 날에는, 그녀는 대신 초록색 시내버스를 타고 그곳에 간다.) 버스는 'On rainy days'(비 오는 날에는) 자전거 'instead'(대신) 타는 것이에요. 대부분의 아침에 타는 것은 둘째 문장의 자전거예요.",
 "4) 묶기: 대부분의 아침에 서진이 학교에 가는 방법 = 'on her older brother's bike'(오빠의 자전거를 타고)."],
 traps="「초록색 시내버스를 타고」가 끌릴 수 있어요. 셋째 문장에 'on the green city bus'(초록색 시내버스를 타고)가 그대로 나오거든요. 하지만 그것은 'On rainy days'(비 오는 날에는)의 이야기이고, 빈칸 문장은 'On most mornings'(대부분의 아침에)의 이야기예요. 「노란 스쿨버스를 타고」도 끌리지만, 둘째 문장에서 대부분의 아침에 서진이 타는 것은 'her older brother's bike'(오빠의 자전거)예요.",
 cn=[("오빠의 자전거를 타고", "둘째 문장 «On most mornings, she rides to school on her older brother's bike.»이 근거예요. 대부분의 아침에 서진은 오빠의 자전거를 타고 학교에 가요."),
     ("초록색 시내버스를 타고", "셋째 문장 «On rainy days, she gets there on the green city bus instead.»에서 초록색 시내버스는 비 오는 날에 타는 것이에요. 대부분의 아침에 타는 것은 둘째 문장의 오빠의 자전거예요."),
     ("엄마의 작은 차를 타고", "엄마의 차는 글에서 이야기하는 것이 아니에요. 둘째 문장에서 대부분의 아침에 서진이 타는 것은 오빠의 자전거이고, 셋째 문장에서 비 오는 날에 타는 것은 초록색 시내버스예요."),
     ("노란 스쿨버스를 타고", "노란 스쿨버스는 글에서 이야기하는 것이 아니에요. 둘째 문장에서 대부분의 아침에 서진이 타는 것은 'her older brother's bike'(오빠의 자전거)이고, 셋째 문장에 나오는 버스도 비 오는 날에 타는 'the green city bus'(초록색 시내버스)예요."),
     ("친구들과 함께 걸어서", "걸어서 가는 것은 글에서 이야기하는 것이 아니에요. 둘째 문장에서 대부분의 아침에 서진은 'on her older brother's bike'(오빠의 자전거를 타고) 학교에 가요.")])
