# -*- coding: utf-8 -*-
# 31번(빈칸 추론) 레벨2 다시 쓰기 — 맡은 문항 n = 0~9. A/B 두 조건을 세우고 빈칸 문장은 그 결과를 견주거나 원인을 묻는 꼴.
# I[n] = dict(S=[네 문장 — 빈칸은 넷째 문장], ch={0..4: 선택지})
I = {}
I[0] = dict(S=['On nights A and B, Sora does the same amount of homework at her desk.',
 'Her phone is off both nights, but a neighbor plays loud songs on night A.',
 'She needs two hours on night A, but only one hour on night B.',
 'So on night A, the real trouble for Sora is probably the ______.'],
 ch={0: 'phone', 1: 'homework', 2: 'desk', 3: 'chair', 4: 'noise'})
I[1] = dict(S=['Noodle shops A and B sit side by side, and both are open every day.',
 'Both sell the same noodles until nine at night, but shop B opens at noon.',
 "At breakfast, shop A is full of workers, but shop B's door is locked.",
 'So shop B never gets any of the ______ customers on this street.'],
 ch={0: 'lunch', 1: 'dinner', 2: 'weekend', 3: 'holiday', 4: 'morning'})
I[2] = dict(S=['Leo puts two empty bowls, A and B, out in the spring rain.',
 'The next day, he covers bowl B, but he leaves bowl A open.',
 'After a week, bowl A holds dust, leaves and bugs, but bowl B holds none.',
 'So at the end of the week, the water in bowl B is ______.'],
 ch={0: 'clean', 1: 'dirty', 2: 'frozen', 3: 'sweet', 4: 'hot'})
I[3] = dict(S=['On Friday afternoon, Ben borrows two books, A and B, from the school library.',
 'He reads every page of both books at home over the weekend.',
 'On Monday, book A is on the library shelf again, but book B is not.',
 'So by Monday, Ben has ______ book A, but not book B.'],
 ch={0: 'read', 1: 'lost', 2: 'returned', 3: 'bought', 4: 'opened'})
I[4] = dict(S=['On days A and B, Tom wakes up at seven and leaves home at eight.',
 'Both days are sunny, but on day B, his road is full of cars.',
 'His bus ride takes ten minutes on day A, but forty minutes on day B.',
 'So on day B, the ______ makes Tom late for school.'],
 ch={0: 'alarm', 1: 'traffic', 2: 'weather', 3: 'breakfast', 4: 'homework'})
I[5] = dict(S=['Rivers A and B are the same size, and both get heavy rain on Monday.',
 'River A runs past open farm fields, but river B runs between big rocks.',
 'On Tuesday, both rivers run high, but only river A looks like chocolate milk.',
 'So after the rain, river A is carrying a lot more ______.'],
 ch={0: 'water', 1: 'fish', 2: 'ice', 3: 'soil', 4: 'salt'})
I[6] = dict(S=['At the market, Jun fills two paper bags of the same size, A and B.',
 'Bag A holds chips and paper cups, and bag B holds four bottles of milk.',
 'Jun lifts bag A with one finger, but he needs both arms for bag B.',
 'So for Jun, bag B is much ______ than bag A.'],
 ch={0: 'bigger', 1: 'lighter', 2: 'smaller', 3: 'heavier', 4: 'newer'})
I[7] = dict(S=['Every night, Grandpa reads a book, and he leaves his glasses next to it.',
 'He reads in the kitchen on night A, but in bed on night B.',
 'On the morning after night B, the kitchen table has no glasses on it.',
 'So that morning, Grandpa should look for his glasses in his ______.'],
 ch={0: 'kitchen', 1: 'car', 2: 'bedroom', 3: 'pocket', 4: 'garden'})
I[8] = dict(S=["Amy's yard has two fences, A on the east and B on the other side.",
 'One autumn night, a strong wind moves all the leaves in the yard.',
 'In the morning, most leaves lie against fence A, and few lie near fence B.',
 'So that night, the wind probably comes from the ______.'],
 ch={0: 'west', 1: 'east', 2: 'north', 3: 'south', 4: 'sea'})
I[9] = dict(S=['On a calm day, Mia builds castles A and B from the same beach sand.',
 "Both castles are equally tall, but she wets only A's sand, and B's stays dry.",
 'An hour later, castle A still stands, but castle B is a flat pile.',
 'So the one real difference between the two castles is the ______.'],
 ch={0: 'size', 1: 'water', 2: 'sand', 3: 'wind', 4: 'maker'})
