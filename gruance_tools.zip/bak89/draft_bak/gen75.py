# -*- coding: utf-8 -*-
# 원고(d75.I)와 한글(k75_1~6.K)을 합쳐 pending/edits_X75x.py를 만든다.  python3 draft/gen75.py a   (뒷 절반은 b)
import sys, pprint, importlib
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
D = importlib.import_module('d75')
KO = {}
for _i in range(1, 7): KO.update(importlib.import_module('k75_%d' % _i).K)
ns = list(range(0, 15) if tag == 'a' else range(15, 30))
assert all(n in KO for n in ns), [n for n in ns if n not in KO]
from lib import load
_tb = load()[1]
head = '앞' if tag == 'a' else '뒤'
out = ['# -*- coding: utf-8 -*-',
       '# 359번: 40번(요약문 완성) 레벨1 %s 절반 — 지어낸 일상 장면에서 두 경우를 맞세우고, 요약문이 한 경우를 골라 (A)·(B)를 물음(두 낱말 모두 지문에 그대로). 지문 네 문장 + 요약문 한 문장(단문) · 문장당 10~15낱말. 정답 번호는 바탕 그대로' % head,
       'AUTO_SYNC = False', 'E = {}', 'from z40rw import maker', "rw = maker(E, '1')", '']
for n in ns:
    I = D.I[n]; k = KO[n]; a = _tb['40']['1'][n]['answer']; CH = [I['ch'][x] for x in range(5)]
    out.append('# %d번째 (정답 %s)' % (n + 1, '①②③④⑤'[a]))
    out.append('rw(%d, %s,\n   %r,\n   %s,\n   %r,\n   %r,\n   %s,\n   %r,\n   %s,\n   %s,\n   %r)\n' % (n, pprint.pformat(I['S'], width=200), I['SM'], pprint.pformat(CH, width=200), k['kop'], k['kosm'], pprint.pformat(k['steps'], width=200), k['trap'], pprint.pformat(k['reasons'], width=200), pprint.pformat(k['gl'], width=200), k.get('words')))
open('/home/claude/work/pending/edits_X75%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X75%s.py (%d문항)' % (tag, len(ns)))
