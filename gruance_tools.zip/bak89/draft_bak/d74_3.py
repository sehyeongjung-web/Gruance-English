# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 다시 쓰기 영어 원고 n=20~29. 네 문장 · 단문 · 정답 긴 구가 둘째/셋째 문장에 그대로 · 조건 대비 꼴
I = {}
I[20] = dict(S=["Minjae's photo club goes out to take pictures on two Sundays every month.",
 'On the first Sunday, the members take pictures only at the busy fish market.',
 'On the third Sunday, they take pictures only in the big flower garden.',
 "So on the first Sunday, Minjae's club takes pictures only ______."],
 ch={0: 'in the big flower garden', 1: 'on the old stone bridge', 2: 'along the quiet river path', 3: 'at the small train station', 4: 'at the busy fish market'})
I[21] = dict(S=['Every weekend, Sohee bakes cookies with her dad in the kitchen at home.',
 'On Saturdays, she always decorates them by putting a nut on each cookie.',
 'On Sundays, she always decorates them by drawing smiles with pink cream.',
 'So on Sundays, Sohee always decorates the cookies by ______.'],
 ch={0: 'putting a nut on each cookie', 1: 'covering them with white sugar', 2: 'adding colorful candies on top', 3: 'writing short words in chocolate', 4: 'drawing smiles with pink cream'})
I[22] = dict(S=['Every Sunday, Gaeun and her younger brother Siu visit their grandmother in a small town.',
 "Siu's own gift for Grandma is always a bag of fresh oranges.",
 "Gaeun's own gift for Grandma is always a bunch of yellow flowers.",
 "So every Sunday, Gaeun's own gift for Grandma is ______."],
 ch={0: 'a bag of fresh oranges', 1: 'a jar of strawberry jam', 2: 'a bunch of yellow flowers', 3: 'a box of sweet rice cakes', 4: 'a basket of green grapes'})
I[23] = dict(S=["The ice rink near Junseo's house has two special rules for weekends.",
 'Skaters can race each other around the ice only on Saturdays.',
 'Skaters can play hockey with their friends only on Sundays.',
 'So at this rink, skaters can ______ only on Saturdays.'],
 ch={0: 'race each other around the ice', 1: 'play hockey with their friends', 2: 'skate to music from their phones', 3: 'try jumps in the center circle', 4: 'eat snacks on the side benches'})
I[24] = dict(S=['Doyun keeps a small whiteboard on the wall above his homework desk.',
 'On school nights, the board only helps him remember the books for each class.',
 'On Saturdays, the board only helps him review his new English words.',
 'So on school nights, the board only helps Doyun ______.'],
 ch={0: 'review his new English words', 1: 'remember the books for each class', 2: 'finish his science report by Friday', 3: 'check his math answers one more time', 4: 'plan his study time for the week'})
I[25] = dict(S=['Seoa goes to the small library near her apartment twice a week.',
 'On Wednesdays, she goes there only to study for her school tests.',
 'On Saturdays, she goes there only to read stories to little kids.',
 'So on Saturdays, Seoa goes to the library only ______.'],
 ch={0: 'to study for her school tests', 1: 'to meet her friends from school', 2: 'to read stories to little kids', 3: 'to use the computers for homework', 4: 'to borrow comic books for herself'})
I[26] = dict(S=['Grandma Lim has a cup of tea at four every afternoon.',
 'On weekdays, she always drinks her tea in the chair by the window.',
 'On weekends, she drinks it with her grandchildren on the bench in the yard.',
 'So on weekdays, Grandma Lim always has her tea ______.'],
 ch={0: 'at the table in the kitchen', 1: 'in the chair by the window', 2: 'on the bench in the yard', 3: 'at the desk in her bedroom', 4: 'on the steps by the front door'})
I[27] = dict(S=['Sewon wears his white sneakers to school almost every day.',
 'On Fridays, he cleans them only by wiping them with a wet towel.',
 'On Sundays, he cleans them only by brushing them under warm water.',
 'So on Sundays, Sewon cleans his sneakers only by ______.'],
 ch={0: 'brushing them under warm water', 1: 'wiping them with a wet towel', 2: 'washing them in the bathtub', 3: 'rubbing them with a soft eraser', 4: 'putting them in the washing machine'})
I[28] = dict(S=["Every fall, Jiyul's class has a small snack stand at the school festival.",
 'On the first day, the class sells only bags of sweet popcorn.',
 'On the second day, the class sells only cups of hot rice cakes.',
 "So on the second day, Jiyul's class sells only ______."],
 ch={0: 'bags of sweet popcorn', 1: 'slices of cheese pizza', 2: 'bowls of cold noodles', 3: 'cups of fresh lemonade', 4: 'cups of hot rice cakes'})
I[29] = dict(S=["Yerim is a new member of the kids' club at the city museum.",
 'In the club, new members may only draw pictures of the old pots.',
 'Members from last year may give short tours to young visitors.',
 'So as a new member, Yerim may only ______.'],
 ch={0: 'give short tours to young visitors', 1: 'take photos of the dinosaur bones', 2: 'write notes about the old maps', 3: 'draw pictures of the old pots', 4: 'watch short films in the small hall'})
