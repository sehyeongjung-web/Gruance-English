# -*- coding: utf-8 -*-
# 31번(빈칸) 레벨2 뒤 절반 영어 원고 (346번). I[n] = dict(S=[네 문장 — 빈칸은 넷째 문장], ch={자리: 바꾼 선택지})
I = {}
I[15] = dict(S=[
 "Many birds fly far south in autumn, and they fly in a V shape.",
 "Each bird flies a little behind and to the side of the bird in front.",
 "Each bird's wings push the air up, so the next bird flies with less work.",
 "The bird at the very front gets no ______ with its work."])
I[16] = dict(S=[
 "A seed in the soil needs water, warmth and air to start growing.",
 "With water and warmth but no air, the seed stays asleep in the dark soil.",
 "With air and warmth but no water, it does not grow either.",
 "So each one of the three things is ______ to the seed."])
I[17] = dict(S=[
 "Ice is clear like glass, and you can see right to the other side.",
 "Snow is made of countless tiny crystals of ice with air between them.",
 "Each small crystal sends the light off in a different direction.",
 "So light goes straight ______ the ice, but it is turned away by the snow."],
 ch={1: 'down', 2: 'past', 3: 'over'})
I[18] = dict(S=[
 "Bread in a refrigerator goes stale faster than bread on a kitchen counter.",
 "The cold changes the starch in the bread and makes it hard and dry.",
 "A refrigerator is a few degrees above zero, but frozen bread stays fresh for months.",
 "So the worst place for bread is just a few degrees above ______."])
I[19] = dict(S=[
 "Honey can stay good for many years, even in a warm kitchen.",
 "It has very little water in it, and it is a little sour.",
 "Bacteria are tiny living things, and they need water to get bigger and spread.",
 "So in honey, bacteria cannot ______, and the honey stays good."])
I[20] = dict(S=[
 "A wet cloth on a hot forehead feels cooler than a dry cloth.",
 "The water in the cloth slowly dries and goes into the air.",
 "To do this, the water needs energy, and it takes the energy from your skin.",
 "So your skin gives some ______ to the water, and it feels cool."])
I[21] = dict(S=[
 "A whale's call can travel across a whole ocean, and other whales hear it.",
 "Sound goes much farther in the sea than in the air above it.",
 "The tiny parts of water sit near each other and pass the shaking along fast.",
 "So in water the tiny parts are packed more ______ than in air."])
I[22] = dict(S=[
 "A spider walks across its web every day, and it does not get stuck.",
 "Some threads in the web have glue on them, but other threads are plain.",
 "The spider steps carefully, and it uses only the plain threads to walk.",
 "So only some of the threads in the web are ______."])
I[23] = dict(S=[
 "A tortoise cannot step out of its shell, even for a short time.",
 "The shell is joined to the tortoise's ribs and backbone, and it grows with them.",
 "These bones and the shell are one piece, so they cannot be pulled apart.",
 "So the shell is a real part of the tortoise's ______."])
I[24] = dict(S=[
 "In winter the ground freezes, and the roots of a tree cannot take in water.",
 "But leaves lose water into the air all day long.",
 "A tree with leaves would lose a lot of water and get none back.",
 "So the tree cannot ______ the lost water, and it drops its leaves."])
I[25] = dict(S=[
 "A fresh egg lies flat on the bottom of a glass of water.",
 "An old egg stands up on one end, and it holds more air inside.",
 "The shell is not broken at all, but air still comes in slowly.",
 "So the shell must have many tiny ______ all over it."],
 ch={0: 'spots', 1: 'holes', 2: 'layers', 3: 'cracks', 4: 'corners'})
I[26] = dict(S=[
 "A compass needle points to magnetic north, not to true north.",
 "The two north points are a few degrees apart, and the gap slowly changes.",
 "A good map therefore gives you the number of degrees to add or take away.",
 "In other words, the map prints a ______ for the compass."])
I[27] = dict(S=[
 "Soap is made of tiny parts, and each part has two ends.",
 "One end likes water, but the other end likes grease and oil.",
 "In dirty water, one end pulls toward the water, and the other toward the dirt.",
 "So the two ends of each tiny part pull in ______ directions."],
 ch={0: 'same', 1: 'slow', 2: 'upward', 3: 'many', 4: 'opposite'})
I[28] = dict(S=[
 "The wind hits the flat face of a kite and pushes the kite up.",
 "A kite without a tail turns and spins in the air.",
 "A long tail is light, but it pulls back against the air.",
 "In short, the tail gives the kite some ______ against the air."])
I[29] = dict(S=[
 "At night, many moths seem to keep one angle to the moon and fly straight.",
 "The moon is very far away, so the angle hardly changes.",
 "A lamp is not far away, so the angle changes at every turn.",
 "A lamp is too ______ for this trick, so the moth circles around it."])
