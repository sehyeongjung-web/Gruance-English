# 33번 레벨1 새 꼴 본보기 (꼴만 보고, 글감은 쓰지 말 것)
I = {}
I[0] = dict(S=['Mina waters the plants in her small garden every day.',
 'On school days, she does this easy job before breakfast.',
 'On Sundays, she has more time and waters them in the afternoon.',
 'So on school days, Mina always waters her little plants ______.'],
 ch={0:'after lunch',1:'in the afternoon',2:'before breakfast',3:'at midnight',4:'during dinner'})
I[1] = dict(S=['Every Saturday, Tom takes a big bag to the corner shop.',
 'His grandmother gives him some money and a short list first.',
 'At the shop, Tom uses the money to buy bread and eggs.',
 'So every Saturday Tom goes to the corner shop ______.'],
 ch={0:'to buy bread and eggs',1:'to meet his friends',2:'to sell old books',3:'to fix a bicycle',4:'to see a doctor'})
I[2] = dict(S=['Dana packs her own lunch box on busy school mornings.',
 'Every day she puts two boiled eggs in the box.',
 'Her little brother likes a cheese sandwich more than eggs.',
 'So on school days, Dana eats ______ at noon.'],
 ch={0:'a cheese sandwich',1:'a bowl of rice',2:'two boiled eggs',3:'a plate of noodles',4:'three fried fish'})
