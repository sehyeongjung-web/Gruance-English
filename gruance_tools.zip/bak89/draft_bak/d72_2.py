# -*- coding: utf-8 -*-
# 32번(빈칸 — 낱말) 레벨1 다시 쓰기 원고 둘째 묶음(문항 10~19). 단문 네 문장 · 정답 낱말이 첫째~셋째 문장에 그대로 나오되 빈칸 문장만으로는 정해지지 않는 꼴.
I = {}
# n11 해·달·하늘 — 때(몇 시)
I[10] = dict(S=['On a cloudy October night, Jae looked for the moon at eight, ten and twelve.',
 'At eight and at twelve, thick gray clouds hid the moon from him.',
 "At ten o'clock, he saw a bright round moon above the dark hill.",
 "So that night, Jae saw the moon only at ______ o'clock."],
 ch={0: 'ten', 1: 'eight', 2: 'twelve', 3: 'nine', 4: 'eleven'})
# n12 곤충 — 물건(먹이)
I[11] = dict(S=['Yeri put some bread, an apple slice and some cheese near an ant hill.',
 'After twenty minutes, many ants were all over the small piece of cheese.',
 'Only a few ants walked onto the bread and the apple slice.',
 'So out of the three foods, the ants liked the ______ the most.'],
 ch={0: 'bread', 1: 'apple', 2: 'cookie', 3: 'cheese', 4: 'candy'})
# n13 바다·바닷가 — 곳(어디 아래)
I[12] = dict(S=['One morning on the beach, Yuri found a small crab beside a big rock.',
 'The crab ran quickly across the wet sand to an old boat.',
 'Then it hid under the old boat for the rest of the morning.',
 'So in the end, the little crab stayed under the ______.'],
 ch={0: 'rock', 1: 'sand', 2: 'boat', 3: 'shell', 4: 'net'})
# n14 씨앗·열매 — 곳(어디에 내려앉았나)
I[13] = dict(S=['On a windy afternoon, Sujin blew on a white dandelion in her yard.',
 'The wind carried its seeds over the fence and across the road.',
 'Most of the seeds came down in a big field of grass.',
 "So most of Sujin's dandelion seeds landed in the ______."],
 ch={0: 'yard', 1: 'road', 2: 'garden', 3: 'field', 4: 'forest'})
# n15 전지·전구 — 까닭(무엇이 고장)
I[14] = dict(S=["On the first night of her trip, Minji's old flashlight gave no light.",
 'Two new batteries and a new bulb did not help the flashlight at all.',
 'The next day, a new switch made the old flashlight bright again.',
 'So the flashlight did not work because of a bad ______.'],
 ch={0: 'battery', 1: 'bulb', 2: 'wire', 3: 'spring', 4: 'switch'})
# n16 공기·바람 — 상태 형용사(색)
I[15] = dict(S=['Taeho blew up a red, a green and a yellow balloon for the party.',
 'The next morning, the red and the green balloons were still big and round.',
 'Only the yellow balloon lay small and soft on the floor.',
 'So the ______ balloon lost the most air during the night.'],
 ch={0: 'red', 1: 'green', 2: 'blue', 3: 'yellow', 4: 'pink'})
# n17 연못 물고기 — 동사
I[16] = dict(S=['Hana dropped a small piece of bread into the pond at the park.',
 'A big orange fish swam over and touched the bread with its mouth.',
 'Then the fish left the bread on the water and swam away.',
 "So in the end, the big orange fish ______ Hana's bread."],
 ch={0: 'ate', 1: 'left', 2: 'took', 3: 'pulled', 4: 'carried'})
# n18 눈·서리 — 동물
I[17] = dict(S=['Early on Monday, Dami found small tracks in the new snow in her yard.',
 'Her cat and her dog were inside the house all night.',
 'At the end of the tracks, she saw a gray mouse under the back steps.',
 "So the tracks in the snow in Dami's yard came from a ______."],
 ch={0: 'cat', 1: 'dog', 2: 'rabbit', 3: 'chicken', 4: 'mouse'})
# n19 거울·유리 — 사람
I[18] = dict(S=["Jun's school put a round mirror at a corner of the long hall.",
 'On Monday, Jun stood next to his teacher at the classroom door.',
 'In the mirror, Jun saw the school nurse near the stairs around the corner.',
 'So the mirror showed Jun the ______ around the corner.'],
 ch={0: 'teacher', 1: 'nurse', 2: 'cook', 3: 'coach', 4: 'doctor'})
# n20 부엌 과학 — 물건(채소)
I[19] = dict(S=['Sumi weighed an onion, a potato and a carrot on the kitchen scale.',
 'The onion and the carrot each weighed about one hundred grams.',
 'The big potato weighed almost two hundred grams on the same scale.',
 "So the heaviest of the three vegetables on Sumi's scale was the ______."],
 ch={0: 'onion', 1: 'potato', 2: 'carrot', 3: 'cucumber', 4: 'eggplant'})
