# 32번 레벨1 새 꼴 본보기 (꼴만 보고, 글감은 쓰지 말 것)
I = {}
I[0] = dict(S=['Ben put a bean, a pea and a corn seed in three jars.',
 'He gave each jar the same water every morning for one week.',
 'On Friday, only the bean showed a green stem above the soil.',
 'So the seed with the tallest stem in his jars was the ______.'],
 ch={0:'bean',1:'pea',2:'corn',3:'rice',4:'wheat'})
I[1] = dict(S=['Sora set a cup, a plate and a bowl in the sun at nine o\'clock.',
 'She poured the same amount of water into each one.',
 'By noon, only the plate had no water left in it.',
 'So the water dried up the fastest in the ______.'],
 ch={0:'cup',1:'plate',2:'bowl',3:'pot',4:'glass'})
I[2] = dict(S=['Jun read the thermometer in his yard in the morning, at noon and at night.',
 'It showed ten degrees in the morning, twenty at noon and twelve at night.',
 'The warm sun at noon had made the air hotter than at any other time.',
 'So the air in his yard was the coolest in the ______.'],
 ch={0:'afternoon',1:'noon',2:'night',3:'morning',4:'evening'})
