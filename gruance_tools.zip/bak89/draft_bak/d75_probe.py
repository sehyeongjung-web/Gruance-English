# 40번 레벨1 새 꼴 본보기 (꼴만 보고, 글감은 쓰지 말 것). 정답 자리는 바탕 그대로: n=0→2, n=1→0, n=2→4
I = {}
I[0] = dict(S=["Minji's family takes good care of their small dog, Bori.",
 'On weekdays, Minji walks Bori in the park after school.',
 'On weekends, her father takes Bori to the river in the morning.',
 'Bori loves both walks and always sleeps well at night.'],
 SM="On (A) ______, Bori goes to the (B) ______ with Minji's father.",
 ch={0:'weekdays - river',1:'weekends - park',2:'weekends - river',3:'weekdays - park',4:'holidays - park'})
I[1] = dict(S=["Sena and her younger brother help at their aunt's flower shop.",
 'Every morning, Sena waters the roses near the front window.',
 'In the evening, her brother waters the tulips in the back room.',
 'Their aunt gives them fresh bread for their hard work.'],
 SM="Sena's job at the shop is to water the (A) ______ every (B) ______.",
 ch={0:'roses - morning',1:'tulips - morning',2:'roses - evening',3:'tulips - evening',4:'lilies - evening'})
I[2] = dict(S=['Two friends, Dami and Yuna, take the same art class.',
 'In class, Dami always paints the ocean with bright blue colors.',
 'In class, Yuna always paints the forest with soft green colors.',
 'Their teacher hangs their best pictures on the classroom wall.'],
 SM='In art class, Yuna paints the (A) ______ in (B) ______ colors.',
 ch={0:'ocean - green',1:'forest - blue',2:'ocean - blue',3:'flowers - blue',4:'forest - green'})
