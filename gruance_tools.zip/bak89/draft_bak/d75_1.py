# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨1 다시 쓰기 — 맡은 열 문항 n=0~9 (정답 자리: 2 0 4 1 3 1 3 1 2 1)
I = {}
I[0] = dict(S=["Jiho and his older sister Nayeon spend every August on their grandparents' farm.",
 'Every morning, Nayeon feeds the chickens in the field near the big tree.',
 'Every evening, Jiho feeds the pigs in the small yard behind the house.',
 'Grandma bakes sweet bread for the two hard workers every Sunday.'],
 SM="On his grandparents' farm, Jiho takes care of the (A) ______ every (B) ______.",
 ch={0: 'chickens - evening', 1: 'pigs - morning', 2: 'pigs - evening', 3: 'cows - morning', 4: 'chickens - morning'})
I[1] = dict(S=["Sumin's garden club looks after two small gardens at her school.",
 'The garden by the front gate has flowers in four long rows.',
 'The garden behind the library has potatoes in six short rows.',
 'Every Friday after school, the club members water both gardens together.'],
 SM="Behind the school library, Sumin's club grows (A) ______ in (B) ______ rows.",
 ch={0: 'potatoes - six', 1: 'flowers - four', 2: 'flowers - six', 3: 'trees - four', 4: 'potatoes - four'})
I[2] = dict(S=['Siwoo and Bomi look after Max, the little hamster in their classroom.',
 'Siwoo gives Max a few seeds from a paper cup after lunch.',
 'Bomi gives Max small pieces of fresh fruit after school every day.',
 'Max often sleeps in his little wooden house during class.'],
 SM='In their classroom, Bomi feeds Max some (A) ______ after (B) ______.',
 ch={0: 'seeds - lunch', 1: 'seeds - school', 2: 'rice - lunch', 3: 'fruit - lunch', 4: 'fruit - school'})
I[3] = dict(S=["Seho's family often takes long car trips to the sea on holidays.",
 'On these trips, Seho always sits in the back seat with his camera.',
 'His older sister Gaeun always sits in the front seat with a book.',
 'Their mom drives the whole way with soft music on the radio.'],
 SM='On family car trips, Gaeun rides in the (A) ______ seat with a (B) ______.',
 ch={0: 'back - camera', 1: 'front - book', 2: 'middle - camera', 3: 'back - book', 4: 'front - camera'})
I[4] = dict(S=['Jaeho goes to the morning exercise club at his school twice a week.',
 "On Tuesdays, Jaeho's English teacher leads the club on the big field.",
 'On Fridays, a young coach from the city leads the club on the tennis court.',
 'After exercise, the members drink cold water and go to class.'],
 SM="On Friday mornings, Jaeho's club exercises with a (A) ______ on the (B) ______.",
 ch={0: 'teacher - field', 1: 'nurse - field', 2: 'teacher - court', 3: 'coach - court', 4: 'coach - field'})
I[5] = dict(S=['Last weekend, Yujin and her dad painted the old fence around their yard.',
 'Near the road, they painted the fence blue with little white birds.',
 'Near the house, they painted the fence green with little white stars.',
 "Yujin's mom took many photos of the new fence for Grandma."],
 SM='The part of the fence near the house is now (A) ______ with white (B) ______.',
 ch={0: 'blue - birds', 1: 'green - stars', 2: 'yellow - birds', 3: 'blue - stars', 4: 'green - birds'})
I[6] = dict(S=["Taemin's apartment has its recycling day every Wednesday behind the main building.",
 'In the morning, Taemin carries the cans down in an old box.',
 'In the evening, his dad carries the paper down in a big bag.',
 'The yard behind the building looks clean and neat on Thursday mornings.'],
 SM="On recycling day, Taemin's dad takes the (A) ______ down in a (B) ______.",
 ch={0: 'cans - bag', 1: 'bottles - box', 2: 'paper - box', 3: 'paper - bag', 4: 'cans - box'})
I[7] = dict(S=["Haeun's apartment has a little free library in the lobby on the first floor.",
 "Last month, Haeun's aunt put her old novels on the top shelf.",
 'A young teacher from the third floor put her magazines on the bottom shelf.',
 'Now many neighbors borrow books from the little library every week.'],
 SM="In the lobby library, the (A) ______ from Haeun's aunt sit on the (B) ______ shelf.",
 ch={0: 'magazines - top', 1: 'novels - top', 2: 'poems - bottom', 3: 'magazines - bottom', 4: 'novels - bottom'})
I[8] = dict(S=["Every Saturday morning, Dayeon helps at her uncle's small cafe near the river.",
 'Dayeon brings fresh bread from the market to the cafe by bus.',
 "Dayeon's uncle brings cold milk from a farm to the cafe by bike.",
 'At ten, the cafe opens its doors for the first guests.'],
 SM="Every Saturday, Dayeon's uncle takes (A) ______ to the cafe by (B) ______.",
 ch={0: 'bread - bike', 1: 'cheese - bus', 2: 'milk - bike', 3: 'bread - bus', 4: 'milk - bus'})
I[9] = dict(S=["Yeonjun's school has its sports day on a sunny Friday in May.",
 'In the morning, the students run a long race with their parents.',
 'In the afternoon, the students play a ball game with their teachers.',
 'At the end of the day, everyone sings the school song together.'],
 SM='On sports day, Yeonjun joins a (A) ______ with the (B) ______ in the afternoon.',
 ch={0: 'race - teachers', 1: 'game - teachers', 2: 'dance - parents', 3: 'race - parents', 4: 'game - parents'})
