# 부분 원고(문항 몇 개만 든 d 파일)의 보기 길이 점검: python3 draft/lenpart.py <유형> <레벨> <d파일>
# 정답 자리는 바탕 index.html 에서 읽는다. 규칙은 verify.py 길이 점검표와 같다.
import sys, importlib.util
sys.path.insert(0,'/home/claude/work')
from lib import load
T,L,dfile=sys.argv[1:4]
_,tb,_=load('/home/claude/Gruance-English/index.html')
sp=importlib.util.spec_from_file_location('d',dfile); d=importlib.util.module_from_spec(sp); sp.loader.exec_module(d)
r1=r2=b=c=e=0; ns=sorted(d.I)
for n in ns:
    k=tb[T][L][n]['answer']; ch=[d.I[n]['ch'][i] for i in range(5)]; Lk=len(ch[k])
    r=1+sum(len(x)>Lk for i,x in enumerate(ch) if i!=k)
    ls=sorted((len(x) for x in ch),reverse=True)
    B=bool(ls[1] and ls[0]/ls[1]>=1.3); med=(ls[2]+ls[3])/2; C=bool(med and ls[0]/med>=1.4 and ls[0]-med>=5)
    oth=sorted(len(x) for i,x in enumerate(ch) if i!=k); E=False
    if Lk<oth[0]:
        om=(oth[1]+oth[2])/2; E=bool(Lk and om/Lk>=1.4 and om-Lk>=5)
    r1+=r==1; r2+=r<=2; b+=B; c+=C; e+=E
    print('%2d R%d%s%s%s key=%-10s %s'%(n,r,' B' if B else '',' C' if C else '',' E' if E else '',ch[k],' '.join('%s(%d)'%(x,len(x)) for x in ch)))
print('문항 %d · 정답이 가장 긴(동률 포함) %d · 첫째·둘째로 긴 %d · B %d · C %d · E %d'%(len(ns),r1,r2,b,c,e))
