# -*- coding: utf-8 -*-
# 36-37번(글의 순서) 레벨1~3을 레벨 기준으로 다시 쓸 때의 도우미 (333번)
#   from z3637common import maker;  rw = maker(E, '1')
#   rw(n, 주어진 글, {'A': [문장…], 'B': […], 'C': […]}, 주어진 글 해석, {'A': [해석…], …}, [풀이 1)~4) 네 줄], 헷갈리는 곳, [선택지별 해설 다섯], 낱말 줄(선택))
#   - 정답 번호·선택지·발문은 바탕 그대로. 글의 이름표 (A)(B)(C)를 정답 순서에 맞게 붙여서 씀
#   - 풀이·해설에서 지문을 그대로 옮긴 말은 «…»로 쓰면 큰따옴표로 바뀌고, 지문에 없으면 멈춤
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
_s, _tb, _te = load()
T = '36_37'
TIP3 = _te[T]['3'][0]['walk'].split('\n\n【이 문제에 적용】')[0]      # 레벨1~3이 함께 쓰는 「~요」 말투 요령 네 줄
assert TIP3.startswith('【글의 순서 요령】') and TIP3.count('\n') == 4
def lay(g, P): return g + "\n\n" + "\n".join("(%s) %s" % (k, " ".join(P[k])) for k in 'ABC')
def maker(E, lv):
    def rw(n, g, P, kg, K, steps, confuse, cn, words=None):
        it = _tb[T][lv][n]; ch = it['choices']; a = it['answer']; text = lay(g, P)
        assert len(steps) == 4 and all(steps[i].startswith('%d) ' % (i + 1)) for i in range(4)), (n, '풀이 네 줄')
        assert len(cn) == 5 and all(len(P[k]) == len(K[k]) for k in 'ABC'), (n, '해설 다섯 · 해석 문장 수')
        def q(tx):
            for m in re.findall(r'«([^»]*)»', tx): assert m in text, (n, '지문에 없는 인용', m)
            return tx.replace('«', '"').replace('»', '"')
        order = re.findall(r'\(([ABC])\)', ch[a]); assert sorted(order) == ['A', 'B', 'C']
        for i, k in enumerate(order): assert steps[i + 1].startswith('%d) %s 글 (%s)' % (i + 2, '첫째 둘째 셋째'.split()[i], k)), (n, '풀이 줄의 글 이름', steps[i + 1][:20])
        assert steps[3].rstrip().endswith('순서는 %s예요.' % ch[a]), (n, '풀이 끝')
        walk = TIP3 + '\n\n【이 문제에 적용】\n' + '\n'.join(q(x) for x in steps) + '\n\n【헷갈리는 곳】\n' + q(confuse)
        if words: walk += '\n\n📌 낱말: ' + words
        cns = [("정답이에요. " if k == a else "") + "'" + ch[k] + "' — " + q(cn[k]) for k in range(5)]
        E[(T, lv, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(ch), 'ko': lay(kg, K), 'walk': walk, 'cn': cns}}
    return rw
