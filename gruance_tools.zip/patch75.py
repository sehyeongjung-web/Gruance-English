import sys
def patch(p, reps):
    s=open(p,encoding='utf-8').read()
    for o,n in reps:
        c=s.count(o)
        assert c>=1,(p,o[:60])
        s=s.replace(o,n)
    open(p,'w',encoding='utf-8').write(s)
