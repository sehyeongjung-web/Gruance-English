# -*- coding: utf-8 -*-
# 363번: 22번(요지) 레벨1 — 공통 도우미 (z20common을 본뜸)
#   rw(n, 정답 자리, 지문, [선택지 다섯], 해석, 주장 문장, 그 해석, 몇째, 까닭, 바꾸어 말한 곳, 낱말, [선택지별 까닭 다섯], lead=None)
# 해설의 꼴은 20번이 써 오던 꼴(① 주장 문장 찾기 → ② 까닭 → ③ 선택지와 잇기 → 📌 낱말)을 그대로 따르되 조금 넉넉하게 씀. 말끝은 「~어요」
import sys; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
ORD = {1: '첫째', 2: '둘째', 3: '셋째', 4: '넷째', 5: '다섯째'}
LEAD = "① 요지는 글이 결국 말하려는 한 가지예요. 겪은 일을 묶어 누구에게나 통하는 말로 정리한 문장을 찾아요. 이 글에서는 %s 문장이에요."
def maker(E, T='22', LV='1', NS=4):
    def rw(n, ans, text, choices, ko, claim, claim_ko, pos, why, mapping, words, cn, lead=None):
        it = _tb[T][LV][n]
        assert it['answer'] == ans, (n, '정답 자리가 문항과 다름')
        assert len(choices) == 5 == len(set(choices)) == len(cn), n
        sents = [s.strip() for s in __import__('re').split(r'(?<=[.?!])\s+', text)]
        assert len(sents) == NS, (n, '문장 수', len(sents))
        assert sents[pos - 1] == claim, (n, '요지 문장의 자리', sents[pos - 1])
        assert all('정답' not in c for c in cn) and '정답' not in why + mapping, (n, '까닭에 정답이라는 말')
        W4 = ['첫째', '둘째', '셋째', '넷째', '다섯째']
        def q(tx):
            for m in __import__('re').findall(r'«([^»]*)»', tx): assert m in text, (n, '지문에 없는 인용', m)
            for who, m in __import__('re').findall(r'(첫째|둘째|셋째|넷째|다섯째) 문장[^«\n]{0,14}«([^»]*)»', tx):
                assert m in sents[W4.index(who)], (n, '문장 자리가 어긋남', who, m)
            return tx.replace('«', '"').replace('»', '"')
        why, mapping, cn = q(why), q(mapping), [q(c) for c in cn]
        walk = (lead or LEAD % ORD[pos]) + '\n"%s" (%s)\n② %s\n③ 그러니까 글의 요지는 \'%s\'는 거예요. %s\n📌 낱말: %s' % (claim, claim_ko, why, choices[ans], mapping, words)
        out = [("정답이에요! " if k == ans else "") + "'%s' — %s" % (choices[k], cn[k]) for k in range(5)]
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(choices), 'ko': ko, 'walk': walk, 'cn': out}}
    return rw
