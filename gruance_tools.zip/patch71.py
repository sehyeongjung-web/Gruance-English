import re,sys,glob
FILES=sorted(glob.glob('draft/k71_*.py'))
src={f:open(f,encoding='utf-8').read() for f in FILES}
def blk(f,n):
    t=src[f]; ms=list(re.finditer(r'^K\[(\d+)\] = dict\(',t,re.M))
    for i,m in enumerate(ms):
        if int(m.group(1))==n:
            end=ms[i+1].start() if i+1<len(ms) else len(t)
            return m.start(),end
    return None
def where(n):
    for f in FILES:
        if blk(f,n): return f
def patch(n,reps):
    f=where(n); s,e=blk(f,n); b=src[f][s:e]
    for r in reps:
        old,new=r[0],r[1]; cnt=r[2] if len(r)>2 else 1
        c=b.count(old)
        if cnt is None: assert c>=1,(n,old)
        else: assert c==cnt,(n,old,c,cnt)
        b=b.replace(old,new)
    src[f]=src[f][:s]+b+src[f][e:]
# n4
patch(4,[("「교통 혼잡」도 눈 오는 날에 떠올리기 쉬워 끌리지만,","「얼음」도 눈 오는 날에 떠올리기 쉬워 끌리지만, 얼음은 글에 나오지 않고,")])
# n1
patch(1,[("빈칸 문장도 벤의 집 근처라고 했어요.","빈칸 문장의 «near Ben's house»(벤의 집 근처)는 셋째 문장의 이웃의 마당과 이어져요.")])
# n5
patch(5,[("깊은 물은 둘째 문장과 맞지 않아요.","또 넷째 문장의 'So'(그래서)는 셋째 문장의 'very cold'(매우 차가운)에 이어지니, 진이 수영하지 않은 까닭은 깊이가 아니라 차가움이에요.")])
# n6
patch(6,[("사무실까지 줄곧 ______다.","사무실까지 줄곧 ______.")])
# n7
patch(7,[("가끔 아침을 걸렀다","가끔 아침밥을 걸렀다",2)])
# n8
patch(8,[("(그래서 민수는 새 …을 메고 갔다)","(그래서 민수는 새 … 메고 갔다)"),('("초록색",','("초록색의",'),('("갈색",','("갈색의",')])
# n10 형제 -> 형
f=where(10); s,e=blk(f,10); b=src[f][s:e]
M={'"':'"',')':')','\n':'\n','는':'은','가':'이','와':'과','를':'을','도':'도','」':'」',',':',',"'":"'",' ':' '}
def rep(m):
    c=m.group(1); assert c in M,(c,)
    return '형'+M[c]
b2=re.sub(r'형제(.)',rep,b)
assert '형제' not in b2
src[f]=src[f][:s]+b2+src[f][e:]
# n11
patch(11,[("(글에 나오는 곳은 호텔과 공항이에요)","(글에 나오는 제주의 장소는 호텔과 공항이에요)")])
# n16
patch(16,[("받으려고 ______기이다.","받으려고 ______이다."),
 ('("앉다",','("앉기",'),('("짖다",','("짖기",'),('("춤추다",','("춤추기",'),('("점프하다",','("점프하기",'),('("손을 흔들다",','("손 흔들기",'),
 ("「앉다」나 「짖다」가","「앉기」나 「짖기」가"),("= 'jump'(점프하다).","= 'jump'(점프하기).")])
# n20
patch(20,[("새 둥지라면 나무가","새가 짓는 둥지라면 나무가")])
f=where(20); s,e=blk(f,20); b=src[f][s:e]
print('n20 새 둥지 count',b.count('새 둥지'))
b=b.replace('새 둥지','새로운 둥지')
src[f]=src[f][:s]+b+src[f][e:]
# n22
f=where(22); s,e=blk(f,22); b=src[f][s:e]; print('n22 누이',b.count('누이')); b=b.replace('누이','누나'); src[f]=src[f][:s]+b+src[f][e:]
patch(22,[("(그래서 그 중요한 날, 엄마는 새)","(그래서 그 중요한 날, 엄마는 새 …을 받았다)")])
# n25
patch(25,[("(그래서 코코는 이제 밝은)","(그래서 코코는 이제 밝은 … 집에서 잔다)"),("(마당에 있는 집에서 잔다)","(마당에 있는 집)"),("'yellow'(노란)로","'yellow'(노란색)로",2)])
# n26
patch(26,[("빈칸 문장의 주어는 'Dad'(아빠)예요.\"),","빈칸 문장의 주어는 'Dad'(아빠)예요. 셋째 문장에서 아빠가 태민이와 함께 세 시간 동안 한 일은 'swam'(수영했다)이에요.\"),")])
# n29
patch(29,[("(그래서 은비의 첫째 날 스키 사진은 모두)","(그래서 은비의 첫째 날 스키 사진은 모두 … 하늘을 보여 준다)"),("'sky'(하늘을 보여 준다)","'sky'(하늘)")])
# 보증해요
for f in FILES:
    t=src[f]; 
    for a in ("»가 보증해요.","»이 보증해요."):
        src[f]=src[f].replace(a,a.replace('보증해요','근거예요'))
for f in FILES:
    open(f,'w',encoding='utf-8').write(src[f])
print('보증' , sum(src[f].count('보증') for f in FILES))
