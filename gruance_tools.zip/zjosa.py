# -*- coding: utf-8 -*-
# ★ 쓰지 말 것(336번): 이 도구는 "괄호 안 한글" 기준이라 바탕(괄호 앞 낱말 기준)을 오히려 망침. → zjosa2.py
# 괄호·꺾쇠 뒤 조사 확인/고침 (은/는 · 이/가 · 을/를 · 와/과 · 으로/로 · 이라고/라고 · 이에요/예요)
#   python3 zjosa.py 파일…            → 어긋난 곳을 보여 줌
#   python3 zjosa.py --fix 파일…      → 고쳐 씀
# 앞 글자가 우리말(한글)로 끝나는 「(…)」·「「…」」 뒤의 조사만 봄. 「)」 앞이 마침표 등이면(인용문) 건너뜀.
import re, sys
PAIRS = [('은', '는'), ('이', '가'), ('을', '를'), ('과', '와'), ('으로', '로'), ('이라고', '라고'), ('이에요', '예요')]
FORM = {}
for with_b, no_b in PAIRS:
    FORM[with_b] = (with_b, no_b); FORM[no_b] = (with_b, no_b)
ALT = sorted(FORM, key=len, reverse=True)
PAT = re.compile(r'(\([^()\n]*?([가-힣])\)|「[^」\n]*?([가-힣])」)(' + '|'.join(ALT) + r')(?![가-힣])')
def batchim(ch): return (ord(ch) - 0xAC00) % 28
def fix(s):
    out = []; n = [0]
    def rep(m):
        ch = m.group(2) or m.group(3); p = m.group(4); b = batchim(ch)
        with_b, no_b = FORM[p]
        if with_b == '으로': want = with_b if (b != 0 and b != 8) else no_b
        else: want = with_b if b != 0 else no_b
        if want != p:
            n[0] += 1; out.append((m.group(1)[-12:], p, want))
        return m.group(1) + want
    return PAT.sub(rep, s), out
if __name__ == '__main__':
    do = '--fix' in sys.argv; tot = 0
    for p in [a for a in sys.argv[1:] if a != '--fix']:
        s = open(p, encoding='utf-8').read(); t, ch = fix(s); tot += len(ch)
        for x in ch: print('%s: …%s %s → %s' % (p.split('/')[-1], x[0], x[1], x[2]))
        if do and ch: open(p, 'w', encoding='utf-8').write(t)
    print('어긋난 조사 %d곳%s' % (tot, ' (고침)' if do else ''))
