#!/bin/bash
# 350·351번: 32번 레벨2(새 꼴) — 원고에서 수정안 만들기 → 조사 → 빌드 → 자체 검사
cd /home/claude/work
python3 draft/gen69.py a && python3 draft/gen69.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X69a.py pending/edits_X69b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X67a,edits_X67b,edits_X69a,edits_X69b out/index.html | tail -3
