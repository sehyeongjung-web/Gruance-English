# -*- coding: utf-8 -*-
# 31~34번(빈칸 추론) 레벨9 해설 두텁게 — 공통 도우미 (183번~)
#   mk = maker(E, '31')
#   mk(n, 정답 자리(0~4), [적용 네 줄], 끌리는 오답, [(선택지 해석, 까닭) × 5])
# - 선택지 영어는 문항에서 자동으로 가져오고, 정답 자리에는 "정답입니다."를 붙임
# - 원고의 «…»는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜
# - 원고가 생각한 정답 자리가 문항과 다르거나, 꼴이 어긋나거나, 까닭에 "정답"이라는 말이 있으면 멈춤
import sys; sys.path.insert(0, '.')
from lib import load as _load
_tb = _load()[1]
TIP = ("【빈칸 추론 요령】\n"
       "첫째, 빈칸이 든 문장부터 읽습니다. 무엇을 묻는지 한 줄로 정하고, 부정하는 말(not, no, nothing, cannot)이 있는지 봅니다.\n"
       "둘째, 빈칸 문장의 틀(not A but B, A rather than B, less A than B)과 이어 주는 말(therefore, which suggests, which means)로 빈칸이 어느 편인지 정합니다.\n"
       "셋째, 짝꿍 문장을 찾습니다. 빈칸의 답은 지문 안 다른 곳에 다른 말로 한 번 더 나옵니다. 빈칸이 끝 문장에 있으면 바로 앞 문장과 첫 문장부터 봅니다.\n"
       "넷째, 짝꿍 문장을 다른 낱말로 묶은 선택지를 고릅니다. 지문 낱말이 들어 있다고, 상식으로 그럴듯하다고 고르지 않습니다.")
def _q(x): return x.replace('«', '"').replace('»', '"')
def W(steps, traps):
    return TIP + "\n\n【이 문제에 적용】\n" + "\n".join(steps) + "\n\n【끌리는 오답】\n" + traps
def maker(E, t, lv='9'):
    def mk(n, ans, steps, traps, cn, ch=None, ans_ok=False):
        # ans_ok=True: 정답 선택지의 낱말까지 고치는 문항(인계문서에 까닭을 적은 것만)
        # ch: 같은 수정안에서 오답 선택지를 바꾸는 문항이면 {자리: '새 선택지'} — 해설 머리에 새 선택지가 들어가고 문항에도 반영됨
        it = dict(_tb[t][lv][n]); it['choices'] = list(it['choices'])
        for kk, vv in (ch or {}).items():
            assert kk != ans or ans_ok, (n, '정답 선택지는 바꾸지 않음'); it['choices'][kk] = vv
        assert it['answer'] == ans, ('원고의 정답 자리가 문항과 다름', t, n, it['answer'], ans)
        assert len(cn) == 5 and len(steps) == 4, (n, '개수')
        assert steps[0].startswith('1) 빈칸 문장:') and steps[1].startswith('2) ') and steps[2].startswith('3) ') and steps[3].startswith('4) 묶기:'), (n, '적용 줄의 머리말')
        assert any('짝꿍 문장' in s for s in steps), (n, '짝꿍 문장이 없음')
        out = {}
        for k, (ko, why) in enumerate(cn):
            assert '정답' not in why and '정답' not in ko, (n, k, '까닭에 "정답"이라는 말')
            out[k] = ("정답입니다. " if k == ans else "") + "'%s' (%s) — %s" % (it['choices'][k], ko, _q(why))
        assert (t, lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(t, lv, n)] = {'walk': W([_q(x) for x in steps], _q(traps)), 'cn': out}
        if ch: E[(t, lv, n)]['ch'] = dict(ch)
        if ans_ok: E[(t, lv, n)]['ans_ok'] = True
    return mk
