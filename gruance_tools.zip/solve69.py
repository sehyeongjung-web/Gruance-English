# -*- coding: utf-8 -*-
# 32번 레벨2 다시 쓰기(349번 이후): 영어 원고 d69_*.py 를 합쳐 풀이꾼용 문제지 셋을 만든다
#   python3 solve69.py <폴더> [파일들...]   (기본 d69_1,d69_2,d69_3)  → blind.txt · last.txt · audit.txt
import sys, os, importlib.util
sys.path.insert(0,'/home/claude/work')
from lib import load
_,tb,_ = load('/home/claude/Gruance-English/index.html')
folder = sys.argv[1]; files = sys.argv[2:] or ['d69_1','d69_2','d69_3','d69_fix']
I = {}
for f in files:
    spec = importlib.util.spec_from_file_location(f, '/home/claude/work/draft/%s.py' % f); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); I.update(m.I)
os.makedirs(folder, exist_ok=True)
B=[];L=[];A=[]
for n in sorted(I):
    it = I[n]; ans = tb['32']['2'][n]['answer']
    ch = '  '.join('%s %s' % ('①②③④⑤'[k], it['ch'][k]) for k in range(5))
    B.append('[%d]\n%s\n%s\n' % (n+1, ' '.join(it['S']), ch))
    L.append('[%d] %s\n   %s\n' % (n+1, it['S'][3], ch))
    A.append('[%d]  KEY=%s %s\n%s\n%s\n' % (n+1, '①②③④⑤'[ans], it['ch'][ans], ' '.join(it['S']), ch))
for name, rows in (('blind', B), ('last', L), ('audit', A)):
    open(os.path.join(folder, name + '.txt'), 'w', encoding='utf-8').write('\n'.join(rows))
print('ok', len(I))
