# -*- coding: utf-8 -*-
import os
def rd(p): return open(p, encoding='utf-8').read()
def wr(p, s): open(p, 'w', encoding='utf-8').write(s)
def rep(s, old, new, cnt=1):
    assert s.count(old) == cnt, (old[:70], s.count(old)); return s.replace(old, new)
W = '/home/claude/work/'; SIZE = '{:,}'.format(os.path.getsize(W + 'out/index.html'))
g = rd(W + 'LEVEL_GUIDE.md')
g = rep(g, '18번 레벨1은 360번에 마침', '18번 레벨1은 360번 · 19번 레벨1은 361번에 마침')
sec = '''## 19번(심경 변화) 레벨1의 꼴 (361번 — 서른 문항 다시 씀)
※ 옛 판은 세 문장 · 문장당 8.8낱말 · 이은 문장과 종속절이 섞임(`regauge` 어긋남), 보기도 정답 짝만 글과 맞아 찍혔음. 361번에 이 꼴로 다시 씀 → `regauge.py 19 1` **맞음**.
- 틀: **네 문장 · 단문 100% · 문장당 10~15낱말 · 평균 50낱말**. 주인공의 처음 마음 낱말 a와 나중 마음 낱말 b가 **글에 그대로**(「felt very nervous」「felt proud」), 바뀌는 계기가 한 문장, **다른 사람(동생 · 엄마 · 친구 · 코치)의 마음 낱말 하나**가 미끼. 레벨1의 생각은 「주인공의 마음 낱말을 그대로 찾고, 다른 사람의 마음 낱말은 뺀다」
- 보기 'a → b' 다섯: (a → b) · (a′ → b) · (a → b′) · (a′ → b′) · (a″ → b′) — 40번 레벨1과 같은 짜임. 마음이 바뀌는 방향(나쁨→좋음 · 좋음→나쁨 · 나쁨→나쁨 · 좋음→좋음)을 섞어 「대개 좋아진다」로 찍히지 않게
- 보기만 보고 찍기: 첫판 14/30(확신 7, 그중 맞힌 것 3 — 「nervous → relieved」처럼 짝 자체가 굳은 말이면 확신하고 맞힘) → 그 세 문항의 짝을 바꿔(nervous → proud · worried → proud 등) 둘째 판 13/30(확신 6, 맞힌 것 2). 짜임을 노린 풀이꾼(많이 나온 낱말 고르기)은 0/30. 지문 전체 30/30. 감사꾼: 엄마의 worried와 주인공의 nervous가 거의 같은 뜻(→ 엄마를 sad로) · 가리키는 말 her가 둘(→ 이름으로) · 케이크가 이미 식탁 위인데 식탁으로 가다 떨어뜨림(→ 손에 든 상자로)
- **배운 것**: 다른 사람의 마음 낱말이 주인공의 것과 뜻이 가까우면(worried ↔ nervous) 둘째 답이 됨 · 「relieved」「thankful」처럼 앞 마음을 끌어오는 낱말은 짝이 굳어 보기만으로 찍힘 · 같은 문항에서 마음 낱말의 우리말을 하나로(proud = 자랑스러운) · 엄마 쪽 삼촌은 「외삼촌」
- 원고: 영어 `draft/d78.py`(검사 `draft/chk78.py`, 지침 `brief_d78.txt`, 본보기 `d78_probe.py`), 한글 `draft/k78_1~6.py`(검사 `draft/zk78.py`, 지침 `brief_k78.txt`), 도우미 `z19common.py`, `./fin78.sh` → `pending/edits_X77a|b.py`. 보기 길이: 정답이 가장 긴 6 · 첫째 · 둘째로 긴 14 · B · C · E 0
- 남은 한계: 학생 결과 없음 · `check_all`의 「19번 L1: 평균 50단어(목표 약 24단어)」는 옛 기준

'''
i = g.index('## 20번(주장) 레벨2의 꼴'); g = g[:i] + sec + g[i:]
wr(W + 'LEVEL_GUIDE.md', g)
r = rd(W + 'README.md')
old = "| `pending/edits_X76a.py` · `edits_X76b.py` |"
r = rep(r, old, "| `pending/edits_X77a.py` · `edits_X77b.py` | **19번(심경 변화) 레벨1(361번)** — 네 문장 · 단문 · 주인공의 마음 낱말 그대로 + 다른 사람의 마음 낱말 미끼. `z19common.maker(E)`의 `rw(n, 정답 자리, 지문, [보기], 해석, 처음 문장, 해석, 풀이, 나중 문장, 해석, 풀이, [보기 뜻], 낱말, [까닭])`. 영어 `draft/d78.py`, 한글 `draft/k78_1~6.py` → `python3 draft/gen78.py a|b` · `./fin78.sh`(바탕 7b287fb 위에 X77만) · 검사 `draft/chk78.py` · `draft/zk78.py` · 점수 `python3 score_any.py <폴더> 19 1` |\n" + old)
wr(W + 'README.md', r)
d = rd(W + 'DEFERRED.md')
d = rep(d, '(18번 360번에 마침 → 19 · 20 ·', '(18번 360번 · 19번 361번에 마침 → 20 ·')
wr(W + 'DEFERRED.md', d)
h = rd(W + 'out/그루앙스_작업인계문서.md').rstrip('\n') + '''

## 361. 19번(심경 변화) 레벨1을 새 꼴로 다시 씀 (2026-10-12, 같은 방)

선생님 「계속」(14:02) → 순서대로 **19번 레벨1**(옛 판 `regauge` 어긋남: 문장당 8.8낱말 · 단문 65%). 수정안 `pending/edits_X77a.py` · `edits_X77b.py`.
- 꼴(LEVEL_GUIDE 「19번(심경 변화) 레벨1의 꼴」): 네 문장 · 단문 · 주인공의 처음 · 나중 마음 낱말이 글에 그대로 + 다른 사람의 마음 낱말(미끼). 보기 짜임은 40번 레벨1과 같음. 정답 번호 바탕 그대로
- 영어: 세 opus 초안(마음이 바뀌는 방향 · 장면 배정) → `draft/d78.py`. 시험(보기만): 첫판(`sheets87/`) 14/30 확신 7 → 세 문항 짝 바꿈 → 둘째 판(`sheets88/`) 13/30 확신 6 · 지문 전체 30/30 · 감사꾼 2 + 3건 반영. 한글 쓰는 이들이 알린 작은 흠 셋도 고침(In the test → On the test · still 뺌 · her kindness → the woman's kindness)
- 한글: 여섯 opus(한 묶음이 한 문항만 써서 다시 맡김) → 교정꾼 둘(번역 6 · 논리 4) → 고침꾼이 10건 반영(외삼촌 · 신발 · 「마음」 → 「모습」 · 겁이 났다 …)
- 점검: `chk78.py` 0 · `zk78.py` 0 · `regauge.py 19 1` **맞음** · `check_all.py` 통과(② 변동 0 · ④ 143/144)
- 다음에 시작할 때: 바탕 **25,142,249바이트(`7b287fb`)**이면 `PYTHONPATH=pending python3 build.py edits_X77a,edits_X77b out/index.html` → **''' + SIZE + '''바이트**. 다음은 **20번(주장) 레벨1** → 22 → 23 → 24 → 26 → 41-42 → 43 → 44 → 45. 새 방 첫 줄: 「인계문서 361번까지 올렸습니다. 20번 레벨1을 봅니다.」
'''
wr(W + 'out/그루앙스_작업인계문서.md', h)
t = rd(W + 'page/template.html')
t = rep(t, '<b style="color:var(--fg)">18번 레벨1</b> (10-12, 인계문서 360번', '<b style="color:var(--fg)">19번 레벨1</b> (10-12, 인계문서 361번 — 심경 변화: 네 문장 · 단문 100% · 주인공의 마음 낱말이 글에 그대로, 다른 사람의 마음 낱말을 미끼로 서른 문항을 다시 씀) · <b style="color:var(--fg)">18번 레벨1</b> (10-12, 인계문서 360번')
wr(W + 'page/template.html', t)
print('docs361', SIZE)
