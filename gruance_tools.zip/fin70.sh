#!/bin/bash
# 352·353번: 31번 레벨2(A/B 꼴) — 원고에서 수정안 만들기 → 조사 → 빌드
cd /home/claude/work
python3 draft/gen70.py a && python3 draft/gen70.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X70a.py pending/edits_X70b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X69a,edits_X69b,edits_X70a,edits_X70b out/index.html | tail -3
