#!/bin/bash
# 362번: 20번 레벨1 — 원고에서 수정안 만들기 → 조사 → 빌드 (바탕 27d580d 위에 X78만)
cd /home/claude/work
python3 draft/gen79.py a && python3 draft/gen79.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X78a.py pending/edits_X78b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X78a,edits_X78b out/index.html | tail -3
