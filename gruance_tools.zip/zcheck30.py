# -*- coding: utf-8 -*-
# 30번(어휘) 원고 자체 검사 (342·343번).  python3 zcheck30.py draft   → 영어 원고(d66a/d66b)만 봄
#   (빌드 뒤 검사는 zcheck30b.py)
import re, sys, collections; sys.path.insert(0, '.'); sys.path.insert(0, 'draft')
from lib import load
from zlevel import check_texts
s, tb, te = load(); CIRC = '①②③④⑤'
import d66a, d66b
I = {**d66a.I, **d66b.I}; tx = {}; bad = 0
for n in range(30):
    it = I[n]; a = tb['30']['1'][n]['answer']; S = it['S']
    assert len(S) == 5
    toks = []
    for k in range(5):
        assert S[k].count(CIRC[k]) == 1 and sum(S[k].count(c) for c in CIRC) == 1, (n, k)
        toks.append(re.search(CIRC[k] + r"([A-Za-z']+)", S[k]).group(1))
    assert toks[a].lower() != it['cw'].lower(), (n, '틀린 말과 올바른 말이 같음')
    fixed = [x if k != a else x.replace(CIRC[k] + toks[k], it['cw']) for k, x in enumerate(S)]
    tx[n] = (re.sub('[①②③④⑤]', '', ' '.join(fixed)).replace('Mr.', 'Mr_'), 'x')
print('정답 자리', collections.Counter(tb['30']['1'][n]['answer'] + 1 for n in range(30)))
bad = check_texts('30', '1', tx, 5)
print('결과: 걸린 것', bad)
