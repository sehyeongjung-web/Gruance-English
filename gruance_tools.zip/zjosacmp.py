# 두 쪽 사이에서 해설의 어느 글이 바뀌었는지, 그 바뀐 것이 조사뿐인지 보여 줌
#   python3 zjosacmp.py 앞쪽.html 뒤쪽.html 이름
import sys, re, collections
sys.path.insert(0,'/home/claude/work')
from lib import load
import zjosa2 as Z
def norm(t):
    t = Z.PAT_P.sub(lambda m: m.group(0)[:m.start(3)-m.start()] + '#', t)
    return Z.PAT_Q.sub(lambda m: m.group(0)[:m.start(3)-m.start()] + '#', t)
def walk(o,p=()):
    if isinstance(o,str): yield p,o
    elif isinstance(o,dict):
        for k,v in o.items(): yield from walk(v,p+(k,))
    elif isinstance(o,list):
        for i,v in enumerate(o): yield from walk(v,p+(i,))
def compare(a_path, b_path, label):
    _,tba,tea=load(a_path); _,tbb,teb=load(b_path)
    pa=dict(walk(tea)); pb=dict(walk(teb)); assert pa.keys()==pb.keys(), '구조 다름'
    cells=collections.defaultdict(lambda:[0,0]); bad=[]
    for p,v in pb.items():
        w=pa[p]
        if w!=v:
            c=(p[0],p[1]); cells[c][0]+=1
            if norm(w)==norm(v): cells[c][1]+=1
            else: bad.append(p)
    bank=sum(1 for (p,v),(q,w) in zip(walk(tba),walk(tbb)) if v!=w)
    print('[%s] 해설에서 바뀐 글: %d (조사만 바뀐 글 %d, 그 밖의 변화 %d) · 문제은행 바뀐 곳 %d' % (label, sum(x[0] for x in cells.values()), sum(x[1] for x in cells.values()), len(bad), bank))
    for c,(n,k) in sorted(cells.items()): print('   ', c, '바뀐 글', n, '조사만', k)
    return bad
if __name__=='__main__':
    compare(sys.argv[1], sys.argv[2], sys.argv[3])
