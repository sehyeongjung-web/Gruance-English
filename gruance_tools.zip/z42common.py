# -*- coding: utf-8 -*-
# 367번: 42번(낱말 쓰임) 레벨1 — 공통 도우미 (z30rw를 본뜸: 다섯 문장 · 문장마다 표시 하나 · 틀린 낱말 하나)
#   from z42common import maker;  rw = maker(E)
#   rw(n, 지문(표시 (a)~(e)가 한 번씩, 정답 자리는 틀린 낱말), 해석 다섯(정답 자리에는 「틀린 뜻(→ 올바른 뜻)」), 표시 낱말의 뜻 다섯, 자리별 설명 다섯, 올바른 낱말(cw), 낱말 줄)
#   - 정답 자리는 바탕 그대로(어기면 멈춤) · 선택지는 (a)~(e) 그대로
#   - 정답 자리 설명은 「원래는 cw(뜻)」을 담고, 나머지 설명은 「맞아요.」로 끝남
#   - 풀이(walk)·선택지별 해설(cn)은 바탕 42번 레벨1의 꼴 그대로
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
_s, _tb, _te = load()
LET = 'abcde'
HEAD = "① 낱말 쓰임 문제는 (a)~(e) 낱말이 앞뒤 내용과 맞는지 하나씩 확인해요. 답은 문맥과 반대되거나 어울리지 않는 낱말이에요."
def maker(E, T='42', LV='1'):
    def rw(n, text, ko, gl, notes, cw, words):
        base = _tb[T][LV][n]; a = base['answer']
        assert len(ko) == 5 == len(gl) == len(notes), (n, '해석 · 뜻 · 설명은 다섯')
        sents = [s.strip() for s in re.split(r'(?<=[.?!])\s+', text)]
        assert len(sents) == 5, (n, '문장 수', len(sents))
        toks = []
        for k in range(5):
            tag = '(%s)' % LET[k]
            assert sents[k].count(tag) == 1 and sum(sents[k].count('(%s)' % c) for c in LET) == 1, (n, k, '표시는 문장마다 하나')
            m = re.search(re.escape(tag) + r"([A-Za-z']+)", sents[k]); assert m, (n, k, '표시 뒤 낱말'); toks.append(m.group(1))
        assert list(base['choices']) == ['(%s)' % c for c in LET], (n, '선택지는 (a)~(e)')
        assert toks[a].lower() != cw.lower(), (n, '정답 자리의 틀린 말과 올바른 말이 같음')
        assert '(→' in ko[a] and sum(x.count('(→') for x in ko) == 1, (n, '해석의 「(→ 올바른 뜻)」은 정답 자리에 한 번')
        assert all(re.search(r'[가-힣]', x) for x in ko) and all(re.search(r'[가-힣]', g) for g in gl), (n, '해석 · 뜻')
        for k in range(5):
            if k == a: assert '원래는 %s(' % cw in notes[k], (n, k, '정답 자리 설명에 「원래는 %s(뜻)」' % cw)
            else: assert notes[k].endswith('맞아요.'), (n, k, '다른 자리 설명은 「맞아요.」로 끝')
            assert '정답' not in notes[k], (n, k, '설명에 「정답」이라는 말')
        walk = (HEAD + '\n② (%s) %s 부분을 보세요.\n"%s" (%s)\n→ %s\n③ 나머지 네 낱말은 모두 문맥에 맞아요. 그러니까 정답은 (%s)예요.\n📌 낱말: %s'
                % (LET[a], toks[a], sents[a], ko[a], notes[a], LET[a], words))
        cn = [('정답이에요! ' if k == a else '') + '(%s) %s(%s) — %s' % (LET[k], toks[k], gl[k], notes[k]) for k in range(5)]
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                         'rewrite': {'text': text, 'choices': ['(%s)' % c for c in LET], 'ko': ' '.join(ko), 'walk': walk, 'cn': cn}}
    return rw
