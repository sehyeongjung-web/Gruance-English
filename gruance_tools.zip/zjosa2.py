# -*- coding: utf-8 -*-
# 조사 확인/고침 (2판) — 선생님 결정(Sat 2026-10-10): 「(뜻)」 괄호 뒤 조사는 "괄호 바로 앞 낱말"의 받침을 따른다.
#   예) also(또한)가 · 말(주제)을 · tool(공구)이 · 'one photo'(사진 한 장)는
#   · 앞 낱말이 우리말이면 그 마지막 글자, 영어면 읽는 소리(CMU 발음사전), 숫자면 읽는 소리로 봄
#   · 영어가 p·t·k·b·d·g로 끝나면(book·cat…) 읽는 사람에 따라 갈리므로 둘 다 맞는 것으로 침
#   · 앞 낱말이 없거나(줄 맨 앞) 알 수 없으면 괄호 안 한글의 받침을 따름
#   · 「…」 뒤 조사는 「…」 안 마지막 글자의 받침을 따름 (앞 낱말이 없음)
#   python3 zjosa2.py 파일…            → 어긋난 곳을 보여 줌 (원고 .py 파일도 되고, 쪽 .html도 되고, --data 로 문제은행 해설만 볼 수도 있음)
#   python3 zjosa2.py --fix 파일…      → 고쳐 씀 (엄격 판: 괄호 안 기준으로만 맞는 곳도 앞 낱말 기준으로 고침)
#   python3 zjosa2.py --data 쪽.html   → TYPE_EXPLAIN 안의 글자만 검사(앱 코드 제외); 바탕 글은 '괄호 안 기준으로만 맞는 곳'을 오류로 세지 않음
import re, sys, os, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
PAIRS = [('은', '는'), ('이', '가'), ('을', '를'), ('과', '와'), ('으로', '로'), ('이라고', '라고'), ('이에요', '예요')]
FORM = {}
for _b, _n in PAIRS: FORM[_b] = (_b, _n); FORM[_n] = (_b, _n)
ALT = sorted(FORM, key=len, reverse=True)
_TAIL = '(' + '|'.join(ALT) + r')(?![가-힣])'
PAT_P = re.compile(r'\(([^()\n]*?)([가-힣])\)' + _TAIL)
PAT_Q = re.compile(r'「([^」\n]*?)([가-힣])」' + _TAIL)
try:
    import cmudict; _D = cmudict.dict()
except Exception: _D = {}
STRONG = {'N', 'M', 'NG'}; STOP = {'P', 'T', 'K', 'B', 'D', 'G'}
def batchim(ch): return (ord(ch) - 0xAC00) % 28
def kclass(ch):                       # 우리말 글자 → 'V'(받침 없음) · 'L'(ㄹ받침) · 'B'(그 밖의 받침)
    b = batchim(ch); return 'V' if b == 0 else ('L' if b == 8 else 'B')
def eclass(word):
    w = word.lower().strip("'’")
    if w not in _D and w.endswith("'s"): w = w[:-2]
    if w not in _D: UNKNOWN[w] += 1; return '?'
    last = re.sub(r'\d', '', _D[w][0][-1])
    if last in STRONG: return 'B'
    if last == 'L': return 'L'
    if last in STOP: return '?'
    return 'V'
NUM = {'0': 'B', '1': 'L', '2': 'V', '3': 'B', '4': 'V', '5': 'V', '6': 'B', '7': 'L', '8': 'L', '9': 'V'}
CIRC = {'①': 'L', '②': 'V', '③': 'B', '④': 'V', '⑤': 'V'}
UNKNOWN = collections.Counter()
def front(pre):
    """괄호 바로 앞 낱말의 받침 종류: ('ko'|'en'|'num'|'none', 'V'|'L'|'B'|'?'|None, 낱말)"""
    t = pre.rstrip(' ')
    if t.endswith('\\n') or t.endswith('\n') or t == '': return ('none', None, '')
    while t and t[-1] in "'’”\"‘“\\ …»›": t = t[:-1]
    if not t: return ('none', None, '')
    mm = re.search(r'\(([A-Za-z0-9]{1,3})\)$', t)                 # …(B)(뜻) 처럼 앞에 (B)가 붙은 경우는 B를 앞 낱말로
    if mm: t = mm.group(1)
    c = t[-1]
    if c in CIRC: return ('num', CIRC[c], c)
    if '가' <= c <= '힣': return ('ko', kclass(c), c)
    if c in '0123456789':
        n = re.search(r'[0-9]+$', t).group(0)
        return ('num', 'B' if (len(n) > 1 and n[-1] == '0') else NUM[n[-1]], n)
    if c.isascii() and c.isalpha():
        m = re.search(r"[A-Za-z]+(?:'[A-Za-z]+)?$", t); w = m.group(0) if m else c
        return ('en', eclass(w), w)
    return ('other', None, c)
def want(par, cls):
    wb, nb = FORM[par]
    if wb == '으로': return nb if cls in ('V', 'L') else wb
    return wb if cls in ('B', 'L') else nb
def judge(m, pre, quote):
    """→ (상태, 고칠 조사)  상태: ok · style(괄호 안 기준으로만 맞음) · bad(둘 다 어긋남) · ambig(영어 p·t·k로 끝나 판단 보류)"""
    par = m.group(3); ch = m.group(2); gl = want(par, kclass(ch))
    if quote: return ('ok', par) if gl == par else ('bad', gl)
    fr = front(pre)
    if fr[1] in ('V', 'L', 'B'):
        fw = want(par, fr[1])
        if fw == par: return ('ok', par)
        return ('style', fw) if gl == par else ('bad', fw)
    if fr[1] == '?': return ('ambig', par)
    return ('ok', par) if gl == par else ('bad', gl)      # 앞 낱말 없음/모름 → 괄호 안 기준
def scan(s):
    """글 한 덩어리 → [(시작, 끝, 상태, 고칠 조사, 원래 조사, 앞뒤 보기)]"""
    res = []
    for pat, quote in ((PAT_P, False), (PAT_Q, True)):
        for m in pat.finditer(s):
            pre = s[max(0, m.start() - 40):m.start()]
            st, fx = judge(m, pre, quote)
            res.append((m.start(3), m.end(3), st, fx, m.group(3), s[max(0, m.start() - 16):m.end() + 8].replace('\n', '⏎')))
    return sorted(res)
def fix(s, strict=True):
    out = []; last = 0; n = 0
    for a, b, st, fx, old, ctx in scan(s):
        if (st == 'bad' or (strict and st == 'style')) and fx != old:
            out.append(s[last:a]); out.append(fx); last = b; n += 1
    out.append(s[last:]); return ''.join(out), n
def summarize(items):
    c = collections.Counter(x[2] for x in items); return c
if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    do_fix = '--fix' in sys.argv; data = '--data' in sys.argv
    strict = do_fix or '--strict' in sys.argv
    tot = collections.Counter()
    for p in args:
        s = open(p, encoding='utf-8').read()
        if data:
            from lib import load
            _, _, te = load(p); texts = []
            def walk(o):
                if isinstance(o, str): texts.append(o)
                elif isinstance(o, dict): [walk(v) for v in o.values()]
                elif isinstance(o, list): [walk(v) for v in o]
            walk(te); items = [x for t in texts for x in scan(t)]
        else: items = scan(s)
        c = summarize(items); tot.update(c)
        for a, b, st, fx, old, ctx in items:
            if st == 'bad' or (strict and st == 'style'): print('%s [%s] …%s  %s → %s' % (os.path.basename(p), st, ctx, old, fx))
        if do_fix and not data:
            t, n = fix(s, True)
            if n: open(p, 'w', encoding='utf-8').write(t)
    bad = tot['bad'] + (tot['style'] if strict else 0)
    if UNKNOWN: print('발음사전에 없는 영어 낱말(판단 보류):', ', '.join('%s×%d' % kv for kv in UNKNOWN.most_common(40)))
    print('결과: 맞음 %d · 괄호 안 기준으로만 맞음 %d · 둘 다 어긋남 %d · 판단 보류(영어 p/t/k 끝) %d → 고칠 곳 %d%s' % (tot['ok'], tot['style'], tot['bad'], tot['ambig'], bad, ' (고침)' if do_fix else ''))
