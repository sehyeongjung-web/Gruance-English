# -*- coding: utf-8 -*-
"""폴더 안 docx의 숨은 정보(만든 이·만든 때·고친 횟수·프로그램 이름)를 비우고, 문단 테두리 차례를 규격대로 바로잡는다 (332번).
  python3 /home/claude/work/paper/scrub.py <폴더>"""
import sys, os, re, zipfile
CORE = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"/>')
BAD = re.compile(rb'claude|anthropic|openai|chatgpt|docx-js|python|libreoffice|w:rsid', re.I)
PB = re.compile(r'<w:pBdr>(.*?)</w:pBdr>', re.S)
def order(m):
    el = dict((re.match(r'<w:(\w+)', e).group(1), e) for e in re.findall(r'<w:\w+ [^>]*/>', m.group(1)))
    return '<w:pBdr>' + ''.join(el[k] for k in ('top', 'left', 'bottom', 'right', 'between', 'bar') if k in el) + '</w:pBdr>'
def scrub(p):
    zin = zipfile.ZipFile(p); tmp = p + '.tmp'
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as z:
        for n in zin.namelist():
            d = zin.read(n)
            if n == 'docProps/core.xml': d = CORE.encode('utf-8')
            if n == 'word/document.xml': d = PB.sub(order, d.decode('utf-8')).encode('utf-8')   # 문단 테두리 차례를 규격대로(위·왼쪽·아래·오른쪽)
            zi = zipfile.ZipInfo(n, date_time=(1980, 1, 1, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
            z.writestr(zi, d)
    os.replace(tmp, p)
    z = zipfile.ZipFile(p); assert z.testzip() is None
    hits = [n for n in z.namelist() if BAD.search(z.read(n))]
    core = z.read('docProps/core.xml').decode(); app = z.read('docProps/app.xml').decode() if 'docProps/app.xml' in z.namelist() else ''
    assert not hits, hits; assert '<dc:' not in core and '<cp:last' not in core and 'dcterms:created' not in core
    assert 'Application' not in app and 'Company' not in app, app
    print('비움 확인:', os.path.basename(p), format(os.path.getsize(p), ','), '바이트')
for f in sorted(os.listdir(sys.argv[1])):
    if f.endswith('.docx'): scrub(os.path.join(sys.argv[1], f))
