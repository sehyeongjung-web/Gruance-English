# -*- coding: utf-8 -*-
"""38-39번(문장 넣기) 한 칸을 시험지용 자료(items.json)로 뽑는다 (332번).
  python3 /home/claude/work/paper/extract.py 1      (out/index.html의 38-39번 레벨1)
그런 다음: cd /home/claude/work/paper && node make.js <폴더>  →  python3 scrub.py <폴더>"""
import sys, os, re, json
HERE = '/home/claude/work'; sys.path.insert(0, HERE)
from lib import load
LV = sys.argv[1] if len(sys.argv) > 1 else '1'
_, tb, te = load(os.path.join(HERE, 'out/index.html'))
out = []
for i, it in enumerate(tb['38_39'][LV]):
    t = it['text']; m = re.match(r'\[삽입할 문장\] (.+?)\n\n(.+)$', t, re.S); assert m, i + 1
    given, body = m.group(1).strip(), m.group(2).strip()
    parts = re.split(r'\s*\( [①②③④⑤] \)\s*', body); parts = [p for p in parts if p]
    assert len(parts) == 5 and re.findall(r'\( ([①②③④⑤]) \)', body) == list('①②③④⑤'), i + 1
    ex = te['38_39'][LV][i]; ex = ex if isinstance(ex, str) else json.dumps(ex, ensure_ascii=False)
    k = ex.find('헷갈리는 곳'); seg = ex[k:k + 400]; j = seg.find('끌려요')
    lure = ''.join(dict.fromkeys(re.findall('[①②③④⑤]', seg[:j]))) if j > 0 else ''
    out.append({'n': i + 1, 'given': given, 'sents': parts, 'answer': it['answer'] + 1, 'lure': lure, 'prompt': it.get('q', '')})
json.dump(out, open(os.path.join(HERE, 'paper/items.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('문항', len(out), '· 정답', ''.join(str(o['answer']) for o in out))
