// 38-39번(문장 넣기) 레벨1 — 학생용 시험지 · 선생님용 정답과 채점표
const fs = require('fs');
const path = require('path');
const D = require('docx');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, BorderStyle, Footer, PageNumber,
        ShadingType, VerticalAlign, SectionType, LevelFormat } = D;
const HERE = __dirname;
const items = JSON.parse(fs.readFileSync(path.join(HERE, 'items.json'), 'utf8'));
const C = '①②③④⑤';
const KO = { ascii: 'Times New Roman', hAnsi: 'Times New Roman', eastAsia: '바탕', cs: 'Times New Roman' };
const KG = { ascii: '맑은 고딕', hAnsi: '맑은 고딕', eastAsia: '맑은 고딕', cs: '맑은 고딕' };
const COPY = 'ⓒ 정세형. 무단 복제 및 배포를 금지합니다.';
const mm = v => Math.round(v * 56.6929);   // mm → DXA
const run = (text, o = {}) => new TextRun(Object.assign({ text, font: KO, size: 20 }, o));
const hrun = (text, o = {}) => new TextRun(Object.assign({ text, font: KG, size: 20 }, o));
const line = { style: BorderStyle.SINGLE, size: 6, color: '000000' };
const thin = { style: BorderStyle.SINGLE, size: 4, color: '555555' };
const none = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
const footer = () => new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
  hrun(COPY + '    ', { size: 15, color: '444444' }), new TextRun({ children: [PageNumber.CURRENT], font: KG, size: 15, color: '444444' }),
  hrun(' / ', { size: 15, color: '444444' }), new TextRun({ children: [PageNumber.TOTAL_PAGES], font: KG, size: 15, color: '444444' })] })] });
const cell = (children, w, o = {}) => new TableCell(Object.assign({ children, width: { size: w, type: WidthType.DXA }, verticalAlign: VerticalAlign.CENTER,
  margins: { top: 50, bottom: 50, left: 70, right: 70 }, borders: { top: thin, bottom: thin, left: thin, right: thin } }, o));
const cp = (text, o = {}, po = {}) => new Paragraph(Object.assign({ alignment: AlignmentType.CENTER, children: [hrun(text, Object.assign({ size: 18 }, o))] }, po));
const PAGE = { size: { width: mm(210), height: mm(297) }, margin: { top: mm(13), bottom: mm(15), left: mm(14), right: mm(14), footer: mm(7) } };
const FULL = mm(210 - 28);

// ───────── 학생용 시험지 ─────────
function student() {
  const head = [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [hrun('문장 넣기 연습 · 레벨 1', { size: 30, bold: true })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 140 }, children: [hrun('30문항 · 권장 시간 30분', { size: 18, color: '333333' })] }),
    new Table({ width: { size: FULL, type: WidthType.DXA }, columnWidths: [FULL * 0.14, FULL * 0.16, FULL * 0.12, FULL * 0.16, FULL * 0.12, FULL * 0.30].map(Math.round),
      rows: [new TableRow({ children: [
        cell([cp('학년 · 반')], Math.round(FULL * 0.14), { shading: { type: ShadingType.CLEAR, fill: 'EEEEEE', color: 'auto' } }), cell([cp('')], Math.round(FULL * 0.16)),
        cell([cp('번호')], Math.round(FULL * 0.12), { shading: { type: ShadingType.CLEAR, fill: 'EEEEEE', color: 'auto' } }), cell([cp('')], Math.round(FULL * 0.16)),
        cell([cp('이름')], Math.round(FULL * 0.12), { shading: { type: ShadingType.CLEAR, fill: 'EEEEEE', color: 'auto' } }), cell([cp('')], Math.round(FULL * 0.30))] })] }),
    new Paragraph({ spacing: { before: 160, after: 40 }, border: { top: line, bottom: line, left: line, right: line },
      children: [hrun(' [1~30] 글의 흐름으로 보아, 주어진 문장이 들어가기에 가장 적절한 곳을 고르시오.', { size: 20, bold: true })] }),
    new Paragraph({ spacing: { before: 60, after: 80 }, children: [hrun('· 답은 문항 번호 옆의 (    )와 아래 「답 적는 곳」에 모두 적으세요.   · 자신 없이 고른 문항은 답 옆에 △ 표시를 하세요.', { size: 16, color: '333333' })] }),
  ];
  const W = Math.floor(FULL / 10);
  const rows = [];
  for (let r = 0; r < 3; r++) {
    rows.push(new TableRow({ cantSplit: true, children: Array.from({ length: 10 }, (_, c) => cell([cp(String(r * 10 + c + 1), { bold: true, size: 16 }, { keepNext: true })], W, { shading: { type: ShadingType.CLEAR, fill: 'EEEEEE', color: 'auto' }, margins: { top: 20, bottom: 20, left: 70, right: 70 } })) }));
    rows.push(new TableRow({ cantSplit: true, height: { value: 400, rule: 'atLeast' }, children: Array.from({ length: 10 }, () => cell([cp('', {}, { keepNext: true })], W)) }));
  }
  head.push(new Paragraph({ keepNext: true, spacing: { before: 60, after: 50 }, children: [hrun('답 적는 곳', { size: 19, bold: true })] }));
  head.push(new Table({ width: { size: W * 10, type: WidthType.DXA }, columnWidths: Array(10).fill(W), rows }));
  head.push(new Paragraph({ spacing: { before: 0, after: 0 }, children: [hrun('', { size: 8 })] }));
  const body = [];
  for (const it of items) {
    body.push(new Paragraph({ keepNext: true, keepLines: true, spacing: { before: 190, after: 60 },
      children: [hrun(it.n + '.', { size: 21, bold: true }), hrun('  (        )', { size: 20 })] }));
    body.push(new Paragraph({ keepNext: true, keepLines: true, spacing: { before: 0, after: 100, line: 290 }, indent: { left: 90, right: 90 },
      border: { top: line, bottom: line, left: line, right: line }, alignment: AlignmentType.BOTH,
      children: [run(it.given, { size: 20 })] }));
    const kids = [];
    it.sents.forEach((s, k) => { kids.push(run(s + ' ')); kids.push(run('( ' + C[k] + ' )' + (k < 4 ? ' ' : ''))); });
    body.push(new Paragraph({ keepLines: true, alignment: AlignmentType.BOTH, spacing: { before: 0, after: 0, line: 310 }, children: kids }));
  }
  return new Document({
    creator: '', title: '', description: '', lastModifiedBy: '',
    styles: { default: { document: { run: { font: KO, size: 20 } } } },
    sections: [
      { properties: { page: PAGE }, footers: { default: footer() }, children: head },
      { properties: { type: SectionType.CONTINUOUS, page: PAGE, column: { count: 2, space: mm(9), separate: true } }, footers: { default: footer() }, children: body },
    ] });
}

// ───────── 선생님용 정답과 채점표 ─────────
function teacher() {
  const kids = [];
  kids.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [hrun('문장 넣기 연습 · 레벨 1 — 정답과 채점표', { size: 28, bold: true })] }));
  kids.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 }, children: [hrun('선생님용 · 학생에게 나누어 주지 않습니다', { size: 18, color: '333333' })] }));
  const H = t => new Paragraph({ spacing: { before: 220, after: 90 }, children: [hrun(t, { size: 22, bold: true })] });
  const B = t => new Paragraph({ numbering: { reference: 'dots', level: 0 }, spacing: { after: 50, line: 300 }, children: [hrun(t, { size: 19 })] });
  kids.push(H('1. 정답'));
  const W = Math.floor(FULL / 10); const rows = [];
  for (let r = 0; r < 3; r++) {
    rows.push(new TableRow({ children: Array.from({ length: 10 }, (_, c) => cell([cp(String(r * 10 + c + 1), { bold: true })], W, { shading: { type: ShadingType.CLEAR, fill: 'EEEEEE', color: 'auto' } })) }));
    rows.push(new TableRow({ children: Array.from({ length: 10 }, (_, c) => cell([cp(C[items[r * 10 + c].answer - 1], { size: 22 })], W)) }));
  }
  kids.push(new Table({ width: { size: W * 10, type: WidthType.DXA }, columnWidths: Array(10).fill(W), rows }));
  kids.push(H('2. 이렇게 써 주십시오'));
  kids.push(B('한 번에 서른 문항을 풀려도 되고, 1~15번과 16~30번으로 나누어 두 번에 풀려도 됩니다. 사전 없이, 권장 시간은 서른 문항에 30분입니다.'));
  kids.push(B('학생에게 「자신 없이 고른 문항은 답 옆에 △」라고 일러 주십시오. 찍어서 맞힌 문항을 가려내는 데 씁니다.'));
  kids.push(B('채점한 뒤 아래 집계표에 문항마다 ①~⑤를 고른 학생 수만 적어 주십시오. 학생 이름은 필요 없습니다.'));
  kids.push(B('집계표를 사진으로 찍거나 숫자만 옮겨 적어 보내 주시면, 그 결과로 문항을 고칩니다.'));
  kids.push(H('3. 결과에서 볼 것'));
  kids.push(B('오답 한 자리에 학생이 몰린 문항 — 답이 둘로 읽히거나 지문에 걸리는 말이 있다는 뜻입니다. 가장 먼저 고칩니다.'));
  kids.push(B('맞힌 학생이 아주 적은 문항 — 레벨 1에 견주어 어렵거나 낱말이 낯설다는 뜻입니다.'));
  kids.push(B('거의 모두가 맞힌 문항 — 너무 쉽거나, 읽지 않고도 풀리는 단서가 있다는 뜻입니다.'));
  kids.push(B('「예상한 오답」과 실제로 많이 고른 오답이 다른 문항 — 해설의 【헷갈리는 곳】을 실제에 맞게 고칩니다.'));
  kids.push(B('△가 많은데도 정답률이 높은 문항 — 찍어서 맞힐 수 있다는 뜻입니다.'));
  kids.push(new Paragraph({ pageBreakBefore: true, spacing: { after: 90 }, children: [hrun('4. 문항별 집계표', { size: 22, bold: true }), hrun('    응시 학생 수: (        )명', { size: 19 })] }));
  const cw = [0.07, 0.07, 0.11, 0.105, 0.105, 0.105, 0.105, 0.105, 0.10, 0.125].map(x => Math.round(FULL * x));
  const sum = cw.reduce((a, b) => a + b, 0);
  const hd = ['번호', '정답', '예상한 오답', '①', '②', '③', '④', '⑤', '무응답', '△ 표시'];
  const g = { type: ShadingType.CLEAR, fill: 'EEEEEE', color: 'auto' };
  const trows = [new TableRow({ tableHeader: true, children: hd.map((t, i) => cell([cp(t, { bold: true, size: 17 })], cw[i], { shading: g })) })];
  for (const it of items) {
    const cells = [cell([cp(String(it.n), { bold: true })], cw[0]), cell([cp(C[it.answer - 1], { size: 20 })], cw[1]), cell([cp(it.lure.split('').join(' · '), { size: 18 })], cw[2])];
    for (let k = 0; k < 5; k++) cells.push(cell([cp('')], cw[3 + k], k === it.answer - 1 ? { shading: { type: ShadingType.CLEAR, fill: 'E2E2E2', color: 'auto' } } : {}));
    cells.push(cell([cp('')], cw[8])); cells.push(cell([cp('')], cw[9]));
    trows.push(new TableRow({ cantSplit: true, height: { value: 400, rule: 'atLeast' }, children: cells }));
  }
  kids.push(new Table({ width: { size: sum, type: WidthType.DXA }, columnWidths: cw, rows: trows }));
  kids.push(new Paragraph({ spacing: { before: 100 }, children: [hrun('· 회색 칸이 정답 자리입니다. 칸마다 그 번호를 고른 학생 수를 적습니다.   · 「예상한 오답」은 해설의 【헷갈리는 곳】에서 가장 끌린다고 본 자리입니다.', { size: 16, color: '333333' })] }));
  return new Document({
    creator: '', title: '', description: '', lastModifiedBy: '',
    styles: { default: { document: { run: { font: KG, size: 20 } } } },
    numbering: { config: [{ reference: 'dots', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 360, hanging: 240 } } } }] }] },
    sections: [{ properties: { page: PAGE }, footers: { default: footer() }, children: kids }] });
}

(async () => {
  const out = process.argv[2];
  fs.writeFileSync(path.join(out, '38-39번_문장넣기_레벨1_학생용_시험지_30문제.docx'), await Packer.toBuffer(student()));
  fs.writeFileSync(path.join(out, '38-39번_문장넣기_레벨1_선생님용_정답_채점표.docx'), await Packer.toBuffer(teacher()));
  console.log('made');
})();
