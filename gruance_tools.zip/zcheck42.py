# -*- coding: utf-8 -*-
# 42번(장문 속 낱말) 두텁게 — 자체 엄격 검사 (223번에 다시 만듦)
#   python3 zcheck42.py 8 edits_Y5a,edits_Y5b     (레벨, 그리고 바꾸어 넣을 낱말 목록을 읽어 올 수정안 이름들 — 안 주면 예외 없이 봄)
import re, sys, importlib, statistics as st; sys.path.insert(0, '.')
from lib import *
import z7common
from z7common import words, plain, KEYS, HEADS
LV = sys.argv[1] if len(sys.argv) > 1 else '8'
for m in (sys.argv[2].split(',') if len(sys.argv) > 2 else []): importlib.import_module(m)
ALT = z7common.ALT
ITEM_FIX = {('8', 4), ('8', 16)}   # 지문·밑줄 낱말을 고친 문항(인계문서에 적은 것만): (레벨, 몇째-1) — 223번: 5번째(dearer → cheaper) / 224번: 17번째(문장 다시 씀)
s, tb, te = load('out/index.html'); s0, tb0, te0 = load()
T = '42'; done = 0; soft = []; wl = []; cl = []
OKW = set('but yet and or so not if because since therefore'.split())
for n in range(30):
    it = tb[T][LV][n]; ex = te[T][LV][n]; P = plain(it['text']); a = it['answer']; w = ex['walk']
    if '【이 문제에 적용】' not in w: continue
    done += 1; W = words(it['text']); alt = [x.lower() for x in ALT.get((LV, n), [])]
    ok = lambda q: q.lower().strip(' .,') in P.lower() or q.lower().strip(' .,') in alt
    for tx in [w] + ex['cn']:
        assert '«' not in tx and '»' not in tx, (n, '꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"') % 2 == 0, (n, line)
            for q in re.findall(r'"([^"]*)"', line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"' % (n + 1, q))
                if len(q) < 12: print('!! 짧은 큰따옴표: %d번째 "%s"' % (n + 1, q))
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])", tx):
            if re.search(r'[가-힣]', q) or not re.search(r'[A-Za-z]{3,}', q): continue
            if any(not ok(p) for p in re.split(r'…', q) if p.strip(' .,')): soft.append((n + 1, "작은따옴표 '%s'" % q))
        tx2 = tx.split('【이 문제에 적용】')[-1]
        pl = re.sub(r'"[^"]*"', '', tx2); pl = re.sub(r"'[^'\n]*'", '', pl)
        for wd in set(re.findall(r'[A-Za-z][A-Za-z\-]{2,}', pl)):
            if not ok(wd) and wd.lower() not in OKW: print('!! %d번째: 따옴표 없는 영어 낱말 %s — 지문에도 바꿔 넣을 낱말에도 없음' % (n + 1, wd))
    assert w.startswith('【문맥 속 낱말 요령】') and w.count('【') == 3 and '【헷갈리는 곳】' in w, (n, '세 단락 꼴')
    assert all(('\n' + h) in w for h in HEADS), (n, '적용 꼴')
    body = w.split('【이 문제에 적용】')[1]
    assert re.findall(r'\(([a-e])\)가 문맥에 맞지 않습니다', w) == [KEYS[a]], (n, '풀이가 말한 답')
    assert '정답' not in body, (n, '풀이에 정답이라는 말')
    line2 = [l for l in w.split('\n') if l.startswith('2) 낱말마다 확인:')][0]
    for k in range(5):
        assert (('(%s) %s(' % (KEYS[k], W[k])) in line2) == (k != a), (n, k, '2)의 네 낱말')
        c = ex['cn'][k]
        head = ('(%s)가 정답입니다. %s(' if k == a else '(%s) %s(') % (KEYS[k], W[k])
        assert c.startswith(head), (n, k, '해설 머리'); assert c.count('정답') == (1 if k == a else 0), (n, k)
        if k != a: assert '): 문맥에 맞습니다. ' in c[:60 + len(W[k])], (n, k, '문맥에 맞습니다')
        assert not re.search(r'\([a-e]\)', c[3:]), (n, k, '낱말 해설에 다른 기호')
    b0 = tb0[T][LV][n]
    if (LV, n) in ITEM_FIX: assert it['answer'] == b0['answer'] and it['choices'] == b0['choices'], (n, '정답·선택지 변동')
    else: assert it == b0 and ex['ko'] == te0[T][LV][n]['ko'], (n, '문항·해석 변동')
    wl.append(len(w)); cl += [len(c) for c in ex['cn']]
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']: assert tb[T][LV][n] == tb0[T][LV][n] and te[T][LV][n] == te0[T][LV][n], (n, '안 쓴 문항이 바뀜')
print('두텁게 쓴 문항:', done, '/ 30')
if wl: print('풀이 평균 %d자(최소 %d, 최대 %d) / 낱말별 해설 평균 %d자(최소 %d, 최대 %d)' % (st.mean(wl), min(wl), max(wl), st.mean(cl), min(cl), max(cl)))
for x in soft: print('  눈으로 볼 것: %d번째 %s' % x)
