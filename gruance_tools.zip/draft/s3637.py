# -*- coding: utf-8 -*-
# 36-37번 레벨1 본보기 원고: I[n] = (주어진 글, {'A': [문장들], 'B': [...], 'C': [...]}, 정답 순서)
I = {}
I[0] = ("Last Saturday Tom baked cookies for the first time in his life.",
        {'A': ["After that hour, he cut the cold dough into twelve small circles.", "He left them in the hot oven for fifteen minutes."],
         'B': ["Those fifteen minutes were too long for such small cookies.", "Tom's first cookies came out of the oven dark and hard."],
         'C': ["In the morning he mixed flour, sugar and butter into a soft dough.", "The bowl of dough then stayed in the fridge for one hour."]},
        'CAB')
I[1] = ("Lily grew three small tomato plants in pots by her bedroom window.",
        {'A': ["Their leaves slowly turned yellow one after another in early June.", "Lily gave the plants more and more water every day."],
         'B': ["The old man kept the soil dry for the next ten days.", "Soon new green leaves appeared on all three of her plants."],
         'C': ["However, all that extra water only made the yellow leaves worse.", "Her grandfather looked at the wet soil and shook his head."]},
        'ACB')
I[3] = ("On Lunar New Year's Day, many Korean families eat a bowl of tteokguk together.",
        {'A': ["Because of this coin shape, the soup carries a wish for a rich year.", "So one bowl of this soup brings two good wishes for the new year."],
         'B': ["This soup has many thin white slices of rice cake in it.", "Their white color means a clean start to the year."],
         'C': ["The round shape of the slices also has its own meaning.", "Each of them looks very much like an old Korean coin."]},
        'BCA')
def lay(g, P): return g + "\n\n" + "\n".join("(%s) %s" % (k, " ".join(P[k])) for k in 'ABC')
