# -*- coding: utf-8 -*-
# 36-37번 레벨1 뒤 절반(16~30번째) 원고. I[n] = (주어진 글, {'A': [...], 'B': [...], 'C': [...]}, 정답 순서)  n = 0부터 센 번호(15~29)
I = {}
I[15] = ("Eric joined a swim class at the city pool last July.",
         {'A': ["That first float gave him a great deal of courage in class.", "By August, he swam across the whole pool without any help."],
          'B': ["She told him to lie flat on the cool water.", "After three tries, Eric floated on his back for ten seconds."],
          'C': ["At first, Eric held the wall tightly with both hands.", "His teacher, Ms. Lee, stood next to him in the water."]}, 'CBA')
I[16] = ("A small bean seed can grow into a tall green plant.",
         {'A': ["Now the young plant stands firmly on that deep root.", "A thin green stem rises from the seed toward the sun."],
          'B': ["Soon a tiny white root comes out of the soft seed.", "That white root grows deep into the dark soil below."],
          'C': ["The seed first takes in water from the wet soil.", "The water makes the hard outside of the seed soft."]}, 'CBA')
I[17] = ("Nari wanted to make a birthday card for her grandmother.",
         {'A': ["On Saturday morning, the blue envelope reached her grandmother's house.", "Her grandmother smiled warmly at the poem for a long time."],
          'B': ["At home, she cut a large heart from red paper.", "She wrote a short poem inside the heart in black ink."],
          'C': ["That poem told a small story about her grandmother's old garden.", "Last of all, she put the card in a blue envelope."]}, 'BCA')
I[18] = ("Salmon live in two very different places during their lives.",
         {'A': ["After those years at sea, these big fish swim back to the river.", "There, each female lays thousands of eggs in the cold gravel."],
          'B': ["After this long stay, the small fish swim down to the sea.", "In the salty ocean, they grow much bigger over several years."],
          'C': ["Young salmon hatch in clear, cold rivers far from the coast.", "For one or two years, they stay in that fresh water."]}, 'CBA')
I[19] = ("Anna wanted to join the school play in the fall.",
         {'A': ["Those three lines made the whole room laugh out loud.", "The teacher gave her the role of the funny old cook."],
          'B': ["Her teacher held a short test for the new actors.", "Anna read three lines from the play in front of everyone."],
          'C': ["For that role, Anna learned five short lines at home.", "On opening night, the audience laughed at every one of them."]}, 'BAC')
I[20] = ("Ryan made a kite with his father on a windy Sunday.",
         {'A': ["Ryan and his father covered a cross of long sticks with red paper.", "At the bottom, Ryan glued a long cloth tail to the red paper."],
          'B': ["Suddenly that thin string snapped with a loud crack near the old tree.", "The kite sailed away over the wide river toward the hills."],
          'C': ["That tail kept the kite steady in the strong wind.", "Ryan held the thin string with both hands near the park gate."]}, 'ACB')
I[21] = ("The moon is the brightest object in the night sky.",
         {'A': ["This daily change gives the moon many different shapes in the sky.", "Scientists call each of these shapes a phase of the moon."],
          'B': ["That sunlight always shines on one half of the moon.", "Each night, we see a different part of that bright half."],
          'C': ["The moon does not make any light of its own.", "It only reflects the light of the sun, like a mirror."]}, 'CBA')
I[22] = ("Mia lost her silver key on the way to school.",
         {'A': ["He opened the old lost-and-found box behind his small desk.", "Inside, Mia found her silver key under a blue glove."],
          'B': ["She looked in her bag, her pockets and her desk.", "Finally, she asked the school guard about her lost key."],
          'C': ["After that happy find, Mia keeps her key on a long string.", "The string hangs around her neck during every school day."]}, 'BAC')
I[23] = ("Dohyun went fishing with his grandfather at a quiet lake.",
         {'A': ["That strong pull bent his rod almost down to the water.", "His grandfather held a net under the large silver fish."],
          'B': ["It weighed nearly three kilograms on his grandfather's old scale.", "Dohyun proudly carried his catch home in a blue bucket."],
          'C': ["They sat on a wooden dock for two long hours.", "Suddenly Dohyun felt a strong pull on his thin line."]}, 'CAB')
I[24] = ("A rainbow can appear in the sky after a rain shower.",
         {'A': ["Inside each drop, that white light splits into many colors.", "Each color leaves the drop at a slightly different angle."],
          'B': ["Those separate colors reach our eyes from many different drops.", "Together, they form a wide band of color across the sky."],
          'C': ["Rain leaves millions of tiny drops of water in the air.", "Bright sunlight then enters each one of those small drops."]}, 'CAB')
I[25] = ("Jisoo spent last Saturday morning at the town animal shelter.",
         {'A': ["After those ten minutes, the shy dog crept out to her side.", "Jisoo gave the dog a gentle pat on its head."],
          'B': ["A worker gave her a green apron and a stiff brush.", "Her first job was to carry a bucket of fresh water to the dog cages."],
          'C': ["In one of those cages, a shy brown dog was hiding.", "Jisoo sat quietly on the cold floor beside the bucket for ten minutes."]}, 'BCA')
I[26] = ("Leo entered his model volcano in the school science fair.",
         {'A': ["Inside that tall cone, Leo put baking soda and red water.", "Then he slowly added vinegar from a small plastic cup."],
          'B': ["At home, he built a tall cone from thick brown cardboard.", "A coat of gray paint made it look like real rock."],
          'C': ["This mixture quickly sent red foam out of the top.", "The judges clapped loudly for Leo's model at the end."]}, 'BAC')
I[27] = ("Bats can find small insects even in the dark night.",
         {'A': ["The bat hears each echo with its two large ears.", "These echoes tell the bat the exact place of its food."],
          'B': ["A bat sends out very high sounds into the night air.", "Those sounds travel quickly in every direction around the bat."],
          'C': ["Some of these sounds hit a small insect in the air.", "Those sounds then bounce back to the bat as faint echoes."]}, 'BCA')
I[28] = ("Haneul took the bus alone to her aunt's house for the first time.",
         {'A': ["On the bus, Haneul held that card tightly in her hand.", "A kind driver told her the name of each stop."],
          'B': ["At the last of those stops, Haneul stepped carefully off the bus.", "Her aunt was already waiting there with a wide smile."],
          'C': ["Her mother walked her to the bus stop at nine.", "She gave Haneul a small card with her aunt's phone number."]}, 'CAB')
I[29] = ("Chaeyoung's class kept a jar of tadpoles on the window.",
         {'A': ["Every morning, she checked the jar before the first lesson.", "One day she saw two tiny back legs on a tadpole."],
          'B': ["By June, that small animal was a tiny green frog.", "The class carried the frog to the pond behind school."],
          'C': ["Those back legs grew much longer over the next two weeks.", "Its long black tail slowly became shorter day by day."]}, 'ACB')
KEY = {15:'CBA',16:'CBA',17:'BCA',18:'CBA',19:'BAC',20:'ACB',21:'CBA',22:'BAC',23:'CAB',24:'CAB',25:'BCA',26:'BAC',27:'BCA',28:'CAB',29:'ACB'}
assert all(I[n][2]==KEY[n] for n in KEY) and len(I)==15
