# -*- coding: utf-8 -*-
# 21번 레벨1 본보기 셋 시험 (335번 준비) — 번호는 0부터: 2=3번째, 6=7번째, 16=17번째
I = {
 2: ("My father comes home from work very late every night. He never says one word about his feelings for us. Still, he leaves the small light in the hall on. At home, its warm glow always meets me at the door. To me, that glow is <u>a hug without a sound</u>.",
     "love that a person shows without speaking"),
 6: ("The school built a new stone path around the big field. It curves a long way past the gym and the library. Students almost never use it on their way to class. By summer, a brown line in the grass had become <u>the school's real road</u>. They walk straight across the grass from the gate to the door.",
     "the way people actually walk"),
 16: ("Mr. Han painted the long fence in front of his house. He painted only the street side of the fence bright white. To Mr. Han, that side is <u>a coat of paint for show</u>. The other side, near his yard, is still gray and dirty. Many neighbors praise the bright white street side of the fence.",
      "something done only to look good to others"),
}
