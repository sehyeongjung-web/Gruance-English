# -*- coding: utf-8 -*-
# 원고(d63x.I)와 한글(ko63x_*.K)을 합쳐 pending/edits_X63x.py를 만든다.  python3 draft/gen63.py a   (뒷 절반은 b)
import sys, pprint, importlib, glob, os
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
d = importlib.import_module('d63' + tag)
KO = {}
for p in sorted(glob.glob('/home/claude/work/draft/ko63%s_*.py' % tag)):
    KO.update(importlib.import_module(os.path.basename(p)[:-3]).K)
ns = sorted(d.I)
from lib import load
_tb = load()[1]
OFF = 0 if tag == 'a' else 15
assert all(_tb['21']['1'][n + OFF]['answer'] == d.ANS[n] for n in ns), '정답 자리가 바탕과 다름'
assert sorted(KO) == ns, (sorted(KO), ns)
head = '앞' if tag == 'a' else '뒤'
out = ['# -*- coding: utf-8 -*-',
       '# %s번: 21번(함축 의미) 레벨1 %s 절반 — 다섯 문장 · 문장당 10~15낱말 · 단문 · 밑줄은 둘째~다섯째 문장. 정답 번호는 바탕 그대로, 지문·선택지·해석·풀이·해설을 통째로 다시 씀' % ('335' if tag == 'a' else '337', head),
       'AUTO_SYNC = False', 'E = {}', 'from z21common import maker', "rw = maker(E, '1')", '']
for n in ns:
    text, ch = d.I[n]; k = KO[n]
    out.append('# %d번째 (정답 %s)' % (n + (0 if tag == 'a' else 15) + 1, '①②③④⑤'[d.ANS[n]]))
    out.append('rw(%d, %r,\n   %r,\n   %r,\n   %s,\n   %r,\n   %s,\n   %s,\n   %r)\n' % (n + (0 if tag == 'a' else 15), text, ch, k['ko'], pprint.pformat(k['steps'], width=200), k['confuse'], pprint.pformat(k['reasons'], width=200), pprint.pformat(k['gl'], width=200), k.get('words')))
open('/home/claude/work/pending/edits_X63%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X63%s.py (%d문항)' % (tag, len(ns)))
