# -*- coding: utf-8 -*-
# 21번(함축 의미) 레벨1 앞 절반(1~15번째) 영어 원고 — 335번
#   I[n] = (지문(밑줄은 <u>…</u>), [선택지 다섯], 정답 자리(0~4, 바탕 그대로))      n = 0..14
ANS = [0,2,3,4,2,2,1,0,4,3,2,2,1,0,1]
I = {}
I[0] = ("Mina has practiced the piano every day for ten weeks. She cannot hear any change in her own playing yet. To her teacher, those weeks are <u>the seed under the soil</u>. Mina feels a little sad and tired after so much work. Her teacher tells her to keep playing every single day.",
 ["progress that is still hidden", "a change that anyone can measure", "a seed buried too deep", "a song that is too hard", "ten weeks of work that were wasted"])
I[1] = ("Grandma keeps one old red cookbook on the kitchen table. Oil stains and old cracks cover every page of the book. She opens it almost every single day for dinner ideas. To our family, that cookbook is <u>the book with the broken back</u>. Nobody in the house wants to buy a new one.",
 ["a book kept new on a shelf", "a recipe that is too hard to follow", "a thing used again and again", "a gift for a friend", "a book with missing pages"])
I[2] = ("My father comes home from work very late every night. He never says one word about his feelings for us. Still, he leaves the small light in the hall on. At home, its warm glow always meets me at the door. To me, that glow is <u>a hug without a sound</u>.",
 ["a mistake with the hall light", "a promise to come home much earlier", "a sign of anger at the family", "love that does not need speaking", "a strict rule about coming home at night"])
I[3] = ("We eat dinner at the big wooden table every evening. Grandpa always sat in the chair at the far end. He passed away last winter after a very long illness. Nobody in the family has sat in that chair since then. To all of us, it is still <u>an empty chair with his name on it</u>.",
 ["a space cleared and given away", "a seat placed beside the window", "a chair that is too hard to sit in", "furniture the family does not need now", "a place kept ready for someone who is gone"])
I[4] = ("After school, I always check the floor by our front door. My mother's brown shoes stand there neatly on most afternoons. I look for her shoes before anything else at home. For me, those quiet shoes are <u>the first hello of the day</u>. On other days, the empty floor makes the flat feel cold.",
 ["a loud greeting", "a rule about shoes", "a sign that somebody is home", "a pair of shoes that nobody wears", "a bad habit of leaving things around"])
I[5] = ("My older brother left for university far away in March. We still set four places at the dinner table every night. Nobody in the house ever says his name out loud. For my mother, that empty chair is <u>a loud silence</u>. Every night, each of us glances very quickly at that chair.",
 ["a noisy dinner full of talk", "an angry quarrel at the table", "a sad feeling that nobody talks about", "a plan to buy a new table", "a letter from my older brother at the university"])
I[6] = ("The school built a new stone path around the big field. It curves a long way past the gym and the library. Students almost never use it on their way to class. By summer, a brown line in the grass had become <u>the school's real road</u>. They walk straight across the grass from the gate to the door.",
 ["a road that the school planned first", "the way people actually walk", "a rule about the grass", "a stone path that is long and curved", "a new path that the school wants to build"])
I[7] = ("Jin does not understand the new math lesson at all. She feels too shy in front of the whole class. Her teacher asks the class for questions two different times. Jin keeps her hands in her lap during both times. To her teacher, those quiet hands are <u>questions with no voice</u>.",
 ["a doubt that she never says out loud", "a question the teacher asks two different times", "a student who knows every answer", "a class too large for one teacher", "a hand that has grown tired"])
I[8] = ("My grandmother lives alone in a quiet little village house. She has never turned the key in her gate lock. Her neighbors drop by at any hour of the day. To the whole village, her gate is <u>an open hand at the road</u>. Nobody in the village has ever stolen anything from her.",
 ["a promise signed by both people", "a broken gate", "a house that is unsafe at night", "a lost lock", "trust shown in a small way"])
I[9] = ("My new neighbor knocked on our door last night after dinner. My mother carried a tray with tea into the room. She did not ask him to stay for a talk. Two warm cups of tea sat on her small tray. For the neighbor, that second cup was <u>a place at our table</u>.",
 ["a printed invitation sent to all neighbors by post", "tea made much too quickly", "a cup that nobody needs", "an invitation made without speaking", "a tray that is too heavy to carry"])
I[10] = ("Our old kitchen table has many marks from the past. A deep dent sits in the middle of the wood. My brother dropped a heavy pan there at the age of nine. Nobody in my family wants to sand that spot away. To all of us, that dent is <u>a small page of our family story</u>.",
 ["a surface kept clean and smooth", "furniture that is too old to use", "a mark of everyday life", "a mistake by the table maker", "damage to repair"])
I[11] = ("Ms. Choi shares a big open office with ten other workers. On her first week, she brought a green plant from home. She put it carefully on the corner of her desk. Now nobody else uses that corner of the shared room. For Ms. Choi, that plant is <u>a small flag on her desk</u>.",
 ["a rule for all the workers", "a plant that needs more light", "a small sign that the space is hers", "a desk that is untidy", "an office that is far too crowded"])
I[12] = ("My uncle moved to another city far away last March. His old blue coat still hangs on our hall hook. Nobody in the house has touched it since that day. Every day, my aunt looks at it for a moment. For her, that coat is <u>a goodbye with no ending</u>.",
 ["a visit everybody agreed to long ago", "a farewell not yet finished", "a hall full of coats", "a very old coat", "a hook that came loose from the wall"])
I[13] = ("Every evening at six, the gate outside our house squeaks. Mr. Kim comes home from his job at exactly that time. The old sound tells me the hour without any help. My mother always starts cooking our dinner at that sound. To our family, that squeak is <u>a clock with no hands</u>.",
 ["a regular event that marks the time", "a job that takes a different time each day", "a gate that needs a little oil", "a neighbor with a loud voice", "a clock that shows the wrong time"])
I[14] = ("My aunt always put one extra plate on the table. Nobody in the family expected a guest on those evenings. Still, a stranger once knocked at the door at dinner time. He sat down at the extra place with a grateful smile. For my aunt, that extra plate was <u>a hello in advance</u>.",
 ["a welcome arranged too late", "a greeting planned ahead of time", "a meal cooked and wasted", "a guest who arrives late for dinner", "a plate that nobody at home ever uses"])
assert sorted(I) == list(range(15)) and all(len(v[1]) == 5 for v in I.values())
