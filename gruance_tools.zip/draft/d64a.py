# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨1 앞 절반 영어 원고 (1~15번째). I[n] = (지문 네 문장, 요약문, 선택지 다섯, 정답 자리)
I = {}
I[0] = (["Ice floats on the water of a cold lake in winter.",
         "Frozen water is lighter than liquid water of the same size.",
         "For this reason, the ice never sinks to the bottom of the lake.",
         "The fish below the ice stay safe in the deeper water."],
        "The (A) ______ ice stays at the (B) ______ of the lake all winter.",
        ["heavier - top", "lighter - bottom", "lighter - top", "heavier - bottom", "colder - bottom"], 2)
I[1] = (["Long ago, people put a lot of salt on their meat.",
         "Salt pulls most of the water out of the meat.",
         "Most kinds of bacteria need plenty of water for their growth.",
         "Salted meat can stay fresh for many months even without ice."],
        "Meat with little (A) ______ stays fresh for a (B) ______ time than wet meat.",
        ["water - longer", "salt - longer", "water - shorter", "salt - shorter", "sugar - shorter"], 0)
I[2] = (["An owl can fly through the night without making a sound.",
         "Each wing feather has a soft edge like the teeth of a comb.",
         "This soft edge breaks the air into many tiny streams around the wing.",
         "A hungry mouse on the ground cannot hear the flying owl at all."],
        "The shape of the (A) ______ makes the owl's flight (B) ______.",
        ["comb - silent", "feathers - stronger", "comb - stronger", "beak - stronger", "feathers - silent"], 4)
I[3] = (["A thermos bottle keeps hot soup hot for many hours.",
         "The two glass walls of the bottle have almost no air between them.",
         "Without air, heat can hardly travel across the space between the walls.",
         "The outside of the bottle stays cool to the touch all day."],
        "Without (A) ______ between the walls, heat stays (B) ______ the bottle.",
        ["glass - inside", "air - inside", "air - outside", "glass - outside", "dust - outside"], 1)
I[4] = (["A plant on a window sill grows toward the glass.",
         "The cells on its dark side grow longer than the other cells.",
         "This uneven growth bends the stem toward the bright window light.",
         "Turning the pot a little every week keeps the stem straight."],
        "To stop a plant from leaning toward (A) ______, turn its pot every (B) ______.",
        ["shade - week", "water - month", "light - month", "light - week", "shade - month"], 3)
I[5] = (["A ball of bread dough grows much bigger in a warm place.",
         "Tiny yeast cells in the dough make a lot of gas.",
         "Kneading the dough builds a stretchy net of thin threads.",
         "This net keeps most of the gas inside the soft dough."],
        "The (A) ______ from the yeast is held in the dough by its (B) ______.",
        ["heat - net", "gas - net", "gas - crust", "heat - crust", "water - crust"], 1)
I[6] = (["A small candle burns brightly on a table in a dark room.",
         "Next, a girl puts a tall glass jar over the candle.",
         "The flame uses up much of the oxygen inside the jar very quickly.",
         "After about ten seconds, the small flame goes out for good."],
        "The (A) ______ in the jar is (B) ______ by the flame.",
        ["smoke - used up", "smoke - pushed out", "light - pushed out", "oxygen - used up", "oxygen - pushed out"], 3)
I[7] = (["A very old egg floats high in a glass of water.",
         "A fresh egg sinks to the bottom of the same glass.",
         "Tiny holes in the shell let air slowly replace water inside the egg.",
         "Air inside the egg weighs much less than water in the same space."],
        "Air enters through the (A) ______ to make an old egg (B) ______.",
        ["yolk - lighter", "shell - lighter", "shell - heavier", "yolk - heavier", "cracks - heavier"], 1)
I[8] = (["A field of fresh snow looks bright white on a sunny morning.",
         "Each piece of ice by itself is clear like glass.",
         "However, snow is full of tiny crystals with many flat sides.",
         "Light bounces off the flat sides of the crystals in every direction."],
        "The crystals (A) ______ light in many directions to make snow look (B) ______.",
        ["absorb - white", "scatter - clear", "scatter - white", "absorb - colorless", "block - colorless"], 2)
I[9] = (["A wet cloth on your forehead feels cool on a hot day.",
         "Water slowly dries out of the wet cloth into the air.",
         "Drying water pulls heat out of your warm forehead below the cloth.",
         "Your forehead feels cooler for a few minutes after that."],
        "Drying water takes (A) ______ away from the (B) ______ beneath it.",
        ["cold - skin", "heat - skin", "heat - cloth", "cold - cloth", "sweat - cloth"], 1)
I[10] = (["Sound is a shaking movement of the things around us.",
          "It travels through air, water, and even a metal door.",
          "Deep space has almost no air or anything else in it.",
          "A loud explosion in space makes no sound for any listener."],
         "There is no (A) ______ to carry sound in deep (B) ______.",
         ["matter - space", "sunlight - space", "matter - water", "sunlight - water", "warmth - water"], 0)
I[11] = (["Small drops of water cover the grass early in the morning.",
          "At night, the grass gives off heat faster than the air.",
          "Soon the grass is much colder than the air around it.",
          "Water vapor in the air turns into tiny drops on the cold grass."],
         "The (A) ______ grass makes water vapor in the air turn into (B) ______.",
         ["warmer - water", "colder - frost", "warmer - frost", "colder - water", "freezing - frost"], 3)
I[12] = (["Many trees lose all of their leaves in the late autumn.",
          "In winter, the ground around the roots is frozen hard.",
          "Frozen ground gives the roots almost no water to take in.",
          "Leaves lose a lot of water into the air every day."],
         "To save (A) ______ in the winter, many trees drop their (B) ______.",
         ["heat - leaves", "water - roots", "heat - roots", "sunlight - roots", "water - leaves"], 4)
I[13] = (["A bat finds its food in the dark with a special sound.",
          "The echo from a flying insect comes back to the bat's ears.",
          "Some moths can hear the high sound of an approaching bat.",
          "At that moment, the moth drops straight down toward the ground."],
         "After hearing a bat's (A) ______, a moth escapes by (B) ______.",
         ["smell - falling", "sound - freezing", "smell - freezing", "eyes - freezing", "sound - falling"], 4)
I[14] = (["A compass needle turns toward the magnetic north pole of Earth.",
          "This pole is a little away from the true north pole.",
          "The angle between the two north directions changes from place to place.",
          "Careful map makers print a small adjustment for this angle on their maps."],
         "The (A) ______ north of a compass needs a printed (B) ______ on maps.",
         ["true - correction", "magnetic - instruction", "true - instruction", "magnetic - correction", "local - instruction"], 3)
