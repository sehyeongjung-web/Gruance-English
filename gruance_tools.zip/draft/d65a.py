# -*- coding: utf-8 -*-
# 29번(어법) 레벨1 앞 절반 영어 원고 (1~15번째). I[n] = dict(cat, S=[다섯 문장(표시 ①~⑤ 한 번씩, 정답 자리는 틀린 꼴)], cw=올바른 꼴)
# cat: sv(주어-동사 일치) · past(과거형) · modal(조동사 뒤 원형) · plural(명사의 -s) · pron(대명사 자리)
I = {}
I[0] = dict(cat='sv', cw='swim', S=[
 "My grandfather ①walks along the river near our house every morning.",
 "He ②carries a small bag of bread for the hungry ducks.",
 "The white ducks ③swims toward him across the cold river water.",
 "Grandfather slowly ④gives each duck a little piece of bread.",
 "Then the happy ducks ⑤eat quietly under the big tree near the bridge."])
I[1] = dict(cat='past', cw='found', S=[
 "My family ①went to the lake for a picnic yesterday.",
 "My father ②carried a heavy bag of food from the car.",
 "In the afternoon, my little sister ③find a pretty stone by the water.",
 "We ④ate sandwiches and fruit on the soft grass by the lake.",
 "Everyone in the car ⑤was very happy on the long drive home."])
I[2] = dict(cat='sv', cw='smiles', S=[
 "Mr. Kim ①drives a big yellow bus to our school every day.",
 "He ②knows the name of every child on the bus.",
 "The children ③wave to him at the corner each morning.",
 "Mr. Kim ④smile at the children from his seat by the door.",
 "Every child ⑤feels very safe on his big yellow bus."])
I[3] = dict(cat='modal', cw='play', S=[
 "My little brother can ①read many short books by himself.",
 "He ②plays the guitar in our school band on Fridays.",
 "He still cannot ③plays the piano very well in front of people.",
 "Next year, he will ④join the school soccer team with his friends.",
 "My parents ⑤are very proud of his hard work and good grades."])
I[4] = dict(cat='plural', cw='posters', S=[
 "My large classroom has two big ①windows near the school playground.",
 "There are thirty ②desks in long rows on the floor.",
 "The back wall has four large ③poster with pictures of animals.",
 "Each ④student keeps a small box under the desk in class.",
 "Many ⑤books stand on the long shelf beside the door."])
I[5] = dict(cat='pron', cw='her', S=[
 "My cousin Anna ①lives in a small town by the sea.",
 "②She visits our house in the summer with her mother and father.",
 "I always show ③she the best shops near my house.",
 "④We walk along the long beach near my house every evening.",
 "My friends at school ask ⑤me about our fun days with her."])
I[6] = dict(cat='sv', cw='keeps', S=[
 "The town library ①opens its big doors at nine every morning.",
 "Many young students ②come there to read interesting books after school.",
 "The librarian ③helps them find books about animals and space.",
 "She always ④keep the reading room very clean for every visitor.",
 "The students ⑤enjoy their quiet time in this warm place."])
I[7] = dict(cat='past', cw='fell', S=[
 "Our school ①held its big sports day on the large field last Friday.",
 "My class ②ran in the first race in the morning.",
 "Our team ③won the second race by only a few seconds.",
 "My best friend ④fall down near the last turn of the race.",
 "Our teacher ⑤gave all of us a small prize after the race."])
I[8] = dict(cat='modal', cw='walk', S=[
 "Dolphins ①live in the warm water near the beach all year.",
 "They can ②swim very fast through the deep blue sea.",
 "They can also ③jump very high above the water in the sun.",
 "Dolphins cannot ④walks on land like a dog or a cat.",
 "Many visitors will ⑤see them from the boat next summer."])
I[9] = dict(cat='past', cw='made', S=[
 "Yesterday morning, my father ①woke up very early to make breakfast.",
 "He ②make eggs and toast for the whole family in the kitchen.",
 "My mother ③thanked him with a big smile at the table.",
 "I ④drank two glasses of cold milk with my toast.",
 "We all ⑤felt very happy after that big breakfast at home."])
I[10] = dict(cat='plural', cw='eggs', S=[
 "Our big farm has ten ①cows in a green field.",
 "There are also two ②horses and one old sheep near the house.",
 "Many white ③chickens walk around the yard all day long.",
 "The farmer collects six ④egg from the nest every morning.",
 "Each fresh ⑤egg goes into a small paper box for the market."])
I[11] = dict(cat='sv', cw='sleep', S=[
 "In summer, the sun ①rises very early in the morning.",
 "My mother ②wakes up with the first light of the sun.",
 "She ③opens all the windows in our small house for fresh air.",
 "My two brothers ④help her with the morning work in the kitchen.",
 "On Sundays, I ⑤sleeps until eight o'clock in my soft bed."])
I[12] = dict(cat='past', cw='came', S=[
 "Last summer, my class ①went to a camp in the mountains.",
 "We ②slept in small green tents near a quiet river.",
 "Our guide ③showed us the stars on the first night.",
 "Some of the boys ④swam in the cold river every afternoon.",
 "Everybody ⑤come home with a big smile on the last day."])
I[13] = dict(cat='modal', cw='read', S=[
 "My grandmother ①has a new phone from my uncle in Busan.",
 "She can ②call all of her friends with just one button.",
 "She can also ③take pictures of the flowers in her garden.",
 "She will ④send the best pictures to our family tonight.",
 "She cannot ⑤reads small letters on the screen without her glasses."])
I[14] = dict(cat='plural', cw='books', S=[
 "My small room has one big ①window above my old bed.",
 "Two ②shelves hold all of my favorite books and toys.",
 "A large ③map of the world hangs on the wall.",
 "Three green ④plants stand on the table near the door.",
 "My mother gives me five new ⑤book every year as a gift."])
