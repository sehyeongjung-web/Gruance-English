# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨1 뒤 절반 영어 원고 (16~30번째). I[n] = (지문 네 문장, 요약문, 선택지 다섯, 정답 자리)  — n은 15~29
I = {}
I[15] = (["Honey in a sealed jar can stay good for many years.",
          "Bees fan the nectar with their wings to dry it out.",
          "Honey therefore holds very little water for bacteria to use.",
          "Without enough water, bacteria cannot grow in the thick honey."],
         "Honey with (A) ______ water stops bacteria from (B) ______ in the jar for many years.",
         ["plenty of - growing", "little - dying", "little - growing", "plenty of - dying", "salty - dying"], 2)
I[16] = (["An iron tool in the rain slowly turns red with rust.",
          "Rust needs both water and air to form on iron.",
          "A thin layer of oil stops water from touching the iron.",
          "Oiled tools stay clean for many years in a damp shed."],
         "A thin coat of (A) ______ keeps (B) ______ away from the iron tool.",
         ["salt - water", "oil - light", "oil - water", "air - light", "salt - light"], 2)
I[17] = (["Geese often fly across the sky in the shape of a V.",
          "Each follower flaps its wings in the rising air behind the bird ahead.",
          "This rising air gives each follower a free lift in flight.",
          "Only the leader at the front must push through still air."],
         "Every goose saves (A) ______ except the leader at the (B) ______.",
         ["time - front", "effort - back", "effort - front", "distance - front", "feathers - back"], 2)
I[18] = (["A bar magnet has a north end and a south end.",
          "A girl cuts the bar magnet in half with a strong saw.",
          "Each half still has its own north end and south end.",
          "A single end of a magnet can never be found alone."],
         "Cutting a magnet in half makes (A) ______ small magnets with (B) ______ ends each.",
         ["three - four", "two - four", "three - two", "two - two", "four - four"], 3)
I[19] = (["A dry seed in a jar stays asleep for many years.",
          "To start growing, the seed needs water, warmth, and air.",
          "A seed with only water and warmth still cannot start growing.",
          "A seed in cold, dry soil stays asleep through the winter."],
         "Without one of the (A) ______ things, a seed stays (B) ______.",
         ["four - awake", "three - asleep", "four - asleep", "three - wide awake", "two - wide awake"], 1)
I[20] = (["A hermit crab uses an empty shell as a small house.",
          "A tortoise can never step out of its own shell.",
          "The ribs and backbone of a tortoise are joined to its shell.",
          "A deep crack in the shell hurts the tortoise like a broken bone."],
         "The tortoise's shell, part of its (A) ______, can suffer a serious (B) ______.",
         ["skin - injury", "skeleton - illness", "house - injury", "clothing - sunburn", "skeleton - injury"], 4)
I[21] = (["A stick hits the skin of a drum to make a sound.",
          "The skin then shakes back and forth many times each second.",
          "A tighter skin shakes more times each second than a loose skin.",
          "Many shakes each second make the sound of the drum higher."],
         "A tighter skin shakes (A) ______ times each second to give a (B) ______ sound.",
         ["fewer - lower", "more - lower", "fewer - higher", "more - louder", "more - higher"], 4)
I[22] = (["A kite without a tail often spins wildly in the strong wind.",
          "A long tail adds drag to the bottom of the kite.",
          "This extra drag keeps the kite from turning around in the wind.",
          "A kite with a long tail flies steadily in the strong wind."],
         "A tail keeps a kite (A) ______ by adding (B) ______ to its bottom.",
         ["steady - drag", "brighter - drag", "steady - wind", "steady - lift", "stronger - lift"], 0)
I[23] = (["Soap helps water wash away the grease on dirty plates.",
          "Plain water alone slides over a layer of grease without picking it up.",
          "One end of each soap molecule is attracted to water.",
          "The other end of the same molecule sticks tightly to grease."],
         "Soap acts as a bridge between (A) ______ and (B) ______ during washing.",
         ["water - grease", "sponge - grease", "water - sponge", "plates - grease", "water - soap"], 0)
I[24] = (["Lightning and thunder happen at the same moment in a storm.",
          "A flash of light moves through the air much more quickly than sound.",
          "Thunder from a faraway storm therefore reaches you after a long wait.",
          "Thunder from a nearby storm reaches you after only a short wait."],
         "With light much (A) ______ than sound, a faraway storm gives you a (B) ______ wait.",
         ["slower - long", "faster - short", "slower - short", "brighter - short", "faster - long"], 4)
I[25] = (["A pencil in a glass of water looks bent at the surface.",
          "Light from the pencil travels more slowly in water than in air.",
          "This change makes the light turn at the surface of the water.",
          "Our eyes follow the turned light back in a straight line."],
         "A change in the light's (A) ______ makes the pencil look (B) ______.",
         ["color - bent", "direction - darker", "color - darker", "direction - bent", "brightness - colored"], 3)
I[26] = (["A water pipe can burst in very cold winter weather.",
          "Water takes up more room as ice than as liquid.",
          "The growing ice pushes hard against the walls of the pipe.",
          "Soon a long crack appears in the wall of the pipe."],
         "Growing ice puts (A) ______ force on a pipe wall to cause a (B) ______.",
         ["weak - crack", "strong - bubble", "strong - crack", "weak - bubble", "gentle - stain"], 2)
I[27] = (["Earth is actually closest to the sun in early January.",
          "The northern half of Earth has cold winter weather in January.",
          "A tilted axis gives northern places slanted sunlight in January.",
          "Slanted sunlight spreads over a wider area of the ground."],
         "The seasons depend on Earth's (A) ______, not on its (B) ______ from the sun.",
         ["tilt - distance", "distance - tilt", "speed - distance", "tilt - size", "speed - size"], 0)
I[28] = (["Sound travels about four times faster in water than in air.",
          "Water molecules sit much closer together than the molecules in air.",
          "A shaking molecule quickly pushes the next molecule beside it.",
          "Close neighbors pass the shaking along from place to place faster."],
         "Water's (A) ______ molecules carry sound much (B) ______ than the molecules of air.",
         ["crowded - faster", "scattered - faster", "crowded - slower", "scattered - slower", "bigger - louder"], 0)
I[29] = (["Fresh bread slowly turns hard after a few days on a table.",
          "Starch in the bread slowly changes its form day by day.",
          "This change is fastest at cool temperatures just above freezing.",
          "A home fridge holds food at about that cool temperature."],
         "In a fridge, the (A) ______ in bread changes (B) ______ than on a table.",
         ["yeast - sooner", "starch - sooner", "starch - more slowly", "yeast - more slowly", "protein - more slowly"], 1)
