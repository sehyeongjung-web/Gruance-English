# -*- coding: utf-8 -*-
# 29번(어법) 레벨1 뒤 절반 영어 원고 (16~30번째). 꼴은 d65a.py와 같음
I = {}
I[15] = dict(cat='pron', cw='He', S=[
 "My father ①cooks a big dinner for our family on Saturdays.",
 "②Him makes the best noodle soup in our whole town.",
 "My cousin and I ③help him in the busy kitchen every week.",
 "He always gives ④us easy jobs like washing the vegetables.",
 "⑤We love his noodle soup more than any other food."])
I[16] = dict(cat='modal', cw='walk', S=[
 "Tomorrow, my friends and I will ①ride our bikes to the big park.",
 "Kate can ②carry all the water bottles in her blue bag.",
 "Her father will ③bring some fruit and bread for lunch.",
 "Jun cannot ④ride fast on the hill with a broken bike.",
 "He can ⑤walks to the park with his own small dog."])
I[17] = dict(cat='sv', cw='is', S=[
 "My aunt ①owns a small bakery near the train station.",
 "The bakery ②are always full of people in the morning.",
 "Her fresh bread ③smells wonderful to everyone on the street.",
 "Two workers ④make cakes and cookies in the back room.",
 "The small cookies ⑤are very cheap for students after school."])
I[18] = dict(cat='sv', cw='has', S=[
 "My school ①has a large garden behind the main building.",
 "Many students ②grow tomatoes and peppers there in the spring.",
 "Our teacher ③have a small room for the garden tools.",
 "The students ④use these tools after their last lesson on Wednesday.",
 "Every vegetable from the garden ⑤tastes better after hard work."])
I[19] = dict(cat='pron', cw='She', S=[
 "Sora and her little brother ①walk to school together every day.",
 "②Her carries both school bags up the long hill on rainy days.",
 "The little boy ③thanks her with a big smile at the gate.",
 "④They stop at a small shop near the school gate.",
 "The kind old owner gives ⑤them some free candy on Fridays."])
I[20] = dict(cat='past', cw='held', S=[
 "Last night, a strong wind ①blew across our small town for hours.",
 "Heavy rain ②fell on the old roof of our house until midnight.",
 "My little sister ③hid under a thick blanket on my bed.",
 "I ④hold her hand for a long time that night.",
 "The storm ⑤ended at six on the next sunny morning."])
I[21] = dict(cat='sv', cw='reaches', S=[
 "My baby sister ①sleeps for ten hours every night in her bed.",
 "She ②wakes up with a loud cry at six in the morning.",
 "My mother ③gives her warm milk in a small bottle.",
 "My father ④plays soft music for her in the quiet room.",
 "The baby ⑤reach for her toys with both small hands."])
I[22] = dict(cat='sv', cw='live', S=[
 "My two cousins ①lives in a big city far from my town.",
 "Their new house in the city ②has a big window in every room.",
 "Every month, they ③visit us by train with their parents.",
 "My aunt ④brings us fresh cheese from the city market.",
 "We ⑤eat it with warm bread at home after each visit."])
I[23] = dict(cat='past', cw='visited', S=[
 "I ①visit my grandparents in their country house last winter.",
 "We ②built a big snowman in the front yard that week.",
 "My grandfather ③made it a hat from an old newspaper.",
 "My grandmother ④took many photos of us in the white snow.",
 "That night, we all ⑤drank hot tea by the warm fire."])
I[24] = dict(cat='modal', cw='use', S=[
 "Our science club ①meets every Thursday after school in room ten.",
 "Members can ②uses the new computers on the big table in the room.",
 "New members must always ③ask the teacher for help first.",
 "Everyone should ④wear a white coat in the science room.",
 "Next month, our club will ⑤visit a big science museum together."])
I[25] = dict(cat='plural', cw='monkeys', S=[
 "At the zoo, I see four ①monkey in the tall tree near the gate.",
 "One small ②monkey eats a yellow banana on a high branch.",
 "Two ③babies hold on to their mother with both arms.",
 "Many happy ④visitors take pictures of the monkeys all day long.",
 "Each ⑤monkey has its own name on a sign by the fence."])
I[26] = dict(cat='pron', cw='We', S=[
 "Tom and ①I are in the same class this year.",
 "②Us sit together in the last row near the window.",
 "Our kind teacher knows ③us very well after many long months.",
 "④She often gives us hard questions about math on Fridays.",
 "Tom always helps ⑤me with the hard ones after school."])
I[27] = dict(cat='pron', cw='I', S=[
 "①Me like swimming in the big pool with my cousin Mia.",
 "②She teaches me new tricks in the water every weekend.",
 "Our new coach tells ③us to practice hard every night.",
 "④We swim together in the same lane at the city pool.",
 "My mother watches ⑤me from the seats near the pool."])
I[28] = dict(cat='plural', cw='boxes', S=[
 "I have two ①box of colored pencils in my school bag.",
 "Each ②box holds twelve long pencils in many different colors.",
 "I use red and blue ③pencils for my science notes.",
 "My best friend borrows three ④pencils from me each week.",
 "She always gives back every ⑤pencil on the next day."])
I[29] = dict(cat='there', cw='are', S=[
 "There ①is two parks near the school in my town.",
 "One park ②has a small pond with many white ducks.",
 "The other park ③has a big playground for little children.",
 "Many families ④visit these two parks on warm sunny days.",
 "My little brother ⑤runs around the pond for a long time."])
