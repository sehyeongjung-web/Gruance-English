# -*- coding: utf-8 -*-
# 원고(d64x.I)와 한글(k64x_*.K)을 합쳐 pending/edits_X64x.py를 만든다.  python3 draft/gen64.py a   (뒷 절반은 b)
import sys, pprint, importlib, glob, os
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
d = importlib.import_module('d64' + tag)
KO = {}
for p in sorted(glob.glob('/home/claude/work/draft/k64%s_*.py' % tag)):
    KO.update(importlib.import_module(os.path.basename(p)[:-3]).K)
ns = sorted(d.I)
from lib import load
_tb = load()[1]
assert all(_tb['40']['1'][n]['answer'] == d.I[n][3] for n in ns), '정답 자리가 바탕과 다름'
assert sorted(KO) == ns, (sorted(KO), ns)
head = '앞' if tag == 'a' else '뒤'
out = ['# -*- coding: utf-8 -*-',
       '# %s번: 40번(요약문 완성) 레벨1 %s 절반 — 지문 네 문장 + 요약문 한 문장(단문) · 문장당 10~15낱말. 정답 번호는 바탕 그대로, 지문·요약문·선택지·해석·풀이·해설을 통째로 다시 씀' % ('338' if tag == 'a' else '339', head),
       'AUTO_SYNC = False', 'E = {}', 'from z40rw import maker', "rw = maker(E, '1')", '']
for n in ns:
    P, SM, CH, a = d.I[n]; k = KO[n]
    out.append('# %d번째 (정답 %s)' % (n + 1, '①②③④⑤'[a]))
    out.append('rw(%d, %s,\n   %r,\n   %s,\n   %r,\n   %r,\n   %s,\n   %r,\n   %s,\n   %s,\n   %r)\n' % (n, pprint.pformat(P, width=200), SM, pprint.pformat(CH, width=200), k['kop'], k['kosm'], pprint.pformat(k['steps'], width=200), k['trap'], pprint.pformat(k['reasons'], width=200), pprint.pformat(k['gl'], width=200), k.get('words')))
open('/home/claude/work/pending/edits_X64%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X64%s.py (%d문항)' % (tag, len(ns)))
