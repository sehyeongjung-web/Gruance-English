# -*- coding: utf-8 -*-
# 원고(d62x.I)와 한글(ko62x_*.D)을 합쳐 pending/edits_X62x.py를 만든다.  python3 draft/gen62.py a   (뒷 절반은 b — 번호 n은 0~14로 같은 칸이 아니라 문항 번호-1)
import sys, pprint, importlib
sys.path.insert(0, '/home/claude/work/draft')
tag = sys.argv[1]
d = importlib.import_module('d62' + tag)
KO = {}
import glob, os
for p in sorted(glob.glob('/home/claude/work/draft/ko62%s_*.py' % tag)):
    KO.update(importlib.import_module(os.path.basename(p)[:-3]).D)
ns = sorted(d.I)
assert sorted(KO) == ns, (sorted(KO), ns)
head = '앞' if tag == 'a' else '뒤'
out = ['# -*- coding: utf-8 -*-',
       '# 333번: 36-37번(글의 순서) 레벨1 %s 절반 — 단순문장 · 한 문장 10~15낱말 · 세 덩이 각 두 문장. 정답 번호·선택지·발문은 바탕 그대로, 지문·해석·풀이·해설을 통째로 다시 씀' % head,
       'AUTO_SYNC = False', 'E = {}', 'from z3637common import maker', "rw = maker(E, '1')", '']
for n in ns:
    g, P, order = d.I[n]; k = KO[n]
    out.append('# %d번째 (정답 순서 %s)' % (n + 1, order))
    out.append('rw(%d, %r,\n   %s,\n   %r,\n   %s,\n   %s,\n   %r,\n   %s,\n   %r)\n' % (n, g, pprint.pformat(P, width=200), k['kg'], pprint.pformat(k['K'], width=200), pprint.pformat(k['steps'], width=200), k['confuse'], pprint.pformat(k['cn'], width=200), k.get('words')))
open('/home/claude/work/pending/edits_X62%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X62%s.py (%d문항)' % (tag, len(ns)))
