# -*- coding: utf-8 -*-
# 36-37번 레벨1 앞 절반(1~15번째) 원고. I[n] = (주어진 글, {'A': [...], 'B': [...], 'C': [...]}, 정답 순서)
I = {}
I[0] = ("Last Saturday, Tom baked cookies for the first time in his life.",
        {'A': ["After that hour, he cut the cold dough into twelve small round pieces.", "He left them in the hot oven for fifteen minutes."],
         'B': ["Those fifteen minutes were too long for such small cookies.", "Tom's first cookies came out of the oven dark and hard."],
         'C': ["In the morning, he mixed flour, sugar and butter into a soft dough.", "He then put the dough in the fridge for one full hour."]}, 'CAB')
I[1] = ("Lily grew three small tomato plants in pots by her bedroom window.",
        {'A': ["Their leaves slowly turned yellow one after another in early June.", "Lily gave the plants more and more water every day."],
         'B': ["He gave the plants very little water for the next ten days.", "After that, new green leaves appeared on all three of her plants."],
         'C': ["However, all that extra water only turned more of the leaves yellow.", "Her grandfather shook his head at the wet soil in the pots."]}, 'ACB')
I[2] = ("On a rainy Monday, Jiho left his blue umbrella on the bus.",
        {'A': ["At home, he called the bus company about his lost umbrella.", "A kind woman wrote down his name and his phone number."],
         'B': ["On Friday after school, he went to that office alone.", "The woman gave the umbrella back to him with a smile."],
         'C': ["She later called him back with some very good news.", "His blue umbrella was waiting at the bus station office."]}, 'ACB')
I[3] = ("On Lunar New Year's Day, many Korean families eat tteokguk together in the morning.",
        {'A': ["Because of this coin shape, the soup holds a wish for more money.", "So every bowl of this soup carries two good wishes for the new year."],
         'B': ["This soup has many thin white slices of rice cake in it.", "Their white color means a clean start to the year."],
         'C': ["The shape of the slices also has a different meaning.", "Each of them looks a little like an old Korean coin."]}, 'BCA')
I[4] = ("Hyunwoo wanted to play the guitar at the school festival.",
        {'A': ["By October, his fingers no longer hurt after all that practice.", "He then asked his music teacher to put his name on the festival list."],
         'B': ["His uncle gave him an old guitar on his birthday.", "Every night after dinner, Hyunwoo practiced one easy song again and again."],
         'C': ["At the festival, his name was first on that list.", "Hyunwoo played the whole song on the big stage without a mistake."]}, 'BAC')
I[5] = ("A small brown puppy followed Yuna home from school one rainy day.",
        {'A': ["The next morning, the puppy was warm and full of energy.", "Yuna's mother called the neighbors to find its real owner."],
         'B': ["Yuna's mother did not want a dog in their small apartment.", "However, she let the cold puppy sleep in the kitchen that night."],
         'C': ["At noon, the real owner came to their door in a hurry.", "He thanked Yuna's family for taking care of the puppy."]}, 'BAC')
I[6] = ("Bees make honey from the sweet juice of many flowers.",
        {'A': ["A worker bee drinks the juice from hundreds of flowers each day.", "She carries it home in a special part of her body."],
         'B': ["Next, the bees move their wings quickly over those cells.", "After many hours, the thin sweet juice becomes thick honey."],
         'C': ["At the hive, other bees take the juice from her mouth.", "They then put it into thousands of tiny wax cells."]}, 'ACB')
I[7] = ("Our class planned a surprise party for Mr. Kim's birthday.",
        {'A': ["We hid the cake in a big box in the classroom.", "Everyone waited quietly for Mr. Kim to come through the door."],
         'B': ["Every student gave two thousand won to the class leader.", "With that money, the leader bought a big chocolate cake."],
         'C': ["At that moment, the teacher stood at the door with a surprised look.", "Then we all sang a happy birthday song to him."]}, 'BAC')
I[8] = ("Sora started at a new middle school in the spring.",
        {'A': ["That shared hobby soon made the two girls good friends.", "Now Sora walks into the school with a big smile every morning."],
         'B': ["The girl asked Sora about her old school and her hobbies.", "Both of them loved drawing cartoons in their free time."],
         'C': ["Everything in the big building looked new and strange to her.", "At lunch, a girl with short hair sat beside her."]}, 'CBA')
I[9] = ("Camels can walk across the hot desert for many days.",
        {'A': ["With these two helpers, a camel can cross the hot desert safely.", "People often call the camel the ship of the desert."],
         'B': ["The hump on a camel's back holds fat, not water.", "This fat is the first helper on long walks without food."],
         'C': ["However, a thirsty camel needs a second helper besides fat.", "A camel can drink a huge amount of water within minutes."]}, 'BCA')
I[10] = ("Last winter, Minjae joined the running club at his middle school.",
        {'A': ["After all that work, Minjae ran ten laps around the track in April.", "Ms. Park then put his name on the list for the city race."],
         'B': ["Minjae followed that plan three times a week for two months.", "Slowly, the laps became easier for him week after week."],
         'C': ["At first, he could not run even one lap of the track.", "His coach, Ms. Park, gave him a short training plan."]}, 'CBA')
I[11] = ("Hangeul is the great writing system of all Korean people.",
         {'A': ["He announced the new letters to the whole country in 1446.", "Since then, many people have learned Hangeul quickly and easily."],
          'B': ["Long ago, ordinary people had no easy letters for their language.", "Most of them could not read or write the hard Chinese characters."],
          'C': ["King Sejong felt very sorry for those ordinary people and their problem.", "In 1443, he made easy new letters for them to use."]}, 'BCA')
I[12] = ("Bomi borrowed a mystery book from the town library last week.",
         {'A': ["She read the whole story in just two nights at home.", "On the last page, she found an old photo of a little girl."],
          'B': ["Many years ago, the librarian herself was that little girl.", "She thanked Bomi warmly for finding her old photo at last."],
          'C': ["She took the photo to the library the next morning.", "The librarian looked at the little girl in the photo very carefully."]}, 'ACB')
I[13] = ("A compass helps hikers find their way in a large forest.",
         {'A': ["The Earth is also a giant magnet with its own two ends.", "One end of the needle is pulled toward the north."],
          'B': ["Hikers can then use that direction to read their map.", "In this way, a small tool keeps hikers safe in the forest."],
          'C': ["Inside it, a thin metal needle turns freely on a tiny point.", "That thin needle is really a small magnet with two ends."]}, 'CAB')
I[14] = ("Last summer, a strong storm hit Hajin's small village by the sea.",
         {'A': ["Soon, students from a nearby town came to help them with that work.", "They worked beside the tired villagers for three long weekends."],
          'B': ["After those weekends, the harbor looked clean and full of boats again.", "The villagers thanked the students with a big party at the harbor."],
          'C': ["The strong waves damaged twenty boats near the harbor wall.", "The villagers needed help with the repair and cleaning work right away."]}, 'CAB')
