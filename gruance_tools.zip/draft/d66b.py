# -*- coding: utf-8 -*-
# 30번(어휘) 레벨1 뒤 절반 영어 원고 (343번). I[n] = dict(cw=올바른 말, S=[다섯 문장])
I = {}
I[15] = dict(cw='polite', S=[
 "Mia is always ①rude to her teachers and classmates at school.",
 "She says please and ②thank you to everyone in the hall.",
 "Her classmates ③like her warm and friendly smile very much.",
 "She always ④holds the door open for people behind her.",
 "Everyone at her school ⑤respects her for her very good manners."])
I[16] = dict(cw='open', S=[
 "The town library is ①closed from morning to night every day.",
 "Many children ②visit it to read comics and storybooks after school.",
 "Students may ③borrow up to five books for two weeks.",
 "A kind young librarian ④helps them find the right book.",
 "The room is ⑤quiet, with soft light and warm chairs."])
I[17] = dict(cw='strong', S=[
 "My grandfather is still very ①weak at the age of eighty.",
 "Every day he ②carries heavy boxes of fruit to the market.",
 "He ③walks two miles each morning on the steep hill.",
 "Young workers at the market ④admire his energy and his kind heart.",
 "His doctor finds him ⑤healthier than many people half his age."])
I[18] = dict(cw='after', S=[
 "Every Friday, Dad ①cooks a big dinner in our small kitchen.",
 "Mom ②sets the table with clean plates, forks, and cups.",
 "Our old brown dog ③waits quietly near the kitchen door.",
 "At seven o'clock, we all ④eat dinner together at the table.",
 "At eight o'clock, Ben and I wash the dishes ⑤before dinner."])
I[19] = dict(cw='wet', S=[
 "After the big storm, all the streets in town were ①dry.",
 "Big ②puddles stood at every corner near the old park.",
 "Happy children ③jumped in them with their bright yellow rain boots.",
 "Fast cars ④splashed cold water across the wide sidewalk again.",
 "By noon, the warm yellow sun ⑤appeared in the clear sky."])
I[20] = dict(cw='sour', S=[
 "The fresh lemon tea tasted very ①sweet to Jake at first.",
 "His whole face ②twisted into a funny shape after one sip.",
 "His little sister ③laughed at his funny face from the door.",
 "Jake ④added two big spoons of sugar to the cup.",
 "Now the warm tea tasted ⑤much better to him at last."])
I[21] = dict(cw='easy', S=[
 "Mr. Park gave his class a ①short math test on Monday.",
 "The test questions were ②simple for everyone in the room.",
 "Most students ③finished the whole page in only ten minutes.",
 "Mr. Park ④smiled at the correct answers on the pages.",
 "In the end, the whole class called the short math test ⑤difficult."])
I[22] = dict(cw='asleep', S=[
 "The house was ①dark and quiet at midnight on Saturday.",
 "The baby ②slept in her small bed by the window.",
 "Dad ③turned off the old television in the living room.",
 "Mom ④closed the window to keep out the cold air.",
 "Soon everyone in the whole house was ⑤awake under warm blankets."])
I[23] = dict(cw='full', S=[
 "After the big family lunch, Nina's plate was ①empty again.",
 "Her little brother ②ate three bowls of hot rice and soup.",
 "Their proud father ③laughed at the little boy's big appetite.",
 "At the end, they ④drank cold barley tea from tall glasses.",
 "Both children felt ⑤hungry after such a big and tasty lunch."])
I[24] = dict(cw='dangerous', S=[
 "A rainy road can be very ①slippery for people on bicycles.",
 "Thin bicycle tires ②slide easily on the cold wet ground.",
 "Fast riding in the rain is ③safe for everyone on the road.",
 "Smart riders ④slow down before every sharp curve in town.",
 "Bright yellow jackets ⑤help drivers see people on bicycles at dusk."])
I[25] = dict(cw='cooler', S=[
 "An old basement is a good place to keep ①vegetables fresh.",
 "The ground around the thick walls ②cools the air inside the room.",
 "In summer, a basement is much ③warmer than the rooms upstairs.",
 "Potatoes and onions ④last for many months in the dark.",
 "Apples on the lower shelves ⑤stay crisp and sweet for many weeks."])
I[26] = dict(cw='clean', S=[
 "Jin's mother loves to keep the ①kitchen neat and tidy.",
 "She always ②wipes the long wooden table after every meal.",
 "The sink in her kitchen is always ③dirty, with no plates in it.",
 "Every spoon and cup ④shines on the drying rack by the window.",
 "Visitors always ⑤praise her kitchen for its fresh smell and bright light."])
I[27] = dict(cw='dropped', S=[
 "Our city has built many new ①bike lanes since last year.",
 "More people ②ride to work by bicycle in our city these days.",
 "As a result, the number of cars on the main road ③increased.",
 "The air in the middle of downtown ④feels much cleaner than before.",
 "Many shop owners ⑤enjoy the quiet streets in front of their stores."])
I[28] = dict(cw='bright', S=[
 "The artist's studio has a ①huge window on the east wall.",
 "Warm morning sunlight ②pours through the glass on most days.",
 "The whole room is ③dim from early morning to noon.",
 "Paint colors ④look clear and strong in that room all year.",
 "Many young art students ⑤come to paint in that studio each week."])
I[29] = dict(cw='remembers', S=[
 "Kim has a ①great memory for the names of new people.",
 "He ②meets many new customers at the bank every week.",
 "He ③forgets each name even after a long, busy day.",
 "His friendly greeting makes those customers ④feel special every single week.",
 "Everyone in the neighborhood ⑤likes him for his kind heart."])
