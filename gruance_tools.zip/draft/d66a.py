# -*- coding: utf-8 -*-
# 30번(어휘) 레벨1 앞 절반 영어 원고 (342번). I[n] = dict(cw=올바른 말, S=[다섯 문장]) — 정답 자리(문장 번호)는 바탕 그대로, 그 자리의 낱말은 틀린 말로 씀
I = {}
I[0] = dict(cw='smiled', S=[
 "Tom was very ①happy on the morning of his tenth birthday.",
 "He ②frowned at the shiny new soccer ball from his father.",
 "His friends were ③glad to see such a nice gift.",
 "They ④kicked it around the park all afternoon with great joy.",
 "That night, Tom felt ⑤thankful for his father and his new ball."])
I[1] = dict(cw='cold', S=[
 "It was a ①snowy morning on the hill near Mia's house.",
 "Her small fingers felt ②hot inside her thin wool gloves all morning.",
 "Mia ③pulled a thick red hat down over her ears.",
 "The ④deep white snow made every step slow and hard.",
 "At home, a ⑤warm cup of milk was waiting for her."])
I[2] = dict(cw='early', S=[
 "The airport was ①empty at six o'clock in the morning.",
 "Our family arrived ②late at the airport, long before the first plane.",
 "We ③waited on soft chairs near a big window with Grandma.",
 "The sky ④turned pink over the long gray runway at last.",
 "Soon our big plane ⑤rose into the bright morning sky."])
I[3] = dict(cw='quick', S=[
 "The school race started at ten o'clock on a ①sunny Saturday.",
 "With ②slow steps, Eli reached the finish line before every other runner.",
 "The crowd on the hill ③cheered loudly for the happy winner.",
 "His coach ④gave him a shiny gold medal and a hug.",
 "Eli's mother was very ⑤proud of her son that day."])
I[4] = dict(cw='crowded', S=[
 "The new bakery on Elm Street is ①famous for its fresh bread.",
 "At noon the small shop is ②empty, with a long line outside.",
 "Every customer ③buys a warm roll with butter and jam.",
 "The baker ④works very hard from five in the morning.",
 "By evening, almost every ⑤loaf is gone from the shelves."])
I[5] = dict(cw='tidy', S=[
 "Lena's ①mother asked her to clean her room on Saturday.",
 "Soon the floor looked ②messy, with no toys on it.",
 "Her books ③stood in a neat line on the shelf.",
 "Her bed was ④made with a soft blue blanket and pillow.",
 "Her mother gave her a ⑤big smile and a sweet snack."])
I[6] = dict(cw='happy', S=[
 "Mina left her blue umbrella on the ①bus on Monday.",
 "She ②looked for it at home and at school all week long.",
 "On Friday, a kind bus driver ③called the school office about it.",
 "Mina was ④sad to get her blue umbrella back at last.",
 "Later, Mina ⑤thanked the kind driver with a small card."])
I[7] = dict(cw='quiet', S=[
 "Sam studies in the school ①library every day after class.",
 "Everyone there ②reads at the long wooden tables by the window.",
 "A sign on the wall ③asks students to stay silent.",
 "Sam loves the ④loud room for its calm, peaceful feeling.",
 "He ⑤finishes his math homework there before dinner every single day."])
I[8] = dict(cw='slowly', S=[
 "On land, sea turtles are very ①slow animals with heavy shells.",
 "Their thick shells ②protect them from hungry sharks in the sea.",
 "On the beach, a mother turtle ③digs a deep hole for her eggs.",
 "Then she crawls ④quickly across the warm sand back to the water.",
 "Her eggs stay ⑤safe under the sand for two months."])
I[9] = dict(cw='cheap', S=[
 "Jina went to the ①market with her grandmother on Sunday.",
 "Fresh red apples were ②piled high on a long table.",
 "Grandmother ③bought three big bags of them for her family.",
 "Each big paper bag was very ④expensive at only two dollars.",
 "At home, they ⑤made a sweet apple pie for dessert."])
I[10] = dict(cw='heavy', S=[
 "Dan's grandmother lives on the ①top floor of an old building.",
 "The old building has no ②elevator, only a long dark stairway.",
 "Dan ③carried her big bags of rice up the stairs.",
 "After ten floors, the bags felt ④light in his tired arms.",
 "His grandmother ⑤thanked him with a big hug at the door."])
I[11] = dict(cw='cheered', S=[
 "The school soccer team played its final game of the ①season.",
 "Both teams ②ran hard on the wet green field for ninety minutes.",
 "In the last minute, our best player ③kicked the ball into the net.",
 "Our fans in the crowded seats ④booed the winning goal.",
 "After the long game, the players ⑤shook hands on the field."])
I[12] = dict(cw='nervous', S=[
 "Zoe felt very ①calm before her first big piano concert.",
 "Her hands ②shook badly on the way to the big stage.",
 "Her teacher ③smiled kindly at her from the front row.",
 "Zoe ④took a long deep breath at the grand piano.",
 "The music ⑤filled the whole hall with a soft sound."])
I[13] = dict(cw='thick', S=[
 "A ①heavy white fog covered the whole town this morning.",
 "Many drivers ②turned on their lights on the main road.",
 "The traffic ③moved slowly through the white mist near the bridge.",
 "Nobody on the busy street could ④see more than a few meters.",
 "By noon, the fog was still too ⑤thin to see through."])
I[14] = dict(cw='taller', S=[
 "Sora planted ten bean ①seeds in a small pot in April.",
 "She ②watered them with a little cup every morning before school.",
 "After two weeks, small green ③leaves came up from the soil.",
 "The young plants ④grew a little more every single week.",
 "By July, the biggest plant was ⑤shorter than in early May."])
