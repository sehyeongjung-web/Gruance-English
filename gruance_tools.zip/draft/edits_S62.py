# -*- coding: utf-8 -*-
# 333번: 36-37번(글의 순서) 레벨1 — 선생님께 보여 드릴 본보기 셋(1·2·4번째). 아직 올리는 파일이 아님
AUTO_SYNC = False
E = {}
from z3637common import maker
rw = maker(E, '1')

rw(0, "Last Saturday, Tom baked cookies for the first time in his life.",
   {'A': ["After that hour, he cut the cold dough into twelve small round pieces.", "He left them in the hot oven for fifteen minutes."],
    'B': ["Those fifteen minutes were too long for such small cookies.", "Tom's first cookies came out of the oven dark and hard."],
    'C': ["In the morning, he mixed flour, sugar and butter into a soft dough.", "He then put the dough in the fridge for one full hour."]},
   "지난 토요일, 톰은 태어나서 처음으로 쿠키를 구웠다.",
   {'A': ["그 한 시간이 지난 뒤, 그는 차가운 반죽을 작고 동그란 조각 열두 개로 잘랐다.", "그는 그 조각들을 뜨거운 오븐에 십오 분 동안 두었다."],
    'B': ["그 십오 분은 그렇게 작은 쿠키에는 너무 긴 시간이었다.", "톰의 첫 쿠키는 거무스름하고 딱딱한 채로 오븐에서 나왔다."],
    'C': ["아침에 그는 밀가루와 설탕, 버터를 섞어 부드러운 반죽을 만들었다.", "그런 다음 그는 그 반죽을 냉장고에 꼬박 한 시간 동안 넣어 두었다."]},
   ["1) 주어진 글: 지난 토요일에 톰이 처음으로 쿠키를 구웠다고 해요. 이어서 쿠키를 어떤 차례로 만들었는지가 나올 거예요.",
    "2) 첫째 글 (C): «In the morning, he mixed flour, sugar and butter into a soft dough.»(아침에 그는 밀가루와 설탕, 버터를 섞어 부드러운 반죽을 만들었다.) 이 문장에는 앞의 것을 가리키는 말이 없어요. 아침에 재료를 섞는 일이니 쿠키 굽기의 시작으로 알맞아요. (C)는 반죽을 냉장고에 꼬박 한 시간 동안 넣어 두었다는 말로 끝나요.",
    "3) 둘째 글 (A): «After that hour, he cut the cold dough into twelve small round pieces.»(그 한 시간이 지난 뒤, 그는 차가운 반죽을 작고 동그란 조각 열두 개로 잘랐다.) 'that hour'(그 한 시간)는 앞에 나온 한 시간을 가리켜요. (C)의 끝에 있는 'one full hour'(꼬박 한 시간)가 그것이에요. 냉장고에 있었으니 반죽이 'cold'(차가운) 것도 맞아요. (A)는 조각들을 오븐에 십오 분 동안 두었다는 말로 끝나요.",
    "4) 셋째 글 (B)와 확인: «Those fifteen minutes were too long for such small cookies.»(그 십오 분은 그렇게 작은 쿠키에는 너무 긴 시간이었다.) 'Those fifteen minutes'(그 십오 분)는 (A)의 끝에 있는 오븐 속 십오 분이에요. 반죽을 만듦 → 한 시간 뒤에 자름 → 십오 분 동안 구움 → 너무 오래 구워서 딱딱해짐. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(A)-(B)예요."],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)에는 주어진 글과 같은 'first'(첫)와 'cookies'(쿠키)가 있거든요. 하지만 낱말이 같다고 바로 이어지는 것은 아니에요. (B)는 'Those fifteen minutes'(그 십오 분)로 시작해요. 주어진 글에는 십오 분이 나오지 않으니 가리킬 것이 없어요. (A)와 (B)에 모두 'oven'(오븐)이 있다고 차례를 헷갈리지도 마세요. 십오 분은 (A)의 끝에 처음 나오고, (B)가 그것을 받아요.",
   ["(A)의 'that hour'(그 한 시간)가 가리킬 시간이 주어진 글에 없어요. 한 시간은 (C)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
    "(B)의 'Those fifteen minutes'(그 십오 분)가 가리킬 시간이 주어진 글에 없어요. 다 구운 쿠키가 맨 먼저 나오고 반죽을 만드는 일이 맨 끝에 와서 차례도 거꾸로예요.",
    "(B)의 'Those fifteen minutes'(그 십오 분)가 가리킬 시간이 앞에 없어요. 주어진 글과 같은 낱말이 있어서 끌리지만, 십오 분은 (A)의 끝에 처음 나와요.",
    "(C)의 끝에 있는 한 시간을 (A)의 'that hour'(그 한 시간)가 받아요. (A)의 끝에 있는 십오 분을 (B)의 'Those fifteen minutes'(그 십오 분)가 받아요. 반죽 만들기, 자르기, 굽기의 차례예요.",
    "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (B)가 오면 'Those fifteen minutes'(그 십오 분)가 가리킬 것이 없어요. (C)에 나온 시간은 한 시간이에요."])

rw(1, "Lily grew three small tomato plants in pots by her bedroom window.",
   {'A': ["Their leaves slowly turned yellow one after another in early June.", "Lily gave the plants more and more water every day."],
    'B': ["The old man gave the plants very little water for the next ten days.", "Soon new green leaves appeared on all three of her plants."],
    'C': ["However, all that extra water only turned more of the leaves yellow.", "Her grandfather looked at the wet soil and shook his head."]},
   "릴리는 자기 방 창가의 화분에서 작은 토마토 세 포기를 길렀다.",
   {'A': ["유월 초에 그 잎들이 하나둘 천천히 노랗게 변했다.", "릴리는 날마다 그 식물들에 물을 점점 더 많이 주었다."],
    'B': ["그 노인은 그 뒤 열흘 동안 식물들에 물을 아주 조금만 주었다.", "곧 세 포기 모두에서 새 초록 잎이 돋아났다."],
    'C': ["하지만 그렇게 더 준 물은 더 많은 잎을 노랗게 만들 뿐이었다.", "릴리의 할아버지는 젖은 흙을 보고 고개를 가로저었다."]},
   ["1) 주어진 글: 릴리가 창가의 화분에서 토마토 세 포기를 길렀다고 해요. 이어서 그 토마토에 무슨 일이 생겼는지가 나올 거예요.",
    "2) 첫째 글 (A): «Their leaves slowly turned yellow one after another in early June.»(유월 초에 그 잎들이 하나둘 천천히 노랗게 변했다.) 'Their'(그것들의)는 앞에서 말한 여럿을 가리켜요. 주어진 글의 'three small tomato plants'(작은 토마토 세 포기)가 바로 그것이에요. 그래서 (A)가 주어진 글 바로 뒤에 와요. (A)는 릴리가 물을 점점 더 많이 주었다는 말로 끝나요.",
    "3) 둘째 글 (C): «However, all that extra water only turned more of the leaves yellow.»(하지만 그렇게 더 준 물은 더 많은 잎을 노랗게 만들 뿐이었다.) 'all that extra water'(그렇게 더 준 물)는 (A)의 끝에서 릴리가 더 준 물이에요. 'However'(하지만)는 물을 더 주었는데도 잎이 낫지 않았다고 앞의 말을 뒤집어요. (C)는 릴리의 할아버지가 젖은 흙을 보고 고개를 가로저었다는 말로 끝나요.",
    "4) 셋째 글 (B)와 확인: «The old man gave the plants very little water for the next ten days.»(그 노인은 그 뒤 열흘 동안 식물들에 물을 아주 조금만 주었다.) 'The old man'(그 노인)은 누구인지 이미 아는 사람을 말해요. (C)의 끝에 나온 할아버지예요. 잎이 노래짐 → 물을 더 줌 → 더 나빠짐 → 할아버지가 물을 줄임 → 새잎이 돋음. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (A)-(C)-(B)예요."],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)에는 주어진 글과 같은 'three'(세)와 'plants'(식물들)가 있거든요. 하지만 낱말이 같다고 바로 이어지는 것은 아니에요. (B)는 'The old man'(그 노인)으로 시작하는데, 주어진 글에는 릴리밖에 없어요. 노인이 누구인지 알 수 없으니 (B)는 맨 앞에 올 수 없어요. (A) 바로 뒤에 (B)를 놓는 것도 조심해요. 두 글에 똑같이 'gave the plants'(식물들에 주었다)와 'water'(물)가 있어서 이어질 것 같지만, (A)까지 읽어도 노인은 아직 나오지 않았어요. 할아버지는 (C)의 끝에 처음 나와요.",
   ["(A)의 'Their'(그것들의)가 주어진 글의 토마토 세 포기를 받아요. (C)의 'all that extra water'(그렇게 더 준 물)는 (A)의 끝에서 릴리가 더 준 물이에요. (B)의 'The old man'(그 노인)은 (C)의 끝에 나온 할아버지예요. 세 군데가 다 맞물려요.",
    "(B)의 'The old man'(그 노인)이 가리킬 사람이 주어진 글에 없어요. 주어진 글에는 릴리만 나와요. 주어진 글과 같은 낱말이 있어서 끌리지만, 낱말이 같다고 이어지는 것은 아니에요.",
    "(B)의 'The old man'(그 노인)이 가리킬 사람이 앞에 없어요. 또 새잎이 돋았다는 (B) 뒤에 잎이 더 노래졌다는 (C)가 오면 이야기가 거꾸로 가요.",
    "(C)의 'all that extra water'(그렇게 더 준 물)가 가리킬 물이 주어진 글에 없어요. 물을 더 준 일은 (A)의 끝에 나와요. 'However'(하지만)가 뒤집을 말도 앞에 없어요.",
    "(C)의 'all that extra water'(그렇게 더 준 물)가 가리킬 물이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 잎이 노래지기 시작했다는 (A)가 맨 끝에 오는 것도 맞지 않아요."])

rw(3, "On Lunar New Year's Day, many Korean families eat tteokguk together in the morning.",
   {'A': ["Because of this coin shape, the soup carries a wish for more money.", "So one bowl of this soup brings two good wishes for the new year."],
    'B': ["This soup has many thin white slices of rice cake in it.", "Their white color means a clean start to the year."],
    'C': ["The shape of the slices also has a meaning of its own.", "Each of them looks a little like an old Korean coin."]},
   "음력 설날에 많은 한국 가정은 아침에 함께 떡국을 먹는다.",
   {'A': ["이 동전 모양 때문에 그 국에는 돈이 더 많아지기를 바라는 마음이 담겨 있다.", "그래서 이 국 한 그릇은 새해를 위한 좋은 바람 두 가지를 가져다준다."],
    'B': ["이 국에는 얇고 흰 떡 조각이 많이 들어 있다.", "그 흰 빛깔은 한 해를 깨끗하게 시작한다는 뜻이다."],
    'C': ["떡 조각의 모양에도 그 나름의 뜻이 있다.", "떡 조각 하나하나는 옛날 한국 동전과 조금 닮았다."]},
   ["1) 주어진 글: 음력 설날에 많은 한국 가정이 떡국을 먹는다고 해요. 이어서 떡국이 어떤 음식인지, 어떤 뜻이 담겼는지가 나올 거예요.",
    "2) 첫째 글 (B): «This soup has many thin white slices of rice cake in it.»(이 국에는 얇고 흰 떡 조각이 많이 들어 있다.) 'This soup'(이 국)은 주어진 글의 'tteokguk'(떡국)을 가리켜요. 떡 조각을 처음 알려 주는 글이기도 해요. (B)는 흰 빛깔이 깨끗한 시작을 뜻한다는 말로 끝나요.",
    "3) 둘째 글 (C): «The shape of the slices also has a meaning of its own.»(떡 조각의 모양에도 그 나름의 뜻이 있다.) 'also'(~도)는 앞에 다른 뜻이 하나 나와 있어야 쓸 수 있어요. (B)의 끝에 나온 흰 빛깔의 뜻이 그것이에요. 'the slices'(그 조각들)도 (B)의 떡 조각을 받아요. (C)는 떡 조각이 옛날 동전과 닮았다는 말로 끝나요.",
    "4) 셋째 글 (A)와 확인: «Because of this coin shape, the soup carries a wish for more money.»(이 동전 모양 때문에 그 국에는 돈이 더 많아지기를 바라는 마음이 담겨 있다.) 'this coin shape'(이 동전 모양)는 (C)의 끝에 나온 동전을 닮은 모양이에요. 마지막 문장의 'two good wishes'(좋은 바람 두 가지)는 깨끗한 시작과 돈, 두 가지를 다 들은 뒤에야 할 수 있는 말이에요. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(C)-(A)예요."],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. (C)와 (A)가 동전 이야기로 딱 붙어 있어서 그 둘부터 묶고 싶어지거든요. 하지만 (C)에는 'also'(~도)가 있어요. 뜻이 하나 먼저 나와 있어야 해요. 'the slices'(그 조각들)가 가리킬 떡 조각도 주어진 글에는 없어요. 둘 다 (B)에 있으니 (B)가 (C) 앞에 와야 해요.",
   ["(A)의 'this coin shape'(이 동전 모양)가 가리킬 것이 주어진 글에 없어요. 동전은 (C)의 끝에 처음 나와요. 뜻을 하나도 듣기 전에 'two good wishes'(좋은 바람 두 가지)라고 맺는 것도 맞지 않아요.",
    "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (A)가 오면 'this coin shape'(이 동전 모양)가 가리킬 것이 없어요. (B)에는 흰 빛깔 이야기만 있어요.",
    "(B)의 'This soup'(이 국)이 주어진 글의 떡국을 받아요. (C)의 'also'(~도)는 (B)의 끝에 나온 흰 빛깔의 뜻에 하나를 더해요. (A)의 'this coin shape'(이 동전 모양)는 (C)의 끝에 나온 동전 모양이에요.",
    "(C)의 'also'(~도)는 앞에 다른 뜻이 있어야 쓸 수 있는데, 주어진 글에는 뜻 이야기가 없어요. 떡 조각을 처음 알려 주는 (B)가 맨 끝에 오는 것도 맞지 않아요.",
    "(C)의 'also'(~도)가 받을 뜻이 앞에 없어요. 또 (A)의 'this coin shape'(이 동전 모양)가 (C)의 동전에서 떨어지고, 그 사이에 (B)가 끼어들어요."])
