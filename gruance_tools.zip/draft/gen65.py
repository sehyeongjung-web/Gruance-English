# -*- coding: utf-8 -*-
# 원고(d65x.I)와 한글(k65x.K)을 합쳐 pending/edits_X65x.py를 만든다.  python3 draft/gen65.py a   (뒷 절반은 b)
import sys, pprint, importlib
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
tag = sys.argv[1]
d = importlib.import_module('d65' + tag); k = importlib.import_module('k65' + tag)
ns = sorted(d.I)
assert sorted(k.K) == ns, (sorted(k.K), ns)
from z29rw import maker
head = '앞' if tag == 'a' else '뒤'
out = ['# -*- coding: utf-8 -*-',
       '# %s번: 29번(어법) 레벨1 %s 절반 — 다섯 문장(문장당 10~15낱말 · 단문) · 틀린 곳 하나. 정답 번호는 바탕 그대로, 지문·해석·풀이·해설·올바른 꼴(correctWord)을 통째로 다시 씀' % ('340' if tag == 'a' else '341', head),
       'AUTO_SYNC = False', 'E = {}', 'from z29rw import maker', 'rw = maker(E)', '']
for n in ns:
    I = d.I[n]; K = k.K[n]
    out.append('# %d번째' % (n + 1))
    out.append('rw(%d, %r,\n   %s,\n   %r,\n   %s,\n   %s,\n   %r)\n' % (n, I['cat'], pprint.pformat(I['S'], width=200), I['cw'], pprint.pformat(K['ko'], width=200), pprint.pformat(K['notes'], width=200), K['words']))
open('/home/claude/work/pending/edits_X65%s.py' % tag, 'w', encoding='utf-8').write('\n'.join(out))
print('만듦: pending/edits_X65%s.py (%d문항)' % (tag, len(ns)))
