# -*- coding: utf-8 -*-
# 41번 읽기: python3 show41.py 8 5 10
import sys; sys.path.insert(0, '.')
from lib import *
lv, a, b = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
s, tb, te = load()
for n in range(a, b):
    it = tb['41'][lv][n]
    print('=====', n + 1, '정답', it['answer']); print(it['text'].replace('\n\n', '\n'))
    for k, c in enumerate(it['choices']): print('   %s%d %s' % ('*' if k == it['answer'] else ' ', k, c))
