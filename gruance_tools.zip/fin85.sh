#!/bin/bash
# 368번: 43번 레벨1 — GitHub 최신본을 받아 그 위에 X84만 얹어 빌드
cd /home/claude/Gruance-English && git pull -q --rebase && echo "바탕: $(git log --oneline -1)" || exit 1
cd /home/claude/work
python3 draft/gen85.py a && python3 draft/gen85.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X84a.py pending/edits_X84b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X84a,edits_X84b out/index.html | tail -3
