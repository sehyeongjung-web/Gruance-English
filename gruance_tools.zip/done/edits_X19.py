# -*- coding: utf-8 -*-
# 272번: 40번(요약문 완성) 레벨5 — 30문항을 다 읽고 답이 둘로 읽히거나 말이 서지 않는 문항을 바로잡음(일곱 문항 + 해석만 두 문항)
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새로 씀(레벨6~9와 같은 꼴). 정답 번호 변동 없음. z40common.py가 같은 폴더에 있어야 함
#   6번째  — 오답 'price - product'도 답으로 섬(옆 모델의 값에 견주어 보인 것). 오답 'decoration - the shop'은 넣으면 'the the shop'이 됨, 'weather - delivery time'은 엉뚱함
#            → 'discount - product' / 'window display - shop' / 'time of year - product'
#   10번째 — 오답 'rejected - produced'도 답으로 섬(지문: 애매한 물건을 불합격시키지 않고 통과시킴 = 불합격되는 것이 달라짐) → 'designed - produced'
#   16번째 — 오답 'line - school'도 답으로 읽힘(학교 전체에 걸쳐) → 'line - staff'
#   17번째 — 정답의 (B) postpone: 'made the whole system easier to postpone'은 말이 서지 않음(지문은 'something they could ignore until later') → 정답을 'first - ignore'로. 오답 'last - remember later'는 넣으면 꼴이 깨져 'last - remember'로
#   24번째 — **정답의 근거가 지문에 없고 지문은 오히려 반대를 받쳐 줌**(값을 무료로 하자 모든 가족이 사진을 가짐 = 값이 장벽이었다는 말. 「달라고 해야 하는 것」은 지문에 없음)
#            → 지문을 다시 씀(달라고 한 가족에게만 팔다가, 같은 값으로 모든 아이 편에 보냄). 엉뚱한 오답 둘('the weather - the decoration'·'the music - the decoration')도 바꿈
#   27번째 — 오답 'how much it cost - dumping'도 답으로 섬(요금을 매기면 드는 돈이 달라지는 것은 당연히 참) → 'who collected it - dumping'
#   28번째 — 오답 'revisit - shorten'도 답으로 섬(두 배속으로 보기 = 줄이기). 요약문도 'used to revisit … used to replace'로 목적어가 없어 어색함
#            → 요약문 '… used to (A) ______ a lecture and harmed when used to (B) ______ it.' / 오답 셋을 바꿈
# 해석만: 4번째(batch를 「배치」로 옮긴 것 → 「판」) · 7번째(해석에 [요약문] 줄이 빠져 있었음)
AUTO_SYNC = False
E = {}
from z40common import maker
mk = maker(E, lv='5')
def fix(n, text, ko):
    d = {}
    if ko: d['ko'] = ko
    if text: d.update({'passage_ok': True, 'text': text})
    E[('40', '5', n)].update(d)

# ---------- 해석만 고친 두 문항 (지문·풀이·해설은 그대로) ----------
E[('40', '5', 3)] = {'ko': [('두 번째 배치를 굽기 시작했다', '두 번째 판을 굽기 시작했다'), ('한 배치로 돌아가', '한 판으로 돌아가')]}
E[('40', '5', 6)] = {'ko': ('기술하는 법을 몰랐다는 것을 알게 되었다.', '기술하는 법을 몰랐다는 것을 알게 되었다.\n\n[요약문] 신고는 주민이 그 고장을 그저 (B)______ 것이 아니라 (A)______ 방법을 얻자 늘었다.')}

# ---------- 6번째: 판매를 바꾼 것은 물건이 아니라 견줌 ----------
mk(5, 2, [
 "1) 요약문: 'A rather than B' 틀입니다. «What altered the sales was the (A) ______ the bicycle was seen against rather than anything about the (B) ______ itself.»(그 판매를 바꾼 것은 그 (B) 자체에 관한 무엇이 아니라 그 자전거가 견주어진 (A)였다.) (A)는 판매를 바꾼 것, (B)는 바꾸지 않은 것입니다.",
 "2) (A) 찾기: 둘째 문장이 짝꿍 문장입니다. «One displayed it beside a cheaper model and the other beside a more expensive one.»(하나는 그것을 더 싼 모델 옆에, 다른 하나는 더 비싼 모델 옆에 진열했다.) 두 가게에서 다른 것은 옆에 놓인 모델뿐입니다. 손님은 그 자전거를 옆의 것과 견주어 봅니다. 비싼 것 옆에서는 싸 보여서 세 배가 팔렸습니다.",
 "3) (B) 찾기: 셋째 문장의 뒤쪽입니다. «neither shop had changed the bicycle or the price»(어느 가게도 그 자전거나 그 값을 바꾸지 않았다). 팔리는 물건은 그대로였습니다. 첫 문장도 같은 자전거를 같은 값에 팔았다고 했습니다.",
 "4) 묶기: (A) 'beside a cheaper model'(더 싼 모델 옆에)과 'beside a more expensive one'(더 비싼 것 옆에) = 무엇과 견주어 보이는가 = 'comparison'(견줌). 지문에 없는 낱말로 바꾼 것입니다. (B) 'the bicycle'(그 자전거) = 'product'(물건). 이것도 다른 말로 바꾼 것입니다."],
 "「품질 - 물건」이 가장 끌립니다. (B)가 맞고, 더 많이 팔렸다면 더 좋아 보였을 것이라는 생각이 들기 때문입니다. 하지만 두 가게의 자전거는 똑같습니다. 품질은 달라진 것이 없습니다. 달라진 것은 옆에 무엇이 놓였는가입니다. 「할인 - 물건」도 (B)만 맞습니다. 지문은 두 가게가 같은 값에 팔았고 값을 바꾸지 않았다고 했습니다.",
 [("진열창 꾸밈 - 가게", "두 낱말 모두 글과 맞지 않습니다. 진열창을 어떻게 꾸몄는지는 지문에 없습니다. 첫 문장이 두 가게는 똑같다고 했고, 다른 것은 옆에 놓은 모델뿐입니다."),
  ("할인 - 물건", "(B)는 맞고 (A)가 틀렸습니다. 물건이 그대로였던 것은 맞습니다. 하지만 지문은 두 가게가 같은 값에 팔았고 값을 바꾸지 않았다고 했습니다. 값을 깎아 준 가게는 없습니다."),
  ("견줌 - 물건", "(A)는 둘째 문장 «One displayed it beside a cheaper model and the other beside a more expensive one.»이, (B)는 «neither shop had changed the bicycle or the price»가 근거입니다. 달라진 것은 그 자전거가 무엇 옆에 놓였는가뿐이고, 자전거 자체는 그대로였습니다."),
  ("한 해의 시기 - 물건", "(B)는 맞고 (A)가 틀렸습니다. 언제 팔았는지는 지문에 나오지 않습니다. 두 가게의 차이는 옆에 놓은 모델 하나뿐입니다."),
  ("품질 - 물건", "(B)는 맞고 (A)가 틀렸습니다. 두 가게가 판 것은 같은 자전거이므로 품질은 같습니다. 판매를 바꾼 것은 품질이 아니라 옆에 놓인 모델과의 견줌입니다.")],
 ch={0: 'window display - shop', 1: 'discount - product', 3: 'time of year - product'})

# ---------- 10번째: 보상은 만든 것이 아니라 적은 것을 바꿨다 ----------
mk(9, 0, [
 "1) 요약문: 'A rather than B' 틀입니다. «The reward changed what was (A) ______ rather than what was (B) ______.»(그 보상은 (B)된 것이 아니라 (A)된 것을 바꿨다.) (A)는 보상 때문에 달라진 것, (B)는 달라지지 않은 것입니다.",
 "2) (A) 찾기: 둘째 문장이 짝꿍 문장입니다. «Faults fell on paper and rose in the complaints received from customers.»(서류상 불량은 줄었고 손님에게서 받는 항의는 늘었다.) 'on paper'(서류상)가 단서입니다. 줄어든 것은 서류에 적힌 불량의 수입니다. 셋째 문장이 까닭을 댑니다. 애매한 물건을 불합격시키지 않고 통과시켰습니다. 불합격은 그 조에 불리하게 적히기 때문입니다.",
 "3) (B) 찾기: 같은 둘째 문장의 뒤쪽입니다. 손님의 항의는 오히려 늘었습니다. 실제로 만들어져 나간 물건은 나아지지 않았다는 뜻입니다. 첫 문장의 «produced the fewest faulty items»(불량품을 가장 적게 만든)에서 보듯 보상이 바라던 것은 만드는 물건이 나아지는 것이었지만, 그것은 달라지지 않았습니다.",
 "4) 묶기: (A) 'on paper'(서류상) = 'recorded'(기록된). 지문에 없는 낱말로 바꾼 것입니다. (B) 첫 문장의 'produced'(만든) 그대로입니다. 보상은 만드는 물건이 아니라 적는 숫자를 바꾸었습니다."],
 "「만들어진 - 기록된」이 가장 위험합니다. 두 낱말이 답과 같고 자리만 바뀌었습니다. 'A rather than B'에서는 앞쪽이 달라진 것입니다. 달라진 것은 서류의 숫자이고, 만든 물건은 그대로입니다. 「기록된 - 보상받은」은 (A)만 맞습니다. 무엇에 보상을 주는지는 처음부터 끝까지 그대로였고, 글이 맞세우는 것은 서류와 실제 물건입니다.",
 [("기록된 - 만들어진", "(A)는 둘째 문장 «Faults fell on paper and rose in the complaints received from customers.»이 근거입니다. 줄어든 것은 서류상의 불량입니다. (B)는 같은 문장에서 손님의 항의가 늘었다는 데서 나옵니다. 실제로 만든 물건은 나아지지 않았습니다."),
  ("만들어진 - 기록된", "방향이 거꾸로입니다. 낱말은 맞지만 자리가 바뀌었습니다. 보상이 바꾼 것은 서류에 적힌 숫자이고, 만든 물건은 그대로여서 항의가 늘었습니다."),
  ("설계된 - 만들어진", "(B)는 맞고 (A)가 틀렸습니다. 만든 물건이 달라지지 않은 것은 맞습니다. 하지만 물건의 설계는 지문에 나오지 않습니다. 달라진 것은 서류에 적히는 불량의 수입니다."),
  ("기록된 - 보상받은", "(A)는 맞고 (B)가 틀렸습니다. 서류의 숫자가 달라진 것은 맞습니다. 하지만 글이 그것과 맞세우는 것은 보상이 아니라 실제로 만든 물건입니다. 손님의 항의가 그것을 보여 줍니다."),
  ("점검된 - 불합격된", "두 낱말 모두 글과 맞지 않습니다. 무엇을 점검하는지가 달라졌다는 말은 없습니다. 불합격은 오히려 달라진 쪽입니다. 애매한 물건을 불합격시키지 않고 통과시키게 되었습니다.")],
 ch={2: 'designed - produced'})

# ---------- 16번째: 경계선 가까이에만 몰린 노력 ----------
mk(15, 0, [
 "1) 요약문: 'A rather than B' 틀입니다. «A boundary measure concentrated effort on students near the (A) ______ rather than across the (B) ______.»(경계 척도는 (B) 전체에 걸치기보다 그 (A) 가까이의 학생에게 노력을 집중시켰다.) (A)는 노력이 몰린 곳, (B)는 노력이 고루 가야 했던 범위입니다.",
 "2) (A) 찾기: 둘째 문장이 짝꿍 문장입니다. «Students well above and well below the boundary received measurably less attention than those just beneath it.»(그 경계보다 한참 위와 한참 아래의 학생은 그 바로 아래의 학생보다 측정 가능하게 적은 관심을 받았다.) 관심은 경계 바로 아래의 학생에게 몰렸습니다. 조금만 밀어 주면 경계를 넘을 학생들입니다.",
 "3) (B) 찾기: 셋째 문장입니다. «The school changed the measure to progress across the whole class»(그 학교가 그 척도를 반 전체의 향상으로 바꾸었다). 그러자 관심이 고르게 되었습니다. 노력이 고루 가야 할 범위는 반 전체입니다.",
 "4) 묶기: (A) 'the boundary'(그 경계) = 'line'(선). 등급을 가르는 선입니다. 지문에 없는 낱말로 바꾼 것입니다. (B) 'across the whole class'(반 전체에 걸쳐) → 'class'(반). 지문 낱말 그대로입니다."],
 "「평균 - 반」이 가장 끌립니다. (B)가 맞고, 성적 이야기에는 평균이 흔히 나오기 때문입니다. 하지만 지문에는 평균이 나오지 않습니다. 관심이 몰린 곳은 평균 근처가 아니라 등급 경계 바로 아래입니다. 「선 - 과목」은 (A)만 맞습니다. 지문은 과목을 말하지 않습니다. 고루 가야 할 범위는 반 전체입니다.",
 [("선 - 반", "(A)는 둘째 문장 «Students well above and well below the boundary received measurably less attention than those just beneath it.»이, (B)는 셋째 문장의 «progress across the whole class»가 근거입니다. 노력이 경계선 바로 아래의 학생에게 몰렸고, 척도를 반 전체로 바꾸자 고르게 되었습니다."),
  ("선 - 과목", "(A)는 맞고 (B)가 틀렸습니다. 노력이 경계선 가까이에 몰린 것은 맞습니다. 하지만 과목은 지문에 나오지 않습니다. 지문이 말하는 범위는 반 전체입니다."),
  ("평균 - 반", "(B)는 맞고 (A)가 틀렸습니다. 반 전체가 맞는 범위입니다. 하지만 평균은 지문에 나오지 않습니다. 관심이 몰린 곳은 등급 경계 바로 아래입니다."),
  ("꼭대기 - 학년", "두 낱말 모두 글과 맞지 않습니다. 경계보다 한참 위의 학생은 오히려 관심을 덜 받았습니다. 학년도 지문에 나오지 않습니다."),
  ("선 - 교직원", "(A)는 맞고 (B)가 틀렸습니다. 노력이 고루 가야 할 곳은 학생들입니다. 교직원 전체에 걸친다는 말은 지문과 이어지지 않습니다. 지문이 말하는 범위는 반 전체입니다.")],
 ch={4: 'line - staff'})

# ---------- 17번째: 알림이 하나 더 생기자 첫 알림이 가벼워졌다 ----------
mk(16, 2, [
 "1) 요약문: «The extra reminder reduced the weight of the (A) ______ one and made the whole system easier to (B) ______.»(그 추가 알림은 (A) 알림의 무게를 줄였고 그 체계 전체를 (B)하기 쉽게 만들었다.) 'The extra reminder'(그 추가 알림)는 나중에 보탠 두 번째 알림입니다. (A)는 그 때문에 가벼워진 알림, (B)는 사람들이 알림을 어떻게 다루게 되었는지입니다.",
 "2) (A) 찾기: 셋째 문장이 짝꿍 문장입니다. «the second message made the first one feel like something they could ignore until later»(그 두 번째 메시지가 첫 번째를 나중까지 무시해도 되는 것처럼 느끼게 만들었다). 가벼워진 것은 첫 번째 알림입니다. 두 번째가 또 올 테니 첫 번째는 넘겨도 된다고 여기게 되었습니다.",
 "3) (B) 찾기: 같은 문장의 'ignore'(무시하다)가 그대로 단서입니다. 둘째 문장도 두 번째 알림을 보탠 뒤 «missed appointments rose again»(예약 불참이 다시 늘었다)이라고 합니다. 알림을 무시하기 쉬워져서 예약을 놓치는 사람이 늘었습니다.",
 "4) 묶기: (A) 'the first one'(첫 번째 것) → 'first'. (B) 'ignore' 그대로입니다. 둘 다 지문 낱말입니다."],
 "「두 번째 - 무시하다」가 가장 위험합니다. (B)가 맞고, 지문에 'the second message'가 그대로 나오기 때문입니다. 하지만 요약문의 주어인 추가 알림이 바로 그 두 번째 알림입니다. 두 번째 알림이 자기 자신의 무게를 줄였다고 하면 말이 되지 않습니다. 가벼워진 것은 첫 번째입니다. 「두 번째 - 미루다」도 같은 까닭으로 (A)가 틀립니다.",
 [("첫 번째 - 읽다", "(A)는 맞고 (B)가 틀렸습니다. 첫 번째 알림이 가벼워진 것은 맞습니다. 하지만 알림이 읽기 쉬워졌다는 말은 없습니다. 환자들은 첫 번째를 무시해도 되는 것처럼 느꼈다고 했습니다."),
  ("두 번째 - 미루다", "(A)가 틀렸습니다. 추가 알림이 바로 두 번째 알림입니다. 그것 때문에 가벼워진 것은 첫 번째 알림입니다. 환자들이 그렇게 말했습니다."),
  ("첫 번째 - 무시하다", "셋째 문장의 «the second message made the first one feel like something they could ignore until later»가 (A)와 (B) 모두의 근거입니다. 두 번째 알림이 생기자 첫 번째는 넘겨도 되는 것이 되었고, 그래서 예약 불참이 다시 늘었습니다."),
  ("두 번째 - 무시하다", "(B)는 맞고 (A)가 틀렸습니다. 알림을 무시하기 쉬워진 것은 맞습니다. 하지만 무게가 줄어든 것은 두 번째가 아니라 첫 번째 알림입니다."),
  ("마지막 - 기억하다", "두 낱말 모두 글과 맞지 않습니다. 마지막 알림은 추가 알림 자신입니다. 예약 불참이 다시 늘었으니 기억하기 쉬워진 것도 아닙니다.")],
 ch={2: 'first - ignore', 4: 'last - remember'}, ans_ok=True)

# ---------- 24번째: 장벽은 값이 아니라 달라고 해야 하는 일 ----------
mk(23, 4, [
 "1) 요약문: 'A rather than B' 틀입니다. «The barrier turned out to be (A) ______ rather than (B) ______»((B)가 아니라 (A)가 그 장벽인 것으로 드러났다). (A)는 사진을 사지 못하게 막던 진짜 장벽, (B)는 장벽인 줄 알았지만 아니었던 것입니다.",
 "2) (A) 찾기: 첫 문장이 짝꿍 문장입니다. «sold prints to families who asked for one»(달라고 한 가족에게 인화본을 팔았다). 처음에는 달라고 해야만 살 수 있었습니다. 셋째 문장에서 학교는 이것을 바꿉니다. «a print was sent home with every child»(인화본을 모든 아이 편에 집으로 보냈다). 달라고 하지 않아도 사진이 집에 옵니다. 그러자 거의 모든 가족이 그것을 가졌습니다. 막고 있던 것은 달라고 해야 하는 일이었습니다.",
 "3) (B) 찾기: 둘째 문장입니다. «the school assumed the price was the reason»(그 학교는 그 값이 이유라고 여겼다). 'assumed'(여겼다)는 알아보기 전의 짐작입니다. 그런데 새 방식에서도 값은 «at the same price»(같은 값으로) 그대로였습니다. 값이 그대로인데 거의 모든 가족이 샀으니, 값은 장벽이 아니었습니다.",
 "4) 묶기: (A) 'families who asked for one'(달라고 한 가족) → 'having to ask'(달라고 해야 하는 것). (B) 'the price' 그대로입니다. 요약문의 'turned out'(드러났다)은 처음 짐작이 틀렸다는 말입니다."],
 "「그 값 - 달라고 해야 하는 것」이 가장 위험합니다. 두 낱말이 답과 같고 자리만 바뀌었습니다. 학교가 처음에 값이 이유라고 여겼다는 말도 눈에 들어옵니다. 하지만 'A rather than B'에서는 앞쪽이 진짜 장벽입니다. 값은 새 방식에서도 그대로였으니 장벽이 아니었습니다. 「달라고 해야 하는 것 - 그 품질」은 (A)만 맞습니다. 학교가 이유라고 짐작한 것은 사진의 품질이 아니라 값입니다.",
 [("그 값 - 달라고 해야 하는 것", "방향이 거꾸로입니다. 낱말은 맞지만 자리가 바뀌었습니다. 값은 새 방식에서도 그대로였는데 거의 모든 가족이 샀습니다. 진짜 장벽은 달라고 해야 하는 일이었습니다."),
  ("그 품질 - 그 값", "(B)는 맞고 (A)가 틀렸습니다. 값이 장벽이 아니었던 것은 맞습니다. 하지만 사진의 품질은 지문에 나오지 않습니다. 달라진 것은 달라고 하지 않아도 사진이 집에 온다는 점입니다."),
  ("달라고 해야 하는 것 - 그 품질", "(A)는 맞고 (B)가 틀렸습니다. 달라고 해야 하는 일이 장벽이었던 것은 맞습니다. 하지만 학교가 이유라고 짐작했던 것은 품질이 아니라 값입니다."),
  ("한 해의 시기 - 그 값", "(B)는 맞고 (A)가 틀렸습니다. 값이 장벽이 아니었던 것은 맞습니다. 하지만 사진을 파는 시기가 탈이었다는 말은 없습니다. 탈은 가족이 먼저 달라고 해야 했다는 점입니다."),
  ("달라고 해야 하는 것 - 그 값", "(A)는 첫 문장의 «sold prints to families who asked for one»이, (B)는 둘째 문장의 «the school assumed the price was the reason»이 근거입니다. 같은 값으로 모든 아이 편에 사진을 보내자 거의 모든 가족이 샀습니다. 값이 아니라 달라고 해야 하는 일이 막고 있었습니다.")],
 ch={2: 'having to ask - the quality', 3: 'the time of year - the price'})
fix(23, ('A school photographed every class and sold prints to families. About a fifth never bought one, and the school assumed the price was the reason. A free print for every family, with extra copies sold, produced the same income and no family without a photograph.',
         'A school photographed every class and sold prints to families who asked for one. About a fifth never did, and the school assumed the price was the reason. The next year a print was sent home with every child at the same price, to be paid for or returned. Almost every family kept it, and the income rose.'),
        ('한 학교가 모든 반을 사진 찍고 가족에게 인화본을 팔았다. 약 5분의 1이 한 번도 사지 않았고, 그 학교는 그 값이 이유라고 여겼다. 모든 가족에게 무료 인화본 하나를 주고 추가본을 파는 방식이 같은 수입을 내면서 사진 없는 가족을 하나도 남기지 않았다.',
         '한 학교가 모든 반을 사진 찍고 달라고 한 가족에게 인화본을 팔았다. 약 5분의 1은 한 번도 그러지 않았고, 그 학교는 그 값이 이유라고 여겼다. 이듬해에는 인화본을 같은 값으로 모든 아이 편에 집으로 보내, 값을 치르거나 돌려보내게 했다. 거의 모든 가족이 그것을 가졌고 수입이 늘었다.'))

# ---------- 27번째: 요금은 쓰는 횟수를 바꾸었고 무단 투기는 늘지 않았다 ----------
mk(26, 1, [
 "1) 요약문: «A charge changed (A) ______ without producing the (B) ______ that had been predicted.»(요금은 예상되었던 (B)를 만들어내지 않으면서 (A)를 바꿨다.) (A)는 요금 때문에 달라진 것, (B)는 걱정했지만 일어나지 않은 일입니다.",
 "2) (A) 찾기: 첫 문장과 둘째 문장이 짝꿍 문장입니다. 무료일 때는 «the same households using it every month»(같은 가구가 달마다 그것을 쓰는) 것이 탈이었습니다. 작은 요금을 매기자 «eliminated the repeat users»(그 반복 이용자를 없앴다)가 되었습니다. 달라진 것은 사람들이 그것을 쓰는 횟수입니다.",
 "3) (B) 찾기: 셋째 문장입니다. «Fly-tipping, which the council had expected to rise, did not change.»(지자체가 늘 것으로 예상했던 무단 투기는 달라지지 않았다.) 'had expected'(예상했던)가 요약문의 'had been predicted'(예상되었던)와 짝입니다. 걱정한 것은 아무 데나 버리는 일이었고, 그것은 늘지 않았습니다.",
 "4) 묶기: (A) 'every month'(달마다)와 'repeat users'(반복 이용자) = 'how often it was used'(얼마나 자주 쓰였는가). 지문에 없는 말로 바꾼 것입니다. (B) 'Fly-tipping'(무단 투기) = 'dumping'(내다 버리기). 이것도 다른 낱말로 바꾼 것입니다."],
 "「얼마나 자주 쓰였는가 - 절약」이 가장 끌립니다. (A)가 맞고, 요금을 매겼으니 돈이 아껴졌을 것 같기 때문입니다. 하지만 (B)는 예상했는데 일어나지 않은 일입니다. 지자체가 예상한 것은 절약이 아니라 무단 투기가 느는 것이었습니다. 「그 총량 - 비용」은 (A)가 그럴듯합니다. 총량이 3분의 1 줄어든 것은 맞습니다. 하지만 예상되었던 비용이라는 말은 지문에 없습니다.",
 [("누가 그것을 수거했는가 - 내다 버리기", "(B)는 맞고 (A)가 틀렸습니다. 무단 투기가 늘지 않은 것은 맞습니다. 하지만 누가 수거하는지가 달라졌다는 말은 없습니다. 달라진 것은 같은 가구가 달마다 쓰던 일입니다."),
  ("얼마나 자주 쓰였는가 - 내다 버리기", "(A)는 둘째 문장의 «eliminated the repeat users»가, (B)는 셋째 문장 «Fly-tipping, which the council had expected to rise, did not change.»이 근거입니다. 달마다 쓰던 가구가 사라졌고, 걱정했던 무단 투기는 늘지 않았습니다."),
  ("얼마나 자주 쓰였는가 - 절약", "(A)는 맞고 (B)가 틀렸습니다. 쓰는 횟수가 달라진 것은 맞습니다. 하지만 지자체가 예상한 것은 절약이 아니라 무단 투기가 느는 것이었습니다."),
  ("누가 그것을 쓸 수 있는가 - 새 항의", "두 낱말 모두 글과 맞지 않습니다. 쓸 수 있는 사람이 달라진 것은 아닙니다. 누구나 쓸 수 있되 요금이 붙었을 뿐입니다. 항의는 지문에 나오지 않습니다."),
  ("그 총량 - 비용", "(A)는 맞고 (B)가 틀렸습니다. 총량이 3분의 1 줄어든 것은 맞습니다. 하지만 지자체가 예상했던 것은 비용이 아니라 무단 투기입니다.")],
 ch={0: 'who collected it - dumping'})

# ---------- 28번째: 녹화는 다시 볼 때 돕고, 출석을 대신할 때 해친다 ----------
mk(27, 4, [
 "1) 요약문: «The recordings helped when used to (A) ______ a lecture and harmed when used to (B) ______ it.»(그 녹화는 강의를 (A)하는 데 쓰였을 때 도움이 되었고 그것을 (B)하는 데 쓰였을 때 해가 되었다.) (A)는 도움이 된 쓰임, (B)는 해가 된 쓰임입니다. 지문에서 성적이 오른 쪽과 떨어진 쪽을 찾으면 됩니다.",
 "2) (A) 찾기: 둘째 문장의 뒤쪽이 짝꿍 문장입니다. «those who used recordings to revisit a difficult passage did better than either»(어려운 대목을 다시 보는 데 녹화를 쓴 학생이 그 둘보다 잘했다). 성적이 가장 좋았던 것은 어려운 곳을 다시 본 학생입니다.",
 "3) (B) 찾기: 둘째 문장의 앞쪽입니다. «students who watched recordings at double speed did worse than those who attended»(녹화를 두 배속으로 본 학생이 출석한 학생보다 못했다). 이 학생들은 출석한 학생과 맞세워져 있습니다. 강의에 가지 않고 녹화로 때운 학생들입니다. 첫 문장도 녹화가 생기자 출석이 떨어졌다고 했습니다.",
 "4) 묶기: (A) 'revisit'(다시 보다) 그대로입니다. 지문 낱말입니다. (B) 출석하는 대신 녹화를 본다 = 'replace'(대신하다). 지문에 없는 낱말로 바꾼 것입니다."],
 "「대신하다 - 다시 보다」가 가장 위험합니다. 두 낱말이 답과 같고 자리만 바뀌었습니다. 요약문에서 앞쪽은 도움이 된 쓰임이고 뒤쪽은 해가 된 쓰임입니다. 다시 본 학생이 가장 잘했으니 다시 보기가 앞에 와야 합니다. 「다시 보다 - 출석하다」는 (A)만 맞습니다. 출석한 학생은 두 배속으로 본 학생보다 잘했습니다. 출석은 해가 된 쪽이 아닙니다.",
 [("대신하다 - 다시 보다", "방향이 거꾸로입니다. 낱말은 맞지만 자리가 바뀌었습니다. 어려운 대목을 다시 본 학생이 가장 잘했고, 출석 대신 녹화를 본 학생이 못했습니다."),
  ("다시 보다 - 출석하다", "(A)는 맞고 (B)가 틀렸습니다. 다시 보는 쓰임이 도움이 된 것은 맞습니다. 하지만 출석한 학생은 두 배속으로 본 학생보다 잘했습니다. 출석은 해가 된 쪽이 아닙니다."),
  ("간추리다 - 대신하다", "(B)는 맞고 (A)가 틀렸습니다. 출석을 대신하는 쓰임이 해가 된 것은 맞습니다. 하지만 강의를 간추린다는 말은 지문에 없습니다. 도움이 된 쓰임은 어려운 대목을 다시 보는 것입니다."),
  ("날짜를 옮기다 - 출석하다", "두 낱말 모두 글과 맞지 않습니다. 강의 날짜를 옮긴다는 말은 지문에 없습니다. 출석한 학생은 오히려 두 배속으로 본 학생보다 잘했습니다."),
  ("다시 보다 - 대신하다", "(A)는 «those who used recordings to revisit a difficult passage did better than either»가, (B)는 «students who watched recordings at double speed did worse than those who attended»가 근거입니다. 어려운 곳을 다시 본 학생이 가장 잘했고, 출석 대신 녹화를 본 학생이 가장 못했습니다.")],
 ch={1: 'revisit - attend', 2: 'summarize - replace', 3: 'reschedule - attend'})
fix(27, ('The recordings helped when used to (A) ______ and harmed when used to (B) ______.', 'The recordings helped when used to (A) ______ a lecture and harmed when used to (B) ______ it.'),
        ('[요약문] 그 녹화는 (A)______ 에 쓰였을 때 도움이 되었고 (B)______ 에 쓰였을 때 해가 되었다.', '[요약문] 그 녹화는 강의를 (A)______ 데 쓰였을 때 도움이 되었고 그것을 (B)______ 데 쓰였을 때 해가 되었다.'))
