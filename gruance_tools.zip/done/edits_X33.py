# -*- coding: utf-8 -*-
# 287번: 41번(장문 제목) 레벨4 — 30문항을 다 읽고 두 문항을 바로잡음(+ 두 문항은 지문의 한 구절·해석만)
# 레벨4의 41번은 42번과 쌍둥이 지문(41번 = 맞는 낱말로 쓴 글). 본문 해석은 서른 문항 모두 통째로 있고 영어와 맞음
# 고친 두 문항의 풀이(walk)·제목별 해설(cn)은 새로 씀(레벨5~9와 같은 꼴). 정답 번호 변동 없음. z41common.py가 같은 폴더에 있어야 함
#   13번째 — 정답 제목 'Cutting Away From the Hand'가 지문과 부딪힘(지문: 칼을 엄지 쪽으로 당긴다 / 몸 바깥으로 자르라고 배운 초보자는 조절이 더 나쁘다)
#            → 'Cutting Toward the Thumb'
#   21번째 — 정답 제목 'Two Weeks at the Right Temperature'의 Two Weeks(2주)가 지문에 없음(지문: 'slows over weeks') → 'Slow Weeks at the Right Temperature'
# 지문의 한 구절·해석만(선택지·풀이·해설은 그대로):
#   1번째  — 'the rice is stirred only when it is served, with a light lifting motion rather than a stir'(젓는다 … 젓기보다)가 스스로 부딪힘 → 'touched'(42번 1번째와 같게 — 282번)
#   7번째  — 정답 제목 'Vinegar Poured Hot'의 vinegar가 지문에 없음(지문은 'The liquid'로만 시작) → 첫 문장 'The vinegar mixture is poured over the vegetables …'
AUTO_SYNC = False
E = {}
from z41common import maker, _tb
mk = maker(E, lv='4')
def swap(n, k, new):
    """정답 제목을 바꿈(인계문서에 까닭을 적은 것만): 해설 머리의 영어도 새 제목으로"""
    old = _tb['41']['4'][n]['choices'][k]; e = E[('41', '4', n)]
    assert ("'%s' (" % old) in e['cn'][k]; e['cn'][k] = e['cn'][k].replace("'%s' (" % old, "'%s' (" % new)
    e['ch'] = {k: new}; e['ans_ok'] = True

# ---------- 지문의 한 구절·해석만 바로잡은 두 문항 ----------
E[('41', '4', 0)] = {'passage_ok': True,
    'text': ('the rice is stirred only when it is served', 'the rice is touched only when it is served'),
    'ko': ('밥은 풀 때에만 젓되 젓기보다 가볍게 들어 올리듯 섞어서', '밥은 풀 때에만 손을 대되 젓기보다 가볍게 들어 올리듯 섞어서')}
E[('41', '4', 6)] = {'passage_ok': True,
    'text': ('The liquid is poured over the vegetables while it is still hot', 'The vinegar mixture is poured over the vegetables while it is still hot'),
    'ko': ('절임물은 아직 뜨거울 때 채소 위에 붓는데', '식초 절임물은 아직 뜨거울 때 채소 위에 붓는데')}

# ---------- 13번째: 과일은 칼을 엄지 쪽으로 당겨 깎는다 ----------
mk(12, 1, [
 "1) 되풀이: 「과일은 칼을 엄지 쪽으로 당겨 깎는다」는 생각이 글 전체에 이어집니다. 칼을 엄지 쪽으로 당긴다 → 몸 바깥으로 자르면 작고 둥근 것은 조절이 더 나쁘다 → 그래서 칼날이 짧다 → 과일을 손바닥에 쥐면 고르게 돌릴 수 있다 → 긴 칼은 이 일에 불편하다. 다섯 문장이 모두 그 한 가지 깎는 법을 받쳐 줍니다.",
 "2) 꺾이는 곳: 둘째 문장이 흔한 가르침을 뒤집습니다. «Beginners taught to cut away from the body find the control worse with something small and round.»(몸 바깥으로 자르라고 배운 초보자는 작고 둥근 것에서는 조절이 더 나쁘다는 것을 알게 된다.) 칼은 몸 바깥으로 쓰라고 배우지만, 과일을 깎을 때는 그 반대가 낫다는 말입니다.",
 "3) 끝 문장: «Anyone using a long knife for the job finds it awkward and is more likely to slip.»(이 일에 긴 칼을 쓰는 사람은 누구든 그것이 불편하고 미끄러지기 더 쉽다.) 엄지 쪽으로 당기는 일에는 짧은 칼이 맞는다는 것을 뒤집어 보여 줍니다. 글은 끝까지 그 깎는 법을 말합니다.",
 "4) 묶기: 첫 문장의 'is drawn toward the thumb'(엄지 쪽으로 당겨진다) = 'Cutting Toward the Thumb'(엄지 쪽으로 자르기). 지문의 말을 거의 그대로 제목으로 삼은 것입니다."],
 "「부엌에서 쓰는 칼들」이 가장 끌립니다. 글에 칼이 내내 나오고, 짧은 칼과 긴 칼을 견주기도 하기 때문입니다. 하지만 글이 다루는 것은 부엌칼 전체가 아니라 과일 깎는 칼 하나와 그것을 쓰는 법입니다. 글보다 넓은 제목입니다. 「어떤 과일은 껍질을 벗기는 이유」도 조심합니다. 껍질을 벗기는 이야기이지만, 왜 벗기는지는 지문에 나오지 않습니다.",
 [("과일이 딴 뒤에 익는 과정", "지문에 없는 이야기입니다. 과일이 나와서 떠올린 것이지만, 과일이 익는 일은 나오지 않습니다. 글이 다루는 것은 과일을 깎는 법입니다."),
  ("엄지 쪽으로 자르기", "첫 문장의 «A peeling knife is drawn toward the thumb»이 근거입니다. 둘째 문장은 몸 바깥으로 자르면 조절이 더 나쁘다고 하고, 칼날이 짧은 것도 긴 칼이 불편한 것도 모두 엄지 쪽으로 당겨 깎기 때문입니다."),
  ("손님에게 과일 대접하기", "지문에 없는 이야기입니다. 과일을 깎는 것에서 떠올린 것이지만, 누구에게 내는지는 나오지 않습니다."),
  ("어떤 과일은 껍질을 벗기는 이유", "지문에 없는 이야기입니다. 껍질을 벗기는 글이라서 끌립니다. 하지만 왜 벗기는지는 나오지 않습니다. 글이 말하는 것은 어떻게 벗기는가입니다."),
  ("부엌에서 쓰는 칼들", "글보다 넓은 제목입니다. 짧은 칼과 긴 칼이 나와서 끌립니다. 하지만 글이 다루는 것은 부엌칼 전체가 아니라 과일 깎는 칼 하나와 그 쓰는 법입니다.")])
swap(12, 1, 'Cutting Toward the Thumb')

# ---------- 21번째: 김치는 알맞은 온도에서 천천히 ----------
mk(20, 1, [
 "1) 되풀이: 「김치는 낮은 온도에서 천천히 익혀야 한다」는 생각이 글 처음과 끝에서 되풀이됩니다. 실온에서는 며칠 만에 익고 차가운 곳에서는 몇 주에 걸쳐 느려진다 → 천천히 익은 것이 맛이 더 좋고 훨씬 오래간다 → 통을 가득 채우고 채소를 국물 아래에 둔다 → 뚜껑을 날마다 열지 않는다 → 김치 냉장고가 하는 일은 온도를 붙드는 것 하나다.",
 "2) 꺾이는 곳: 꺾이는 말은 없습니다. 대신 둘째 문장이 두 가지 가운데 한쪽을 고릅니다. «The slow version tastes better and keeps far longer.»(그 느린 쪽이 맛이 더 좋고 훨씬 오래간다.) 며칠 만에 익는 쪽과 몇 주에 걸쳐 익는 쪽 가운데 글이 내세우는 것은 느린 쪽입니다.",
 "3) 끝 문장: «Households that keep a separate refrigerator for it are controlling one thing only, which is temperature.»(그것을 위해 따로 냉장고를 두는 가정은 오직 한 가지만 다스리고 있는데, 그것이 온도다.) 'one thing only'(오직 한 가지)로 글 전체를 한 낱말에 모읍니다. 온도입니다.",
 "4) 묶기: 'slows over weeks'(몇 주에 걸쳐 느려진다)와 'The slow version'(그 느린 쪽) = 'Slow Weeks'(느린 몇 주). 끝 문장의 'temperature'(온도) → 'at the Right Temperature'(알맞은 온도에서). 글의 처음과 끝을 하나로 묶은 제목입니다."],
 "「냉장고 이전의 음식 저장」이 가장 끌립니다. 끝 문장에 냉장고가 나오고, 김치가 오래 두고 먹는 음식이기 때문입니다. 하지만 글은 냉장고가 없던 때의 이야기를 하지 않습니다. 오히려 지금 김치 냉장고를 따로 두는 가정을 말합니다. 「겨울 내내 먹는 채소」도 조심합니다. 김치에서 떠올리기 쉬운 말이지만, 겨울은 지문에 나오지 않습니다.",
 [("집집마다 자기 조리법이 있는 이유", "지문에 없는 이야기입니다. 가정이 나와서 끌리지만, 담그는 법이 집마다 다르다는 말은 없습니다. 글이 다루는 것은 익히는 온도입니다."),
  ("알맞은 온도에서의 느린 몇 주", "끝 문장의 «are controlling one thing only, which is temperature»가 근거입니다. 첫 문장은 차가운 곳에서 몇 주에 걸쳐 느려진다고 하고, 둘째 문장은 그 느린 쪽이 맛이 더 좋고 오래간다고 합니다. 글의 처음과 끝이 모두 온도와 느린 익힘입니다."),
  ("냉장고 이전의 음식 저장", "지문에 없는 이야기입니다. 끝 문장의 냉장고 때문에 끌립니다. 하지만 글은 냉장고가 없던 때를 말하지 않습니다. 지금 김치 냉장고를 두는 가정을 말합니다."),
  ("겨울 내내 먹는 채소", "지문에 없는 이야기입니다. 김치에서 떠올리기 쉬운 말이지만, 겨울도 언제 먹는지도 나오지 않습니다."),
  ("배추를 절이는 방법", "지문에 없는 이야기입니다. 김치를 담그는 일에서 떠올린 것이지만, 절이는 일은 나오지 않습니다. 글은 담근 뒤에 익히는 일을 말합니다.")])
swap(20, 1, 'Slow Weeks at the Right Temperature')
