# -*- coding: utf-8 -*-
# 313번: 35번(무관한 문장) 레벨5 — 레벨 기준에 맞춤: 분사구문이 없는 문항에 문장 하나를 분사구문이 든 문장으로 바꿈(구동사도 하나쯤)
# 선생님 결정(308번): 「진행하고, 4·5도 같은 방식으로 진행해.」 — 레벨5의 기준(측정기준표): 중간 수준 낱말 + 구동사 · 복문 + 분사구문 하나
# 서른 문항을 읽어 가림: 분사구문이 이미 있는 문항 1(11번째 — '…, made from different drops') → 그대로 둠. 나머지 스물아홉 문항에서 문장 하나씩만 바꿈
#   - 문장 앞의 분사구문(Pressing … / Held … by … / Left behind by … / Being …)과 문장 끝의 분사구문(…, exposing … / …, producing …)을 고루 씀
#   - 구동사: cut away · spring back · pull along · set up · speed up · freeze over · spread out · send out · work out · give off · dry up · slow down · fall over ·
#             turn into · burst apart · hold up · push aside · pin down · draw out · dry out · seep in · draw in · blow out
# 글감·정답 번호·나머지 문장·풀이·해설은 그대로(레벨5의 풀이·해설은 문장을 인용하지 않고 내용만 말함). 바꾼 문장의 해석을 함께 고침
AUTO_SYNC = False
E = {}
SENT = {   # 번째-1: (옛 문장, 새 문장, 옛 해석, 새 해석)
 0:  ("② The blade cuts a cone in the casing and the graphite is simply exposed by it.", "② The blade cuts away the casing in a cone, simply exposing the graphite.",
      "② 그 날은 그 껍데기에 원뿔을 깎고 그 흑연은 그것에 의해 그저 드러날 뿐이다.", "② 그 날은 그 껍데기를 원뿔 모양으로 깎아 내어, 그저 그 흑연을 드러낼 뿐이다."),
 1:  ("④ Bakers judge the moment by pressing a finger into the surface and watching it return.", "④ Pressing a finger into the surface, bakers watch it spring back and judge the moment.",
      "④ 제빵사는 그 표면에 손가락을 눌러 그것이 돌아오는 것을 지켜보며 그 순간을 판단한다.", "④ 제빵사는 그 표면에 손가락을 눌러 보며, 그것이 되튀어 오르는 것을 지켜보고 그 순간을 판단한다."),
 2:  ("② The string holds the kite at an angle so that the air cannot simply pass over it.", "② Held at an angle by the string, the kite does not let the air simply pass over it.",
      "② 그 줄이 연을 비스듬히 붙들어 공기가 그저 그 위로 지나가지 못하게 한다.", "② 그 줄에 비스듬히 붙들려 있어서, 연은 공기가 그저 그 위로 지나가게 두지 않는다."),
 3:  ("③ That difference pulls the whole column along and the flow continues without a pump.", "③ That difference pulls the whole column along, keeping the flow going without a pump.",
      "③ 그 차이가 그 물기둥 전체를 끌고 가고 펌프 없이 그 흐름이 이어진다.", "③ 그 차이가 그 물기둥 전체를 끌고 가서, 펌프 없이도 그 흐름을 이어 가게 한다."),
 4:  ("③ The difference produces a force that tips the spinning arc gradually round.", "③ The difference sets up a force, gradually tipping the spinning arc round.",
      "③ 그 차이가 그 회전하는 호를 차츰 돌려 기울이는 힘을 만들어낸다.", "③ 그 차이가 힘을 만들어 내어, 그 회전하는 호를 차츰 돌려 기울인다."),
 5:  ("② Air passing the curved side moves faster and pulls the sail forward.", "② Speeding up as it passes the curved side, the air pulls the sail forward.",
      "② 그 굽은 쪽을 지나는 공기가 빠르게 움직이며 그 돛을 앞으로 당긴다.", "② 그 굽은 쪽을 지나면서 빨라져서, 공기는 그 돛을 앞으로 당긴다."),
 6:  ("③ The film refreezes the moment the skater has passed.", "③ Left behind by the skater, the film freezes over again at once.",
      "③ 그 막은 스케이터가 지나간 순간 다시 언다.", "③ 스케이터가 지나가고 남겨지면, 그 막은 곧바로 다시 얼어붙는다."),
 7:  ("① Heating the air makes the molecules spread out, so fewer of them fill the envelope.", "① Heated by the burner, the air molecules spread out, so fewer of them fill the envelope.",
      "① 공기를 데우면 분자가 퍼져서 더 적은 수가 그 기구를 채운다.", "① 버너로 데워지면 공기 분자가 퍼져서 더 적은 수가 그 기구를 채운다."),
 8:  ("③ The tip therefore accelerates until it breaks the sound barrier and produces the noise.", "③ The tip therefore speeds up until it breaks the sound barrier, producing the sharp crack.",
      "③ 따라서 그 끝이 음속의 벽을 깨고 그 소리를 낼 때까지 가속한다.", "③ 따라서 그 끝은 음속의 벽을 깰 때까지 빨라져서, 그 날카로운 소리를 낸다."),
 9:  ("② A faster boat produces larger waves along the same lines rather than a wider spread.", "② Speeding up, a boat sends out larger waves along the same lines rather than a wider spread.",
      "② 더 빠른 배는 더 넓게 퍼지기보다 같은 선을 따라 더 큰 파도를 만들어낸다.", "② 속도를 올리면, 배는 더 넓게 퍼뜨리기보다 같은 선을 따라 더 큰 파도를 내보낸다."),
 11: ("② Light travelling at a shallow angle bends upward as it passes through the thin layer.", "② Passing through the thin layer at a shallow angle, the light bends upward.",
      "② 얕은 각도로 이동하는 빛은 그 옅은 층을 지나며 위로 굽는다.", "② 얕은 각도로 그 옅은 층을 지나면서, 빛은 위로 굽는다."),
 12: ("④ Counting the seconds between the two therefore gives a usable distance.", "④ Counting the seconds between the two, a listener can therefore work out the distance.",
      "④ 따라서 그 둘 사이의 초를 세면 쓸 만한 거리가 나온다.", "④ 따라서 그 둘 사이의 초를 세어, 듣는 사람은 그 거리를 셈해 낼 수 있다."),
 13: ("① Grass radiates its heat to the open sky and cools below the temperature of the air.", "① Grass gives off its heat to the open sky, cooling below the temperature of the air.",
      "① 풀은 트인 하늘로 자기 열을 내보내고 공기의 온도 아래로 식는다.", "① 풀은 트인 하늘로 자기 열을 내보내어, 공기의 온도 아래로 식는다."),
 14: ("③ Below about minus ten the film is gone and the crystals break instead of sliding.", "③ Below about minus ten the film dries up, leaving the crystals to break instead of sliding.",
      "③ 영하 10도쯤 아래에서는 그 막이 사라지고 그 결정이 미끄러지는 대신 부서진다.", "③ 영하 10도쯤 아래에서는 그 막이 말라 없어져, 그 결정이 미끄러지는 대신 부서지게 된다."),
 15: ("④ The top begins to wobble as friction slows it and falls when the spin is gone.", "④ Slowed down by friction, the top begins to wobble and falls over when the spin is gone.",
      "④ 그 팽이는 마찰이 그것을 늦추면서 흔들리기 시작하고 그 회전이 사라지면 넘어진다.", "④ 마찰로 느려지면, 그 팽이는 흔들리기 시작하고 그 회전이 사라지면 쓰러진다."),
 16: ("② Air moves faster past one side than the other, and the ball is pushed toward the faster side.", "② Moving faster past one side than the other, the air pushes the ball toward the faster side.",
      "② 한쪽을 지나는 공기가 다른 쪽보다 빠르게 움직이고, 그 공은 빠른 쪽으로 밀린다.", "② 한쪽을 다른 쪽보다 빠르게 지나면서, 공기는 그 공을 빠른 쪽으로 민다."),
 17: ("② The load is turned into a push that travels along the curve to the ground.", "② The load is turned into a push, travelling along the curve down to the ground.",
      "② 그 하중은 그 곡선을 따라 땅으로 가는 밀침으로 바뀐다.", "② 그 하중은 밀침으로 바뀌어, 그 곡선을 따라 땅으로 내려간다."),
 18: ("① The cables hang in a curve and every part of them is being pulled rather than bent.", "① Hanging in a curve, the cables are pulled rather than bent along their whole length.",
      "① 그 케이블은 곡선으로 늘어지고 그 모든 부분이 휘어지는 것이 아니라 당겨지고 있다.", "① 곡선으로 늘어져 있어서, 그 케이블은 전체 길이에 걸쳐 휘어지는 것이 아니라 당겨진다."),
 19: ("② The lower rings are also being pushed outward and would burst without restraint.", "② Pushed outward as well, the lower rings would burst apart without restraint.",
      "② 아래쪽 고리는 또한 바깥으로 밀리고 있어서 붙들지 않으면 터질 것이다.", "② 또한 바깥으로 밀리고 있어서, 아래쪽 고리는 붙들지 않으면 터져 벌어질 것이다."),
 20: ("③ Adding one diagonal turns it into two triangles and it becomes rigid.", "③ Adding one diagonal turns it into two triangles, making the whole frame rigid.",
      "③ 대각선 하나를 더하면 그것이 삼각형 둘이 되고 단단해진다.", "③ 대각선 하나를 더하면 그것이 삼각형 둘이 되어, 틀 전체가 단단해진다."),
 21: ("③ The same sheet folded into ridges holds several without bending.", "③ Folded into ridges, the same sheet holds up several coins without bending.",
      "③ 같은 장을 골이 지게 접으면 휘지 않고 여러 개를 지탱한다.", "③ 골이 지게 접으면, 같은 장이 휘지 않고 동전 여러 개를 떠받친다."),
 22: ("③ A hull encloses a great deal of air and displaces far more water than the steel alone.", "③ Enclosing a great deal of air, a hull pushes aside far more water than the steel alone.",
      "③ 선체는 아주 많은 공기를 품어 그 강철만보다 훨씬 많은 물을 밀어낸다.", "③ 아주 많은 공기를 품고 있어서, 선체는 그 강철만보다 훨씬 많은 물을 밀어낸다."),
 23: ("⑤ Matching a beam against a master pattern dates it to a single year.", "⑤ Matching a beam against a master pattern, experts can pin it down to a single year.",
      "⑤ 한 들보를 기준 양상에 맞추면 그것의 연대가 한 해까지 정해진다.", "⑤ 한 들보를 기준 양상에 맞추어 보아, 전문가들은 그것의 연대를 한 해까지 짚어 낼 수 있다."),
 24: ("② Water moves out of the cells of the food and out of any organism on it.", "② Drawn out by the salt, water leaves the cells of the food and of any organism on it.",
      "② 물이 그 음식의 세포에서, 그리고 그 위의 어떤 생물에게서도 빠져나온다.", "② 소금에 끌려 나와, 물이 그 음식의 세포에서, 그리고 그 위의 어떤 생물의 세포에서도 빠져나온다."),
 25: ("① The heat dries the outer layer so that there is less water for anything to grow in.", "① The heat dries out the outer layer, leaving less water for anything to grow in.",
      "① 그 열이 바깥층을 말려 무언가 자랄 물이 줄어든다.", "① 그 열이 바깥층을 바싹 말려, 무언가 자랄 물을 덜 남긴다."),
 26: ("④ A loaf frozen on the day of baking is better after a month than one kept two days cold.", "④ Frozen on the day of baking, a loaf holds up better after a month than one kept two days cold.",
      "④ 구운 날에 얼린 빵이 한 달 뒤에도 이틀 차게 둔 것보다 낫다.", "④ 구운 날에 얼리면, 빵은 한 달 뒤에도 이틀 차게 둔 것보다 더 잘 버틴다."),
 27: ("① The shell is slightly porous and air enters it steadily over weeks.", "① Being slightly porous, the shell lets air seep in steadily over weeks.",
      "① 그 껍데기는 약간 다공성이고 몇 주에 걸쳐 공기가 꾸준히 들어간다.", "① 약간 다공성이어서, 그 껍데기는 몇 주에 걸쳐 공기가 꾸준히 스며들게 한다."),
 28: ("② A stem cut in air draws in a bubble that blocks the tubes carrying water.", "② Cut in air, a stem draws in a bubble that blocks the tubes carrying water.",
      "② 공기 중에서 자른 줄기는 물을 나르는 관을 막는 기포를 빨아들인다.", "② 공기 중에서 잘리면, 줄기는 물을 나르는 관을 막는 기포를 빨아들인다."),
 29: ("⑤ Blowing a candle out leaves a line of vapour that can be lit again from above.", "⑤ Blown out, a candle leaves a line of vapour that can be lit again from above.",
      "⑤ 초를 불어 끄면 위에서 다시 불을 붙일 수 있는 증기의 줄이 남는다.", "⑤ 불어서 끄면, 초는 위에서 다시 불을 붙일 수 있는 증기의 줄을 남긴다."),
}
for n, (a, b, ka, kb) in SENT.items():
    E[('35', '5', n)] = {'passage_ok': True, 'text': (a, b), 'ko': (ka, kb)}
