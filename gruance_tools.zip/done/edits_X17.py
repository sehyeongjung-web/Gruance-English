# -*- coding: utf-8 -*-
# 270번: 31번(빈칸 추론) 레벨5 — 검토해서 탈이 있는 문항만 바로잡음(30문항을 다 읽고 한 문항을 고침)
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새로 씀(레벨6~9와 같은 꼴). 정답 번호·선택지 변동 없음. z8common.py가 같은 폴더에 있어야 함
#   23번째 — 정답(용수철)의 근거가 지문에 없음. 오답 'a grip of rough wood that will not slip'·'a shape that fits closely over the line'과 지문만으로는 가를 수 없음
#            → 첫 문장 끝에 ': press the ends and the jaws open, let go and they shut'
AUTO_SYNC = False
E = {}
from z8common import maker
mk = maker(E, '31', lv='5')
def fix(n, text, ko):
    E[('31', '5', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 23번째: 빨래집게가 하는 일은 모두 용수철에서 온다 ----------
mk(22, 1, [
 "1) 빈칸 문장: 둘째 문장입니다. «Everything it does comes from»(그것이 하는 모든 것은 ~에서 온다). 빨래집게가 빨래를 붙드는 힘이 어디서 나오는지를 묻습니다. 뒤에 «pegs that fail have almost always failed at that one part»(망가지는 집게는 거의 언제나 그 한 부분에서 망가졌다)가 붙어 있으니, 빈칸에는 집게의 한 부분이 들어갑니다.",
 "2) 짝꿍 문장: 첫 문장의 뒤쪽입니다. «press the ends and the jaws open, let go and they shut»(끝을 누르면 입이 벌어지고, 놓으면 닫힌다). 손을 놓기만 해도 저절로 닫힙니다. 손이 닫는 것이 아닙니다. 집게 안의 무언가가 두 쪽을 맞붙도록 밀고 있습니다.",
 "3) 한 부분 찾기: 놓으면 되돌아가게 하는 부분, 눌렀다 놓기를 되풀이하다 망가지는 부분을 생각합니다. 누르면 버티고 놓으면 되돌리는 것은 용수철입니다. 용수철이 망가지면 집게는 닫히지 않습니다.",
 "4) 묶기: 놓으면 저절로 닫힌다 = 두 쪽을 맞붙게 미는 부분이 있다 = 'a spring pressing two arms together'. jaws(입)를 이루는 두 쪽이 'two arms'(두 팔)입니다."],
 "「미끄러지지 않을 거친 나무의 잡는 면」이 가장 끌립니다. 빨래를 붙들려면 미끄러지지 않아야 한다고 생각하기 쉽습니다. 하지만 첫 문장의 단서는 놓으면 저절로 닫힌다는 것입니다. 나무의 거친 면은 닫는 힘을 내지 못합니다. 닫는 힘이 없으면 거친 면도 빨래를 물지 못합니다. 「그 줄에 꼭 맞게 끼워지는 모양」도 끌리지만, 모양은 망가질 수 있는 한 부분이 아닙니다.",
 [("그 줄에 꼭 맞게 끼워지는 모양", "모양은 집게의 한 부분이 아닙니다. 글은 망가지는 집게가 그 한 부분에서 망가진다고 했습니다. 놓으면 저절로 닫힌다는 것도 모양으로는 풀리지 않습니다."),
  ("두 팔을 맞붙게 누르는 용수철", "첫 문장의 «press the ends and the jaws open, let go and they shut»가 근거입니다. 손을 놓으면 저절로 닫히는 것은 안에서 두 쪽을 맞붙게 미는 용수철이 있기 때문입니다. 용수철이 망가지면 집게는 아무것도 하지 못합니다."),
  ("그 천의 무게에 맞춘 크기", "지문에 없는 이야기입니다. 빨래의 무게나 집게의 크기는 나오지 않습니다. 크기는 망가질 수 있는 한 부분도 아닙니다."),
  ("미끄러지지 않을 거친 나무의 잡는 면", "빨래를 붙든다는 말 때문에 끌립니다. 하지만 거친 면은 닫는 힘을 내지 못합니다. 지문의 단서는 놓으면 저절로 닫힌다는 것이고, 그 힘은 다른 데서 옵니다."),
  ("그 집게를 붙드는 고리", "지문에 없는 이야기입니다. 고리는 나오지 않습니다. 글이 말하는 것은 집게가 빨래를 무는 힘이지 집게를 어디에 거는가가 아닙니다.")])
fix(22, ('with almost no change in design. Everything it does', 'with almost no change in design: press the ends and the jaws open, let go and they shut. Everything it does'),
        ('빨랫줄에 빨래를 붙들어 왔다.', '빨랫줄에 빨래를 붙들어 왔다. 끝을 누르면 입이 벌어지고, 놓으면 닫힌다.'))
