# -*- coding: utf-8 -*-
# 257번: 36-37번(글의 순서) 레벨6 — 검토해서 탈이 있는 문항만 바로잡음(30문항을 다 읽고 일곱 문항을 고침)
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새 지문에 맞게 다시 씀(레벨7~9와 같은 꼴). 정답·선택지 변동 없음. z3common.py가 같은 폴더에 있어야 함
# 탈: 모두 「다른 순서로도 읽힘」 — 가리키는 말 하나씩으로 막음(해석도 함께)
#   1번째 (A) 'They' → 'The four men on board', (C) 'The crew had no radio, so they …' → 'Their second was about being seen: with no radio, they …'   ((C)-(A)-(B)를 막음)
#   4번째 (B) 'areas the team had recorded as empty' → 'areas that those sample squares had missed'        ((B)-(C)-(A)를 막음)
#   8번째 (B) 'It recorded' → 'In that time it recorded'                                                    ((B)-(C)-(A)를 막음)
#   16번째 (C) 'Gas dissolved …' → 'The cause of that pain was gas dissolved …, which …'                    ((C)-(B)-(A)를 막음)
#   17번째 (A) 'The entries … at fixed times' → 'Those four-hourly entries …'                               ((A)-(C)-(B)를 막음)
#   21번째 (B) 'Teams were landed' → 'Later teams were landed'                                              ((B)-(C)-(A)를 막음)
#   23번째 (A) 'Watches, …, so' → 'He moves it so little because watches, …, and', (C) 'rarely notice' → 'rarely notice either'   ((A)-(C)-(B)·(B)-(C)-(A)를 막음)
AUTO_SYNC = False
E = {}
from z3common import maker
mk = maker(E, lv='6')
def fix(n, text, ko):
    E[('36_37', '6', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 1번째: 떠내려간 고깃배의 사흘 ----------
mk(0, 'ACB', [
 "1) 주어진 글: 고깃배 한 척이 뭍에서 사십 킬로미터 떨어진 데서 엔진을 잃고, 찾아낼 때까지 사흘을 떠내려갔습니다. 배에 탄 사람들이 그동안 무엇을 했는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (A): «The four men on board had water for two days and food for one, and the first decision they made was to cut both in half.»(배에 탄 네 사람에게는 이틀 치 물과 하루 치 먹거리가 있었고, 그들이 내린 첫 결정은 둘 다 절반으로 줄이는 것이었다.) 사람을 처음 내놓고, 'the first decision'(첫 결정)을 말합니다.",
 "3) 둘째 글 (C): «Their second was about being seen»(그들의 둘째 결정은 눈에 띄는 것에 관한 것이었다). 'Their second'(그들의 둘째)는 첫 결정이 앞에 있어야 쓸 수 있습니다. 무전기가 없어서 노란 웃옷을 찢어 돛대에 묶었습니다.",
 "4) 셋째 글 (B)와 확인: 찾는 비행기가 둘째 날 낮에 'the yellow marks'(그 노란 표시)를 보았습니다. (C)의 노란 조각입니다. 'All four'(넷 모두)는 (A)의 네 사람입니다. 첫 결정 → 둘째 결정 → 구해짐으로 맞물리므로 순서는 (A)-(C)-(B)입니다."],
 "(C)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 떠내려가는 배에서 가장 먼저 할 일은 알리는 것 같기 때문입니다. 하지만 (C)는 'Their second'(그들의 둘째)로 시작합니다. 첫 결정이 먼저 나와야 하고, 그것은 (A)에 있습니다. Their가 가리킬 사람들도 (A)에서 처음 나옵니다.",
 {'ACB': "주어진 글의 배를 (A)가 받아 네 사람과 첫 결정을 내놓고, (C)의 'Their second'가 그 뒤의 둘째 결정을 말하고, (B)의 'the yellow marks'가 (C)의 노란 조각을 받아 구해진 이야기로 맺습니다.",
  'BAC': "(B)의 'the yellow marks'(그 노란 표시)가 가리킬 것이 주어진 글에 없습니다. 노란 조각은 (C)에 나옵니다. 구해진 이야기가 맨 앞에 올 수 없습니다.",
  'BCA': "(B)에서 넷 모두 구해진 뒤에 (C)에서 노란 조각을 묶고 (A)에서 먹거리를 줄입니다. 끝이 처음보다 먼저 나와 차례가 거꾸로입니다.",
  'CAB': "(C)의 'Their second'(그들의 둘째)는 첫 결정이 앞에 있어야 합니다. 첫 결정은 (A)에 있으므로 (A)가 (C) 앞에 와야 합니다.",
  'CBA': "(C)의 'Their second'가 가리킬 첫 결정이 앞에 없습니다. 또 (A)가 맨 끝에 오면, 다 구해진 뒤에 물과 먹거리를 절반으로 줄이게 됩니다."})
fix(0, [('(A) They had water for two days and food for one,', '(A) The four men on board had water for two days and food for one,'),
        ('(C) The crew had no radio, so they tore up a yellow jacket and tied strips of it', '(C) Their second was about being seen: with no radio, they tore up a yellow jacket and tied strips of it')],
       [('(A) 그들에게는 이틀 치 물과', '(A) 배에 탄 네 사람에게는 이틀 치 물과'),
        ('(C) 선원들에게는 무전기가 없어서, 노란 재킷을 찢어', '(C) 두 번째 결정은 눈에 띄는 것에 관한 것이었다. 무전기가 없어서, 그들은 노란 재킷을 찢어')])

# ---------- 4번째: 땅에서 센 펭귄과 위에서 본 펭귄 ----------
mk(3, 'CBA', [
 "1) 주어진 글: 땅에서 펭귄 무리를 센 살핌 무리가 낸 숫자를, 나중의 위성 사진이 크게 뒤집었습니다. 그들이 어떻게 세었는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «The counters had walked the perimeter and estimated density from sample squares, which is the standard method.»(세는 이들은 둘레를 걸으며 본보기 네모들에서 빽빽함을 어림했는데, 그것은 여느 방법이다.) 'The counters'가 주어진 글의 살핌 무리입니다. 'sample squares'(본보기 네모)를 처음 내놓습니다.",
 "3) 둘째 글 (B): 위에서 찍은 사진은 새들이 «areas that those sample squares had missed»(그 본보기 네모들이 놓친 곳)에 빽빽이 들어차 있음을 보여 주었습니다. 'those sample squares'가 (C)를 받습니다. 낮은 등성이가 땅에서의 눈길을 가렸기 때문입니다.",
 "4) 셋째 글 (A)와 확인: «Colonies are now counted from satellite images»(무리는 이제 위성 사진으로 센다). now(이제)가 그 뒤의 일임을 알립니다. 센 방법 → 그 방법이 놓친 것 → 그래서 지금은으로 맞물리므로 순서는 (C)-(B)-(A)입니다."],
 "(B)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 주어진 글이 위성 사진으로 끝나니 위에서 찍은 사진 이야기가 바로 이어질 것 같기 때문입니다. 하지만 (B)의 'those sample squares'(그 본보기 네모들)가 가리킬 것이 주어진 글에 없습니다. 그 말은 (C)에서 처음 나옵니다.",
 {'ACB': "(A)의 now(이제)는 그 뒤의 일을 말합니다. 왜 숫자가 틀렸는지를 말하기도 전에 지금의 방법이 나오면 차례가 맞지 않습니다.",
  'BAC': "(B)의 'those sample squares'가 가리킬 것이 주어진 글에 없습니다. 또 (C)가 맨 끝에 오면, 지금의 방법까지 말한 뒤에 옛 방법으로 되돌아갑니다.",
  'BCA': "(B)의 'those sample squares'(그 본보기 네모들)가 (C)의 'sample squares'보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다.",
  'CAB': "(C)로 시작하는 것은 맞습니다. 하지만 (A)의 「이제는 위성으로 센다」가 (B)보다 먼저 나옵니다. 땅에서 센 것이 무엇을 놓쳤는지를 말한 뒤에야 방법을 바꾼 까닭이 섭니다.",
  'CBA': "주어진 글의 살핌 무리를 (C)의 'The counters'가 받아 세는 방법을 말하고, (B)의 'those sample squares'가 그 방법이 놓친 것을 말하고, (A)가 그래서 이제는 위성으로 센다고 맺습니다."})
fix(3, ('areas the team had recorded as empty', 'areas that those sample squares had missed'),
       ('조사팀이 비어 있다고 기록한 곳에', '그 표본 구획이 놓친 곳에'))

# ---------- 8번째: 한 주를 내다본 꼬리표가 넉 달을 버텼다 ----------
mk(7, 'CBA', [
 "1) 주어진 글: 연구하는 이들이 고래에 작은 꼬리표를 달면서, 그것이 떨어지기 전에 한 주 치의 잠수를 적으리라고 내다보았습니다. 실제로는 어떻게 되었는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «The tag stayed attached for four months and travelled with the animal across most of an ocean.»(그 꼬리표는 넉 달 동안 붙어 있었고, 그 짐승과 함께 큰 바다의 대부분을 건넜다.) 한 주라는 내다봄과 넉 달이 맞섭니다.",
 "3) 둘째 글 (B): «In that time it recorded dives to depths that nobody had thought the species capable of»(그 동안에 그것은 아무도 그 갈래가 할 수 있다고 여기지 않던 깊이까지의 잠수를 적었다). 'that time'(그 동안)이 (C)의 넉 달을 받습니다.",
 "4) 셋째 글 (A)와 확인: «The paper that followed changed what was known about the animal»(뒤따른 글은 그 짐승에 대해 알려진 것을 바꾸었다). (B)에서 적은 것이 글로 나온 것입니다. 넉 달을 버팀 → 그 동안 적은 것 → 그것으로 쓴 글로 맞물리므로 순서는 (C)-(B)-(A)입니다."],
 "(B)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. it이 주어진 글의 꼬리표를 바로 받을 수 있어 보이기 때문입니다. 하지만 (B)는 'In that time'(그 동안에)으로 시작합니다. 주어진 글의 「한 주」는 내다본 것일 뿐 실제로 지난 시간이 아닙니다. 그 동안은 (C)의 넉 달입니다.",
 {'ACB': "(A)의 「뒤따른 글」은 꼬리표가 무엇을 적었는지가 나온 뒤에야 올 수 있습니다. 주어진 글에서는 아직 꼬리표를 달았을 뿐입니다.",
  'BAC': "(B)의 'In that time'(그 동안에)이 가리킬 동안이 주어진 글에 없습니다. 또 (C)가 맨 끝에 오면, 글까지 나온 뒤에 꼬리표가 넉 달을 버텼다는 말이 나옵니다.",
  'BCA': "(B)의 'that time'이 (C)의 넉 달보다 먼저 나옵니다. 얼마나 붙어 있었는지를 말하기 전에 「그 동안에」라고 할 수 없습니다.",
  'CAB': "(C)로 시작하는 것은 맞습니다. 하지만 (A)의 글이 (B)보다 먼저 나옵니다. 무엇을 적었는지가 나온 뒤에야 그것에 기댄 글을 말할 수 있습니다.",
  'CBA': "주어진 글의 꼬리표를 (C)가 받아 넉 달을 버텼다고 하고, (B)의 'In that time'이 그 넉 달을 받아 무엇을 적었는지를 말하고, (A)가 그것으로 쓴 글로 맺습니다."})
fix(7, ('(B) It recorded dives', '(B) In that time it recorded dives'),
       ('(B) 그것은 아무도', '(B) 그 기간에 그것은 아무도'))

# ---------- 16번째: 물 위로 올라온 뒤에 앓은 잠수하는 이들 ----------
mk(15, 'BCA', [
 "1) 주어진 글: 19세기에 항구의 밑바탕 일을 하던 잠수하는 이들이 물 위로 돌아온 뒤에 앓았고, 아무도 그 까닭을 몰랐습니다. 어떻게 앓았는지, 그 까닭이 무엇인지가 다음에 나와야 합니다.",
 "2) 첫째 글 (B): «The pain appeared in the joints and the men worked bent over»(아픔은 뼈마디에 나타났고 사람들은 몸을 굽힌 채 일했다). 주어진 글의 「앓았다」가 어떤 모습이었는지를 풉니다. 그 병의 흔한 이름이 거기서 나왔습니다.",
 "3) 둘째 글 (C): «The cause of that pain was gas dissolved under pressure»(그 아픔의 까닭은 누르는 힘 아래 녹아 있던 기체였다). 'that pain'(그 아픔)이 (B)의 'The pain'을 받습니다. 그 기체가 누르는 힘이 너무 빨리 풀리면 방울이 되어 나왔습니다.",
 "4) 셋째 글 (A)와 확인: «Once that was understood»(그것을 알게 되자)의 that은 (C)의 까닭입니다. 단계를 두어 천천히 올리자 그것을 온전히 막을 수 있었습니다. 앓는 모습 → 까닭 → 막는 법으로 맞물리므로 순서는 (B)-(C)-(A)입니다."],
 "(C)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 주어진 글이 「아무도 그 까닭을 몰랐다」로 끝나니 까닭이 바로 이어질 것 같기 때문입니다. 하지만 (C)의 'that pain'(그 아픔)이 가리킬 말이 주어진 글에 없습니다. 주어진 글은 앓았다고만 했습니다. 아픔은 (B)에서 처음 나옵니다.",
 {'ACB': "(A)의 'Once that was understood'(그것을 알게 되자)가 가리킬 것이 주어진 글에 없습니다. 주어진 글은 아무도 까닭을 몰랐다고 했습니다. 막는 법이 맨 앞에 올 수 없습니다.",
  'BAC': "(B)로 시작하는 것은 맞습니다. 하지만 (A)의 「그것을 알게 되자」가 (C)의 까닭보다 먼저 나옵니다. 까닭을 말하기 전에 알게 되었다고 할 수 없습니다.",
  'BCA': "주어진 글의 「앓았다」를 (B)가 아픔의 모습으로 풀고, (C)의 'that pain'이 그 아픔을 받아 까닭을 대고, (A)의 that이 그 까닭을 받아 막는 법으로 맺습니다.",
  'CAB': "(C)의 'that pain'이 가리킬 것이 주어진 글에 없습니다. 또 (B)가 맨 끝에 오면, 막는 법까지 말한 뒤에 아픔이 어디에 나타났는지를 말하게 됩니다.",
  'CBA': "(C)의 'that pain'(그 아픔)이 (B)의 'The pain'보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다."})
fix(15, ('(C) Gas dissolved under pressure came out of solution as bubbles', '(C) The cause of that pain was gas dissolved under pressure, which came out of solution as bubbles'),
        ('(C) 압력 아래 녹아 있던 기체가 압력이 너무 빨리 풀리면 기포가 되어 빠져나왔다.', '(C) 그 통증의 원인은 압력 아래 녹아 있던 기체였는데, 그것은 압력이 너무 빨리 풀리면 기포가 되어 빠져나왔다.'))

# ---------- 17번째: 뱃길 일지가 날씨의 기록이 되다 ----------
mk(16, 'CAB', [
 "1) 주어진 글: 세 세기에 걸쳐 적은 배의 일지가 바다의 지난 날씨에 대한 가장 좋은 기록으로 드러났습니다. 일지에 무엇을, 왜 적었는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «Officers recorded wind direction and force every four hours because the information was needed to work out position.»(배의 윗사람들은 바람의 쪽과 세기를 네 시간마다 적었는데, 그것이 자리를 셈하는 데 있어야 했기 때문이다.) 무엇을 얼마나 자주 적었는지가 여기서 처음 나옵니다.",
 "3) 둘째 글 (A): «Those four-hourly entries were made in a standard form and by trained people»(네 시간마다의 그 적은 것들은 정해진 꼴로, 익힌 사람들이 적었다). 'Those four-hourly entries'가 (C)의 「네 시간마다 적었다」를 받습니다. 과학자가 바랄 바로 그것입니다.",
 "4) 셋째 글 (B)와 확인: «Millions of those entries have now been transcribed»(그 적은 것들 수백만 건이 이제 옮겨 적혔다). now(이제)가 오늘의 일임을 알립니다. 무엇을 적었나 → 어떻게 적었나 → 지금 어떻게 쓰나로 맞물리므로 순서는 (C)-(A)-(B)입니다."],
 "(A)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. entries(적은 것들)가 주어진 글의 일지를 바로 받을 수 있어 보이기 때문입니다. 하지만 (A)는 'Those four-hourly entries'(네 시간마다의 그 적은 것들)로 시작합니다. 네 시간마다 적었다는 말은 (C)에서 처음 나옵니다.",
 {'ACB': "(A)의 'Those four-hourly entries'가 가리킬 「네 시간마다」가 주어진 글에 없습니다. 그 말은 (C)에 나오므로 (C)가 (A) 앞에 와야 합니다.",
  'BAC': "(B)의 now(이제)는 오늘의 일입니다. 무엇을 어떻게 적었는지를 말하기도 전에, 그것을 옮겨 적어 쓴다는 말이 맨 앞에 올 수 없습니다.",
  'BCA': "(B)에서 오늘의 쓰임을 말한 뒤에 (C)와 (A)에서 옛날에 어떻게 적었는지로 되돌아갑니다. 차례가 거꾸로입니다.",
  'CAB': "주어진 글의 일지를 (C)가 받아 무엇을 네 시간마다 적었는지를 말하고, (A)의 'Those four-hourly entries'가 그것을 받아 어떻게 적었는지를 말하고, (B)가 그것을 지금 어떻게 쓰는지로 맺습니다.",
  'CBA': "(C)로 시작하는 것은 맞습니다. 하지만 (B)의 오늘 이야기 뒤에 (A)가 옵니다. 기후 모델에 넣었다고 맺은 뒤에 옛날에 정해진 꼴로 적었다는 말이 오면 흐름이 뒤로 돌아갑니다."})
fix(16, ('(A) The entries were made in a standard form, by trained people, at fixed times, which', '(A) Those four-hourly entries were made in a standard form and by trained people, which'),
        ('(A) 그 기록은 정해진 양식으로, 훈련받은 사람이, 정해진 시각에 적은 것이었는데,', '(A) 네 시간마다 적은 그 기록은 정해진 양식으로, 훈련받은 사람이 적은 것이었는데,'))

# ---------- 21번째: 얼음덩이와 함께 떠내려가는 날씨 살핌터 ----------
mk(20, 'CBA', [
 "1) 주어진 글: 얼음덩이 위의 날씨 살핌터는 얼음과 함께 떠내려가는데, 그것은 거기 있는 사람들에게는 어려움이고 과학에는 좋은 점입니다. 그런 살핌터가 어떻게 이어져 왔는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «The first such camp was established in 1937»(그런 첫 머무는 터는 1937년에 세워졌다). 'such camp'(그런 터)가 주어진 글의 살핌터를 받습니다. first(첫)가 차례의 처음임을 알립니다. 그것은 부서지기까지 이천 킬로미터를 갔습니다.",
 "3) 둘째 글 (B): «Later teams were landed with huts and supplies and collected a year later»(나중의 무리들은 오두막과 물자와 함께 내려졌다가 한 해 뒤에 거두어졌다). 'Later teams'(나중의 무리들)는 첫 터가 앞에 있어야 쓸 수 있습니다.",
 "4) 셋째 글 (A)와 확인: «Automatic stations have done the work since the 1990s»(1990년대부터는 저절로 도는 살핌터가 그 일을 해 왔다). 1937년 → 나중의 무리들 → 1990년대, 때의 차례대로 맞물리므로 순서는 (C)-(B)-(A)입니다."],
 "(B)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 주어진 글의 「거기 있는 사람들」을 무리가 바로 받는 것처럼 보이기 때문입니다. 하지만 (B)는 'Later teams'(나중의 무리들)로 시작합니다. 나중이라고 하려면 처음이 앞에 있어야 하고, 그것이 (C)의 'The first such camp'입니다.",
 {'ACB': "(A)의 1990년대가 (C)의 1937년보다 먼저 나옵니다. 때의 차례가 거꾸로입니다. 「그 일을 해 왔다」의 그 일도 아직 나오지 않았습니다.",
  'BAC': "(B)의 'Later teams'(나중의 무리들)는 처음이 앞에 있어야 합니다. 또 (C)가 맨 끝에 오면, 1990년대 뒤에 1937년의 첫 터가 나옵니다.",
  'BCA': "(B)의 'Later teams'가 (C)의 'The first such camp'보다 먼저 나옵니다. 나중이 처음보다 앞에 올 수 없습니다.",
  'CAB': "(C)로 시작하는 것은 맞습니다. 하지만 (A)의 1990년대가 (B)보다 먼저 나옵니다. 저절로 도는 살핌터가 일을 넘겨받은 뒤에 사람 무리를 내렸다는 말이 오면 차례가 맞지 않습니다.",
  'CBA': "주어진 글의 살핌터를 (C)의 'such camp'가 받아 1937년의 첫 터를 말하고, (B)의 'Later teams'가 그 뒤의 무리들을 말하고, (A)가 1990년대부터의 저절로 도는 살핌터로 맺습니다."})
fix(20, ('(B) Teams were landed', '(B) Later teams were landed'),
        ('(B) 팀은 오두막과', '(B) 그 뒤의 팀들은 오두막과'))

# ---------- 23번째: 배의 시계는 날마다 조금씩 옮긴다 ----------
mk(22, 'BAC', [
 "1) 주어진 글: 큰 바다를 건너는 배는 시계를 한꺼번에가 아니라 날마다 조금씩 바꿉니다. 누가, 어떻게 바꾸는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (B): «The master decides when to advance or retard the clock, usually by a few minutes at a time overnight.»(배의 으뜸이 시계를 언제 당기거나 늦출지를 정하는데, 대개 밤사이에 한 번에 몇 분씩이다.) 'The master'로 사람을 처음 내놓습니다.",
 "3) 둘째 글 (A): «He moves it so little because watches, meals and work are organized around the ship's time»의 뜻, 곧 그가 그것을 그렇게 조금씩 옮기는 것은 번 서기와 끼니와 일이 배의 시간에 맞춰 짜여 있기 때문이라는 말입니다. He는 (B)의 으뜸이고, it은 시계입니다. 'so little'(그렇게 조금)이 (B)의 「몇 분씩」을 받습니다.",
 "4) 셋째 글 (C)와 확인: «Passengers rarely notice either»(타는 이들도 좀처럼 알아채지 못한다). either(~도 또한)는 앞에 흐트러지지 않는 다른 쪽이 나와 있어야 쓸 수 있습니다. 그것이 (A)의 번 서기와 끼니와 일입니다. 누가 어떻게 → 왜 그렇게 → 그래서 타는 이들도로 맞물리므로 순서는 (B)-(A)-(C)입니다."],
 "(A)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 조금씩 바꾼다는 말 뒤에 그 까닭이 바로 와도 될 것 같기 때문입니다. 하지만 (A)의 He가 가리킬 사람이 주어진 글에 없습니다. 주어진 글의 임자말은 배입니다. 사람은 (B)의 'The master'에서 처음 나옵니다.",
 {'ACB': "(A)의 He가 가리킬 사람이 주어진 글에 없습니다. 배의 으뜸은 (B)에서 처음 나오므로 (B)가 (A) 앞에 와야 합니다.",
  'BAC': "주어진 글의 「조금씩 바꾼다」를 (B)가 누가 어떻게 하는지로 풀고, (A)의 He가 그 으뜸을 받아 왜 그렇게 조금씩인지를 대고, (C)의 either가 (A)에 이어 타는 이들도 알아채지 못한다고 맺습니다.",
  'BCA': "(B)로 시작하는 것은 맞습니다. 하지만 (C)의 either(~도 또한)가 받을 것이 (B)에 없습니다. 흐트러지지 않는 다른 쪽을 말하는 (A)가 (C) 앞에 와야 합니다.",
  'CAB': "(C)의 either가 받을 것이 주어진 글에 없습니다. 또 (B)가 맨 끝에 오면, 까닭과 결과를 다 말한 뒤에야 누가 시계를 옮기는지가 나옵니다.",
  'CBA': "(C)의 either가 받을 것이 앞에 없고, (A)의 He가 (B)의 으뜸을 바로 받기는 하지만 글이 까닭으로 끝나 맺음이 서지 않습니다. (C)의 「그것이 바로 뜻한 바」가 맺음 자리에 와야 합니다."})
fix(22, [("(A) Watches, meals and work are organized around the ship's time, so a large jump", "(A) He moves it so little because watches, meals and work are organized around the ship's time, and a large jump"),
         ('(C) Passengers rarely notice, which is the point', '(C) Passengers rarely notice either, which is the point')],
        [('(A) 당직, 식사, 작업은 배의 시각에 맞추어 짜여 있어서, 한꺼번에 크게 바꾸면 모든 것이 동시에 흐트러진다.', '(A) 그가 그렇게 조금씩만 옮기는 까닭은, 당직, 식사, 작업이 배의 시각에 맞추어 짜여 있어서 한꺼번에 크게 바꾸면 모든 것이 동시에 흐트러지기 때문이다.'),
         ('(C) 승객들은 좀처럼 알아채지 못하는데,', '(C) 승객들 또한 좀처럼 알아채지 못하는데,')])
