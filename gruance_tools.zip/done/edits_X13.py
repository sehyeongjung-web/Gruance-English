# -*- coding: utf-8 -*-
# 266번: 36-37번(글의 순서) 레벨5 — 검토해서 탈이 있는 문항만 바로잡음(30문항을 다 읽고 여덟 문항을 고침 + 두 문항은 해석만)
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새 지문에 맞게 다시 씀(레벨6~9와 같은 꼴). 정답·선택지 변동 없음. z3common.py가 같은 폴더에 있어야 함
# 탈: 여덟 문항 모두 「다른 순서로도 읽힘」 — 가리키는 말 하나씩으로 막음(해석도 함께)
#   7번째 (A) 'showed that the park emptied' → 'showed otherwise: the park emptied' ((A)-(C)-(B)를 막음). 주어진 글 'was empty' → 'was little used'(네 시에 빈다는 말과 맞춤)
#   8번째 (A) 'That is why' → 'That guess is why' ((A)-(C)-(B)를 막음)
#   10번째 (C) 'That is why' → 'That stretching is why' ((B)-(C)-(A)를 막음). (B) 'Yeast feeds' → 'Yeast that is kept warm feeds'(따뜻한 곳·차가운 곳의 까닭)
#   12번째 (A) 'A walk round the site showed that' → 'That assumption proved wrong after a walk round the site:' ((A)-(C)-(B)를 막음)
#   18번째 (B) 앞에 'To ease that guilt,' ((B)-(C)-(A)·(B)-(A)-(C)를 막음)
#   20번째 (C) 'above eye level' → 'at the top row' ((C)-(A)-(B)를 막음)
#   22번째 (B) 'Staff … found that most families arriving had already bought' → 'Yet staff … found that most families arriving had never seen that price: they had already bought' ((B)-(C)-(A)를 막음)
#   27번째 (A) → 'That was the aim, since the path had been built to protect the ground either side of it.' ((C)-(A)-(B)를 막음), (C)에 'however', (B) 'at the near end' → 'facing that shore'
# 해석만: 3번째(before each test — 「시험마다」 → 「각 시험 전에 하는」) · 5번째(mainly가 꾸미는 자리)
AUTO_SYNC = False
E = {}
from z3common import maker
mk = maker(E, lv='5')
def fix(n, text, ko):
    E[('36_37', '5', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 해석만 고친 두 문항 (지문·풀이·해설은 그대로) ----------
E[('36_37', '5', 2)] = {'ko': ('그 학교는 그다음 시험마다 짧은 호흡 운동을 도입했고', '그 학교는 그다음 각 시험 전에 하는 짧은 호흡 운동을 도입했고')}
E[('36_37', '5', 4)] = {'ko': ('첫해에 그녀는 사람들이 이야기하는 것을 듣기 위해 주로 매주 무료 저녁 수업에 나갔다.', '첫해에 그녀는 주로 사람들이 이야기하는 것을 들으려고 매주 무료 저녁 수업에 나갔다.')}

# ---------- 7번째: 겨울 공원이 비는 까닭은 추위가 아니라 빛 ----------
mk(6, 'CAB', [
 "1) 주어진 글: 강가의 공원이 길을 치워 두는데도 겨울마다 이용이 적었습니다. 왜 그런지, 사람들이 그 까닭을 어떻게 여겼는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «The council had assumed that people simply preferred to stay indoors in cold weather.»(지자체는 사람들이 추운 날씨에는 그저 실내에 있기를 선호한다고 여겨 왔다.) 'had assumed'(여겨 왔다)는 실제로 알아보기 전의 짐작입니다. 주어진 글의 물음에 먼저 나온 답입니다.",
 "3) 둘째 글 (A): «Counts taken over two winters showed otherwise»(두 번의 겨울에 걸쳐 센 집계는 그렇지 않음을 보여주었다). otherwise(그렇지 않음)는 앞에 나온 생각과 다르다는 말입니다. 그 생각이 (C)의 짐작입니다. 공원은 추워서가 아니라 빛이 사라지는 네 시에 비었습니다.",
 "4) 셋째 글 (B)와 확인: «Lamps were fitted along the main path»(주요 길을 따라 등이 달렸다). 빛이 문제였으니 등을 답니다. (A)의 'when the light went'(빛이 사라질 때)를 받는 해결책입니다. 짐작 → 실제 → 해결로 맞물리므로 순서는 (C)-(A)-(B)입니다."],
 "(A)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 이용이 적다는 말 뒤에 세어 본 결과가 바로 이어질 것 같기 때문입니다. 하지만 (A)의 otherwise(그렇지 않음)는 뒤집을 생각이 앞에 있어야 쓸 수 있습니다. 주어진 글에는 사실만 있고 누구의 생각도 없습니다. 그 생각은 (C)에 있습니다.",
 {'ACB': "(A)의 otherwise(그렇지 않음)가 뒤집을 생각이 주어진 글에 없습니다. 지자체의 짐작은 (C)에 있으므로 (C)가 (A)보다 먼저 와야 합니다.",
  'BAC': "(B)에서 등을 다는 것은 빛이 문제라는 것을 안 뒤의 일입니다. 주어진 글에는 아직 까닭이 나오지 않았으므로 (B)가 맨 앞에 올 수 없습니다.",
  'BCA': "(B)에서 등을 달아 이용이 늘어난 뒤에, 추워서 안 온다는 짐작과 세어 본 결과가 나옵니다. 해결이 까닭보다 먼저 나와 차례가 거꾸로입니다.",
  'CAB': "주어진 글의 물음에 (C)가 지자체의 짐작을 말하고, (A)의 otherwise가 그 짐작을 뒤집어 빛이 까닭임을 밝히고, (B)가 등을 달아 해결합니다.",
  'CBA': "(C)로 시작하는 것은 맞습니다. 하지만 (B)의 등이 (A)보다 먼저 나옵니다. 빛이 까닭이라는 것을 (A)에서 알아낸 뒤에야 등을 달 까닭이 생깁니다."})
fix(6, [('was empty every winter', 'was little used every winter'),
        ("showed that the park emptied at four o'clock", "showed otherwise: the park emptied at four o'clock")],
       [('겨울마다 비어 있었다', '겨울마다 이용이 적었다'),
        ('(A) 두 번의 겨울에 걸쳐 센 집계는 그 공원이 빛이 사라지는 네 시에 빈다는 것을 보여주었다.', '(A) 두 번의 겨울에 걸쳐 센 집계는 그렇지 않음을 보여주었다. 그 공원은 빛이 사라지는 네 시에 비었던 것이다.')])

# ---------- 8번째: 보이는 것이 맛을 바꾼다 ----------
mk(7, 'CBA', [
 "1) 주어진 글: 음식이 어떻게 보이는지가 맛을 바꾼다고 합니다. 정말 그런지를 보여 주는 본보기가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «In one experiment, people were given the same juice in three glasses, each colored differently»(한 실험에서 사람들은 색깔이 각기 다른 세 잔에 담긴 똑같은 주스를 받았다). 주어진 글의 말을 실험으로 보여 줍니다. 똑같은 주스인데도 대부분이 주황색 잔의 것이 더 달다고 했습니다.",
 "3) 둘째 글 (B): «This shows that the eyes send information to the brain before the tongue does»(이것은 혀보다 눈이 먼저 뇌에 정보를 보낸다는 것을 보여 준다). This(이것)가 (C)의 실험 결과를 받습니다. 뇌는 눈이 보낸 정보로 'a guess'(짐작)를 합니다.",
 "4) 셋째 글 (A)와 확인: «That guess is why restaurants think carefully about the color of plates and lights»(그 짐작 때문에 식당은 접시와 조명의 색을 신중하게 생각한다). 'That guess'(그 짐작)가 (B)의 'a guess'를 받습니다. 실험 → 실험이 보여 주는 것 → 그래서 식당은으로 맞물리므로 순서는 (C)-(B)-(A)입니다."],
 "(A)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 「보이는 것이 맛을 바꾼다, 그래서 식당은 색에 신경 쓴다」로 바로 이어질 것 같기 때문입니다. 하지만 (A)는 'That guess'(그 짐작)로 시작합니다. 짐작이라는 말은 주어진 글에 없고 (B)의 끝에 있습니다. 그러니 (B)가 (A) 바로 앞에 와야 합니다.",
 {'ACB': "(A)의 'That guess'(그 짐작)가 가리킬 것이 주어진 글에 없습니다. 짐작은 (B)에서 처음 나오므로 (A)가 맨 앞에 올 수 없습니다.",
  'BAC': "(B)의 This(이것)가 가리킬 실험 결과가 주어진 글에 없습니다. 무엇이 그것을 보여 주는지가 먼저 나와야 하므로 (C)가 (B)보다 앞에 와야 합니다.",
  'BCA': "(B)의 This(이것)가 가리킬 것이 앞에 없습니다. 또 (A)의 'That guess'가 (B)의 짐작에서 떨어져 (C)의 실험 뒤에 오게 됩니다.",
  'CAB': "(C)로 시작하는 것은 맞습니다. 하지만 (A)의 'That guess'(그 짐작)가 (B)의 'a guess'보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다.",
  'CBA': "주어진 글의 말을 (C)가 실험으로 보여 주고, (B)의 This가 그 결과를 받아 뇌가 눈의 정보로 짐작을 한다고 풀이하고, (A)의 'That guess'가 그 짐작을 받아 식당 이야기로 맺습니다."})
fix(7, ('(A) That is why restaurants', '(A) That guess is why restaurants'),
       ('(A) 그래서 식당은', '(A) 그 짐작 때문에 식당은'))

# ---------- 10번째: 효모의 방울이 반죽을 늘린다 ----------
mk(9, 'BAC', [
 "1) 주어진 글: 빵이 부푸는 것은 효모라는 아주 작은 생물 때문이라고 합니다. 효모가 무엇을 하기에 빵이 부푸는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (B): «Yeast that is kept warm feeds on the sugar in the dough and, as it does so, gives off bubbles of gas.»(따뜻하게 둔 효모는 반죽 속의 당분을 먹고, 그러면서 기체 방울을 내놓는다.) 주어진 글의 효모를 바로 받아 하는 일을 말합니다. 'bubbles of gas'(기체 방울)가 처음 나옵니다.",
 "3) 둘째 글 (A): «These bubbles are trapped inside the sticky dough, which stretches around them like a balloon.»(이 방울들은 끈적한 반죽 속에 갇히고, 반죽은 풍선처럼 그 둘레로 늘어난다.) 'These bubbles'(이 방울들)가 (B)의 방울을 받습니다. 반죽이 stretches(늘어난다)고 합니다.",
 "4) 셋째 글 (C)와 확인: «That stretching is why dough left in a warm place doubles in size»(그렇게 늘어나기 때문에 따뜻한 곳에 둔 반죽은 크기가 두 배가 된다). 'That stretching'(그 늘어남)이 (A)의 stretches를 받습니다. 방울이 생김 → 방울이 갇혀 반죽이 늘어남 → 그래서 반죽이 커짐으로 맞물리므로 순서는 (B)-(A)-(C)입니다."],
 "(B) 바로 뒤에 (C)를 놓고 싶어질 수 있습니다. 「기체 방울을 내놓는다, 그래서 반죽이 두 배가 된다」로 이어질 것 같기 때문입니다. 하지만 (C)는 'That stretching'(그 늘어남)으로 시작합니다. 늘어난다는 말은 (A)에 있습니다. 그러니 (A)가 (C) 바로 앞에 와야 합니다. (A)의 'These bubbles'도 (B)의 방울 바로 뒤에 붙어야 합니다.",
 {'ACB': "(A)의 'These bubbles'(이 방울들)가 가리킬 것이 주어진 글에 없습니다. 방울은 (B)에서 처음 나오므로 (A)가 맨 앞에 올 수 없습니다.",
  'BAC': "주어진 글의 효모를 (B)가 받아 기체 방울을 내놓는다고 하고, (A)의 'These bubbles'가 그 방울을 받아 반죽이 늘어난다고 하고, (C)의 'That stretching'이 그 늘어남을 받아 반죽이 커지는 까닭으로 맺습니다.",
  'BCA': "(B)로 시작하는 것은 맞습니다. 하지만 (C)의 'That stretching'(그 늘어남)이 (A)의 stretches보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다.",
  'CAB': "(C)의 'That stretching'이 가리킬 것이 주어진 글에 없습니다. 늘어난다는 말은 (A)에, 방울은 (B)에 있으므로 (C)는 맨 끝에 와야 합니다.",
  'CBA': "(C)의 'That stretching'이 가리킬 것이 앞에 없습니다. 또 (A)가 맨 끝에 오면, 반죽이 커진 까닭까지 말한 뒤에 방울이 갇히는 이야기로 되돌아갑니다."})
fix(9, [('(B) Yeast feeds on the sugar', '(B) Yeast that is kept warm feeds on the sugar'),
        ('(C) That is why dough left', '(C) That stretching is why dough left')],
       [('(B) 효모는 반죽 속의', '(B) 따뜻하게 둔 효모는 반죽 속의'),
        ('(C) 그래서 따뜻한 곳에 둔 반죽은', '(C) 그렇게 늘어나기 때문에 따뜻한 곳에 둔 반죽은')])

# ---------- 12번째: 땅이 모자란 것이 아니라 안 쓰는 땅이 묶여 있었다 ----------
mk(11, 'BAC', [
 "1) 주어진 글: 한 텃밭 단지에 기다리는 사람이 아흔 명인데, 구획의 3분의 1은 묵어 있습니다. 기다리는 사람이 왜 그렇게 많은지, 운영하는 쪽이 그것을 어떻게 여겼는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (B): «The committee had assumed that demand simply exceeded the space available.»(운영위원회는 수요가 그저 쓸 수 있는 공간을 넘어선다고 여겨 왔다.) 'had assumed'(여겨 왔다)는 실제로 알아보기 전의 짐작입니다. 주어진 글의 물음에 먼저 나온 답입니다.",
 "3) 둘째 글 (A): «That assumption proved wrong after a walk round the site»(그 짐작은 단지를 한 바퀴 돌아보자 틀린 것으로 드러났다). 'That assumption'(그 짐작)이 (B)의 짐작을 받습니다. 묵은 구획의 대부분은 2년 동안 오지 않은 보유자의 것이었습니다. 땅이 모자란 것이 아니라 안 쓰는 땅이 묶여 있었습니다.",
 "4) 셋째 글 (C)와 확인: «The rules were changed so that an unworked plot was reassigned after one season»(한 철 동안 가꾸지 않은 구획은 재배정되도록 규칙이 바뀌었다). 안 쓰는 땅이 문제였으니 그 땅을 다시 나누어 줍니다. 그러자 'the list'(그 명단)가 반으로 줄었습니다. 짐작 → 실제 → 해결로 맞물리므로 순서는 (B)-(A)-(C)입니다."],
 "(A)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 묵은 구획 이야기가 주어진 글에 나왔으니 그것을 돌아본 이야기가 바로 이어질 것 같기 때문입니다. 하지만 (A)는 'That assumption'(그 짐작)으로 시작합니다. 주어진 글에는 사실만 있고 누구의 짐작도 없습니다. 짐작은 (B)에 있습니다.",
 {'ACB': "(A)의 'That assumption'(그 짐작)이 가리킬 것이 주어진 글에 없습니다. 운영위원회의 짐작은 (B)에 있으므로 (B)가 (A)보다 먼저 와야 합니다.",
  'BAC': "주어진 글의 물음에 (B)가 운영위원회의 짐작을 말하고, (A)의 'That assumption'이 그 짐작이 틀렸음을 밝히고, (C)가 규칙을 바꾸어 해결합니다.",
  'BCA': "(B)로 시작하는 것은 맞습니다. 하지만 (C)의 규칙 바꾸기가 (A)보다 먼저 나옵니다. 묵은 구획이 오지 않는 보유자의 것임을 (A)에서 알아낸 뒤에야 규칙을 바꿀 까닭이 생깁니다.",
  'CAB': "(C)에서 규칙을 바꾸는 것은 까닭을 안 뒤의 일입니다. 주어진 글에는 아직 까닭이 나오지 않았으므로 (C)가 맨 앞에 올 수 없습니다.",
  'CBA': "(C)에서 규칙을 바꾸어 명단이 줄어든 뒤에, 땅이 모자란다는 짐작과 돌아본 결과가 나옵니다. 해결이 까닭보다 먼저 나와 차례가 거꾸로입니다."})
fix(11, ('(A) A walk round the site showed that most of the overgrown plots', '(A) That assumption proved wrong after a walk round the site: most of the overgrown plots'),
        [('(A) 그 단지를 한 바퀴 돌아보니 묵은 구획의 대부분이', '(A) 그 짐작은 단지를 한 바퀴 돌아보자 틀린 것으로 드러났다. 묵은 구획의 대부분이'),
         ('재배정된다는 규칙이 생겼고', '재배정되도록 규칙이 바뀌었고')])

# ---------- 18번째: 관리자가 먼저 쉬어야 직원이 쉰다 ----------
mk(17, 'CBA', [
 "1) 주어진 글: 직원이 휴가를 더 쓰기를 바란 회사가, 휴가 일수를 넉넉히 주는데도 쓰지 않은 날이 해마다 쌓이는 것을 발견했습니다. 왜 안 쓰는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «Employees reported that they felt guilty leaving their teams short-handed.»(직원들은 자기 팀을 일손이 모자라게 두고 떠나는 것에 죄책감을 느낀다고 보고했다.) 주어진 글의 물음에 대한 답입니다. 휴가를 안 쓰는 까닭은 죄책감입니다.",
 "3) 둘째 글 (B): «To ease that guilt, the company began requiring managers to take their own vacations first»(그 죄책감을 덜어 주려고 그 회사는 관리자가 먼저 자기 휴가를 쓰도록 요구하기 시작했다). 'that guilt'(그 죄책감)가 (C)의 'felt guilty'를 받습니다. 까닭을 알았으니 해결책을 냅니다.",
 "4) 셋째 글 (A)와 확인: «Once employees saw their managers leave, they felt free to do the same.»(직원들은 자기 관리자가 떠나는 것을 보고 나자 똑같이 해도 된다고 느꼈다.) 관리자가 먼저 휴가를 간 (B) 뒤의 결과입니다. 까닭 → 해결책 → 결과로 맞물리므로 순서는 (C)-(B)-(A)입니다."],
 "(B)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 문제가 나왔으니 회사가 한 일이 바로 이어질 것 같기 때문입니다. 하지만 (B)는 'that guilt'(그 죄책감)를 덜어 주려고 한 일입니다. 죄책감이라는 말은 주어진 글에 없고 (C)에 있습니다. 그러니 (C)가 (B) 앞에 와야 합니다.",
 {'ACB': "(A)에서 직원이 관리자가 떠나는 것을 보는 것은, 관리자에게 먼저 휴가를 쓰게 한 (B) 뒤의 일입니다. 주어진 글 바로 뒤에 올 수 없습니다.",
  'BAC': "(B)의 'that guilt'(그 죄책감)가 가리킬 것이 주어진 글에 없습니다. 죄책감은 (C)에서 처음 나오므로 (C)가 (B)보다 먼저 와야 합니다.",
  'BCA': "(B)의 'that guilt'가 (C)의 'felt guilty'보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다.",
  'CAB': "(C)로 시작하는 것은 맞습니다. 하지만 (A)에서 관리자가 떠나는 것을 본 뒤에 (B)에서 관리자에게 휴가를 쓰게 합니다. 결과가 해결책보다 먼저 나와 차례가 거꾸로입니다.",
  'CBA': "주어진 글의 물음에 (C)가 죄책감이라는 까닭을 대고, (B)의 'that guilt'가 그것을 받아 관리자가 먼저 휴가를 쓰게 하고, (A)가 그것을 본 직원들이 마음 놓고 쉬게 되었다고 맺습니다."})
fix(17, ('(B) The company began requiring managers', '(B) To ease that guilt, the company began requiring managers'),
        ('(B) 그 회사는 관리자가', '(B) 그 죄책감을 덜어 주려고 그 회사는 관리자가'))

# ---------- 20번째: 세 줄로 건 그림, 아무도 보지 않는 맨 윗줄 ----------
mk(19, 'ACB', [
 "1) 주어진 글: 한 시립 미술관이, 관람객이 주 전시실을 4분도 안 되어 지나간다는 것을 발견했습니다. 그 방이 어떤 방인지, 왜 그렇게 빨리 지나가는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (A): «The room held forty works hung in three rows, which was how the collection had always been shown.»(그 방은 세 줄로 건 마흔 점을 두고 있었는데, 그것이 그 소장품을 늘 보여 온 방식이었다.) 'The room'(그 방)이 주어진 글의 주 전시실을 받습니다. 'three rows'(세 줄)가 처음 나옵니다.",
 "3) 둘째 글 (C): «A curator counted where people stopped and found that nobody looked at the top row at all.»(한 큐레이터가 사람들이 어디서 멈추는지 세어 보고 아무도 맨 윗줄을 전혀 보지 않는다는 것을 발견했다.) 'the top row'(맨 윗줄)는 줄이 여럿이라는 말이 앞에 있어야 쓸 수 있습니다. (A)의 세 줄 가운데 맨 위입니다.",
 "4) 셋째 글 (B)와 확인: «The hang was reduced to twelve works in a single row»(그 전시가 한 줄에 열두 점으로 줄었다). 윗줄을 아무도 안 보니 한 줄로 줄였습니다. (A)의 마흔 점·세 줄과 맞서는 열두 점·한 줄입니다. 그 방의 모습 → 알아낸 것 → 고친 것으로 맞물리므로 순서는 (A)-(C)-(B)입니다."],
 "(C)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 빨리 지나간다는 것을 알았으니 큐레이터가 세어 본 이야기가 바로 이어질 것 같기 때문입니다. 하지만 (C)의 'the top row'(맨 윗줄)는 그림을 여러 줄로 걸었다는 말이 먼저 나와야 알 수 있습니다. 그 말은 (A)에 있습니다.",
 {'ACB': "주어진 글의 주 전시실을 (A)의 'The room'이 받아 세 줄로 건 마흔 점을 말하고, (C)의 'the top row'가 그 줄 가운데 맨 위를 받아 아무도 보지 않는다고 하고, (B)가 한 줄로 줄여 해결합니다.",
  'BAC': "(B)에서 전시를 한 줄로 줄이는 것은 까닭을 안 뒤의 일입니다. 주어진 글에는 그림을 어떻게 걸었는지도, 무엇이 문제인지도 아직 나오지 않았습니다.",
  'BCA': "(B)에서 한 줄로 줄인 뒤에 (C)에서 맨 윗줄을 안 본다고 하면 맞지 않습니다. 한 줄에는 윗줄이 없습니다. 해결이 까닭보다 먼저 나와 차례가 거꾸로입니다.",
  'CAB': "(C)의 'the top row'(맨 윗줄)가 (A)의 'three rows'보다 먼저 나옵니다. 줄이 여럿이라는 말이 나오기 전에 맨 윗줄이라고 할 수 없습니다.",
  'CBA': "(C)의 'the top row'가 가리킬 줄이 앞에 없습니다. 또 (A)가 맨 끝에 오면, 한 줄로 줄인 뒤에 세 줄로 걸려 있었다는 말이 나옵니다."})
fix(19, ('found that nobody looked above eye level at all', 'found that nobody looked at the top row at all'),
        ('아무도 눈높이 위를 보지 않는다는 것을 발견했다', '아무도 맨 윗줄을 전혀 보지 않는다는 것을 발견했다'))

# ---------- 22번째: 값은 잘 매겼지만 그 값을 본 사람이 없었다 ----------
mk(21, 'CBA', [
 "1) 주어진 글: 한 수족관이 가족권을 내놓았는데 찾아오는 가족 수에 아무 변화가 없었습니다. 왜 변화가 없었는지가 다음에 나와야 합니다. 먼저 떠오르는 것은 값입니다.",
 "2) 첫째 글 (C): «The ticket had been priced carefully against what other attractions in the region charged.»(그 표는 그 지역의 다른 명소가 받는 값에 맞춰 꼼꼼히 가격이 매겨져 있었다.) 'The ticket'(그 표)이 주어진 글의 가족권을 받습니다. 값은 잘 매겼으니 값 탓은 아니라는 말입니다.",
 "3) 둘째 글 (B): «Yet staff at the door found that most families arriving had never seen that price»(그런데 입구의 직원들은 도착하는 가족 대부분이 그 가격을 본 적도 없다는 것을 알게 되었다). Yet(그런데)과 'that price'(그 가격)가 (C)를 받습니다. 값을 잘 매겼지만 그 값을 본 사람이 없었습니다. 온라인에는 가족 선택지가 보이지 않았기 때문입니다.",
 "4) 셋째 글 (A)와 확인: «The website was rebuilt so that the family price appeared first»(그 웹사이트가 가족 가격이 먼저 나오도록 다시 만들어졌다). 'The website'(그 웹사이트)가 (B)의 online(온라인)을 받습니다. 보이지 않던 것을 맨 먼저 보이게 고쳤습니다. 값은 문제없음 → 진짜 까닭 → 해결로 맞물리므로 순서는 (C)-(B)-(A)입니다."],
 "(B)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 변화가 없었다는 말 뒤에 직원들이 알아낸 까닭이 바로 이어질 것 같기 때문입니다. 하지만 (B)는 Yet(그런데)으로 시작하고 'that price'(그 가격)를 말합니다. 값 이야기가 먼저 나와야 「그런데 그 값을 본 사람이 없었다」로 뒤집을 수 있습니다. 값 이야기는 (C)에 있습니다.",
 {'ACB': "(A)에서 웹사이트를 고치는 것은 온라인에 가족권이 보이지 않는다는 것을 안 뒤의 일입니다. 주어진 글에는 아직 까닭이 나오지 않았으므로 (A)가 맨 앞에 올 수 없습니다.",
  'BAC': "(B)의 'that price'(그 가격)가 가리킬 것이 주어진 글에 없습니다. 값 이야기는 (C)에 있습니다. 또 (C)가 맨 끝에 오면, 다 해결한 뒤에 값을 잘 매겼다는 말이 나옵니다.",
  'BCA': "(B)의 'that price'가 (C)의 값 이야기보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다. Yet(그런데)이 뒤집을 말도 앞에 없습니다.",
  'CAB': "(C)로 시작하는 것은 맞습니다. 하지만 (A)에서 웹사이트를 고친 뒤에 (B)에서 그 가격을 본 사람이 없다고 하면 차례가 거꾸로입니다. 해결이 까닭보다 먼저 나옵니다.",
  'CBA': "주어진 글의 가족권을 (C)의 'The ticket'이 받아 값은 잘 매겼다고 하고, (B)의 'that price'가 그 값을 받아 아무도 그것을 보지 못했다고 하고, (A)가 웹사이트를 고쳐 해결합니다."})
fix(21, ('(B) Staff at the door found that most families arriving had already bought separate tickets online,', '(B) Yet staff at the door found that most families arriving had never seen that price: they had already bought separate tickets online,'),
        [('(B) 문의 직원들은 도착하는 가족 대부분이 이미 온라인에서 따로 표를 샀다는 것을 알게 되었는데,', '(B) 그런데 입구의 직원들은 도착하는 가족 대부분이 그 가격을 본 적도 없다는 것을 알게 되었다. 그들은 이미 온라인에서 따로 표를 샀는데,'),
         ('다시 지어졌고', '다시 만들어졌고')])

# ---------- 27번째: 길은 땅을 지켰지만 길에서는 새가 보이지 않았다 ----------
mk(26, 'ACB', [
 "1) 주어진 글: 한 자연 보호구역이 호수 둘레에 자갈길을 놓았더니, 방문객이 그 길 위에만 머물렀습니다. 그것이 바라던 일인지 아닌지가 다음에 나와야 합니다.",
 "2) 첫째 글 (A): «That was the aim, since the path had been built to protect the ground either side of it.»(그것이 바로 목표였는데, 그 길은 그 양옆의 땅을 보호하려고 지어졌기 때문이다.) That(그것)이 주어진 글의 「방문객이 길 위에 머문 것」을 받습니다. 여기까지는 바라던 대로입니다.",
 "3) 둘째 글 (C): «Wardens noticed, however, that the birds people came to see were on the far shore, out of sight from the path.»(그러나 관리인들은 사람들이 보러 온 그 새들이 그 길에서 보이지 않는 먼 쪽 기슭에 있다는 것을 알아차렸다.) however(그러나)가 (A)의 「바라던 대로」를 뒤집습니다. 길은 땅을 지켰지만, 길에서는 새가 보이지 않았습니다.",
 "4) 셋째 글 (B)와 확인: «A screened hide was built facing that shore»(그 기슭을 마주 보는 가림막 친 관찰대가 지어졌다). 'that shore'(그 기슭)가 (C)의 'the far shore'(먼 쪽 기슭)를 받습니다. 새를 볼 수 있게 되자 머무는 시간이 20분에서 한 시간 넘게로 늘었습니다. 바라던 일 → 뜻밖의 문제 → 해결로 맞물리므로 순서는 (A)-(C)-(B)입니다."],
 "(C)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 방문객이 길 위에만 머문다는 말 뒤에 관리인들이 알아차린 문제가 바로 이어질 것 같기 때문입니다. 하지만 그렇게 하면 (A)의 That(그것)이 가리키는 것이 달라집니다. 「새가 보이지 않는 것」이 목표였다는 이상한 말이 됩니다. That은 주어진 글의 「길 위에 머문 것」을 바로 받아야 합니다.",
 {'ACB': "주어진 글의 「길 위에 머문 것」을 (A)의 That이 받아 그것이 목표였다고 하고, (C)의 however가 그런데 새가 보이지 않았다고 뒤집고, (B)의 'that shore'가 (C)의 기슭을 받아 관찰대로 해결합니다.",
  'BAC': "(B)의 'that shore'(그 기슭)가 가리킬 것이 주어진 글에 없습니다. 기슭은 (C)에서 처음 나옵니다. 문제가 나오기도 전에 해결이 올 수 없습니다.",
  'BCA': "(B)의 'that shore'가 (C)의 'the far shore'보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다.",
  'CAB': "(C) 뒤에 (A)가 오면 (A)의 That(그것)이 「새가 보이지 않는 것」을 가리키게 됩니다. 그것이 목표였다는 말은 맞지 않습니다. (A)는 주어진 글 바로 뒤에 와야 합니다.",
  'CBA': "(C)와 (B)가 이어지는 것은 맞습니다. 하지만 (A)가 맨 끝에 오면, That(그것)이 「머무는 시간이 늘어난 것」을 가리키게 되어 땅을 보호하려고 길을 지었다는 까닭과 맞지 않습니다."})
fix(26, [('(A) The path had been built to protect the ground either side of it, which it did.', '(A) That was the aim, since the path had been built to protect the ground either side of it.'),
         ('(B) A screened hide was built at the near end,', '(B) A screened hide was built facing that shore,'),
         ('(C) Wardens noticed that the birds', '(C) Wardens noticed, however, that the birds')],
        [('(A) 그 길은 그 양옆의 땅을 보호하려고 지어졌고, 실제로 그렇게 했다.', '(A) 그것이 바로 목표였는데, 그 길은 그 양옆의 땅을 보호하려고 지어졌기 때문이다.'),
         ('(B) 가까운 쪽 끝에 가림막을 친 관찰대가 지어졌고,', '(B) 그 기슭을 마주 보는 가림막 친 관찰대가 지어졌고,'),
         ('(C) 관리인들은 사람들이', '(C) 그러나 관리인들은 사람들이')])
