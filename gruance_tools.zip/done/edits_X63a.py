# -*- coding: utf-8 -*-
# 335번: 21번(함축 의미) 레벨1 앞 절반 — 다섯 문장 · 문장당 10~15낱말 · 단문 · 밑줄은 둘째~다섯째 문장. 정답 번호는 바탕 그대로, 지문·선택지·해석·풀이·해설을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z21common import maker
rw = maker(E, '1')

# 1번째 (정답 ①)
rw(0, 'Mina has practiced the piano every day for ten weeks. She cannot hear any change in her own playing yet. To her teacher, those weeks are <u>the seed under the soil</u>. Mina feels a little sad and tired after so much work. Her teacher tells her to keep playing every single day.',
   ['progress that is still hidden', 'a change that anyone can measure', 'a seed buried too deep', 'a talent that she does not have', 'ten weeks of work that were wasted'],
   '미나는 열 주 동안 매일 피아노를 연습해 왔다. 그녀는 자신의 연주에서 아직 아무 변화도 들을 수 없다. 선생님에게 그 몇 주는 「흙 속의 씨앗」이다. 미나는 그렇게 많이 노력한 뒤라 조금 슬프고 지친다. 선생님은 그녀에게 하루도 빠짐없이 계속 연주하라고 말한다.',
   ["1) 밑줄 친 'the seed under the soil'(흙 속의 씨앗)은 진짜 씨앗이 아니라 비유예요. «those weeks are»(그 몇 주는 ~이다) 바로 뒤에 나오니, 미나가 연습한 열 주를 가리켜요.",
 "2) 단서를 찾아요. «She cannot hear any change in her own playing yet.»(그녀는 자신의 연주에서 아직 아무 변화도 들을 수 없다.) 'yet'(아직)은 「지금은 아니지만 앞으로는」이라는 느낌을 줘요. 마지막 문장에서 선생님은 «keep playing every single day»(하루도 빠짐없이 계속 "
 '연주하라)고 해요.',
 '3) 씨앗은 흙 속에 있어서 눈에 보이지 않지만 자라고 있어요. 열 주의 연습도 아직 소리로는 안 나타나지만 속에서 쌓이고 있다고 볼 수 있어요.',
 "4) 그러니까 밑줄 친 'the seed under the soil'의 뜻은 'progress that is still hidden'(아직 보이지 않는 발전)이에요."],
   "'a seed buried too deep'(너무 깊이 묻힌 씨앗)을 고르고 싶어질 수 있어요. 밑줄 친 말의 낱말을 그대로 따온 보기라서 눈에 띄거든요. 하지만 밑줄 친 말은 비유이고, 씨앗을 너무 깊이 묻었다는 말은 글에 없어요. 'ten weeks of work that were wasted'(헛수고가 된 열 주)도 미나가 지친 모습 때문에 끌릴 수 있어요. 하지만 선생님이 계속 연주하라고 하니 헛수고로 보지 않는다는 걸 알 수 있어요.",
   ['변화가 아직 안 들려도 연습은 속에서 쌓이고 있다고 읽을 수 있어요. 씨앗이 흙 속에서 자라는 것과 닮았어요.',
 '글은 «She cannot hear any change in her own playing yet.»(그녀는 자신의 연주에서 아직 아무 변화도 들을 수 없다.)라고 해요. 눈에 띄는 변화가 없는 상황이라서 누구나 잴 수 있는 변화와 맞지 않아요.',
 '밑줄 친 말의 낱말만 따온 보기예요. 씨앗을 너무 깊이 묻었다는 말은 글에 없어요.',
 '재능이 없다는 말은 글에 없어요. 선생님은 계속 연주하라고 해요.',
 '미나는 지쳤지만, 선생님은 하루도 빠짐없이 계속 연주하라고 해요. 헛수고라면 계속하라고 하지 않을 거예요.'],
   ['아직 보이지 않는 발전', '누구나 잴 수 있는 변화', '너무 깊이 묻힌 씨앗', '그녀에게 없는 재능', '헛수고가 된 열 주의 노력'],
   'practice 연습하다 / seed 씨앗 / soil 흙 / measure 재다')

# 2번째 (정답 ③)
rw(1, 'Grandma keeps one old red cookbook on the kitchen table. Oil stains and bent corners mark many pages of the book. She opens it almost every single day for dinner ideas. To our family, that cookbook is <u>the book with the broken back</u>. Nobody in the house wants to buy a new one.',
   ['a book Grandma just bought', 'a recipe that is hard to follow', 'a thing used again and again', 'a thing that has lost its worth', 'a book that stays unopened'],
   '할머니는 낡은 빨간 요리책 한 권을 부엌 식탁 위에 둔다. 기름 얼룩과 접힌 모서리가 그 책의 많은 쪽에 나 있다. 할머니는 저녁 메뉴를 찾으려고 거의 매일 그 책을 편다. 우리 가족에게 그 요리책은 「등이 부러진 책」이다. 집에서는 아무도 새 책을 사고 싶어 하지 않는다.',
   ["1) 밑줄 친 'the book with the broken back'(등이 부러진 책)은 «that cookbook»(그 요리책)을 가리키는 비유예요. 책이 어떤 모습인지 앞뒤 문장에서 찾아요.",
 '2) 단서를 찾아요. «Oil stains and bent corners mark many pages of the book.»(기름 얼룩과 접힌 모서리가 그 책의 많은 쪽에 나 있다.) 또 «She opens it almost every single day for dinner ideas.»(할머니는 저녁 메뉴를 찾으려고 거의 매일 그 책을 '
 '편다.)라고 해요.',
 "3) 'broken back'은 책의 등 부분이 망가진 모습이에요. 기름 얼룩과 접힌 모서리처럼 많이 쓴 흔적이에요. 그래도 마지막 문장은 «Nobody in the house wants to buy a new one.»(집에서는 아무도 새 책을 사고 싶어 하지 않는다.)라고 해요. 낡았어도 계속 쓰는 책이에요.",
 "4) 그러니까 밑줄 친 'the book with the broken back'의 뜻은 'a thing used again and again'(되풀이해서 쓰는 것)이에요."],
   "'a thing that has lost its worth'(가치를 잃은 것)를 고르고 싶어질 수 있어요. 'broken'(부러진)만 보면 쓸모없게 된 책처럼 읽히거든요. 하지만 할머니는 거의 매일 그 책을 펴고, 아무도 새 책을 사고 싶어 하지 않아요. 가치를 잃은 책이 아니라 많이 써서 낡은 책이에요.",
   ['첫 문장에 «old red cookbook»(낡은 빨간 요리책)이라고 나와요. 새로 산 책이 아니에요.',
 '요리법이 어렵다는 말은 글에 없어요.',
 '기름 얼룩과 접힌 모서리가 많은 쪽에 나 있고, 할머니는 거의 매일 책을 펴요. 많이 써서 낡은 책이라는 뜻이에요.',
 "'broken'(부러진)만 보면 끌리지만, 할머니는 거의 매일 책을 펴고 새 책도 원하지 않아요.",
 '할머니는 «almost every single day»(거의 매일) 책을 펴요. 반대예요.'],
   ['할머니가 막 산 책', '따라 하기 어려운 요리법', '되풀이해서 쓰는 것', '가치를 잃은 것', '펴지 않은 채 그대로인 책'],
   'cookbook 요리책 / stain 얼룩 / corner 모서리 / back (책의) 등 / idea 생각')

# 3번째 (정답 ④)
rw(2, 'My father comes home from work very late every night. He never says one word about his feelings for us. Still, he leaves the small light in the hall on. Its warm glow always meets me at the front door. To me, that glow is <u>a hug without a sound</u>.',
   ['a light he forgets to turn off', 'a promise to come home much earlier', 'a sign of anger at the family', 'love that does not need speaking', 'a message that he wants to be alone'],
   '아버지는 매일 밤 아주 늦게 퇴근해서 집에 오신다. 아버지는 우리에 대한 마음을 한마디도 말하지 않는다. 그래도 아버지는 복도의 작은 불을 켜 둔다. 그 따뜻한 불빛은 늘 현관에서 나를 맞아 준다. 나에게 그 불빛은 「소리 없는 포옹」이다.',
   ["1) 밑줄 친 'a hug without a sound'(소리 없는 포옹)은 «that glow»(그 불빛)를 가리키는 비유예요. 불빛이 진짜로 안아 주는 것은 아니에요.",
 "2) 단서를 찾아요. «He never says one word about his feelings for us.»(아버지는 우리에 대한 마음을 한마디도 말하지 않는다.) 그런데 «Still, he leaves the small light in the hall on.»(그래도 아버지는 복도의 작은 불을 켜 둔다.) 'Still'(그래도)은 말은 없어도 "
 '행동은 한다는 뜻을 이어 줘요.',
 '3) 포옹은 마음을 몸으로 전하는 일이에요. 아버지는 말 대신 불로 마음을 전한다고 읽을 수 있어요. 그 «warm glow»(따뜻한 불빛)가 나를 맞아 줘요.',
 "4) 그러니까 밑줄 친 'a hug without a sound'의 뜻은 'love that does not need speaking'(말이 필요 없는 사랑)이에요."],
   "'a light he forgets to turn off'(끄는 것을 잊은 불)를 고르고 싶어질 수 있어요. 불을 켜 둔 것만 보면 깜빡한 것처럼 읽히거든요. 하지만 «Still, he leaves the small light in the hall on.»(그래도 아버지는 복도의 작은 불을 켜 둔다.)은 말은 안 해도 불은 켜 둔다는 이야기예요. 그 불빛이 «warm glow»(따뜻한 불빛)로 나를 맞아 주니 잊은 불이 아니라 마음이 담긴 불로 읽혀요.",
   ['말은 안 해도 불은 켜 둔다는 이야기라서, 깜빡 잊은 불로 읽지 않아요. 불빛은 따뜻하게 나를 맞아 줘요.',
 '글에는 약속 이야기가 없어요. 아버지는 마음에 대해서는 한마디도 하지 않아요.',
 '불빛은 «warm glow»(따뜻한 불빛)라고 하고 나를 맞아 줘요. 화난 모습이 아니에요.',
 '말은 없지만 복도의 작은 불을 켜 둬요. 포옹처럼 따뜻하게 맞아 주는 사랑이에요.',
 '불빛은 나를 따뜻하게 맞아 줘요. 혼자 있고 싶은 모습이 아니에요.'],
   ['끄는 것을 잊은 불', '훨씬 일찍 오겠다는 약속', '가족에 대한 화의 표시', '말이 필요 없는 사랑', '혼자 있고 싶다는 메시지'],
   'feeling 마음 / glow 은은한 불빛 / hug 포옹 / hall 복도')

# 4번째 (정답 ⑤)
rw(3, 'We eat dinner at the big wooden table every evening. Grandpa always sat in the chair at the far end. He passed away last winter after a very long illness. Nobody in the family has sat in that chair since then. To all of us, it is still <u>an empty chair with his name on it</u>.',
   ['a seat that the whole family shares now', 'a chair that Grandpa did not like much', 'a gift that Grandpa left for the family', 'furniture the family does not need now', 'a seat saved for someone who is gone'],
   '우리는 저녁마다 큰 나무 식탁에서 저녁을 먹는다. 할아버지는 늘 맨 끝자리의 의자에 앉으셨다. 할아버지는 지난겨울 아주 오랜 병 끝에 돌아가셨다. 그 뒤로 가족 중 아무도 그 의자에 앉지 않았다. 우리 모두에게 그것은 여전히 「그의 이름이 붙은 빈 의자」이다.',
   ["1) 밑줄 친 'an empty chair with his name on it'(그의 이름이 붙은 빈 의자)는 진짜 이름표가 붙은 의자가 아니라 비유예요. 'his'(그의)는 «Grandpa»(할아버지)를 가리켜요.",
 '2) 단서를 찾아요. «Grandpa always sat in the chair at the far end.»(할아버지는 늘 맨 끝자리의 의자에 앉으셨다.) «He passed away last winter after a very long illness.»(할아버지는 지난겨울 아주 오랜 병 끝에 돌아가셨다.) «Nobody in the family '
 'has sat in that chair since then.»(그 뒤로 가족 중 아무도 그 의자에 앉지 않았다.)',
 "3) 마지막 문장의 'still'(여전히)도 눈여겨봐요. 돌아가신 뒤에도 그 의자를 할아버지의 자리로 여기기 때문에 아무도 앉지 않는 것으로 읽을 수 있어요.",
 "4) 그러니까 밑줄 친 'an empty chair with his name on it'의 뜻은 'a seat saved for someone who is gone'(떠난 사람을 위해 남겨 둔 자리)이에요."],
   "'furniture the family does not need now'(가족이 이제 필요 없는 가구)를 고르고 싶어질 수 있어요. 아무도 앉지 않으니 쓸모가 없어졌다고 읽기 쉽거든요. 하지만 «still»(여전히)과 «his name»(그의 이름)은 그 의자가 지금도 할아버지의 자리라는 뜻으로 읽혀요. 필요 없어서 비워 둔 것이라면 이런 말이 어울리지 않아요.",
   ['«Nobody in the family has sat in that chair since then.»(그 뒤로 가족 중 아무도 그 의자에 앉지 않았다.)와 반대예요.',
 '할아버지는 «always sat»(늘 앉았다)고 해요. 별로 좋아하지 않았다는 말은 글에 없어요.',
 '선물이라는 말은 글에 없어요.',
 "필요 없어서 비워 둔 것이라면 'still'(여전히)과 'his name'(그의 이름)이 어울리지 않아요.",
 '돌아가신 할아버지의 의자에 아무도 앉지 않아요. 그 자리는 여전히 할아버지의 것으로 남아 있어요.'],
   ['이제 온 가족이 함께 쓰는 자리', '할아버지가 별로 좋아하지 않던 의자', '할아버지가 가족에게 남긴 선물', '가족이 이제 필요 없는 가구', '떠난 사람을 위해 남겨 둔 자리'],
   'pass away 돌아가시다 / illness 병 / far 먼 / still 여전히')

# 5번째 (정답 ③)
rw(4, "After school, I always check the floor by our front door. My mother's brown shoes stand there neatly on most afternoons. I look for her shoes before anything else at home. For me, those quiet shoes are <u>the first hello of the day</u>. On other days, the empty floor makes our home feel cold.",
   ['a loud greeting', 'a rule about shoes', 'a sign that somebody is home', 'a pair of shoes that nobody wears', 'a sign that Mother is still at work'],
   '방과 후에 나는 늘 현관 옆 바닥을 살펴본다. 엄마의 갈색 신발이 대부분의 오후에 거기 가지런히 놓여 있다. 나는 집에서 무엇보다 먼저 엄마의 신발을 찾는다. 나에게 그 조용한 신발은 「하루의 첫 인사」이다. 다른 날에는 빈 바닥 때문에 우리 집이 차갑게 느껴진다.',
   ["1) 밑줄 친 'the first hello of the day'(하루의 첫 인사)는 «those quiet shoes»(그 조용한 신발)를 가리키는 비유예요. 신발은 말을 하지 않으니 진짜 인사가 아니에요.",
 '2) 단서를 찾아요. «I look for her shoes before anything else at home.»(나는 집에서 무엇보다 먼저 엄마의 신발을 찾는다.) 마지막 문장은 신발이 없는 날을 말해요. «On other days, the empty floor makes our home feel cold.»(다른 날에는 빈 바닥 때문에 우리 '
 '집이 차갑게 느껴진다.)',
 '3) 현관에 엄마 신발이 놓여 있으면 엄마가 집 안에 있다는 뜻으로 읽혀요. 신발이 없는 날의 «the empty floor»(빈 바닥)는 집이 «cold»(차갑게) 느껴지는 날이에요. 그러니 신발은 「집에 누가 있다」고 소리 없이 알려 주는 첫 인사예요.',
 "4) 그러니까 밑줄 친 'the first hello of the day'의 뜻은 'a sign that somebody is home'(집에 누가 있다는 표시)이에요."],
   "'a loud greeting'(큰 소리의 인사)이 끌릴 수 있어요. 'hello'(안녕)를 그대로 읽으면 소리 내는 인사 같거든요. 하지만 밑줄 친 말 앞에 «quiet»라는 낱말이 있어요. 「조용한」 신발이 건네는 인사이니 소리 내는 인사가 아니에요. 또 'a sign that Mother is still at work'(엄마가 아직 일터에 있다는 표시)는 거꾸로 읽은 보기예요. 신발이 놓여 있으면 엄마가 집에 있다고 읽을 수 있는데, 이 보기는 엄마가 아직 집에 없다는 뜻이거든요. 글에는 엄마가 일터에 있다는 말도 없어요.",
   ['신발은 «quiet»(조용한) 것이에요. 소리 내는 인사가 아니에요.',
 '신발에 관한 규칙 이야기는 글에 없어요.',
 '신발이 놓인 날에는 엄마가 집에 있다고 읽을 수 있어요. 빈 바닥인 날과 대비되는 모습이에요.',
 '신발을 아무도 신지 않는다는 말은 글에 없어요. 글은 엄마의 신발이 놓여 있는 날을 이야기해요.',
 '엄마가 일터에 있다는 말은 글에 없어요. 신발이 놓여 있는 모습은 엄마가 집에 있다는 뜻으로 읽히니, 오히려 반대예요.'],
   ['큰 소리의 인사', '신발에 관한 규칙', '집에 누가 있다는 표시', '아무도 신지 않는 신발', '엄마가 아직 일터에 있다는 표시'],
   'neatly 가지런히 / check 살펴보다 / quiet 조용한 / empty 빈')

# 6번째 (정답 ③)
rw(5, 'My older brother left for university far away in March. His bedroom door has stayed shut for many long months now. Nobody in the house ever says his name out loud. For my mother, that shut door is <u>a loud silence</u>. Every day, each of us walks past it quickly and sadly.',
   ['a noisy house full of talk', 'a happy talk about my brother', 'a sad feeling that nobody talks about', 'a plan to paint the room', 'a letter from my brother at the university'],
   '형은 3월에 아주 먼 곳의 대학으로 떠났다. 형의 방문은 이제 길고 긴 여러 달 동안 닫힌 채로 있다. 집에서는 아무도 형의 이름을 소리 내어 말하지 않는다. 엄마에게 그 닫힌 문은 「시끄러운 침묵」이다. 날마다 우리는 모두 그 문 앞을 서둘러, 슬프게 지나간다.',
   ["1) 밑줄 친 'a loud silence'(시끄러운 침묵)는 'loud'는 「시끄러운」이라는 뜻인데, 소리가 없는 침묵을 시끄럽다고 했으니 진짜 소리 이야기가 아니라 비유예요. «that shut door»(그 닫힌 문)와 이어져 있어요.",
 '2) 단서를 찾아요. «Nobody in the house ever says his name out loud.»(집에서는 아무도 그의 이름을 소리 내어 말하지 않는다.) 마지막 문장은 «Every day, each of us walks past it quickly and sadly.»(날마다 우리는 모두 그것을 서둘러, 슬프게 지나간다.)라고 해요.',
 '3) 아무도 형의 이름을 소리 내어 말하지 않지만, 닫힌 문 앞에서 모두 슬픔을 느껴요. 말은 없는데 그 슬픔이 집 안에서 크게 느껴진다는 뜻이에요.',
 "4) 그러니까 밑줄 친 'a loud silence'의 뜻은 'a sad feeling that nobody talks about'(아무도 말하지 않는 슬픈 마음)이에요."],
   "'a noisy house full of talk'(말소리로 가득한 시끄러운 집)이 끌릴 수 있어요. 'loud'를 소리가 큰 것으로만 읽는 거예요. 하지만 글에서는 «Nobody in the house ever says his name out loud.»(집에서는 아무도 그의 이름을 소리 내어 말하지 않는다.)라고 해요. 'loud'는 진짜 소리가 큰 것이 아니라, 말은 없는데 슬픔이 크게 느껴진다는 비유예요. 'a happy talk about my brother'(형에 대한 즐거운 이야기)도 아무도 형의 이름조차 소리 내어 말하지 않고 모두 슬프게 지나가니 맞지 않아요.",
   ['글에서는 아무도 형의 이름을 소리 내어 말하지 않아요. 형 이야기로 떠들썩한 집이 아니에요.',
 '아무도 형의 이름조차 소리 내어 말하지 않고, 모두 «sadly»(슬프게) 문 앞을 지나가요.',
 '말은 없지만 모두 슬프게 닫힌 문을 지나가요. 소리 없는 슬픔이 집 안에서 크게 느껴져요.',
 '방을 칠한다는 말은 글에 없어요.',
 '편지 이야기는 글에 없어요.'],
   ['말소리로 가득한 시끄러운 집', '형에 대한 즐거운 이야기', '아무도 말하지 않는 슬픈 마음', '방을 칠하려는 계획', '대학에 있는 형이 보낸 편지'],
   'university 대학 / shut 닫힌 / silence 침묵 / out loud 소리 내어')

# 7번째 (정답 ②)
rw(6, "The school built a new stone path around the big field. It curves a long way past the gym and the library. Students almost never use it on their way to class. By summer, a brown line in the grass had become <u>the school's real road</u>. They walk straight across the grass from the gate to the door.",
   ['a road that the school planned first', 'the route people really use', 'a rule about the grass', 'a stone path that is long and curved', 'a new path that the school wants to build'],
   '학교는 큰 운동장 둘레에 새 돌길을 놓았다. 그 길은 체육관과 도서관을 지나 멀리 돌아간다. 학생들은 교실로 가는 길에 그 길을 거의 쓰지 않는다. 여름이 되자 풀밭의 갈색 선이 「학교의 진짜 길」이 되었다. 학생들은 교문에서 출입문까지 풀밭을 곧장 가로질러 걷는다.',
   ["1) 밑줄 친 'the school's real road'(학교의 진짜 길)에서 'real'(진짜)에 주목해요. 돌길 말고 따로 '진짜' 길이 있다는 말이고, 그것은 «a brown line in the grass»(풀밭의 갈색 선)예요.",
 "2) 단서를 찾아요. «Students almost never use it on their way to class.»(학생들은 교실로 가는 길에 그것을 거의 쓰지 않는다.) 여기서 'it'(그것)은 새 돌길이에요. 마지막 문장은 «They walk straight across the grass from the gate to the "
 'door.»(학생들은 교문에서 출입문까지 풀밭을 곧장 가로질러 걷는다.)예요.',
 '3) 학생들은 돌길 대신 풀밭을 가로질러 다녀요. 그 갈색 선은 학생들이 실제로 다니는 길이 되었어요.',
 "4) 그러니까 밑줄 친 말의 뜻은 'the route people really use'(사람들이 실제로 쓰는 길)예요."],
   "'a road that the school planned first'(학교가 먼저 계획한 길)을 고르고 싶어질 수 있어요. 밑줄 친 말에 'school'(학교)과 'road'(길)이 나오니까요. 하지만 학교가 계획해서 놓은 것은 돌길이고, 학생들은 그 길을 «almost never»(거의 쓰지 않아요). 「진짜 길」은 학생들이 실제로 다니는 쪽이에요.",
   ['학교가 놓은 것은 돌길이고, 학생들은 그것을 거의 쓰지 않아요.',
 '학생들은 돌길 대신 풀밭을 곧장 가로질러 걸어요. 그 갈색 선이 진짜 길이 되었어요.',
 '규칙 이야기는 글에 없어요.',
 '돌길은 «It curves a long way»(멀리 돌아간다)라고 나오지만, 밑줄 친 말은 돌길이 아니라 풀밭의 갈색 선이에요.',
 '학교가 새 길을 지으려 한다는 말은 글에 없어요.'],
   ['학교가 먼저 계획한 길', '사람들이 실제로 쓰는 길', '풀밭에 관한 규칙', '길고 굽은 돌길', '학교가 지으려는 새 길'],
   'path 길 / curve 굽다 / field 운동장 / route 길, 경로')

# 8번째 (정답 ①)
rw(7, 'Jin does not understand the new math lesson at all. She feels too shy in front of the whole class. Her teacher asks the class for questions two different times. Jin keeps her hands in her lap during both times. To her teacher, those quiet hands are <u>questions with no voice</u>.',
   ['something she wants to ask but does not', 'a question the teacher asks two different times', 'a student who knows every answer', 'a class too large for one teacher', 'a sign that she is not listening'],
   '진은 새 수학 수업을 전혀 이해하지 못한다. 그녀는 반 전체 앞에서 너무 부끄럽다. 선생님은 반 학생들에게 두 번, 서로 다른 때에 질문이 있는지 묻는다. 진은 두 번 모두 두 손을 무릎 위에 둔 채로 있다. 선생님에게 그 조용한 두 손은 「목소리 없는 질문」이다.',
   ["1) 밑줄 친 'questions with no voice'(목소리 없는 질문)는 «those quiet hands»(그 조용한 손)를 가리키는 비유예요. 손이 진짜 질문을 하는 것은 아니에요.",
 '2) 단서를 찾아요. «Jin does not understand the new math lesson at all.»(진은 새 수학 수업을 전혀 이해하지 못한다.) «She feels too shy in front of the whole class.»(그녀는 반 전체 앞에서 너무 부끄럽다.)',
 '3) 선생님이 두 번 물었지만 진은 두 손을 무릎 위에 둔 채로 있어요. 모르는 것이 있는데 부끄러워서 말하지 못하는 모습으로 읽을 수 있어요. 질문이 입 밖으로 나오지 않고 손에만 담겨 있는 거예요.',
 "4) 그러니까 밑줄 친 'questions with no voice'의 뜻은 'something she wants to ask but does not'(묻고 싶지만 묻지 못하는 것)이에요."],
   "'a sign that she is not listening'(듣고 있지 않다는 표시)이 끌릴 수 있어요. 선생님이 질문이 있느냐고 두 번 물었는데도 가만히 있으니 딴생각을 하는 것처럼 보이거든요. 하지만 글은 진이 수업을 이해하지 못하고 «too shy»(너무 부끄러워한다)고 해요. 그래서 가만히 있는 것도 부끄러움 때문으로 읽을 수 있어요.",
   ['진은 수업을 이해하지 못하지만 부끄러워서 말을 못 해요. 그래서 질문이 목소리 없이 손에만 담겨 있어요.',
 '선생님이 두 번 묻는 것은 맞지만, 「목소리 없는 질문」은 진의 조용한 손을 가리켜요.',
 '진은 «does not understand the new math lesson at all»(새 수학 수업을 전혀 이해하지 못한다). 반대예요.',
 '반의 크기 이야기는 글에 없어요.',
 '진은 «too shy»(너무 부끄러워한다)고 해요. 가만히 있는 것도 부끄러움 때문으로 읽을 수 있고, 밑줄 친 말이 「질문」이라는 점도 듣지 않는 학생과 맞지 않아요.'],
   ['묻고 싶지만 묻지 못하는 것', '선생님이 두 번 묻는 질문', '모든 답을 아는 학생', '한 선생님에게 너무 큰 반', '듣고 있지 않다는 표시'],
   'shy 부끄러워하는 / lap 무릎 / lesson 수업 / voice 목소리')

# 9번째 (정답 ⑤)
rw(8, 'My grandmother lives alone in a quiet little village house. She has never turned the key in her gate lock. Her neighbors drop by at any hour of the day. To the whole village, her gate is <u>an open hand at the road</u>. Nobody in the village has ever stolen anything from her.',
   ['a rule that every guest must follow', 'a gate that does not shut well', 'a house that is unsafe at night', 'a warning to strangers to stay away', 'a sign of trust and welcome'],
   '할머니는 마을의 조용하고 작은 집에 혼자 사신다. 할머니는 대문 자물쇠에 열쇠를 한 번도 돌려 잠근 적이 없다. 이웃들은 하루 중 아무 때나 들른다. 마을 모든 사람에게 할머니의 대문은 「길가에 펼친 손」이다. 마을에서 할머니의 물건을 훔친 사람은 지금까지 아무도 없다.',
   ["1) 밑줄 친 'an open hand at the road'(길가에 펼친 손)은 «her gate»(할머니의 대문)을 가리키는 비유예요. 대문이 진짜 손은 아니에요.",
 '2) 단서를 찾아요. «She has never turned the key in her gate lock.»(할머니는 대문 자물쇠에 열쇠를 한 번도 돌려 잠근 적이 없다.) «Her neighbors drop by at any hour of the day.»(이웃들은 하루 중 아무 때나 들른다.)',
 '3) 마지막 문장은 «Nobody in the village has ever stolen anything from her.»(마을에서 아무도 그녀의 물건을 훔친 적이 없다.)예요. 대문을 잠그지 않아도 서로 믿는 마을로 읽을 수 있고, 이웃들은 편하게 드나들어요. 펼친 손은 문을 잠그지 않고 누구든 맞이하는 모습이에요.',
 "4) 그러니까 밑줄 친 'an open hand at the road'의 뜻은 'a sign of trust and welcome'(믿음과 환영의 표시)이에요."],
   "'a house that is unsafe at night'(밤에 위험한 집)이 끌릴 수 있어요. 혼자 사는 할머니가 대문을 잠그지 않았다고 하니 걱정이 되거든요. 하지만 마지막 문장은 마을에서 아무도 그녀의 물건을 훔친 적이 없다고 해요. 위험한 이야기가 아니라 믿음 이야기예요. 'a gate that does not shut well'(잘 닫히지 않는 대문)은 「잠그지 않았다」를 「닫히지 않는다」로 잘못 읽은 보기예요.",
   ['규칙 이야기는 글에 없어요.',
 '열쇠를 돌려 잠그지 않았다는 말이지, 대문이 고장 났다는 말은 아니에요.',
 '마을에서 아무도 훔친 적이 없다고 해요. 위험하다는 이야기가 아니에요.',
 '대문을 잠그지 않은 「펼친 손」은 오지 말라는 경고와 반대되는 모습이에요. 이웃들도 «drop by»(들른다)라고 해요.',
 '대문을 잠그지 않아 이웃들이 아무 때나 들러요. 아무도 훔친 적이 없다는 말이 믿음을 보여 줘요.'],
   ['모든 손님이 따라야 하는 규칙', '잘 닫히지 않는 대문', '밤에 위험한 집', '낯선 사람에게 오지 말라는 경고', '믿음과 환영의 표시'],
   'lock 자물쇠 / drop by 잠깐 들르다 / steal 훔치다 / trust 믿음 / welcome 환영')

# 10번째 (정답 ④)
rw(9, 'My new neighbor knocked on our door last night after dinner. My mother carried a tray with tea to the kitchen table. She did not say a single word to him about staying. She set one cup for herself and one for him. For the neighbor, that second cup was <u>a place at our table</u>.',
   ['a hint that it was time to go', 'a cup that was poured by mistake', 'tea with a strange taste', 'a silent invitation to stay', 'a tray that is heavy for my mother'],
   '새 이웃이 어젯밤 저녁 식사 뒤에 우리 집 문을 두드렸다. 엄마는 차를 담은 쟁반을 들고 부엌 식탁으로 갔다. 엄마는 그에게 머무는 일에 대해 한마디도 하지 않았다. 엄마는 자기 잔 하나와 그의 잔 하나를 놓았다. 그 이웃에게 그 둘째 잔은 「우리 식탁의 한 자리」였다.',
   ["1) 밑줄 친 'a place at our table'(우리 식탁의 한 자리)은 «that second cup»(그 둘째 잔)을 가리키는 비유예요. 잔이 진짜 자리는 아니에요.",
 '2) 단서를 찾아요. «She did not say a single word to him about staying.»(엄마는 그에게 머무는 일에 대해 한마디도 하지 않았다.) 그런데 «She set one cup for herself and one for him.»(엄마는 자기 잔 하나와 그의 잔 하나를 놓았다.)',
 '3) 말은 하지 않았지만 이웃 몫의 잔을 놓은 것은 함께 앉아 차를 마시자는 마음으로 읽을 수 있어요. 말 없이 건넨 초대예요.',
 "4) 그러니까 밑줄 친 'a place at our table'의 뜻은 'a silent invitation to stay'(머물라는 말 없는 초대)예요."],
   "'a hint that it was time to go'(이제 갈 때라는 암시)가 끌릴 수 있어요. 엄마가 아무 말도 하지 않았으니 가라는 뜻으로도 읽히거든요. 하지만 엄마는 이웃 몫의 잔과 함께 자기 잔도 놓았어요. 같이 앉겠다는 모습이라서 가라는 뜻이 아니에요.",
   ['엄마는 이웃 몫의 잔과 함께 자기 잔도 놓았어요. 함께 앉겠다는 모습이라서 가라는 뜻이 아니에요.',
 '«She set one cup for herself and one for him.»(엄마는 자기 잔 하나와 그의 잔 하나를 놓았다.) 일부러 이웃 몫을 놓은 거예요.',
 '차의 맛 이야기는 글에 없어요.',
 '말은 하지 않았지만 이웃 몫의 잔을 놓았어요. 함께 있자는 마음을 잔으로 전한 거예요.',
 '쟁반이 무겁다는 말은 글에 없어요.'],
   ['이제 갈 때라는 암시', '실수로 따른 잔', '이상한 맛의 차', '머물라는 말 없는 초대', '엄마에게 무거운 쟁반'],
   'neighbor 이웃 / tray 쟁반 / invitation 초대 / single 단 하나의')

# 11번째 (정답 ③)
rw(10, 'Our old kitchen table has many marks from the past. A deep dent sits in the middle of the wood. My cousin dropped a heavy pan there at the age of nine. Nobody in my whole family wants to fix that spot. To all of us, that dent is <u>a small page of our family story</u>.',
   ['a clean and smooth surface', 'a piece of furniture that is very old', 'a mark that holds a family memory', 'a sign that the family is very careless', 'damage that must be repaired'],
   '우리 낡은 부엌 식탁에는 지난날의 자국이 많다. 나무 한가운데에 깊이 팬 자국이 있다. 사촌은 아홉 살 때 무거운 냄비를 거기에 떨어뜨렸다. 우리 가족 모두 그 자리를 고치고 싶어 하지 않는다. 우리 모두에게 그 팬 자국은 「우리 가족 이야기의 작은 한 쪽」이다.',
   ["1) 밑줄 친 'a small page of our family story'(우리 가족 이야기의 작은 한 쪽)는 «that dent»(그 팬 자국)을 가리키는 비유예요. 팬 자국이 진짜 책의 쪽은 아니에요.",
 '2) 단서를 찾아요. «My cousin dropped a heavy pan there at the age of nine.»(사촌은 아홉 살 때 무거운 냄비를 거기에 떨어뜨렸다.) 자국에는 가족이 겪은 일이 담겨 있어요.',
 '3) «Nobody in my whole family wants to fix that spot.»(우리 가족 모두 그 자리를 고치고 싶어 하지 않는다.) 고치고 싶어 하지 않으니, 가족이 소중하게 여기는 자국으로 읽을 수 있어요. 이야기책의 한 쪽처럼 가족의 일이 남아 있어요.',
 "4) 그러니까 밑줄 친 'a small page of our family story'의 뜻은 'a mark that holds a family memory'(가족의 기억을 담은 자국)예요."],
   "'damage that must be repaired'(고쳐야 할 손상)을 고르고 싶어질 수 있어요. 깊이 팬 자국은 상처처럼 보이거든요. 하지만 글은 «Nobody in my whole family wants to fix that spot.»(우리 가족 모두 그 자리를 고치고 싶어 하지 않는다.)라고 해요. 고쳐야 할 것으로 보지 않아요.",
   ['식탁에는 «A deep dent»(깊이 팬 자국)이 있어요. 반대예요.',
 '식탁이 낡았다는 말은 첫 문장에 나오지만, 밑줄 친 말이 가리키는 것은 식탁이 아니라 팬 자국이에요.',
 '사촌이 냄비를 떨어뜨린 일이 자국으로 남았고, 가족은 그 자리를 고치고 싶어 하지 않아요.',
 '조심성이 없다는 말은 글에 없어요. 가족은 그 자국을 고치고 싶어 하지 않아요.',
 '고치고 싶어 하는 사람이 없어요.'],
   ['깨끗하고 매끈한 표면', '아주 낡은 가구', '가족의 기억을 담은 자국', '가족이 아주 조심성 없다는 표시', '고쳐야 할 손상'],
   'dent 움푹 팬 자국 / mark 자국 / pan 냄비 / fix 고치다 / repair 수리하다')

# 12번째 (정답 ③)
rw(11, 'Ms. Choi shares a big open office with ten other workers. In her first week, she brought a green plant from home. She put it carefully on the corner of her desk. Now nobody else puts a cup or a book on that corner. For Ms. Choi, that plant is <u>a small flag on her desk</u>.',
   ['a plant that the whole office shares', 'a plant that needs sun', 'a sign that this space is hers', 'a gift she gives to the other workers', 'a very busy office'],
   'Ms. Choi는 다른 직원 열 명과 넓게 트인 사무실을 함께 쓴다. 첫 주에 그녀는 집에서 초록 식물을 가져왔다. 그녀는 그것을 조심스럽게 책상 모서리에 놓았다. 이제는 다른 누구도 그 모서리에 컵이나 책을 올려놓지 않는다. Ms. Choi에게 그 식물은 「책상 위의 작은 깃발」이다.',
   ["1) 밑줄 친 'a small flag on her desk'(그녀의 책상 위 작은 깃발)은 «that plant»(그 식물)을 가리키는 비유예요. 진짜 깃발이 아니에요.",
 '2) 단서를 찾아요. «She put it carefully on the corner of her desk.»(그녀는 그것을 조심스럽게 책상 모서리에 놓았다.) «Now nobody else puts a cup or a book on that corner.»(이제는 다른 누구도 그 모서리에 컵이나 책을 올려놓지 않는다.)',
 '3) 깃발은 「여기는 내 자리」라고 알리는 표시예요. 식물을 놓은 뒤로 다른 사람들이 그 모서리를 쓰지 않으니, 식물이 그 자리를 알리는 표시가 되었어요.',
 "4) 그러니까 밑줄 친 'a small flag on her desk'의 뜻은 'a sign that this space is hers'(이 자리가 그녀의 것이라는 표시)예요."],
   "'a plant that the whole office shares'(온 사무실이 함께 쓰는 식물)가 끌릴 수 있어요. 그녀가 «a big open office»(넓게 트인 사무실)를 여럿이 쓴다고 했거든요. 하지만 식물은 «her desk»(그녀의 책상) 위에 있어요. 함께 쓰는 것이 아니라 그녀의 자리를 알리는 표시예요.",
   ['식물은 «the corner of her desk»(그녀의 책상 모서리)에 있어요. 함께 쓰는 것이 아니에요.',
 '햇빛 이야기는 글에 없어요.',
 '식물을 놓은 뒤로 아무도 그 모서리에 물건을 놓지 않아요. 식물이 「내 자리」라고 알려 줘요.',
 '식물은 그녀의 책상에 놓여 있어요. 다른 직원에게 준다는 말은 글에 없어요.',
 '사무실이 넓고 직원이 열 명 더 있다는 말은 있지만, 바쁘다는 말은 글에 없어요. 밑줄 친 말은 사무실이 아니라 식물을 가리켜요.'],
   ['온 사무실이 함께 쓰는 식물', '햇빛이 필요한 식물', '이 자리가 그녀의 것이라는 표시', '그녀가 다른 직원들에게 주는 선물', '아주 바쁜 사무실'],
   'office 사무실 / corner 모서리 / flag 깃발 / space 자리, 공간')

# 13번째 (정답 ②)
rw(12, 'My uncle moved from our house to a faraway city last March. His old blue coat still hangs on our hall hook. Nobody in the house has touched it since that day. Every day, my mother looks at it with sad eyes. For her, that coat is <u>a goodbye with no ending</u>.',
   ['a thing that she is ready to forget', 'a loss she has not yet accepted', 'a plan to send the coat back to him', 'a very old coat', 'a coat that my mother wants to give away'],
   '삼촌은 지난 3월에 우리 집을 떠나 아주 먼 도시로 이사 갔다. 삼촌의 낡은 파란 외투는 아직도 우리 집 복도 걸이에 걸려 있다. 집에서는 아무도 그날 이후 그것을 만지지 않았다. 날마다 엄마는 슬픈 눈으로 그것을 바라본다. 엄마에게 그 외투는 「끝나지 않는 작별 인사」이다.',
   ["1) 밑줄 친 'a goodbye with no ending'(끝나지 않는 작별 인사)은 «that coat»(그 외투)를 가리키는 비유예요. 외투가 진짜 작별 인사를 하는 것은 아니에요.",
 '2) 단서를 찾아요. «His old blue coat still hangs on our hall hook.»(삼촌의 낡은 파란 외투는 아직도 우리 집 복도 걸이에 걸려 있다.) «Nobody in the house has touched it since that day.»(집에서는 아무도 그날 이후 그것을 만지지 않았다.)',
 '3) «Every day, my mother looks at it with sad eyes.»(날마다 엄마는 슬픈 눈으로 그것을 바라본다.) 삼촌은 떠났지만 외투는 그대로이고 엄마는 날마다 그것을 봐요. 아직 이별을 받아들이지 못한 마음으로 읽을 수 있어요.',
 "4) 그러니까 밑줄 친 'a goodbye with no ending'의 뜻은 'a loss she has not yet accepted'(그녀가 아직 받아들이지 못한 상실)이에요."],
   "'a very old coat'(아주 낡은 외투)가 끌릴 수 있어요. 글에 «old blue coat»(낡은 파란 외투)가 나오거든요. 하지만 밑줄 친 말은 외투가 낡았다는 뜻이 아니라 엄마의 마음을 말해요. 'a thing that she is ready to forget'(잊을 준비가 된 것)은 엄마가 날마다 슬프게 외투를 바라보는 모습과 맞지 않아요.",
   ['엄마는 날마다 외투를 슬픈 눈으로 바라봐요. 잊으려는 모습이 아니에요.',
 '삼촌이 떠난 뒤 외투는 그대로 걸려 있고, 엄마는 날마다 그것을 슬프게 바라봐요.',
 '외투를 보낸다는 말은 글에 없어요. 외투는 그대로 걸려 있어요.',
 '글에 «old blue coat»(낡은 파란 외투)가 나오지만, 밑줄 친 말은 외투가 낡았다는 뜻이 아니라 엄마의 마음을 말해요.',
 '아무도 외투를 만지지 않았고, 엄마는 날마다 바라봐요. 남에게 주려는 모습이 아니에요.'],
   ['잊을 준비가 된 것', '아직 받아들이지 못한 상실', '외투를 그에게 돌려보내려는 계획', '아주 낡은 외투', '엄마가 남에게 주고 싶어 하는 외투'],
   'hook 걸이 / faraway 아주 먼 / goodbye 작별 인사 / accept 받아들이다')

# 14번째 (정답 ①)
rw(13, 'Every evening at six, the gate outside our house squeaks. Dad comes home from his job at exactly that time. The old sound tells me the hour without any help. My mother always starts cooking our dinner at that sound. To our family, that squeak is <u>a clock with no hands</u>.',
   ['a regular event that marks time', 'an event at a different time each day', 'a gate that needs oil', 'a warning that a stranger is near', 'a clock that shows the wrong time'],
   '저녁 여섯 시마다 우리 집 밖의 대문이 삐걱거린다. 아빠는 바로 그 시각에 일터에서 집에 오신다. 그 오래된 소리가 도움 없이도 나에게 시각을 알려 준다. 엄마는 늘 그 소리가 나면 저녁을 짓기 시작한다. 우리 가족에게 그 삐걱거림은 「바늘 없는 시계」이다.',
   ["1) 밑줄 친 'a clock with no hands'(바늘 없는 시계)는 «that squeak»(그 삐걱거림)을 가리키는 비유예요. 진짜 시계가 아니에요.",
 '2) 단서를 찾아요. «Every evening at six, the gate outside our house squeaks.»(저녁 여섯 시마다 우리 집 밖의 대문이 삐걱거린다.) «The old sound tells me the hour without any help.»(그 오래된 소리가 도움 없이도 나에게 시각을 알려 준다.)',
 '3) 엄마는 «starts cooking our dinner at that sound»(그 소리에 저녁을 짓기 시작한다). 시계를 보지 않아도 소리만으로 때를 알아요. 시계처럼 시간을 알려 주는 일이에요.',
 "4) 그러니까 밑줄 친 'a clock with no hands'의 뜻은 'a regular event that marks time'(시간을 알려 주는, 되풀이되는 일)이에요."],
   "'a gate that needs oil'(기름이 필요한 대문)이 끌릴 수 있어요. 삐걱거리는 소리를 들으면 대문이 낡은 것처럼 느껴지거든요. 하지만 글에는 기름이 필요하다는 말이 없고, 소리는 때를 알려 주는 일을 해요. 'a clock that shows the wrong time'(틀린 시각을 보여 주는 시계)은 「바늘이 없다」를 고장으로 읽은 보기인데, 소리는 «Every evening at six»(저녁 여섯 시마다) 나요.",
   ['대문 소리가 저녁 여섯 시마다 나서 시각을 알려 줘요. 엄마도 그 소리에 맞춰 저녁을 지어요.',
 '소리는 «Every evening at six»(저녁 여섯 시마다) 나요. 날마다 시각이 달라지는 일이 아니에요.',
 '기름이 필요하다는 말은 글에 없어요. 소리는 시각을 알려 주는 일을 해요.',
 '소리는 아빠가 집에 오는 시각을 알려 줘요. 낯선 사람 이야기는 글에 없어요.',
 '소리는 «Every evening at six»(저녁 여섯 시마다) 나고, 아빠도 «exactly that time»(바로 그 시각)에 와요. 틀린 시각이 아니에요.'],
   ['시간을 알려 주는, 되풀이되는 일', '날마다 시각이 다른 일', '기름이 필요한 대문', '낯선 사람이 가까이 있다는 경고', '틀린 시각을 보여 주는 시계'],
   'squeak 삐걱거리다 / hour 시각 / gate 대문 / hands (시계) 바늘')

# 15번째 (정답 ②)
rw(14, 'My aunt always put one extra plate on the table. Nobody in the family expected a guest on those evenings. Still, a stranger once knocked at the door at dinner time. He sat down at the extra place with a grateful smile. For my aunt, that extra plate was <u>a hello in advance</u>.',
   ['a welcome that nobody wanted', 'a welcome made ready for a guest', 'a meal cooked and wasted', 'a guest who arrives late for dinner', 'a plate the family uses every night'],
   '이모는 늘 식탁에 접시를 하나 더 놓았다. 그런 저녁에는 가족 중 아무도 손님이 오리라고 예상하지 못했다. 그런데도 어느 저녁 식사 시간에 낯선 사람이 문을 두드렸다. 그는 고마워하는 미소를 지으며 그 여분의 자리에 앉았다. 이모에게 그 여분의 접시는 「미리 건넨 인사」였다.',
   ["1) 밑줄 친 'a hello in advance'(미리 건넨 인사)는 «that extra plate»(그 여분의 접시)를 가리키는 비유예요. 접시가 말을 하는 것은 아니에요.",
 '2) 단서를 찾아요. «Nobody in the family expected a guest on those evenings.»(그런 저녁에는 가족 중 아무도 손님이 오리라고 예상하지 못했다.) 그런데도 이모는 접시를 놓았어요. «a stranger once knocked at the door at dinner time»(어느 날 낯선 사람이 저녁 '
 '시간에 문을 두드렸다)고 해요.',
 '3) «He sat down at the extra place with a grateful smile.»(그는 고마워하는 미소를 지으며 여분의 자리에 앉았다.) 손님이 올지 모르는데 미리 자리를 준비해 둔 것은, 올 사람을 반기는 마음이에요.',
 "4) 그러니까 밑줄 친 'a hello in advance'의 뜻은 'a welcome made ready for a guest'(손님을 위해 미리 준비한 환영)이에요."],
   "'a plate the family uses every night'(가족이 매일 밤 쓰는 접시)가 끌릴 수 있어요. 접시가 늘 놓이니까요. 하지만 그 접시는 «extra»(여분)이고, 손님이 오리라고 예상하지 못한 저녁에도 더 놓아 두는 접시예요. 가족이 매일 쓰려고 차린 접시가 아니에요. 'a welcome that nobody wanted'(아무도 원하지 않던 환영)은 «Nobody in the family expected a guest»(가족 중 아무도 손님이 오리라고 예상하지 못했다)를 「아무도 원하지 않았다」로 잘못 읽은 보기예요. 낯선 사람은 «grateful»(고마워하며) 앉았어요.",
   ["'expected'는 「올 거라고 예상했다」는 뜻이에요. 올 줄 몰랐던 것과 원하지 않은 것은 달라요. 낯선 사람은 «a grateful smile»(고마워하는 미소)로 그 자리에 앉았어요.",
 '이모는 손님이 올 줄 몰라도 접시를 놓았고, 낯선 사람이 그 자리에 앉았어요. 올 사람을 미리 반기는 마음이에요.',
 '음식을 버렸다는 말은 글에 없어요.',
 '낯선 사람이 «at dinner time»(저녁 시간에) 왔다고 해요. 늦게 왔다는 말은 없고, 밑줄 친 말은 손님이 아니라 접시를 가리켜요.',
 '접시를 늘 놓는 것은 맞지만, 그 접시는 «extra»(여분)예요. 손님이 오리라고 예상하지 못한 저녁에도 더 놓아 두는 접시이지, 가족이 매일 쓰려고 차린 접시가 아니에요.'],
   ['아무도 원하지 않던 환영', '손님을 위해 미리 준비한 환영', '만들어 놓고 버린 음식', '저녁에 늦게 오는 손님', '가족이 매일 밤 쓰는 접시'],
   'extra 여분의 / guest 손님 / stranger 낯선 사람 / grateful 고마워하는 / in advance 미리')
