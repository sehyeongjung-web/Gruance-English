# -*- coding: utf-8 -*-
# 312번: 35번(무관한 문장) 레벨3 — 새 레벨 기준으로 다시 씀 (뒤 절반: 16~30번째). 선생님 말씀(「더 이은 문장 만듭시다」)에 따라 and·but·so로 이은 문장도 섞음
# 레벨3의 기준(LEVEL_GUIDE.md): 쉬운 일반 낱말(고교 기초) · 종속절 하나(because·when·if·although·before·until) · 간단한 분사구문(문장 끝·앞의 -ing) · 문장당 10~15낱말
#   - 단문도 섞음. 관계사절·완료형/수동 분사구문은 쓰지 않음(레벨4·5의 몫)
#   - 문항마다 여섯 문장 가운데 둘셋이 종속절을 가진 문장, 하나가 분사구문, 나머지는 단문
# 글감·정답 번호·무관한 문장의 내용은 줄이기 전 지문(restore35.py) 그대로. 레벨2와 겹치는 글감(벌·낙엽·소금·얼음·씨앗·나침반·소리)은 짜임이 다름
# 지문·해석·풀이·해설은 data_X52b.json에 둠
AUTO_SYNC = False
E = {}
import json, os
from z35common import maker, _tb
LV = '3'
mk = maker(E, lv=LV)
_here = os.path.dirname(os.path.abspath(__file__))
_p = next(p for p in (os.path.join(_here, 'data_X52b.json'), os.path.join(_here, '..', 'data_X52b.json'), 'data_X52b.json') if os.path.exists(p))   # 수정안이 pending/·done/에 있어도 찾도록
_D = json.load(open(_p, encoding='utf-8'))
def rw(n, text, ko, steps, confuse, cn):
    mk(n, steps, confuse, cn); e = E.pop(('35', LV, n))
    assert all(c in text for c in '①②③④⑤') and all(c in ko for c in '①②③④⑤'), n
    E[('35', LV, n)] = {'passage_ok': True, 'ans_ok': True,
                        'rewrite': {'text': text, 'choices': list(_tb['35'][LV][n]['choices']), 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}
for _i in range(15):
    _s, _c, _cn = _D['x'][_i]
    rw(15 + _i, _D['text'][_i], _D['ko'][_i], _s, _c, _cn)
