# -*- coding: utf-8 -*-
# 277번: 36-37번(글의 순서) 레벨4 — 30문항을 다 읽고 두 문항을 바로잡음
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새 지문에 맞게 다시 씀(레벨5~9와 같은 꼴). 정답·선택지 변동 없음. z3common.py가 같은 폴더에 있어야 함
#   1번째 — 다른 순서로도 읽힘: (B) 그러나 효율이 떨어진다 → (C) 그 결과 더 오래 걸린다 → (A) 이것은 뇌가 다시 집중할 시간이 필요하기 때문이다 ((B)-(C)-(A)도 말이 됨)
#           → (C) 'As a result, people who multitask …' → 'All that refocusing adds up, so people who multitask …'((A)의 refocus를 받음)
#   2번째 — (B)의 숫자가 말이 서지 않음('arrived between four and six and left before five thirty' — 여섯 시에 온 사람이 다섯 시 반 전에 떠날 수 없음).
#           저녁 시간이 안 쓰이는 까닭과 폐관 시간을 한 시간 늦춘 해결도 이어지지 않음
#           → (B) 'people did arrive after work, but so close to closing time that most left within half an hour' / (A) 'moved back by two hours'
AUTO_SYNC = False
E = {}
from z3common import maker
mk = maker(E, lv='4')
def fix(n, text, ko):
    E[('36_37', '4', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 1번째: 멀티태스킹은 오히려 느리다 ----------
mk(0, 'BAC', [
 "1) 주어진 글: 많은 사람이 멀티태스킹을 하면 더 짧은 시간에 더 많이 해낸다고 믿습니다. 'Many people believe'(많은 사람이 믿는다)로 시작하는 글은 흔히 그 믿음을 뒤집는 말로 이어집니다.",
 "2) 첫째 글 (B): «However, research suggests that switching between tasks actually reduces overall efficiency»(그러나 연구는 과제 사이를 오가는 것이 실제로는 전체 효율을 떨어뜨린다는 것을 시사한다). However(그러나)가 주어진 글의 믿음을 뒤집습니다. 믿음 바로 뒤에 올 수 있는 것은 이 글뿐입니다.",
 "3) 둘째 글 (A): «This is because the brain needs time to refocus each time a person switches from one task to another.»(이것은 사람이 한 과제에서 다른 과제로 옮길 때마다 뇌가 다시 집중할 시간을 필요로 하기 때문이다.) 'This is because'(이것은 ~ 때문이다)가 (B)의 「효율이 떨어진다」에 까닭을 댑니다. refocus(다시 집중하다)라는 말이 여기서 처음 나옵니다.",
 "4) 셋째 글 (C)와 확인: «All that refocusing adds up»(그렇게 다시 집중하는 시간이 쌓인다). 'All that refocusing'(그 모든 다시 집중하기)이 (A)의 refocus를 받습니다. 그래서 멀티태스킹하는 사람이 더 오래 걸린다는 결과로 맺습니다. 뒤집기 → 까닭 → 결과로 맞물리므로 순서는 (B)-(A)-(C)입니다."],
 "(B) 바로 뒤에 (C)를 놓고 싶어질 수 있습니다. 「효율이 떨어진다, 그래서 더 오래 걸린다」로 바로 이어질 것 같기 때문입니다. 하지만 (C)는 'All that refocusing'(그 모든 다시 집중하기)으로 시작합니다. 다시 집중한다는 말은 (A)에 있습니다. 그러니 (A)가 (C) 앞에 와야 합니다.",
 {'ACB': "(A)의 'This is because'(이것은 ~ 때문이다)가 까닭을 댈 것이 주어진 글에 없습니다. 멀티태스킹이 도움이 된다는 믿음에 「뇌가 다시 집중할 시간이 필요해서」라는 까닭은 맞지 않습니다.",
  'BAC': "주어진 글의 믿음을 (B)의 However가 뒤집고, (A)가 뇌가 다시 집중할 시간이 필요하다는 까닭을 대고, (C)의 'All that refocusing'이 그것을 받아 더 오래 걸린다는 결과로 맺습니다.",
  'BCA': "(B)로 시작하는 것은 맞습니다. 하지만 (C)의 'All that refocusing'(그 모든 다시 집중하기)이 (A)의 refocus보다 먼저 나옵니다. 가리키는 말이 가리킬 것보다 앞에 올 수 없습니다.",
  'CAB': "(C)의 'All that refocusing'이 가리킬 것이 주어진 글에 없습니다. 다시 집중한다는 말은 (A)에서 처음 나오므로 (C)가 맨 앞에 올 수 없습니다.",
  'CBA': "(C)의 'All that refocusing'이 가리킬 것이 앞에 없습니다. 또 (B)의 However가 믿음 바로 뒤가 아니라 가운데에 오게 되어, 뒤집을 말에서 떨어집니다."})
fix(0, ('(C) As a result, people who multitask often take longer', '(C) All that refocusing adds up, so people who multitask often take longer'),
       ('(C) 그 결과 멀티태스킹하는 사람은', '(C) 그렇게 다시 집중하는 시간이 쌓여서, 멀티태스킹하는 사람은'))

# ---------- 2번째: 저녁에 사람이 없던 까닭은 폐관 시간 ----------
mk(1, 'CBA', [
 "1) 주어진 글: 한 도서관이 저녁 시간에 이용이 거의 없다는 것을 발견했습니다. 왜 그런지, 직원들이 그 까닭을 어떻게 여겼는지가 다음에 나와야 합니다.",
 "2) 첫째 글 (C): «The staff assumed that few people wanted to read after work.»(직원들은 퇴근 뒤에 책을 읽고 싶어 하는 사람이 적다고 여겼다.) assumed(여겼다)는 알아보기 전의 짐작입니다. 주어진 글의 물음에 먼저 나온 답입니다.",
 "3) 둘째 글 (B): «A count at the door showed that people did arrive after work»(문에서 센 집계는 사람들이 퇴근 뒤에 오기는 한다는 것을 보여주었다). 'did arrive'(오기는 한다)는 (C)의 짐작을 뒤집는 힘준 말입니다. 사람들은 왔지만 폐관 시간이 너무 가까워 대부분 30분 안에 떠났습니다. 까닭은 사람들의 마음이 아니라 폐관 시간이었습니다.",
 "4) 셋째 글 (A)와 확인: «The closing time was moved back by two hours»(폐관 시간이 두 시간 뒤로 옮겨졌다). 'The closing time'(그 폐관 시간)이 (B)의 'closing time'을 받습니다. 까닭을 알았으니 그것을 고쳤고, 저녁이 가장 붐비는 시간이 되었습니다. 짐작 → 실제 → 해결로 맞물리므로 순서는 (C)-(B)-(A)입니다."],
 "(B)를 주어진 글 바로 뒤에 놓고 싶어질 수 있습니다. 이용이 없다는 말 뒤에 세어 본 결과가 바로 이어질 것 같기 때문입니다. 하지만 (B)의 'did arrive'(오기는 한다)는 「안 온다」는 생각을 뒤집는 말입니다. 그 생각이 (C)의 짐작입니다. 짐작이 먼저 나와야 뒤집을 수 있습니다.",
 {'ACB': "(A)에서 폐관 시간을 옮기는 것은 까닭을 안 뒤의 일입니다. 주어진 글에는 아직 까닭이 나오지 않았으므로 (A)가 맨 앞에 올 수 없습니다.",
  'BAC': "(B)의 'did arrive'(오기는 한다)가 뒤집을 짐작이 주어진 글에 없습니다. 또 (C)가 맨 끝에 오면, 다 해결한 뒤에 사람들이 책을 읽고 싶어 하지 않는다는 짐작이 나옵니다.",
  'BCA': "(B)에서 사람들이 퇴근 뒤에 온다는 것을 세어서 알았는데, 그 뒤에 (C)에서 그런 사람이 적다고 여겼다고 하면 앞뒤가 맞지 않습니다. 짐작은 세어 보기 전의 일입니다.",
  'CAB': "(C)로 시작하는 것은 맞습니다. 하지만 (A)의 폐관 시간 옮기기가 (B)보다 먼저 나옵니다. 폐관 시간이 까닭이라는 것을 (B)에서 알아낸 뒤에야 그것을 옮길 까닭이 생깁니다.",
  'CBA': "주어진 글의 물음에 (C)가 직원들의 짐작을 말하고, (B)의 'did arrive'가 그 짐작을 뒤집어 폐관 시간이 까닭임을 밝히고, (A)가 폐관 시간을 옮겨 해결합니다."})
fix(1, [('(A) The closing time was moved back an hour and the evening became', '(A) The closing time was moved back by two hours, and the evening became'),
        ('(B) A count at the door showed that most visitors arrived between four and six and left before five thirty.', '(B) A count at the door showed that people did arrive after work, but so close to closing time that most left within half an hour.')],
       [('(A) 폐관 시간이 한 시간 뒤로 옮겨졌고', '(A) 폐관 시간이 두 시간 뒤로 옮겨졌고'),
        ('(B) 문에서 센 집계는 대부분의 방문자가 네 시와 여섯 시 사이에 와서 다섯 시 반 전에 떠난다는 것을 보여주었다.', '(B) 문에서 센 집계는 사람들이 퇴근 뒤에 오기는 하지만 폐관 시간에 너무 가까워서 대부분이 30분 안에 떠난다는 것을 보여주었다.')])
