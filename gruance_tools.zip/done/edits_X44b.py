# -*- coding: utf-8 -*-
# 298번: 40번(요약문 완성) 레벨3 — 30문항을 다 읽고 아홉 문항을 바로잡음 (이 파일: 17·18·25·29번째)
#   17번째 — 정답의 (A) oboe가 지문에 없음(지문은 'one instrument'뿐 — 그것이 오보에라는 것은 바깥 지식). (B) carries도 'most stable'과 맞지 않음
#            → 지문 'Before a concert the oboe sounds a single note … It is chosen because …' / 선택지의 (B) carries·sets → holds(정답 'oboe - holds')
#   18번째 — 정답의 light·developer가 지문에 없음(필름에 상을 남기는 것이 빛이고 그 약품이 현상액이라는 것은 바깥 지식)
#            → 지문 'A film exposed to light carries an invisible pattern until it is treated. A chemical called developer makes the pattern visible and another called fixer stops it changing further.'
#   25번째 — 엉뚱한 오답 'music - body' → 'actor - body'
#   29번째 — 오답 'tail - weight'도 답으로 섬(아래에 다는 것이 무게를 더하는지 끌리는 힘을 더하는지 지문에 단서가 없음)
#            → 둘째 문장 'Adding a long light ribbon at the bottom steadies it, because the wind pulls on the ribbon.'
AUTO_SYNC = False
E = {}
from z40common import maker
mk = maker(E, lv='3')
def fix(n, text, ko):
    E[('40', '3', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 17번째: 연주회 전에 음을 주는 악기 ----------
mk(16, 3, [
 "1) 요약문: «The (A) ______ gives the note because it (B) ______ steadily.»((A)가 그 음을 주는 것은 그것이 흔들림 없이 (B)하기 때문이다.) (A)는 음을 내는 것이 무엇인가, (B)는 그것이 뽑힌 까닭이에요.",
 "2) (A) 찾기: 첫 문장이 짝꿍 문장이에요. «the oboe sounds a single note and the rest match it»(오보에가 음 하나를 내고 나머지가 그것에 맞춘다). 음을 내는 것은 오보에예요.",
 "3) (B) 찾기: 둘째 문장이에요. «its pitch is the most stable»(그것의 음높이가 가장 안정되어 있다). 오보에의 음은 오르내리지 않고 그대로 있어요. 그래서 다른 악기들이 거기에 맞출 수 있어요.",
 "4) 묶기: (A) 'the oboe' 그대로예요. (B) 'the most stable'(가장 안정된) = 흔들리지 않고 그대로 있다 = 'holds'(그대로 버틴다). 요약문의 steadily(흔들림 없이)와 이어져요."],
 "「바이올린 - 그대로 버틴다」가 가장 끌려요. (B)가 맞고, 관현악단의 맨 앞자리가 바이올린이라는 것을 알고 있거든요. 하지만 지문은 오보에라고 했어요. 「오보에 - 변한다」는 (A)만 맞아요. 음이 변하는 악기에는 다른 악기들이 맞출 수 없어요. 지문은 가장 안정되어 있다고 했어요.",
 [("지휘자 - 그대로 버틴다", "(A)가 틀렸어요. 지휘자는 악기가 아니에요. 지문은 한 악기가 음을 낸다고 했고, 그것은 오보에예요."),
  ("바이올린 - 그대로 버틴다", "(B)는 맞고 (A)가 틀렸어요. 음이 그대로 있어서 뽑혔다는 것은 맞아요. 하지만 그 악기는 바이올린이 아니라 오보에예요."),
  ("오보에 - 변한다", "(A)는 맞고 (B)가 틀렸어요. 오보에가 음을 내는 것은 맞아요. 하지만 지문은 그 음높이가 가장 안정되어 있다고 했어요. 변한다는 것은 반대예요."),
  ("오보에 - 그대로 버틴다", "(A)는 첫 문장의 «the oboe sounds a single note and the rest match it»이, (B)는 둘째 문장의 «its pitch is the most stable»이 근거예요. 오보에의 음이 가장 흔들리지 않아서 다른 악기들이 거기에 맞추어요."),
  ("바이올린 - 변한다", "두 낱말 모두 글과 맞지 않아요. 음을 내는 것은 오보에이고, 그 음은 변하지 않고 안정되어 있어요.")],
 ch={0: 'conductor - holds', 1: 'violin - holds', 3: 'oboe - holds'}, ans_ok=True)
fix(16, ('Before a concert one instrument sounds a single note and the rest match it. That instrument is chosen because its pitch is the most stable.', 'Before a concert the oboe sounds a single note and the rest match it. It is chosen because its pitch is the most stable.'),
        ('연주회 전에 한 악기가 음 하나를 내고 나머지가 그것에 맞춘다. 그 악기는 음높이가 가장 안정적이어서 선택된다.', '연주회 전에 오보에가 음 하나를 내고 나머지가 그것에 맞춘다. 그것은 음높이가 가장 안정적이어서 선택된다.'))

# ---------- 18번째: 빛이 남긴 무늬를 현상액이 드러낸다 ----------
mk(17, 4, [
 "1) 요약문: «The image made by (A) ______ is brought out by the (B) ______.»((A)로 만들어진 상은 (B)에 의해 드러난다.) (A)는 상을 만든 것, (B)는 그 상을 눈에 보이게 하는 것이에요.",
 "2) (A) 찾기: 첫 문장이 짝꿍 문장이에요. «A film exposed to light carries an invisible pattern»(빛에 쬔 필름은 보이지 않는 무늬를 지닌다). 필름에 무늬를 남긴 것은 빛이에요.",
 "3) (B) 찾기: 둘째 문장이에요. «A chemical called developer makes the pattern visible»(현상액이라는 약품이 그 무늬를 보이게 만든다). 보이게 하는 것은 현상액이에요. 다른 약품인 fixer(정착액)는 «stops it changing further»(그것이 더 변하는 것을 멈춘다)라고 했어요. 드러내는 일이 아니라 멈추는 일을 해요.",
 "4) 묶기: (A) 'exposed to light'(빛에 쬔) → 'light'(빛). (B) 'makes the pattern visible'(그 무늬를 보이게 만든다) = 요약문의 'brought out'(드러난) → 'developer'(현상액). 지문 낱말 그대로예요."],
 "「빛 - 정착액」이 가장 조심할 선택지예요. (A)가 맞고, 정착액도 지문에 나오는 약품이거든요. 하지만 정착액이 하는 일은 무늬가 더 변하지 않게 멈추는 것이에요. 보이게 하는 것은 현상액이에요. 「어둠 - 정착액」은 사진을 어두운 방에서 다룬다는 것을 알고 있어서 끌리지만, 어둠은 지문에 나오지 않아요.",
 [("열 - 현상액", "(B)는 맞고 (A)가 틀렸어요. 현상액이 무늬를 보이게 하는 것은 맞아요. 하지만 필름에 무늬를 남긴 것은 열이 아니라 빛이에요."),
  ("빛 - 정착액", "(A)는 맞고 (B)가 틀렸어요. 빛이 무늬를 남긴 것은 맞아요. 하지만 정착액은 무늬가 더 변하지 않게 멈추는 약품이에요. 보이게 하는 것은 현상액이에요."),
  ("어둠 - 정착액", "두 낱말 모두 글과 맞지 않아요. 어둠은 지문에 나오지 않고, 정착액은 드러내는 것이 아니라 멈추는 약품이에요."),
  ("시간 - 빛", "두 낱말 모두 글과 맞지 않아요. 무늬를 만든 것은 시간이 아니라 빛이고, 무늬를 드러내는 것은 약품이에요."),
  ("빛 - 현상액", "(A)는 첫 문장의 «A film exposed to light carries an invisible pattern»이, (B)는 둘째 문장의 «A chemical called developer makes the pattern visible»이 근거예요. 빛이 보이지 않는 무늬를 남기고, 현상액이 그것을 보이게 해요.")])
fix(17, ('A film carries an invisible pattern until it is treated. One chemical makes the pattern visible and another stops it changing further.', 'A film exposed to light carries an invisible pattern until it is treated. A chemical called developer makes the pattern visible and another called fixer stops it changing further.'),
        ('필름은 처리되기 전까지 보이지 않는 무늬를 지니고 있다. 한 약품이 그 무늬를 보이게 하고 다른 약품이 그것이 더 바뀌지 않게 한다.', '빛에 쬔 필름은 처리되기 전까지 보이지 않는 무늬를 지니고 있다. 현상액이라는 약품이 그 무늬를 보이게 하고, 정착액이라는 다른 약품이 그것이 더 바뀌지 않게 한다.'))

# ---------- 25번째: 가면을 쓰면 몸이 뜻을 전한다 ----------
mk(24, 4, [
 "1) 요약문: «The (A) ______ fixes the expression, so the (B) ______ carries the meaning.»((A)가 표정을 고정하고, 그래서 (B)가 뜻을 전한다.) (A)는 표정을 바꿀 수 없게 하는 것, (B)는 그 대신 뜻을 전하는 것이에요.",
 "2) (A) 찾기: 첫 문장이 짝꿍 문장이에요. «A masked performer cannot use the face at all.»(가면을 쓴 연기자는 얼굴을 전혀 쓸 수 없다.) 얼굴을 쓸 수 없게 하는 것은 가면이에요. 가면의 표정은 바뀌지 않아요.",
 "3) (B) 찾기: 둘째 문장이에요. «Everything the audience reads must come from movement.»(관객이 읽어 내는 모든 것은 움직임에서 나와야 한다.) 얼굴 대신 움직임이 뜻을 전해요. 움직이는 것은 몸이에요.",
 "4) 묶기: (A) 'masked'(가면을 쓴) → 'mask'(가면). (B) 'movement'(움직임) = 'body'(몸). 움직임을 그것을 하는 몸으로 바꾸어 말한 것이에요."],
 "「가면 - 목소리」가 가장 끌려요. (A)가 맞고, 얼굴을 쓸 수 없으면 목소리로 전할 것 같거든요. 하지만 지문은 모든 것이 움직임에서 나와야 한다고 했어요. 목소리는 지문에 나오지 않아요. 「연기자 - 몸」은 (B)만 맞아요. 표정을 고정하는 것은 연기자가 아니라 연기자가 쓴 가면이에요.",
 [("연기자 - 몸", "(B)는 맞고 (A)가 틀렸어요. 몸이 뜻을 전하는 것은 맞아요. 하지만 표정을 고정하는 것은 연기자가 아니라 가면이에요. 연기자는 얼굴을 쓸 수 없게 된 쪽이에요."),
  ("의상 - 목소리", "두 낱말 모두 글과 맞지 않아요. 의상도 목소리도 지문에 나오지 않아요."),
  ("가면 - 목소리", "(A)는 맞고 (B)가 틀렸어요. 가면이 표정을 고정하는 것은 맞아요. 하지만 지문은 모든 것이 움직임에서 나와야 한다고 했어요. 목소리는 나오지 않아요."),
  ("의상 - 몸", "(B)는 맞고 (A)가 틀렸어요. 몸이 뜻을 전하는 것은 맞아요. 하지만 의상은 지문에 나오지 않아요. 표정을 고정하는 것은 가면이에요."),
  ("가면 - 몸", "(A)는 첫 문장 «A masked performer cannot use the face at all.»이, (B)는 둘째 문장 «Everything the audience reads must come from movement.»가 근거예요. 가면이 표정을 고정하니, 몸의 움직임이 뜻을 전해요.")],
 ch={0: 'actor - body'})

# ---------- 29번째: 연의 꼬리는 끌리는 힘을 더한다 ----------
mk(28, 1, [
 "1) 요약문: «The (A) ______ works by adding (B) ______ below the centre.»((A)는 중심 아래에 (B)를 더해서 일한다.) (A)는 연에 다는 것, (B)는 그것이 더해 주는 것이에요.",
 "2) (A) 찾기: 둘째 문장이 짝꿍 문장이에요. «Adding a long light ribbon at the bottom steadies it»(아래쪽에 길고 가벼운 띠를 더하면 그것이 안정된다). 연의 아래쪽에 다는 긴 띠는 꼬리예요.",
 "3) (B) 찾기: 같은 문장의 because(~ 때문에) 뒤예요. «the wind pulls on the ribbon»(바람이 그 띠를 잡아당긴다). 꼬리가 하는 일은 바람에 끌리는 것이에요. 그 띠는 light(가벼운)라고 했어요. 무거워서 연을 잡아 주는 것이 아니에요.",
 "4) 묶기: (A) 'a long light ribbon at the bottom'(아래쪽의 길고 가벼운 띠) = 'tail'(꼬리). (B) 'the wind pulls on the ribbon'(바람이 그 띠를 잡아당긴다) = 'drag'(끌리는 힘). 둘 다 지문에 없는 낱말로 바꾼 것이에요."],
 "「꼬리 - 무게」가 가장 끌려요. (A)가 맞고, 아래에 무엇을 달면 무거워져서 안정될 것 같거든요. 하지만 지문은 그 띠가 가볍다고 했어요. 안정되는 까닭도 바람이 띠를 잡아당기기 때문이라고 했어요. 「줄 - 뜨는 힘」은 연이라면 떠오르는 낱말이지만, 줄도 뜨는 힘도 지문에 나오지 않아요.",
 [("줄 - 뜨는 힘", "두 낱말 모두 글과 맞지 않아요. 연줄도 뜨는 힘도 지문에 나오지 않아요. 글이 말하는 것은 아래쪽에 다는 띠예요."),
  ("꼬리 - 끌리는 힘", "(A)는 둘째 문장의 «Adding a long light ribbon at the bottom steadies it»이, (B)는 «the wind pulls on the ribbon»이 근거예요. 아래에 단 가벼운 띠를 바람이 잡아당겨서 연이 돌지 않게 돼요."),
  ("뼈대 - 무게", "두 낱말 모두 글과 맞지 않아요. 뼈대는 지문에 나오지 않고, 더해 주는 것도 무게가 아니에요."),
  ("꼬리 - 무게", "(A)는 맞고 (B)가 틀렸어요. 아래에 다는 띠가 꼬리인 것은 맞아요. 하지만 지문은 그 띠가 가볍다고 했어요. 무게가 아니라 바람이 잡아당기는 힘으로 안정돼요."),
  ("뼈대 - 끌리는 힘", "(B)는 맞고 (A)가 틀렸어요. 바람이 잡아당기는 힘이 더해지는 것은 맞아요. 하지만 그 힘을 받는 것은 뼈대가 아니라 아래에 단 띠예요.")])
fix(28, ('Adding length at the bottom steadies it in the air.', 'Adding a long light ribbon at the bottom steadies it, because the wind pulls on the ribbon.'),
        ('아래쪽에 길이를 더하면 공중에서 안정된다.', '아래쪽에 길고 가벼운 띠를 더하면 안정되는데, 바람이 그 띠를 잡아당기기 때문이다.'))
