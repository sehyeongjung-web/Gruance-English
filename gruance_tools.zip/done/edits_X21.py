# -*- coding: utf-8 -*-
# 274번: 23번(주제) 레벨5 — 30문항을 다 읽고 두 문항을 바로잡음(+ 두 문항은 해석만)
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새로 씀(레벨6~9와 같은 꼴). 정답 번호 변동 없음. z23common.py가 같은 폴더에 있어야 함
#   15번째 — 정답 'why ironing works on some fabrics and not others'(어떤 천에는 듣고 다른 천에는 안 듣는 이유)가 지문과 어긋남:
#            지문은 합성 섬유가 다림질이 안 된다는 것이 아니라 낮은 온도로 다려야 한다는 것(그래서 다이얼에 설정이 여럿) → 'why fabrics are ironed at different temperatures'
#   19번째 — 지문의 'the sound is air rushing in to replace what left'가 사실과 다름(탄산병을 열 때 나는 소리는 바깥 공기가 밀려드는 소리가 아니라 갇혀 있던 기체가 밀려 나가는 소리)
#            → 'the gas trapped above the drink rushes out, which is the sound, and more comes out of solution as bubbles'. 해설 머리의 선택지 해석 하나(「생산 라인에서」 군말)도 바로잡음
# 해석만: 6번째('a crossing with no button at all'을 「버튼이 있는데도 아무 반응이 없으면」으로 옮겨 놓음) · 10번째('droplets too small to see through'를 「눈에 보이지 않을 만큼 작은 물방울」로 옮겨 놓음)
AUTO_SYNC = False
E = {}
from z23common import maker, _tb
mk = maker(E, lv='5')
def swap(n, k, new, ans_ok=False):
    """선택지 하나를 바꿈: 해설 머리의 영어도 새 선택지로"""
    old = _tb['23']['5'][n]['choices'][k]; e = E[('23', '5', n)]
    assert ("'%s' (" % old) in e['cn'][k]; e['cn'][k] = e['cn'][k].replace("'%s' (" % old, "'%s' (" % new)
    e['ch'] = {k: new}
    if ans_ok: e['ans_ok'] = True

# ---------- 해석만 고친 두 문항 (지문·풀이·해설은 그대로) ----------
E[('23', '5', 5)] = {'ko': ('기술자들은 버튼이 있는데도 아무 반응이 없으면 불만이 더 많이 들어오고, 밤에는 실제로 작동하기 때문에 버튼을 그대로 둔다.', '기술자들은 버튼이 아예 없는 횡단보도가 불만을 더 많이 낳고, 밤에는 버튼이 실제로 작동하기 때문에 그것을 그대로 둔다.')}
E[('23', '5', 9)] = {'ko': ('눈에 보이지 않을 만큼 작은 물방울로 남긴다', '그 너머가 비쳐 보이지 않을 만큼 잘디잔 물방울로 남긴다')}

# ---------- 15번째: 천마다 다림질 온도가 다른 까닭 ----------
mk(14, 1, [
 "1) 되풀이: 「천마다 열에 달리 움직인다」는 생각이 세 문장에 걸쳐 이어집니다. 열과 습기가 섬유를 움직이게 하고 식으면서 새 자리에 굳게 한다 → 면과 리넨은 그 새 모양을 잘 지닌다 → 합성 섬유는 녹는 온도 가까이에서 부드러워진다. 첫 문장이 다림질의 원리를 말하고, 뒤의 두 문장이 섬유마다 그것이 어떻게 다른지를 말합니다.",
 "2) 꺾이는 곳: 꺾이는 말은 없습니다. 대신 둘째 문장과 셋째 문장이 맞서 있습니다. «Cotton and linen hold the new shape well.»(면과 리넨은 그 새 모양을 잘 지닌다.) 이와 달리 합성 섬유는 조금만 뜨거워도 녹을 수 있습니다. 섬유에 따라 견디는 열이 다르다는 것이 이 맞섬의 뜻입니다.",
 "3) 끝 문장: «which is why the dial has settings rather than one heat»(그래서 그 다이얼에 온도 하나가 아니라 여러 설정이 있는 것이다). 'which is why'(그래서 ~인 것이다)로 글을 맺습니다. 글이 끝에서 풀어 주는 것은 다리미에 온도 설정이 여럿인 까닭입니다. 천마다 알맞은 온도가 다르기 때문입니다.",
 "4) 묶기: 'Cotton and linen'(면과 리넨)과 'Synthetic fibres'(합성 섬유) = 'fabrics'(천). 'settings rather than one heat'(온도 하나가 아니라 여러 설정) = 'different temperatures'(서로 다른 온도). 지문의 낱말을 다른 말로 묶은 것입니다."],
 "「다림질할 때 스팀을 쓰는 이유」가 가장 끌립니다. 첫 문장에 moisture(습기)가 나오기 때문입니다. 하지만 습기는 첫 문장에 한 번 나올 뿐이고, 둘째·셋째 문장은 섬유마다 견디는 열이 다르다는 이야기입니다. 「다리미가 스스로 온도를 조절하는 방법」도 조심합니다. 끝 문장에 dial(다이얼)이 나와서 끌리지만, 글은 다리미 속의 장치가 아니라 설정이 왜 여럿이어야 하는지를 말합니다.",
 ["지문에 없는 이야기입니다. 면과 합성 섬유가 나와서 끌리지만, 어떤 옷을 무슨 천으로 만드는지는 나오지 않습니다. 글이 다루는 것은 천마다 알맞은 다림질 온도가 다른 까닭입니다.",
  "끝 문장의 «which is why the dial has settings rather than one heat»가 근거입니다. 면과 리넨은 새 모양을 잘 지니지만 합성 섬유는 녹는 온도 가까이에서 부드러워집니다. 그래서 천마다 다른 온도로 다려야 합니다.",
  "지문에 없는 이야기입니다. 어떤 옷을 다려야 하는지는 나오지 않습니다. 글은 옷의 종류가 아니라 섬유가 열에 어떻게 움직이는지를 말합니다.",
  "끝 문장의 다이얼 때문에 끌립니다. 하지만 다리미가 온도를 어떻게 맞추는지는 나오지 않습니다. 글이 말하는 것은 설정이 왜 여럿이어야 하는가입니다.",
  "글의 한 부분만 봅니다. 첫 문장에 습기가 나오기는 합니다. 하지만 나머지 두 문장은 습기가 아니라 섬유마다 견디는 열이 다르다는 이야기입니다."],
 kofix={1: '천을 서로 다른 온도로 다리는 이유'})
swap(14, 1, 'why fabrics are ironed at different temperatures', ans_ok=True)

# ---------- 19번째: 탄산병을 열 때 소리가 나는 까닭 ----------
mk(18, 4, [
 "1) 되풀이: 「압력이 풀리면서 기체가 나온다」는 생각이 세 문장에 걸쳐 이어집니다. 탄산음료는 압력을 가해 기체를 녹인 채로 병에 담는다 → 뚜껑을 열면 그 압력이 순식간에 풀리고 갇혀 있던 기체가 밀려 나간다 → 천천히 열면 소리도 작고 빠지는 기체도 적다. 세 문장이 모두 병을 열 때 기체에 일어나는 일을 말합니다.",
 "2) 꺾이는 곳: 꺾이는 말은 없습니다. 대신 둘째 문장의 쌍점(:) 뒤가 풀이입니다. «the gas trapped above the drink rushes out, which is the sound»(음료 위에 갇혀 있던 기체가 밀려 나가는데, 그것이 그 소리다). 'which is the sound'(그것이 그 소리다)가 글이 풀어 주려는 것을 짚습니다. 소리의 정체입니다.",
 "3) 끝 문장: «A bottle opened slowly makes less noise and loses less gas.»(천천히 연 병은 소리를 덜 내고 기체를 덜 잃는다.) 끝 문장도 noise(소리)로 돌아옵니다. 압력이 한꺼번에 풀릴수록 소리가 크다는 것을 뒤집어 보여 줍니다.",
 "4) 묶기: 'bottled with gas dissolved under pressure'(압력을 가해 기체를 녹인 채 병에 담긴) = 'a sealed bottle'(밀봉된 병). 'Opening the cap'(뚜껑을 열기) = 'when opened'(열 때). 'the sound'와 'noise' = 'makes a noise'(소리를 낸다)."],
 "「공장에서 음료에 탄산을 넣는 방법」이 가장 끌립니다. 첫 문장이 압력을 가해 기체를 녹여 병에 담는다고 했기 때문입니다. 하지만 그것은 첫 문장 하나뿐이고, 어떻게 녹이는지는 나오지 않습니다. 나머지 문장은 모두 병을 여는 순간의 이야기입니다. 「기체를 가장 잘 가두는 용기의 종류」도 조심합니다. 기체를 덜 잃는다는 말이 끝에 나오지만, 용기를 견주는 내용은 없습니다.",
 ["지문에 없는 이야기입니다. 병에 담는다는 말에서 떠올린 것이지만, 병을 어떻게 막고 라벨을 붙이는지는 나오지 않습니다. 글이 다루는 것은 병을 여는 순간입니다.",
  "지문에 없는 이야기입니다. 탄산음료라는 낱말만 같습니다. 차게 두는 방법은 나오지 않습니다.",
  "지문에 없는 이야기입니다. 기체를 덜 잃는다는 끝 문장 때문에 끌리지만, 용기를 서로 견주는 내용은 없습니다.",
  "글의 한 부분만 봅니다. 첫 문장이 기체를 녹여 병에 담는다고 하기는 합니다. 하지만 어떻게 녹이는지는 나오지 않고, 나머지는 모두 병을 열 때의 이야기입니다.",
  "둘째 문장의 «the gas trapped above the drink rushes out, which is the sound»가 근거입니다. 뚜껑을 열면 압력이 풀리며 갇혀 있던 기체가 밀려 나가고, 그것이 소리입니다. 끝 문장도 천천히 열면 소리가 작다고 했습니다."],
 kofix={0: '유리병이 밀봉되고 라벨이 붙는 방법'})
E[('23', '5', 18)].update({'passage_ok': True,
 'text': ('Opening the cap releases that pressure in an instant, the gas comes out of solution as bubbles, and the sound is air rushing in to replace what left.',
          'Opening the cap releases that pressure in an instant: the gas trapped above the drink rushes out, which is the sound, and more comes out of solution as bubbles.'),
 'ko': ('뚜껑을 열면 그 압력이 순식간에 풀리고, 기체가 녹아 있던 상태에서 빠져나와 거품이 되며, 그 소리는 빠져나간 자리를 채우려 공기가 밀려드는 소리다.',
        '뚜껑을 열면 그 압력이 순식간에 풀린다. 음료 위에 갇혀 있던 기체가 밀려 나가는데 그것이 그 소리이고, 녹아 있던 기체가 더 빠져나와 거품이 된다.')})
