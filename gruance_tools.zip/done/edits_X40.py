# -*- coding: utf-8 -*-
# 294번: 33번(빈칸 추론) 레벨3 — 30문항을 다 읽고 세 문항을 바로잡음
# 레벨3의 33번은 세 문장짜리 글(바꾼 것 → 결과 → 빈칸). 서른 가운데 스물일곱은 답의 근거가 지문 안에 있음
# 지문에 단서를 넣되 낱말 수가 늘지 않게 다른 곳을 줄임 — 33번 레벨3은 평균 낱말 수가 길이 경고의 턱(31.7) 바로 아래(31.67)라, 서른 문항 통틀어 두 낱말만 늘어도 새 경고가 뜸
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새로 씀. 레벨3이므로 말끝은 「~어요」
#   17번째 — 빈칸 문장 'The problem had never been ______.'에 다섯 선택지가 모두 들어감(값·시간·방·나이도 지문에서 탈이라고 한 적이 없음)
#            → 첫 문장 '… why they had left; nearly all had enjoyed it but knew nobody there.'(활동은 즐거웠다는 근거를 넣음. 낱말 수는 늘리지 않음)
#   23번째 — 오답 'to arrange transport to the clinic'도 답으로 섬(교통편을 마련해 올 수 있게 됨)
#            → 첫 문장 'Patients reminded two days ahead missed fewer appointments than those reminded the night before, though no more came.'
#   27번째 — 정답(짐작)의 근거가 지문에 없어 오답 'the wishes of the staff alone'과 가를 수 없음(34번 25번째와 같은 글감·같은 탈 — 293번)
#            → 첫 문장 '… instead of running a programme staff thought they would enjoy.' / 둘째 문장 'Attendance rose by half; costs fell.'(낱말 수를 맞춤)
AUTO_SYNC = False
E = {}
from z8common import maker
mk = maker(E, '33', lv='3')
def fix(n, text, ko):
    E[('33', '3', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 17번째: 동아리를 그만둔 까닭 ----------
mk(16, 2, [
 "1) 빈칸 문장: 셋째 문장이에요. «The problem had never been»(그 문제는 한 번도 ~이 아니었다). never(한 번도 ~않다)가 있어요. 탈인 줄 알았지만 탈이 아니었던 것을 물어요.",
 "2) 짝꿍 문장: 첫 문장이에요. «nearly all had enjoyed it but knew nobody there»(거의 모두가 그것을 즐겼지만 거기서 아무도 알지 못했다). 앞은 좋았던 것이고 뒤는 탈이었던 것이에요. 활동은 즐거웠고, 아는 사람이 없는 것이 탈이었어요.",
 "3) 둘째 문장 확인: «Pairing each new member with an existing one for a month stopped the leaving.»(새 회원마다 기존 회원 한 명과 한 달 동안 짝지어 주자 그 떠남이 멈췄다.) 활동은 그대로 두고 아는 사람만 만들어 주었는데 떠나지 않게 되었어요. 활동이 탈이 아니었다는 것이 다시 확인돼요.",
 "4) 묶기: 'enjoyed it'(그것을 즐겼다) = 탈이 아니었던 것 = 'the activity itself'(활동 자체). 동아리에서 하는 일을 즐겼다는 말을 'the activity'(활동)로 바꾸어 말한 것이에요."],
 "「회원권의 값」이 가장 끌려요. 사람들이 그만두는 까닭으로 흔히 돈을 떠올리거든요. 하지만 값은 지문에 나오지 않아요. 지문이 탈이 아니었다고 알려 주는 것은 하나뿐이에요. 회원들이 즐겼다고 한 활동이에요. 「그 모임의 시간」도 같은 까닭으로 틀려요. 시간이 맞지 않았다는 말도, 맞았다는 말도 지문에 없어요.",
 [("회원권의 값", "지문에 없는 이야기예요. 값은 나오지 않아요. 지문이 탈이 아니었다고 알려 주는 것은 회원들이 즐겼다고 한 활동이에요."),
  ("그 모임의 시간", "지문에 없는 이야기예요. 모임 시간은 나오지 않아요."),
  ("활동 자체", "첫 문장의 «nearly all had enjoyed it but knew nobody there»가 근거예요. 회원들은 활동을 즐겼어요. 탈은 아는 사람이 없는 것이었고, 짝을 지어 주자 떠나지 않게 되었어요."),
  ("그 방의 크기", "지문에 없는 이야기예요. 방은 나오지 않아요."),
  ("회원들의 나이", "지문에 없는 이야기예요. 나이는 나오지 않아요. 탈은 아는 사람이 없다는 것이었어요.")])
fix(16, ('A club asked members why they had stopped coming and almost all said they had known nobody there.', 'A club asked members why they had left; nearly all had enjoyed it but knew nobody there.'),
        ('한 동아리가 회원들에게 왜 나오지 않게 되었는지 물었더니 거의 모두가 거기서 아는 사람이 없었다고 했다.', '한 동아리가 회원들에게 왜 그만두었는지 물었더니, 거의 모두가 활동은 즐거웠지만 거기서 아는 사람이 없었다고 했다.'))

# ---------- 23번째: 일찍 온 알림은 취소할 시간을 준다 ----------
mk(22, 0, [
 "1) 빈칸 문장: 둘째 문장이에요. «The earlier reminder gave them time»(더 이른 알림은 그들에게 ~할 시간을 주었다). 알림이 일찍 와서 환자들이 무엇을 할 수 있게 되었는지를 물어요.",
 "2) 짝꿍 문장: 첫 문장의 뒤쪽이에요. «though no more came»(더 많이 온 것은 아니었지만). though(~이지만)가 단서예요. 오는 사람이 늘지 않았는데도 어긴 예약이 줄었어요.",
 "3) 어떻게 그럴 수 있는지: 예약을 어긴다는 것은 말없이 안 오는 것이에요. 오는 사람은 그대로인데 어긴 예약이 줄었다면, 못 오는 사람이 말없이 안 오는 대신 미리 알렸다는 뜻이에요. 미리 알리면 그 자리는 다른 환자가 써요.",
 "4) 묶기: 못 온다고 미리 알려 자리를 내놓는다 = 'to cancel so that somebody else could come'(다른 누군가가 올 수 있도록 취소할). 지문에 없는 낱말로 바꾼 것이에요."],
 "「병원까지 갈 교통편을 마련할」이 가장 끌려요. 알림을 일찍 받으면 갈 준비를 할 수 있으니까요. 하지만 그렇다면 오는 사람이 늘었어야 해요. 지문은 오는 사람이 더 많아지지 않았다고 했어요. 「그 예약을 까맣게 잊을」은 뜻이 거꾸로예요. 잊으면 예약을 더 많이 어기게 돼요.",
 [("다른 누군가가 올 수 있도록 취소할", "첫 문장의 «though no more came»이 근거예요. 오는 사람은 늘지 않았는데 어긴 예약이 줄었어요. 못 오는 사람이 미리 취소해서 그 자리를 다른 환자가 썼다는 뜻이에요."),
  ("병원까지 갈 교통편을 마련할", "글과 어긋나요. 교통편을 마련해서 올 수 있게 되었다면 오는 사람이 늘었어야 해요. 지문은 오는 사람이 더 많아지지 않았다고 했어요."),
  ("물어볼 것을 미리 준비할", "지문에 없는 이야기예요. 물어볼 것을 준비한다고 어긴 예약이 줄지는 않아요."),
  ("그 편지를 한 번 더 읽을", "지문에 없는 이야기예요. 편지는 나오지 않아요."),
  ("그 예약을 까맣게 잊을", "방향이 거꾸로예요. 예약을 잊으면 어기는 일이 더 늘어요. 지문은 어긴 예약이 줄었다고 했어요.")])
fix(22, ('Patients given appointment reminders two days ahead missed far fewer appointments than those reminded the evening before.', 'Patients reminded two days ahead missed fewer appointments than those reminded the night before, though no more came.'),
        ('이틀 전에 예약 알림을 받은 환자들은 전날 저녁에 받은 환자들보다 예약을 훨씬 덜 어겼다.', '이틀 전에 알림을 받은 환자들은 전날 밤에 받은 환자들보다 예약을 덜 어겼는데, 오는 사람이 더 많아진 것은 아니었다.'))

# ---------- 27번째: 묻지 않고 짐작으로 짠 프로그램 ----------
mk(26, 3, [
 "1) 빈칸 문장: 셋째 문장이에요. «The earlier programme had been built on»(그 이전 프로그램은 ~을 바탕으로 짜여 있었다). 전의 프로그램을 무엇에 기대어 짰는지를 물어요.",
 "2) 짝꿍 문장: 첫 문장의 뒤쪽이에요. «a programme staff thought they would enjoy»(직원들이 그들이 즐기리라고 생각한 프로그램). thought(생각했다)가 단서예요. 물어본 것이 아니라 그럴 것이라고 생각한 것이에요.",
 "3) 앞과 뒤를 견주기: 새 방식은 «asked members what they wanted»(회원들에게 무엇을 원하는지 물었다)예요. 묻자 참석이 절반이나 늘었어요. 전에는 묻지 않고 미루어 생각했고, 그 생각이 잘 맞지 않았다는 뜻이에요.",
 "4) 묶기: 묻지 않고 그럴 것이라고 생각했다 = 'guesses about what they would like'(그들이 좋아할 것에 관한 짐작). 'thought'(생각했다)가 'guesses'(짐작)로 바뀌었어요."],
 "「직원들만의 바람」이 가장 끌려요. 직원이 프로그램을 짰으니 직원 마음대로 했다고 생각하기 쉽거든요. 하지만 지문은 직원들이 회원들이 즐기리라고 생각한 프로그램이라고 했어요. 직원이 바라는 것을 넣은 것이 아니라, 회원이 좋아할 것을 짐작한 것이에요. 「좋은 것을 하기에는 너무 적은 예산」은 돈 이야기가 나와서 끌리지만, 새 방식은 오히려 돈이 덜 들었어요.",
 [("좋은 것을 하기에는 너무 적은 예산", "글과 어긋나요. 회원들에게 묻자 활동에 드는 돈은 오히려 줄었어요. 돈이 모자란 것이 탈은 아니었어요."),
  ("직원들만의 바람", "글과 어긋나요. 지문은 직원들이 회원들이 즐기리라고 생각한 프로그램이라고 했어요. 직원 자신이 바라는 것을 넣은 것이 아니에요."),
  ("다른 청소년 동아리들이 내놓는 것", "지문에 없는 이야기예요. 다른 동아리는 나오지 않아요."),
  ("그들이 좋아할 것에 관한 짐작", "첫 문장의 «a programme staff thought they would enjoy»가 근거예요. 전에는 묻지 않고 회원들이 좋아할 것이라고 생각해서 짰어요. 묻자 참석이 늘었으니 그 짐작이 잘 맞지 않았던 것이에요."),
  ("그 강당에서 쓸 수 있는 공간", "지문에 없는 이야기예요. 공간은 나오지 않아요.")])
fix(26, ('A youth club asked its members what they wanted instead of announcing a programme. Attendance rose by half and the activities cost less.', 'A youth club asked members what they wanted instead of running a programme staff thought they would enjoy. Attendance rose by half; costs fell.'),
        ('한 청소년 동아리가 프로그램을 발표하는 대신 회원들에게 무엇을 원하는지 물었다. 참석이 절반 늘었고 활동비는 줄었다.', '한 청소년 동아리가 직원들이 회원들이 좋아하리라고 생각한 프로그램을 돌리는 대신 회원들에게 무엇을 원하는지 물었다. 참석이 절반 늘었고 비용은 줄었다.'))
