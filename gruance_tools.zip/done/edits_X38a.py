# -*- coding: utf-8 -*-
# 292번: 36-37번(글의 순서) 레벨3 — 30문항을 다 읽고 열여섯 문항을 바로잡음 (이 파일: 1~16번째 가운데 아홉 문항)
# 레벨3의 36-37번은 주어진 글 한 문장 + (A)(B)(C) 한 문장씩. 가리키는 말·이어 주는 말이 적어 다른 순서로도 읽히는 문항이 많음
# → 한 글에 가리키는 말·이어 주는 말을 넣어 순서를 하나로 묶음. 정답·선택지 변동 없음
# 고친 문항의 풀이(walk)·선택지별 해설(cn)은 새로 씀. 레벨3이므로 말끝은 「~어요」(z3common.py가 레벨1~3의 요령·머리말·맺음을 그 말끝으로 냄)
#   1번째  — (C)-(B)-(A)로도 읽힘(검사 → 표본 → 처리 → 재배자 기록) → (A) 'First, …' / (C) '… is then taken …' / (B) 'Any batch whose sample is above the limit …'
#   2번째  — (A)가 주어진 글 바로 뒤에도 옴(it = the water) → (A) '… removes most of that weight.'((C)의 heavy를 받음)
#   4번째  — (B)가 주어진 글 바로 뒤에도 옴 → (B) 'Mills therefore wet the cloth and let the fibres pull back before it is cut.'
#   7번째  — (B)-(C)-(A)로도 읽힘 → (C) 'That protection costs little, since the dividers are reused many times.'
#   9번째  — (C)-(B)-(A)로도 읽힘 → (C) 'Pressing the centre of such a lid …'
#   10번째 — (C)-(A)-(B)로도 읽힘(표준 모양 → 모양이 같아야 비교) → (A) 'Comparing such figures only works if the shape is the same.'
#   12번째 — (B)-(C)-(A)로도 읽힘(오히려 더 자연스러움) → (C) 'Nothing made before or after them can then be contaminated.'
#   14번째 — (A)가 주어진 글 바로 뒤에도 옴(They = crates) → (A) 'These plastic ones are folded flat …'
#   16번째 — (B)의 'Each stage'가 가리킬 과정이 지문 어디에도 없음(표백이라는 말이 없음) → (B) 'Bleaching removes it in stages, and each stage takes out a little more of the colour.'
AUTO_SYNC = False
E = {}
from z3common import maker
mk = maker(E, lv='3')
def fix(n, text, ko):
    E[('36_37', '3', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 1번째: 농산물 검사의 차례 ----------
mk(0, 'ACB', [
 "1) 주어진 글: 농산물은 가게에 닿기 전에 검사를 받는다고 해요. 이어서 검사가 어떤 차례로 이루어지는지가 나올 거예요.",
 "2) 첫째 글 (A): «First, growers record what they sprayed and when.»(먼저 재배자가 무엇을 언제 뿌렸는지 기록한다.) First(먼저)가 있으니 차례의 맨 앞이에요.",
 "3) 둘째 글 (C): «A small sample is then taken from each batch.»(그다음 각 묶음에서 작은 표본을 떼어 낸다.) then(그다음)이 앞에 다른 일이 있었다고 알려 줘요. 기록이 먼저이고 표본이 그다음이에요.",
 "4) 셋째 글 (B)와 확인: «Any batch whose sample is above the limit is held back»(표본이 기준치를 넘는 묶음은 보류된다). 'whose sample'(그 표본이)은 (C)에서 떼어 낸 표본이에요. 표본을 떼어 낸 뒤에야 넘는지 알 수 있어요. 기록 → 표본 → 처리로 맞물리므로 순서는 (A)-(C)-(B)예요."],
 "(C)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글이 검사를 말하니 표본 이야기가 바로 이어질 것 같거든요. 하지만 (C)에는 then(그다음)이 있어요. 그 앞에 다른 일이 하나 있어야 해요. First(먼저)가 붙은 (A)가 그 일이에요.",
 {'ACB': "(A)의 First가 차례의 처음을 알리고, (C)의 then이 그다음을 이어요. (B)의 'whose sample'은 (C)에서 떼어 낸 표본을 받아요. 기록, 표본, 처리의 차례예요.",
  'BAC': "(B)의 'whose sample'이 가리킬 표본이 앞에 없어요. 표본은 (C)에서 처음 나오므로 (B)가 맨 앞에 올 수 없어요.",
  'BCA': "(B)의 'whose sample'이 가리킬 표본이 앞에 없어요. 또 First가 붙은 (A)가 맨 끝에 오게 되어 차례가 맞지 않아요.",
  'CAB': "(C)의 then은 앞에 다른 일이 있어야 쓸 수 있는데, 주어진 글 바로 뒤에는 그런 일이 없어요. First가 붙은 (A)가 가운데에 오는 것도 맞지 않아요.",
  'CBA': "(C)의 then이 받을 앞의 일이 없고, First가 붙은 (A)가 맨 끝에 와요. 먼저 하는 일이 가장 나중에 나오게 돼요."})
fix(0, [('(A) Growers record what they sprayed and when.', '(A) First, growers record what they sprayed and when.'),
        ('(B) Anything above the limit is held back rather than sold.', '(B) Any batch whose sample is above the limit is held back rather than sold.'),
        ('(C) A small sample is taken from each batch.', '(C) A small sample is then taken from each batch.')],
       [('(A) 재배자는 무엇을 언제 뿌렸는지 기록한다.', '(A) 먼저 재배자가 무엇을 언제 뿌렸는지 기록한다.'),
        ('(B) 기준치를 넘는 것은 팔지 않고 보류한다.', '(B) 표본이 기준치를 넘는 묶음은 팔지 않고 보류한다.'),
        ('(C) 각 묶음에서 작은 표본을 떼어 낸다.', '(C) 그다음 각 묶음에서 작은 표본을 떼어 낸다.')])

# ---------- 2번째: 물을 빼고 실어 나르는 주스 ----------
mk(1, 'CAB', [
 "1) 주어진 글: 주스는 물을 빼면 실어 나르기가 더 쉽다고 해요. 왜 그런지, 물을 어떻게 빼는지가 이어질 거예요.",
 "2) 첫째 글 (C): «Fresh juice is mostly water and heavy to move.»(생주스는 대부분 물이고 옮기기에 무겁다.) 주어진 글의 까닭이에요. 물이 많아서 무겁다는 것을 먼저 말해요.",
 "3) 둘째 글 (A): «Gentle heat under low pressure removes most of that weight.»(낮은 압력에서의 약한 열이 그 무게의 대부분을 없앤다.) 'that weight'(그 무게)는 (C)의 heavy(무거운)를 받아요. 무겁다는 말이 먼저 나와야 「그 무게」라고 할 수 있어요.",
 "4) 셋째 글 (B)와 확인: «Water is added again at the far end.»(도착지에서 물을 다시 넣는다.) again(다시)은 물을 한 번 뺀 뒤에야 쓸 수 있는 말이에요. 무겁다 → 그 무게를 없앤다 → 물을 다시 넣는다로 맞물리므로 순서는 (C)-(A)-(B)예요."],
 "(A)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글이 물을 뺀다고 했으니 빼는 방법이 바로 이어질 것 같거든요. 하지만 (A)의 'that weight'(그 무게)가 가리킬 말이 주어진 글에는 없어요. 무겁다는 말은 (C)에 있어요.",
 {'ACB': "(A)의 'that weight'가 가리킬 무게가 주어진 글에 없어요. 무겁다는 말은 (C)에 나오므로 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)의 again은 물을 한 번 뺀 뒤에 쓰는 말이에요. 물을 빼는 (A)보다 먼저 오면 다시 넣을 것이 없어요.",
  'BCA': "(B)의 again이 받을 일이 앞에 없어요. 물을 빼는 이야기가 나오기 전에 다시 넣는다고 할 수 없어요.",
  'CAB': "(C)가 생주스는 물이 많아 무겁다고 하고, (A)의 'that weight'가 그 무게를 받아 없앤다고 해요. (B)의 again이 뺀 물을 다시 넣는다고 맺어요.",
  'CBA': "(C)로 시작하는 것은 맞아요. 하지만 물을 다시 넣는 (B)가 물을 빼는 (A)보다 먼저 와요. 빼기도 전에 다시 넣을 수는 없어요."})
fix(1, ('(A) Gentle heat under low pressure removes most of it.', '(A) Gentle heat under low pressure removes most of that weight.'),
       ('(A) 낮은 압력에서 약한 열로 그 대부분을 없앤다.', '(A) 낮은 압력에서 약한 열로 그 무게의 대부분을 없앤다.'))

# ---------- 4번째: 천을 미리 줄여 두는 까닭 ----------
mk(3, 'CBA', [
 "1) 주어진 글: 천은 처음 빨 때 줄어든다고 해요. 왜 줄어드는지, 그래서 어떻게 하는지가 이어질 거예요.",
 "2) 첫째 글 (C): «Fibres stretched during weaving pull back when wet.»(짤 때 늘어난 섬유가 젖으면 도로 줄어든다.) 주어진 글의 까닭이에요. 섬유가 여기 처음 나와요.",
 "3) 둘째 글 (B): «Mills therefore wet the cloth and let the fibres pull back before it is cut.»(그래서 공장은 그 천을 재단하기 전에 적셔서 그 섬유가 도로 줄어들게 한다.) therefore(그래서)가 (C)의 까닭을 받아요. 'the fibres'(그 섬유)와 'pull back'(도로 줄어든다)도 (C)에 나온 말이에요.",
 "4) 셋째 글 (A)와 확인: «A garment cut from treated cloth keeps its size.»(처리한 천으로 재단한 옷은 그 크기를 지킨다.) 'treated cloth'(처리한 천)는 (B)에서 미리 줄여 둔 천이에요. 까닭 → 미리 줄이기 → 결과로 맞물리므로 순서는 (C)-(B)-(A)예요."],
 "(B)를 맨 앞에 놓고 싶어질 수 있어요. 천이 줄어든다는 말 뒤에 그래서 공장은 어떻게 한다는 말이 이어져도 될 것 같거든요. 하지만 (B)에는 'the fibres'(그 섬유)가 있어요. 섬유는 (C)에서 처음 나오니 (C)가 먼저 와야 해요.",
 {'ACB': "(A)의 'treated cloth'는 미리 처리한 천인데, 처리하는 이야기인 (B)가 아직 나오지 않았어요. (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)의 'the fibres'가 가리킬 섬유가 앞에 없어요. 섬유는 (C)에서 처음 나오므로 (C)가 (B)보다 먼저 와야 해요.",
  'BCA': "(B)의 'the fibres'가 가리킬 섬유가 앞에 없어요. 까닭인 (C)가 그래서로 시작하는 (B)보다 뒤에 오는 것도 맞지 않아요.",
  'CAB': "(C)로 시작하는 것은 맞아요. 하지만 (A)의 'treated cloth'가 처리하는 이야기인 (B)보다 먼저 와요. 처리하기 전에 처리한 천이라고 할 수 없어요.",
  'CBA': "(C)가 섬유가 젖으면 줄어든다는 까닭을 말하고, (B)의 therefore가 그래서 미리 적셔 줄인다고 이어요. (A)의 'treated cloth'가 그렇게 처리한 천을 받아 결과로 맺어요."})
fix(3, ('(B) Mills therefore shrink the cloth before it is cut.', '(B) Mills therefore wet the cloth and let the fibres pull back before it is cut.'),
       ('(B) 그래서 공장은 천을 재단하기 전에 줄인다.', '(B) 그래서 공장은 천을 재단하기 전에 적셔서 섬유가 줄어들게 한다.'))

# ---------- 7번째: 병 사이의 칸막이 ----------
mk(6, 'BAC', [
 "1) 주어진 글: 병은 상자에 부딪혀서가 아니라 병끼리 부딪혀서 깨진다고 해요. 그렇다면 병끼리 닿지 않게 하는 방법이 이어질 거예요.",
 "2) 첫째 글 (B): «Card dividers separate each bottle from its neighbours.»(판지 칸막이가 병 하나하나를 그 이웃들과 떼어 놓는다.) 주어진 글의 탈에 대한 해결이에요. 칸막이가 여기 처음 나와요.",
 "3) 둘째 글 (A): «A full crate then rattles without any glass touching glass.»(그러면 가득 찬 상자가 덜그럭거려도 유리가 유리에 닿지 않는다.) then(그러면)이 칸막이를 넣은 결과를 말해요.",
 "4) 셋째 글 (C)와 확인: «That protection costs little, since the dividers are reused many times.»(그 보호는 돈이 적게 드는데, 그 칸막이를 여러 번 다시 쓰기 때문이다.) 'That protection'(그 보호)은 (A)의 유리끼리 닿지 않게 되는 것을 가리켜요. 해결 → 결과 → 비용으로 맞물리므로 순서는 (B)-(A)-(C)예요."],
 "(B) 바로 뒤에 (C)를 놓고 싶어질 수 있어요. 둘 다 칸막이 이야기라서 이어질 것 같거든요. 하지만 (C)는 'That protection'(그 보호)으로 시작해요. 무엇을 보호하는지는 (A)에 나와요. 유리가 유리에 닿지 않는다는 말이 먼저 있어야 해요.",
 {'ACB': "(A)의 then은 앞에 한 일이 있어야 쓸 수 있어요. 칸막이를 넣는 (B)가 아직 나오지 않았으니 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)가 칸막이로 병을 떼어 놓는다고 하고, (A)의 then이 그러면 유리끼리 닿지 않는다고 이어요. (C)의 'That protection'이 그 보호를 받아 돈이 적게 든다고 맺어요.",
  'BCA': "(B)로 시작하는 것은 맞아요. 하지만 (C)의 'That protection'이 가리킬 보호가 (A)에 나오는데, (A)가 그 뒤에 와요. 가리키는 말이 먼저 나오게 돼요.",
  'CAB': "(C)의 'That protection'과 'the dividers'가 가리킬 것이 주어진 글에 없어요. 칸막이도 보호도 아직 나오지 않았어요.",
  'CBA': "(C)의 'That protection'이 가리킬 것이 앞에 없어요. 칸막이를 처음 말하는 (B)보다 먼저 올 수 없어요."})
fix(6, ('(C) The dividers cost little and are reused many times.', '(C) That protection costs little, since the dividers are reused many times.'),
       ('(C) 칸막이는 싸고 여러 번 다시 쓴다.', '(C) 그 보호는 돈이 적게 드는데, 칸막이를 여러 번 다시 쓰기 때문이다.'))

# ---------- 9번째: 열린 적이 있는 병을 알아보는 법 ----------
mk(8, 'ACB', [
 "1) 주어진 글: 병은 열린 적이 있는지를 보여 준다고 해요. 어떻게 보여 주는지가 이어질 거예요.",
 "2) 첫째 글 (A): «The lid is drawn down by a vacuum as the contents cool.»(내용물이 식으면서 진공이 그 뚜껑을 아래로 당긴다.) 뚜껑이 어떻게 되어 있는지를 먼저 말해요. 뚜껑이 아래로 당겨져 있어요.",
 "3) 둘째 글 (C): «Pressing the centre of such a lid gives no movement while the seal holds.»(밀봉이 유지되는 동안에는 그런 뚜껑의 가운데를 눌러도 움직임이 없다.) 'such a lid'(그런 뚜껑)는 (A)의 아래로 당겨진 뚜껑이에요. 그 말이 먼저 나와야 그런 뚜껑이라고 할 수 있어요.",
 "4) 셋째 글 (B)와 확인: «A lid that clicks has lost its seal.»(딸깍 소리가 나는 뚜껑은 그 밀봉을 잃은 것이다.) (C)의 움직이지 않는 뚜껑과 맞서는 경우예요. 밀봉이 유지되면 안 움직이고, 풀리면 딸깍거려요. 당겨짐 → 안 움직임 → 딸깍거리면 풀린 것으로 맞물리므로 순서는 (A)-(C)-(B)예요."],
 "(C)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글이 병이 보여 준다고 했으니 눌러 보는 방법이 바로 이어질 것 같거든요. 하지만 (C)에는 'such a lid'(그런 뚜껑)가 있어요. 어떤 뚜껑인지는 (A)에 나와요.",
 {'ACB': "(A)가 뚜껑이 진공으로 아래로 당겨진다고 하고, (C)의 'such a lid'가 그런 뚜껑을 받아 눌러도 움직이지 않는다고 해요. (B)가 그와 맞서는 딸깍거리는 뚜껑으로 맺어요.",
  'BAC': "(B)가 맨 앞에 오면 딸깍 소리가 왜 밀봉이 풀린 표시인지 알 수 없어요. 뚜껑이 당겨져 있다는 (A)와 눌러도 움직이지 않는다는 (C)가 먼저 있어야 해요.",
  'BCA': "(B)가 맨 앞에 와서 까닭 없이 결론부터 나와요. 또 (C)의 'such a lid'가 가리킬 (A)가 그 뒤에 와요.",
  'CAB': "(C)의 'such a lid'가 가리킬 뚜껑이 주어진 글에 없어요. 아래로 당겨진 뚜껑은 (A)에서 나오므로 (C)가 맨 앞에 올 수 없어요.",
  'CBA': "(C)의 'such a lid'가 가리킬 것이 앞에 없어요. 뚜껑이 어떻게 되어 있는지를 말하는 (A)가 맨 끝에 오게 돼요."})
fix(8, ('(C) Pressing the centre gives no movement while the seal holds.', '(C) Pressing the centre of such a lid gives no movement while the seal holds.'),
       ('(C) 밀봉이 유지되는 동안에는 가운데를 눌러도 움직이지 않는다.', '(C) 밀봉이 유지되는 동안에는 그런 뚜껑의 가운데를 눌러도 움직이지 않는다.'))

# ---------- 10번째: 당겨서 끊어 재는 강도 ----------
mk(9, 'CBA', [
 "1) 주어진 글: 재료는 당겨서 끊어 보아 강도를 잰다고 해요. 그 시험을 어떻게 하는지가 이어질 거예요.",
 "2) 첫째 글 (C): «A sample is cut to a standard shape and gripped at both ends.»(표본을 표준 모양으로 잘라 양 끝을 붙잡는다.) 시험의 첫 단계예요. 표본을 준비해요.",
 "3) 둘째 글 (B): «The machine records the force at the moment it breaks.»(그 기계는 그것이 끊어지는 순간의 힘을 기록한다.) 여기서 끊어지는 것은 (C)의 표본이에요. 붙잡은 표본을 당겨서 끊어지는 순간의 힘을 적어요.",
 "4) 셋째 글 (A)와 확인: «Comparing such figures only works if the shape is the same.»(그런 수치를 견주는 것은 모양이 같을 때만 통한다.) 'such figures'(그런 수치)는 (B)에서 기록한 힘이에요. 수치가 나온 뒤에야 견줄 수 있어요. 준비 → 기록 → 견주기로 맞물리므로 순서는 (C)-(B)-(A)예요."],
 "(C) 바로 뒤에 (A)를 놓고 싶어질 수 있어요. (C)에 표준 모양이 나오고 (A)에 모양이 같아야 한다는 말이 나와서 이어질 것 같거든요. 하지만 (A)는 'such figures'(그런 수치)를 견준다고 해요. 수치는 (B)에서 기록해요. 그러니 (B)가 (A)보다 먼저 와야 해요.",
 {'ACB': "(A)의 'such figures'가 가리킬 수치가 주어진 글에 없어요. 수치는 (B)에서 기록하므로 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)에서 끊어지는 것은 표본인데, 표본이 앞에 없어요. 표본은 (C)에서 나오므로 (C)가 (B)보다 먼저 와야 해요.",
  'BCA': "(B)에서 끊어지는 표본이 앞에 없어요. 또 표본을 준비하는 (C)가 힘을 기록하는 (B)보다 뒤에 와서 차례가 거꾸로예요.",
  'CAB': "(C)로 시작하는 것은 맞아요. 하지만 (A)의 'such figures'가 가리킬 수치는 (B)에 나오는데, (B)가 그 뒤에 와요. 가리키는 말이 먼저 나오게 돼요.",
  'CBA': "(C)가 표본을 준비하고, (B)가 그것이 끊어지는 순간의 힘을 기록해요. (A)의 'such figures'가 그 수치를 받아 모양이 같아야 견줄 수 있다고 맺어요."})
fix(9, ('(A) Comparing materials only works if the shape is the same.', '(A) Comparing such figures only works if the shape is the same.'),
       ('(A) 재료를 비교하는 것은 모양이 같을 때만 의미가 있다.', '(A) 그런 수치를 비교하는 것은 모양이 같을 때만 의미가 있다.'))

# ---------- 12번째: 견과류 제품은 마지막에 ----------
mk(11, 'BAC', [
 "1) 주어진 글: 한 생산 라인이 하루에 여러 조리법을 돌릴 수 있다고 해요. 여러 가지를 한 줄에서 만들면 섞일 걱정이 생겨요. 그것을 어떻게 막는지가 이어질 거예요.",
 "2) 첫째 글 (B): «Products containing nuts are run last.»(견과류가 든 제품은 마지막에 돌린다.) 하루의 차례를 정해요. 견과류 제품이 맨 끝이에요.",
 "3) 둘째 글 (A): «The line is then cleaned before the next day begins.»(그런 다음 다음 날이 시작되기 전에 그 라인을 청소한다.) then(그런 다음)은 (B)의 마지막 제품을 돌린 뒤라는 뜻이에요.",
 "4) 셋째 글 (C)와 확인: «Nothing made before or after them can then be contaminated.»(그러면 그것들 앞에 만든 것도 뒤에 만든 것도 오염될 수 없다.) them(그것들)은 (B)의 견과류 제품이에요. 앞에 만든 것은 (B) 덕분에, 뒤에 만든 것은 (A)의 청소 덕분에 괜찮아요. 두 가지가 다 나온 뒤에야 할 수 있는 말이에요. 마지막에 돌리기 → 청소 → 결과로 맞물리므로 순서는 (B)-(A)-(C)예요."],
 "(B) 바로 뒤에 (C)를 놓고 싶어질 수 있어요. 견과류를 마지막에 돌리면 앞에 만든 것은 괜찮다는 말이 바로 이어질 것 같거든요. 하지만 (C)는 뒤에 만든 것도 괜찮다고 해요. 뒤에 만든 것이 괜찮으려면 (A)의 청소가 먼저 나와야 해요.",
 {'ACB': "(A)의 then은 앞에 한 일이 있어야 쓸 수 있어요. 마지막에 돌리는 (B)가 아직 나오지 않았으니 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)가 견과류 제품을 마지막에 돌린다고 하고, (A)의 then이 그런 다음 청소한다고 이어요. (C)가 그러면 그 앞에 만든 것도 뒤에 만든 것도 괜찮다고 맺어요.",
  'BCA': "(B)로 시작하는 것은 맞아요. 하지만 (C)가 뒤에 만든 것도 오염될 수 없다고 하는데, 그 까닭인 청소가 (A)에 나와요. (A)가 (C)보다 먼저 와야 해요.",
  'CAB': "(C)의 them이 가리킬 견과류 제품이 주어진 글에 없어요. (B)가 먼저 나와야 해요.",
  'CBA': "(C)의 them이 가리킬 것이 앞에 없어요. 또 청소하는 (A)가 맨 끝에 와서, 청소하기도 전에 뒤에 만든 것이 괜찮다고 말하게 돼요."})
fix(11, ('(C) Anything made earlier cannot have been contaminated.', '(C) Nothing made before or after them can then be contaminated.'),
        ('(C) 더 먼저 만든 것은 무엇이든 오염되었을 수 없다.', '(C) 그러면 그것들 앞에 만든 것도 뒤에 만든 것도 오염될 수 없다.'))

# ---------- 14번째: 여러 해를 오가는 플라스틱 상자 ----------
mk(13, 'CAB', [
 "1) 주어진 글: 어떤 상자는 여러 해 동안 오간다고 해요. 어떤 상자가 그런지, 왜 그렇게 쓰는지가 이어질 거예요.",
 "2) 첫째 글 (C): «Plastic crates cost far more than cardboard at the start.»(플라스틱 상자는 처음에는 판지보다 훨씬 비싸다.) 주어진 글의 그 상자가 플라스틱 상자라는 것을 알려 줘요.",
 "3) 둘째 글 (A): «These plastic ones are folded flat for the return journey.»(이 플라스틱 상자들은 돌아오는 길에는 납작하게 접힌다.) 'These plastic ones'(이 플라스틱 상자들)가 (C)의 'Plastic crates'를 받아요. 플라스틱이라는 말이 먼저 나와야 해요.",
 "4) 셋째 글 (B)와 확인: «The saving appears only where the route is fixed.»(그 절약은 경로가 정해진 곳에서만 나타난다.) 'The saving'(그 절약)은 비싼 상자를 접어서 되돌려 받아 여러 번 쓰는 데서 나와요. (C)의 비용과 (A)의 되돌아옴이 다 나온 뒤에 할 수 있는 말이에요. 비쌈 → 접어서 돌아옴 → 절약으로 맞물리므로 순서는 (C)-(A)-(B)예요."],
 "(A)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글이 상자가 오간다고 했으니 돌아오는 길 이야기가 바로 이어질 것 같거든요. 하지만 (A)는 'These plastic ones'(이 플라스틱 상자들)로 시작해요. 플라스틱이라는 말은 (C)에 처음 나와요.",
 {'ACB': "(A)의 'These plastic ones'가 가리킬 플라스틱 상자가 주어진 글에 없어요. 플라스틱은 (C)에서 처음 나오므로 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)의 'The saving'이 가리킬 절약이 앞에 없어요. 무엇이 비싸고 어떻게 되돌아오는지가 나오기 전이에요.",
  'BCA': "(B)의 'The saving'이 가리킬 것이 앞에 없어요. 비용을 말하는 (C)와 되돌아옴을 말하는 (A)가 먼저 나와야 해요.",
  'CAB': "(C)가 플라스틱 상자는 처음에 비싸다고 하고, (A)의 'These plastic ones'가 그것을 받아 접혀서 돌아온다고 해요. (B)의 'The saving'이 그렇게 여러 번 써서 얻는 절약으로 맺어요.",
  'CBA': "(C)로 시작하는 것은 맞아요. 하지만 (B)의 절약은 상자가 되돌아와 다시 쓰이는 데서 나와요. 되돌아옴을 말하는 (A)가 (B)보다 먼저 와야 해요."})
fix(13, ('(A) They are folded flat for the return journey.', '(A) These plastic ones are folded flat for the return journey.'),
        ('(A) 돌아오는 길에는 납작하게 접힌다.', '(A) 이 플라스틱 상자들은 돌아오는 길에는 납작하게 접힌다.'))

# ---------- 16번째: 갈색 펄프와 표백 ----------
mk(15, 'CBA', [
 "1) 주어진 글: 펄프는 갈색으로 나온다고 해요. 왜 갈색인지, 어떻게 희게 하는지가 이어질 거예요.",
 "2) 첫째 글 (C): «The brown comes from lignin holding the fibres together.»(그 갈색은 섬유를 붙들고 있는 리그닌에서 온다.) 'The brown'(그 갈색)이 주어진 글의 brown을 받아 까닭을 대요.",
 "3) 둘째 글 (B): «Bleaching removes it in stages»(표백은 그것을 여러 단계에 걸쳐 없앤다). 여기서 없애는 것은 (C)의 리그닌이에요. 리그닌이 먼저 나와야 그것을 없앤다고 할 수 있어요.",
 "4) 셋째 글 (A)와 확인: «Paper that need not be white skips the whole sequence.»(흴 필요가 없는 종이는 그 과정 전체를 건너뛴다.) 'the whole sequence'(그 과정 전체)는 (B)의 여러 단계예요. 단계 이야기가 먼저 나와야 해요. 까닭 → 표백 단계 → 건너뛰는 경우로 맞물리므로 순서는 (C)-(B)-(A)예요."],
 "(B)를 맨 앞에 놓고 싶어질 수 있어요. 갈색으로 나온다는 말 뒤에 표백 이야기가 바로 이어질 것 같거든요. 하지만 (B)가 없앤다고 하는 그것은 색이 아니라 리그닌이에요. 색은 같은 글 뒤쪽에서 'the colour'라고 따로 말해요. 리그닌은 (C)에 처음 나와요.",
 {'ACB': "(A)의 'the whole sequence'가 가리킬 과정이 주어진 글에 없어요. 여러 단계는 (B)에서 나오므로 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)가 없앤다고 하는 리그닌이 앞에 없어요. 리그닌은 (C)에서 처음 나오므로 (C)가 (B)보다 먼저 와야 해요.",
  'BCA': "(B)가 없앤다고 하는 것이 앞에 없어요. 또 갈색의 까닭인 (C)가 그것을 없애는 (B)보다 뒤에 와서 차례가 거꾸로예요.",
  'CAB': "(C)로 시작하는 것은 맞아요. 하지만 (A)의 'the whole sequence'가 가리킬 단계들은 (B)에 나오는데, (B)가 그 뒤에 와요.",
  'CBA': "(C)가 갈색이 리그닌에서 온다고 하고, (B)가 그 리그닌을 표백이 단계마다 없앤다고 해요. (A)의 'the whole sequence'가 그 단계들을 받아 맺어요."})
fix(15, ('(B) Each stage removes a little more of the colour.', '(B) Bleaching removes it in stages, and each stage takes out a little more of the colour.'),
        ('(B) 단계마다 색이 조금씩 더 빠진다.', '(B) 표백은 그것을 여러 단계에 걸쳐 없애고, 단계마다 색이 조금씩 더 빠진다.'))
