# -*- coding: utf-8 -*-
# 310번: 35번(무관한 문장) 레벨2 — 새 레벨 기준으로 다시 씀 (뒤 절반: 16~30번째). 선생님 말씀(「섞읍시다」)에 따라 단문과 이은 문장을 섞음
# 레벨2의 기준(LEVEL_GUIDE.md): 기초 생활 낱말 · 단문 둘을 and·but·so·or로 이은 문장 · 문장당 10~15낱말
#   - 종속접속사(because·when·if)·관계사절·분사구문은 쓰지 않음. 문항마다 여섯 문장 가운데 다섯쯤이 and·but·so·or로 이은 문장
# 글감·정답 번호·무관한 문장의 내용은 줄이기 전 지문(restore35.py) 그대로
# 지문·해석·풀이·해설은 data_X51b.json에 둠(글이 길어 파이썬 글자열로 적으면 따옴표가 엉키기 쉬움)
AUTO_SYNC = False
E = {}
import json, os
from z35common import maker, _tb
LV = '2'
mk = maker(E, lv=LV)
_here = os.path.dirname(os.path.abspath(__file__))
_p = next(p for p in (os.path.join(_here, 'data_X51b.json'), os.path.join(_here, '..', 'data_X51b.json'), 'data_X51b.json') if os.path.exists(p))   # 수정안이 pending/·done/에 있어도 찾도록
_D = json.load(open(_p, encoding='utf-8'))
def rw(n, text, ko, steps, confuse, cn):
    mk(n, steps, confuse, cn); e = E.pop(('35', LV, n))
    assert all(c in text for c in '①②③④⑤') and all(c in ko for c in '①②③④⑤'), n
    E[('35', LV, n)] = {'passage_ok': True, 'ans_ok': True,
                        'rewrite': {'text': text, 'choices': list(_tb['35'][LV][n]['choices']), 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}
for _i in range(15):
    _s, _c, _cn = _D['x'][_i]
    rw(15 + _i, _D['text'][_i], _D['ko'][_i], _s, _c, _cn)
