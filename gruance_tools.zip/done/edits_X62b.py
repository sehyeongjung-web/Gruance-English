# -*- coding: utf-8 -*-
# 333번: 36-37번(글의 순서) 레벨1 뒤 절반 — 단순문장 · 한 문장 10~15낱말 · 세 덩이 각 두 문장. 정답 번호·선택지·발문은 바탕 그대로, 지문·해석·풀이·해설을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z3637common import maker
rw = maker(E, '1')

# 16번째 (정답 순서 CBA)
rw(15, 'Eric joined a swim class at the city pool last July.',
   {'A': ['That first float gave him a great deal of courage in class.', 'By August, he swam across the whole pool without any help.'],
 'B': ['She told him to lie flat on the cool water.', 'After three tries, Eric floated on his back for ten seconds.'],
 'C': ['At first, Eric held the wall tightly with both hands.', 'His teacher, Ms. Lee, stood next to him in the water.']},
   '에릭은 지난 칠월에 시내 수영장의 수영반에 들어갔다.',
   {'A': ['그 첫 뜨기는 그에게 수영반에서 큰 용기를 주었다.', '팔월이 되자 그는 아무 도움 없이 수영장 전체를 헤엄쳐 건넜다.'],
 'B': ['그녀는 그에게 시원한 물 위에 납작하게 누우라고 말했다.', '세 번 시도한 끝에 에릭은 등을 대고 십 초 동안 물에 떴다.'],
 'C': ['처음에 에릭은 양손으로 벽을 꼭 잡고 있었다.', '그의 선생님인 리 선생님이 물속에서 그의 옆에 서 있었다.']},
   ['1) 주어진 글: 에릭이 지난 칠월에 시내 수영장의 수영반에 들어갔다고 해요. 이어서 수영반에서 에릭에게 생긴 일이 나올 거예요.',
 "2) 첫째 글 (C): «At first, Eric held the wall tightly with both hands.»(처음에 에릭은 양손으로 벽을 꼭 잡고 있었다.) 'Eric'은 주어진 글의 에릭이고, 앞의 것을 가리키는 말이 없어요. 수영을 막 배우기 시작한 때라 이야기의 처음으로 알맞아요. (C)는 «His teacher, Ms. Lee, "
 'stood next to him in the water.»(그의 선생님인 리 선생님이 물속에서 그의 옆에 서 있었다.)로 끝나요.',
 "3) 둘째 글 (B): «She told him to lie flat on the cool water.»(그녀는 그에게 시원한 물 위에 납작하게 누우라고 말했다.) 'She'(그녀)는 주어진 글에 없던 여자예요. (C)의 끝에 나온 'Ms. Lee'(리 선생님)가 바로 그 사람이에요. (B)는 에릭이 세 번 시도한 끝에 십 초 동안 등을 대고 물에 "
 '떴다는 말로 끝나요.',
 "4) 셋째 글 (A)와 확인: «That first float gave him a great deal of courage in class.»(그 첫 뜨기는 그에게 수영반에서 큰 용기를 주었다.) 'That first float'(그 첫 뜨기)는 (B)의 끝에서 에릭이 처음 물에 뜬 일이에요. 벽을 잡고 있음 → 선생님이 눕게 함 → 처음으로 뜸 → "
 '혼자 수영함. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(B)-(A)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)에 주어진 글과 같은 'class'(수영반)와 'pool'(수영장)이 있고, 수영을 해냈다는 반가운 결말이 바로 이어질 것 같거든요. 하지만 (A)는 'That first float'(그 첫 뜨기)로 시작해요. 주어진 글에는 뜨는 일이 나오지 않아요. 뜨는 일은 (B)의 끝에 처음 나와요. (B)도 'She'(그녀)로 시작하는데, 주어진 글에는 에릭 말고 다른 사람이 나오지 않아요.",
   ["(A)의 'That first float'(그 첫 뜨기)가 가리킬 일이 주어진 글에 없어요. 뜨는 일은 (B)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'She'(그녀)가 가리킬 사람이 주어진 글에 없어요. 주어진 글에는 에릭만 나와요. 'Ms. Lee'(리 선생님)는 (C)의 끝에 처음 나와요.",
 "(B)의 'She'(그녀)가 가리킬 사람이 앞에 없어요. 리 선생님은 (C)의 끝에 나오므로 (B)는 (C) 뒤에 와야 해요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (A)가 오면 'That first float'(그 첫 뜨기)가 가리킬 일이 없어요. (C)에는 벽을 잡고 있었다는 말뿐이고, 뜬 일은 (B)에 있어요.",
 "(C)의 끝에 나온 'Ms. Lee'(리 선생님)를 (B)의 'She'(그녀)가 받아요. (B)의 끝에서 처음 물에 뜬 일을 (A)의 'That first float'(그 첫 뜨기)가 받아요. 두 군데가 다 맞물려요."],
   'tightly 꼭, 단단히 / float 물에 뜨다, 뜨기 / courage 용기')

# 17번째 (정답 순서 CBA)
rw(16, 'A small bean seed can grow into a tall green plant.',
   {'A': ['Now the young plant stands firmly on that deep root.', 'A thin green stem rises from the seed toward the sun.'],
 'B': ['Soon a tiny white root comes out of the soft seed.', 'That white root grows deep into the dark soil below.'],
 'C': ['The seed first takes in water from the wet soil.', 'The water makes the hard outside of the seed soft.']},
   '작은 콩 씨앗은 키가 큰 초록색 식물로 자랄 수 있다.',
   {'A': ['이제 어린 식물은 그 깊은 뿌리 위에 단단히 서 있다.', '가느다란 초록 줄기가 씨앗에서 해를 향해 올라온다.'],
 'B': ['곧 작고 하얀 뿌리가 그 부드러워진 씨앗에서 나온다.', '그 하얀 뿌리는 아래쪽 어두운 흙 속으로 깊이 자란다.'],
 'C': ['씨앗은 먼저 젖은 흙에서 물을 빨아들인다.', '그 물은 씨앗의 딱딱한 겉을 부드럽게 만든다.']},
   ['1) 주어진 글: 작은 콩 씨앗이 키 큰 초록색 식물로 자랄 수 있다고 해요. 이어서 씨앗이 어떻게 자라는지가 나올 거예요.',
 "2) 첫째 글 (C): «The seed first takes in water from the wet soil.»(씨앗은 먼저 젖은 흙에서 물을 빨아들인다.) 'The seed'(그 씨앗)은 주어진 글의 콩 씨앗이에요. 'first'(먼저)가 있어서 자라는 일의 첫 단계로 알맞아요. (C)는 «The water makes the hard "
 'outside of the seed soft.»(그 물은 씨앗의 딱딱한 겉을 부드럽게 만든다.)로 끝나요.',
 "3) 둘째 글 (B): «Soon a tiny white root comes out of the soft seed.»(곧 작고 하얀 뿌리가 그 부드러워진 씨앗에서 나온다.) 'the soft seed'(그 부드러워진 씨앗)은 (C)의 끝에서 겉이 부드러워진 씨앗이에요. (B)는 하얀 뿌리가 어두운 흙 속으로 깊이 자란다는 말로 끝나요.",
 "4) 셋째 글 (A)와 확인: «Now the young plant stands firmly on that deep root.»(이제 어린 식물은 그 깊은 뿌리 위에 단단히 서 있다.) 'that deep root'(그 깊은 뿌리)는 (B)의 끝에서 깊이 자란 뿌리예요. 물을 먹음 → 뿌리가 나옴 → 뿌리가 깊이 자람 → 줄기가 올라옴. 앞 글의 "
 '끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(B)-(A)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)에 주어진 글과 같은 'plant'(식물)이 있고, 식물이 서 있는 모습이 씨앗이 자란 결과처럼 보이거든요. 하지만 (A)는 'that deep root'(그 깊은 뿌리)로 이어져요. 주어진 글에는 뿌리가 나오지 않아요. 뿌리는 (B)에서 처음 나오니 (B)가 (A) 앞에 와야 해요.",
   ["(A)의 'that deep root'(그 깊은 뿌리)가 가리킬 뿌리가 주어진 글에 없어요. 뿌리는 (B)의 첫 문장에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'the soft seed'(그 부드러워진 씨앗)이 가리킬 일이 주어진 글에 없어요. 씨앗의 겉이 부드러워지는 일은 (C)에 나와요. 어린 식물이 뿌리 위에 선 뒤에 씨앗이 '먼저' 물을 빨아들이는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(B)의 'the soft seed'(그 부드러워진 씨앗)이 가리킬 일이 앞에 없어요. 또 뿌리가 나온 뒤에 씨앗이 '먼저' 물을 빨아들이는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (A)가 오면 'that deep root'(그 깊은 뿌리)가 가리킬 뿌리가 없어요. 뿌리는 (B)에서 처음 나와요.",
 "(C)의 끝에서 겉이 부드러워진 씨앗을 (B)가 'the soft seed'(그 부드러워진 씨앗)으로 받아요. (B)의 끝에서 깊이 자란 뿌리를 (A)가 'that deep root'(그 깊은 뿌리)로 받아요. 두 군데가 다 맞물려요."],
   'root 뿌리 / stem 줄기 / soil 흙')

# 18번째 (정답 순서 BCA)
rw(17, 'Nari wanted to make a birthday card for her grandmother.',
   {'A': ["On Saturday morning, the blue envelope reached her grandmother's house.", 'Her grandmother smiled warmly at the poem for a long time.'],
 'B': ['At home, she cut a large heart from red paper.', 'She wrote a short poem inside the heart in black ink.'],
 'C': ["That poem told a small story about her grandmother's old garden.", 'Last of all, she put the card in a blue envelope.']},
   '나리는 할머니를 위해 생일 카드를 만들고 싶었다.',
   {'A': ['토요일 아침에 그 파란 봉투가 할머니 댁에 도착했다.', '할머니는 그 시를 보며 오랫동안 따뜻하게 웃으셨다.'],
 'B': ['집에서 그녀는 빨간 종이로 큰 하트를 오렸다.', '그녀는 하트 안쪽에 검은 잉크로 짧은 시를 썼다.'],
 'C': ['그 시는 할머니의 오래된 정원에 대한 작은 이야기를 들려주었다.', '마지막으로 그녀는 카드를 파란 봉투에 넣었다.']},
   ['1) 주어진 글: 나리가 할머니께 드릴 생일 카드를 만들고 싶었다고 해요. 이어서 카드를 어떻게 만들었는지가 나올 거예요.',
 "2) 첫째 글 (B): «At home, she cut a large heart from red paper.»(집에서 그녀는 빨간 종이로 큰 하트를 오렸다.) 'she'(그녀)는 주어진 글의 나리예요. 카드 만들기의 처음 일이라 알맞아요. (B)는 «She wrote a short poem inside the heart in black "
 'ink.»(그녀는 하트 안쪽에 검은 잉크로 짧은 시를 썼다.)로 끝나요.',
 "3) 둘째 글 (C): «That poem told a small story about her grandmother's old garden.»(그 시는 할머니의 오래된 정원에 대한 작은 이야기를 들려주었다.) 'That poem'(그 시)은 (B)의 끝에서 쓴 시예요. (C)는 카드를 파란 봉투에 넣었다는 말로 끝나요.",
 "4) 셋째 글 (A)와 확인: «On Saturday morning, the blue envelope reached her grandmother's house.»(토요일 아침에 그 파란 봉투가 할머니 댁에 도착했다.) 'the blue envelope'(그 파란 봉투)는 (C)의 끝에서 카드를 넣은 봉투예요. 하트를 오림 → 시를 씀 → 봉투에 넣음 "
 '→ 봉투가 도착함 → 할머니가 시를 보고 웃으심. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(C)-(A)예요.'],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. (C)에 'her grandmother's'(할머니의)와 'card'(카드)가 있어서 주어진 글의 카드·할머니 이야기와 바로 이어질 것 같거든요. 하지만 (C)는 'That poem'(그 시)으로 시작해요. 주어진 글에는 시가 나오지 않아요. 시는 (B)의 끝에 처음 나와요. (A)도 첫 문장에 'the blue envelope'(그 파란 봉투)가 나오는데, 파란 봉투는 (C)의 끝에 처음 나와요.",
   ["(A)의 'the blue envelope'(그 파란 봉투)가 가리킬 봉투가 주어진 글에 없어요. 파란 봉투는 (C)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (A)가 오면 'the blue envelope'(그 파란 봉투)가 가리킬 봉투가 없어요. (B)에는 하트와 시 이야기만 있어요.",
 "(B)의 끝에서 쓴 시를 (C)가 'That poem'(그 시)으로 받아요. (C)의 끝에서 카드를 넣은 파란 봉투를 (A)가 'the blue envelope'(그 파란 봉투)로 받아요. 두 군데가 다 맞물려요.",
 "(C)의 'That poem'(그 시)이 가리킬 시가 주어진 글에 없어요. 시는 (B)의 끝에 처음 나와요. 그래서 (C)는 맨 앞에 올 수 없어요.",
 "(C)의 'That poem'(그 시)이 가리킬 시가 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 카드를 봉투에 넣은 뒤에 하트를 오리는 (B)가 오는 것도 차례가 거꾸로예요."],
   'heart 하트 / poem 시 / envelope 봉투')

# 19번째 (정답 순서 CBA)
rw(18, 'Salmon live in two very different places during their lives.',
   {'A': ['After those years at sea, these big fish swim back to the river.', 'There, each female lays thousands of eggs in the cold gravel.'],
 'B': ['After this long stay, the small fish swim down to the sea.', 'In the salty ocean, they grow much bigger over several years.'],
 'C': ['Young salmon hatch in clear, cold rivers far from the coast.', 'For one or two years, they stay in that fresh water.']},
   '연어는 평생 동안 아주 다른 두 곳에서 산다.',
   {'A': ['바다에서 보낸 그 몇 해가 지난 뒤, 이 큰 물고기들은 강으로 헤엄쳐 돌아온다.', '그곳에서 암컷은 저마다 차가운 자갈 속에 수천 개의 알을 낳는다.'],
 'B': ['이렇게 오래 머문 뒤에 그 작은 물고기들은 바다로 헤엄쳐 내려간다.', '짠 바닷물 속에서 그들은 몇 해에 걸쳐 훨씬 더 커진다.'],
 'C': ['어린 연어는 해안에서 먼 맑고 차가운 강에서 알에서 깬다.', '일 년이나 이 년 동안 그들은 그 민물에서 지낸다.']},
   ['1) 주어진 글: 연어가 평생 동안 아주 다른 두 곳에서 산다고 해요. 이어서 그 두 곳이 어디인지가 나올 거예요.',
 '2) 첫째 글 (C): «Young salmon hatch in clear, cold rivers far from the coast.»(어린 연어는 해안에서 먼 맑고 차가운 강에서 알에서 깬다.) 연어의 삶이 시작되는 곳을 말하고, 앞의 것을 가리키는 말이 없어요. (C)는 «For one or two years, they stay in that '
 'fresh water.»(일 년이나 이 년 동안 그들은 그 민물에서 지낸다.)로 끝나요.',
 "3) 둘째 글 (B): «After this long stay, the small fish swim down to the sea.»(이렇게 오래 머문 뒤에 그 작은 물고기들은 바다로 헤엄쳐 내려간다.) 'this long stay'(이렇게 오래 머문 일)는 (C)의 끝에서 일 년이나 이 년 동안 민물에 머문 일이에요. (B)는 짠 바닷물 속에서 몇 "
 '해에 걸쳐 훨씬 더 커진다는 말로 끝나요.',
 "4) 셋째 글 (A)와 확인: «After those years at sea, these big fish swim back to the river.»(바다에서 보낸 그 몇 해가 지난 뒤, 이 큰 물고기들은 강으로 헤엄쳐 돌아온다.) 'those years at sea'(바다에서 보낸 그 몇 해)는 (B)의 끝에 나온 바다에서 지낸 몇 해이고, "
 "'these big fish'(이 큰 물고기들)는 (B)에서 훨씬 커진 연어예요. 강에서 알에서 깸 → 바다로 내려감 → 커져서 강으로 돌아옴. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(B)-(A)예요."],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. 연어가 알을 낳는 이야기는 연어의 삶을 설명하는 글의 처음에 올 것 같거든요. 하지만 (A)는 첫머리에 'those years at sea'(바다에서 보낸 그 몇 해)가 나와요. 주어진 글에는 바다에서 보낸 해가 나오지 않아요. 바다 이야기는 (B)에서 처음 나오니 (B)가 (A) 앞에 와야 해요. (B)도 첫머리에 'this long stay'(이렇게 오래 머문 일)가 나오므로 맨 앞에 올 수 없고, 강에서 지낸 이야기가 담긴 (C)가 맨 앞이에요.",
   ["(A)의 'those years at sea'(바다에서 보낸 그 몇 해)가 가리킬 해가 주어진 글에 없어요. 바다에서 보낸 몇 해는 (B)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'this long stay'(이렇게 오래 머문 일)가 가리킬 일이 주어진 글에 없어요. 오래 머문 일은 (C)의 끝에 처음 나와요.",
 "(B)의 'this long stay'(이렇게 오래 머문 일)가 가리킬 일이 앞에 없어요. 또 바다에서 커진 뒤에 알에서 깨는 이야기가 담긴 (C)가 오는 것도 차례가 거꾸로예요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (A)가 오면 'those years at sea'(바다에서 보낸 그 몇 해)가 가리킬 해가 없어요. (C)에는 강에서 지낸 이야기뿐이에요.",
 "(C)의 끝에서 민물에 머문 일을 (B)가 'this long stay'(이렇게 오래 머문 일)로 받아요. (B)의 끝에서 바다에서 보낸 몇 해를 (A)가 'those years at sea'(바다에서 보낸 그 몇 해)로 받아요. 두 군데가 다 맞물려요."],
   'hatch 알에서 깨다 / salty 짠 / gravel 자갈')

# 20번째 (정답 순서 BAC)
rw(19, 'Anna wanted to join the school play in the fall.',
   {'A': ['Those three lines made the whole room laugh out loud.', 'The teacher gave her the role of the funny old cook.'],
 'B': ['Her teacher held a short test for the new actors.', 'Anna read three lines from the play in front of everyone.'],
 'C': ['For that role, Anna learned five short lines at home.', 'On opening night, the audience laughed at every one of them.']},
   '애나는 가을에 학교 연극에 참가하고 싶었다.',
   {'A': ['그 세 줄은 방 안의 모든 사람을 크게 웃게 만들었다.', '선생님은 그녀에게 우스꽝스러운 늙은 요리사 역을 주었다.'],
 'B': ['그녀의 선생님이 새 배우들을 위해 짧은 시험을 열었다.', '애나는 모두가 보는 앞에서 연극의 대사 세 줄을 읽었다.'],
 'C': ['그 역을 위해 애나는 집에서 짧은 대사 다섯 줄을 외웠다.', '개막 날 밤에 관객은 그 대사 하나하나에 웃음을 터뜨렸다.']},
   ['1) 주어진 글: 애나가 가을에 학교 연극에 참가하고 싶었다고 해요. 이어서 애나가 연극에 들어가려고 한 일이 나올 거예요.',
 "2) 첫째 글 (B): «Her teacher held a short test for the new actors.»(그녀의 선생님이 새 배우들을 위해 짧은 시험을 열었다.) 'Her'(그녀의)는 주어진 글의 애나예요. 연극에 들어가려면 먼저 시험을 보는 것이 알맞은 시작이에요. (B)는 «Anna read three lines from the "
 'play in front of everyone.»(애나는 모두가 보는 앞에서 연극의 대사 세 줄을 읽었다.)로 끝나요.',
 "3) 둘째 글 (A): «Those three lines made the whole room laugh out loud.»(그 세 줄은 방 안의 모든 사람을 크게 웃게 만들었다.) 'Those three lines'(그 세 줄)는 (B)의 끝에서 애나가 읽은 세 줄이에요. (A)는 선생님이 애나에게 우스꽝스러운 늙은 요리사 역을 주었다는 말로 "
 '끝나요.',
 "4) 셋째 글 (C)와 확인: «For that role, Anna learned five short lines at home.»(그 역을 위해 애나는 집에서 짧은 대사 다섯 줄을 외웠다.) 'that role'(그 역)은 (A)의 끝에서 받은 요리사 역이에요. 시험을 봄 → 세 줄을 읽어 웃음을 줌 → 역을 받음 → 대사를 외움 → 공연 날 관객이 "
 '웃음. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(A)-(C)예요.'],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글에서 연극에 참가하고 싶었으니 대사를 외우는 이야기가 바로 이어질 것 같거든요. 하지만 (C)는 'For that role'(그 역을 위해)로 시작해요. 주어진 글에는 역이 나오지 않아요. 역은 (A)의 끝에 처음 나오니 (A)가 (C) 앞에 와야 해요. (A)도 'Those three lines'(그 세 줄)로 시작하는데, 세 줄은 (B)의 끝에 처음 나와요.",
   ["(A)의 'Those three lines'(그 세 줄)가 가리킬 세 줄이 주어진 글에 없어요. 세 줄은 (B)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 끝에서 읽은 세 줄을 (A)가 'Those three lines'(그 세 줄)로 받아요. (A)의 끝에서 받은 요리사 역을 (C)가 'that role'(그 역)로 받아요. 두 군데가 다 맞물려요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (C)가 오면 'that role'(그 역)이 가리킬 역이 없어요. (B)에는 시험을 봤다는 말뿐이고, 요리사 역은 (A)의 끝에 나와요.",
 "(C)의 'that role'(그 역)이 가리킬 역이 주어진 글에 없어요. 공연이 끝난 뒤에 시험을 보는 (B)가 오는 것도 차례가 거꾸로예요.",
 "(C)의 'that role'(그 역)이 가리킬 역이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 공연이 끝난 뒤에 시험을 보는 (B)가 오는 것도 차례가 거꾸로예요."],
   'actor 배우 / role 역할, 배역 / audience 관객')

# 21번째 (정답 순서 ACB)
rw(20, 'Ryan made a kite with his father on a windy Sunday.',
   {'A': ['Ryan and his father covered a cross of long sticks with red paper.', 'At the bottom, Ryan glued a long cloth tail to the red paper.'],
 'B': ['Suddenly that thin string snapped with a loud crack near the old tree.', 'The kite sailed away over the wide river toward the hills.'],
 'C': ['That tail kept the kite steady in the strong wind.', 'Ryan held the thin string with both hands near the park gate.']},
   '라이언은 바람 부는 어느 일요일에 아버지와 함께 연을 만들었다.',
   {'A': ['라이언과 아버지는 긴 막대기로 만든 십자 모양에 빨간 종이를 씌웠다.', '맨 아래에 라이언은 긴 천 꼬리를 그 빨간 종이에 붙였다.'],
 'B': ['갑자기 그 가느다란 줄이 큰 소리를 내며 오래된 나무 근처에서 끊어졌다.', '연은 넓은 강 위로 언덕을 향해 날아가 버렸다.'],
 'C': ['그 꼬리는 세찬 바람 속에서 연을 흔들리지 않게 해 주었다.', '라이언은 공원 문 근처에서 가느다란 줄을 두 손으로 잡고 있었다.']},
   ['1) 주어진 글: 라이언이 바람 부는 어느 일요일에 아버지와 함께 연을 만들었다고 해요. 이어서 연을 어떻게 만들고 날렸는지가 나올 거예요.',
 '2) 첫째 글 (A): «Ryan and his father covered a cross of long sticks with red paper.»(라이언과 아버지는 긴 막대기로 만든 십자 모양에 빨간 종이를 씌웠다.) 주어진 글의 두 사람이 연을 만드는 일이라 처음으로 알맞아요. (A)는 «At the bottom, Ryan glued a long '
 'cloth tail to the red paper.»(맨 아래에 라이언은 긴 천 꼬리를 그 빨간 종이에 붙였다.)로 끝나요.',
 "3) 둘째 글 (C): «That tail kept the kite steady in the strong wind.»(그 꼬리는 세찬 바람 속에서 연을 흔들리지 않게 해 주었다.) 'That tail'(그 꼬리)은 (A)의 끝에서 붙인 천 꼬리예요. (C)는 라이언이 가느다란 줄을 두 손으로 잡고 있었다는 말로 끝나요.",
 "4) 셋째 글 (B)와 확인: «Suddenly that thin string snapped with a loud crack near the old tree.»(갑자기 그 가느다란 줄이 큰 소리를 내며 오래된 나무 근처에서 끊어졌다.) 'that thin string'(그 가느다란 줄)은 (C)의 끝에서 라이언이 잡고 있던 줄이에요. 연을 만듦 → "
 '꼬리가 연을 안정시킴 → 줄이 끊어짐 → 연이 날아감. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (A)-(C)-(B)예요.'],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. (C)에 'kite'(연)과 'wind'(바람)이 있어서 주어진 글의 'kite'와 'windy'(바람 부는)에 바로 이어질 것 같거든요. 하지만 (C)는 'That tail'(그 꼬리)로 시작해요. 주어진 글에는 꼬리가 나오지 않아요. 꼬리는 (A)의 끝에 처음 나오니 (A)가 (C) 앞에 와야 해요. (B)도 첫 문장에 'that thin string'(그 가느다란 줄)이 나오는데, 줄은 (C)의 끝에 처음 나와요.",
   ["(A)의 끝에서 붙인 천 꼬리를 (C)가 'That tail'(그 꼬리)로 받아요. (C)의 끝에서 라이언이 잡고 있던 줄을 (B)가 'that thin string'(그 가느다란 줄)으로 받아요. 두 군데가 다 맞물려요.",
 "(B)의 'that thin string'(그 가느다란 줄)이 가리킬 줄이 주어진 글에 없어요. 줄은 (C)의 끝에 처음 나와요. 연이 날아간 뒤에 연을 만드는 (A)가 오는 것도 차례가 거꾸로예요.",
 "(B)의 'that thin string'(그 가느다란 줄)이 가리킬 줄이 앞에 없어요. 연이 날아간 뒤에 꼬리가 연을 안정시키는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(C)의 'That tail'(그 꼬리)이 가리킬 꼬리가 주어진 글에 없어요. 꼬리는 (A)의 끝에 처음 나와요.",
 "(C)의 'That tail'(그 꼬리)이 가리킬 꼬리가 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 연이 날아간 뒤에 연을 만드는 (A)가 맨 끝에 오는 것도 차례가 거꾸로예요."],
   'kite 연 / tail 꼬리 / string 줄, 끈 / snap 뚝 끊어지다')

# 22번째 (정답 순서 CBA)
rw(21, 'The moon is the brightest object in the night sky.',
   {'A': ['This daily change gives the moon many different shapes in the sky.', 'Scientists call each of these shapes a phase of the moon.'],
 'B': ['That sunlight always shines on one half of the moon.', 'Each night, we see a different part of that bright half.'],
 'C': ['The moon does not make any light of its own.', 'It only reflects the light of the sun, like a mirror.']},
   '달은 밤하늘에서 가장 밝은 물체이다.',
   {'A': ['이렇게 날마다 달라지는 모습 때문에 달은 하늘에서 여러 가지 모양을 갖게 된다.', '과학자들은 이 모양 하나하나를 달의 위상이라고 부른다.'],
 'B': ['그 햇빛은 언제나 달의 절반을 비춘다.', '밤마다 우리는 그 밝은 절반의 서로 다른 부분을 본다.'],
 'C': ['달은 스스로 내는 빛이 전혀 없다.', '달은 거울처럼 해의 빛을 되비출 뿐이다.']},
   ['1) 주어진 글: 달이 밤하늘에서 가장 밝은 물체라고 해요. 이어서 달이 왜 밝은지가 나올 거예요.',
 '2) 첫째 글 (C): «The moon does not make any light of its own.»(달은 스스로 내는 빛이 전혀 없다.) 달이 밝다는 말에 이어 그 빛이 어디서 오는지를 짚어 줘요. 앞의 것을 가리키는 말이 없어요. (C)는 «It only reflects the light of the sun, like a '
 'mirror.»(달은 거울처럼 해의 빛을 되비출 뿐이다.)로 끝나요.',
 "3) 둘째 글 (B): «That sunlight always shines on one half of the moon.»(그 햇빛은 언제나 달의 절반을 비춘다.) 'That sunlight'(그 햇빛)은 (C)의 끝에 나온 'the light of the sun'(해의 빛)이에요. (B)는 밤마다 그 밝은 절반의 서로 다른 부분을 본다는 말로 "
 '끝나요.',
 "4) 셋째 글 (A)와 확인: «This daily change gives the moon many different shapes in the sky.»(이렇게 날마다 달라지는 모습 때문에 달은 하늘에서 여러 가지 모양을 갖게 된다.) 'This daily change'(이렇게 날마다 달라지는 일)는 (B)의 끝에서 밤마다 다른 부분이 보인다는 "
 '말이에요. 스스로 빛을 내지 않음 → 해의 빛을 되비춤 → 밤마다 다른 부분이 보임 → 모양이 달라짐. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(B)-(A)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. 달이 가장 밝다는 말 뒤에 달의 모양 이야기가 이어질 것 같고, (A)에 주어진 글과 같은 'moon'(달)과 'sky'(하늘)가 있거든요. 하지만 (A)는 'This daily change'(이렇게 날마다 달라지는 일)로 시작해요. 주어진 글에는 날마다 달라지는 것이 나오지 않아요. 날마다 다른 부분이 보인다는 말은 (B)의 끝에 처음 나와요. (B)도 'That sunlight'(그 햇빛)으로 시작하는데, 햇빛은 (C)의 끝에 처음 나와요.",
   ["(A)의 'This daily change'(이렇게 날마다 달라지는 일)가 가리킬 변화가 주어진 글에 없어요. 변화는 (B)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'That sunlight'(그 햇빛)이 가리킬 햇빛이 주어진 글에 없어요. 해의 빛은 (C)의 끝에 처음 나와요.",
 "(B)의 'That sunlight'(그 햇빛)이 가리킬 햇빛이 앞에 없어요. 달이 해의 빛을 되비춘다고 처음 알려 주는 (C)가 (B) 뒤에 오는 것도 차례가 거꾸로예요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (A)가 오면 'This daily change'(이렇게 날마다 달라지는 일)가 가리킬 변화가 없어요. (C)에는 달이 빛을 되비춘다는 말뿐이에요.",
 "(C)의 끝에 나온 해의 빛을 (B)가 'That sunlight'(그 햇빛)으로 받아요. (B)의 끝에 나온 밤마다 달라지는 부분을 (A)가 'This daily change'(이렇게 날마다 달라지는 일)로 받아요. 두 군데가 다 맞물려요."],
   'reflect 되비추다 / mirror 거울 / phase (달의) 위상, 모양')

# 23번째 (정답 순서 BAC)
rw(22, 'Mia lost her silver key on the way to school.',
   {'A': ['He opened the old lost-and-found box behind his small desk.', 'Inside, Mia found her silver key under a blue glove.'],
 'B': ['She looked in her bag, her pockets and her desk.', 'Finally, she asked the school guard about her lost key.'],
 'C': ['After that happy find, Mia keeps her key on a long string.', 'The string hangs around her neck during every school day.']},
   '미아는 학교 가는 길에 은색 열쇠를 잃어버렸다.',
   {'A': ['그는 자기 작은 책상 뒤에 있는 낡은 분실물 상자를 열었다.', '안에서 미아는 파란 장갑 밑에 있던 은색 열쇠를 찾았다.'],
 'B': ['그녀는 가방과 주머니와 책상 안을 살펴보았다.', '마침내 그녀는 학교 경비 아저씨에게 잃어버린 열쇠에 대해 물어보았다.'],
 'C': ['그 기쁜 발견 이후로 미아는 열쇠를 긴 줄에 달아 둔다.', '그 줄은 학교에 가는 날마다 그녀의 목에 걸려 있다.']},
   ['1) 주어진 글: 미아가 학교 가는 길에 은색 열쇠를 잃어버렸다고 해요. 이어서 열쇠를 찾으려고 한 일이 나올 거예요.',
 "2) 첫째 글 (B): «She looked in her bag, her pockets and her desk.»(그녀는 가방과 주머니와 책상 안을 살펴보았다.) 'She'(그녀)는 주어진 글의 미아예요. 열쇠를 잃어버렸으니 먼저 자기 물건 속을 찾는 것이 알맞아요. (B)는 «Finally, she asked the school guard "
 'about her lost key.»(마침내 그녀는 학교 경비 아저씨에게 잃어버린 열쇠에 대해 물어보았다.)로 끝나요.',
 "3) 둘째 글 (A): «He opened the old lost-and-found box behind his small desk.»(그는 자기 작은 책상 뒤에 있는 낡은 분실물 상자를 열었다.) 'He'(그)는 주어진 글에 없던 남자예요. (B)의 끝에 나온 'the school guard'(학교 경비 아저씨)가 바로 그 사람이에요. (A)는 "
 '미아가 파란 장갑 밑에서 은색 열쇠를 찾았다는 말로 끝나요.',
 "4) 셋째 글 (C)와 확인: «After that happy find, Mia keeps her key on a long string.»(그 기쁜 발견 이후로 미아는 열쇠를 긴 줄에 달아 둔다.) 'that happy find'(그 기쁜 발견)은 (A)의 끝에서 열쇠를 찾은 일이에요. 가방 속을 찾음 → 경비 아저씨에게 물음 → 분실물 상자에서 "
 '찾음 → 열쇠를 줄에 달아 둠. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(A)-(C)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)에 'Mia'(미아)와 'silver key'(은색 열쇠)가 있어서 주어진 글의 사건과 바로 이어질 것 같거든요. 하지만 (A)는 'He'(그)로 시작해요. 주어진 글에는 남자가 나오지 않아요. 그 사람은 (B)의 끝에 나오는 학교 경비 아저씨예요. (C)도 첫머리에 'that happy find'(그 기쁜 발견)이 나오는데, 열쇠를 찾은 일은 (A)의 끝에서 처음 나와요.",
   ["(A)의 'He'(그)가 가리킬 남자가 주어진 글에 없어요. 그 사람인 학교 경비 아저씨는 (B)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 끝에 나온 학교 경비 아저씨를 (A)가 'He'(그)로 받아요. (A)의 끝에서 열쇠를 찾은 일을 (C)가 'that happy find'(그 기쁜 발견)으로 받아요. 두 군데가 다 맞물려요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (C)가 오면 'that happy find'(그 기쁜 발견)이 가리킬 발견이 없어요. (B)에서는 아직 열쇠를 찾지 못했고, 찾은 일은 (A)에 나와요.",
 "(C)의 'that happy find'(그 기쁜 발견)이 가리킬 발견이 주어진 글에 없어요. 주어진 글에는 열쇠를 잃어버렸다는 말뿐이에요. 그래서 (C)는 맨 앞에 올 수 없어요.",
 "(C)의 'that happy find'(그 기쁜 발견)이 가리킬 발견이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 열쇠를 찾은 뒤에 가방 속을 뒤지는 (B)가 오는 것도 차례가 거꾸로예요."],
   'lost-and-found 분실물 보관소 / glove 장갑 / guard 경비원 / string 줄, 끈')

# 24번째 (정답 순서 CAB)
rw(23, 'Dohyun went fishing with his grandfather at a quiet lake.',
   {'A': ['That strong pull bent his rod almost down to the water.', 'His grandfather held a net under the large silver fish.'],
 'B': ["It weighed nearly three kilograms on his grandfather's old scale.", 'Dohyun proudly carried his catch home in a blue bucket.'],
 'C': ['They sat on a wooden dock for two long hours.', 'Suddenly Dohyun felt a strong pull on his thin line.']},
   '도현이는 조용한 호수로 할아버지와 함께 낚시를 갔다.',
   {'A': ['그 강한 당김은 그의 낚싯대를 거의 물에 닿을 만큼 휘게 했다.', '할아버지는 커다란 은빛 물고기 밑에 그물을 받쳐 들었다.'],
 'B': ['그것은 할아버지의 낡은 저울에서 거의 삼 킬로그램이 나갔다.', '도현이는 자랑스럽게 잡은 물고기를 파란 양동이에 담아 집으로 가져갔다.'],
 'C': ['그들은 긴 두 시간 동안 나무 부두에 앉아 있었다.', '갑자기 도현이는 가느다란 낚싯줄에서 강한 당김을 느꼈다.']},
   ['1) 주어진 글: 도현이가 조용한 호수로 할아버지와 함께 낚시를 갔다고 해요. 이어서 낚시터에서 있었던 일이 나올 거예요.',
 "2) 첫째 글 (C): «They sat on a wooden dock for two long hours.»(그들은 긴 두 시간 동안 나무 부두에 앉아 있었다.) 'They'(그들)는 주어진 글의 도현이와 할아버지예요. 낚시터에서 기다리는 모습이라 이야기의 처음으로 알맞아요. (C)는 «Suddenly Dohyun felt a strong pull "
 'on his thin line.»(갑자기 도현이는 가느다란 낚싯줄에서 강한 당김을 느꼈다.)로 끝나요.',
 "3) 둘째 글 (A): «That strong pull bent his rod almost down to the water.»(그 강한 당김은 그의 낚싯대를 거의 물에 닿을 만큼 휘게 했다.) 'That strong pull'(그 강한 당김)은 (C)의 끝에서 도현이가 느낀 당김이에요. (A)는 할아버지가 커다란 은빛 물고기 밑에 그물을 받쳐 "
 '들었다는 말로 끝나요.',
 "4) 셋째 글 (B)와 확인: «It weighed nearly three kilograms on his grandfather's old scale.»(그것은 할아버지의 낡은 저울에서 거의 삼 킬로그램이 나갔다.) 'It'(그것)은 (A)의 끝에 나온 커다란 은빛 물고기예요. 낚시터에 앉아 기다림 → 강한 당김을 느낌 → 물고기를 그물로 받침 → "
 '무게를 잼. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(A)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)에 'grandfather'(할아버지)가 있고, 잡은 물고기를 들고 집에 간다는 말이 낚시 이야기의 결말처럼 보이거든요. 하지만 (B)는 'It'(그것)으로 시작해요. 주어진 글에는 저울에 달 만한 것이 나오지 않아요. 저울에 단 것은 물고기이고, 물고기는 (A)의 끝에 처음 나와요. (A)도 'That strong pull'(그 강한 당김)로 시작하는데, 당김은 (C)의 끝에 처음 나와요.",
   ["(A)의 'That strong pull'(그 강한 당김)이 가리킬 당김이 주어진 글에 없어요. 당김은 (C)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'It'(그것)이 가리킬 것이 주어진 글에 없어요. 저울에 단 물고기는 (A)의 끝에 처음 나와요. 그래서 (B)는 맨 앞에 올 수 없고, 물고기를 집에 가져간 뒤에 그물을 드는 (A)가 오는 것도 차례가 거꾸로예요.",
 "(B)의 'It'(그것)이 가리킬 것이 주어진 글에 없어요. 저울에 단 물고기는 (A)의 끝에 처음 나와요. 그래서 (B)는 맨 앞에 올 수 없고, 물고기를 집에 가져간 뒤에 부두에 앉아 기다리는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(C)의 끝에서 느낀 당김을 (A)가 'That strong pull'(그 강한 당김)로 받아요. (A)의 끝에 나온 물고기를 (B)가 'It'(그것)으로 받아요. 두 군데가 다 맞물려요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (B)가 오면 'It'(그것)이 가리킬 것이 없어요. (C)에는 낚싯줄에 느껴진 당김만 나오고, 저울에 달 물고기는 아직 나오지 않아요."],
   'dock 부두, 선착장 / pull 당김 / rod 낚싯대 / net 그물 / scale 저울 / catch 잡은 것')

# 25번째 (정답 순서 CAB)
rw(24, 'A rainbow can appear in the sky after a rain shower.',
   {'A': ['Inside each drop, that white light splits into many colors.', 'Each color leaves the drop at a slightly different angle.'],
 'B': ['Those separate colors reach our eyes from many different drops.', 'Together, they form a wide band of color across the sky.'],
 'C': ['Rain leaves millions of tiny drops of water in the air.', 'Bright sunlight then enters each one of those small drops.']},
   '무지개는 소나기가 내린 뒤 하늘에 나타날 수 있다.',
   {'A': ['각 물방울 안에서 그 하얀 빛은 여러 가지 색으로 갈라진다.', '각각의 색은 조금씩 다른 각도로 물방울을 빠져나온다.'],
 'B': ['그 갈라진 색들은 여러 개의 서로 다른 물방울에서 우리 눈에 닿는다.', '그 색들이 함께 하늘을 가로지르는 넓은 색의 띠를 이룬다.'],
 'C': ['비는 공기 중에 수백만 개의 작은 물방울을 남긴다.', '그러면 밝은 햇빛이 그 작은 물방울 하나하나 안으로 들어간다.']},
   ['1) 주어진 글: 무지개가 소나기가 내린 뒤 하늘에 나타날 수 있다고 해요. 이어서 무지개가 생기는 과정이 나올 거예요.',
 "2) 첫째 글 (C): «Rain leaves millions of tiny drops of water in the air.»(비는 공기 중에 수백만 개의 작은 물방울을 남긴다.) 'Rain'(비)은 주어진 글의 'rain shower'(소나기)와 이어져요. 앞의 것을 가리키는 말이 없고, 무지개가 생기는 과정의 첫 단계예요. (C)는 «Bright "
 'sunlight then enters each one of those small drops.»(그러면 밝은 햇빛이 그 작은 물방울 하나하나 안으로 들어간다.)로 끝나요.',
 "3) 둘째 글 (A): «Inside each drop, that white light splits into many colors.»(각 물방울 안에서 그 하얀 빛은 여러 가지 색으로 갈라진다.) 'that white light'(그 하얀 빛)은 (C)의 끝에 나온 'Bright sunlight'(밝은 햇빛)을 다시 말한 거예요. (A)는 각각의 "
 '색이 조금씩 다른 각도로 물방울을 빠져나온다는 말로 끝나요.',
 "4) 셋째 글 (B)와 확인: «Those separate colors reach our eyes from many different drops.»(그 갈라진 색들은 여러 개의 서로 다른 물방울에서 우리 눈에 닿는다.) 'Those separate colors'(그 갈라진 색들)는 (A)에서 갈라져 물방울을 떠나는 색들이에요. 물방울이 남음 → "
 '햇빛이 들어감 → 색으로 갈라짐 → 눈에 닿아 띠를 이룸. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(A)-(B)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)가 빛이 여러 색으로 갈라진다는 무지개의 핵심 내용이라서 설명의 처음에 올 것 같거든요. 하지만 (A)는 'Inside each drop, that white light'(각 물방울 안에서, 그 하얀 빛)으로 시작해요. 주어진 글에는 물방울도 빛도 나오지 않아요. 둘 다 (C)에서 처음 나오니 (C)가 (A) 앞에 와야 해요. (B)도 'Those separate colors'(그 갈라진 색들)로 시작하는데, 갈라진 색은 (A)에서 처음 나와요.",
   ["(A)의 'each drop'(각 물방울)과 'that white light'(그 하얀 빛)이 가리킬 것이 주어진 글에 없어요. 물방울과 햇빛은 (C)에서 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'Those separate colors'(그 갈라진 색들)가 가리킬 색이 주어진 글에 없어요. 색이 갈라지는 일은 (A)에 나와요. 그래서 (B)는 맨 앞에 올 수 없어요.",
 "(B)의 'Those separate colors'(그 갈라진 색들)가 가리킬 색이 주어진 글에 없어서 (B)는 맨 앞에 올 수 없어요. 또 하늘에 색의 띠가 생긴 뒤에 물방울이 공기 중에 남는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(C)의 끝에 나온 햇빛과 물방울을 (A)가 'that white light'(그 하얀 빛)과 'each drop'(각 물방울)로 받아요. (A)의 끝에서 물방울을 떠나는 색들을 (B)가 'Those separate colors'(그 갈라진 색들)로 받아요. 두 군데가 다 맞물려요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (B)가 오면 'Those separate colors'(그 갈라진 색들)가 가리킬 색이 없어요. (C)의 끝에서는 햇빛이 물방울에 들어갈 뿐이고, 색으로 갈라지는 일은 (A)에 나와요."],
   'drop 방울 / split 갈라지다, 나뉘다 / angle 각도 / band 띠 / shower 소나기')

# 26번째 (정답 순서 BCA)
rw(25, 'Jisoo spent last Saturday morning at the town animal shelter.',
   {'A': ['After those ten minutes, the shy dog crept out to her side.', 'Jisoo gave the dog a gentle pat on its head.'],
 'B': ['A worker gave her a green apron and a stiff brush.', 'Her first job was to carry a bucket of fresh water to the dog cages.'],
 'C': ['In one of those cages, a shy brown dog was hiding.', 'Jisoo sat quietly on the cold floor beside the bucket for ten minutes.']},
   '지수는 지난 토요일 아침을 동네 동물 보호소에서 보냈다.',
   {'A': ['그 십 분이 지난 뒤, 겁 많은 개가 살금살금 나와 그녀 곁으로 왔다.', '지수는 그 개의 머리를 부드럽게 쓰다듬어 주었다.'],
 'B': ['직원이 그녀에게 초록색 앞치마와 뻣뻣한 솔을 주었다.', '그녀의 첫 일은 신선한 물이 든 양동이를 개 우리로 나르는 것이었다.'],
 'C': ['그 우리들 가운데 한 곳에 겁 많은 갈색 개가 숨어 있었다.', '지수는 십 분 동안 양동이 옆 차가운 바닥에 조용히 앉아 있었다.']},
   ['1) 주어진 글: 지수가 지난 토요일 아침을 동네 동물 보호소에서 보냈다고 해요. 이어서 보호소에서 한 일이 나올 거예요.',
 "2) 첫째 글 (B): «A worker gave her a green apron and a stiff brush.»(직원이 그녀에게 초록색 앞치마와 뻣뻣한 솔을 주었다.) 'her'(그녀)는 주어진 글의 지수예요. 보호소에 도착해서 일을 시작하는 장면이라 처음으로 알맞아요. (B)는 «Her first job was to carry a bucket "
 'of fresh water to the dog cages.»(그녀의 첫 일은 신선한 물이 든 양동이를 개 우리로 나르는 것이었다.)로 끝나요.',
 "3) 둘째 글 (C): «In one of those cages, a shy brown dog was hiding.»(그 우리들 가운데 한 곳에 겁 많은 갈색 개가 숨어 있었다.) 'those cages'(그 우리들)는 (B)의 끝에서 물을 나른 개 우리들이에요. (C)는 지수가 양동이 옆 바닥에 십 분 동안 조용히 앉아 있었다는 말로 끝나요.",
 "4) 셋째 글 (A)와 확인: «After those ten minutes, the shy dog crept out to her side.»(그 십 분이 지난 뒤, 겁 많은 개가 살금살금 나와 그녀 곁으로 왔다.) 'those ten minutes'(그 십 분)는 (C)의 끝에서 지수가 앉아 있던 십 분이고, 'the shy dog'(겁 많은 개)는 "
 '(C)에서 숨어 있던 개예요. 일을 받음 → 우리에서 개를 봄 → 십 분 앉아 있음 → 개가 나옴. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(C)-(A)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)에 'Jisoo'(지수)가 나오고, 보호소에서 개를 쓰다듬는 장면이 이야기의 핵심처럼 보이거든요. 하지만 (A)는 'After those ten minutes'(그 십 분이 지난 뒤)로 시작해요. 주어진 글에는 십 분이 나오지 않아요. 십 분은 (C)의 끝에 처음 나와요. (C)도 첫 문장에 'those cages'(그 우리들)가 나오는데, 우리는 (B)의 끝에 처음 나와요.",
   ["(A)의 'those ten minutes'(그 십 분)와 'the shy dog'(겁 많은 개)가 가리킬 것이 주어진 글에 없어요. 십 분과 개는 (C)에서 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (A)가 오면 'those ten minutes'(그 십 분)와 'the shy dog'(겁 많은 개)가 가리킬 것이 없어요. (B)에는 양동이를 나르는 일뿐이고, 십 분 동안 앉아 있던 일과 겁 많은 개는 (C)에 나와요.",
 "(B)의 끝에서 물을 나른 개 우리들을 (C)가 'those cages'(그 우리들)로 받아요. (C)의 끝에서 앉아 있던 십 분을 (A)가 'those ten minutes'(그 십 분)로 받아요. 두 군데가 다 맞물려요.",
 "(C)의 'those cages'(그 우리들)가 가리킬 우리가 주어진 글에 없어요. 우리는 (B)의 끝에 처음 나와요. 그래서 (C)는 맨 앞에 올 수 없어요.",
 "(C)의 'those cages'(그 우리들)가 가리킬 우리가 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 또 지수가 양동이 옆에 십 분 앉아 있은 뒤에 '첫 일'(first job)을 말하는 (B)가 오는 것도 차례가 거꾸로예요."],
   'shelter 보호소 / apron 앞치마 / stiff 뻣뻣한 / shy 겁 많은, 수줍은 / crept (creep의 과거형) 살금살금 움직였다')

# 27번째 (정답 순서 BAC)
rw(26, 'Leo entered his model volcano in the school science fair.',
   {'A': ['Inside that tall cone, Leo put baking soda and red water.', 'Then he slowly added vinegar from a small plastic cup.'],
 'B': ['At home, he built a tall cone from thick brown cardboard.', 'A coat of gray paint made it look like real rock.'],
 'C': ['This mixture quickly sent red foam out of the top.', "The judges clapped loudly for Leo's model at the end."]},
   '레오는 학교 과학 박람회에 자신이 만든 화산 모형을 출품했다.',
   {'A': ['그 높은 원뿔 안에 레오는 베이킹 소다와 붉은 물을 넣었다.', '그런 다음 그는 작은 플라스틱 컵에 든 식초를 천천히 부었다.'],
 'B': ['집에서 그는 두꺼운 갈색 판지로 높은 원뿔을 만들었다.', '회색 페인트를 한 겹 칠하자 그것은 진짜 바위처럼 보였다.'],
 'C': ['이 혼합물은 곧바로 붉은 거품을 꼭대기 밖으로 뿜어냈다.', '마지막에 심사위원들이 레오의 모형에 크게 박수를 쳤다.']},
   ['1) 주어진 글: 레오가 학교 과학 박람회에 화산 모형을 출품했다고 해요. 이어서 그 모형을 어떻게 만들고 보여 주었는지가 나올 거예요.',
 "2) 첫째 글 (B): «At home, he built a tall cone from thick brown cardboard.»(집에서 그는 두꺼운 갈색 판지로 높은 원뿔을 만들었다.) 'he'(그)는 주어진 글의 레오예요. 모형을 만드는 첫 일이라 알맞아요. (B)는 «A coat of gray paint made it look like real "
 'rock.»(회색 페인트를 한 겹 칠하자 그것은 진짜 바위처럼 보였다.)로 끝나요.',
 "3) 둘째 글 (A): «Inside that tall cone, Leo put baking soda and red water.»(그 높은 원뿔 안에 레오는 베이킹 소다와 붉은 물을 넣었다.) 'that tall cone'(그 높은 원뿔)은 (B)에서 만들고 페인트를 칠한 원뿔이에요. (A)는 «Then he slowly added vinegar "
 'from a small plastic cup.»(그런 다음 그는 작은 플라스틱 컵에 든 식초를 천천히 부었다.)로 끝나요.',
 "4) 셋째 글 (C)와 확인: «This mixture quickly sent red foam out of the top.»(이 혼합물은 곧바로 붉은 거품을 꼭대기 밖으로 뿜어냈다.) 'This mixture'(이 혼합물)는 (A)에서 베이킹 소다, 붉은 물, 식초를 섞은 것이에요. 원뿔을 만듦 → 안에 재료를 넣고 식초를 부음 → 거품이 뿜어져 "
 '나옴 → 심사위원이 박수 침. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(A)-(C)예요.'],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. 화산 모형이 거품을 뿜는 장면이 이야기의 핵심 같고, (C)에 심사위원 이야기가 있어서 주어진 글의 박람회와 바로 이어질 것 같거든요. 하지만 (C)는 'This mixture'(이 혼합물)로 시작해요. 주어진 글에는 섞은 것이 나오지 않아요. 섞는 일은 (A)에 나와요. (A)도 첫 문장에 'that tall cone'(그 높은 원뿔)이 나오는데, 원뿔은 (B)에서 처음 나와요.",
   ["(A)의 'that tall cone'(그 높은 원뿔)이 가리킬 원뿔이 주어진 글에 없어요. 원뿔은 (B)에서 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)에서 만든 원뿔을 (A)가 'that tall cone'(그 높은 원뿔)으로 받아요. (A)에서 섞은 베이킹 소다, 붉은 물, 식초를 (C)가 'This mixture'(이 혼합물)로 받아요. 두 군데가 다 맞물려요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (C)가 오면 'This mixture'(이 혼합물)가 가리킬 것이 없어요. (B)에는 원뿔과 페인트 이야기뿐이고, 섞는 일은 (A)에 나와요.",
 "(C)의 'This mixture'(이 혼합물)가 가리킬 것이 주어진 글에 없어요. 섞는 일은 (A)에 나와요. 그래서 (C)는 맨 앞에 올 수 없어요.",
 "(C)의 'This mixture'(이 혼합물)가 가리킬 것이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 또 거품이 뿜어져 나온 뒤에 원뿔을 만드는 (B)가 오는 것도 차례가 거꾸로예요."],
   'volcano 화산 / cardboard 판지 / baking soda 베이킹 소다 / vinegar 식초 / foam 거품 / judge 심사위원')

# 28번째 (정답 순서 BCA)
rw(27, 'Bats can find small insects even in the dark night.',
   {'A': ['The bat hears each echo with its two large ears.', 'These echoes tell the bat the exact place of its food.'],
 'B': ['A bat sends out very high sounds into the night air.', 'Those sounds travel quickly in every direction around the bat.'],
 'C': ['Some of these sounds hit a small insect in the air.', 'Those sounds then bounce back to the bat as faint echoes.']},
   '박쥐는 어두운 밤에도 작은 곤충을 찾을 수 있다.',
   {'A': ['박쥐는 각각의 메아리를 큰 두 귀로 듣는다.', '이 메아리는 박쥐에게 먹이의 정확한 위치를 알려 준다.'],
 'B': ['박쥐는 매우 높은 소리를 밤공기 속으로 내보낸다.', '그 소리는 박쥐 주위 모든 방향으로 빠르게 퍼진다.'],
 'C': ['이 소리 가운데 일부는 공기 중의 작은 곤충에 부딪친다.', '그러면 그 소리는 희미한 메아리가 되어 박쥐에게 되돌아온다.']},
   ['1) 주어진 글: 박쥐가 어두운 밤에도 작은 곤충을 찾을 수 있다고 해요. 이어서 박쥐가 곤충을 어떻게 찾는지가 나올 거예요.',
 "2) 첫째 글 (B): «A bat sends out very high sounds into the night air.»(박쥐는 매우 높은 소리를 밤공기 속으로 내보낸다.) 'A bat'(박쥐)는 주어진 글의 박쥐를 한 마리로 말한 거예요. 곤충을 찾는 과정의 첫 단계이고, 앞의 것을 가리키는 말이 없어요. (B)는 «Those sounds "
 'travel quickly in every direction around the bat.»(그 소리는 박쥐 주위 모든 방향으로 빠르게 퍼진다.)로 끝나요.',
 "3) 둘째 글 (C): «Some of these sounds hit a small insect in the air.»(이 소리 가운데 일부는 공기 중의 작은 곤충에 부딪친다.) 'these sounds'(이 소리)는 (B)의 끝에서 모든 방향으로 퍼지는 소리예요. (C)는 «Those sounds then bounce back to the bat "
 'as faint echoes.»(그러면 그 소리는 희미한 메아리가 되어 박쥐에게 되돌아온다.)로 끝나요.',
 "4) 셋째 글 (A)와 확인: «The bat hears each echo with its two large ears.»(박쥐는 각각의 메아리를 큰 두 귀로 듣는다.) 'each echo'(각각의 메아리)는 (C)의 끝에서 되돌아온 메아리예요. 소리를 내보냄 → 곤충에 부딪침 → 메아리로 돌아옴 → 귀로 듣고 위치를 앎. 앞 글의 끝과 뒤 글의 "
 '처음이 다 맞물리므로 순서는 (B)-(C)-(A)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)에 'The bat'(박쥐)와 'food'(먹이)가 있어서 주어진 글의 박쥐·곤충 이야기와 바로 이어질 것 같거든요. 하지만 (A)는 'each echo'(각각의 메아리)를 중심으로 말해요. 주어진 글에는 메아리가 나오지 않아요. 메아리는 (C)의 끝에 처음 나와요. (C)도 첫 문장에 'these sounds'(이 소리)가 나오는데, 소리는 (B)에서 처음 나와요.",
   ["(A)의 'each echo'(각각의 메아리)가 가리킬 메아리가 주어진 글에 없어요. 메아리는 (C)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (A)가 오면 'each echo'(각각의 메아리)가 가리킬 메아리가 없어요. (B)에는 소리가 퍼진다는 말뿐이고, 되돌아온 메아리는 (C)에 나와요.",
 "(B)의 끝에서 퍼지는 소리를 (C)가 'these sounds'(이 소리)로 받아요. (C)의 끝에서 되돌아온 메아리를 (A)가 'each echo'(각각의 메아리)로 받아요. 두 군데가 다 맞물려요.",
 "(C)의 'these sounds'(이 소리)가 가리킬 소리가 주어진 글에 없어요. 소리는 (B)에서 처음 나와요. 그래서 (C)는 맨 앞에 올 수 없어요.",
 "(C)의 'these sounds'(이 소리)가 가리킬 소리가 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 또 소리가 곤충에 부딪친 뒤에 소리를 처음 내보내는 (B)가 오는 것도 차례가 거꾸로예요."],
   'echo 메아리 / bounce back 되돌아오다 / faint 희미한 / insect 곤충')

# 29번째 (정답 순서 CAB)
rw(28, "Haneul took the bus alone to her aunt's house for the first time.",
   {'A': ['On the bus, Haneul held that card tightly in her hand.', 'A kind driver told her the name of each stop.'],
 'B': ['At the last of those stops, Haneul stepped carefully off the bus.', 'Her aunt was already waiting there with a wide smile.'],
 'C': ['Her mother walked her to the bus stop at nine.', "She gave Haneul a small card with her aunt's phone number."]},
   '하늘이는 처음으로 혼자 버스를 타고 이모 댁에 갔다.',
   {'A': ['버스에서 하늘이는 그 카드를 손에 꼭 쥐고 있었다.', '친절한 운전기사가 그녀에게 정류장마다 이름을 알려 주었다.'],
 'B': ['그 정류장들 가운데 마지막 정류장에서 하늘이는 조심스럽게 버스에서 내렸다.', '이모는 이미 거기서 환한 웃음을 지으며 기다리고 있었다.'],
 'C': ['어머니가 아홉 시에 그녀를 버스 정류장까지 걸어서 데려다 주었다.', '어머니는 하늘이에게 이모의 전화번호가 적힌 작은 카드를 주었다.']},
   ['1) 주어진 글: 하늘이가 처음으로 혼자 버스를 타고 이모 댁에 갔다고 해요. 이어서 하늘이가 가는 과정이 나올 거예요.',
 "2) 첫째 글 (C): «Her mother walked her to the bus stop at nine.»(어머니가 아홉 시에 그녀를 버스 정류장까지 걸어서 데려다 주었다.) 'Her'(그녀의)는 주어진 글의 하늘이예요. 버스를 타러 가는 출발 장면이라 처음으로 알맞아요. (C)는 «She gave Haneul a small card with "
 "her aunt's phone number.»(어머니는 하늘이에게 이모의 전화번호가 적힌 작은 카드를 주었다.)로 끝나요.",
 "3) 둘째 글 (A): «On the bus, Haneul held that card tightly in her hand.»(버스에서 하늘이는 그 카드를 손에 꼭 쥐고 있었다.) 'that card'(그 카드)는 (C)의 끝에서 어머니가 준 카드예요. (A)는 «A kind driver told her the name of each "
 'stop.»(친절한 운전기사가 그녀에게 정류장마다 이름을 알려 주었다.)로 끝나요.',
 "4) 셋째 글 (B)와 확인: «At the last of those stops, Haneul stepped carefully off the bus.»(그 정류장들 가운데 마지막 정류장에서 하늘이는 조심스럽게 버스에서 내렸다.) 'those stops'(그 정류장들)는 (A)의 끝에서 운전기사가 이름을 알려 준 정류장들이에요. 정류장까지 걸어감 → "
 '카드를 쥐고 버스를 탐 → 마지막 정류장에서 내림. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(A)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. 이모가 기다리고 있다는 (B)의 끝이 주어진 글의 '이모 댁에 갔다'와 바로 이어질 것 같거든요. 하지만 (B)는 첫머리에 'those stops'(그 정류장들)가 나와요. 주어진 글에는 정류장이 나오지 않아요. 여러 정류장은 (A)의 끝에서 처음 나와요. (A)도 첫 문장에 'that card'(그 카드)가 나오는데, 카드는 (C)의 끝에 처음 나와요.",
   ["(A)의 'that card'(그 카드)가 가리킬 카드가 주어진 글에 없어요. 카드는 (C)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'those stops'(그 정류장들)가 가리킬 정류장들이 주어진 글에 없어요. 정류장 이름을 알려 준 일은 (A)의 끝에 나와요. 그래서 (B)는 맨 앞에 올 수 없어요.",
 "(B)의 'those stops'(그 정류장들)가 가리킬 정류장들이 앞에 없어서 (B)는 맨 앞에 올 수 없어요. 또 이모를 만난 뒤에 버스 정류장에서 출발하는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(C)의 끝에서 어머니가 준 카드를 (A)가 'that card'(그 카드)로 받아요. (A)의 끝에서 운전기사가 이름을 알려 준 정류장들을 (B)가 'those stops'(그 정류장들)로 받아요. 두 군데가 다 맞물려요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (B)가 오면 'those stops'(그 정류장들)가 가리킬 정류장들이 없어요. (C)에는 'the bus stop'(버스 정류장) 한 곳만 나오고, 여러 정류장을 말하는 'each stop'(정류장마다)는 (A)의 끝에 처음 나와요."],
   'aunt 이모, 고모 / stop 정류장 / tightly 꼭, 단단히 / step off ~에서 내리다')

# 30번째 (정답 순서 ACB)
rw(29, "Chaeyoung's class kept a jar of tadpoles on the window.",
   {'A': ['Every morning, she checked the jar before the first lesson.', 'One day she saw two tiny back legs on a tadpole.'],
 'B': ['By June, that small animal was a tiny green frog.', 'The class carried the frog to the pond behind school.'],
 'C': ['Those back legs grew much longer over the next two weeks.', 'Its long black tail slowly became shorter day by day.']},
   '채영이네 반은 창가에 올챙이가 든 병을 두었다.',
   {'A': ['매일 아침 그녀는 첫 수업 전에 병을 살펴보았다.', '어느 날 그녀는 올챙이 한 마리에게서 아주 작은 뒷다리 두 개를 보았다.'],
 'B': ['유월이 되자 그 작은 동물은 아주 작은 초록색 개구리가 되어 있었다.', '반 아이들은 그 개구리를 학교 뒤 연못으로 데려갔다.'],
 'C': ['그 뒷다리는 그다음 두 주 동안 훨씬 더 길어졌다.', '그 올챙이의 긴 검은 꼬리는 날마다 조금씩 짧아졌다.']},
   ['1) 주어진 글: 채영이네 반이 창가에 올챙이가 든 병을 두었다고 해요. 이어서 올챙이에게 생긴 변화가 나올 거예요.',
 "2) 첫째 글 (A): «Every morning, she checked the jar before the first lesson.»(매일 아침 그녀는 첫 수업 전에 병을 살펴보았다.) 'she'(그녀)는 주어진 글의 채영이이고, 'the jar'(그 병)는 올챙이가 든 병이에요. 올챙이를 관찰하기 시작하는 장면이라 처음으로 알맞아요. (A)는 "
 '«One day she saw two tiny back legs on a tadpole.»(어느 날 그녀는 올챙이 한 마리에게서 아주 작은 뒷다리 두 개를 보았다.)로 끝나요.',
 "3) 둘째 글 (C): «Those back legs grew much longer over the next two weeks.»(그 뒷다리는 그다음 두 주 동안 훨씬 더 길어졌다.) 'Those back legs'(그 뒷다리)는 (A)의 끝에서 본 뒷다리 두 개예요. (C)는 «Its long black tail slowly became "
 'shorter day by day.»(그 올챙이의 긴 검은 꼬리는 날마다 조금씩 짧아졌다.)로 끝나요.',
 "4) 셋째 글 (B)와 확인: «By June, that small animal was a tiny green frog.»(유월이 되자 그 작은 동물은 아주 작은 초록색 개구리가 되어 있었다.) 'that small animal'(그 작은 동물)은 (C)의 끝에서 꼬리가 짧아지던 그 올챙이예요. 병을 살펴봄 → 뒷다리를 봄 → 뒷다리가 길어지고 "
 '꼬리가 짧아짐 → 개구리가 되어 연못으로 보냄. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (A)-(C)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. 올챙이가 개구리가 되어 연못으로 가는 결말이 주어진 글의 올챙이 이야기와 바로 이어질 것 같고, (B)에 'the class'(반)가 있거든요. 하지만 (B)는 첫머리에 'that small animal'(그 작은 동물)이 나와요. 이것은 어느 한 마리를 콕 집어 가리키는 말인데, 주어진 글에는 올챙이들(tadpoles)만 나와서 어느 한 마리를 가리키는지 알 수 없어요. 한 마리를 처음 말하는 곳은 (A)의 끝이에요. 또 개구리가 되어 연못으로 간 뒤에 병을 살펴보며 뒷다리를 처음 보았다는 (A)가 이어지면 시간이 거꾸로예요. (C)도 'Those back legs'(그 뒷다리)로 시작하는데, 뒷다리는 (A)의 끝에 처음 나와요.",
   ["(A)의 끝에서 본 뒷다리를 (C)가 'Those back legs'(그 뒷다리)로 받아요. (C)의 끝에서 꼬리가 짧아지던 올챙이를 (B)가 'that small animal'(그 작은 동물)로 받아요. 두 군데가 다 맞물려요.",
 "(B)의 'that small animal'(그 작은 동물)이 어느 한 마리를 가리키는지 주어진 글만으로는 알 수 없어요. 올챙이를 한 마리로 처음 말하는 곳은 (A)의 끝이에요. 또 개구리가 된 뒤에 뒷다리가 처음 보였다는 (A)가 오는 것도 차례가 거꾸로예요.",
 "(B)의 'that small animal'(그 작은 동물)이 어느 한 마리를 가리키는지 주어진 글만으로는 알 수 없어요. 또 (B) 뒤의 (C)에서 'Those back legs'(그 뒷다리)가 가리킬 뒷다리도 앞에 나오지 않아요. 뒷다리는 (A)의 끝에 처음 나와요.",
 "(C)의 'Those back legs'(그 뒷다리)가 가리킬 뒷다리가 주어진 글에 없어요. 뒷다리는 (A)의 끝에 처음 나와요. 그래서 (C)는 맨 앞에 올 수 없어요.",
 "(C)의 'Those back legs'(그 뒷다리)가 가리킬 뒷다리가 주어진 글에 없어서 (C)는 맨 앞에 올 수 없어요. 또 개구리가 된 뒤에 뒷다리가 처음 보였다는 (A)가 오는 것도 차례가 거꾸로예요."],
   'tadpole 올챙이 / jar 병, 단지 / frog 개구리 / pond 연못')
