# -*- coding: utf-8 -*-
# 313번: 35번(무관한 문장) 레벨4 — 레벨 기준에 맞춤: 관계사절이 없는 문항에 문장 하나를 관계사절이 든 문장으로 바꿈
# 선생님 결정(308번): 「진행하고, 4·5도 같은 방식으로 진행해.」 — 레벨4의 기준(측정기준표): 중간 수준 낱말 · 복문 둘 · 관계대명사 하나
# 서른 문항을 읽어 가림: 관계사절이 이미 있는 문항 18(1·2·3·4·5·7·8·10·11·14·16·17·20·21·26·28·29·30번째) → 그대로 둠
#   관계사절이 없는 문항 11(6·9·12·13·15·18·19·22·24·25·27번째) + 관계대명사가 생략된 문항 1(23번째) → 문장 하나씩만 바꿈
# 글감·정답 번호·나머지 문장·풀이·해설은 그대로(레벨4의 풀이·해설은 문장을 인용하지 않고 내용만 말하므로 손댈 것이 없음). 뜻이 달라진 문장은 해석도 함께 고침
AUTO_SYNC = False
E = {}
SENT = {   # 번째-1: (옛 문장, 새 문장, 옛 해석 또는 None, 새 해석 또는 None)
 5:  ("④ Sweating uses water to hold body temperature steady in heat.", "④ Sweat, which is mostly water, keeps body temperature steady in hot weather.",
      "④ 땀은 더위에서 체온을 일정하게 붙들려고 물을 쓴다.", "④ 땀은 대부분이 물인데, 더운 날씨에 체온을 일정하게 유지해 준다."),
 8:  ("③ A sailor counts the seconds between flashes and checks the chart.", "③ A sailor who counts the seconds between flashes can find the lighthouse on a chart.",
      "③ 선원은 섬광 사이의 초를 세고 해도를 확인한다.", "③ 섬광 사이의 초를 세는 선원은 해도에서 그 등대를 찾을 수 있다."),
 11: ("① A leaf loses water constantly through tiny openings on its surface.", "① A leaf loses water constantly through the tiny openings that cover its surface.",
      "① 잎은 그 표면의 작은 구멍을 통해 끊임없이 물을 잃는다.", "① 잎은 그 표면을 덮고 있는 작은 구멍들을 통해 끊임없이 물을 잃는다."),
 12: ("③ Bacteria need liquid water and cannot grow without it.", "③ The bacteria that spoil food need liquid water and cannot grow without it.",
      "③ 세균은 액체 상태의 물을 필요로 하고 그것 없이는 자랄 수 없다.", "③ 음식을 상하게 하는 세균은 액체 상태의 물을 필요로 하고 그것 없이는 자랄 수 없다."),
 14: ("④ Two people standing apart are therefore seeing different drops.", "④ Two people who stand apart are therefore seeing different drops.", None, None),
 17: ("⑤ A patched one never holds as well as one spun in a single session.", "⑤ A web that has been patched never holds as well as one spun in a single session.", None, None),
 18: ("① Water released from deep in a reservoir is colder than the river used to be.", "① Water that is released from deep in a reservoir is colder than the river used to be.", None, None),
 21: ("① Any place receiving less than about twenty-five centimetres a year counts as one.", "① Any place that receives less than about twenty-five centimetres of rain a year counts as one.",
      "① 1년에 약 25센티미터보다 적게 받는 곳이면 어디든 그것에 해당한다.", "① 1년에 비가 약 25센티미터보다 적게 오는 곳이면 어디든 그것에 해당한다."),
 22: ("③ New polyps grow on the skeletons the old ones left behind.", "③ New polyps grow on the skeletons that the old ones left behind.", None, None),
 23: ("② A whale cannot fall fully asleep, because breathing is a decision for it.", "② A whale, which has to decide to take every breath, cannot fall fully asleep.",
      "② 고래는 완전히 잠들 수 없는데, 숨 쉬는 것이 그것에게는 하나의 결정이기 때문이다.", "② 고래는 숨을 쉴 때마다 그렇게 하기로 마음먹어야 하므로 완전히 잠들 수 없다."),
 24: ("② Warm air over a hot surface rises and leaves lower pressure behind it.", "② Air that is warmed by a hot surface rises and leaves lower pressure behind it.",
      "② 뜨거운 면 위의 따뜻한 공기가 올라가고 그 뒤에 낮은 기압을 남긴다.", "② 뜨거운 면에 데워진 공기가 올라가고 그 뒤에 낮은 기압을 남긴다."),
 26: ("① Cutting a magnet in half produces two magnets, each with both ends.", "① Cutting a magnet in half produces two magnets, each of which has both ends.", None, None),
}
for n, (a, b, ka, kb) in SENT.items():
    e = {'passage_ok': True, 'text': (a, b)}
    if ka: e['ko'] = (ka, kb)
    E[('35', '4', n)] = e
