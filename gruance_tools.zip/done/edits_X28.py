# -*- coding: utf-8 -*-
# 281번: 31번(빈칸 추론) 레벨4 — 30문항을 다 읽고 한 문항을 바로잡음
# 레벨4의 31번은 몸 쓰는 요령(짐 들기, 문 밀기, 계단, 배낭, 젖은 바닥, 걸레질, 밧줄, 못 뽑기, 삽질 …)이고, 서른 모두 because/since/which로 근거를 지문 안에 달고 있어 탈이 거의 없음
#   22번째 — 빈칸 문장의 틀과 선택지의 꼴이 맞지 않음: 'Opening with ______ turns …'에 정답 'using the far hand'를 넣으면 'Opening with using the far hand turns …'가 되어 말이 서지 않음(다른 선택지도 모두 ~ing 꼴)
#            → 'What helps is ______, which turns the shoulders and the head toward the road automatically, …'
AUTO_SYNC = False
E = {}
from z8common import maker
mk = maker(E, '31', lv='4')
def fix(n, text, ko):
    E[('31', '4', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 22번째: 차 문은 먼 쪽 손으로 ----------
mk(21, 0, [
 "1) 빈칸 문장: 둘째 문장입니다. «What helps is»(도움이 되는 것은 ~이다). 차 문을 열 때 무엇이 도움이 되는지를 묻습니다. 뒤의 which가 그것이 하는 일을 말해 줍니다.",
 "2) 짝꿍 문장: 첫 문장입니다. «A driver who opens the door with the near hand faces forward and sees nothing behind.»(가까운 쪽 손으로 문을 여는 운전자는 앞을 향한 채 뒤를 전혀 보지 못한다.) 탈은 'the near hand'(가까운 쪽 손)입니다. 문에 가까운 손으로 열면 몸이 돌지 않습니다.",
 "3) 뒤쪽 단서: «turns the shoulders and the head toward the road automatically»(어깨와 고개를 저절로 도로 쪽으로 돌린다). 빈칸의 방법은 몸을 저절로 돌게 합니다. 문에서 먼 쪽 손을 뻗으면 몸이 틀어지고, 고개가 뒤쪽 도로를 향합니다. 뒤에서 오는 자전거가 보입니다.",
 "4) 묶기: 가까운 쪽 손의 반대 = 먼 쪽 손 = 'using the far hand'. 'near'(가까운)를 'far'(먼)로 뒤집은 것입니다."],
 "「그 거울을 보기」가 가장 끌립니다. 뒤를 보려면 거울을 보라고 배우기 때문입니다. 하지만 빈칸 뒤는 그 방법이 어깨와 고개를 저절로 도로 쪽으로 돌린다고 했습니다. 거울을 볼 때는 몸이 돌지 않습니다. 저절로 되는 일도 아닙니다. 「그것을 천천히 열기」도 조심합니다. 조심하는 방법이기는 하지만, 천천히 열어도 앞을 향한 채라면 뒤는 여전히 보이지 않습니다.",
 [("먼 쪽 손을 쓰기", "빈칸 뒤의 «turns the shoulders and the head toward the road automatically»가 근거입니다. 문에서 먼 쪽 손을 뻗으면 몸이 틀어져 고개가 저절로 뒤쪽 도로를 향합니다. 가까운 쪽 손으로 열 때와 반대입니다."),
  ("그 손잡이를 단단히 잡기", "지문에 없는 이야기입니다. 손잡이를 어떻게 잡는지는 나오지 않습니다. 단단히 잡아도 몸은 앞을 향한 채입니다."),
  ("그것을 천천히 열기", "지문에 없는 이야기입니다. 조심하는 방법이라서 끌리지만, 빠르기는 나오지 않습니다. 천천히 열어도 어깨와 고개가 돌지는 않습니다."),
  ("먼저 뒤로 물러서기", "지문에 없는 이야기입니다. 차 안에 앉은 운전자는 뒤로 물러설 수 없습니다. 글이 말하는 것은 어느 손으로 여느냐입니다."),
  ("그 거울을 보기", "뒤를 보는 방법이라서 끌립니다. 하지만 빈칸 뒤는 그 방법이 어깨와 고개를 저절로 돌린다고 했습니다. 거울을 볼 때는 몸이 돌지 않고, 저절로 되는 일도 아닙니다.")])
fix(21, ('Opening with ______ turns the shoulders and the head toward the road automatically, and cyclists are safer for it.', 'What helps is ______, which turns the shoulders and the head toward the road automatically, and cyclists are safer for it.'),
        ('______으로 열면 어깨와 고개가 저절로 도로 쪽으로 돌아가고, 자전거 이용자가 그 덕에 안전해진다.', '도움이 되는 것은 ______인데, 그것이 어깨와 고개를 저절로 도로 쪽으로 돌려 주고, 자전거 이용자가 그 덕에 안전해진다.'))
