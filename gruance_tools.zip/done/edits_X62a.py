# -*- coding: utf-8 -*-
# 333번: 36-37번(글의 순서) 레벨1 앞 절반 — 단순문장 · 한 문장 10~15낱말 · 세 덩이 각 두 문장. 정답 번호·선택지·발문은 바탕 그대로, 지문·해석·풀이·해설을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z3637common import maker
rw = maker(E, '1')

# 1번째 (정답 순서 CAB)
rw(0, 'Last Saturday, Tom baked cookies for the first time in his life.',
   {'A': ['After that hour, he cut the cold dough into twelve small round pieces.', 'He left them in the hot oven for fifteen minutes.'],
 'B': ['Those fifteen minutes were too long for such small cookies.', "Tom's first cookies came out of the oven dark and hard."],
 'C': ['In the morning, he mixed flour, sugar and butter into a soft dough.', 'He then put the dough in the fridge for one full hour.']},
   '지난 토요일, 톰은 태어나서 처음으로 쿠키를 구웠다.',
   {'A': ['그 한 시간이 지난 뒤, 그는 차가운 반죽을 작고 동그란 조각 열두 개로 잘랐다.', '그는 그 조각들을 뜨거운 오븐에 십오 분 동안 두었다.'],
 'B': ['그 십오 분은 그렇게 작은 쿠키에는 너무 긴 시간이었다.', '톰의 첫 쿠키는 거무스름하고 딱딱한 채로 오븐에서 나왔다.'],
 'C': ['아침에 그는 밀가루, 설탕, 버터를 섞어 부드러운 반죽을 만들었다.', '그런 다음 그는 그 반죽을 냉장고에 꼬박 한 시간 동안 넣어 두었다.']},
   ['1) 주어진 글: 지난 토요일에 톰이 처음으로 쿠키를 구웠다고 해요. 이어서 쿠키를 어떤 차례로 만들었는지가 나올 거예요.',
 '2) 첫째 글 (C): «In the morning, he mixed flour, sugar and butter into a soft dough.»(아침에 그는 밀가루, 설탕, 버터를 섞어 부드러운 반죽을 만들었다.) 이 문장에는 앞의 것을 가리키는 말이 없어요. 아침에 재료를 섞는 일이니 쿠키 굽기의 시작으로 알맞아요. (C)는 반죽을 냉장고에 '
 '꼬박 한 시간 동안 넣어 두었다는 말로 끝나요.',
 "3) 둘째 글 (A): «After that hour, he cut the cold dough into twelve small round pieces.»(그 한 시간이 지난 뒤, 그는 차가운 반죽을 작고 동그란 조각 열두 개로 잘랐다.) 'that hour'(그 한 시간)는 앞에 나온 한 시간을 가리켜요. (C)의 끝에 있는 'one full "
 "hour'(꼬박 한 시간)가 그것이에요. 냉장고에 있었으니 반죽이 'cold'(차가운) 것도 맞아요. (A)는 조각들을 오븐에 십오 분 동안 두었다는 말로 끝나요.",
 "4) 셋째 글 (B)와 확인: «Those fifteen minutes were too long for such small cookies.»(그 십오 분은 그렇게 작은 쿠키에는 너무 긴 시간이었다.) 'Those fifteen minutes'(그 십오 분)는 (A)의 끝에 있는 오븐 속 십오 분이에요. 반죽을 만듦 → 한 시간 뒤에 자름 → 십오 분 "
 '동안 구움 → 너무 오래 구워서 딱딱해짐. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(A)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)에는 주어진 글과 같은 'first'(첫)과 'cookies'(쿠키)가 있거든요. 하지만 낱말이 같다고 바로 이어지는 것은 아니에요. (B)는 'Those fifteen minutes'(그 십오 분)로 시작해요. 주어진 글에는 십오 분이 나오지 않으니 가리킬 것이 없어요. (A)와 (B)에 모두 'oven'(오븐)이 있다고 차례를 헷갈리지도 마세요. 십오 분은 (A)의 끝에 처음 나오고, (B)가 그것을 받아요.",
   ["(A)의 'that hour'(그 한 시간)가 가리킬 시간이 주어진 글에 없어요. 한 시간은 (C)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'Those fifteen minutes'(그 십오 분)가 가리킬 시간이 주어진 글에 없어요. 다 구운 쿠키가 맨 먼저 나오고 반죽을 만드는 일이 맨 끝에 와서 차례도 거꾸로예요.",
 "(B)의 'Those fifteen minutes'(그 십오 분)가 가리킬 시간이 앞에 없어요. 주어진 글과 같은 낱말이 있어서 끌리지만, 십오 분은 (A)의 끝에 처음 나와요.",
 "(C)의 끝에 있는 한 시간을 (A)의 'that hour'(그 한 시간)가 받아요. (A)의 끝에 있는 십오 분을 (B)의 'Those fifteen minutes'(그 십오 분)가 받아요. 반죽 만들기, 자르기, 굽기의 차례예요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (B)가 오면 'Those fifteen minutes'(그 십오 분)가 가리킬 것이 없어요. (C)에 나온 시간은 한 시간이에요."],
   'dough 반죽 / oven 오븐 / fridge 냉장고')

# 2번째 (정답 순서 ACB)
rw(1, 'Lily grew three small tomato plants in pots by her bedroom window.',
   {'A': ['Their leaves slowly turned yellow one after another in early June.', 'Lily gave the plants more and more water every day.'],
 'B': ['He gave the plants very little water for the next ten days.', 'After that, new green leaves appeared on all three of her plants.'],
 'C': ['However, all that extra water only turned more of the leaves yellow.', 'Her grandfather shook his head at the wet soil in the pots.']},
   '릴리는 자기 방 창가의 화분에서 작은 토마토 세 포기를 길렀다.',
   {'A': ['유월 초에 그 잎들이 하나둘 천천히 노랗게 변했다.', '릴리는 날마다 그 식물들에 물을 점점 더 많이 주었다.'],
 'B': ['그는 그다음 열흘 동안 식물들에 물을 아주 조금만 주었다.', '그러자 릴리의 식물 세 포기 모두에서 새 초록 잎이 돋아났다.'],
 'C': ['하지만 그렇게 더 준 물은 더 많은 잎을 노랗게 만들 뿐이었다.', '릴리의 할아버지는 화분의 젖은 흙을 보고 고개를 저었다.']},
   ['1) 주어진 글: 릴리가 창가의 화분에서 토마토 세 포기를 길렀다고 해요. 이어서 그 토마토에 무슨 일이 생겼는지가 나올 거예요.',
 "2) 첫째 글 (A): «Their leaves slowly turned yellow one after another in early June.»(유월 초에 그 잎들이 하나둘 천천히 노랗게 변했다.) 'Their'(그것들의)는 앞에서 말한 여럿을 가리켜요. 주어진 글의 'three small tomato plants'(작은 토마토 세 포기)가 바로 "
 '그것이에요. 그래서 (A)가 주어진 글 바로 뒤에 와요. (A)는 릴리가 날마다 물을 점점 더 많이 주었다는 말로 끝나요.',
 "3) 둘째 글 (C): «However, all that extra water only turned more of the leaves yellow.»(하지만 그렇게 더 준 물은 더 많은 잎을 노랗게 만들 뿐이었다.) 'all that extra water'(그렇게 더 준 물)는 (A)의 끝에서 릴리가 더 준 물이에요. 'However'(하지만)는 "
 '물을 더 주었는데도 나아지지 않았다고 앞의 말을 뒤집어요. (C)는 릴리의 할아버지가 젖은 흙을 보고 고개를 저었다는 말로 끝나요.',
 "4) 셋째 글 (B)와 확인: «He gave the plants very little water for the next ten days.»(그는 그다음 열흘 동안 식물들에 물을 아주 조금만 주었다.) 'He'(그)는 남자를 가리켜요. 주어진 글에는 여자인 릴리밖에 없지만, (C)의 끝에 할아버지가 나왔어요. 그 할아버지가 물을 줄인 거예요. 잎이 "
 '노래짐 → 물을 더 줌 → 더 나빠짐 → 할아버지가 물을 줄임 → 새잎이 돋음. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (A)-(C)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)에는 주어진 글과 같은 'three'(셋)와 'plants'(식물들)가 있거든요. 하지만 낱말이 같다고 바로 이어지는 것은 아니에요. (B)는 'He'(그)로 시작하는데, 주어진 글에는 남자가 나오지 않아요. 그가 누구인지 알 수 없으니 (B)는 맨 앞에 올 수 없어요. (A) 바로 뒤에 (B)를 놓는 것도 조심해요. 두 글에 똑같이 'water'(물)가 있어서 이어질 것 같지만, (A)까지 읽어도 남자는 아직 나오지 않았어요. 할아버지는 (C)의 끝에 처음 나와요.",
   ["(A)의 'Their'(그것들의)가 주어진 글의 토마토 세 포기를 받아요. (C)의 'all that extra water'(그렇게 더 준 물)는 (A)의 끝에서 릴리가 더 준 물이에요. (B)의 'He'(그)는 (C)의 끝에 나온 할아버지예요. 세 군데가 다 맞물려요.",
 "(B)의 'He'(그)가 가리킬 사람이 주어진 글에 없어요. 주어진 글에는 릴리만 나와요. 주어진 글과 같은 낱말이 있어서 끌리지만, 낱말이 같다고 이어지는 것은 아니에요.",
 "(B)의 'He'(그)가 가리킬 사람이 앞에 없어요. 또 새잎이 돋았다는 (B) 뒤에 잎이 더 노래졌다는 (C)가 오면 이야기가 거꾸로 가요.",
 "(C)의 'all that extra water'(그렇게 더 준 물)가 가리킬 물이 주어진 글에 없어요. 물을 더 준 일은 (A)의 끝에 나와요. 'However'(하지만)가 뒤집을 말도 앞에 없어요.",
 "(C)의 'all that extra water'(그렇게 더 준 물)가 가리킬 물이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 잎이 노래지기 시작했다는 (A)가 맨 끝에 오는 것도 맞지 않아요."],
   'leaves 잎 / soil 흙 / pot 화분')

# 3번째 (정답 순서 ACB)
rw(2, 'On a rainy Monday, Jiho left his blue umbrella on the bus.',
   {'A': ['At home, he called the bus company about his lost umbrella.', 'A kind woman wrote down his name and his phone number.'],
 'B': ['On Friday after school, he went to that office alone.', 'The woman gave the umbrella back to him with a smile.'],
 'C': ['She later called him back with some very good news.', 'His blue umbrella was waiting at the bus station office.']},
   '비 오는 월요일에 지호는 파란 우산을 버스에 두고 내렸다.',
   {'A': ['집에서 그는 잃어버린 우산 때문에 버스 회사에 전화를 걸었다.', '친절한 여자분이 그의 이름과 전화번호를 적어 두었다.'],
 'B': ['금요일 방과 후에 그는 혼자 그 사무실에 갔다.', '그 여자분은 웃는 얼굴로 우산을 그에게 돌려주었다.'],
 'C': ['그녀는 얼마 뒤 아주 좋은 소식을 가지고 그에게 다시 전화했다.', '그의 파란 우산이 버스 터미널 사무실에서 기다리고 있었다.']},
   ['1) 주어진 글: 비 오는 월요일에 지호가 파란 우산을 버스에 두고 내렸다고 해요. 이어서 우산을 찾으려고 한 일이 나올 거예요.',
 "2) 첫째 글 (A): «At home, he called the bus company about his lost umbrella.»(집에서 그는 잃어버린 우산 때문에 버스 회사에 전화를 걸었다.) 'he'(그)는 지호예요. 'his lost umbrella'(그가 잃어버린 우산)는 주어진 글에서 버스에 두고 내린 파란 우산이에요. 우산을 잃어버린 "
 '일 바로 뒤에 우산을 찾으려고 전화하는 것이 자연스러워요. (A)는 친절한 여자분이 이름과 전화번호를 적어 두었다는 말로 끝나요.',
 "3) 둘째 글 (C): «She later called him back with some very good news.»(그녀는 얼마 뒤 아주 좋은 소식을 가지고 그에게 다시 전화했다.) 'She'(그녀)는 (A)의 끝에 나온 친절한 여자분이에요. 'called him back'(다시 전화했다)는 지호가 먼저 전화했기 때문에 쓸 수 있는 말이에요. "
 '(C)는 우산이 버스 터미널 사무실에 있다는 말로 끝나요.',
 "4) 셋째 글 (B)와 확인: «On Friday after school, he went to that office alone.»(금요일 방과 후에 그는 혼자 그 사무실에 갔다.) 'that office'(그 사무실)는 (C)의 끝에 나온 'the bus station office'(버스 터미널 사무실)예요. 우산이 있다는 소식을 들은 뒤에야 찾으러 "
 '갈 수 있어요. 우산을 잃어버림 → 전화함 → 여자분이 소식을 알려 줌 → 사무실에 가서 우산을 돌려받음. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (A)-(C)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글에서 우산을 잃어버렸으니 우산을 찾으러 가는 이야기가 바로 이어질 것 같거든요. 하지만 (B)는 첫 문장에 'that office'(그 사무실)가 나와요. 주어진 글에는 사무실이 나오지 않아서 가리킬 것이 없어요. (A)에 나오는 'the bus company'(버스 회사)가 사무실이라고 생각하기 쉬운데, 그렇다 해도 (B)에서 지호는 이미 우산을 돌려받아요. 그러면 (A)의 전화와 (C)의 반가운 소식이 모두 쓸모없어져요.",
   ["(A)에서 지호가 버스 회사에 전화해요. (C)의 'She'(그녀)는 (A)의 끝에 나온 여자분이에요. (B)의 'that office'(그 사무실)는 (C)의 끝에 나온 사무실이에요. 전화, 소식, 찾으러 가기의 차례예요.",
 "(B)의 'that office'(그 사무실)가 가리킬 곳이 주어진 글에 없어요. 우산을 돌려받은 뒤에 우산을 잃어버렸다며 전화하는 것도 차례가 거꾸로예요.",
 "(B)의 'that office'(그 사무실)가 가리킬 곳이 앞에 없어요. 우산을 이미 돌려받았는데 (C)에서 우산이 사무실에서 기다린다는 소식을 듣는 것도 맞지 않아요.",
 "(C)의 'She'(그녀)가 가리킬 여자가 주어진 글에 없어요. 'called him back'(다시 전화했다)라고 했으니 지호가 먼저 전화한 일이 앞에 있어야 해요. 그 일은 (A)에 나와요.",
 "(C)의 'She'(그녀)가 가리킬 여자가 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 우산을 돌려받은 뒤에 (A)에서 전화하는 것도 차례가 거꾸로예요."],
   'umbrella 우산 / company 회사 / office 사무실')

# 4번째 (정답 순서 BCA)
rw(3, "On Lunar New Year's Day, many Korean families eat tteokguk together in the morning.",
   {'A': ['Because of this coin shape, the soup holds a wish for more money.', 'So every bowl of this soup carries two good wishes for the new year.'],
 'B': ['This soup has many thin white slices of rice cake in it.', 'Their white color means a clean start to the year.'],
 'C': ['The shape of the slices also has a different meaning.', 'Each of them looks a little like an old Korean coin.']},
   '음력 설날에 많은 한국 가정은 아침에 함께 떡국을 먹는다.',
   {'A': ['이 동전 모양 때문에 그 국에는 돈이 더 많아지기를 바라는 마음이 담겨 있다.', '그래서 이 국은 한 그릇마다 새해를 위한 좋은 바람 두 가지를 담고 있다.'],
 'B': ['이 국에는 얇고 흰 떡 조각이 많이 들어 있다.', '그 흰 빛깔은 한 해를 깨끗하게 시작한다는 뜻이다.'],
 'C': ['떡 조각의 모양에도 다른 뜻이 있다.', '떡 조각 하나하나는 옛날 한국 동전과 조금 닮았다.']},
   ['1) 주어진 글: 음력 설날에 많은 한국 가정이 아침에 함께 떡국을 먹는다고 해요. 이어서 떡국이 어떤 음식인지, 어떤 뜻이 담겼는지가 나올 거예요.',
 "2) 첫째 글 (B): «This soup has many thin white slices of rice cake in it.»(이 국에는 얇고 흰 떡 조각이 많이 들어 있다.) 'This soup'(이 국)은 주어진 글의 'tteokguk'(떡국)을 가리켜요. 떡 조각을 처음 알려 주는 글이기도 해요. (B)는 흰 빛깔이 깨끗한 시작을 뜻한다는 "
 '말로 끝나요.',
 "3) 둘째 글 (C): «The shape of the slices also has a different meaning.»(떡 조각의 모양에도 다른 뜻이 있다.) 'also'(~도)는 앞에 뜻이 하나 나와 있어야 쓸 수 있어요. (B)의 끝에 나온 흰 빛깔의 뜻이 그것이에요. 'the slices'(그 조각들)도 (B)의 떡 조각을 받아요. (C)는 "
 '떡 조각이 옛날 동전과 닮았다는 말로 끝나요.',
 "4) 셋째 글 (A)와 확인: «Because of this coin shape, the soup holds a wish for more money.»(이 동전 모양 때문에 그 국에는 돈이 더 많아지기를 바라는 마음이 담겨 있다.) 'this coin shape'(이 동전 모양)은 (C)의 끝에 나온 동전을 닮은 모양이에요. 마지막 문장의 'two "
 "good wishes'(좋은 바람 두 가지)는 깨끗한 시작과 돈, 두 가지를 다 들은 뒤에야 할 수 있는 말이에요. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(C)-(A)예요."],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. (C)와 (A)가 동전 이야기로 딱 붙어 있어서 그 둘부터 묶고 싶어지거든요. 하지만 (C)에는 'also'(~도)가 있어요. 뜻이 하나 먼저 나와 있어야 해요. 'the slices'(그 조각들)가 가리킬 떡 조각도 주어진 글에는 없어요. 둘 다 (B)에 있으니 (B)가 (C) 앞에 와야 해요.",
   ["(A)의 'this coin shape'(이 동전 모양)이 가리킬 것이 주어진 글에 없어요. 동전은 (C)의 끝에 처음 나와요. 뜻을 하나도 듣기 전에 'two good wishes'(좋은 바람 두 가지)라고 맺는 것도 맞지 않아요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (A)가 오면 'this coin shape'(이 동전 모양)이 가리킬 것이 없어요. (B)에는 흰 빛깔 이야기만 있어요.",
 "(B)의 'This soup'(이 국)이 주어진 글의 떡국을 받아요. (C)의 'also'(~도)는 (B)의 끝에 나온 흰 빛깔의 뜻에 하나를 더해요. (A)의 'this coin shape'(이 동전 모양)은 (C)의 끝에 나온 동전 모양이에요.",
 "(C)의 'also'(~도)는 앞에 다른 뜻이 있어야 쓸 수 있는데, 주어진 글에는 뜻 이야기가 없어요. 떡 조각을 처음 알려 주는 (B)가 맨 끝에 오는 것도 맞지 않아요.",
 "(C)의 'also'(~도)가 받을 뜻이 앞에 없어요. 또 (A)의 'this coin shape'(이 동전 모양)이 (C)의 동전에서 떨어지고, 그 사이에 (B)가 끼어들어요."],
   'slice 얇게 썬 조각 / coin 동전 / wish 바람')

# 5번째 (정답 순서 BAC)
rw(4, 'Hyunwoo wanted to play the guitar at the school festival.',
   {'A': ['By October, his fingers no longer hurt after all that practice.', 'He then asked his music teacher to put his name on the festival list.'],
 'B': ['His uncle gave him an old guitar on his birthday.', 'Every night after dinner, Hyunwoo practiced one easy song again and again.'],
 'C': ['At the festival, his name was first on that list.', 'Hyunwoo played the whole song on the big stage without a mistake.']},
   '현우는 학교 축제에서 기타를 연주하고 싶었다.',
   {'A': ['시월이 되자 그 모든 연습을 한 뒤라서 그의 손가락은 더는 아프지 않았다.', '그러고 나서 그는 음악 선생님께 축제 명단에 자기 이름을 올려 달라고 부탁했다.'],
 'B': ['그의 삼촌이 생일에 그에게 낡은 기타를 주었다.', '현우는 저녁 식사 후 매일 밤 쉬운 노래 한 곡을 되풀이해서 연습했다.'],
 'C': ['축제에서 그의 이름은 그 명단의 맨 처음에 있었다.', '현우는 큰 무대에서 그 노래 전체를 실수 없이 연주했다.']},
   ['1) 주어진 글: 현우가 학교 축제에서 기타를 연주하고 싶었다고 해요. 이어서 그 바람을 이루려고 한 일이 나올 거예요.',
 "2) 첫째 글 (B): «His uncle gave him an old guitar on his birthday.»(그의 삼촌이 생일에 그에게 낡은 기타를 주었다.) 'him'(그에게)은 주어진 글의 현우예요. 연주하려면 먼저 기타가 있어야 하니 기타를 받는 일이 맨 처음으로 알맞아요. (B)는 현우가 쉬운 노래 한 곡을 되풀이해서 연습했다는 말로 "
 '끝나요.',
 "3) 둘째 글 (A): «By October, his fingers no longer hurt after all that practice.»(시월이 되자 그 모든 연습을 한 뒤라서 그의 손가락은 더는 아프지 않았다.) 'all that practice'(그 모든 연습)는 (B)의 끝에 나온 밤마다 한 연습이에요. (A)는 음악 선생님께 축제 명단에 "
 '이름을 올려 달라고 부탁했다는 말로 끝나요.',
 "4) 셋째 글 (C)와 확인: «At the festival, his name was first on that list.»(축제에서 그의 이름은 그 명단의 맨 처음에 있었다.) 'that list'(그 명단)은 (A)의 끝에 나온 'the festival list'(축제 명단)이에요. 기타를 받음 → 연습함 → 명단에 이름을 올림 → 무대에서 "
 '연주함. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(A)-(C)예요.'],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. (C)에 주어진 글과 같은 'festival'(축제)이 있고, 현우가 기타를 연주하고 싶다고 했으니 연주하는 장면이 바로 이어질 것 같거든요. 하지만 (C)는 'that list'(그 명단)으로 이어지는데, 주어진 글에는 명단이 나오지 않아요. 명단은 (A)의 끝에 처음 나오므로 (A)가 (C) 앞에 와야 해요.",
   ["(A)의 'all that practice'(그 모든 연습)가 가리킬 연습이 주어진 글에 없어요. 연습 이야기는 (B)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'him'(그에게)은 주어진 글의 현우예요. (A)의 'all that practice'(그 모든 연습)는 (B)의 끝에 나온 연습이에요. (C)의 'that list'(그 명단)은 (A)의 끝에 나온 명단이에요. 세 군데가 다 맞물려요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에 (C)가 오면 'that list'(그 명단)이 가리킬 것이 없어요. (B)에는 명단이 나오지 않아요.",
 "(C)의 'that list'(그 명단)이 가리킬 명단이 주어진 글에 없어요. 무대에서 연주를 마친 뒤에 기타를 받는 것도 차례가 거꾸로예요.",
 "(C)의 'that list'(그 명단)이 가리킬 명단이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 무대에서 연주를 마친 뒤에 기타를 받고 연습하는 (B)가 오고, 명단을 부탁하는 (A)가 맨 끝에 오는 것도 차례가 거꾸로예요."],
   'festival 축제 / practice 연습(하다) / list 명단')

# 6번째 (정답 순서 BAC)
rw(5, 'A small brown puppy followed Yuna home from school one rainy day.',
   {'A': ['The next morning, the puppy was warm and full of energy.', "Yuna's mother called the neighbors to find its real owner."],
 'B': ["Yuna's mother did not want a dog in their small apartment.", 'However, she let the cold puppy sleep in the kitchen that night.'],
 'C': ['At noon, the real owner came to their door in a hurry.', "He thanked Yuna's family for taking care of the puppy."]},
   '작은 갈색 강아지 한 마리가 비 오는 어느 날 학교에서 돌아오는 유나를 집까지 따라왔다.',
   {'A': ['다음 날 아침 그 강아지는 몸이 따뜻해졌고 기운이 넘쳤다.', '유나의 어머니는 그 강아지의 진짜 주인을 찾으려고 이웃들에게 전화했다.'],
 'B': ['유나의 어머니는 작은 아파트에서 개를 키우는 것을 원하지 않았다.', '하지만 어머니는 그날 밤 몸이 찬 강아지를 부엌에서 자게 해 주었다.'],
 'C': ['정오에 진짜 주인이 서둘러 그들의 문 앞에 왔다.', '그는 강아지를 돌봐 준 유나의 가족에게 고마워했다.']},
   ['1) 주어진 글: 비 오는 날 작은 갈색 강아지가 유나를 집까지 따라왔다고 해요. 이어서 그 강아지가 어떻게 되었는지가 나올 거예요.',
 "2) 첫째 글 (B): «Yuna's mother did not want a dog in their small apartment.»(유나의 어머니는 작은 아파트에서 개를 키우는 것을 원하지 않았다.) 강아지가 집까지 따라온 날의 이야기를 이어 가요. 그런데도 «However, she let the cold puppy sleep in the "
 "kitchen that night.»(하지만 어머니는 그날 밤 몸이 찬 강아지를 부엌에서 자게 해 주었다.)라고 해요. (B)는 'that night'(그날 밤)으로 끝나요.",
 "3) 둘째 글 (A): «The next morning, the puppy was warm and full of energy.»(다음 날 아침 그 강아지는 몸이 따뜻해졌고 기운이 넘쳤다.) 'The next morning'(다음 날 아침)은 (B)의 'that night'(그날 밤) 바로 다음이에요. 몸이 찼던 강아지가 밤새 부엌에서 자고 나서 "
 '따뜻해진 것도 자연스러워요. (A)는 어머니가 진짜 주인을 찾으려고 이웃들에게 전화했다는 말로 끝나요.',
 "4) 셋째 글 (C)와 확인: «At noon, the real owner came to their door in a hurry.»(정오에 진짜 주인이 서둘러 그들의 문 앞에 왔다.) 'the real owner'(진짜 주인)는 (A)의 끝에서 찾으려던 'its real owner'예요. 강아지가 따라옴 → 어머니가 하룻밤 재워 줌 → 다음 날 "
 '주인을 찾음 → 주인이 옴. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(A)-(C)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글에 강아지가 나오고 (A)도 강아지 이야기로 시작하거든요. 하지만 (A)의 따뜻하고 기운찬 강아지는 (B)에서 몸이 찼던 강아지가 하룻밤을 보낸 뒤의 모습이에요. (A)가 앞에 오고 (B)에서 다시 몸이 찬 강아지가 나오면 강아지의 상태가 거꾸로예요. 'The next morning'(다음 날 아침)은 (B)의 'that night'(그날 밤) 바로 뒤에 놓을 때 가장 매끄럽게 이어져요.",
   ['(A)의 따뜻하고 기운찬 강아지는 (B)의 몸이 찬 강아지가 하룻밤을 보낸 뒤의 모습이에요. 그래서 (A)는 맨 앞에 올 수 없어요. 또 주인이 찾아온 (C) 뒤에 어머니가 개를 원하지 않았다는 (B)가 오는 것도 이야기가 거꾸로예요.',
 "(B)의 'that night'(그날 밤) 다음 날 아침이 (A)예요. (A)의 끝에서 찾으려던 'its real owner'(그 강아지의 진짜 주인)가 (C)에서 와요. 세 군데가 다 맞물려요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (C)의 'the real owner'(진짜 주인)는 (A)의 끝에서 찾으려던 주인이에요. (B) 바로 뒤에 (C)가 오면 'the real owner'가 가리킬 것이 없어요.",
 "(C)의 'the real owner'(진짜 주인)가 가리킬 것이 주어진 글에 없어요. 주인이 와서 고마워한 뒤에 어머니가 주인을 찾으려고 전화하는 것도 맞지 않아요.",
 "(C)의 'the real owner'(진짜 주인)가 가리킬 것이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 주인이 와서 고마워한 뒤에 그 강아지를 재우는 이야기가 나오는 것도 차례가 거꾸로예요."],
   'puppy 강아지 / owner 주인 / neighbor 이웃')

# 7번째 (정답 순서 ACB)
rw(6, 'Bees make honey from the sweet juice of many flowers.',
   {'A': ['A worker bee drinks the juice from hundreds of flowers each day.', 'She carries it home in a special part of her body.'],
 'B': ['Next, the bees move their wings quickly over those cells.', 'After many hours, the thin sweet juice becomes thick honey.'],
 'C': ['At the hive, other bees take the juice from her mouth.', 'They then put it into thousands of tiny wax cells.']},
   '벌은 많은 꽃의 달콤한 즙으로 꿀을 만든다.',
   {'A': ['일벌 한 마리는 하루에 수백 송이의 꽃에서 즙을 마신다.', '그 벌은 몸의 특별한 부분에 그것을 담아 집으로 가져온다.'],
 'B': ['다음으로 벌들은 그 칸들 위에서 날개를 빠르게 움직인다.', '몇 시간이 지나면 묽고 달콤한 즙이 걸쭉한 꿀이 된다.'],
 'C': ['벌집에서는 다른 벌들이 그 벌의 입에서 즙을 받아 간다.', '그러고 나서 벌들은 그것을 수천 개의 작은 밀랍 칸에 넣는다.']},
   ['1) 주어진 글: 벌이 많은 꽃의 달콤한 즙으로 꿀을 만든다고 해요. 이어서 꿀이 만들어지는 과정이 나올 거예요.',
 "2) 첫째 글 (A): «A worker bee drinks the juice from hundreds of flowers each day.»(일벌 한 마리는 하루에 수백 송이의 꽃에서 즙을 마신다.) 'the juice'(그 즙)는 주어진 글에 나온 꽃의 달콤한 즙이에요. 꿀을 만들려면 먼저 꽃에서 즙을 모아야 하니 꿀 만들기의 첫 단계로 "
 '알맞아요. (A)는 그 벌이 즙을 집으로 가져온다는 말로 끝나요.',
 "3) 둘째 글 (C): «At the hive, other bees take the juice from her mouth.»(벌집에서는 다른 벌들이 그 벌의 입에서 즙을 받아 간다.) 'the hive'(벌집)는 (A)의 끝에 나온 'home'(집)이에요. 'her'(그 벌의)는 (A)의 일벌 'She'를 가리켜요. 'other bees'(다른 "
 '벌들)도 앞에 먼저 나온 벌이 있어야 쓸 수 있는 말이에요. (C)는 즙을 수천 개의 작은 밀랍 칸에 넣는다는 말로 끝나요.',
 "4) 셋째 글 (B)와 확인: «Next, the bees move their wings quickly over those cells.»(다음으로 벌들은 그 칸들 위에서 날개를 빠르게 움직인다.) 'those cells'(그 칸들)는 (C)의 끝에 나온 'tiny wax cells'(작은 밀랍 칸)예요. 즙을 모음 → 집으로 가져옴 → 다른 벌들이 "
 '받아 칸에 넣음 → 날개를 움직여 꿀로 만듦. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (A)-(C)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)의 'the thin sweet juice'(묽고 달콤한 즙)가 주어진 글의 'sweet juice'(달콤한 즙)와 같은 말이거든요. 하지만 (B)는 'Next'(다음으로)와 'those cells'(그 칸들)로 시작해요. 'Next'는 앞에 먼저 한 일이 있어야 쓸 수 있고, 주어진 글에는 칸이 나오지 않아요. 칸은 (C)의 끝에 처음 나와요.",
   ["(A)의 'the juice'(그 즙)는 주어진 글의 꽃의 즙이에요. (C)의 'the hive'(벌집)와 'her'(그 벌의)는 (A)의 끝에 나온 집과 일벌이에요. (B)의 'those cells'(그 칸들)는 (C)의 끝에 나온 밀랍 칸이에요. 세 군데가 다 맞물려요.",
 "(B)의 'those cells'(그 칸들)가 가리킬 칸이 주어진 글에 없어요. 'Next'(다음으로)도 먼저 한 일이 없으면 쓸 수 없어요. 꿀이 다 만들어진 뒤에 꽃에서 즙을 마시는 (A)가 오는 것도 거꾸로예요.",
 "(B)의 'those cells'(그 칸들)가 가리킬 칸이 앞에 없어요. 칸은 (C)의 끝에 처음 나와요. (B)가 맨 앞에 오면 'Next'(다음으로)가 이어받을 일도 없어요.",
 "(C)의 'her'(그 벌의)가 가리킬 벌이 주어진 글에 없어요. (C)는 'other bees'(다른 벌들)라고 했으니 먼저 나온 벌이 있어야 해요. 그 벌은 (A)에 나와요.",
 "(C)의 'her'(그 벌의)가 가리킬 벌이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 칸에 넣은 뒤에 꽃에서 즙을 마시는 (A)가 맨 끝에 오는 것도 차례가 거꾸로예요."],
   'hive 벌집 / cell 벌집의 작은 칸 / wax 밀랍')

# 8번째 (정답 순서 BAC)
rw(7, "Our class planned a surprise party for Mr. Kim's birthday.",
   {'A': ['We hid the cake in a big box in the classroom.', 'Everyone waited quietly for Mr. Kim to come through the door.'],
 'B': ['Every student gave two thousand won to the class leader.', 'With that money, the leader bought a big chocolate cake.'],
 'C': ['At that moment, the teacher stood at the door with a surprised look.', 'Then we all sang a happy birthday song to him.']},
   '우리 반은 김 선생님의 생신을 위해 깜짝 파티를 계획했다.',
   {'A': ['우리는 교실의 큰 상자 안에 케이크를 숨겼다.', '모두가 김 선생님이 문으로 들어오시기를 조용히 기다렸다.'],
 'B': ['모든 학생이 반장에게 이천 원씩 냈다.', '그 돈으로 반장은 큰 초콜릿 케이크를 샀다.'],
 'C': ['바로 그때 선생님이 놀란 표정으로 문가에 서 계셨다.', '그러고 나서 우리는 모두 선생님께 생일 축하 노래를 불러 드렸다.']},
   ['1) 주어진 글: 우리 반이 김 선생님의 생신을 위해 깜짝 파티를 계획했다고 해요. 이어서 파티를 어떻게 준비하고 열었는지가 나올 거예요.',
 '2) 첫째 글 (B): «Every student gave two thousand won to the class leader.»(모든 학생이 반장에게 이천 원씩 냈다.) 파티를 준비하려면 먼저 돈이 있어야 하니 돈을 모으는 일이 첫 준비로 알맞아요. (B)는 «With that money, the leader bought a big chocolate '
 'cake.»(그 돈으로 반장은 큰 초콜릿 케이크를 샀다.)로 끝나요.',
 "3) 둘째 글 (A): «We hid the cake in a big box in the classroom.»(우리는 교실의 큰 상자 안에 케이크를 숨겼다.) 'the cake'(그 케이크)는 (B)의 끝에서 반장이 산 케이크예요. (A)는 모두가 김 선생님이 문으로 들어오시기를 조용히 기다렸다는 말로 끝나요.",
 "4) 셋째 글 (C)와 확인: «At that moment, the teacher stood at the door with a surprised look.»(바로 그때 선생님이 놀란 표정으로 문가에 서 계셨다.) 'At that moment'(바로 그때)는 (A)의 끝에서 모두가 기다리던 때이고, 'the teacher'(선생님)는 김 선생님이에요. "
 '돈을 모음 → 케이크를 숨김 → 선생님이 들어오심 → 노래를 부름. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(A)-(C)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. 깜짝 파티를 계획했다는 말 바로 뒤에 케이크를 숨기고 기다리는 준비 이야기가 이어질 것 같거든요. 하지만 (A)의 'the cake'(그 케이크)는 이미 정해진 케이크예요. 주어진 글에는 케이크가 나오지 않아요. 케이크는 (B)의 끝에서 반장이 산 것이므로 (B)가 (A) 앞에 와야 해요.",
   ["(A)의 'the cake'(그 케이크)가 가리킬 케이크가 주어진 글에 없어요. 케이크는 (B)의 끝에서 처음 사요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(A)의 'the cake'(그 케이크)는 (B)의 끝에서 산 케이크예요. (C)의 'At that moment'(바로 그때)는 (A)의 끝에서 모두가 선생님을 기다리던 때예요. 돈, 케이크, 선생님의 도착 순서가 맞아요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (C)의 'At that moment'(바로 그때)가 가리킬 때가 (B)에는 없어요. (B)는 케이크를 샀다는 말로 끝나요. 선생님이 문가에 서 계신 바로 그때는 (A)의 끝에서 모두가 기다리던 때예요.",
 "(C)의 'At that moment'(바로 그때)가 가리킬 때가 주어진 글에 없어요. 노래까지 부른 뒤에 케이크를 숨기는 것도 차례가 거꾸로예요.",
 "(C)의 'At that moment'(바로 그때)가 가리킬 때가 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 노래까지 부른 뒤에 돈을 모으고 케이크를 사는 것도 거꾸로예요."],
   'surprise 깜짝 놀랄 일 / surprised 놀란 / leader 반장, 우두머리')

# 9번째 (정답 순서 CBA)
rw(8, 'Sora started at a new middle school in the spring.',
   {'A': ['That shared hobby soon made the two girls good friends.', 'Now Sora walks into the school with a big smile every morning.'],
 'B': ['The girl asked Sora about her old school and her hobbies.', 'Both of them loved drawing cartoons in their free time.'],
 'C': ['Everything in the big building looked new and strange to her.', 'At lunch, a girl with short hair sat beside her.']},
   '소라는 봄에 새 중학교에 다니기 시작했다.',
   {'A': ['그 공통된 취미는 곧 두 소녀를 좋은 친구로 만들었다.', '이제 소라는 아침마다 환하게 웃으며 학교로 걸어 들어간다.'],
 'B': ['그 소녀는 소라에게 예전 학교와 취미에 대해 물었다.', '두 사람 모두 여가 시간에 만화 그리기를 아주 좋아했다.'],
 'C': ['큰 건물 안의 모든 것이 그녀에게는 새롭고 낯설어 보였다.', '점심시간에 머리가 짧은 한 소녀가 그녀 옆에 앉았다.']},
   ['1) 주어진 글: 소라가 봄에 새 중학교에 다니기 시작했다고 해요. 이어서 새 학교에서 소라에게 어떤 일이 있었는지가 나올 거예요.',
 "2) 첫째 글 (C): «Everything in the big building looked new and strange to her.»(큰 건물 안의 모든 것이 그녀에게는 새롭고 낯설어 보였다.) 'her'(그녀)는 새 학교에 온 소라예요. 새 학교에 막 온 때의 느낌이니 이야기의 처음으로 알맞아요. (C)는 점심시간에 머리가 짧은 소녀가 옆에 "
 '앉았다는 말로 끝나요.',
 "3) 둘째 글 (B): «The girl asked Sora about her old school and her hobbies.»(그 소녀는 소라에게 예전 학교와 취미에 대해 물었다.) 'The girl'(그 소녀)은 (C)의 끝에 'a girl with short hair'(머리가 짧은 소녀)로 처음 나온 아이예요. (B)는 두 사람 모두 만화 "
 '그리기를 아주 좋아했다는 말로 끝나요.',
 "4) 셋째 글 (A)와 확인: «That shared hobby soon made the two girls good friends.»(그 공통된 취미는 곧 두 소녀를 좋은 친구로 만들었다.) 'That shared hobby'(그 공통된 취미)는 (B)의 끝에서 두 사람이 모두 좋아한 만화 그리기예요. 낯선 학교 → 소녀가 옆에 앉음 → 취미 "
 '이야기를 함 → 친구가 됨 → 지금은 웃으며 등교함. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(B)-(A)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)에 'Sora'와 'old school'(예전 학교)이 나와서 새 학교에 갔다는 말 바로 뒤에 이어질 것 같거든요. 하지만 (B)는 'The girl'(그 소녀)로 시작해요. 주어진 글에는 소라 말고 다른 소녀가 나오지 않아요. 그 소녀는 (C)의 끝에 'a girl'(한 소녀)로 처음 나와요. 보통 처음 말할 때는 'a'를 쓰고, 이미 말한 것을 다시 가리킬 때 'the'를 쓴다는 점을 기억해요.",
   ["(A)의 'That shared hobby'(그 공통된 취미)가 가리킬 취미가 주어진 글에 없어요. 공통된 취미(만화 그리기)는 (B)의 끝에서 처음 밝혀져요. 또 '이제는 웃으며 등교한다'는 (A)가 맨 앞에 오면 이야기의 끝이 맨 앞에 와요.",
 "(B)의 'The girl'(그 소녀)이 가리킬 소녀가 주어진 글에 없어요. 소녀는 (C)의 끝에 처음 나와요. 그래서 (B)는 맨 앞에 올 수 없어요.",
 "(B)의 'The girl'(그 소녀)이 가리킬 소녀가 앞에 없어요. (B)에 'Sora'가 나와도 그 소녀가 누구인지는 (C)를 읽어야 알 수 있어요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (A)가 오면 'That shared hobby'(그 공통된 취미)가 가리킬 취미가 없어요. (C)에는 취미 이야기가 없어요.",
 "(C)의 끝에 나온 'a girl'(한 소녀)을 (B)가 'The girl'(그 소녀)로 받아요. (B)의 끝에 나온 만화 그리기를 (A)가 'That shared hobby'(그 공통된 취미)로 받아요. 세 군데가 다 맞물려요."],
   'strange 낯선 / hobby 취미 / cartoon 만화')

# 10번째 (정답 순서 BCA)
rw(9, 'Camels can walk across the hot desert for many days.',
   {'A': ['With these two helpers, a camel can cross the hot desert safely.', 'People often call the camel the ship of the desert.'],
 'B': ["The hump on a camel's back holds fat, not water.", 'This fat is the first helper on long walks without food.'],
 'C': ['However, a thirsty camel needs a second helper besides fat.', 'A camel can drink a huge amount of water within minutes.']},
   '낙타는 뜨거운 사막을 며칠씩 걸어서 건널 수 있다.',
   {'A': ['이 두 도우미 덕분에 낙타는 뜨거운 사막을 안전하게 건널 수 있다.', '사람들은 흔히 낙타를 사막의 배라고 부른다.'],
 'B': ['낙타 등의 혹에는 물이 아니라 지방이 들어 있다.', '이 지방은 먹이 없이 오래 걷는 길에서 첫 번째 도우미이다.'],
 'C': ['하지만 목마른 낙타에게는 지방 말고 두 번째 도우미가 필요하다.', '낙타는 몇 분 안에 엄청난 양의 물을 마실 수 있다.']},
   ['1) 주어진 글: 낙타가 뜨거운 사막을 며칠씩 걸어서 건널 수 있다고 해요. 이어서 낙타가 어떻게 그럴 수 있는지가 나올 거예요.',
 "2) 첫째 글 (B): «The hump on a camel's back holds fat, not water.»(낙타 등의 혹에는 물이 아니라 지방이 들어 있다.) 낙타가 오래 걸을 수 있는 까닭을 설명하기 시작해요. 'fat'(지방)이 처음 나오는 글이기도 해요. (B)는 «This fat is the first helper on long "
 'walks without food.»(이 지방은 먹이 없이 오래 걷는 길에서 첫 번째 도우미이다.)로 끝나요.',
 "3) 둘째 글 (C): «However, a thirsty camel needs a second helper besides fat.»(하지만 목마른 낙타에게는 지방 말고 두 번째 도우미가 필요하다.) 'a second helper'(두 번째 도우미)는 'the first helper'(첫 번째 도우미)가 먼저 나와야 쓸 수 있는 말이에요. "
 "'fat'(지방)도 (B)에서 나왔어요. (C)는 낙타가 몇 분 안에 엄청난 양의 물을 마실 수 있다는 말로 끝나요.",
 "4) 셋째 글 (A)와 확인: «With these two helpers, a camel can cross the hot desert safely.»(이 두 도우미 덕분에 낙타는 뜨거운 사막을 안전하게 건널 수 있다.) 'these two helpers'(이 두 도우미)는 (B)의 첫 번째 도우미(지방)와 (C)의 두 번째 도우미(물)를 합쳐 부른 "
 '말이에요. 둘을 다 읽은 뒤에야 쓸 수 있어요. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(C)-(A)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)에 주어진 글과 같은 'hot desert'(뜨거운 사막)이 있고, 낙타가 사막을 건넌다는 내용이 바로 이어질 것 같거든요. 하지만 (A)는 'these two helpers'(이 두 도우미)로 시작해요. 주어진 글에는 도우미가 나오지 않아요. 도우미는 (B)와 (C)에 하나씩 나오니, 둘을 다 읽은 뒤에야 'these two helpers'라고 할 수 있어요.",
   ["(A)의 'these two helpers'(이 두 도우미)가 가리킬 도우미가 주어진 글에 없어요. 두 도우미는 (B)와 (C)에서 하나씩 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (B) 뒤에는 도우미가 하나밖에 나오지 않았어요. 'these two helpers'(이 두 도우미)는 둘을 다 읽은 뒤에 쓸 수 있는 말이므로 (A)는 (B) 바로 뒤에 올 수 없어요.",
 "(B)에서 첫 번째 도우미(지방)가 나와요. (C)에서 두 번째 도우미(물)가 나와요. 그 둘을 (A)가 'these two helpers'(이 두 도우미)로 받아요.",
 "(C)의 'a second helper'(두 번째 도우미)는 첫 번째 도우미가 먼저 나와야 쓸 수 있어요. 첫 번째 도우미와 'fat'(지방)은 (B)에서 처음 나오므로 (C) 앞에는 (B)가 있어야 해요.",
 "(C)의 'a second helper'(두 번째 도우미)는 첫 번째 도우미가 먼저 나와야 쓸 수 있어요. 첫 번째 도우미를 소개하는 (B)가 (C) 뒤에 오는 것은 차례가 거꾸로예요."],
   'hump (낙타의) 혹 / fat 지방 / thirsty 목마른')

# 11번째 (정답 순서 CBA)
rw(10, 'Last winter, Minjae joined the running club at his middle school.',
   {'A': ['After all that work, Minjae ran ten laps around the track in April.', 'Ms. Park then put his name on the list for the city race.'],
 'B': ['Minjae followed that plan three times a week for two months.', 'Slowly, the laps became easier for him week after week.'],
 'C': ['At first, he could not run even one lap of the track.', 'His coach, Ms. Park, gave him a short training plan.']},
   '지난겨울 민재는 자기 중학교의 달리기 동아리에 들어갔다.',
   {'A': ['그 모든 노력 끝에 민재는 사월에 트랙을 열 바퀴 달렸다.', '그러자 박 선생님이 그의 이름을 시 대회 명단에 올렸다.'],
 'B': ['민재는 두 달 동안 일주일에 세 번 그 계획을 따랐다.', '주를 거듭할수록 트랙을 도는 일이 그에게 서서히 쉬워졌다.'],
 'C': ['처음에 그는 트랙을 한 바퀴조차 달릴 수 없었다.', '그의 코치인 박 선생님은 그에게 짧은 훈련 계획을 주었다.']},
   ['1) 주어진 글: 지난겨울 민재가 중학교 달리기 동아리에 들어갔다고 해요. 이어서 동아리에서 민재가 달리기를 어떻게 해 나갔는지가 나올 거예요.',
 "2) 첫째 글 (C): «At first, he could not run even one lap of the track.»(처음에 그는 트랙을 한 바퀴조차 달릴 수 없었다.) 'At first'(처음에)는 동아리에 막 들어간 때를 말해요. 한 바퀴도 못 달리던 때가 이야기의 시작으로 알맞아요. (C)는 코치 박 선생님이 짧은 훈련 계획을 주었다는 "
 '말로 끝나요.',
 "3) 둘째 글 (B): «Minjae followed that plan three times a week for two months.»(민재는 두 달 동안 일주일에 세 번 그 계획을 따랐다.) 'that plan'(그 계획)은 (C)의 끝에 나온 'a short training plan'(짧은 훈련 계획)이에요. (B)는 트랙을 도는 일이 서서히 "
 '쉬워졌다는 말로 끝나요.',
 "4) 셋째 글 (A)와 확인: «After all that work, Minjae ran ten laps around the track in April.»(그 모든 노력 끝에 민재는 사월에 트랙을 열 바퀴 달렸다.) 'all that work'(그 모든 노력)은 (B)에서 두 달 동안 계획을 따른 일이에요. 'Ms. Park'도 (C)에서 코치로 "
 '먼저 소개되었어요. 한 바퀴도 못 달림 → 계획을 받음 → 두 달 동안 따름 → 열 바퀴를 달림. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(B)-(A)예요.'],
   "(B)나 (A)를 맨 앞에 놓고 싶어질 수 있어요. 둘 다 민재가 달리는 이야기라서 달리기 동아리에 들어간 일 바로 뒤에 이어질 것 같거든요. 하지만 (B)는 'that plan'(그 계획)으로, (A)는 'all that work'(그 모든 노력)으로 이어져요. 주어진 글에는 계획도 노력도 나오지 않아요. 계획은 (C)의 끝에 처음 나오니 (C)가 맨 앞에 와야 해요.",
   ["(A)의 'all that work'(그 모든 노력)이 가리킬 노력이 주어진 글에 없어요. 또 열 바퀴를 달린 뒤에 '처음에는 한 바퀴도 못 달렸다'는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(B)의 'that plan'(그 계획)이 가리킬 계획이 주어진 글에 없어요. 열 바퀴를 달린 뒤에 '처음에는 한 바퀴도 못 달렸다'며 계획을 받는 (C)가 오는 것도 차례가 거꾸로예요.",
 "(B)의 'that plan'(그 계획)이 가리킬 계획이 앞에 없어요. 계획은 (C)의 끝에 처음 나와요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (A)가 오면 'all that work'(그 모든 노력)이 가리킬 노력이 없어요. (C)에는 계획을 받았다는 말만 있고, 계획을 따른 이야기는 (B)에 있어요.",
 "(C)의 끝에 나온 'a short training plan'(짧은 훈련 계획)을 (B)가 'that plan'(그 계획)으로 받아요. (B)에서 두 달 동안 한 일을 (A)가 'all that work'(그 모든 노력)으로 받아요. 세 군데가 다 맞물려요."],
   'lap (트랙) 한 바퀴 / track 트랙 / coach 코치')

# 12번째 (정답 순서 BCA)
rw(11, 'Hangeul is the great writing system of all Korean people.',
   {'A': ['He announced the new letters to the whole country in 1446.', 'Since then, many people have learned Hangeul quickly and easily.'],
 'B': ['Long ago, ordinary people had no easy letters for their language.', 'Most of them could not read or write the hard Chinese characters.'],
 'C': ['King Sejong felt very sorry for those ordinary people and their problem.', 'In 1443, he made easy new letters for them to use.']},
   '한글은 모든 한국 사람의 위대한 글자 체계이다.',
   {'A': ['그는 1446년에 새 글자를 온 나라에 알렸다.', '그때부터 많은 사람이 한글을 빠르고 쉽게 배워 왔다.'],
 'B': ['옛날에 보통 사람들은 자기 말을 적을 쉬운 글자가 없었다.', '그들 대부분은 어려운 한자를 읽거나 쓸 수 없었다.'],
 'C': ['세종대왕은 그 보통 사람들과 그들의 문제를 몹시 안타깝게 여겼다.', '1443년에 그는 그들이 쓸 수 있는 쉬운 새 글자를 만들었다.']},
   ['1) 주어진 글: 한글이 모든 한국 사람의 위대한 글자 체계라고 해요. 이어서 한글이 어떻게 생겼는지가 나올 거예요.',
 "2) 첫째 글 (B): «Long ago, ordinary people had no easy letters for their language.»(옛날에 보통 사람들은 자기 말을 적을 쉬운 글자가 없었다.) 'Long ago'(옛날에)는 한글이 생기기 전의 사정을 말해요. 'ordinary people'(보통 사람들)이 처음 나오는 글이기도 해요. "
 '(B)는 그들 대부분이 어려운 한자를 읽거나 쓸 수 없었다는 말로 끝나요.',
 "3) 둘째 글 (C): «King Sejong felt very sorry for those ordinary people and their problem.»(세종대왕은 그 보통 사람들과 그들의 문제를 몹시 안타깝게 여겼다.) 'those ordinary people'(그 보통 사람들)은 (B)에 나온 사람들이에요. 'their problem'(그들의 "
 '문제)은 (B)의 끝에서 말한, 한자를 읽거나 쓰지 못하는 어려움이에요. (C)는 1443년에 쉬운 새 글자를 만들었다는 말로 끝나요.',
 "4) 셋째 글 (A)와 확인: «He announced the new letters to the whole country in 1446.»(그는 1446년에 새 글자를 온 나라에 알렸다.) 'He'(그)는 (C)의 세종대왕이고 'the new letters'(그 새 글자)는 (C)의 끝에서 만든 글자예요. 1443년에 만들고 1446년에 알린 차례도 "
 '맞아요. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (B)-(C)-(A)예요.'],
   "(C)를 맨 앞에 놓고 싶어질 수 있어요. 한글 이야기에는 세종대왕이 바로 나오는 것이 자연스러워 보이거든요. 하지만 (C)는 'those ordinary people and their problem'(그 보통 사람들과 그들의 문제)으로 이어져요. 주어진 글에는 보통 사람들도 그들의 문제도 나오지 않아요. 둘 다 (B)에서 처음 나오니 (B)가 (C) 앞에 와야 해요. (A)도 'He'(그)와 'the new letters'(그 새 글자)로 시작하는데, 세종대왕도 새 글자도 주어진 글에 없으니 맨 앞에 올 수 없어요.",
   ["(A)의 'He'(그)가 가리킬 사람이 주어진 글에 없어요. 또 1446년의 일인 (A)가 1443년의 일인 (C)보다 앞에 오는 것도 차례가 거꾸로예요.",
 "(B)로 시작하는 것은 맞아요. 하지만 (A)의 'He'(그)가 가리킬 사람이 (B)에는 없어요. 세종대왕은 (C)에 처음 나와요. 또 1446년 뒤에 1443년이 오는 것도 거꾸로예요.",
 "(B)의 'ordinary people'(보통 사람들)을 (C)가 'those ordinary people'(그 보통 사람들)로 받아요. (C)의 세종대왕과 그가 만든 새 글자를 (A)가 'He'(그)와 'the new letters'(그 새 글자)로 받아요.",
 "(C)의 'those ordinary people'(그 보통 사람들)이 가리킬 사람들이 주어진 글에 없어요. 'ordinary people'(보통 사람들)은 (B)에 처음 나와요.",
 "(C)의 'those ordinary people'(그 보통 사람들)이 가리킬 사람들이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. 새 글자를 만든 일을 말한 뒤에 그 글자가 없던 시절 이야기를 하는 것도 차례가 거꾸로예요."],
   'ordinary 보통의 / letter 글자 / announce 알리다, 발표하다')

# 13번째 (정답 순서 ACB)
rw(12, 'Bomi borrowed a mystery book from the town library last week.',
   {'A': ['She read the whole story in just two nights at home.', 'On the last page, she found an old photo of a little girl.'],
 'B': ['Many years ago, the librarian herself was that little girl.', 'She thanked Bomi warmly for finding her old photo at last.'],
 'C': ['She took the photo to the library the next morning.', 'The librarian looked at the little girl in the photo very carefully.']},
   '보미는 지난주에 동네 도서관에서 추리 소설책을 한 권 빌렸다.',
   {'A': ['그녀는 집에서 단 이틀 밤 만에 이야기 전체를 읽었다.', '마지막 쪽에서 그녀는 어린 소녀의 오래된 사진을 한 장 발견했다.'],
 'B': ['여러 해 전에 사서 본인이 그 어린 소녀였다.', '그녀는 자신의 오래된 사진을 마침내 찾아 준 보미에게 따뜻하게 고마워했다.'],
 'C': ['그녀는 다음 날 아침 그 사진을 도서관에 가져갔다.', '사서는 사진 속 어린 소녀를 아주 자세히 보았다.']},
   ['1) 주어진 글: 보미가 지난주에 동네 도서관에서 추리 소설책을 빌렸다고 해요. 이어서 보미가 그 책을 읽으며 겪은 일이 나올 거예요.',
 "2) 첫째 글 (A): «She read the whole story in just two nights at home.»(그녀는 집에서 단 이틀 밤 만에 이야기 전체를 읽었다.) 'She'(그녀)는 주어진 글의 보미예요. 'the whole story'(그 이야기 전체)는 빌린 추리 소설이에요. 책을 빌린 뒤에 집에서 읽는 것이 자연스러워요. "
 '(A)는 마지막 쪽에서 어린 소녀의 오래된 사진을 발견했다는 말로 끝나요.',
 "3) 둘째 글 (C): «She took the photo to the library the next morning.»(그녀는 다음 날 아침 그 사진을 도서관에 가져갔다.) 'the photo'(그 사진)는 (A)의 끝에서 발견한 사진이에요. 'the next morning'(다음 날 아침)도 사진을 발견한 날의 다음 날이에요. (C)는 사서가 사진 "
 '속 어린 소녀를 아주 자세히 보았다는 말로 끝나요.',
 "4) 셋째 글 (B)와 확인: «Many years ago, the librarian herself was that little girl.»(여러 해 전에 사서 본인이 그 어린 소녀였다.) 'the librarian'(그 사서)은 (C)의 끝에 나온 사서이고, 'that little girl'(그 어린 소녀)은 사서가 자세히 본 사진 속 소녀예요. "
 '책을 읽음 → 사진을 발견함 → 도서관에 가져감 → 사서가 그 소녀였음이 밝혀짐. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (A)-(C)-(B)예요.'],
   "(B)를 맨 앞에 놓고 싶어질 수 있어요. (B)에 'Bomi'가 나오고, 'librarian'(사서)이 주어진 글의 'library'(도서관)와 어울리거든요. 하지만 (B)는 'that little girl'(그 어린 소녀)과 'her old photo'(자신의 오래된 사진)로 이어져요. 주어진 글에는 소녀도 사진도 나오지 않아요. 소녀와 사진은 모두 (A)의 끝에 처음 나와요.",
   ["(A)의 'She'(그녀)는 주어진 글의 보미예요. (C)의 'the photo'(그 사진)와 'the next morning'(다음 날 아침)은 (A)의 끝에서 사진을 발견한 일을 받아요. (B)의 'the librarian'(그 사서)과 'that little girl'(그 어린 소녀)은 (C)의 끝에 나온 사서와 사진 속 소녀예요.",
 "(B)의 'that little girl'(그 어린 소녀)이 가리킬 소녀가 주어진 글에 없어요. 소녀는 (A)의 끝에 처음 나와요.",
 "(B)의 'that little girl'(그 어린 소녀)이 가리킬 소녀가 앞에 없어요. 주어진 글의 'library'(도서관)와 어울려서 끌리지만, 소녀는 (A)의 끝에 처음 나와요. 사서가 그 소녀였다는 말은 사진이 나온 뒤에야 이어져요.",
 "(C)의 'the photo'(그 사진)가 가리킬 사진이 주어진 글에 없어요. 사진은 (A)의 끝에 처음 나와요.",
 "(C)의 'the photo'(그 사진)가 가리킬 사진이 앞에 없어서 (C)는 맨 앞에 올 수 없어요. (A)에서 사진을 발견하기도 전에 (B)에서 사서가 보미가 사진을 찾아 준 것을 고마워하니 차례가 거꾸로예요."],
   'mystery 추리물, 수수께끼 / librarian 사서 / photo 사진')

# 14번째 (정답 순서 CAB)
rw(13, 'A compass helps hikers find their way in a large forest.',
   {'A': ['The Earth is also a giant magnet with its own two ends.', 'One end of the needle is pulled toward the north.'],
 'B': ['Hikers can then use that direction to read their map.', 'In this way, a small tool keeps hikers safe in the forest.'],
 'C': ['Inside it, a thin metal needle turns freely on a tiny point.', 'That thin needle is really a small magnet with two ends.']},
   '나침반은 등산객이 큰 숲에서 길을 찾도록 돕는다.',
   {'A': ['지구도 두 끝을 가진 거대한 자석이다.', '바늘의 한쪽 끝은 북쪽으로 끌린다.'],
 'B': ['그러면 등산객은 그 방향을 이용해 지도를 볼 수 있다.', '이렇게 해서 작은 도구가 등산객을 숲에서 안전하게 지켜 준다.'],
 'C': ['그 안에서 얇은 금속 바늘이 아주 작은 받침점 위에서 자유롭게 돈다.', '그 얇은 바늘은 사실 두 끝을 가진 작은 자석이다.']},
   ['1) 주어진 글: 나침반이 등산객이 큰 숲에서 길을 찾도록 돕는다고 해요. 이어서 나침반이 어떻게 길을 알려 주는지가 나올 거예요.',
 "2) 첫째 글 (C): «Inside it, a thin metal needle turns freely on a tiny point.»(그 안에서 얇은 금속 바늘이 아주 작은 받침점 위에서 자유롭게 돈다.) 'it'(그것)은 주어진 글의 나침반이에요. 나침반 안의 바늘을 처음 소개하는 글이에요. (C)는 그 바늘이 두 끝을 가진 작은 자석이라는 말로 "
 '끝나요.',
 "3) 둘째 글 (A): «The Earth is also a giant magnet with its own two ends.»(지구도 두 끝을 가진 거대한 자석이다.) 'also'(~도)는 앞에 나온 것에 하나를 더할 때 써요. 지구'도' 자석이려면 앞에 다른 자석이 나와 있어야 해요. (C)의 끝에 나온 작은 자석이 그것이에요. 'two "
 "ends'(두 끝)도 (C)에서 이어져요. (A)는 바늘의 한쪽 끝이 북쪽으로 끌린다는 말로 끝나요.",
 "4) 셋째 글 (B)와 확인: «Hikers can then use that direction to read their map.»(그러면 등산객은 그 방향을 이용해 지도를 볼 수 있다.) 'that direction'(그 방향)은 (A)의 끝에 나온 북쪽이에요. 마지막 문장의 'In this way'(이렇게 해서)는 앞의 설명 전체를 정리하는 "
 '말이에요. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(A)-(B)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. 나침반과 지구의 자석이 관련 있다는 것을 알면 지구 이야기가 바로 나올 것 같거든요. 하지만 (A)의 'also'(~도)는 앞에 나온 자석에 하나를 더하는 말인데, 주어진 글에는 자석이 나오지 않아요. 바늘 이야기도 주어진 글에 없어요. 자석과 바늘은 (C)에 먼저 나와요. 또 (B)의 첫 문장에는 'that direction'(그 방향)이 들어 있는데 방향은 (A)의 끝에 처음 나오니 (B)도 맨 앞에 올 수 없어요.",
   ["(A)의 'also'(~도)는 앞에 나온 자석에 하나를 더하는 말인데 주어진 글에는 자석이 없어요. 바늘 이야기도 주어진 글에 없고, 자석과 바늘은 (C)에 먼저 나와요.",
 "(B)의 'that direction'(그 방향)이 가리킬 방향이 주어진 글에 없어요. 또 (B)는 마지막 문장이 'In this way'(이렇게 해서)로 설명을 마무리해서 맨 앞에 올 수 없어요.",
 "(B)의 'that direction'(그 방향)이 가리킬 방향이 앞에 없어요. 방향은 (A)의 끝에 나오는 북쪽이에요.",
 "(C)의 'it'(그것)이 나침반을 받아요. (C)의 끝에 나온 작은 자석에 (A)의 'also'(~도)가 이어져요. (A)의 끝에 나온 북쪽을 (B)가 'that direction'(그 방향)으로 받아요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (B)가 오면 'that direction'(그 방향)이 가리킬 방향이 없어요. 북쪽은 (A)의 끝에 나와요."],
   'compass 나침반 / needle 바늘 / magnet 자석')

# 15번째 (정답 순서 CAB)
rw(14, "Last summer, a strong storm hit Hajin's small village by the sea.",
   {'A': ['Soon, students from a nearby town came to help them with that work.', 'They worked beside the tired villagers for three long weekends.'],
 'B': ['After those weekends, the harbor looked clean and full of boats again.', 'The villagers thanked the students with a big party at the harbor.'],
 'C': ['The strong waves damaged twenty boats near the harbor wall.', 'The villagers needed help with the repair and cleaning work right away.']},
   '지난여름 강한 폭풍이 바닷가에 있는 하진이네 작은 마을을 덮쳤다.',
   {'A': ['곧 이웃 마을의 학생들이 그 일을 돕기 위해 그들에게 왔다.', '그들은 지친 마을 사람들 곁에서 세 번의 긴 주말 동안 일했다.'],
 'B': ['그 주말들이 지난 뒤 항구는 다시 깨끗해지고 배로 가득해 보였다.', '마을 사람들은 항구에서 열린 큰 잔치로 학생들에게 고마워했다.'],
 'C': ['강한 파도가 항구 방파제 근처의 배 스무 척을 망가뜨렸다.', '마을 사람들은 수리와 청소 일에 곧바로 도움이 필요했다.']},
   ['1) 주어진 글: 지난여름 강한 폭풍이 바닷가에 있는 하진이네 작은 마을을 덮쳤다고 해요. 이어서 폭풍 뒤에 무슨 일이 있었는지가 나올 거예요.',
 '2) 첫째 글 (C): «The strong waves damaged twenty boats near the harbor wall.»(강한 파도가 항구 방파제 근처의 배 스무 척을 망가뜨렸다.) 폭풍이 마을에 준 피해를 말해요. 폭풍 이야기 바로 뒤에 피해를 알려 주는 것이 자연스러워요. (C)는 마을 사람들이 수리와 청소 일에 곧바로 도움이 '
 '필요했다는 말로 끝나요.',
 "3) 둘째 글 (A): «Soon, students from a nearby town came to help them with that work.»(곧 이웃 마을의 학생들이 그 일을 돕기 위해 그들에게 왔다.) 'that work'(그 일)은 (C)의 끝에 나온 수리와 청소 일이에요. 'them'(그들)은 마을 사람들이에요. (A)는 학생들이 긴 "
 '주말을 세 번 일했다는 말로 끝나요.',
 "4) 셋째 글 (B)와 확인: «After those weekends, the harbor looked clean and full of boats again.»(그 주말들이 지난 뒤 항구는 다시 깨끗해지고 배로 가득해 보였다.) 'those weekends'(그 주말들)는 (A)의 끝에 나온 세 번의 긴 주말이에요. 폭풍이 덮침 → 피해를 입음 → "
 '학생들이 도우러 옴 → 항구가 다시 깨끗해짐. 앞 글의 끝과 뒤 글의 처음이 다 맞물리므로 순서는 (C)-(A)-(B)예요.'],
   "(A)를 맨 앞에 놓고 싶어질 수 있어요. (A)에 'Soon'(곧)이 있어서 폭풍이 온 직후의 이야기로 이어질 것 같거든요. 하지만 (A)는 'that work'(그 일)로 이어지는데, 주어진 글에는 일이 나오지 않아요. 그 일은 (C)의 끝에 나온 수리와 청소 일이에요. (B)도 첫머리에 'those weekends'(그 주말들)가 나오니 맨 앞에 올 수 없어요.",
   ["(A)의 'that work'(그 일)이 가리킬 일이 주어진 글에 없어요. 일은 (C)의 끝에 처음 나와요. 그래서 (A)는 맨 앞에 올 수 없어요.",
 "(B)의 'those weekends'(그 주말들)가 가리킬 주말이 주어진 글에 없어요. 항구가 깨끗해진 뒤에 도움이 오는 (A)가 이어지는 것도 차례가 거꾸로예요.",
 "(B)의 'those weekends'(그 주말들)가 가리킬 주말이 앞에 없어요. 주말은 (A)의 끝에 처음 나와요.",
 "(C)의 일을 (A)가 'that work'(그 일)로 받아요. (A)의 끝에 나온 세 번의 주말을 (B)가 'those weekends'(그 주말들)로 받아요.",
 "(C)로 시작하는 것은 맞아요. 하지만 (C) 뒤에 (B)가 오면 'those weekends'(그 주말들)가 가리킬 주말이 없어요. 주말은 (A)의 끝에 나와요."],
   'harbor 항구 / villager 마을 사람 / repair 수리(하다)')
