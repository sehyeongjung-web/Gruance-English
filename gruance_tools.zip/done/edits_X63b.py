# -*- coding: utf-8 -*-
# 337번: 21번(함축 의미) 레벨1 뒤 절반 — 다섯 문장 · 문장당 10~15낱말 · 단문 · 밑줄은 둘째~다섯째 문장. 정답 번호는 바탕 그대로, 지문·선택지·해석·풀이·해설을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z21common import maker
rw = maker(E, '1')

# 16번째 (정답 ②)
rw(15, 'Every night, someone fixes one more board of the old fence. Mr. Park has never once seen the helper at work. Each morning, one more board looks strong and fresh to him. To him, the work on the fence is <u>a gift with no card</u>. He still does not know the name of his helper.',
   ['a present he forgot to open', 'a kindness from someone unknown', 'a favor he must repay soon', 'a fence that costs far too much money', 'a card that his whole family sent'],
   '밤마다 누군가가 낡은 울타리의 널빤지를 하나씩 더 고쳐 놓는다. 박 씨는 그 도와주는 사람이 일하는 모습을 한 번도 본 적이 없다. 아침마다 그의 눈에는 널빤지 하나가 더 튼튼하고 새것처럼 보인다. 그에게 울타리를 고치는 그 일은 「카드가 없는 선물」이다. 그는 아직도 자신을 도와주는 사람의 이름을 모른다.',
   ["1) 밑줄 친 'a gift with no card'(카드가 없는 선물)는 진짜 선물이 아니라 비유예요. «the work on the fence»(울타리를 고치는 그 일)를 가리켜요.",
 '2) 단서를 찾아요. «Mr. Park has never once seen the helper at work.»(박 씨는 그 도와주는 사람이 일하는 모습을 한 번도 본 적이 없다.) 마지막 문장은 «He still does not know the name of his helper.»(그는 아직도 자신을 도와주는 사람의 이름을 모른다.)라고 해요.',
 '3) 선물에는 보통 보낸 사람의 이름이 적힌 카드가 붙어 있어요. 이 선물은 카드가 없어서 누가 줬는지 몰라요. 누가 고쳤는지 모르는 도움도 이와 닮았어요.',
 "4) 그러니까 밑줄 친 'a gift with no card'의 뜻은 'a kindness from someone unknown'(누군지 모르는 사람이 베푼 친절)이에요."],
   "'a present he forgot to open'(열어 보는 것을 잊은 선물)이 끌릴 수 있어요. 밑줄 친 말의 'gift'(선물)를 글자 그대로 읽은 보기라서요. 하지만 글에는 진짜 선물이 나오지 않아요. 고쳐진 울타리가 선물 같다는 비유예요. 'a favor he must repay soon'(곧 갚아야 하는 호의)도 선물에서 떠올릴 수 있지만, 글은 박 씨가 도와주는 사람의 이름조차 모른다고 해요. 갚아야 한다는 말은 글에 없어요.",
   ['선물을 열어 보지 않았다는 말은 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '누군가 밤마다 널빤지를 고치지만 박 씨는 그 사람이 일하는 모습을 한 번도 보지 못했고 이름도 몰라요. 카드가 없는 선물처럼 누가 줬는지 모르는 친절이에요.',
 '갚아야 한다는 말은 글에 없어요. 박 씨는 도와주는 사람이 누구인지도 몰라요.',
 '울타리에 돈이 얼마나 들었는지는 글에 나오지 않아요. 밑줄 친 말은 울타리 값이 아니라 그 일을 말해요.',
 "카드를 보낸 가족은 글에 나오지 않아요. 밑줄 친 말의 'card'(카드)만 따온 보기예요."],
   ['열어 보는 것을 잊은 선물', '누군지 모르는 사람이 베푼 친절', '곧 갚아야 하는 호의', '돈이 너무 많이 드는 울타리', '그의 온 가족이 보낸 카드'],
   'fence 울타리 / board 널빤지 / helper 도와주는 사람 / card 카드')

# 17번째 (정답 ①)
rw(16, "Joon keeps his grandmother's old letters in a small box. On every lonely evening, Joon reads one letter from the box. After just a few lines, his sad face turns bright again. For Joon, those letters are <u>a pocket full of sunshine</u>. Even one short letter can make his whole evening better.",
   ['something that lifts his mood', 'a box full of old coins', 'a secret he must hide from others', 'a warm place to sit in the garden', 'a present for the next sunny day'],
   '준은 할머니의 낡은 편지들을 작은 상자에 보관한다. 쓸쓸한 저녁마다 준은 상자에서 편지를 한 통씩 읽는다. 몇 줄만 읽어도 그의 슬픈 얼굴은 다시 환해진다. 준에게 그 편지들은 「햇빛이 가득 든 주머니」이다. 짧은 편지 한 통만으로도 그의 저녁 전체가 더 좋아질 수 있다.',
   ["1) 밑줄 친 'a pocket full of sunshine'(햇빛이 가득 든 주머니)은 진짜 주머니가 아니라 비유예요. «those letters»(그 편지들)를 가리켜요.",
 '2) 단서를 찾아요. «After just a few lines, his sad face turns bright again.»(몇 줄만 읽어도 그의 슬픈 얼굴은 다시 환해진다.) 마지막 문장도 «Even one short letter can make his whole evening better.»(짧은 편지 한 통만으로도 그의 저녁 전체가 더 좋아질 '
 '수 있다.)라고 해요.',
 '3) 햇빛은 따뜻하고 밝은 느낌을 줘요. 주머니에 넣어 다니는 햇빛이니, 마음이 어두울 때 꺼내 기분을 밝게 해 주는 것이에요. 편지가 준에게 그런 일을 해요.',
 "4) 그러니까 밑줄 친 'a pocket full of sunshine'의 뜻은 'something that lifts his mood'(그의 기분을 끌어올려 주는 것)이에요."],
   "'a warm place to sit in the garden'(정원에서 앉을 수 있는 따뜻한 곳)이 끌릴 수 있어요. 'sunshine'(햇빛)에서 따뜻한 햇볕 드는 자리를 떠올리기 쉬워서요. 하지만 글에서 준은 상자 속 편지를 읽을 뿐이에요. 정원 이야기는 없어요. 'a box full of old coins'(낡은 동전이 가득한 상자)도 'box'(상자)와 'old'(낡은)만 따온 보기예요. 상자 안에는 동전이 아니라 편지가 들어 있어요.",
   ['편지를 읽으면 슬픈 얼굴이 다시 환해지고 저녁 전체가 더 좋아져요. 햇빛이 기분을 밝게 하듯이 편지가 준의 기분을 끌어올려 줘요.',
 "상자에 든 것은 동전이 아니라 할머니의 편지예요. 'box'(상자)와 'old'(낡은)만 따온 보기예요.",
 '편지를 숨겨야 한다는 말은 글에 없어요.',
 '정원은 글에 나오지 않아요. 준은 상자에서 편지를 꺼내 읽을 뿐이에요.',
 "선물 이야기는 글에 없어요. 밑줄 친 말의 'sunshine'(햇빛)에서 떠올린 보기예요."],
   ['그의 기분을 끌어올려 주는 것', '낡은 동전이 가득한 상자', '그가 다른 사람에게 숨겨야 하는 비밀', '정원에서 앉을 수 있는 따뜻한 곳', '다음 맑은 날을 위한 선물'],
   'letter 편지 / lonely 쓸쓸한 / pocket 주머니 / mood 기분')

# 18번째 (정답 ⑤)
rw(17, "Hana became the president of the student club this spring. The club has forty members and many very difficult jobs. Every day, she feels too small for such a big task. To Hana, the president's job is <u>a coat two sizes too big</u>. Her friends help her a little more each week now.",
   ['clothes she bought last week', 'a prize for her good marks', 'a quiet and easy life with few duties', 'a gift from the other club members', 'a duty that is too large for her'],
   '하나는 올봄에 학생 동아리의 회장이 되었다. 그 동아리에는 회원이 마흔 명 있고 아주 어려운 일이 많다. 날마다 그녀는 그렇게 큰 일을 맡기에는 자신이 너무 작다고 느낀다. 하나에게 회장의 일은 「두 치수나 큰 외투」이다. 친구들이 이제 매주 조금씩 더 그녀를 도와준다.',
   ["1) 밑줄 친 'a coat two sizes too big'(두 치수나 큰 외투)은 진짜 외투가 아니라 비유예요. «the president's job»(회장의 일)을 가리켜요.",
 '2) 단서를 찾아요. «Every day, she feels too small for such a big task.»(날마다 그녀는 그렇게 큰 일을 맡기에는 자신이 너무 작다고 느낀다.) 또 둘째 문장은 «many very difficult jobs»(아주 어려운 일 여러 가지)가 있다고 해요.',
 '3) 몸보다 두 치수나 큰 외투를 입으면 옷이 몸에 맞지 않고 입은 사람이 작아 보여요. 하나도 일은 크고 자신은 작다고 느끼니, 일이 아직 몸에 맞지 않는 옷 같아요.',
 "4) 그러니까 밑줄 친 'a coat two sizes too big'의 뜻은 'a duty that is too large for her'(그녀가 맡기에는 너무 큰 임무)예요."],
   "'a quiet and easy life with few duties'(할 일이 적은 조용하고 쉬운 삶)가 끌릴 수 있어요. 글에 'president'(회장)가 나오니 높은 자리의 편한 삶을 떠올릴 수 있거든요. 하지만 글은 «many very difficult jobs»(아주 어려운 일 여러 가지)가 있다고 해요. 쉬운 삶과 반대예요. 'clothes she bought last week'(그녀가 지난주에 산 옷)는 'coat'(외투)를 글자 그대로 읽은 보기예요.",
   ['옷을 샀다는 말은 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '상을 받았다는 말은 글에 없어요. 글에서 하나가 느끼는 것은 자신이 이 큰 일에 비해 너무 작다는 것이에요.',
 '글은 «many very difficult jobs»(아주 어려운 일 여러 가지)가 있다고 해요. 할 일이 적다는 말과 반대예요.',
 '다른 회원이 선물했다는 말은 글에 없어요. 글에 나오는 것은 친구들이 매주 조금씩 더 도와준다는 것뿐이에요.',
 '하나는 «too small for such a big task»(그렇게 큰 일을 하기에는 너무 작은)라고 느껴요. 몸에 맞지 않게 큰 외투처럼 일이 그녀에게 너무 커요.'],
   ['그녀가 지난주에 산 옷', '좋은 성적에 대한 상', '할 일이 적은 조용하고 쉬운 삶', '다른 동아리 회원들이 준 선물', '그녀가 맡기에는 너무 큰 임무'],
   'president 회장 / member 회원 / task 일, 과제 / size 치수')

# 19번째 (정답 ①)
rw(18, "Dae-ho left his grandmother's small village twenty long years ago. He still remembers one morning in her kitchen very well. Every small detail of that room comes back to him. For Dae-ho, that morning is <u>a picture with no dust on it</u>. With closed eyes, he sees the same bright morning light.",
   ['a memory that is still clear', 'a photo kept in a dusty old box', 'a house nobody has cleaned', 'a story that he made up himself', 'a place he plans to visit again'],
   '대호는 스무 해나 전에 할머니의 작은 마을을 떠났다. 그는 할머니의 부엌에서 보낸 어느 아침을 지금도 아주 잘 기억한다. 그 방의 작은 부분 하나하나가 그에게 되살아난다. 대호에게 그 아침은 「먼지 하나 앉지 않은 그림」이다. 눈을 감으면 그는 그때와 똑같은 환한 아침 햇빛을 본다.',
   ["1) 밑줄 친 'a picture with no dust on it'(먼지 하나 앉지 않은 그림)은 진짜 그림이 아니라 비유예요. «that morning»(그 아침)을 가리켜요.",
 '2) 단서를 찾아요. «He still remembers one morning in her kitchen very well.»(그는 할머니의 부엌에서 보낸 어느 아침을 지금도 아주 잘 기억한다.) «Every small detail of that room comes back to him.»(그 방의 작은 부분 하나하나가 그에게 되살아난다.)',
 '3) 오래 둔 그림에는 먼지가 앉아서 흐릿해져요. 먼지가 앉지 않은 그림은 방금 그린 것처럼 또렷해요. 마을을 떠난 지 «twenty long years»(스무 해나) 지났는데도 아침의 모습이 또렷이 떠오르는 기억과 닮았어요.',
 "4) 그러니까 밑줄 친 'a picture with no dust on it'의 뜻은 'a memory that is still clear'(아직도 또렷한 기억)예요."],
   "'a photo kept in a dusty old box'(먼지 낀 낡은 상자에 담긴 사진)가 끌릴 수 있어요. 'picture'(그림)와 'dust'(먼지)를 글자 그대로 읽은 보기라서요. 하지만 밑줄 친 말은 먼지가 '없다'는 뜻이고, 글에는 진짜 사진이 나오지 않아요. 'a place he plans to visit again'(그가 다시 가 보려 하는 곳)도 마을 이야기에서 떠올릴 수 있지만, 글에 다시 가겠다는 계획은 없어요.",
   ['마을을 떠난 지 스무 해가 지났는데도 그는 그 아침을 아주 잘 기억하고, 작은 부분 하나하나가 되살아나요. 먼지 앉지 않은 그림처럼 또렷한 기억이에요.',
 "글에는 사진이 나오지 않아요. 밑줄 친 말은 먼지가 '없다'는 뜻인데, 먼지 낀 상자를 말하는 보기예요.",
 "집을 청소하는 이야기는 글에 없어요. 밑줄 친 말의 'dust'(먼지)만 따온 보기예요.",
 '그가 이야기를 지어냈다는 말은 글에 없어요. 그는 어느 아침을 기억해요.',
 '다시 가겠다는 계획은 글에 없어요. 그는 눈을 감고 그 아침을 떠올릴 뿐이에요.'],
   ['아직도 또렷한 기억', '먼지 낀 낡은 상자에 담긴 사진', '아무도 청소하지 않은 집', '그가 직접 지어낸 이야기', '그가 다시 가 보려 하는 곳'],
   'village 마을 / remember 기억하다 / detail 작은 부분 / dust 먼지')

# 20번째 (정답 ④)
rw(19, 'Tae and his older brother live in the same small house. They sit at the same table for every single meal. Since the big fight last year, neither of them speaks first. Between the two brothers, there is <u>a river with no bridge</u>. Their mother watches the two of them quietly during every meal.',
   ['a bridge that they built together', 'a river near their house', 'a wish to live in different places', 'a gap that is hard to cross', 'an old game they played as boys'],
   '태와 그의 형은 같은 작은 집에서 산다. 둘은 한 끼도 빠짐없이 같은 식탁에 앉는다. 작년의 큰 싸움 뒤로 둘 중 누구도 먼저 말을 걸지 않는다. 두 형제 사이에는 「다리가 없는 강」이 있다. 어머니는 식사 때마다 둘을 조용히 지켜본다.',
   ["1) 밑줄 친 'a river with no bridge'(다리가 없는 강)는 진짜 강이 아니라 비유예요. «Between the two brothers»(두 형제 사이에)라고 했으니 두 형제 사이에 있는 무언가를 말해요.",
 '2) 단서를 찾아요. «Since the big fight last year, neither of them speaks first.»(작년의 큰 싸움 뒤로 둘 중 누구도 먼저 말을 걸지 않는다.) 그런데도 «They sit at the same table for every single meal.»(둘은 한 끼도 빠짐없이 같은 식탁에 앉는다.)',
 '3) 강에 다리가 없으면 건너편으로 갈 수가 없어요. 같은 집, 같은 식탁에 있어도 둘 중 누구도 먼저 말을 걸지 않으니, 가까이 있어도 건너기 어려운 틈이 있다고 읽을 수 있어요.',
 "4) 그러니까 밑줄 친 'a river with no bridge'의 뜻은 'a gap that is hard to cross'(건너기 어려운 틈)예요."],
   "'a bridge that they built together'(둘이 함께 놓은 다리)가 끌릴 수 있어요. 'bridge'(다리)라는 낱말이 있어서요. 하지만 밑줄 친 말은 다리가 '없는' 강이에요. 글에는 둘이 화해했다거나 함께 다리를 놓았다는 말이 없고, 둘은 서로 먼저 말을 걸지 않아요. 'a river near their house'(그들의 집 근처에 있는 강)도 'river'(강)를 글자 그대로 읽은 보기예요.",
   ["밑줄 친 말은 다리가 '없다'고 해요. 둘이 다리를 함께 놓았다는 말은 글에 없어요.",
 '집 근처의 강 이야기는 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '다른 곳에서 살고 싶다는 말은 글에 없어요. 글에 나오는 것은 같은 집, 같은 식탁에서 먼저 말을 걸지 않는 모습이에요.',
 '둘은 한집에서 지내는데도 작년의 싸움 뒤로 먼저 말을 걸지 않아요. 같은 집에 있어도 건너기 어려운 틈이 있다고 읽을 수 있어요.',
 '어릴 때 하던 놀이 이야기는 글에 없어요.'],
   ['둘이 함께 놓은 다리', '그들의 집 근처에 있는 강', '서로 다른 곳에서 살고 싶은 바람', '건너기 어려운 틈', '소년 시절에 하던 옛 놀이'],
   'brother 형제 / fight 싸움 / bridge 다리 / cross 건너다')

# 21번째 (정답 ⑤)
rw(20, "Mr. Lee works at the busy factory from noon until midnight. He has not taken a single day off this year. On the bus home, his head falls against the window. In his wife's eyes, Mr. Lee is <u>a battery with no power left</u>. He cannot lift his arms at the end of the day.",
   ['a tool in the factory', 'a man who hates work', 'a worker who is paid very well', 'a man who is full of energy', 'a worker who is worn out'],
   '이 씨는 바쁜 공장에서 정오부터 자정까지 일한다. 그는 올해 하루도 쉰 적이 없다. 집에 가는 버스에서는 머리가 창문에 툭 기댄다. 아내의 눈에 이 씨는 「전기가 하나도 남지 않은 건전지」이다. 그는 하루가 끝날 즈음에는 팔을 들 수 없다.',
   ["1) 밑줄 친 'a battery with no power left'(전기가 하나도 남지 않은 건전지)는 진짜 건전지가 아니라 비유예요. «Mr. Lee»(이 씨)를 가리켜요.",
 '2) 단서를 찾아요. «He has not taken a single day off this year.»(그는 올해 하루도 쉰 적이 없다.) 또 «Mr. Lee works at the busy factory from noon until midnight.»(이 씨는 바쁜 공장에서 정오부터 자정까지 일한다.) 마지막 문장은 «He cannot lift '
 'his arms at the end of the day.»(그는 하루가 끝날 즈음에는 팔을 들 수 없다.)라고 해요.',
 '3) 건전지는 전기가 다 떨어지면 아무것도 움직이지 못해요. 이 씨도 오래 일하고 쉬지 못한 데다 하루가 끝날 즈음에는 팔을 들지 못하니, 힘이 바닥난 모습으로 읽을 수 있어요.',
 "4) 그러니까 밑줄 친 'a battery with no power left'의 뜻은 'a worker who is worn out'(몹시 지친 일꾼)이에요."],
   "'a tool in the factory'(공장에 있는 도구)가 끌릴 수 있어요. 글에 'factory'(공장)가 나오고 건전지가 도구처럼 보여서요. 하지만 밑줄 친 말이 가리키는 것은 «Mr. Lee»(이 씨)예요. 'a man who is full of energy'(기운이 넘치는 남자)는 정반대예요. 이 씨는 팔을 들지 못해요.",
   ['공장에 있는 도구 이야기는 글에 없어요. 밑줄 친 말은 이 씨를 가리켜요.',
 '일을 싫어한다는 말은 글에 없어요. 글에 나오는 것은 이 씨가 오래 일하고 지쳤다는 사실이에요.',
 '월급이 많다는 말은 글에 없어요.',
 '이 씨는 «cannot lift his arms»(팔을 들 수 없다)고 해요. 기운이 넘치는 남자와 반대예요.',
 '오래 일하고 쉬지 못한 데다 하루가 끝날 즈음 팔을 들 수 없어요. 전기가 다 떨어진 건전지처럼 힘이 바닥난 모습이에요.'],
   ['공장에 있는 도구', '일을 싫어하는 남자', '돈을 아주 많이 받는 일꾼', '기운이 넘치는 남자', '몹시 지친 일꾼'],
   'factory 공장 / midnight 자정 / battery 건전지 / lift 들어 올리다')

# 22번째 (정답 ⑤)
rw(21, 'Last year, Mina got low marks in almost every subject. Now a new school year has started with a new class. Her new teacher does not know anything about the old marks. For Mina, this school year is <u>a clean page in a new notebook</u>. She writes her name with great care on the first line.',
   ['a notebook that she lost', 'a lesson on how to write better', 'a tool that makes hard work easy', 'a mistake that she can never fix', 'a fresh chance to begin again'],
   '작년에 미나는 거의 모든 과목에서 낮은 점수를 받았다. 이제 새 학년이 새 반과 함께 시작되었다. 새 선생님은 예전 점수에 대해 아무것도 모른다. 미나에게 이번 학년은 「새 공책의 깨끗한 쪽」이다. 그녀는 첫 줄에 정성껏 자기 이름을 쓴다.',
   ["1) 밑줄 친 'a clean page in a new notebook'(새 공책의 깨끗한 쪽)은 진짜 공책이 아니라 비유예요. «this school year»(이번 학년)를 가리켜요.",
 '2) 단서를 찾아요. «Last year, Mina got low marks in almost every subject.»(작년에 미나는 거의 모든 과목에서 낮은 점수를 받았다.) 그런데 «Her new teacher does not know anything about the old marks.»(새 선생님은 예전 점수에 대해 아무것도 모른다.)',
 '3) 새 공책의 깨끗한 쪽에는 아직 아무것도 쓰여 있지 않아서 처음부터 새로 쓸 수 있어요. 새 선생님이 예전 점수를 모르는 새 학년도 새로 시작할 수 있는 때로 읽을 수 있어요.',
 "4) 그러니까 밑줄 친 'a clean page in a new notebook'의 뜻은 'a fresh chance to begin again'(다시 시작할 새 기회)이에요."],
   "'a notebook that she lost'(그녀가 잃어버린 공책)가 끌릴 수 있어요. 'notebook'(공책)이 글자 그대로 나와서요. 하지만 글에는 공책을 잃어버렸다는 말이 없어요. 'a mistake that she can never fix'(그녀가 결코 고칠 수 없는 실수)는 낮은 점수 때문에 끌릴 수 있지만, 새 선생님은 «the old marks»(예전 점수)에 대해 아무것도 모르니 처음부터 다시 시작할 수 있어요.",
   ['공책을 잃어버렸다는 말은 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '글쓰기 수업 이야기는 글에 없어요.',
 '일을 쉽게 해 주는 도구 이야기는 글에 없어요.',
 '낮은 점수 때문에 끌릴 수 있지만, 지난 점수가 계속 따라다닌다는 말은 글에 없어요. 새 선생님은 «the old marks»(예전 점수)에 대해 아무것도 몰라요.',
 '작년에는 점수가 낮았지만, 새 학년의 새 선생님은 예전 점수를 몰라요. 깨끗한 쪽에 처음부터 쓰듯 다시 시작할 수 있는 때로 읽을 수 있어요.'],
   ['그녀가 잃어버린 공책', '더 잘 쓰는 법에 대한 수업', '힘든 일을 쉽게 해 주는 도구', '그녀가 결코 고칠 수 없는 실수', '다시 시작할 새 기회'],
   'marks 점수 / subject 과목 / page 쪽 / notebook 공책')

# 23번째 (정답 ④)
rw(22, "Yuri laughs the loudest at every party in her class. Her friends think of her as the happiest girl alive. At home, however, she sits alone in her quiet room. To her mother, Yuri's laughter is <u>a curtain over a dark window</u>. Her mother wants to see the sad girl behind it.",
   ['a window that needs cleaning', 'a joke that Yuri tells at parties', 'a true sign of her happiness', 'a happy act that hides sadness', 'a room with a pretty view of the sea'],
   '유리는 반에서 열리는 모든 파티에서 가장 크게 웃는다. 친구들은 그녀를 세상에서 가장 행복한 소녀로 생각한다. 그러나 집에서는 조용한 방에 혼자 앉아 있다. 어머니에게 유리의 웃음은 「어두운 창문을 덮은 커튼」이다. 어머니는 그 뒤에 있는 슬픈 소녀를 보고 싶어 한다.',
   ["1) 밑줄 친 'a curtain over a dark window'(어두운 창문을 덮은 커튼)는 진짜 커튼이 아니라 비유예요. «Yuri's laughter»(유리의 웃음)를 가리켜요.",
 '2) 단서를 찾아요. «Yuri laughs the loudest at every party in her class.»(유리는 반에서 열리는 모든 파티에서 가장 크게 웃는다.) 하지만 «At home, however, she sits alone in her quiet room.»(그러나 집에서는 조용한 방에 혼자 앉아 있다.) 마지막 문장은 «Her '
 'mother wants to see the sad girl behind it.»(어머니는 그 뒤에 있는 슬픈 소녀를 보고 싶어 한다.)라고 해요.',
 '3) 커튼은 창문 안쪽을 가려서 밖에서는 안이 보이지 않아요. 밝은 웃음 뒤에 어두운 마음이 가려져 있다고 읽을 수 있어요. 어머니는 «behind it»(그 뒤에)에 있는 슬픈 소녀를 보고 싶어 해요.',
 "4) 그러니까 밑줄 친 'a curtain over a dark window'의 뜻은 'a happy act that hides sadness'(슬픔을 감추는 행복한 연기)예요."],
   "'a true sign of her happiness'(그녀의 행복을 보여 주는 진짜 신호)가 끌릴 수 있어요. 친구들은 유리를 «the happiest girl alive»(세상에서 가장 행복한 소녀)로 보거든요. 하지만 밑줄 친 말은 «To her mother»(어머니에게는)라고 했고, 어머니는 그 뒤의 슬픈 소녀를 보고 싶어 해요. 'a window that needs cleaning'(청소가 필요한 창문)은 'window'(창문)를 글자 그대로 읽은 보기예요.",
   ['창문을 청소하는 이야기는 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '유리는 파티에서 크게 웃지만, 농담을 한다는 말은 글에 없어요.',
 '친구들의 생각일 뿐이에요. 어머니는 그 뒤의 «sad girl»(슬픈 소녀)을 보고 싶어 해요.',
 '파티에서는 가장 크게 웃지만 집에서는 조용한 방에 혼자 앉아 있어요. 어머니는 웃음 뒤의 슬픈 소녀를 보고 싶어 하니, 웃음이 슬픔을 가린다고 읽을 수 있어요.',
 "바다가 보이는 방은 글에 나오지 않아요. 'window'(창문)에서 떠올린 보기예요."],
   ['청소가 필요한 창문', '유리가 파티에서 하는 농담', '그녀의 행복을 보여 주는 진짜 신호', '슬픔을 감추는 행복한 연기', '바다가 예쁘게 보이는 방'],
   'laughter 웃음 / curtain 커튼 / alone 혼자 / behind 뒤에')

# 24번째 (정답 ②)
rw(23, 'Old Mr. Han plants small trees on the hill every spring. These small trees will not be tall for fifty years. At the age of eighty, Mr. Han still climbs the hill. For the village, his trees are <u>a letter to the future</u>. Only the village children of tomorrow will rest in their shade.',
   ['a note he wrote to his friends', 'a gift for those born later', 'a plan to sell the wood to a shop', 'a job that he does only for money', 'a sad wish to be young once again'],
   '나이 든 한 씨는 해마다 봄에 언덕에 작은 나무들을 심는다. 이 작은 나무들은 오십 년 동안 키가 크지 않을 것이다. 여든 살에도 한 씨는 여전히 그 언덕을 오른다. 마을에게 그의 나무들은 「미래에 보내는 편지」이다. 내일의 마을 아이들만이 그 그늘에서 쉬게 될 것이다.',
   ["1) 밑줄 친 'a letter to the future'(미래에 보내는 편지)는 진짜 편지가 아니라 비유예요. «his trees»(그의 나무들)를 가리켜요.",
 '2) 단서를 찾아요. «These small trees will not be tall for fifty years.»(이 작은 나무들은 오십 년 동안 키가 크지 않을 것이다.) 한 씨는 «At the age of eighty»(여든 살에)도 언덕을 올라요. 마지막 문장은 «Only the village children of tomorrow will '
 'rest in their shade.»(내일의 마을 아이들만이 그 그늘에서 쉬게 될 것이다.)라고 해요.',
 '3) 편지는 지금 쓰지만 나중에 읽는 사람에게 닿아요. 한 씨의 나무도 지금 심지만 그 그늘은 먼 훗날의 아이들이 누려요. 한 씨는 그날을 보지 못할 수도 있어요. 그 그늘을 누리는 사람은 심은 한 씨가 아니라 훗날의 아이들이니, 나중 사람에게 남겨 주는 선물로 읽을 수 있어요.',
 "4) 그러니까 밑줄 친 'a letter to the future'의 뜻은 'a gift for those born later'(나중에 태어난 사람들을 위한 선물)예요."],
   "'a note he wrote to his friends'(그가 친구들에게 쓴 쪽지)가 끌릴 수 있어요. 'letter'(편지)를 글자 그대로 읽은 보기라서요. 하지만 글에는 한 씨가 쓴 글이 나오지 않아요. 나무를 심는 이야기예요. 'a job that he does only for money'(그가 돈만 보고 하는 일)도 나무를 심는 일에서 끌릴 수 있지만, 글에 돈 이야기는 없고 그늘에서 쉬는 사람은 «the village children of tomorrow»(내일의 마을 아이들)예요.",
   ["한 씨가 글을 썼다는 말은 글에 없어요. 밑줄 친 말의 'letter'(편지)에서 떠올린 보기예요.",
 '나무는 오십 년 동안은 키가 크지 않을 것이고, 그늘에서 쉬는 사람은 «children of tomorrow»(내일의 아이들)예요. 나중에 올 사람들에게 남기는 선물로 읽을 수 있어요.',
 '나무를 팔겠다는 계획은 글에 없어요. 그늘은 마을 아이들이 쉬는 곳이에요.',
 '돈 이야기는 글에 없어요.',
 '젊어지고 싶다는 소망은 글에 없어요. 한 씨는 여든 살에도 언덕을 올라요.'],
   ['그가 친구들에게 쓴 쪽지', '나중에 태어난 사람들을 위한 선물', '나무를 가게에 팔 계획', '그가 돈만 보고 하는 일', '다시 젊어지고 싶은 슬픈 소망'],
   'hill 언덕 / tall 키가 큰 / shade 그늘 / future 미래')

# 25번째 (정답 ①)
rw(24, "Jisoo's grandmother speaks only Korean in her new American town. At the bank, Jisoo turns every English word into Korean. Then she gives the clerk Grandma's answers in clear English. For the two people at the desk, Jisoo is <u>a bridge between two shores</u>. Without her, the clerk and Grandma could not understand each other.",
   ['someone who links two speakers', 'a road built over the water', 'a girl who is afraid of the bank', 'a teacher of two languages', 'a boat that crosses the sea'],
   '지수의 할머니는 미국의 새 마을에서 한국어만 말한다. 은행에서 지수는 영어 낱말을 모두 한국어로 옮겨 준다. 그러고 나서 그녀는 할머니의 대답을 또렷한 영어로 직원에게 전한다. 창구에 있는 두 사람에게 지수는 「두 기슭 사이의 다리」이다. 지수가 없다면 직원과 할머니는 서로를 이해하지 못할 것이다.',
   ["1) 밑줄 친 'a bridge between two shores'(두 기슭 사이의 다리)는 진짜 다리가 아니라 비유예요. «Jisoo»(지수)를 가리켜요.",
 "2) 단서를 찾아요. «At the bank, Jisoo turns every English word into Korean.»(은행에서 지수는 영어 낱말을 모두 한국어로 옮겨 준다.) «Then she gives the clerk Grandma's answers in clear English.»(그러고 나서 그녀는 할머니의 대답을 또렷한 영어로 "
 '직원에게 전한다.)',
 '3) 다리는 강 양쪽 기슭을 이어 줘요. 마지막 문장은 «Without her, the clerk and Grandma could not understand each other.»(지수가 없다면 직원과 할머니는 서로를 이해하지 못할 것이다.)라고 해요. 서로 말이 통하지 않는 두 사람 사이를 이어 주는 사람이에요.',
 "4) 그러니까 밑줄 친 'a bridge between two shores'의 뜻은 'someone who links two speakers'(말하는 두 사람을 이어 주는 사람)예요."],
   "'a teacher of two languages'(두 언어를 가르치는 선생님)가 끌릴 수 있어요. 지수가 한국어와 영어를 둘 다 쓰기 때문이에요. 하지만 글에서 지수는 가르치지 않고, 은행에서 한쪽 말을 다른 쪽 말로 옮겨 줄 뿐이에요. 'a road built over the water'(물 위에 놓은 길)는 'bridge'(다리)를 글자 그대로 읽은 보기예요.",
   ['지수는 직원의 영어를 할머니를 위해 한국어로 옮기고, 할머니의 대답을 영어로 직원에게 전해요. 말이 통하지 않는 두 사람을 이어 주는 사람이에요.',
 '물 위에 놓은 길 이야기는 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '은행을 무서워한다는 말은 글에 없어요. 지수는 은행에서 할머니를 도와요.',
 '지수는 말을 옮겨 줄 뿐 가르치지 않아요. 가르친다는 말은 글에 없어요.',
 "배 이야기는 글에 없어요. 밑줄 친 말의 'shores'(기슭)에서 떠올린 보기예요."],
   ['말하는 두 사람을 이어 주는 사람', '물 위에 놓은 길', '은행을 무서워하는 소녀', '두 언어를 가르치는 선생님', '바다를 건너는 배'],
   'clerk 직원 / bank 은행 / shore 기슭 / understand 이해하다')

# 26번째 (정답 ⑤)
rw(25, 'Dad lost his job at the shoe factory in June. For three long months, the telephone at our house stayed silent. Yesterday, a small company called him about a possible job. To Dad, that short call is <u>a crack of light under a door</u>. Our whole family now hopes for the next phone call.',
   ['a lamp that has been left on', 'a bill that he cannot pay', 'a warning of a coming storm', 'a repair job at the house', 'a small sign of hope'],
   '아빠는 유월에 신발 공장에서 일자리를 잃었다. 긴 석 달 동안 우리 집 전화기는 조용했다. 어제 작은 회사 한 곳이 일자리가 될 수도 있는 일 때문에 그에게 전화했다. 아빠에게 그 짧은 전화는 「문 아래 틈으로 비치는 한 줄기 빛」이다. 이제 우리 온 가족이 다음 전화를 바란다.',
   ["1) 밑줄 친 'a crack of light under a door'(문 아래 틈으로 비치는 한 줄기 빛)는 진짜 빛이 아니라 비유예요. «that short call»(그 짧은 전화)을 가리켜요.",
 '2) 단서를 찾아요. «For three long months, the telephone at our house stayed silent.»(긴 석 달 동안 우리 집 전화기는 조용했다.) «Yesterday, a small company called him about a possible job.»(어제 작은 회사 한 곳이 일자리가 될 수도 있는 일 '
 '때문에 그에게 전화했다.) 마지막 문장은 «Our whole family now hopes for the next phone call.»(이제 우리 온 가족이 다음 전화를 바란다.)라고 해요.',
 '3) 닫힌 문 아래로 새어 나오는 빛은 문 너머에 무언가 있다는 작은 신호예요. 석 달 만에 온 전화도 아직 확실한 일자리가 아니라 일자리가 될 수도 있는 일 이야기일 뿐이지만, 가족에게 희망을 줘요.',
 "4) 그러니까 밑줄 친 'a crack of light under a door'의 뜻은 'a small sign of hope'(작은 희망의 신호)예요."],
   "'a lamp that has been left on'(켜 놓은 채로 둔 등)이 끌릴 수 있어요. 'light'(빛)를 글자 그대로 읽은 보기라서요. 하지만 글에는 등 이야기가 없어요. 'a repair job at the house'(집을 고치는 일)는 글에 나오는 «a possible job»(일자리가 될 수도 있는 일)의 'job'(일)만 따온 보기예요. 전화는 집 수리가 아니라 새 일자리에 대한 것이었어요.",
   ['등을 켜 두었다는 말은 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '빚이나 청구서 이야기는 글에 없어요.',
 '나쁜 일이 올 거라는 경고가 아니에요. 아빠가 받은 전화는 일자리 이야기였고, 가족은 다음 전화를 바라요.',
 "집을 고치는 일은 글에 없어요. 'job'(일)만 따온 보기예요.",
 '긴 석 달 동안 조용하던 전화로 일자리 이야기가 왔고, 가족은 다음 전화를 바라요. 작지만 희망을 주는 신호예요.'],
   ['켜 놓은 채로 둔 등', '그가 낼 수 없는 청구서', '폭풍이 올 것이라는 경고', '집을 고치는 일', '작은 희망의 신호'],
   'factory 공장 / silent 조용한 / company 회사 / crack 틈')

# 27번째 (정답 ②)
rw(26, 'Grandma lives in a small town far across the sea. Every Sunday morning, we sit in front of the tablet. Her face appears on the screen with a warm hello. For little Sam, that screen is <u>a window to the other side of the world</u>. He waves both hands at her for the whole call.',
   ['a glass door in her house', 'a way to see someone far away', 'a game that Sam likes to play alone', 'a gift sent by his favorite teacher', 'a place where the sun comes up first'],
   '할머니는 바다 건너 멀리 있는 작은 마을에 사신다. 일요일 아침마다 우리는 태블릿 앞에 앉는다. 할머니의 얼굴이 따뜻한 인사와 함께 화면에 나타난다. 어린 샘에게 그 화면은 「세상 반대편으로 난 창문」이다. 샘은 통화하는 내내 두 손을 흔든다.',
   ["1) 밑줄 친 'a window to the other side of the world'(세상 반대편으로 난 창문)는 진짜 창문이 아니라 비유예요. «that screen»(그 화면)을 가리켜요.",
 '2) 단서를 찾아요. «Grandma lives in a small town far across the sea.»(할머니는 바다 건너 멀리 있는 작은 마을에 사신다.) «Her face appears on the screen with a warm hello.»(할머니의 얼굴이 따뜻한 인사와 함께 화면에 나타난다.)',
 '3) 창문을 열면 바깥을 볼 수 있어요. 이 화면은 멀리 떨어진 곳을 볼 수 있게 해 주는 창문처럼 쓰이고 있어요. 그 덕에 멀리 사는 할머니를 보고 인사를 나눠요.',
 "4) 그러니까 밑줄 친 'a window to the other side of the world'의 뜻은 'a way to see someone far away'(멀리 있는 사람을 볼 수 있는 방법)예요."],
   "'a glass door in her house'(그녀의 집에 있는 유리문)가 끌릴 수 있어요. 'window'(창문)를 글자 그대로 읽은 보기라서요. 하지만 글은 화면 이야기이고, 유리문은 나오지 않아요. 'a place where the sun comes up first'(해가 가장 먼저 뜨는 곳)는 'other side of the world'(세상의 반대편)에서 떠올릴 수 있지만, 글에 해가 뜨는 이야기는 없어요.",
   ['유리문 이야기는 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '화면에 멀리 사는 할머니의 얼굴이 나타나고 따뜻한 인사를 나눠요. 화면으로 먼 곳의 사람을 볼 수 있어요.',
 '샘이 혼자 하는 놀이 이야기는 글에 없어요. 화면에는 할머니가 나타나요.',
 '선생님이 준 선물 이야기는 글에 없어요.',
 "해가 뜨는 이야기는 글에 없어요. 밑줄 친 말의 'other side of the world'(세상의 반대편)에서 떠올린 보기예요."],
   ['그녀의 집에 있는 유리문', '멀리 있는 사람을 볼 수 있는 방법', '샘이 혼자 즐기는 놀이', '그가 가장 좋아하는 선생님이 보낸 선물', '해가 가장 먼저 뜨는 곳'],
   'tablet 태블릿 / screen 화면 / wave 손을 흔들다 / across 건너')

# 28번째 (정답 ③)
rw(27, "We have moved to a new town almost every year. Dad's company sends him to a different city each spring. I have changed my school five times in six years. In my own mind, I am <u>a leaf in the wind</u>. My friends from every old school are far away now.",
   ['a child who likes strong winds', 'a student with a lot of close friends', 'a person with no place to settle', 'someone who loves the autumn', 'a person afraid of the weather'],
   '우리는 거의 해마다 새로운 마을로 이사했다. 아빠의 회사는 봄마다 아빠를 다른 도시로 보낸다. 나는 육 년 동안 학교를 다섯 번 옮겼다. 내 마음속에서 나는 「바람 속의 나뭇잎」이다. 내가 다녔던 모든 옛 학교의 친구들은 이제 멀리 있다.',
   ["1) 밑줄 친 'a leaf in the wind'(바람 속의 나뭇잎)는 진짜 나뭇잎이 아니라 비유예요. «In my own mind, I am»(내 마음속에서 나는 ~이다) 바로 뒤에 나오니, 말하는 사람 자신을 가리켜요.",
 '2) 단서를 찾아요. «We have moved to a new town almost every year.»(우리는 거의 해마다 새로운 마을로 이사했다.) «I have changed my school five times in six years.»(나는 육 년 동안 학교를 다섯 번 옮겼다.)',
 '3) 바람에 날리는 나뭇잎은 어디에 내려앉을지 스스로 정하지 못하고 바람 부는 대로 가요. 말하는 사람도 아빠의 회사 때문에 도시를 옮겨 다녀서 한곳에 자리 잡지 못해요. 마지막 문장도 «My friends from every old school are far away now.»(내가 다녔던 모든 옛 학교의 친구들은 이제 멀리 있다.)라고 해요.',
 "4) 그러니까 밑줄 친 'a leaf in the wind'의 뜻은 'a person with no place to settle'(자리 잡을 곳이 없는 사람)이에요."],
   "'a child who likes strong winds'(센 바람을 좋아하는 아이)가 끌릴 수 있어요. 'wind'(바람)를 글자 그대로 읽은 보기라서요. 하지만 글에는 바람을 좋아한다는 말이 없고, 이사를 자주 다닌다는 이야기만 나와요. 'a student with a lot of close friends'(친한 친구가 많은 학생)는 여러 학교를 다녔으니 친구가 많을 것 같아 끌릴 수 있지만, 글은 친구가 많다거나 친하다고 말하지 않고 예전 학교의 친구들이 이제 모두 «far away»(멀리 있다)고만 해요. 바람에 날리는 나뭇잎은 한곳에 머물지 못하는 모습이라서 '친구가 많은 학생'과 맞지 않아요.",
   ['바람을 좋아한다는 말은 글에 없어요. 밑줄 친 말을 글자 그대로 읽은 보기예요.',
 '예전 학교의 친구들은 이제 모두 멀리 있어요. 친한 친구가 많다는 말은 글에 없어요.',
 '해마다 이사하고 육 년 동안 학교를 다섯 번 옮겼어요. 바람에 날리는 나뭇잎처럼 한곳에 자리 잡지 못해요.',
 "가을을 좋아한다는 말은 글에 없어요. 밑줄 친 말의 'leaf'(나뭇잎)에서 떠올린 보기예요.",
 '날씨를 두려워한다는 말은 글에 없어요.'],
   ['센 바람을 좋아하는 아이', '친한 친구가 많은 학생', '자리 잡을 곳이 없는 사람', '가을을 좋아하는 사람', '날씨를 두려워하는 사람'],
   'move 이사하다 / company 회사 / leaf 나뭇잎 / settle 자리 잡다')

# 29번째 (정답 ④)
rw(28, "My little sister cried loudly about a tiny crack in her pencil case. Tears ran down her red cheeks for ten full minutes. Mother looked closely at the small crack in the case. To Mother, my sister's loud crying was <u>a big wave in a small pond</u>. The next day, my sister had already forgotten the whole thing.",
   ['a danger that is growing worse every day', 'a serious problem for the whole family', 'a quiet lake near our house', 'a big reaction to a tiny matter', 'a lesson about being careful'],
   '내 여동생은 필통에 생긴 아주 작은 금 때문에 큰 소리로 울었다. 눈물이 그 애의 빨간 뺨을 타고 꼬박 십 분 동안 흘렀다. 어머니는 필통의 작은 금을 자세히 들여다보았다. 어머니에게 여동생의 큰 울음은 「작은 연못 속의 큰 파도」였다. 다음 날 여동생은 그 일을 이미 다 잊었다.',
   ["1) 밑줄 친 'a big wave in a small pond'(작은 연못 속의 큰 파도)는 진짜 파도가 아니라 비유예요. «my sister's loud crying»(여동생의 큰 울음)을 가리켜요.",
 '2) 단서를 찾아요. «My little sister cried loudly about a tiny crack in her pencil case.»(내 여동생은 필통에 생긴 아주 작은 금 때문에 큰 소리로 울었다.) 마지막 문장은 «The next day, my sister had already forgotten the whole thing.»(다음 '
 '날 여동생은 그 일을 이미 다 잊었다.)라고 해요.',
 '3) 작은 연못에서는 큰 파도가 칠 일이 없는데, 거기서 큰 파도가 치는 모습이에요. 아주 작은 금 때문에 큰 소동이 난 것과 닮았어요. 어머니도 작은 금을 자세히 들여다봤어요.',
 "4) 그러니까 밑줄 친 'a big wave in a small pond'의 뜻은 'a big reaction to a tiny matter'(작은 일에 대한 큰 반응)예요."],
   "'a serious problem for the whole family'(온 가족의 심각한 문제)가 끌릴 수 있어요. 여동생이 «cried loudly»(큰 소리로 울었다)고 해서 큰일이 난 것처럼 읽히거든요. 하지만 울음의 까닭은 «a tiny crack»(아주 작은 금)이고, 다음 날 이미 다 잊었어요. 'a quiet lake near our house'(우리 집 근처의 조용한 호수)는 'pond'(연못)를 글자 그대로 읽은 보기예요.",
   ['위험이 점점 커진다는 말은 글에 없어요. 여동생은 다음 날 그 일을 이미 잊었어요.',
 '온 가족의 문제라는 말은 글에 없어요. 울음의 까닭은 아주 작은 금이고, 여동생은 다음 날 다 잊었어요.',
 "호수 이야기는 글에 없어요. 밑줄 친 말의 'pond'(연못)를 글자 그대로 읽은 보기예요.",
 '아주 작은 금 때문에 십 분이나 울었지만 다음 날 다 잊었어요. 작은 연못 속의 큰 파도처럼 작은 일에 크게 반응한 거예요.',
 '조심하라는 가르침은 글에 없어요.'],
   ['날마다 더 나빠지는 위험', '온 가족에게 심각한 문제', '우리 집 근처의 조용한 호수', '작은 일에 대한 큰 반응', '조심하는 것에 대한 교훈'],
   'crack 금 / pencil case 필통 / cheek 뺨 / forget 잊다')

# 30번째 (정답 ④)
rw(29, 'Mr. Oh teaches history at our small village school in Jeju. Students ask him hard questions about the past all day. He never needs a book to find the right answer. To the students, Mr. Oh is <u>a library on two legs</u>. Even the teachers in the school come to him for help.',
   ['a building that is full of old books', 'a man who cannot read well', 'a teacher who walks much too slowly', 'a person who knows a great deal', 'a student who studies very late at night'],
   '오 선생님은 제주에 있는 우리 작은 마을 학교에서 역사를 가르친다. 학생들은 하루 종일 그에게 지난날에 관한 어려운 질문을 한다. 그는 맞는 답을 찾는 데 책이 전혀 필요하지 않다. 학생들에게 오 선생님은 「두 다리로 걷는 도서관」이다. 학교의 선생님들까지도 도움을 받으려고 그를 찾아온다.',
   ["1) 밑줄 친 'a library on two legs'(두 다리로 걷는 도서관)는 진짜 도서관이 아니라 비유예요. «Mr. Oh»(오 선생님)를 가리켜요.",
 '2) 단서를 찾아요. «He never needs a book to find the right answer.»(그는 맞는 답을 찾는 데 책이 전혀 필요하지 않다.) 마지막 문장은 «Even the teachers in the school come to him for help.»(학교의 선생님들까지도 도움을 받으려고 그를 찾아온다.)라고 해요.',
 '3) 도서관에는 책이 많이 있어서 사람들이 답을 찾으러 가요. 오 선생님은 책이 없어도 답을 알고, 학생과 선생님이 모두 도움을 받으러 와요. 아는 것이 많은 사람이에요.',
 "4) 그러니까 밑줄 친 'a library on two legs'의 뜻은 'a person who knows a great deal'(아는 것이 아주 많은 사람)이에요."],
   "'a building that is full of old books'(오래된 책이 가득한 건물)가 끌릴 수 있어요. 'library'(도서관)를 글자 그대로 읽은 보기라서요. 하지만 글은 «He never needs a book»(그는 책이 전혀 필요하지 않다)이라고 해요. 'a teacher who walks much too slowly'(너무 느리게 걷는 선생님)는 'two legs'(두 다리)를 글자 그대로 읽은 보기예요.",
   ['책이 가득한 건물 이야기는 글에 없어요. 글은 오 선생님이 책 없이도 답을 안다고 해요.',
 '오 선생님은 역사를 가르치는 선생님이에요. 글을 잘 읽지 못한다는 말은 글에 없어요.',
 "걸음이 느리다는 말은 글에 없어요. 밑줄 친 말의 'two legs'(두 다리)를 글자 그대로 읽은 보기예요.",
 '어려운 질문에도 책 없이 답하고, 다른 선생님들까지 도움을 받으러 와요. 아는 것이 아주 많은 사람이에요.',
 '오 선생님은 학생이 아니라 선생님이에요.'],
   ['오래된 책이 가득한 건물', '글을 잘 읽지 못하는 남자', '너무 느리게 걷는 선생님', '아는 것이 아주 많은 사람', '밤늦게까지 공부하는 학생'],
   'history 역사 / question 질문 / library 도서관 / leg 다리')
