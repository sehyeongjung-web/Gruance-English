# -*- coding: utf-8 -*-
# 292번: 36-37번(글의 순서) 레벨3 — 30문항을 다 읽고 열여섯 문항을 바로잡음 (이 파일: 18~30번째 가운데 일곱 문항)
#   18번째 — (A)와 (C)가 짝이라 (A)-(C)-(B)로도 읽힘(선택지에 있음) → (A) 'At the other end, dyeing the finished garment …'
#   19번째 — (C)가 주어진 글 바로 뒤에도 옴(They = threads) → (C) 'From there they are wound …'((B)의 실패를 받음)
#   22번째 — (C)가 주어진 글 바로 뒤에도 옴 → (C) 'A camera pointed at that spot reads …'((B)의 정해진 자리를 받음)
#   23번째 — (C)-(B)-(A)로도 읽힘. 주어진 글 'not smoother'가 (C) 'removes the fine scratches'와 부딪혀 보임
#            → 주어진 글 '… not smoother to the touch …' / (A) '…, so the difference lies elsewhere.' / (B) 'Without them, light is reflected …'
#   28번째 — (B)와 (C)가 짝이라 (C)-(B)-(A)로도 읽힘 → (C) 'The top coat then provides …'
#   29번째 — (C)의 They가 주어진 글의 두 가닥을 받아 (C)가 맨 앞에도 옴 → (C) 'Two of them are therefore twisted together the opposite way …'
#   30번째 — (A)와 (C)가 짝이라 (C)-(A)-(B)로도 읽힘 → (C) 'Cool conditions, by contrast, take longer …'
AUTO_SYNC = False
E = {}
from z3common import maker
mk = maker(E, lv='3')
def fix(n, text, ko):
    E[('36_37', '3', n)].update({'passage_ok': True, 'text': text, 'ko': ko})

# ---------- 18번째: 천을 염색하는 단계 ----------
mk(17, 'CAB', [
 "1) 주어진 글: 천은 여러 단계에서 염색할 수 있다고 해요. 어떤 단계들이 있고 어떻게 다른지가 이어질 거예요.",
 "2) 첫째 글 (C): «Fibre dyed before spinning gives the most even colour.»(잣기 전에 염색한 섬유가 가장 고른 색을 낸다.) 가장 이른 단계예요. 실을 잣기도 전이에요.",
 "3) 둘째 글 (A): «At the other end, dyeing the finished garment is cheapest and least even.»(반대쪽 끝에서, 완성된 옷을 염색하는 것이 가장 싸고 가장 고르지 않다.) 'At the other end'(반대쪽 끝에서)는 한쪽 끝이 먼저 나와 있어야 쓸 수 있는 말이에요. 그 한쪽 끝이 (C)의 가장 이른 단계예요.",
 "4) 셋째 글 (B)와 확인: «Which stage is chosen depends on the price of the item.»(어느 단계가 골라지는지는 그 물건의 값에 달려 있다.) 두 끝을 다 본 뒤에 무엇으로 고르는지를 말해요. 한쪽 끝 → 반대쪽 끝 → 고르는 기준으로 맞물리므로 순서는 (C)-(A)-(B)예요."],
 "(A)를 (C)보다 먼저 놓고 싶어질 수 있어요. 두 글이 서로 짝이라서 어느 쪽이 먼저여도 될 것 같거든요. 하지만 (A)는 'At the other end'(반대쪽 끝에서)로 시작해요. 한쪽 끝이 먼저 나와야 반대쪽이라고 할 수 있어요.",
 {'ACB': "(A)의 'At the other end'는 한쪽 끝이 먼저 나와야 쓸 수 있어요. 주어진 글에는 끝이 나오지 않았으니 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)가 맨 앞에 오면 어느 단계가 어떤지를 보기도 전에 고르는 기준부터 말하게 돼요. (A)의 'At the other end'가 받을 한쪽 끝도 없어요.",
  'BCA': "(B)가 맨 앞에 와서 단계들을 보기 전에 고르는 기준부터 나와요. 마무리하는 말이 맨 앞에 온 것이에요.",
  'CAB': "(C)가 가장 이른 단계를 말하고, (A)의 'At the other end'가 그 반대쪽 끝인 완성된 옷을 말해요. (B)가 두 끝 가운데 무엇으로 고르는지를 말하며 맺어요.",
  'CBA': "(C)로 시작하는 것은 맞아요. 하지만 고르는 기준인 (B)가 반대쪽 끝인 (A)보다 먼저 와요. 두 끝을 다 보기 전에 맺게 돼요."})
fix(17, ('(A) Dyeing the finished garment is cheapest and least even.', '(A) At the other end, dyeing the finished garment is cheapest and least even.'),
        ('(A) 완성된 옷을 염색하는 것이 가장 싸고 가장 고르지 않다.', '(A) 반대쪽 끝에서, 완성된 옷을 염색하는 것이 가장 싸고 가장 고르지 않다.'))

# ---------- 19번째: 수천 가닥의 실을 감는 법 ----------
mk(18, 'BCA', [
 "1) 주어진 글: 수천 가닥의 실을 나란히 감아야 한다고 해요. 어떻게 감는지가 이어질 거예요.",
 "2) 첫째 글 (B): «Each one comes from its own bobbin on a frame.»(한 가닥 한 가닥은 틀 위의 제 실패에서 나온다.) 'Each one'(한 가닥 한 가닥)이 주어진 글의 threads를 받아요. 실이 어디서 나오는지를 말해요.",
 "3) 둘째 글 (C): «From there they are wound onto one beam under equal tension.»(거기서부터 그것들은 같은 팽팽함으로 하나의 빔에 감긴다.) 'From there'(거기서부터)가 가리키는 곳은 (B)의 실패예요. 실패가 먼저 나와야 해요.",
 "4) 셋째 글 (A)와 확인: «A single crossed thread stops the loom later.»(엇갈린 실 한 가닥이 나중에 그 베틀을 멈춰 세운다.) later(나중에)가 감은 뒤의 일을 말해요. 잘못 감으면 어떻게 되는지로 글을 맺어요. 나옴 → 감김 → 잘못되면으로 맞물리므로 순서는 (B)-(C)-(A)예요."],
 "(C)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글이 감는다고 했으니 감는 이야기가 바로 이어질 것 같거든요. 하지만 (C)는 'From there'(거기서부터)로 시작해요. 거기가 어디인지는 (B)의 실패가 알려 줘요.",
 {'ACB': "(A)의 later는 감은 뒤의 일이에요. 감는 이야기가 나오기도 전에 나중 일부터 말하게 돼요.",
  'BAC': "(B)로 시작하는 것은 맞아요. 하지만 나중 일인 (A)가 감는 (C)보다 먼저 와요. 또 (C)의 'From there'가 (B)의 실패에서 떨어지게 돼요.",
  'BCA': "(B)가 실이 저마다 제 실패에서 나온다고 하고, (C)의 'From there'가 거기서부터 빔에 감긴다고 이어요. (A)의 later가 잘못 감았을 때 나중에 생기는 일로 맺어요.",
  'CAB': "(C)의 'From there'가 가리킬 곳이 주어진 글에 없어요. 실패는 (B)에서 나오므로 (C)가 맨 앞에 올 수 없어요.",
  'CBA': "(C)의 'From there'가 가리킬 곳이 앞에 없어요. 실이 어디서 나오는지를 말하는 (B)가 감는 (C)보다 뒤에 와서 차례가 거꾸로예요."})
fix(18, ('(C) They are wound onto one beam under equal tension.', '(C) From there they are wound onto one beam under equal tension.'),
        ('(C) 그것들을 같은 팽팽함으로 하나의 빔에 감는다.', '(C) 거기서부터 그것들을 같은 팽팽함으로 하나의 빔에 감는다.'))

# ---------- 22번째: 기계가 소포의 주소를 읽는 법 ----------
mk(21, 'BCA', [
 "1) 주어진 글: 소포는 누가 읽기 전에 기계가 먼저 분류한다고 해요. 기계가 어떻게 읽는지가 이어질 거예요.",
 "2) 첫째 글 (B): «The address is printed in a fixed position on the label.»(주소는 그 라벨의 정해진 자리에 인쇄된다.) 기계가 읽을 수 있게 주소의 자리를 정해 둬요.",
 "3) 둘째 글 (C): «A camera pointed at that spot reads the code and the town.»(그 자리를 향한 카메라가 그 코드와 도시 이름을 읽는다.) 'that spot'(그 자리)은 (B)의 정해진 자리예요. 자리가 먼저 나와야 해요.",
 "4) 셋째 글 (A)와 확인: «Anything unreadable is passed to a person instead.»(읽을 수 없는 것은 대신 사람에게 넘겨진다.) unreadable(읽을 수 없는)은 (C)의 reads(읽는다)와 짝이에요. 카메라가 읽지 못한 것만 사람에게 가요. 자리 → 읽기 → 못 읽으면으로 맞물리므로 순서는 (B)-(C)-(A)예요."],
 "(C)를 맨 앞에 놓고 싶어질 수 있어요. 기계가 분류한다는 말 뒤에 카메라 이야기가 바로 이어질 것 같거든요. 하지만 (C)에는 'that spot'(그 자리)이 있어요. 어느 자리인지는 (B)가 알려 줘요.",
 {'ACB': "(A)는 읽지 못한 것을 어떻게 하는지를 말해요. 읽는 이야기가 나오기도 전에 못 읽은 것부터 말하게 돼요.",
  'BAC': "(B)로 시작하는 것은 맞아요. 하지만 못 읽은 것을 넘기는 (A)가 카메라가 읽는 (C)보다 먼저 와요. 읽기도 전에 못 읽은 것이 나와요.",
  'BCA': "(B)가 주소를 정해진 자리에 인쇄한다고 하고, (C)의 'that spot'이 그 자리를 받아 카메라가 읽는다고 이어요. (A)가 읽지 못한 것은 사람에게 넘긴다고 맺어요.",
  'CAB': "(C)의 'that spot'이 가리킬 자리가 주어진 글에 없어요. 정해진 자리는 (B)에서 나오므로 (C)가 맨 앞에 올 수 없어요.",
  'CBA': "(C)의 'that spot'이 가리킬 자리가 앞에 없어요. 자리를 말하는 (B)가 (C)보다 먼저 와야 해요."})
fix(21, ('(C) A camera reads the code and the town.', '(C) A camera pointed at that spot reads the code and the town.'),
        ('(C) 카메라가 코드와 도시 이름을 읽는다.', '(C) 그 자리를 향한 카메라가 코드와 도시 이름을 읽는다.'))

# ---------- 23번째: 광을 낸 면과 연마한 면 ----------
mk(22, 'ACB', [
 "1) 주어진 글: 광을 낸 면이 연마한 면보다 만져서 더 매끄러운 것은 아니라고 해요. 그렇다면 둘은 무엇이 다른지가 이어질 거예요.",
 "2) 첫째 글 (A): «Both feel the same to a finger, so the difference lies elsewhere.»(둘 다 손가락으로는 똑같이 느껴지니, 그 차이는 다른 데 있다.) Both(둘 다)가 주어진 글의 두 면을 받아요. 차이가 다른 데 있다고 했으니, 뒤에 그 차이가 나와야 해요.",
 "3) 둘째 글 (C): «Polishing removes the fine scratches left by grinding.»(광내기는 연마가 남긴 가는 긁힘을 없앤다.) (A)가 말한 다른 데 있는 차이가 이것이에요. 손으로는 느낄 수 없는 가는 긁힘이에요.",
 "4) 셋째 글 (B)와 확인: «Without them, light is reflected in one direction rather than scattered.»(그것들이 없으면 빛은 흩어지는 대신 한 방향으로 반사된다.) them(그것들)은 (C)의 긁힘이에요. 긁힘이 없어지면 빛이 고르게 반사되어 광이 나요. 손으로는 같음 → 긁힘을 없앰 → 빛이 달라짐으로 맞물리므로 순서는 (A)-(C)-(B)예요."],
 "(C)를 맨 앞에 놓고 싶어질 수 있어요. 광내기가 무엇을 하는지부터 말해도 될 것 같거든요. 하지만 그러면 (A)가 뒤로 밀려요. (A)는 차이가 다른 데 있다고 말하는 글이라서, 그 차이를 말하는 (C)와 (B)보다 앞에 와야 해요.",
 {'ACB': "(A)의 Both가 주어진 글의 두 면을 받아 차이는 다른 데 있다고 하고, (C)가 그 차이인 가는 긁힘을 말해요. (B)의 them이 그 긁힘을 받아 빛이 달라진다고 맺어요.",
  'BAC': "(B)의 them이 가리킬 긁힘이 앞에 없어요. 긁힘은 (C)에서 나오므로 (B)가 맨 앞에 올 수 없어요.",
  'BCA': "(B)의 them이 가리킬 것이 앞에 없어요. 또 차이가 다른 데 있다는 (A)가 차이를 다 말한 뒤에 오게 돼요.",
  'CAB': "(C)가 먼저 오면, 차이를 이미 말한 뒤에 (A)가 차이는 다른 데 있다고 하게 돼요. 또 (B)의 them이 (C)의 긁힘에서 떨어져요.",
  'CBA': "(C)와 (B)가 차이를 다 말한 뒤에 (A)가 차이는 다른 데 있다고 해요. 차이를 꺼내는 말이 맨 끝에 와서 차례가 거꾸로예요."})
fix(22, [('A polished surface is not smoother than a ground one.', 'A polished surface is not smoother to the touch than a ground one.'),
         ('(A) Both feel the same to a finger.', '(A) Both feel the same to a finger, so the difference lies elsewhere.'),
         ('(B) Light is reflected in one direction rather than scattered.', '(B) Without them, light is reflected in one direction rather than scattered.')],
        [('광을 낸 면이 연마한 면보다 더 매끄러운 것은 아니다.', '광을 낸 면이 연마한 면보다 만져서 더 매끄러운 것은 아니다.'),
         ('(A) 둘 다 손가락으로는 똑같이 느껴진다.', '(A) 둘 다 손가락으로는 똑같이 느껴지니, 차이는 다른 데 있다.'),
         ('(B) 빛이 흩어지지 않고 한 방향으로 반사된다.', '(B) 그것들이 없으면 빛이 흩어지지 않고 한 방향으로 반사된다.')])

# ---------- 28번째: 페인트를 여러 번 칠하는 까닭 ----------
mk(27, 'BCA', [
 "1) 주어진 글: 페인트를 한 번이 아니라 여러 번 칠하는 데는 까닭이 있다고 해요. 그 까닭이 이어질 거예요.",
 "2) 첫째 글 (B): «The first coat grips the material and seals it.»(첫 칠은 그 재료를 붙잡고 그것을 막아 준다.) first(첫)가 차례의 처음을 알려요. 첫 칠이 하는 일이에요.",
 "3) 둘째 글 (C): «The top coat then provides the colour and the surface.»(그다음 윗칠이 그 색과 그 겉면을 준다.) then(그다음)이 첫 칠 뒤라는 것을 알려요. 윗칠이 하는 일은 첫 칠과 달라요.",
 "4) 셋째 글 (A)와 확인: «A single thick coat performs neither job well.»(한 번의 두꺼운 칠은 어느 일도 잘 해내지 못한다.) 'neither job'(어느 일도 ~않다)은 두 가지 일이 다 나온 뒤에 쓸 수 있는 말이에요. 첫 칠의 일 → 윗칠의 일 → 한 번으로는 둘 다 안 됨으로 맞물리므로 순서는 (B)-(C)-(A)예요."],
 "(C)를 (B)보다 먼저 놓고 싶어질 수 있어요. 두 글이 서로 짝이라서 어느 쪽이 먼저여도 될 것 같거든요. 하지만 (C)에는 then(그다음)이 있어요. 그 앞에 먼저 하는 일이 나와야 해요. first(첫)가 붙은 (B)가 그 일이에요.",
 {'ACB': "(A)의 'neither job'은 두 가지 일이 먼저 나와야 쓸 수 있어요. 주어진 글에는 일이 나오지 않았으니 (A)가 맨 앞에 올 수 없어요.",
  'BAC': "(B)로 시작하는 것은 맞아요. 하지만 (A)의 'neither job'은 두 가지 일을 가리키는데, 아직 첫 칠의 일 하나만 나왔어요.",
  'BCA': "(B)가 첫 칠의 일을 말하고, (C)의 then이 그다음 윗칠의 일을 말해요. (A)의 'neither job'이 그 두 가지를 받아 한 번의 두꺼운 칠로는 안 된다고 맺어요.",
  'CAB': "(C)의 then은 앞에 먼저 하는 일이 있어야 쓸 수 있어요. 첫 칠을 말하는 (B)가 아직 나오지 않았어요.",
  'CBA': "(C)의 then이 받을 앞의 일이 없어요. 윗칠이 첫 칠보다 먼저 나와서 칠하는 차례와도 거꾸로예요."})
fix(27, ('(C) The top coat provides the colour and the surface.', '(C) The top coat then provides the colour and the surface.'),
        ('(C) 윗칠은 색과 겉면을 만든다.', '(C) 그다음 윗칠이 색과 겉면을 만든다.'))

# ---------- 29번째: 두 가닥을 함께 꼬는 까닭 ----------
mk(28, 'ACB', [
 "1) 주어진 글: 함께 꼰 두 가닥의 실은 한 가닥보다 튼튼하다고 해요. 왜 그런지가 이어질 거예요.",
 "2) 첫째 글 (A): «A single thread untwists when it is pulled.»(한 가닥의 실은 당겨지면 꼬임이 풀린다.) 한 가닥만 썼을 때의 탈이에요. 주어진 글이 한 가닥보다 튼튼하다고 했으니, 한 가닥이 왜 약한지를 먼저 말해요.",
 "3) 둘째 글 (C): «Two of them are therefore twisted together the opposite way from the original spin.»(그래서 그것들 두 가닥을 원래 꼬임과 반대 방향으로 함께 꼰다.) therefore(그래서)가 (A)의 탈을 받아요. 풀리는 것을 막으려고 반대 방향으로 꼬는 거예요.",
 "4) 셋째 글 (B)와 확인: «The result resists twisting in either direction.»(그 결과물은 어느 방향으로의 꼬임에도 버틴다.) 'The result'(그 결과물)는 (C)에서 함께 꼰 실이에요. 탈 → 해결 → 결과로 맞물리므로 순서는 (A)-(C)-(B)예요."],
 "(C)를 맨 앞에 놓고 싶어질 수 있어요. 주어진 글이 두 가닥을 꼰다고 했으니 꼬는 방법이 바로 이어질 것 같거든요. 하지만 (C)에는 therefore(그래서)가 있어요. 왜 반대 방향으로 꼬는지의 까닭이 먼저 나와야 해요. 그 까닭이 (A)예요.",
 {'ACB': "(A)가 한 가닥은 당기면 풀린다고 하고, (C)의 therefore가 그래서 두 가닥을 반대 방향으로 꼰다고 이어요. (B)의 'The result'가 그렇게 꼰 실을 받아 맺어요.",
  'BAC': "(B)의 'The result'가 가리킬 결과물이 앞에 없어요. 꼬는 이야기인 (C)가 먼저 나와야 해요.",
  'BCA': "(B)의 'The result'가 가리킬 것이 앞에 없어요. 또 탈을 말하는 (A)가 맨 끝에 오게 돼요.",
  'CAB': "(C)의 therefore가 받을 까닭이 주어진 글에 없어요. 한 가닥이 풀린다는 (A)가 먼저 나와야 해요.",
  'CBA': "(C)의 therefore가 받을 까닭이 앞에 없어요. 까닭인 (A)가 결과인 (B)보다도 뒤에 와서 차례가 거꾸로예요."})
fix(28, ('(C) They are twisted the opposite way from the original spin.', '(C) Two of them are therefore twisted together the opposite way from the original spin.'),
        ('(C) 그것들을 원래 꼬임과 반대 방향으로 꼰다.', '(C) 그래서 두 가닥을 원래 꼬임과 반대 방향으로 함께 꼰다.'))

# ---------- 30번째: 발효는 온도가 좌우한다 ----------
mk(29, 'ACB', [
 "1) 주어진 글: 발효는 시간보다 온도로 조절된다고 해요. 온도에 따라 어떻게 달라지는지가 이어질 거예요.",
 "2) 첫째 글 (A): «Warm conditions work fast and produce sharp flavours.»(따뜻한 조건은 빨리 일하고 톡 쏘는 맛을 낸다.) 온도의 한쪽이에요. 따뜻할 때를 먼저 말해요.",
 "3) 둘째 글 (C): «Cool conditions, by contrast, take longer and taste rounder.»(이와 달리 서늘한 조건은 더 오래 걸리고 맛이 더 둥글다.) 'by contrast'(이와 달리)는 맞세울 것이 앞에 있어야 쓸 수 있어요. 그것이 (A)의 따뜻한 조건이에요.",
 "4) 셋째 글 (B)와 확인: «The recipe gives a range rather than a number of hours.»(그 조리법은 몇 시간이라는 숫자가 아니라 범위를 준다.) 온도에 따라 걸리는 시간이 달라지니, 시간을 딱 하나로 적을 수 없어요. 두 경우를 다 본 뒤의 맺음이에요. 따뜻함 → 서늘함 → 그래서 범위로 맞물리므로 순서는 (A)-(C)-(B)예요."],
 "(C)를 (A)보다 먼저 놓고 싶어질 수 있어요. 두 글이 서로 짝이라서 어느 쪽이 먼저여도 될 것 같거든요. 하지만 (C)에는 'by contrast'(이와 달리)가 있어요. 맞세울 따뜻한 조건이 먼저 나와야 해요.",
 {'ACB': "(A)가 따뜻한 조건을 말하고, (C)의 'by contrast'가 그와 맞세워 서늘한 조건을 말해요. (B)가 그래서 조리법은 시간을 범위로 준다고 맺어요.",
  'BAC': "(B)가 맨 앞에 오면 왜 범위로 주는지를 알기도 전에 맺는 말부터 나와요. 두 조건을 먼저 보아야 해요.",
  'BCA': "(B)가 맨 앞에 와서 맺는 말부터 나와요. 또 (C)의 'by contrast'가 맞세울 (A)가 그 뒤에 와요.",
  'CAB': "(C)의 'by contrast'는 맞세울 것이 앞에 있어야 쓸 수 있어요. 따뜻한 조건을 말하는 (A)가 아직 나오지 않았어요.",
  'CBA': "(C)의 'by contrast'가 맞세울 것이 앞에 없어요. 또 맺는 말인 (B)가 (A)보다 먼저 와요."})
fix(29, ('(C) Cool conditions take longer and taste rounder.', '(C) Cool conditions, by contrast, take longer and taste rounder.'),
        ('(C) 서늘한 조건은 더 오래 걸리고 맛이 더 둥글다.', '(C) 이와 달리 서늘한 조건은 더 오래 걸리고 맛이 더 둥글다.'))
