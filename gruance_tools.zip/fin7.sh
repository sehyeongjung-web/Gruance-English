#!/bin/bash
# 레벨7 한 묶음 끝내기: bash fin7.sh "<수정안 목록>" "<검사 명령>"   예) bash fin7.sh "edits_W2a,edits_W2b" "zcheck3839.py 7"
cd /home/claude/work
python3 build.py "$1" out/index.html > /tmp/b.txt 2>&1
python3 -c "
t=open('/tmp/b.txt',encoding='utf-8',errors='replace').read()
print('\n'.join(l for l in t.split('\n') if '수정 문항' in l or 'Error' in l or 'ssert' in l or 'Traceback' in l)); print(t[-800:] if 'Traceback' in t else '')"
python3 $2 > /tmp/z.txt 2>&1; python3 -c "print(open('/tmp/z.txt',encoding='utf-8',errors='replace').read()[:2500])"
python3 check_all.py > /tmp/c.txt 2>&1; python3 -c "
t=open('/tmp/c.txt',encoding='utf-8',errors='replace').read(); k=t.find('정답 번호'); print(t[k:][:430])"
