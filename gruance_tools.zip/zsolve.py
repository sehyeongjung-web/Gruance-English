# -*- coding: utf-8 -*-
"""독립 풀이에 줄 문제지를 만든다 (318번 · 320번에 보탬).
  PYTHONPATH=/home/claude/work/pending python3 /home/claude/work/zsolve.py edits_X56a 20 2 0-14 [내보낼 폴더]
  → <폴더>/solve_full.txt     지문 + 선택지 (답 없음)                 … ① 답을 모르는 채로 풀려 보기
  → <폴더>/solve_choices.txt  선택지만 (지문·답 없음)                 … ② 지문 없이 선택지만 보고 찍어 보기(문장 선택지 유형)
  → <폴더>/solve_last.txt     빈칸이 든 문장 + 선택지 (빈칸 유형만)   … ② 빈칸 문장만 보고 풀어 보기(낱말 선택지 유형)
  → <폴더>/explain.txt        답 + 지문 + 해석 + 풀이 + 선택지별 해설 … ③ 해설 교정
  → 화면: 정답 줄, 정답 선택지의 길이 순위
rewrite 꼴(text·choices·ko·walk·cn)로 쓴 수정안만 됨. 정답 자리는 cn이 「정답이에요」로 시작하는 줄에서 읽음."""
import sys, os, re, importlib
W = '/home/claude/work'; sys.path.insert(0, W); sys.path.insert(0, W + '/pending')
def main():
    mod, T, LV, rng = sys.argv[1:5]
    out = sys.argv[5] if len(sys.argv) > 5 else '.'
    a, b = [int(x) for x in rng.split('-')]
    E = importlib.import_module(mod).E; C = '①②③④⑤'; key = ''; top2 = first = 0
    op = lambda name: open(os.path.join(out, name), 'w', encoding='utf-8')
    f = op('solve_full.txt'); g = op('solve_choices.txt'); h = op('solve_last.txt'); x = op('explain.txt')
    for n in range(a, b + 1):
        R = E[(T, LV, n)]['rewrite']; ch = R['choices']
        c = '\n'.join('  %s %s' % (C[k], ch[k]) for k in range(5))
        f.write('[%d]\n%s\n%s\n\n' % (n + 1, R['text'], c)); g.write('[%d]\n%s\n\n' % (n + 1, c))
        if '______' in R['text']:
            last = [s for s in re.split(r'(?<=[.?!])\s+', R['text']) if '______' in s][0]
            h.write('[%d]\n%s\n%s\n\n' % (n + 1, last, c))
        ans = [k for k in range(5) if R['cn'][k].startswith('정답이에요')][0]; key += str(ans + 1)
        x.write('[%d] 정답 %s\n지문: %s\n해석: %s\n풀이:\n%s\n선택지별 해설:\n%s\n\n' % (n + 1, C[ans], R['text'], R['ko'], R['walk'], '\n'.join('  %s %s' % (C[k], R['cn'][k]) for k in range(5))))
        L = [len(x_) for x_ in ch]; rank = 1 + sum(1 for x_ in L if x_ > L[ans]); top2 += rank <= 2; first += rank == 1
        print('%2d번째 답 %s · 길이 순위 %d %s' % (n + 1, C[ans], rank, L))
    print('정답 줄', key, '· 정답이 긴 두 개 안', top2, '· 가장 긴 것', first)
if __name__ == '__main__':
    main()
