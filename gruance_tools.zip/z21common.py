# -*- coding: utf-8 -*-
# 21번(함축 의미) 레벨1~3을 레벨 기준으로 다시 쓸 때의 도우미 (335번)
#   from z21common import maker;  rw = maker(E, '1')
#   rw(n, 지문(밑줄은 <u>…</u>), [선택지 다섯], 해석, [풀이 1)~4) 네 줄], 헷갈리는 곳, [선택지별 까닭 다섯], [선택지 우리말 다섯], 낱말 줄)
#   - 정답 번호는 바탕 그대로(어기면 멈춤) · 발문도 바탕 그대로(이 도우미는 건드리지 않음)
#   - 풀이·해설에서 지문을 그대로 옮긴 말은 «…»로 쓰면 큰따옴표로 바뀌고, 지문에 없으면 멈춤
#   - 「첫 문장·둘째 문장 … 마지막 문장」 바로 뒤에 «…»가 오면 그 문장 안에 있는 말인지도 봄
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
_s, _tb, _te = load()
T = '21'
TIP = ("【함축 의미 요령】\n"
       "첫째, 밑줄 친 말은 글자 그대로 읽지 말고 「비유」일 수 있다고 먼저 생각해요.\n"
       "둘째, 밑줄 친 말이 든 문장의 앞뒤에서 그 말을 풀어 주는 단서를 찾아요.\n"
       "셋째, 단서가 말하는 상황과 밑줄 친 말이 어디가 닮았는지 한 줄로 바꿔 말해 봐요.\n"
       "넷째, 바꿔 말한 뜻과 같은 보기를 고르고, 글자 그대로 읽은 보기나 글과 반대인 보기는 지워요.")
ORDW = {'첫': 0, '둘째': 1, '셋째': 2, '넷째': 3, '다섯째': 4, '마지막': -1}
def sents(plain):
    t = re.sub(r'\b(Ms|Mr|Mrs|Dr)\.', lambda m: m.group(1) + '§', plain)
    return [x.replace('§', '.') for x in re.split(r'(?<=[.!?])\s+', t)]
def maker(E, lv):
    def rw(n, text, ch, ko, steps, confuse, reasons, gl, words=None):
        base = _tb[T][lv][n]; a = base['answer']
        assert len(ch) == 5 == len(set(ch)) == len(reasons) == len(gl), (n, '선택지·해설 개수')
        plain = re.sub(r'</?u>', '', text); ss = sents(plain)
        us = re.findall(r'<u>(.*?)</u>', text); assert len(us) == 1, (n, '밑줄은 하나'); u = us[0]
        assert len(ss) == 5 and '<u>' not in ss[0], (n, '다섯 문장 · 첫 문장에는 밑줄 없음')
        assert len(re.findall(r'「[^」]+」', ko)) == 1, (n, '해석의 「」는 하나')
        assert len(steps) == 4 and all(steps[i].startswith('%d) ' % (i + 1)) for i in range(4)), (n, '풀이 네 줄')
        assert ("'%s'" % u) in steps[0], (n, '풀이 1)에 밑줄 친 말')
        assert ("'%s'" % ch[a]) in steps[3], (n, '풀이 4)에 정답 선택지')
        def q(tx):
            for m in re.findall(r'«([^»]*)»', tx): assert m in plain, (n, '지문에 없는 인용', m)
            for who, m in re.findall(r'(첫|둘째|셋째|넷째|다섯째|마지막) 문장[^«\n]{0,14}«([^»]*)»', tx):
                assert m in ss[ORDW[who]], (n, '문장 자리가 어긋남', who, m)
            return tx.replace('«', '"').replace('»', '"')
        walk = TIP + '\n\n【이 문제에 적용】\n' + '\n'.join(q(x) for x in steps) + '\n\n【헷갈리는 곳】\n' + q(confuse)
        if words: walk += '\n\n📌 낱말: ' + words
        cns = [("정답이에요! " if k == a else "") + "'" + ch[k] + "' (" + gl[k] + ") — " + q(reasons[k]) for k in range(5)]
        assert (T, lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, lv, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(ch), 'ko': ko, 'walk': walk, 'cn': cns}}
    return rw
