# -*- coding: utf-8 -*-
# 370번: 45번(장문 세트 43-45의 내용 불일치) 레벨1 — 공통 도우미 (z26common을 본뜸)
#   rw(n, sel, [보기 다섯], 풀이(비튼 곳), 낱말, S=None, K=None, nt=None)
#   · 지문은 43번 레벨1(368번 최종)의 글을 바른 순서로 이은 일곱 문장(draft/base87.py) — 수능처럼 43~45가 같은 글을 씀
#     (선생님 결정 2026-10-18 「43번 글 그대로」 · 보기는 「우리말로」). S·K를 주면 그 문장·해석으로 바꿔 씀(바꾼 문항은 시험을 다시 해야 함).
#   · sel = 보기 다섯이 가리키는 문장 번호(0~6, 커지는 차례). 보기 k는 문장 sel[k]. 정답(바탕 그대로)인 보기만 그 문장의 한 가지를 비틂.
#   · nt = {보기 자리 k: 덧붙일 한 줄} — 영어 문장의 주어가 대명사(He/She/It)라 보기의 이름과 바로 이어지지 않을 때 「'He'(그)는 바로 앞 문장의 할아버지예요.」
# 해설의 꼴은 45번이 써 오던 꼴(① 내용 일치 요령 → ② 정답 보기와 관련된 문장 → ③ 나머지는 맞음 → 📌 낱말)을 따르고,
# 보기마다 「'보기' — 본문과 맞아요. "영어 문장" (한글)」(정답은 「정답이에요! … 본문과 맞지 않아요. 풀이」). 말끝은 「~어요」
import sys, re; sys.path.insert(0, '/home/claude/work'); sys.path.insert(0, '/home/claude/work/draft')
from lib import load as _load
_tb = _load()[1]
import base87 as _B
def maker(E, T='45', LV='1'):
    def rw(n, sel, choices, why, words, S=None, K=None, nt=None):
        it = _tb[T][LV][n]; ans = it['answer']; nt = dict(nt or {})
        S = list(S) if S else list(_B.B[n]['S']); K = list(K) if K else list(_B.B[n]['K'])
        assert len(S) == 7 == len(K), (n, '문장은 일곱')
        assert len(sel) == 5 and list(sel) == sorted(set(sel)) and all(0 <= i <= 6 for i in sel), (n, 'sel은 0~6에서 다섯, 커지는 차례', sel)
        assert len(choices) == 5 == len(set(choices)), (n, '보기 다섯, 겹침 없음')
        assert all(c.endswith('다') for c in choices), (n, '보기는 「~다」로 끝남')   # 아래 「~와」 조사가 맞으려면 받침 없는 끝(다)이어야 함
        assert '정답' not in why, (n, '풀이에 정답이라는 말')
        assert ans not in nt and all(0 <= k <= 4 for k in nt), (n, 'nt는 정답이 아닌 보기에만')
        sa = S[sel[ans]]
        for q in re.findall(r"'([A-Za-z][^']*)'", why): assert q.lower() in sa.lower(), (n, '풀이의 영어가 비튼 문장에 없음', q)
        for k, x in nt.items():
            assert '정답' not in x and x.rstrip().endswith('요.'), (n, 'nt는 해요체 한 줄', x)
            for q in re.findall(r"'([A-Za-z][^']*)'", x): assert q.lower() in S[sel[k]].lower(), (n, 'nt의 영어가 그 문장에 없음', q)
        walk = ("① 내용 일치 문제는 선택지를 본문 문장과 하나씩 맞춰 봐요. 이 문제는 본문과 맞지 않는 것을 찾아야 해요.\n"
                "② 선택지 '%s'와 관련된 문장을 보세요.\n\"%s\" (%s)\n→ %s\n"
                "③ 나머지 네 선택지는 모두 본문과 맞아요. 그러니까 정답은 이 선택지예요 → '%s'\n📌 낱말: %s") % (choices[ans], sa, K[sel[ans]].strip(), why, choices[ans], words)
        out = []
        for k in range(5):
            if k == ans: out.append("정답이에요! '%s' — 본문과 맞지 않아요. %s" % (choices[k], why))
            else: out.append("'%s' — 본문과 맞아요. \"%s\" (%s)%s" % (choices[k], S[sel[k]], K[sel[k]].strip(), (' ' + nt[k]) if k in nt else ''))
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': ' '.join(S), 'choices': list(choices), 'ko': ' '.join(x.strip() for x in K), 'walk': walk, 'cn': out}}
    return rw
