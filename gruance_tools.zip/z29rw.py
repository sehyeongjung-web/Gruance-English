# -*- coding: utf-8 -*-
# 29번(어법) 레벨1을 레벨 기준으로 다시 쓸 때의 도우미 (340번)
#   from z29rw import maker;  rw = maker(E)
#   rw(n, cat, [다섯 문장(표시 ①~⑤ 한 번씩, 정답 자리는 틀린 꼴)], cw(올바른 꼴), [해석 다섯], [자리별 설명 다섯], 낱말 줄)
#   - 정답 자리는 바탕 그대로(어기면 멈춤) · 선택지는 ①~⑤ 그대로
#   - 설명(notes)의 정답 자리 것은 「틀린 꼴 (×) → 올바른 꼴 (○)」를 담고, 나머지는 「… (○)」로 끝남
#   - 풀이(walk)·선택지별 해설(cn)은 바탕 29번 레벨1의 꼴 그대로 짜 맞춤(5종: sv · past · modal · plural · pron)
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
_s, _tb, _te = load()
CIRC = '①②③④⑤'
HEAD = "① 어법 문제는 밑줄 친 부분이 문장 안에서 맞는 형태인지 하나씩 확인해요. "
INTRO = {
 'sv': "이 글은 '누가 하는 일인지(주어)'를 보고 동사 모양을 살펴보면 돼요.\n· 주어가 하나(He, She, It, 이름 등) → 동사에 -s나 -es (likes, reaches), 모양이 바뀌는 말은 is·has\n· 주어가 여럿(They 등)이거나 you → -s 없이 (like, reach), 모양이 바뀌는 말은 are·have\n· I는 -s 없이 쓰고, be동사는 am이에요 (I like, I am)",
 'past': "이 글은 '언제 일인지'를 보고 동사 모양을 살펴보면 돼요.\n· 지난 일(yesterday, last ~, ~ ago) → 과거형 (went, came, was)",
 'modal': "이 글은 can·will 같은 말 뒤에 오는 동사 모양을 살펴보면 돼요.\n· can, cannot, will, must, should 뒤 → 주어가 누구든 동사 원형 (can swim, will come)\n· 그 밖의 자리는 주어가 하나인지 여럿인지에 맞는 동사 모양인지 함께 봐요 (He plays, They are)",
 'plural': "이 글은 '하나인지 여럿인지'를 보고 이름 말(명사)의 모양을 살펴보면 돼요.\n· 둘 이상 → -s를 붙여요 (two beds). box·baby·shelf처럼 모양이 바뀌는 말도 있어요 (boxes, babies, shelves)\n· 하나 → 붙이지 않아요 (a bed, each student)",
 'pron': "이 글은 사람을 가리키는 말(I, he, she …)이 놓인 자리를 살펴보면 돼요.\n· 주어 자리 → I, he, she, we, they (Tom and I처럼 둘이 함께 주어일 때도 I)\n· 동사나 to·with 뒤 → me, him, her, us, them"}
RULE = {
 'sv': "주어가 하나(He, She, It, 이름 등)면 동사에 -s나 -es를 붙이고(likes, reaches) be동사는 is, have는 has를 써요 / 주어가 여럿(They 등)이거나 you면 -s 없이(like, reach) be동사는 are, have는 그대로 써요 / I도 -s 없이 쓰고 be동사는 am이에요",
 'past': "지난 일(yesterday, last ~, ~ ago)은 동사를 과거형으로 써요 (go → went, come → came, open → opened)",
 'modal': "can, cannot, will, must, should 뒤에는 주어가 누구든 동사 원형을 써요 (can swim, will come)",
 'plural': "둘 이상을 말할 때는 명사에 -s를 붙여요 (two beds, three cats; 단 box → boxes, baby → babies, shelf → shelves) / 하나일 때는 붙이지 않아요 (a bed, one cat)",
 'pron': "주어 자리에는 I, he, she, we, they를 쓰고, 동사나 to·with 뒤에는 me, him, her, us, them을 써요"}
INTRO['there'] = INTRO['sv'] + "\n· There is/are ~ 문장은 is·are 뒤에 오는 말이 주어예요 (There is a park / There are two parks)"
RULE['there'] = RULE['sv'] + " / There is/are ~ 문장은 is·are 뒤에 오는 말이 주어예요"
def sents(S): return S
def maker(E):
    def rw(n, cat, S, cw, ko, notes, words):
        base = _tb['29']['1'][n]; a = base['answer']
        assert cat in INTRO, (n, 'cat')
        assert len(S) == 5 == len(ko) == len(notes), (n, '문장·해석·설명은 다섯')
        toks = []
        for k in range(5):
            assert S[k].count(CIRC[k]) == 1 and sum(S[k].count(c) for c in CIRC) == 1, (n, k, '표시')
            m = re.search(CIRC[k] + r"([A-Za-z']+)", S[k]); assert m, (n, k, '표시 뒤 낱말'); toks.append(m.group(1))
            assert S[k].endswith('.'), (n, k, '문장 끝 마침표')
        assert list(base['choices']) == list(CIRC), (n, '선택지는 ①~⑤')
        assert toks[a] != cw, (n, '정답 자리의 틀린 꼴과 올바른 꼴이 같음')
        for k in range(5):
            if k == a:
                assert '%s (×) → %s (○)' % (toks[k], cw) in notes[k], (n, k, '정답 자리 설명에 「틀린 꼴 (×) → 올바른 꼴 (○)」')
            else:
                assert notes[k].endswith('(○)') and '(×)' not in notes[k], (n, k, '다른 자리 설명은 (○)로 끝')
            assert '정답' not in notes[k], (n, k, '설명에 「정답」이라는 말')
        assert all(re.search(r'[가-힣]', x) for x in ko), (n, '해석')
        text = ' '.join(S)
        walk = (HEAD + INTRO[cat] + '\n② 표시 %s번이 든 문장을 보세요.\n"%s" (%s)\n→ %s\n③ 나머지 네 곳은 모두 맞아요. 그러니까 정답은 %s번이에요.\n📌 문법: %s\n📌 낱말: %s'
                % (CIRC[a], S[a], ko[a], notes[a], CIRC[a], RULE[cat], words))
        cn = [('정답이에요! ' if k == a else '') + '%s %s — %s' % (CIRC[k], toks[k], notes[k]) for k in range(5)]
        assert ('29', '1', n) not in E, (n, '같은 문항을 두 번 씀')
        E[('29', '1', n)] = {'passage_ok': True, 'ans_ok': True,
                             'rewrite': {'text': text, 'choices': list(CIRC), 'ko': ' '.join(ko), 'walk': walk, 'cn': cn, 'cw': cw}}
    return rw
