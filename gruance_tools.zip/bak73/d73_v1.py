# -*- coding: utf-8 -*-
# 33번(빈칸 — 구) 레벨1 다시 쓰기(357번) 영어 원고 전체. 네 문장 · 단문 · 정답 구가 글에 그대로 · 빈칸 문장만으로는 정해지지 않는 꼴(일과·버릇 이야기)
I = {}
I[0] = dict(S=['Jisu keeps a small brown rabbit in a big box in her room.', 'On school days, she cleans the box after her dinner.', 'On Saturdays, she cleans it after breakfast with help from her dad.', "So on school days, Jisu cleans her rabbit's box ______."],
 ch={0: 'before her bedtime', 1: 'after breakfast', 2: 'after her dinner', 3: 'after her bath', 4: 'before her homework'})
I[1] = dict(S=['Daeho plays the drums in a small band with three friends.',
 'On weekday evenings, he practices alone in the music room at school.',
 "On Sunday afternoons, the whole band practices in his uncle's garage.",
 'So on weekday evenings, Daeho usually plays his drums ______.'],
 ch={0: 'in the music room', 1: "in his uncle's garage", 2: 'in his small bedroom', 3: 'in the church hall', 4: 'in the living room'})
I[2] = dict(S=['Sena plays badminton for about an hour every Sunday morning.',
 'From spring to fall, she plays at the park with her best friend Ara.',
 'In winter, she plays in the school gym with her grandfather.',
 'So from spring to fall, Sena plays badminton every Sunday ______.'],
 ch={0: 'with her grandfather', 1: 'with her little sister', 2: 'with her best friend', 3: 'with her school coach', 4: 'with her older cousin'})
I[3] = dict(S=['Every Saturday morning, Yuna walks to the market with her mom.', 'Her mom goes there every week to buy some fresh fish.', 'Yuna goes along to get warm rice cakes at a small shop.', 'So every Saturday morning, Yuna goes to the market ______.'],
 ch={0: 'to buy some fresh fish', 1: 'to get warm rice cakes', 2: 'to meet her school friends', 3: 'to sell her old toys', 4: 'to visit her grandma'})
I[4] = dict(S=['Every Wednesday, Siwoo has a free hour after his last class.',
 'On sunny Wednesdays, he plays soccer outside with his classmates.',
 'On rainy Wednesdays, he stays in the art room and draws funny pictures.',
 'So on rainy Wednesdays, Siwoo usually spends his free hour ______.'],
 ch={0: 'reading comic books', 1: 'playing soccer outside', 2: 'doing his math homework', 3: 'drawing funny pictures', 4: 'practicing the piano'})
I[5] = dict(S=["Hana's parents have a simple rule for TV and games at home.",
 'On school nights, she can watch one TV show after her homework.',
 "On Friday nights, she can play computer games until ten o'clock.",
 'So after her homework on school nights, Hana can ______.'],
 ch={0: 'read a comic book', 1: 'watch one TV show', 2: 'eat some ice cream', 3: 'play computer games', 4: 'call her best friend'})
I[6] = dict(S=["Everyone in Junho's family has a small job at home each week.",
 'Junho takes out the trash for the whole family on Thursday nights.',
 'His older sister Eunji does the laundry on Saturday mornings.',
 "So every week, Junho takes out the family's trash ______."],
 ch={0: 'on Thursday nights', 1: 'on Saturday mornings', 2: 'on Monday mornings', 3: 'on Sunday evenings', 4: 'on Friday afternoons'})
I[7] = dict(S=['Every spring, Grandpa Yoon plants tomatoes and peppers at his house.', 'He grows the tomatoes in big pots on the flat roof.', 'He keeps the peppers in a long box by the back door.', 'So every summer, Grandpa Yoon picks fresh red tomatoes ______.'],
 ch={0: 'in the front yard', 1: 'by the back door', 2: 'on the flat roof', 3: 'behind the garage', 4: 'next to the gate'})
I[8] = dict(S=["Once a month, Taeyang's family visits Grandma in a small town.",
 "In the summer months, they drive there in Dad's old car.",
 'In winter, the family rides there on the slow train instead.',
 "So in winter, Taeyang's family travels to Grandma's town ______."],
 ch={0: "in Dad's old car", 1: 'in a rental car', 2: 'on the express bus', 3: 'on the slow train', 4: "in Uncle's truck"})
I[9] = dict(S=['Yeji gets to school at half past seven every morning.', 'Many boys in her class come early to play table tennis.', 'Yeji comes early to study English words at her quiet desk.', 'So every morning, Yeji arrives at her school early ______.'],
 ch={0: 'to eat a quick breakfast', 1: 'to play table tennis', 2: 'to clean the classroom', 3: 'to study English words', 4: 'to talk with her friends'})
I[10] = dict(S=["Jun's cat Nabi sleeps at the end of his bed every night.",
 'On school days, Nabi wakes Jun up at six by sitting on his chest.',
 'On weekends, his little sister wakes him up by pulling his blanket.',
 "So on school days, the cat starts Jun's morning by ______."],
 ch={0: 'licking his nose softly', 1: 'pulling his blanket', 2: 'meowing next to his ear', 3: 'biting his toes', 4: 'sitting on his chest'})
I[11] = dict(S=['Every Tuesday, Minsu has a taekwondo class at a gym near his school.',
 'At the end of each class, his teacher lets him kick the big black bag.',
 'The younger children stretch on the mats at that time.',
 'So at the end of each class, Minsu can ______.'],
 ch={0: 'stretch on the mats', 1: 'kick the big black bag', 2: 'break a wooden board', 3: 'choose the next game', 4: 'run around the gym'})
I[12] = dict(S=["Junho's family puts cans, bottles and paper into three boxes in the kitchen.",
 'His older sister takes the food waste out on Friday mornings.',
 'Junho carries the full boxes down to the street on Tuesday evenings.',
 'So every week, Junho takes the three boxes outside ______.'],
 ch={0: 'on Friday mornings', 1: 'on Sunday afternoons', 2: 'on Saturday mornings', 3: 'after dinner on Mondays', 4: 'on Tuesday evenings'})
I[13] = dict(S=["Sunwoo's dad comes home from work at about seven every evening.",
 'At the door, he always puts his car keys in the blue bowl.',
 'Then his phone goes on the kitchen shelf next to the radio.',
 "So every evening after work, Sunwoo's dad leaves his car keys ______."],
 ch={0: 'in the blue bowl', 1: 'on the kitchen shelf', 2: 'in his coat pocket', 3: 'on the shoe rack', 4: 'in a desk drawer'})
I[14] = dict(S=['Seojin lives about two kilometers away from her middle school.',
 "On most mornings, she rides to school on her brother's old bike.",
 'On rainy days, she gets there on the green city bus instead.',
 'So on most mornings, Seojin makes the trip to school ______.'],
 ch={0: "on her brother's old bike", 1: 'on the green city bus', 2: "in her mother's small car", 3: 'on the yellow school bus', 4: 'on foot with her friends'})
I[15] = dict(S=['Every morning at seven, Grandma Yoon walks to the small park near her house.',
 'She goes there early to feed the birds by the pond.',
 'In the afternoon, she goes back there to meet her friends.',
 'So at seven every morning, Grandma Yoon goes to the park ______.'],
 ch={0: 'to meet her friends', 1: 'to feed the birds', 2: 'to walk her dog', 3: 'to pick up trash', 4: 'to read the paper'})
I[16] = dict(S=["Every Saturday morning, Hojin's dad makes pancakes for the whole family.",
 "Hojin's little sister sets the table with forks, plates and cups.",
 'In the kitchen, Hojin always helps his dad by cracking the eggs.',
 'So every Saturday morning, Hojin helps with the pancakes by ______.'],
 ch={0: 'mixing the flour', 1: 'setting the table', 2: 'cracking the eggs', 3: 'washing the big bowl', 4: 'pouring in the milk'})
I[17] = dict(S=['Jisu goes to the school newspaper club every Wednesday after lunch.',
 'Her best friend Mina writes the sports news for the back page.',
 'In the club, Jisu always takes the pictures for each new school paper.',
 'So at every Wednesday meeting, the club leader lets Jisu ______.'],
 ch={0: 'write the sports news', 1: 'check the spelling', 2: 'draw the cartoons', 3: 'pick the top stories', 4: 'take the pictures'})
I[18] = dict(S=["Hana's family has an old piano in their small living room.",
 'On school days, Hana practices on it for an hour after dinner.',
 'On Sundays, she plays the piano for her grandmother before lunch.',
 'So from Monday to Friday, Hana sits at the old piano ______.'],
 ch={0: 'after dinner', 1: 'before lunch', 2: 'before school', 3: 'at lunchtime', 4: 'in the morning'})
I[19] = dict(S=['Every Sunday afternoon, Jaemin plays a long game of chess with his grandpa.',
 "In warm weather, they play on the front steps of Grandpa's house.",
 'On cold days, they play in the warm kitchen instead.',
 'So on warm Sundays, Jaemin and his grandpa play chess ______.'],
 ch={0: 'in the warm kitchen', 1: 'under a big tree', 2: 'on the front steps', 3: 'on a park bench', 4: 'in the living room'})
I[20] = dict(S=['Every evening after dinner, Junho washes the dishes in the family kitchen.',
 'On weekends, he does this job with his younger brother Minu.',
 'On school days, he works at the sink with his older sister.',
 'So on school days, Junho cleans the dinner dishes ______.'],
 ch={0: 'with his younger brother', 1: 'with his grandmother', 2: 'with his little cousin', 3: 'with his mom and dad', 4: 'with his older sister'})
I[21] = dict(S=['On school days, Minseo gets to her classroom at half past seven.', 'She always comes early to open the windows for some fresh air.', 'Her friend Jia comes at eight to feed the class fish.', 'So on school days, Minseo gets to school early ______.'],
 ch={0: 'to feed the class fish', 1: 'to open the windows', 2: 'to clean the blackboard', 3: 'to study for a test', 4: 'to finish her homework'})
I[22] = dict(S=["Every summer, Siyeon's family drives to her uncle's farm in Jeonju.",
 'On the way there, she spends the time playing word games with her dad.',
 'On the way home, she sleeps in her seat most of the time.',
 'So on the drive to Jeonju, Siyeon spends most of her time ______.'],
 ch={0: 'playing word games', 1: 'sleeping in her seat', 2: 'reading comic books', 3: 'watching old movies', 4: 'singing with her mom'})
I[23] = dict(S=["Every Sunday morning, Yena's dad makes pancakes for the whole family.",
 'Her little brother Jun helps him set the kitchen table with forks.',
 'Yena always helps her dad mix the flour and milk in a big bowl.',
 'So on Sunday mornings at home, Yena helps her dad ______.'],
 ch={0: 'set the kitchen table', 1: 'cut up the strawberries', 2: 'mix the flour and milk', 3: 'wash the frying pan', 4: 'pour the orange juice'})
I[24] = dict(S=['Mingyu takes his big dog Choco for a walk around the park every day.',
 'On weekends, the two of them start their walk at nine in the morning.',
 'On school days, Mingyu takes Choco out at seven in the evening.',
 'So on school days, Mingyu walks his dog Choco ______.'],
 ch={0: 'at six in the morning', 1: 'at nine in the morning', 2: 'at four in the afternoon', 3: 'at ten in the evening', 4: 'at seven in the evening'})
I[25] = dict(S=['Every day, Siwoo practices his new trumpet for about thirty minutes.',
 'On Saturday mornings, he plays it at the music school with his band.',
 'On weekday evenings, he plays it in the living room after dinner.',
 'So on weekday evenings, Siwoo practices his new trumpet ______.'],
 ch={0: 'at the music school', 1: 'in his small bedroom', 2: 'in the empty garage', 3: 'in the city park', 4: 'in the living room'})
I[26] = dict(S=['Doyun goes to taekwondo class at a gym across town three times a week.',
 'On Mondays and Wednesdays, he rides there on his old bicycle.',
 "On Fridays, he gets there quickly in his mother's car.",
 'So on Mondays and Wednesdays, Doyun goes to taekwondo ______.'],
 ch={0: "in his mother's car", 1: 'on his old bicycle', 2: 'on the city bus', 3: 'on the subway train', 4: 'on his skateboard'})
I[27] = dict(S=["Every year, Bora's whole family has dinner together on Grandpa's birthday.",
 'Bora always gives him a pair of warm socks for the winter.',
 'Her parents always give him a box of green tea at dinner.',
 "So on Grandpa's birthday each year, Bora gives him ______."],
 ch={0: 'a box of green tea', 1: 'a basket of red apples', 2: 'a big family photo', 3: 'a pair of warm socks', 4: 'a long red scarf'})
I[28] = dict(S=["Hyunwoo's family often buys food at the small bakery near their apartment.",
 'On Sundays, his mother buys a strawberry cake at the same bakery.',
 'Every Saturday morning, Hyunwoo buys a bag of milk bread there for breakfast.',
 'So every Saturday morning, Hyunwoo buys ______ at the bakery.'],
 ch={0: 'a strawberry cake', 1: 'a box of butter cookies', 2: 'two chocolate donuts', 3: 'a bag of milk bread', 4: 'a few cheese buns'})
I[29] = dict(S=['Every Saturday afternoon, Yejin takes a drawing class at the art center.',
 'At home on Sundays, she draws her little gray cat on the sofa.',
 'In her Saturday class, the students always draw a bowl of fresh fruit.',
 'So every Saturday at the art center, Yejin draws ______.'],
 ch={0: 'her little gray cat', 1: 'a vase of yellow roses', 2: 'the trees in the park', 3: 'a bowl of fresh fruit', 4: 'a tall glass bottle'})
