# -*- coding: utf-8 -*-
# 42번(장문 속 낱말) 해설 두텁게 — 공통 도우미 (레벨9 때(182번)의 것을 223번에 다시 만들고 레벨 인자를 닮)
#   mk = maker(E, lv='8')
#   mk(n, 답 기호('a'~'e'), [뜻풀이 5개], [바꾸어 넣을 낱말], [적용 네 줄], 헷갈리는 곳, [낱말별 설명 5개])
# - 낱말별 해설의 머리("(a) word(뜻): 문맥에 맞습니다." / "(c)가 정답입니다. word(뜻):")는 자동
# - 답 기호가 문항과 다르거나, 3)이 「(x)가 문맥에 맞지 않습니다.」로 시작하지 않거나, 2)에 네 낱말이 빠졌거나 답 낱말이 들어가면 멈춤
# - 원고의 «…»는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜(밑줄 기호 (a)~(e)는 빼고 옮길 것)
import re, sys; sys.path.insert(0, '.')
from lib import load as _load
_tb = _load()[1]
KEYS = 'abcde'
ALT = {}   # (레벨, 몇째-1) → 바꾸어 넣을 낱말들(지문에 없는 영어) — zcheck42.py가 읽어 감
TIP = ("【문맥 속 낱말 요령】\n"
       "첫째, 밑줄 낱말만 보지 말고 그 낱말이 든 문장 전체를 읽습니다. 낱말 하나하나는 모두 그럴듯해 보이게 골라 놓았습니다.\n"
       "둘째, 글의 큰 흐름을 먼저 잡습니다. 글쓴이가 무엇을 문제로 보고 어느 쪽으로 가는지를 알면 낱말의 방향이 보입니다.\n"
       "셋째, 밑줄 낱말을 반대말로 바꾸어 봅니다. 반대말을 넣어야 앞뒤가 통하면 그 낱말이 답입니다. 답은 거의 언제나 방향이 거꾸로 된 낱말입니다.\n"
       "넷째, 근거는 가까이에 있습니다. because, since, so, therefore, but 같은 말과 쌍점(:) 뒤의 풀이, 바로 뒤의 보기와 맞는지 확인합니다.")
# 297번: 레벨1~3은 해설의 말끝이 「~어요」(README) — 요령·머리말을 그 말끝으로
TIP3 = ("【문맥 속 낱말 요령】\n"
        "첫째, 밑줄 낱말만 보지 말고 그 낱말이 든 문장 전체를 읽어요. 낱말 하나하나는 모두 그럴듯해 보이게 골라 놓았어요.\n"
        "둘째, 글의 큰 흐름을 먼저 잡아요. 글쓴이가 무엇을 문제로 보고 어느 쪽으로 가는지를 알면 낱말의 방향이 보여요.\n"
        "셋째, 밑줄 낱말을 반대말로 바꾸어 봐요. 반대말을 넣어야 앞뒤가 통하면 그 낱말이 답이에요. 답은 거의 언제나 방향이 거꾸로 된 낱말이에요.\n"
        "넷째, 근거는 가까이에 있어요. because, since, so, therefore, but 같은 말과 쌍점(:) 뒤의 풀이, 바로 뒤의 보기와 맞는지 확인해요.")
def low(lv): return lv in ('1', '2', '3')
HEADS = ('1) 글의 흐름:', '2) 낱말마다 확인:', '3) 어긋나는 낱말:', '4) 바꾸어 읽기:')
def words(text):
    """밑줄 낱말 다섯: (a) 바로 뒤의 낱말 하나(붙임표 포함)"""
    w = dict(re.findall(r'\(([a-e])\)([A-Za-z\-]+)', text)); assert len(w) == 5, '밑줄 다섯'
    return [w[k] for k in KEYS]
def plain(text): return re.sub(r'\([a-e]\)', '', text)
def _q(x): return x.replace('«', '"').replace('»', '"')
def maker(E, lv='8'):
    def mk(n, ans, gloss, alt, steps, confuse, cn, wfix=None):
        # wfix: 같은 수정안에서 밑줄 낱말 자체를 바꾸는 문항이면 {'b': '새 낱말'}처럼 알려 줌(해설 머리에 새 낱말이 들어가게)
        it = _tb['42'][lv][n]; a = it['answer']; W = words(it['text'])
        for kk, vv in (wfix or {}).items(): W[KEYS.index(kk)] = vv
        assert KEYS[a] == ans, ('원고의 답 기호가 문항과 다름', n, KEYS[a], ans)
        assert len(gloss) == 5 and len(cn) == 5 and len(steps) == 4 and alt, n
        assert all(s.startswith(h) for s, h in zip(steps, HEADS)), (n, '적용 줄의 머리말')
        assert steps[2].startswith(('3) 어긋나는 낱말: (%s)가 문맥에 맞지 않아요. ' if low(lv) else '3) 어긋나는 낱말: (%s)가 문맥에 맞지 않습니다. ') % ans), (n, '3)의 첫머리')
        for k in range(5):
            tag = '(%s) %s(%s):' % (KEYS[k], W[k], gloss[k])
            assert (tag in steps[1]) == (k != a), (n, k, '2)에 네 낱말이 다 있고 답 낱말은 없어야 함', tag)
        out = {}
        for k, body in enumerate(cn):
            assert '정답' not in body, (n, k, '설명에 "정답"이라는 말')
            assert not re.search(r'\([a-e]\)', body), (n, k, '낱말 해설에 다른 기호')
            if low(lv): head = ('(%s)가 정답이에요. %s(%s): ' if k == a else '(%s) %s(%s): 문맥에 맞아요. ') % (KEYS[k], W[k], gloss[k])
            else: head = ('(%s)가 정답입니다. %s(%s): ' if k == a else '(%s) %s(%s): 문맥에 맞습니다. ') % (KEYS[k], W[k], gloss[k])
            out[k] = head + _q(body)
        assert ('42', lv, n) not in E, (n, '같은 문항을 두 번 씀')
        ALT[(lv, n)] = list(alt)
        E[('42', lv, n)] = {'walk': (TIP3 if low(lv) else TIP) + "\n\n【이 문제에 적용】\n" + "\n".join(_q(x) for x in steps) + "\n\n【헷갈리는 곳】\n" + _q(confuse), 'cn': out}
    return mk
