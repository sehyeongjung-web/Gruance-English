# -*- coding: utf-8 -*-
# 343번: 30번(어휘) 레벨1 뒤 절반 — 다섯 문장(문장당 10~15낱말 · 단문) · 문맥에 맞지 않는 낱말 하나. 정답 번호는 바탕 그대로, 지문·해석·풀이·해설·올바른 말(correctWord)을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z30rw import maker
rw = maker(E)

# 16번째
rw(15,
   ['Mia is always ①rude to her teachers and classmates at school.',
 'She says please and ②thank you to everyone in the hall.',
 'Her classmates ③like her warm and friendly smile very much.',
 'She always ④holds the door open for people behind her.',
 'Everyone at her school ⑤respects her for her very good manners.'],
   'polite',
   ['미아는 학교에서 선생님과 반 친구들에게 늘 무례하다(→ 예의 바르다).', "그녀는 복도에 있는 모든 사람에게 '부탁해요'와 '고마워요'라고 말한다.", '반 친구들은 그녀의 따뜻하고 다정한 미소를 아주 좋아한다.', '그녀는 뒤에 오는 사람들을 위해 늘 문을 열어 잡아 준다.', '학교의 모든 사람이 그녀의 아주 좋은 예절 때문에 그녀를 존경한다.'],
   ['무례한', '고맙다고 말하다', '좋아한다', '잡아 준다', '존경한다'],
   ["'부탁해요, 고마워요'라고 말하고 좋은 예절로 존경받는다고 했으니 무례하다는 것은 반대예요. 원래는 polite(예의 바른)가 알맞아요.",
 "'부탁해요'와 '고마워요'를 말하는 예의 바른 모습이라 맞아요.",
 '다정한 미소를 반 친구들이 좋아한다는 내용이라 맞아요.',
 '뒷사람을 위해 문을 잡아 주는 친절한 행동이라 맞아요.',
 '예절이 바르니 학교 사람들이 존경한다는 내용이라 맞아요.'],
   'rude 무례한 / polite 예의 바른 / manners 예절 / respect 존경하다')

# 17번째
rw(16,
   ['The town library is ①closed from morning to night every day.',
 'Many children ②visit it to read comics and storybooks after school.',
 'Students may ③borrow up to five books for two weeks.',
 'A kind young librarian ④helps them find the right book.',
 'The room is ⑤quiet, with soft light and warm chairs.'],
   'open',
   ['마을 도서관은 날마다 아침부터 밤까지 문이 닫혀(→ 열려) 있다.', '많은 아이가 방과 후에 만화와 이야기책을 읽으러 그곳을 찾는다.', '학생들은 책을 다섯 권까지 두 주 동안 빌릴 수 있다.', '친절한 젊은 사서가 아이들이 알맞은 책을 찾도록 도와준다.', '그곳은 부드러운 불빛과 따뜻한 의자가 있는 조용한 방이다.'],
   ['닫힌', '찾아간다', '빌린다', '도와준다', '조용한'],
   ['많은 아이가 도서관을 찾아 책을 빌린다고 했으니 하루 종일 닫혀 있다는 것은 앞뒤가 안 맞아요. 원래는 open(열려 있는)이 알맞아요.', '아이들이 방과 후에 도서관을 찾는다는 내용이라 맞아요.', '도서관에서 책을 빌리는 내용이라 맞아요.', '사서가 아이들이 책을 찾도록 돕는 모습이라 맞아요.', '도서관이 조용하다는 내용이라 맞아요.'],
   'library 도서관 / comic 만화 / borrow 빌리다 / librarian 사서')

# 18번째
rw(17,
   ['My grandfather is still very ①weak at the age of eighty.',
 'Every day he ②carries heavy boxes of fruit to the market.',
 'He ③walks two miles each morning on the steep hill.',
 'Young workers at the market ④admire his energy and his kind heart.',
 'His doctor finds him ⑤healthier than many people half his age.'],
   'strong',
   ['우리 할아버지는 여든 살에도 여전히 아주 약하시다(→ 튼튼하시다).', '날마다 할아버지는 시장까지 과일이 든 무거운 상자를 나르신다.', '아침마다 가파른 언덕에서 2마일을 걸으신다.', '시장의 젊은 일꾼들은 할아버지의 활력과 따뜻한 마음에 감탄한다.', '의사는 할아버지가 할아버지 나이의 절반쯤 되는 많은 사람보다 더 건강하다고 본다.'],
   ['약한', '나른다', '걸으신다', '감탄한다', '더 건강한'],
   ['여든 살인데도 무거운 상자를 나르고 먼 길을 걷는다고 했으니 약하다는 것은 어울리지 않아요. 원래는 strong(튼튼한)이 알맞아요.',
 '시장까지 과일 상자를 나른다는 내용이라 맞아요.',
 '아침마다 가파른 언덕을 걷는다는 내용이라 맞아요.',
 '젊은 일꾼들이 할아버지의 활력에 감탄한다는 내용이라 맞아요.',
 '튼튼하고 활력이 넘치니 더 건강하다는 내용이라 맞아요.'],
   'steep 가파른 / admire 감탄하다 / energy 기운, 활력 / healthy 건강한')

# 19번째
rw(18,
   ['Every Friday, Dad ①cooks a big dinner in our small kitchen.',
 'Mom ②sets the table with clean plates, forks, and cups.',
 'Our old brown dog ③waits quietly near the kitchen door.',
 "At seven o'clock, we all ④eat dinner together at the table.",
 "At eight o'clock, Ben and I wash the dishes ⑤before dinner."],
   'after',
   ['금요일마다 아빠는 우리 작은 부엌에서 푸짐한 저녁을 요리하신다.', '엄마는 깨끗한 접시, 포크, 컵으로 식탁을 차리신다.', '우리의 늙은 갈색 개는 부엌문 근처에서 조용히 기다린다.', '일곱 시에 우리는 모두 식탁에서 함께 저녁을 먹는다.', '여덟 시에 벤과 나는 저녁 식사 전에(→ 후에) 설거지를 한다.'],
   ['요리한다', '차린다', '기다린다', '먹는다', '전에'],
   ['금요일마다 아빠가 저녁을 요리한다는 내용이라 맞아요.', '식탁을 차리는 엄마의 모습이라 맞아요.', '개가 부엌문 근처에서 얌전히 기다리는 모습이라 맞아요.', '일곱 시에 모두 모여 저녁을 먹는다는 내용이라 맞아요.', '저녁을 일곱 시에 먹었으니 여덟 시의 설거지는 식사 전이 아니라 후예요. 원래는 after(후에)가 알맞아요.'],
   'set the table 식탁을 차리다 / kitchen 부엌 / fork 포크 / wash the dishes 설거지하다')

# 20번째
rw(19,
   ['After the big storm, all the streets in town were ①dry.',
 'Big ②puddles stood at every corner near the old park.',
 'Happy children ③jumped in them with their bright yellow rain boots.',
 'Fast cars ④splashed cold water across the wide sidewalk again.',
 'By noon, the warm yellow sun ⑤appeared in the clear sky.'],
   'wet',
   ['큰 폭풍우가 지난 뒤 마을의 모든 길은 말라(→ 젖어) 있었다.', '오래된 공원 근처 모든 모퉁이에 큰 물웅덩이가 고여 있었다.', '기분 좋은 아이들이 밝은 노란색 장화를 신고 웅덩이에서 뛰었다.', '빠른 자동차들이 넓은 인도 위로 차가운 물을 다시 튀겼다.', '정오쯤에는 따뜻한 노란 해가 맑은 하늘에 나타났다.'],
   ['마른', '물웅덩이', '뛰었다', '튀겼다', '나타났다'],
   ['큰 폭풍우 뒤에 물웅덩이가 생기고 장화를 신었다고 했으니 길이 말랐다는 것은 반대예요. 원래는 wet(젖은)이 알맞아요.',
 '비가 온 뒤라 모퉁이마다 물웅덩이가 생기는 내용이라 맞아요.',
 '장화를 신고 웅덩이에서 뛰는 아이들의 모습이라 맞아요.',
 '자동차가 지나가며 물을 튀기는 모습이라 맞아요.',
 '폭풍우가 그친 뒤 해가 나타나는 장면이라 맞아요.'],
   'storm 폭풍우 / puddle 물웅덩이 / splash (물을) 튀기다 / sidewalk 인도')

# 21번째
rw(20,
   ['The fresh lemon tea tasted very ①sweet to Jake at first.',
 'His whole face ②twisted into a funny shape after one sip.',
 'His little sister ③laughed at his funny face from the door.',
 'Jake ④added two big spoons of sugar to the cup.',
 'Now the warm tea tasted ⑤much better to him at last.'],
   'sour',
   ['신선한 레몬차는 처음에 제이크에게 아주 달게(→ 시게) 느껴졌다.', '한 모금 마시자 그의 얼굴 전체가 우스꽝스러운 모양으로 일그러졌다.', '제이크의 여동생은 문가에서 그의 우스운 얼굴을 보고 웃었다.', '제이크는 컵에 설탕을 큰 숟가락으로 두 숟가락 넣었다.', '이제 따뜻한 차는 마침내 그에게 훨씬 맛있게 느껴졌다.'],
   ['단', '일그러졌다', '웃었다', '넣었다', '훨씬'],
   ['얼굴이 일그러지고 설탕을 넣었다고 했으니 달다는 것은 반대예요. 원래는 sour(시게)가 알맞아요.', '신 차를 마시고 얼굴이 일그러지는 모습이라 맞아요.', '동생이 우스운 얼굴을 보고 웃는 장면이라 맞아요.', '신맛을 줄이려고 설탕을 넣는 행동이라 맞아요.', '설탕을 넣었으니 맛이 훨씬 좋아졌다는 내용이라 맞아요.'],
   'lemon 레몬 / sip 한 모금 / sour (맛이) 신 / spoon 숟가락')

# 22번째
rw(21,
   ['Mr. Park gave his class a ①short math test on Monday.',
 'The test questions were ②simple for everyone in the room.',
 'Most students ③finished the whole page in only ten minutes.',
 'Mr. Park ④smiled at the correct answers on the pages.',
 'In the end, the whole class called the short math test ⑤difficult.'],
   'easy',
   ['박 선생님은 월요일에 반 학생들에게 짧은 수학 시험을 내셨다.', '시험 문제는 교실에 있는 모두에게 간단했다.', '대부분의 학생은 단 10분 만에 한 쪽 전체를 다 풀었다.', '박 선생님은 시험지의 정답들을 보고 미소를 지으셨다.', '결국 반 전체가 그 짧은 수학 시험을 어렵다고(→ 쉽다고) 말했다.'],
   ['짧은', '간단한', '끝냈다', '미소 지었다', '어려운'],
   ['시험이 짧았다는 내용이라 맞아요.', '문제가 간단했다는 내용이라 맞아요.', '10분 만에 한 쪽을 다 풀었다는 내용이라 맞아요.', '맞게 푼 답이 많아 선생님이 미소 짓는 장면이라 맞아요.', '문제가 간단하고 금방 끝냈으니 어렵다는 것은 앞뒤가 안 맞아요. 원래는 easy(쉬운)가 알맞아요.'],
   'test 시험 / simple 간단한 / correct 맞는, 정확한 / difficult 어려운')

# 23번째
rw(22,
   ['The house was ①dark and quiet at midnight on Saturday.',
 'The baby ②slept in her small bed by the window.',
 'Dad ③turned off the old television in the living room.',
 'Mom ④closed the window to keep out the cold air.',
 'Soon everyone in the whole house was ⑤awake under warm blankets.'],
   'asleep',
   ['토요일 한밤중에 집은 어둡고 조용했다.', '아기는 창가의 작은 침대에서 잠을 잤다.', '아빠는 거실의 낡은 텔레비전을 껐다.', '엄마는 찬 공기를 막으려고 창문을 닫았다.', '곧 온 집 안의 모두가 따뜻한 이불 속에서 깨어(→ 잠들어) 있었다.'],
   ['어두운', '잤다', '껐다', '닫았다', '깨어 있는'],
   ['한밤중의 집이 어둡고 조용하다는 내용이라 맞아요.', '한밤중에 아기가 자는 모습이라 맞아요.', '자려고 텔레비전을 끄는 행동이라 맞아요.', '찬 공기를 막으려고 창문을 닫는 행동이라 맞아요.', '한밤중에 어둡고 조용하고 아기도 잤으니 모두 깨어 있다는 것은 반대예요. 원래는 asleep(잠들어 있는)이 알맞아요.'],
   'midnight 한밤중 / living room 거실 / blanket 이불, 담요 / asleep 잠들어 있는')

# 24번째
rw(23,
   ["After the big family lunch, Nina's plate was ①empty again.",
 'Her little brother ②ate three bowls of hot rice and soup.',
 "Their proud father ③laughed at the little boy's big appetite.",
 'At the end, they ④drank cold barley tea from tall glasses.',
 'Both children felt ⑤hungry after such a big and tasty lunch.'],
   'full',
   ['푸짐한 가족 점심을 먹은 뒤 니나의 접시는 다시 비어 있었다.', '니나의 남동생은 뜨거운 밥과 국을 세 그릇이나 먹었다.', '그들의 자랑스러운 아버지는 어린 아들의 대단한 식욕을 보고 웃으셨다.', '마지막에 그들은 긴 잔으로 차가운 보리차를 마셨다.', '두 아이는 그렇게 푸짐하고 맛있는 점심을 먹은 뒤 배가 고팠다(→ 불렀다).'],
   ['빈', '먹었다', '웃었다', '마셨다', '배고픈'],
   ['점심을 다 먹어서 접시가 비었다는 내용이라 맞아요.', '남동생이 세 그릇이나 먹는 모습이라 맞아요.', '아버지가 아들의 큰 식욕을 보고 웃는 장면이라 맞아요.', '식사 끝에 차가운 보리차를 마시는 내용이라 맞아요.', '푸짐한 점심을 먹고 접시도 비웠으니 배고프다는 것은 반대예요. 원래는 full(배부른)이 알맞아요.'],
   'appetite 식욕 / barley tea 보리차 / bowl 그릇 / empty 빈')

# 25번째
rw(24,
   ['A rainy road can be very ①slippery for people on bicycles.',
 'Thin bicycle tires ②slide easily on the cold wet ground.',
 'Fast riding in the rain is ③safe for everyone on the road.',
 'Smart riders ④slow down before every sharp curve in town.',
 'Bright yellow jackets ⑤help drivers see people on bicycles at dusk.'],
   'dangerous',
   ['비 오는 길은 자전거를 타는 사람들에게 매우 미끄러울 수 있다.',
 '얇은 자전거 타이어는 차갑고 젖은 땅에서 쉽게 미끄러진다.',
 '빗속에서 빠르게 달리는 것은 길 위의 모두에게 안전하다(→ 위험하다).',
 '현명한 자전거 타는 사람들은 시내의 모든 급한 커브 앞에서 속도를 줄인다.',
 '밝은 노란색 재킷은 해 질 무렵 운전자가 자전거 타는 사람을 보도록 돕는다.'],
   ['미끄러운', '미끄러진다', '안전한', '줄인다', '돕는다'],
   ['비 오는 길이 미끄럽다는 내용이라 맞아요.',
 '얇은 타이어가 젖은 땅에서 미끄러진다는 내용이라 맞아요.',
 '길이 미끄러운데 빠르게 달리면 위험하니 안전하다는 것은 어울리지 않아요. 원래는 dangerous(위험한)가 알맞아요.',
 '미끄러운 길이라 커브 앞에서 속도를 줄이는 행동이라 맞아요.',
 '밝은 재킷이 눈에 잘 띄게 해 준다는 내용이라 맞아요.'],
   'slippery 미끄러운 / tire 타이어 / curve 커브, 굽은 길 / dusk 해 질 무렵')

# 26번째
rw(25,
   ['An old basement is a good place to keep ①vegetables fresh.',
 'The ground around the thick walls ②cools the air inside the room.',
 'In summer, a basement is much ③warmer than the rooms upstairs.',
 'Potatoes and onions ④last for many months in the dark.',
 'Apples on the lower shelves ⑤stay crisp and sweet for many weeks.'],
   'cooler',
   ['오래된 지하실은 채소를 신선하게 보관하기 좋은 곳이다.', '두꺼운 벽 둘레의 땅이 방 안 공기를 시원하게 해 준다.', '여름에 지하실은 위층 방보다 훨씬 더 따뜻하다(→ 시원하다).', '감자와 양파는 어두운 곳에서 여러 달 동안 오래간다.', '아래쪽 선반의 사과는 여러 주 동안 아삭하고 달콤하게 유지된다.'],
   ['채소', '시원하게 한다', '더 따뜻한', '오래간다', '유지된다'],
   ['지하실에 채소를 보관한다는 내용이라 맞아요.',
 '땅이 벽 둘레를 감싸 공기를 시원하게 한다는 내용이라 맞아요.',
 '땅이 공기를 시원하게 하므로 지하실이 위층보다 따뜻하다는 것은 반대예요. 원래는 cooler(더 시원한)가 알맞아요.',
 '시원한 어둠 속에서 감자와 양파가 오래 간다는 내용이라 맞아요.',
 '시원한 곳에서 사과가 오래 신선하다는 내용이라 맞아요.'],
   'basement 지하실 / vegetable 채소 / upstairs 위층 / crisp 아삭한')

# 27번째
rw(26,
   ["Jin's mother loves to keep the ①kitchen neat and tidy.",
 'She always ②wipes the long wooden table after every meal.',
 'The sink in her kitchen is always ③dirty, with no plates in it.',
 'Every spoon and cup ④shines on the drying rack by the window.',
 'Visitors always ⑤praise her kitchen for its fresh smell and bright light.'],
   'clean',
   ['진의 어머니는 부엌을 깔끔하고 정돈된 상태로 유지하는 것을 아주 좋아하신다.', '어머니는 식사 후마다 긴 나무 식탁을 늘 닦으신다.', '어머니 부엌의 싱크대는 늘 더럽고(→ 깨끗하고) 그 안에는 접시가 하나도 없다.', '모든 숟가락과 컵이 창가의 건조대 위에서 반짝인다.', '손님들은 어머니의 부엌을 상쾌한 냄새와 밝은 빛 때문에 늘 칭찬한다.'],
   ['부엌', '닦는다', '더러운', '반짝인다', '칭찬한다'],
   ['부엌을 깔끔하게 유지하는 것을 좋아한다는 내용이라 맞아요.',
 '식사 후마다 식탁을 닦는 깔끔한 습관이라 맞아요.',
 '깔끔한 부엌에 싱크대 안에 접시도 하나 없다고 했으니 싱크대가 더럽다는 것은 반대예요. 원래는 clean(깨끗한)이 알맞아요.',
 '숟가락과 컵이 깨끗해서 반짝인다는 내용이라 맞아요.',
 '깨끗한 부엌을 손님들이 칭찬하는 장면이라 맞아요.'],
   'tidy 정돈된 / wipe 닦다 / sink 싱크대 / drying rack 건조대')

# 28번째
rw(27,
   ['Our city has built many new ①bike lanes since last year.',
 'More people ②ride to work by bicycle in our city these days.',
 'As a result, the number of cars on the main road ③increased.',
 'The air in the middle of downtown ④feels much cleaner than before.',
 'Many shop owners ⑤enjoy the quiet streets in front of their stores.'],
   'dropped',
   ['우리 도시는 작년부터 새 자전거 도로를 많이 만들었다.', '요즘 우리 도시에서는 더 많은 사람이 자전거로 출근한다.', '그 결과 큰길의 자동차 수는 늘었다(→ 줄었다).', '시내 중심의 공기는 예전보다 훨씬 깨끗하게 느껴진다.', '많은 가게 주인이 가게 앞의 조용한 거리를 즐긴다.'],
   ['자전거', '타고 간다', '늘었다', '느껴진다', '즐긴다'],
   ['자전거 도로를 많이 만들었다는 내용이라 맞아요.',
 '자전거 도로가 생겨 자전거로 출근하는 사람이 늘었다는 내용이라 맞아요.',
 '자전거를 타는 사람이 늘었고 뒤 문장에서 공기가 깨끗해지고 거리가 조용해졌다고 했으니 자동차 수가 늘었다는 것은 어울리지 않아요. 원래는 dropped(줄었다)가 알맞아요.',
 '시내 공기가 예전보다 깨끗하게 느껴진다는 내용이라 맞아요.',
 '가게 앞 거리가 조용해서 즐긴다는 내용이라 맞아요.'],
   'bike lane 자전거 도로 / downtown 시내 중심가 / shop owner 가게 주인 / drop 줄다, 떨어지다')

# 29번째
rw(28,
   ["The artist's studio has a ①huge window on the east wall.",
 'Warm morning sunlight ②pours through the glass on most days.',
 'The whole room is ③dim from early morning to noon.',
 'Paint colors ④look clear and strong in that room all year.',
 'Many young art students ⑤come to paint in that studio each week.'],
   'bright',
   ['그 화가의 작업실은 동쪽 벽에 커다란 창이 있다.', '따뜻한 아침 햇빛이 대부분의 날에 유리창으로 쏟아져 들어온다.', '작업실 전체가 이른 아침부터 정오까지 어둑하다(→ 환하다).', '물감 색이 그 방에서 일 년 내내 선명하고 강하게 보인다.', '많은 어린 미술 학생이 매주 그 작업실에 그림을 그리러 온다.'],
   ['커다란', '쏟아져 들어온다', '어둑한', '보인다', '온다'],
   ['작업실 동쪽 벽에 커다란 창이 있다는 내용이라 맞아요.', '아침 햇빛이 창으로 들어온다는 내용이라 맞아요.', '커다란 창으로 햇빛이 쏟아져 들어오니 어둑하다는 것은 반대예요. 원래는 bright(밝은)이 알맞아요.', '빛이 좋은 방이라 물감 색이 선명하게 보인다는 내용이라 맞아요.', '학생들이 그림을 그리러 매주 온다는 내용이라 맞아요.'],
   'studio 작업실 / pour 쏟아지다 / dim 어둑한 / paint 그림을 그리다')

# 30번째
rw(29,
   ['Kim has a ①great memory for the names of new people.',
 'He ②meets many new customers at the bank every week.',
 'He ③forgets each name even after a long, busy day.',
 'His friendly greeting makes those customers ④feel special every single week.',
 'Everyone in the neighborhood ⑤likes him for his kind heart.'],
   'remembers',
   ['김 씨는 새로운 사람들의 이름에 대한 뛰어난 기억력을 가졌다.', '그는 매주 은행에서 많은 새 손님을 만난다.', '그는 길고 바쁜 하루가 지난 뒤에도 모든 이름을 잊는다(→ 기억한다).', '그의 다정한 인사는 매주 그 손님들이 특별하다고 느끼게 해 준다.', '동네 사람 모두가 그의 따뜻한 마음 때문에 그를 좋아한다.'],
   ['뛰어난', '만난다', '잊는다', '느끼다', '좋아한다'],
   ['이름을 잘 기억하는 사람이라 뛰어난 기억력이 맞아요.',
 '은행에서 새로운 손님을 만나는 일이라 맞아요.',
 '첫 문장에서 이름을 잘 기억한다고 했고, 다정한 인사로 손님들이 특별하다고 느낀다고 했으니 이름을 잊는다는 것은 반대예요. 원래는 remembers(기억한다)가 알맞아요.',
 '다정한 인사로 손님들이 특별하다고 느낀다는 내용이라 맞아요.',
 '마음이 따뜻해서 사람들이 좋아한다는 내용이라 맞아요.'],
   'memory 기억력 / customer 손님 / greeting 인사 / forget 잊다')
