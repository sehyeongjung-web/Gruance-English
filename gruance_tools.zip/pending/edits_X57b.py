# -*- coding: utf-8 -*-
# 321번: 32번(빈칸 추론 — 낱말) 레벨1 — 레벨1 기준으로 다시 씀 (뒤 절반: 16~30번째)
# 꼴은 앞 절반(edits_X57a.py)과 같음: 네 문장 · 모두 단문 · 문장당 10~15낱말 · 빈칸은 넷째 문장
# 짝꿍 문장: 셋째 여덟 문항 · 둘째 다섯 문항(19·21·23·26·27번째) · 첫째 두 문항(20·25번째)
# 생각의 단계(추론축 레벨1): 글에 있는 말 하나를 그대로 확인
#   (다른 말로: sticky ← hold a fly like glue · colder ← (the air) stays a little warmer · water ← deep under the sea · away ← the far sky ·
#    grow ← a small green plant comes out · tighter ← pulls the skin harder · spins ← turns round and round · inside ← (a tube) full of water ·
#    faster ← three days / only one day · true ← the real top of the earth · air ← the wind · low ← just above the hills)
#   (그 낱말 그대로: rust · air(18번째) · grease — 과학 낱말이라 글 안에서 먼저 알려 줌)
# 글감(과학 사실)·정답 번호·정답 낱말은 그대로. **26번째만 글감을 바꿈**: 서리 맞은 잎 → 겨울의 수도관
#   (자연의 서리에서는 얼음이 세포 「밖」에 먼저 생기므로 옛 문항의 「세포 안의 얼음」은 사실과 다르고, 오답 outside·around가 오히려 사실에 가까웠음. 정답 inside와 선택지는 그대로)
# 과학: 독립 풀이에서 문항마다 사실을 확인받음 — 21번째는 2024년 연구(빛을 등 쪽에 두는 버릇)에 맞추어 씀, 28번째 자북과 북극은 지금 470km쯤,
#   30번째 「해가 머리 바로 위」는 우리나라에서 사실이 아니어서 「가장 높은 곳」으로, 29번째 빗 모양은 날개의 앞쪽 가장자리에만
# 선택지: 과학으로는 참이 되는 오답(20번째 ice · 19번째 heavier · 18번째 metal·glass · 22번째 die)과 엉뚱한 오답(sings · melts · pebbles · prey)을 바꿈 — 인계문서 321번에 표
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '32', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, ko, steps, traps, cn, ch=None):
    """문항을 통째로 다시 씀: 지문·해석·풀이·해설. 정답 번호는 그대로. ch = {자리: 새 선택지}(바꾸는 문항만)"""
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=bool(ch and ans in ch)); e = E.pop((T, LV, n))
    choices = list(_tb[T][LV][n]['choices'])
    for k, v in (ch or {}).items(): choices[k] = v
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(choices)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': choices, 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 16번째: 녹은 공기와 물이 함께 있어야 (답 rust) ----------
rw(15, 3, "An iron tool turns brown and rough after many days in the rain. This brown, rough coat on old iron is called rust. It needs both air and water on the iron at the same time. For this reason, only wet iron in the open air can ______.",
 "쇠로 된 도구는 여러 날 비를 맞으면 갈색으로 변하고 거칠어진다. 오래된 쇠에 생긴 이 갈색의 거친 껍질을 녹이라고 한다. 녹이 생기려면 쇠 위에 공기와 물이 둘 다 한꺼번에 있어야 한다. 이런 까닭으로, 바깥 공기 속의 젖은 쇠만 ______ 수 있다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «only wet iron in the open air can»(바깥 공기 속의 젖은 쇠만 ~할 수 있다). 'only'(오직 ~만)가 있어요. 젖은 쇠에만 일어나는 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «It needs both air and water on the iron at the same time.»(그것이 생기려면 쇠 위에 공기와 물이 둘 다 한꺼번에 있어야 한다.) 'It'(그것)은 바로 앞 문장의 'rust'(녹)예요. 'both air and water'(공기와 물 둘 다)가 단서예요.",
 "3) 둘째 문장 확인: «This brown, rough coat on old iron is called rust.»(오래된 쇠에 생긴 이 갈색의 거친 껍질을 녹이라고 한다.) 쇠에 생기는 갈색 껍질의 이름이 'rust'예요.",
 "4) 묶기: 공기와 물이 다 있는 쇠 = 바깥 공기 속의 젖은 쇠. 그런 쇠에만 녹이 생겨요. 녹이 생기는 것을 낱말 하나로 'rust'(녹슬다)라고 해요. 둘째 문장의 낱말이 그대로 답이에요."],
 "「부러지다」가 끌릴 수 있어요. 녹슨 도구는 약해져서 잘 부러지거든요. 하지만 글에는 부러진다는 말이 없어요. 글이 말한 것은 공기와 물이 함께 있어야 녹이 생긴다는 것이에요.",
 [("휘다", "지문에 없는 이야기예요. 쇠가 휜다는 말은 나오지 않아요."),
  ("부러지다", "지문에 없는 이야기예요. 쇠가 부러진다는 말은 나오지 않아요. 글이 말한 것은 녹이 생기는 까닭이에요."),
  ("빛나다", "글과 맞지 않아요. 비를 맞은 쇠는 갈색으로 변하고 거칠어진다고 했어요."),
  ("녹슬다", "셋째 문장 «It needs both air and water on the iron at the same time.»이 근거예요. 녹은 공기와 물이 함께 있어야 생기니, 바깥 공기 속의 젖은 쇠만 녹슬어요."),
  ("녹다", "지문에 없는 이야기예요. 쇠가 녹는 뜨거운 불은 나오지 않아요. 우리말로는 비슷하게 들리지만, 녹스는 것과 녹는 것은 다른 일이에요.")])

# ---------- 17번째: 거미줄의 끈적한 줄 (답 sticky) ----------
rw(16, 1, "A small fly usually cannot get away from a spider's web. The spider itself runs along the straight threads without any trouble. The round threads of the web hold a fly like glue. Only the round threads, not the straight ones, are ______.",
 "작은 파리는 거미줄에서 좀처럼 빠져나가지 못한다. 거미 자신은 곧은 줄을 따라 아무 탈 없이 달린다. 거미줄의 둥근 줄은 풀처럼 파리를 붙든다. 곧은 줄이 아니라 둥근 줄만 ______ 줄이다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Only the round threads, not the straight ones, are»(곧은 줄이 아니라 둥근 줄만 ~한 줄이다). 'Only'(오직 ~만)와 'not'이 있어요. 둥근 줄에만 있는 성질이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The round threads of the web hold a fly like glue.»(거미줄의 둥근 줄은 풀처럼 파리를 붙든다.) 둥근 줄이 어떤지를 바로 앞에서 말했어요. 'hold a fly like glue'(풀처럼 파리를 붙든다)가 단서예요.",
 "3) 둘째 문장 확인: «The spider itself runs along the straight threads without any trouble.»(거미 자신은 곧은 줄을 따라 아무 탈 없이 달린다.) 곧은 줄은 붙지 않아요. 그래서 거미는 곧은 줄로 다녀요.",
 "4) 묶기: 풀처럼 붙든다 = 'sticky'(끈적끈적한). 'hold a fly like glue'를 한 낱말로 바꾼 것이에요."],
 "「튼튼한」이 끌릴 수 있어요. 파리를 붙들고 놓지 않으니 튼튼한 줄이라고 생각하기 쉽거든요. 하지만 글은 둥근 줄이 풀처럼 붙든다고 했어요. 힘이 센 것이 아니라 달라붙는 것이에요.",
 [("튼튼한", "지문에 없는 이야기예요. 줄이 얼마나 튼튼한지는 나오지 않아요. 글이 말한 것은 둥근 줄이 풀처럼 붙든다는 것이에요."),
  ("끈적끈적한", "셋째 문장 «The round threads of the web hold a fly like glue.»가 근거예요. 풀처럼 붙든다는 것은 끈적끈적하다는 뜻이에요."),
  ("흰", "지문에 없는 이야기예요. 줄의 빛깔은 나오지 않아요."),
  ("가는", "지문에 없는 이야기예요. 줄의 굵기는 나오지 않아요."),
  ("새로운", "지문에 없는 이야기예요. 줄이 새것인지 헌것인지는 나오지 않아요.")])

# ---------- 18번째: 보온병의 두 벽 사이 (답 air) ----------
rw(17, 4, "A thermos bottle keeps hot tea hot for many hours. The bottle has two walls with a thin space between them. The makers take all the air out of this thin space. Without ______ in the space, heat cannot travel out of the tea easily.",
 "보온병은 뜨거운 차를 여러 시간 동안 뜨겁게 지켜 준다. 이 병에는 벽이 둘 있고, 그 사이에 얇은 틈이 있다. 만드는 사람들은 이 얇은 틈에서 공기를 모두 빼낸다. 틈 속에 ______가 없으면 열은 차에서 밖으로 쉽게 빠져나갈 수 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «heat cannot travel out of the tea easily»(열은 차에서 밖으로 쉽게 빠져나갈 수 없다). 'Without'(~이 없으면)과 'cannot'이 함께 있어요. 틈 속에 무엇이 없어서 열이 못 빠져나가는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The makers take all the air out of this thin space.»(만드는 사람들은 이 얇은 틈에서 공기를 모두 빼낸다.) 틈에서 빼낸 것이 바로 앞에 나와요. 'take all the air out'(공기를 모두 빼낸다)이 단서예요.",
 "3) 둘째 문장 확인: «The bottle has two walls with a thin space between them.»(이 병에는 벽이 둘 있고, 그 사이에 얇은 틈이 있다.) 빈칸 문장의 'the space'(그 틈)는 두 벽 사이의 틈이에요.",
 "4) 묶기: 틈에서 빼낸 것은 'air'(공기)예요. 공기가 없으니 열을 옮겨 줄 것이 없어서, 열이 쉽게 빠져나가지 못해요. 셋째 문장의 낱말이 그대로 답이에요."],
 "「물」이 끌릴 수 있어요. 병에 든 것은 차, 곧 물이거든요. 하지만 빈칸은 병 안이 아니라 두 벽 사이의 틈에 없는 것을 물어요. 그 틈에서 빼낸 것은 공기라고 했어요.",
 [("물", "글과 맞지 않아요. 틈에서 빼낸 것은 물이 아니라 공기라고 했어요. 물(차)은 병 안에 들어 있어요."),
  ("소리", "지문에 없는 이야기예요. 소리는 나오지 않아요. 틈에서 빼낸 것은 공기예요."),
  ("냄새", "지문에 없는 이야기예요. 냄새는 나오지 않아요."),
  ("먼지", "지문에 없는 이야기예요. 먼지는 나오지 않아요. 틈에서 빼낸 것은 공기예요."),
  ("공기", "셋째 문장 «The makers take all the air out of this thin space.»가 근거예요. 틈에서 공기를 모두 빼냈으니, 틈 속에 없는 것은 공기예요.")],
 ch={1: 'sound', 2: 'smell', 3: 'dust'})

# ---------- 19번째: 이슬이 맺히는 까닭 (답 colder) ----------
rw(18, 1, "On a clear night, the grass in a field loses heat very quickly. The air just above the field stays a little warmer than the grass. Water from this air turns into small drops of dew on the grass. Dew forms only on things ______ than the air around them.",
 "맑은 밤에는 들판의 풀이 열을 아주 빨리 잃는다. 들판 바로 위의 공기는 풀보다 조금 더 따뜻하게 남아 있다. 이 공기 속의 물이 풀 위에서 작은 이슬방울로 바뀐다. 이슬은 둘레의 공기보다 ______ 것에만 맺힌다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «than the air around them»(둘레의 공기보다). 'than'(~보다)이 있으니 견주는 문장이에요. 이슬이 맺히는 것이 둘레의 공기보다 어떠한지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «The air just above the field stays a little warmer than the grass.»(들판 바로 위의 공기는 풀보다 조금 더 따뜻하게 남아 있다.) 풀과 공기를 견준 말이 여기에 나와요. 'a little warmer'(조금 더 따뜻한)가 단서예요.",
 "3) 첫 문장 확인: «On a clear night, the grass in a field loses heat very quickly.»(맑은 밤에는 들판의 풀이 열을 아주 빨리 잃는다.) 풀은 열을 빨리 잃어요. 그래서 풀이 공기보다 먼저 식어요.",
 "4) 묶기: 공기가 풀보다 따뜻하다 = 풀이 공기보다 'colder'(더 찬). 견주는 쪽을 뒤집어 말한 것이에요."],
 "「더 따뜻한」이 끌릴 수 있어요. 둘째 문장에 'warmer'가 그대로 나오거든요. 하지만 더 따뜻한 것은 공기예요. 빈칸은 공기가 아니라 이슬이 맺히는 것, 곧 풀이 어떠한지를 물어요.",
 [("더 따뜻한", "글과 반대예요. 더 따뜻한 것은 공기예요. 이슬이 맺히는 풀은 열을 빨리 잃는다고 했어요."),
  ("더 찬", "둘째 문장 «The air just above the field stays a little warmer than the grass.»가 근거예요. 공기가 더 따뜻하다는 것은 풀이 공기보다 더 차다는 뜻이에요."),
  ("더 밝은", "지문에 없는 이야기예요. 밝기는 나오지 않아요. 글은 따뜻하고 찬 것을 견주었어요."),
  ("더 가벼운", "지문에 없는 이야기예요. 무게는 나오지 않아요. 글은 따뜻하고 찬 것을 견주었어요."),
  ("더 어두운", "지문에 없는 이야기예요. 맑은 밤이라고만 했을 뿐, 어둡기를 견주지는 않았어요.")],
 ch={3: 'lighter'})

# ---------- 20번째: 멀리 가는 고래의 노래 (답 water) ----------
rw(19, 1, "A whale sings a long, low song deep under the sea. Another whale hears the song from hundreds of kilometres away. In the open air, the same song dies away after a few kilometres. Sound can travel much farther in ______ than in the open air.",
 "고래 한 마리가 깊은 바닷속에서 길고 낮은 노래를 부른다. 다른 고래가 수백 킬로미터 떨어진 곳에서 그 노래를 듣는다. 바깥 공기 속에서는 같은 노래가 몇 킬로미터 못 가서 사라진다. 소리는 바깥 공기 속에서보다 ______ 속에서 훨씬 더 멀리 갈 수 있다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «than in the open air»(바깥 공기 속에서보다). 'than'(~보다)이 있으니 견주는 문장이에요. 소리가 공기 속에서보다 더 멀리 가는 곳이 어디인지를 물어요.",
 "2) 짝꿍 문장: 첫 문장이에요. «A whale sings a long, low song deep under the sea.»(고래 한 마리가 깊은 바닷속에서 길고 낮은 노래를 부른다.) 노래가 멀리 간 곳이 여기에 나와요. 'deep under the sea'(깊은 바닷속에서)가 단서예요.",
 "3) 둘째 문장 확인: «Another whale hears the song from hundreds of kilometres away.»(다른 고래가 수백 킬로미터 떨어진 곳에서 그 노래를 듣는다.) 바닷속에서는 수백 킬로미터를 가요. 공기 속에서는 몇 킬로미터 못 간다고 했어요.",
 "4) 묶기: 깊은 바닷속 = 'water'(물) 속. 'under the sea'를 한 낱말로 바꾼 것이에요."],
 "「우주」가 끌릴 수 있어요. 아무것도 막지 않는 넓은 곳이라 소리가 멀리 갈 것 같거든요. 하지만 글에는 우주가 나오지 않아요. 노래가 수백 킬로미터를 간 곳은 깊은 바닷속이에요.",
 [("우주", "지문에 없는 이야기예요. 우주는 나오지 않아요. 노래가 멀리 간 곳은 깊은 바닷속이에요."),
  ("물", "첫 문장 «A whale sings a long, low song deep under the sea.»가 근거예요. 바닷속은 물속이고, 거기에서는 노래가 수백 킬로미터를 가요."),
  ("모래", "지문에 없는 이야기예요. 모래는 나오지 않아요."),
  ("구름", "지문에 없는 이야기예요. 구름은 나오지 않아요. 노래가 멀리 간 곳은 깊은 바닷속이에요."),
  ("빛", "지문에 없는 이야기예요. 빛은 나오지 않아요.")],
 ch={0: 'space', 3: 'clouds'})

# ---------- 21번째: 가로등을 도는 나방 (답 away) ----------
rw(20, 2, "At night, moths fly round and round a street lamp. For millions of years, their only light came from the far sky. A moth always keeps the light above its body during flight. This old habit works well only with a light far ______.",
 "밤이면 나방들이 가로등 둘레를 빙빙 돈다. 수백만 년 동안 나방에게 빛은 먼 하늘에서만 왔다. 나방은 날 때 늘 빛이 몸 위쪽에 오도록 한다. 이 오랜 버릇은 멀리 ______ 있는 빛에서만 잘 통한다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «This old habit works well only with a light far»(이 오랜 버릇은 멀리 ~ 있는 빛에서만 잘 통한다). 'only'(오직 ~만)가 있어요. 나방의 버릇이 통하는 빛이 어디에 있는 빛인지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «For millions of years, their only light came from the far sky.»(수백만 년 동안 나방에게 빛은 먼 하늘에서만 왔다.) 나방이 써 온 빛이 어디에서 왔는지가 여기에 나와요. 'the far sky'(먼 하늘)가 단서예요.",
 "3) 첫 문장 확인: «At night, moths fly round and round a street lamp.»(밤이면 나방들이 가로등 둘레를 빙빙 돈다.) 가로등은 가까이 있는 빛이에요. 가까운 빛에서는 버릇이 통하지 않아서 빙빙 돌게 돼요.",
 "4) 묶기: 먼 하늘에서 오는 빛 = 멀리 떨어져 있는 빛. 'far' 뒤에 와서 그 뜻이 되는 말은 'away'(떨어져)예요."],
 "「더 밝은」이 끌릴 수 있어요. 'far'와 'brighter'를 이으면 「훨씬 더 밝은」이라는 뜻이 되고, 나방은 밝은 빛을 좋아할 것 같거든요. 하지만 글에는 빛의 밝기 이야기가 없어요. 글이 말한 것은 빛이 먼 하늘에서 왔다는 것이에요.",
 [("아래에", "글과 맞지 않아요. 나방은 빛이 몸 위쪽에 오도록 한다고 했어요. 빛은 아래가 아니라 하늘에서 왔어요."),
  ("뒤에", "지문에 없는 이야기예요. 빛이 뒤에 있다는 말은 나오지 않아요. 빛은 먼 하늘에서 왔다고 했어요."),
  ("떨어져", "둘째 문장 «For millions of years, their only light came from the far sky.»가 근거예요. 먼 하늘에서 오는 빛은 멀리 떨어져 있는 빛이에요."),
  ("더 밝은", "지문에 없는 이야기예요. 빛의 밝기는 나오지 않아요. 글이 말한 것은 빛이 얼마나 멀리 있는지예요."),
  ("더 작은", "지문에 없는 이야기예요. 빛의 크기는 나오지 않아요.")])

# ---------- 22번째: 씨앗에 필요한 세 가지 (답 grow) ----------
rw(21, 3, "A seed can sleep in a paper bag for many years. For a new life, the seed needs three things: water, warmth and air. With all three, a small green plant comes out of the seed. Without one of the three, a seed cannot ______ into a new plant.",
 "씨앗은 종이 봉투 속에서 여러 해 동안 잠잘 수 있다. 새 삶을 시작하려면 씨앗에게 세 가지, 곧 물과 따뜻함과 공기가 있어야 한다. 셋이 다 있으면 씨앗에서 작은 푸른 식물이 나온다. 셋 가운데 하나라도 없으면 씨앗은 새 식물로 ______ 수 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Without one of the three, a seed cannot»(셋 가운데 하나라도 없으면 씨앗은 ~할 수 없다). 'Without'과 'cannot'이 함께 있어요. 하나가 모자랄 때 씨앗이 하지 못하는 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «With all three, a small green plant comes out of the seed.»(셋이 다 있으면 씨앗에서 작은 푸른 식물이 나온다.) 셋이 다 있을 때 일어나는 일이 바로 앞에 나와요. 'a small green plant comes out'(작은 푸른 식물이 나온다)이 단서예요.",
 "3) 둘째 문장 확인: «For a new life, the seed needs three things: water, warmth and air.»(새 삶을 시작하려면 씨앗에게 세 가지, 곧 물과 따뜻함과 공기가 있어야 한다.) 'the three'(그 셋)는 물, 따뜻함, 공기예요.",
 "4) 묶기: 씨앗에서 식물이 나온다 = 'grow'(자라다). 셋이 다 있으면 자라고, 하나라도 없으면 자랄 수 없어요. 'With'와 'Without'이 짝을 이루어요."],
 "「잠자다」가 끌릴 수 있어요. 첫 문장에 'sleep'이 그대로 나오거든요. 하지만 씨앗은 봉투 속에서 여러 해 잠잘 수 있다고 했어요. 셋 가운데 하나라도 없을 때 못 하는 일은 새 식물이 되는 것이에요.",
 [("마르다", "지문에 없는 이야기예요. 씨앗이 마르는 일은 나오지 않아요. 글이 말한 것은 셋이 다 있으면 식물이 나온다는 것이에요."),
  ("뜨다", "지문에 없는 이야기예요. 물에 뜨는 일은 나오지 않아요."),
  ("옮겨 가다", "지문에 없는 이야기예요. 씨앗이 다른 곳으로 옮겨 가는 일은 나오지 않아요."),
  ("자라다", "셋째 문장 «With all three, a small green plant comes out of the seed.»가 근거예요. 셋이 다 있어야 식물이 나오니, 하나라도 없으면 씨앗은 자랄 수 없어요."),
  ("잠자다", "글과 맞지 않아요. 씨앗은 종이 봉투 속에서 여러 해 잠잘 수 있다고 했어요. 못 하는 일은 자라는 것이에요.")],
 ch={0: 'dry', 2: 'travel', 4: 'sleep'})

# ---------- 23번째: 북의 가죽과 소리의 높이 (답 tighter) ----------
rw(22, 4, "A drum has a thin skin across its round top. The player pulls the skin harder with the small screws on the side. After that, the same drum gives a much higher note. For a higher sound, the same drum needs a ______ skin.",
 "북의 둥근 윗면에는 얇은 가죽이 씌워져 있다. 연주자가 옆에 달린 작은 나사로 가죽을 더 세게 당긴다. 그러고 나면 같은 북이 훨씬 높은 소리를 낸다. 더 높은 소리를 내려면 같은 북에 ______ 가죽이 있어야 한다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For a higher sound, the same drum needs a»(더 높은 소리를 내려면 같은 북에 ~ 가죽이 있어야 한다). 높은 소리를 내려면 가죽이 어떠해야 하는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «The player pulls the skin harder with the small screws on the side.»(연주자가 옆에 달린 작은 나사로 가죽을 더 세게 당긴다.) 가죽을 어떻게 했는지가 여기에 나와요. 'pulls the skin harder'(가죽을 더 세게 당긴다)가 단서예요.",
 "3) 셋째 문장 확인: «After that, the same drum gives a much higher note.»(그러고 나면 같은 북이 훨씬 높은 소리를 낸다.) 가죽을 당긴 뒤에 소리가 높아졌어요.",
 "4) 묶기: 가죽을 더 세게 당긴다 = 가죽이 'tighter'(더 팽팽한) 것이 된다. 'pulls the skin harder'를 한 낱말로 바꾼 것이에요."],
 "「더 튼튼한」이 끌릴 수 있어요. 'harder'(더 세게)라는 말에서 센 것, 튼튼한 것을 떠올리기 쉽거든요. 하지만 글은 가죽을 바꾼 것이 아니라 같은 가죽을 더 세게 당겼다고 했어요.",
 [("더 느슨한", "글과 반대예요. 연주자는 가죽을 풀지 않고 더 세게 당겼어요."),
  ("더 젖은", "지문에 없는 이야기예요. 가죽에 물을 묻히는 일은 나오지 않아요."),
  ("더 튼튼한", "지문에 없는 이야기예요. 가죽을 튼튼한 것으로 바꾼다는 말은 없어요. 같은 가죽을 더 세게 당겼어요."),
  ("더 오래된", "지문에 없는 이야기예요. 가죽이 얼마나 오래되었는지는 나오지 않아요."),
  ("더 팽팽한", "둘째 문장 «The player pulls the skin harder with the small screws on the side.»가 근거예요. 가죽을 더 세게 당기면 가죽이 더 팽팽해져요.")],
 ch={2: 'stronger'})

# ---------- 24번째: 연의 꼬리 (답 spins) ----------
rw(23, 2, "A flat kite flies with a long tail of paper or cloth. The tail pulls the bottom of the kite down in the wind. A flat kite without a tail turns round and round in the air. Without its tail, the kite ______ and soon falls to the ground.",
 "납작한 연은 종이나 천으로 된 긴 꼬리를 달고 난다. 꼬리는 바람 속에서 연의 아래쪽을 밑으로 당겨 준다. 꼬리가 없는 납작한 연은 공중에서 빙글빙글 돈다. 꼬리가 없으면 연은 ______다가 곧 땅으로 떨어진다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «and soon falls to the ground»(그리고 곧 땅으로 떨어진다). 꼬리가 없는 연이 떨어지기 전에 어떻게 되는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «A flat kite without a tail turns round and round in the air.»(꼬리가 없는 납작한 연은 공중에서 빙글빙글 돈다.) 꼬리 없는 연이 어떻게 되는지를 바로 앞에서 말했어요. 'turns round and round'(빙글빙글 돈다)가 단서예요.",
 "3) 둘째 문장 확인: «The tail pulls the bottom of the kite down in the wind.»(꼬리는 바람 속에서 연의 아래쪽을 밑으로 당겨 준다.) 꼬리가 연을 바로 세워 줘요. 꼬리가 없으면 연이 바로 서지 못해요.",
 "4) 묶기: 빙글빙글 돈다 = 'spins'(뱅뱅 돌다). 'turns round and round'를 한 낱말로 바꾼 것이에요."],
 "「부서지다」가 끌릴 수 있어요. 땅으로 떨어지는 연은 부서질 것 같거든요. 하지만 빈칸은 떨어지기 전의 일을 물어요. 글은 꼬리 없는 연이 공중에서 빙글빙글 돈다고 했어요.",
 [("올라가다", "글과 맞지 않아요. 꼬리 없는 연은 올라가는 것이 아니라 빙글빙글 돌다가 떨어져요."),
  ("멈추다", "글과 맞지 않아요. 꼬리 없는 연은 멈추지 않고 빙글빙글 돈다고 했어요."),
  ("뱅뱅 돌다", "셋째 문장 «A flat kite without a tail turns round and round in the air.»가 근거예요. 빙글빙글 도는 것을 한 낱말로 말한 것이에요."),
  ("접히다", "지문에 없는 이야기예요. 연이 접힌다는 말은 나오지 않아요."),
  ("부서지다", "지문에 없는 이야기예요. 연이 부서진다는 말은 나오지 않아요. 빈칸은 떨어지기 전에 공중에서 일어나는 일을 물어요.")],
 ch={1: 'stops', 4: 'breaks'})

# ---------- 25번째: 비누가 기름때를 씻는 까닭 (답 grease) ----------
rw(24, 4, "Grease, the oil from our food, does not mix with water. For this reason, water alone cannot clean a dirty dinner plate. Each tiny piece of soap has a water end and an oil end. With its oil end, the soap catches the ______ on the plate.",
 "기름때, 곧 음식에서 나온 기름은 물과 섞이지 않는다. 이런 까닭으로 물만으로는 더러운 접시를 깨끗이 씻을 수 없다. 비누의 아주 작은 알갱이마다 물 쪽 끝과 기름 쪽 끝이 있다. 비누는 기름 쪽 끝으로 접시 위의 ______를 붙잡는다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With its oil end, the soap catches the»(기름 쪽 끝으로 비누는 ~를 붙잡는다). 비누가 기름 쪽 끝으로 접시에서 무엇을 붙잡는지를 물어요.",
 "2) 짝꿍 문장: 첫 문장이에요. «Grease, the oil from our food, does not mix with water.»(기름때, 곧 음식에서 나온 기름은 물과 섞이지 않는다.) 접시에 묻은 기름의 이름이 여기에 나와요. 'Grease, the oil from our food'(기름때, 곧 음식에서 나온 기름)가 단서예요.",
 "3) 셋째 문장 확인: «Each tiny piece of soap has a water end and an oil end.»(비누의 아주 작은 알갱이마다 물 쪽 끝과 기름 쪽 끝이 있다.) 기름 쪽 끝은 기름을 붙잡아요. 접시 위의 기름이 바로 기름때예요.",
 "4) 묶기: 접시 위의, 음식에서 나온 기름 = 'grease'(기름때). 첫 문장의 낱말이 그대로 답이에요."],
 "「물」이 끌릴 수 있어요. 비누에는 물 쪽 끝도 있고, 설거지에는 물을 쓰거든요. 하지만 빈칸 문장은 'With its oil end'(기름 쪽 끝으로)로 시작해요. 기름 쪽 끝이 붙잡는 것은 물이 아니라 기름이에요.",
 [("공기", "지문에 없는 이야기예요. 공기는 나오지 않아요."),
  ("거품", "지문에 없는 이야기예요. 거품은 나오지 않아요. 기름 쪽 끝이 붙잡는 것은 기름이에요."),
  ("물", "글과 맞지 않아요. 빈칸 문장은 물 쪽 끝이 아니라 기름 쪽 끝을 말해요. 기름 쪽 끝이 붙잡는 것은 기름이에요."),
  ("소금", "지문에 없는 이야기예요. 소금은 나오지 않아요."),
  ("기름때", "첫 문장 «Grease, the oil from our food, does not mix with water.»가 근거예요. 음식에서 나온 기름이 기름때이고, 비누의 기름 쪽 끝이 그것을 붙잡아요.")],
 ch={1: 'bubbles', 2: 'water'})

# ---------- 26번째: 겨울에 터지는 수도관 (답 inside) — 글감을 바꿈(서리 맞은 잎 → 수도관) ----------
rw(25, 2, "A water pipe is a long, thin tube full of water. On a very cold night, this water turns into hard ice. Ice needs more room than water and pushes against the pipe walls. In winter, a pipe sometimes breaks because of the ice ______ it.",
 "수도관은 물이 가득 든 길고 가는 대롱이다. 아주 추운 밤에는 이 물이 단단한 얼음으로 바뀐다. 얼음은 물보다 자리를 더 많이 차지해서 관의 벽을 밀어낸다. 겨울에 수도관은 그 ______ 있는 얼음 때문에 가끔 터진다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «a pipe sometimes breaks because of the ice»(수도관은 얼음 때문에 가끔 터진다). 수도관을 터지게 하는 얼음이 관의 어디에 있는 얼음인지를 물어요. 빈칸 뒤의 'it'은 수도관이에요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On a very cold night, this water turns into hard ice.»(아주 추운 밤에는 이 물이 단단한 얼음으로 바뀐다.) 얼음이 무엇에서 생기는지가 여기에 나와요. 'this water'(이 물)는 관에 가득 든 물이에요.",
 "3) 첫 문장 확인: «A water pipe is a long, thin tube full of water.»(수도관은 물이 가득 든 길고 가는 대롱이다.) 물은 관 속에 들어 있어요. 그 물이 얼었으니 얼음도 관 속에 있어요.",
 "4) 묶기: 관에 가득 든 물이 언 얼음 = 관 'inside'(안에) 있는 얼음. 'full of water'(물이 가득 든)에서 알 수 있어요."],
 "「둘레에」가 끌릴 수 있어요. 겨울에 관 겉에 얼음이 붙어 있는 모습을 떠올리기 쉽거든요. 하지만 글에서 얼음이 된 것은 관에 가득 든 물이에요. 그 얼음이 안에서 벽을 밀어내요.",
 [("밖에", "글과 반대예요. 얼음이 된 것은 관에 가득 든 물이에요. 얼음은 관 밖이 아니라 안에 있어요."),
  ("아래에", "지문에 없는 이야기예요. 관 아래의 얼음은 나오지 않아요."),
  ("안에", "둘째 문장 «On a very cold night, this water turns into hard ice.»가 근거예요. 관에 가득 든 물이 얼었으니 얼음은 관 안에 있고, 안에서 벽을 밀어내요."),
  ("위에", "지문에 없는 이야기예요. 관 위의 얼음은 나오지 않아요."),
  ("둘레에", "글과 맞지 않아요. 얼음은 관의 둘레가 아니라 관에 가득 든 물에서 생겨요.")])

# ---------- 27번째: 냉장고 속의 빵 (답 faster) ----------
rw(26, 0, "Fresh bread stays soft for about three days on the kitchen table. In the fridge, the same bread gets hard in only one day. Unlike milk or meat, bread does not stay fresh longer in a fridge. In a fridge, the change from soft to hard is much ______.",
 "갓 구운 빵은 부엌 식탁 위에서 사흘쯤 부드럽게 남아 있다. 냉장고에서는 같은 빵이 단 하루 만에 딱딱해진다. 우유나 고기와 달리, 빵은 냉장고에서 더 오래 싱싱하게 남지 않는다. 냉장고에서는 부드럽던 빵이 딱딱해지는 일이 훨씬 ______ 편이다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the change from soft to hard is much»(부드럽던 것이 딱딱해지는 변화가 훨씬 ~하다). 냉장고 안에서 빵이 딱딱해지는 일이 어떠한지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «In the fridge, the same bread gets hard in only one day.»(냉장고에서는 같은 빵이 단 하루 만에 딱딱해진다.) 냉장고에서 얼마나 걸리는지가 여기에 나와요. 'in only one day'(단 하루 만에)가 단서예요.",
 "3) 첫 문장 확인: «Fresh bread stays soft for about three days on the kitchen table.»(갓 구운 빵은 부엌 식탁 위에서 사흘쯤 부드럽게 남아 있다.) 식탁 위에서는 사흘쯤이에요. 냉장고의 하루와 견주어 봐요.",
 "4) 묶기: 사흘 걸리던 일이 하루 만에 일어난다 = 'faster'(더 빠른). 사흘과 하루를 견주어 한 낱말로 말한 것이에요."],
 "「더 느린」이 끌릴 수 있어요. 냉장고는 음식을 오래 가게 하는 곳이라고 알고 있거든요. 하지만 글은 빵은 우유나 고기와 다르다고 했어요. 식탁에서는 사흘, 냉장고에서는 하루예요.",
 [("더 빠른", "둘째 문장 «In the fridge, the same bread gets hard in only one day.»가 근거예요. 식탁에서는 사흘쯤 걸리던 일이 냉장고에서는 하루 만에 일어나요."),
  ("더 느린", "글과 반대예요. 식탁에서는 사흘쯤, 냉장고에서는 하루예요. 냉장고에서 더 빨리 딱딱해져요."),
  ("더 늦은", "글과 반대예요. 냉장고에서는 사흘이 아니라 하루 만에 딱딱해진다고 했어요. 더 늦게가 아니라 더 일찍이에요."),
  ("더 작은", "지문에 없는 이야기예요. 변화가 크고 작은 것은 나오지 않아요. 글은 걸리는 날수를 견주었어요."),
  ("더 약한", "지문에 없는 이야기예요. 변화가 세고 약한 것은 나오지 않아요. 글은 걸리는 날수를 견주었어요.")],
 ch={3: 'smaller', 4: 'weaker'})

# ---------- 28번째: 나침반의 북쪽과 진짜 북쪽 (답 true) ----------
rw(27, 0, "The needle of a compass points to a place in the far north. This place on the map has a special name, magnetic north. The real top of the earth, the North Pole, is hundreds of kilometres from it. Magnetic north and ______ north are not the same place.",
 "나침반의 바늘은 먼 북쪽의 한 곳을 가리킨다. 지도에서 이곳에는 자북이라는 특별한 이름이 있다. 지구의 진짜 꼭대기인 북극은 거기에서 수백 킬로미터 떨어져 있다. 자북과 ______ 북쪽은 같은 곳이 아니다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «north are not the same place»(북쪽은 같은 곳이 아니다). 'not'이 있어요. 자북과 같은 곳이 아닌, 또 하나의 북쪽이 어떤 북쪽인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The real top of the earth, the North Pole, is hundreds of kilometres from it.»(지구의 진짜 꼭대기인 북극은 거기에서 수백 킬로미터 떨어져 있다.) 자북과 다른 또 하나의 북쪽이 바로 앞에 나와요. 'The real top of the earth'(지구의 진짜 꼭대기)가 단서예요.",
 "3) 둘째 문장 확인: «This place on the map has a special name, magnetic north.»(지도에서 이곳에는 자북이라는 특별한 이름이 있다.) 나침반의 바늘이 가리키는 곳이 자북이에요. 자북은 자석이 가리키는 북쪽이라는 뜻이에요. 바로 다음 문장의 'it'(거기)이 이 자북이에요.",
 "4) 묶기: 지구의 진짜 꼭대기 = 진짜 북쪽. 'real'(진짜의)과 같은 뜻의 낱말은 'true'(참된, 진짜의)예요."],
 "「높은」이 끌릴 수 있어요. 글에 'top'(꼭대기)이 나오니 높은 북쪽이라고 생각하기 쉽거든요. 하지만 글은 높이를 견주지 않았어요. 글이 말한 것은 나침반이 가리키는 곳과 지구의 진짜 꼭대기가 다른 곳이라는 것이에요.",
 [("참된, 진짜의", "셋째 문장 «The real top of the earth, the North Pole, is hundreds of kilometres from it.»이 근거예요. 지구의 진짜 꼭대기가 진짜 북쪽이고, 자북은 거기에서 수백 킬로미터 떨어져 있어요."),
  ("더 낮은", "지문에 없는 이야기예요. 높고 낮은 것은 나오지 않아요."),
  ("추운", "지문에 없는 이야기예요. 춥고 더운 것은 나오지 않아요."),
  ("높은", "지문에 없는 이야기예요. 꼭대기라는 말은 있지만 높이를 견주지는 않았어요."),
  ("가까운", "글과 맞지 않아요. 두 곳은 수백 킬로미터 떨어져 있다고 했어요.")],
 ch={2: 'cold'})

# ---------- 29번째: 소리 없이 나는 올빼미 (답 air) ----------
rw(28, 3, "An owl flies over a field at night almost without a sound. The front edge of an owl's wing looks like a small comb. The wind over the wing passes through this comb in tiny streams. Thanks to the comb, each wing breaks the ______ into small, quiet streams.",
 "올빼미는 밤에 거의 소리 없이 들판 위를 난다. 올빼미 날개의 앞쪽 가장자리는 작은 빗처럼 생겼다. 날개 위를 지나는 바람은 이 빗을 지나며 아주 가는 줄기들로 나뉜다. 이 빗 덕분에 날개 하나하나가 ______를 작고 조용한 줄기들로 쪼갠다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «into small, quiet streams»(작고 조용한 줄기들로). 날개가 빗으로 무엇을 작고 조용한 줄기들로 쪼개는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The wind over the wing passes through this comb in tiny streams.»(날개 위를 지나는 바람은 이 빗을 지나며 아주 가는 줄기들로 나뉜다.) 빗을 지나며 나뉘는 것이 바로 앞에 나와요. 'The wind over the wing'(날개 위를 지나는 바람)이 단서예요.",
 "3) 둘째 문장 확인: «The front edge of an owl's wing looks like a small comb.»(올빼미 날개의 앞쪽 가장자리는 작은 빗처럼 생겼다.) 빗은 날개의 앞쪽 가장자리예요. 날 때 맨 먼저 바람을 만나는 곳이에요.",
 "4) 묶기: 날개 위를 지나는 바람 = 움직이는 'air'(공기). 'The wind'를 다른 낱말로 바꾼 것이에요."],
 "「물」이 끌릴 수 있어요. 'streams'가 물줄기를 뜻하기도 하거든요. 하지만 글에는 물이 나오지 않아요. 가는 줄기로 나뉘는 것은 날개 위를 지나는 바람이에요.",
 [("빛", "지문에 없는 이야기예요. 밤이라고 했고, 빛은 나오지 않아요."),
  ("구름", "지문에 없는 이야기예요. 구름은 나오지 않아요. 올빼미는 들판 위를 날아요."),
  ("비", "지문에 없는 이야기예요. 비는 나오지 않아요."),
  ("공기", "셋째 문장 «The wind over the wing passes through this comb in tiny streams.»가 근거예요. 바람은 움직이는 공기이고, 빗이 그것을 가는 줄기로 나누어요."),
  ("물", "지문에 없는 이야기예요. 물은 나오지 않아요. 가는 줄기로 나뉘는 것은 바람이에요.")],
 ch={1: 'cloud'})

# ---------- 30번째: 그림자가 가장 긴 때 (답 low) ----------
rw(29, 1, "At noon on a summer day, your shadow on the ground is very short. At that time, the sun is at its highest point in the sky. Early in the morning, the sun just above the hills makes a long shadow. Your shadow is longest with the sun ______ in the sky.",
 "여름날 한낮에는 땅에 생긴 그림자가 아주 짧다. 그때 해는 하늘에서 가장 높은 곳에 있다. 이른 아침에는 언덕 바로 위에 있는 해가 긴 그림자를 만든다. 그림자는 해가 하늘에 ______ 있을 때 가장 길다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Your shadow is longest with the sun»(그림자는 해가 ~ 있을 때 가장 길다). 그림자가 가장 길 때 해가 하늘의 어디에 있는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Early in the morning, the sun just above the hills makes a long shadow.»(이른 아침에는 언덕 바로 위에 있는 해가 긴 그림자를 만든다.) 긴 그림자를 만드는 해가 어디에 있는지를 바로 앞에서 말했어요. 'just above the hills'(언덕 바로 위에)가 단서예요.",
 "3) 둘째 문장 확인: «At that time, the sun is at its highest point in the sky.»(그때 해는 하늘에서 가장 높은 곳에 있다.) 한낮에는 해가 가장 높고 그림자가 짧아요. 높으면 짧고, 그 반대이면 길어요.",
 "4) 묶기: 언덕 바로 위에 있다 = 하늘에 'low'(낮게) 있다. 'just above the hills'를 한 낱말로 바꾼 것이에요."],
 "「높게」가 끌릴 수 있어요. 둘째 문장에 'highest'(가장 높은)가 나오거든요. 하지만 해가 가장 높은 한낮에는 그림자가 짧다고 했어요. 그림자가 긴 것은 해가 언덕 바로 위에 있는 이른 아침이에요.",
 [("높게", "글과 반대예요. 해가 가장 높은 한낮에는 그림자가 짧다고 했어요."),
  ("낮게", "셋째 문장 «Early in the morning, the sun just above the hills makes a long shadow.»가 근거예요. 언덕 바로 위에 있는 해는 하늘에 낮게 있는 해이고, 그때 그림자가 길어요."),
  ("밝게", "지문에 없는 이야기예요. 해의 밝기는 나오지 않아요. 글은 해가 어디에 있는지를 말했어요."),
  ("멀리", "지문에 없는 이야기예요. 해가 멀고 가까운 것은 나오지 않아요."),
  ("작게", "지문에 없는 이야기예요. 해의 크기는 나오지 않아요.")])
