# -*- coding: utf-8 -*-
# 320번: 32번(빈칸 추론 — 낱말) 레벨1 — 레벨1 기준으로 다시 씀 (앞 절반: 1~15번째)
# 선생님 결정(314번 뒤): 「1. 레벨 1부터. 2. 문장 수도 늘립시다」 → 31번 레벨1(315·316번)과 같은 꼴로
# 레벨1의 기준(LEVEL_GUIDE.md): 중학 기초 생활 낱말 · 단문(접속사로 절을 잇지 않음) · 문장당 10~15낱말
#   - because·when·if·which 절, 분사구문, 명사절은 쓰지 않음. because of + 명사, with/without + 명사, 비교급, to부정사는 씀
# 지문의 꼴: 한두 문장(15낱말쯤) → **네 문장(46낱말쯤)**. 빈칸은 넷째 문장. 짝꿍 문장은 셋째(열한 문항) · 둘째(4·7번째) · 첫째(8번째)
# 생각의 단계(추론축 레벨1): 글에 있는 말 하나를 그대로 확인 — 빈칸의 답이 짝꿍 문장에 다른 말로 나옴
#   (다른 말로: sink ← goes down to the bottom · light ← the bright sun · freeze ← stays liquid · empty ← no air and no water ·
#    shell ← the hard outside of an egg · heat ← feels much cooler · spread ← sends light back · direction ← goes straight … bends · water ← a very dry place · bones ← the hard parts inside)
#   (그 낱말 그대로: air · gas · water(7번째) · poles · echo — 과학 낱말이라 글 안에서 먼저 알려 줌)
# 글감(과학 사실)·정답 번호는 그대로. 정답 낱말도 그대로 — 11번째만 scatter → spread(중학 기초 낱말이 아니어서. 31번 레벨1의 reliable → safe와 같은 까닭)
# 선택지: 318번의 다섯 가지 방법에 따라 엉뚱한 오답(silver · wick · strings · jacket …)과 「과학으로는 참이라 둘째 답이 될 수 있는」 오답(quiet · cold · dark · skin · bend · salt)을 바꿈 — 인계문서 320번에 표
# 과학: 독립 풀이에서 문항마다 사실을 따로 확인받음(1번째는 초 — 굳은 초는 녹은 촛농에 가라앉음. 쇠는 주철이 쇳물에 뜬다는 말이 있어 피함 · 14번째 almost no → very little — 꿀의 물은 17%쯤)
# 해석·풀이·선택지별 해설도 새로 씀(「~어요」, 31~34번의 두터운 꼴 — z8common.py)
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '32', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, ko, steps, traps, cn, ch=None):
    """문항을 통째로 다시 씀: 지문·해석·풀이·해설. 정답 번호는 그대로. ch = {자리: 새 선택지}(바꾸는 문항만)"""
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=bool(ch and ans in ch)); e = E.pop((T, LV, n))
    choices = list(_tb[T][LV][n]['choices'])
    for k, v in (ch or {}).items(): choices[k] = v
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(choices)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': choices, 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 1번째: 얼음은 뜨고 다른 고체는 가라앉는다 (답 sink) ----------
rw(0, 0, "Ice always stays on top of the cold water in a glass. This is very unusual in the world of solids and liquids. Solid wax goes down to the bottom of a pot of hot liquid wax. Unlike ice, most solid things ______ in their own liquid.",
 "얼음은 유리잔 속의 차가운 물 위에 늘 떠 있다. 이것은 고체와 액체의 세계에서 아주 드문 일이다. 굳은 초는 뜨겁게 녹은 촛농이 담긴 냄비의 바닥으로 내려간다. 얼음과 달리, 대부분의 고체는 자기가 녹은 액체 속에서 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Unlike ice, most solid things»(얼음과 달리, 대부분의 고체는). 'Unlike'(~과 달리)가 있어요. 얼음과는 다르게, 다른 고체들이 액체 속에서 어떻게 되는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Solid wax goes down to the bottom of a pot of hot liquid wax.»(굳은 초는 뜨겁게 녹은 촛농이 담긴 냄비의 바닥으로 내려간다.) 다른 고체의 보기가 바로 앞에 나와요. 'goes down to the bottom'(바닥으로 내려간다)이 단서예요.",
 "3) 첫 문장 확인: «Ice always stays on top of the cold water in a glass.»(얼음은 유리잔 속의 차가운 물 위에 늘 떠 있다.) 얼음은 위에 있어요. 둘째 문장은 이것이 드문 일이라고 해요. 그러니 다른 고체는 얼음과 반대예요.",
 "4) 묶기: 바닥으로 내려간다 = 'sink'(가라앉다). 'goes down to the bottom'을 한 낱말로 바꾼 것이에요."],
 "「뜨다」가 끌릴 수 있어요. 글이 얼음이 물 위에 있다는 말로 시작하거든요. 하지만 빈칸 문장은 'Unlike ice'(얼음과 달리)로 시작해요. 얼음과 다른 쪽을 골라야 해요. 굳은 초는 바닥으로 내려간다고 했어요.",
 [("가라앉다", "셋째 문장 «Solid wax goes down to the bottom of a pot of hot liquid wax.»가 근거예요. 바닥으로 내려간다는 것은 가라앉는다는 뜻이에요."),
  ("부서지다", "지문에 없는 이야기예요. 고체가 부서진다는 말은 나오지 않아요. 글이 말한 것은 위에 있는지 바닥으로 가는지예요."),
  ("뜨다", "글과 반대예요. 뜨는 것은 얼음이에요. 빈칸 문장은 얼음과 달리 다른 고체가 어떤지를 물어요."),
  ("타다", "지문에 없는 이야기예요. 불에 타는 일은 나오지 않아요."),
  ("자라다", "지문에 없는 이야기예요. 고체가 커진다는 말은 나오지 않아요.")],
 ch={1: 'break'})

# ---------- 2번째: 창문 쪽으로 도는 식물 (답 light) ----------
rw(1, 1, "The plants on Mina's desk all turn toward the closed window. On Monday she turns every pot around, away from the window. By Friday the leaves face the bright sun in the window again. With their faces to the window, the leaves catch much more ______.",
 "미나의 책상 위 식물들은 모두 닫힌 창문 쪽으로 몸을 돌리고 있다. 월요일에 그녀는 화분을 모두 창문 반대쪽으로 돌려놓는다. 금요일이 되면 잎들은 다시 창문의 밝은 해를 마주 본다. 창문 쪽을 보고 있으면 잎은 훨씬 더 많은 ______을 받는다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the leaves catch much more»(잎은 훨씬 더 많은 ~을 받는다). 잎이 창문 쪽을 보고 무엇을 더 받는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «By Friday the leaves face the bright sun in the window again.»(금요일이 되면 잎들은 다시 창문의 밝은 해를 마주 본다.) 잎이 무엇을 향하는지를 바로 앞에서 말했어요. 'the bright sun'(밝은 해)이 단서예요.",
 "3) 첫 문장 확인: «The plants on Mina's desk all turn toward the closed window.»(미나의 책상 위 식물들은 모두 닫힌 창문 쪽으로 몸을 돌리고 있다.) 창문은 닫혀 있어요. 닫힌 창문으로 들어오는 것은 햇빛뿐이에요.",
 "4) 묶기: 밝은 해에서 오는 것 = 'light'(빛). 'the bright sun'이 보내는 것을 한 낱말로 말한 것이에요."],
 "「물」이 끌릴 수 있어요. 식물에게 물이 필요하다는 것은 누구나 알거든요. 하지만 물을 주는 이야기는 글에 나오지 않아요. 잎이 마주 보는 것은 창문의 밝은 해예요.",
 [("그늘, 그림자", "글과 반대예요. 잎은 그늘이 아니라 창문의 밝은 해를 마주 본다고 했어요."),
  ("빛", "셋째 문장 «By Friday the leaves face the bright sun in the window again.»이 근거예요. 잎이 밝은 해를 마주 본다는 것은 빛을 받으려 한다는 뜻이에요."),
  ("물", "지문에 없는 이야기예요. 물을 주는 일은 나오지 않아요. 창문 쪽을 본다고 물을 더 받지는 않아요."),
  ("비", "글과 맞지 않아요. 창문은 닫혀 있다고 했어요. 닫힌 창문으로 비는 들어오지 않아요."),
  ("바람", "글과 맞지 않아요. 창문은 닫혀 있다고 했어요. 닫힌 창문으로 바람은 들어오지 않아요.")],
 ch={0: 'shadow', 2: 'water', 3: 'rain'})

# ---------- 3번째: 길에 뿌리는 소금 (답 freeze) ----------
rw(2, 3, "In winter, trucks drop salt on icy roads in the early morning. The salt mixes with the ice and makes salty water. Salty water stays liquid even at five degrees below zero. For this reason, salty water on the road does not ______ easily.",
 "겨울에는 이른 아침에 트럭이 얼어붙은 길에 소금을 뿌린다. 소금은 얼음과 섞여 소금물을 만든다. 소금물은 영하 5도에서도 액체로 남아 있다. 이런 까닭으로 길 위의 소금물은 쉽게 ______지 않는다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «salty water on the road does not»(길 위의 소금물은 ~하지 않는다). 부정하는 말 'not'이 있어요. 소금물이 쉽게 하지 않는 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Salty water stays liquid even at five degrees below zero.»(소금물은 영하 5도에서도 액체로 남아 있다.) 소금물이 추위 속에서 어떤지를 바로 앞에서 말했어요. 'stays liquid'(액체로 남아 있다)가 단서예요.",
 "3) 첫 문장 확인: «In winter, trucks drop salt on icy roads in the early morning.»(겨울에는 이른 아침에 트럭이 얼어붙은 길에 소금을 뿌린다.) 길이 얼어서 미끄러운 겨울 이야기예요. 소금을 뿌리는 것은 길이 다시 얼지 않게 하려는 것이에요.",
 "4) 묶기: 영하에서도 액체로 남아 있다 = 얼음이 되지 않는다. 그러니 소금물이 쉽게 하지 않는 일은 'freeze'(얼다)예요."],
 "「녹다」가 끌릴 수 있어요. 소금이 얼음을 녹인다는 말을 들어 보았거든요. 하지만 빈칸 문장의 주어는 얼음이 아니라 소금물이에요. 소금물은 이미 액체라서 녹을 수 없어요. 글이 말한 것은 소금물이 영하에서도 액체로 남는다는 것이에요.",
 [("금이 가다", "글과 맞지 않아요. 금이 가는 것은 단단한 얼음이에요. 빈칸 문장의 주어는 액체인 소금물이에요."),
  ("흐르다", "지문에 없는 이야기예요. 소금물이 흐르는지는 나오지 않아요. 글이 말한 것은 추위 속에서도 액체로 남는다는 것이에요."),
  ("올라가다", "지문에 없는 이야기예요. 소금물이 위로 올라간다는 말은 나오지 않아요."),
  ("얼다", "셋째 문장 «Salty water stays liquid even at five degrees below zero.»가 근거예요. 영하 5도에서도 액체로 남아 있다는 것은 쉽게 얼지 않는다는 뜻이에요."),
  ("녹다", "주어가 달라요. 녹는 것은 얼음이고, 빈칸 문장의 주어는 소금물이에요. 소금물은 이미 액체예요.")],
 ch={0: 'crack', 1: 'flow', 4: 'melt'})

# ---------- 4번째: 병을 덮은 촛불 (답 air) ----------
rw(3, 2, "Put a glass jar upside down over a small lit candle. Now no fresh air from the room can reach the flame. The flame becomes smaller and goes out after a few seconds. Even with a lot of wax, a flame cannot live without ______.",
 "불을 켠 작은 초 위에 유리병을 거꾸로 덮어 보라. 이제 방 안의 새 공기가 불꽃에 닿을 수 없다. 불꽃은 점점 작아지다가 몇 초 뒤에 꺼진다. 초가 많이 남아 있어도 불꽃은 ______ 없이는 살 수 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «a flame cannot live without»(불꽃은 ~ 없이는 살 수 없다). 'cannot'과 'without'이 함께 있어요. 불꽃에 꼭 있어야 하는 것이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Now no fresh air from the room can reach the flame.»(이제 방 안의 새 공기가 불꽃에 닿을 수 없다.) 병을 덮자 불꽃에 닿지 못하게 된 것이 나와요. 'no fresh air'(새 공기가 없음)가 단서예요.",
 "3) 셋째 문장 확인: «The flame becomes smaller and goes out after a few seconds.»(불꽃은 점점 작아지다가 몇 초 뒤에 꺼진다.) 새 공기가 끊기자 불꽃이 꺼졌어요.",
 "4) 묶기: 새 공기가 닿지 않자 불꽃이 꺼졌다 = 불꽃은 'air'(공기) 없이는 살 수 없다. 둘째 문장의 낱말이 그대로 답이에요."],
 "「초」가 끌릴 수 있어요. 초가 다 타면 불이 꺼지거든요. 하지만 빈칸 문장이 'Even with a lot of wax'(초가 많이 남아 있어도)로 시작해요. 초는 모자라지 않아요. 모자란 것은 병 때문에 들어오지 못한 새 공기예요.",
 [("초, 밀랍", "글과 맞지 않아요. 빈칸 문장이 초가 많이 남아 있어도 꺼진다고 했어요. 모자란 것은 초가 아니에요."),
  ("빛", "지문에 없는 이야기예요. 불꽃은 스스로 빛을 내요. 빛이 모자라서 꺼졌다는 말은 없어요."),
  ("공기", "둘째 문장 «Now no fresh air from the room can reach the flame.»이 근거예요. 새 공기가 닿지 않게 되자 불꽃이 꺼졌어요."),
  ("유리", "글의 낱말만 본 것이에요. 유리는 초를 덮은 병으로 나올 뿐이에요. 유리가 없어서 꺼진 것이 아니에요."),
  ("연기", "지문에 없는 이야기예요. 연기 이야기는 글에 나오지 않아요. 불꽃에 닿지 못한 것은 새 공기라고 했어요.")],
 ch={1: 'light'})

# ---------- 5번째: 이스트와 부푸는 반죽 (답 gas) ----------
rw(4, 4, "Bakers add a little yeast to the dough for soft bread. Yeast is alive and eats the sugar in the dough. It turns the sugar into gas and fills the dough with tiny bubbles. After an hour, the dough is much bigger because of the ______ in these bubbles.",
 "빵집에서는 부드러운 빵을 만들려고 반죽에 이스트를 조금 넣는다. 이스트는 살아 있어서 반죽 속의 설탕을 먹는다. 이스트는 설탕을 기체로 바꾸고 반죽을 아주 작은 거품으로 채운다. 한 시간 뒤에 반죽은 이 거품들 속의 ______ 때문에 훨씬 커진다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the dough is much bigger because of the»(반죽은 ~ 때문에 훨씬 커진다). 반죽을 부풀게 한 것, 곧 거품 속에 든 것이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «It turns the sugar into gas and fills the dough with tiny bubbles.»(이스트는 설탕을 기체로 바꾸고 반죽을 아주 작은 거품으로 채운다.) 이스트가 무엇을 만드는지가 바로 앞에 나와요. 'turns the sugar into gas'(설탕을 기체로 바꾼다)가 단서예요.",
 "3) 둘째 문장 확인: «Yeast is alive and eats the sugar in the dough.»(이스트는 살아 있어서 반죽 속의 설탕을 먹는다.) 이스트가 설탕을 먹어요. 먹은 설탕이 다음 문장에서 기체로 바뀌어요.",
 "4) 묶기: 이스트가 만든 것은 'gas'(기체)이고, 그 기체가 작은 거품이 되어 반죽을 채워요. 셋째 문장의 낱말이 그대로 답이에요."],
 "「열」이 끌릴 수 있어요. 빵은 뜨거운 오븐에서 굽거든요. 하지만 글에는 오븐도 열도 나오지 않아요. 빈칸은 이스트가 만든 거품 속에 든 것을 물어요.",
 [("소금", "지문에 없는 이야기예요. 소금은 나오지 않아요. 빈칸은 거품 속에 든 것을 물어요."),
  ("밀가루", "지문에 없는 이야기예요. 밀가루는 나오지 않아요. 빈칸은 거품 속에 든 것을 물어요."),
  ("열", "지문에 없는 이야기예요. 열이나 오븐은 나오지 않아요. 반죽을 키운 것은 이스트가 만든 기체예요."),
  ("물", "지문에 없는 이야기예요. 물은 나오지 않아요. 거품은 이스트가 설탕을 바꾸어 만든 기체로 차 있어요."),
  ("기체", "셋째 문장 «It turns the sugar into gas and fills the dough with tiny bubbles.»가 근거예요. 이스트가 설탕을 기체로 바꾸고, 그 기체가 작은 거품이 되어 반죽을 채워요.")])

# ---------- 6번째: 우주에서는 소리가 가지 못한다 (답 empty) ----------
rw(5, 2, "A sound travels to your ears through the air around you. It can also travel through water, wood and even thick walls. Between the stars, however, there is no air and no water. A sound from a star cannot travel across this almost ______ space.",
 "소리는 둘레의 공기를 지나 여러분의 귀까지 온다. 소리는 물과 나무, 심지어 두꺼운 벽도 지나갈 수 있다. 그러나 별과 별 사이에는 공기도 물도 없다. 별에서 난 소리는 거의 ______ 이 우주를 건너올 수 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «A sound from a star cannot travel across this almost»(별에서 난 소리는 이 거의 ~한 우주를 건너올 수 없다). 소리가 건너지 못하는 우주가 어떤 곳인지를 물어요. 'this'(이)는 바로 앞 문장의 별과 별 사이를 가리켜요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Between the stars, however, there is no air and no water.»(그러나 별과 별 사이에는 공기도 물도 없다.) 우주에 무엇이 없는지를 바로 앞에서 말했어요. 'no air and no water'(공기도 물도 없음)가 단서예요.",
 "3) 첫 문장 확인: «A sound travels to your ears through the air around you.»(소리는 둘레의 공기를 지나 여러분의 귀까지 온다.) 소리는 공기 같은 것을 타고 가요. 우주에는 그런 것이 없어요.",
 "4) 묶기: 공기도 물도 없다 = 아무것도 없다 = 'empty'(텅 빈). 'no air and no water'를 한 낱말로 바꾼 것이에요."],
 "「시끄러운」이 끌릴 수 있어요. 영화에서는 우주에서 큰 소리가 나거든요. 하지만 글은 별과 별 사이에 공기도 물도 없다고 했어요. 소리는 그곳을 건널 수 없으니 시끄러울 수 없어요.",
 [("시끄러운", "글과 맞지 않아요. 넷째 문장이 소리는 이 우주를 건너올 수 없다고 했어요. 소리가 갈 수 없는 곳은 시끄러울 수 없어요."),
  ("따뜻한", "지문에 없는 이야기예요. 우주가 따뜻한지 추운지는 나오지 않아요."),
  ("텅 빈", "셋째 문장 «Between the stars, however, there is no air and no water.»가 근거예요. 공기도 물도 없다는 것은 텅 비어 있다는 뜻이에요."),
  ("밝은", "지문에 없는 이야기예요. 우주의 밝기는 나오지 않아요. 글이 말한 것은 공기와 물이 없다는 것이에요."),
  ("가득 찬", "글과 반대예요. 별과 별 사이에는 공기도 물도 없다고 했어요.")],
 ch={0: 'loud', 1: 'warm', 4: 'full'})

# ---------- 7번째: 가을에 잎을 떨어뜨리는 나무 (답 water) ----------
rw(6, 1, "Many trees drop all their leaves at the end of autumn. Green leaves let a lot of water out into the air every day. In winter the roots cannot drink anything from the frozen ground. Without leaves, a tree loses very little ______ during the cold months.",
 "많은 나무가 가을이 끝날 무렵 잎을 모두 떨어뜨린다. 푸른 잎은 날마다 많은 물을 공기 속으로 내보낸다. 겨울에는 뿌리가 언 땅에서 아무것도 빨아들일 수 없다. 잎이 없으면 나무는 추운 몇 달 동안 ______을 아주 조금만 잃는다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Without leaves, a tree loses very little»(잎이 없으면 나무는 ~을 아주 조금만 잃는다). 잎이 없을 때 나무가 덜 잃게 되는 것이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Green leaves let a lot of water out into the air every day.»(푸른 잎은 날마다 많은 물을 공기 속으로 내보낸다.) 잎이 있을 때 나무에서 빠져나가는 것이 나와요. 'let a lot of water out'(많은 물을 내보낸다)이 단서예요.",
 "3) 셋째 문장 확인: «In winter the roots cannot drink anything from the frozen ground.»(겨울에는 뿌리가 언 땅에서 아무것도 빨아들일 수 없다.) 겨울에는 새 물을 얻을 수 없어요. 그래서 가진 물을 지켜야 해요.",
 "4) 묶기: 잎이 내보내는 것은 'water'(물)예요. 잎이 없으면 물이 거의 빠져나가지 않아요. 둘째 문장의 낱말이 그대로 답이에요."],
 "「빛깔」이 끌릴 수 있어요. 가을에는 잎의 빛깔이 바뀌거든요. 하지만 글에는 잎의 빛깔이 바뀐다는 이야기가 없어요. 잎이 내보낸다고 한 것은 물이에요.",
 [("빛", "지문에 없는 이야기예요. 햇빛은 나오지 않아요. 잎이 내보낸다고 한 것은 물이에요."),
  ("물", "둘째 문장 «Green leaves let a lot of water out into the air every day.»가 근거예요. 잎이 물을 내보내니, 잎이 없으면 물을 조금만 잃어요."),
  ("흙", "지문에 없는 이야기예요. 땅은 겨울에 뿌리가 아무것도 빨아들이지 못하는 곳으로 나올 뿐이에요. 나무가 흙을 잃는다는 말은 없어요."),
  ("공기", "글의 낱말만 본 것이에요. 공기는 잎이 물을 내보내는 곳으로 나올 뿐이에요. 나무가 잃는 것은 물이에요."),
  ("빛깔", "지문에 없는 이야기예요. 잎의 빛깔이 바뀐다는 말은 나오지 않아요. 나무가 잃는 것은 물이에요.")])

# ---------- 8번째: 자석의 두 극 (답 poles) ----------
rw(7, 4, "The two ends of a magnet are its north pole and south pole. Cut a long magnet into two short pieces with a strong tool. Each short piece has its own north end and south end. A magnet of any size always keeps its two ______.",
 "자석의 두 끝은 N극과 S극이다. 긴 자석을 튼튼한 도구로 잘라 짧은 두 조각으로 만들어 보라. 짧은 조각마다 자기의 북쪽 끝과 남쪽 끝이 있다. 자석은 크기가 어떻든 늘 두 ______을 지닌다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «A magnet of any size always keeps its two»(자석은 크기가 어떻든 늘 두 ~을 지닌다). 어떤 자석에나 둘씩 있는 것이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 첫 문장이에요. «The two ends of a magnet are its north pole and south pole.»(자석의 두 끝은 N극과 S극이다.) 자석에 둘 있는 것의 이름이 여기에 나와요. 'north pole and south pole'(N극과 S극)이 단서예요.",
 "3) 셋째 문장 확인: «Each short piece has its own north end and south end.»(짧은 조각마다 자기의 북쪽 끝과 남쪽 끝이 있다.) 자석을 잘라도 조각마다 두 끝이 다시 생겨요. 그래서 어떤 크기의 자석이든 둘을 다 가져요.",
 "4) 묶기: 북쪽 끝과 남쪽 끝 = 두 'poles'(극). 첫 문장의 'pole'이 그대로 답이에요."],
 "「반쪽」이 끌릴 수 있어요. 자석을 두 조각으로 자르는 이야기가 나오거든요. 하지만 반쪽은 자른 조각을 말해요. 빈칸은 자른 뒤에도 조각마다 다시 생기는 두 끝을 물어요.",
 [("금속", "지문에 없는 이야기예요. 자석이 어떤 금속으로 되어 있는지는 나오지 않아요."),
  ("빛깔", "지문에 없는 이야기예요. 자석의 빛깔은 나오지 않아요. 글이 말한 것은 북쪽 끝과 남쪽 끝이에요."),
  ("반쪽", "글의 한 부분만 본 것이에요. 자석을 두 조각으로 자르는 이야기는 있지만, 빈칸은 조각마다 다시 생기는 두 끝을 물어요."),
  ("크기", "글의 낱말만 본 것이에요. 빈칸 문장의 'size'(크기)는 크기가 어떻든이라는 뜻으로 나올 뿐이에요."),
  ("극", "첫 문장 «The two ends of a magnet are its north pole and south pole.»이 근거예요. 자석의 두 끝이 극이고, 셋째 문장은 잘라도 조각마다 두 끝이 있다고 했어요.")],
 ch={3: 'sizes'})

# ---------- 9번째: 물에 뜨는 오래된 달걀 (답 shell) ----------
rw(8, 0, "A fresh egg goes down to the bottom of a bowl of water. A very old egg stays near the top with more air inside. The hard outside of an egg has thousands of very small holes. Day after day, a little more air comes in through the ______.",
 "싱싱한 달걀은 물이 담긴 그릇의 바닥으로 내려간다. 아주 오래된 달걀은 속에 공기가 더 많아서 위쪽에 떠 있다. 달걀의 단단한 겉에는 아주 작은 구멍이 수천 개 있다. 날이 갈수록 공기가 ______를 지나 조금씩 더 들어온다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «a little more air comes in through the»(공기가 ~를 지나 조금씩 더 들어온다). 공기가 달걀 속으로 들어올 때 지나는 곳이 어디인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The hard outside of an egg has thousands of very small holes.»(달걀의 단단한 겉에는 아주 작은 구멍이 수천 개 있다.) 공기가 지나갈 구멍이 어디에 있는지를 바로 앞에서 말했어요. 'The hard outside of an egg'(달걀의 단단한 겉)가 단서예요.",
 "3) 둘째 문장 확인: «A very old egg stays near the top with more air inside.»(아주 오래된 달걀은 속에 공기가 더 많아서 위쪽에 떠 있다.) 오래된 달걀 속에는 공기가 많아요. 그 공기가 구멍으로 들어온 것이에요.",
 "4) 묶기: 달걀의 단단한 겉 = 'shell'(껍데기). 'The hard outside of an egg'를 한 낱말로 바꾼 것이에요."],
 "「흰자」가 끌릴 수 있어요. 달걀 하면 흰자와 노른자가 떠오르거든요. 하지만 흰자와 노른자는 달걀의 속이에요. 구멍이 있다고 한 곳은 달걀의 단단한 겉이에요.",
 [("껍데기", "셋째 문장 «The hard outside of an egg has thousands of very small holes.»가 근거예요. 달걀의 단단한 겉이 껍데기이고, 거기에 있는 작은 구멍으로 공기가 들어와요."),
  ("물", "글의 낱말만 본 것이에요. 물은 달걀을 담근 그릇에 든 것으로 나올 뿐이에요. 구멍이 있는 곳은 달걀의 단단한 겉이에요."),
  ("노른자", "글과 맞지 않아요. 노른자는 달걀의 속이에요. 구멍이 있다고 한 곳은 단단한 겉이에요."),
  ("흰자", "글과 맞지 않아요. 흰자는 달걀의 속이에요. 구멍이 있다고 한 곳은 단단한 겉이에요."),
  ("바닥", "글의 낱말만 본 것이에요. 바닥은 싱싱한 달걀이 내려가는 그릇의 바닥으로 나올 뿐이에요. 구멍이 있는 곳은 달걀의 단단한 겉이에요.")],
 ch={1: 'water', 4: 'bottom'})

# ---------- 10번째: 젖은 수건이 시원한 까닭 (답 heat) ----------
rw(9, 0, "On a hot day, put a wet towel on your arm. The water slowly goes from the towel into the warm air. Soon the skin under the wet towel feels much cooler than before. On its way into the air, the water takes ______ from your skin.",
 "더운 날, 젖은 수건을 팔에 올려 보라. 물은 수건에서 따뜻한 공기 속으로 천천히 빠져나간다. 곧 젖은 수건 아래의 살갗이 전보다 훨씬 시원하게 느껴진다. 물은 공기 속으로 가면서 살갗에서 ______을 가져간다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «On its way into the air, the water takes»(공기 속으로 가면서 물은 ~을 가져간다). 물이 살갗에서 가져가는 것이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Soon the skin under the wet towel feels much cooler than before.»(곧 젖은 수건 아래의 살갗이 전보다 훨씬 시원하게 느껴진다.) 물이 빠져나간 뒤 살갗이 어떻게 되는지를 바로 앞에서 말했어요. 'feels much cooler'(훨씬 시원하게 느껴진다)가 단서예요.",
 "3) 둘째 문장 확인: «The water slowly goes from the towel into the warm air.»(물은 수건에서 따뜻한 공기 속으로 천천히 빠져나간다.) 수건이 마르는 것이에요.",
 "4) 묶기: 살갗이 시원해졌다 = 살갗의 더운 기운이 줄었다. 물이 가져간 것은 'heat'(열)예요."],
 "「때」가 끌릴 수 있어요. 젖은 수건은 몸을 닦을 때 쓰거든요. 하지만 닦는 이야기는 글에 없어요. 글이 말한 것은 살갗이 훨씬 시원해졌다는 것이에요.",
 [("열", "셋째 문장 «Soon the skin under the wet towel feels much cooler than before.»가 근거예요. 살갗이 시원해졌다는 것은 물이 살갗의 열을 가져갔다는 뜻이에요."),
  ("빛깔", "지문에 없는 이야기예요. 살갗의 빛깔은 나오지 않아요."),
  ("무게", "지문에 없는 이야기예요. 무게는 나오지 않아요. 글이 말한 것은 살갗이 시원해졌다는 것이에요."),
  ("공기", "글의 낱말만 본 것이에요. 공기는 물이 빠져나가는 곳으로 나올 뿐이에요. 물이 살갗에서 가져가는 것이 아니에요."),
  ("때, 먼지", "지문에 없는 이야기예요. 몸을 닦는 일은 나오지 않아요. 글이 말한 것은 살갗이 시원해졌다는 것이에요.")])

# ---------- 11번째: 눈이 하얀 까닭 (답 spread — scatter에서 바꿈) ----------
rw(10, 0, "A piece of ice is clear, like the glass of a window. White snow is also ice, in millions of very small pieces. Every small piece faces a different way and sends light back like a mirror. Together the millions of pieces ______ the sunlight in every direction.",
 "얼음 한 조각은 창문의 유리처럼 맑다. 하얀 눈도 얼음인데, 아주 작은 조각 수백만 개로 되어 있다. 작은 조각마다 서로 다른 쪽을 보면서 거울처럼 빛을 되돌려 보낸다. 수백만 개의 조각이 함께 햇빛을 모든 쪽으로 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the sunlight in every direction»(햇빛을 모든 쪽으로). 눈의 작은 조각들이 햇빛을 모든 쪽으로 어떻게 하는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Every small piece faces a different way and sends light back like a mirror.»(작은 조각마다 서로 다른 쪽을 보면서 거울처럼 빛을 되돌려 보낸다.) 조각 하나가 빛을 어떻게 하는지를 바로 앞에서 말했어요. 'faces a different way'(서로 다른 쪽을 본다)와 'sends light back'(빛을 되돌려 보낸다)이 단서예요.",
 "3) 둘째 문장 확인: «White snow is also ice, in millions of very small pieces.»(하얀 눈도 얼음인데, 아주 작은 조각 수백만 개로 되어 있다.) 조각이 수백만 개예요.",
 "4) 묶기: 수백만 개의 조각이 저마다 다른 쪽으로 빛을 돌려보낸다 = 빛을 사방으로 'spread'(퍼뜨리다). 그래서 눈은 맑지 않고 하얗게 보여요."],
 "「막다」가 끌릴 수 있어요. 눈은 얼음과 달리 속이 비쳐 보이지 않으니, 빛을 막는다고 생각하기 쉽거든요. 하지만 글은 조각마다 거울처럼 빛을 되돌려 보낸다고 했어요. 막는 것이 아니라 여러 쪽으로 보내는 것이에요.",
 [("퍼뜨리다", "셋째 문장 «Every small piece faces a different way and sends light back like a mirror.»가 근거예요. 수백만 개의 조각이 저마다 다른 쪽으로 빛을 돌려보내면 빛은 모든 쪽으로 퍼져요."),
  ("마시다", "글과 맞지 않아요. 조각들은 빛을 빨아들이지 않고 거울처럼 되돌려 보낸다고 했어요."),
  ("간직하다", "글과 맞지 않아요. 조각들은 빛을 가지고 있지 않고 되돌려 보낸다고 했어요."),
  ("막다", "글과 맞지 않아요. 조각들은 빛을 막는 것이 아니라 거울처럼 되돌려 보낸다고 했어요."),
  ("숨기다", "글과 맞지 않아요. 조각들은 빛을 숨기지 않고 되돌려 보낸다고 했어요.")],
 ch={0: 'spread', 1: 'drink', 2: 'keep', 3: 'stop', 4: 'hide'})

# ---------- 12번째: 박쥐의 사냥 (답 echo) ----------
rw(11, 3, "A bat flies fast through the trees on a dark night. It makes a short, high sound many times every second. The sound hits a small insect and comes back as an echo. With its big ears, the bat finds its dinner by the ______.",
 "박쥐는 어두운 밤에 나무 사이를 빠르게 난다. 박쥐는 짧고 높은 소리를 일 초에 여러 번 낸다. 그 소리는 작은 벌레에 부딪혀 메아리가 되어 돌아온다. 박쥐는 큰 귀를 써서 ______로 저녁거리를 찾는다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With its big ears, the bat finds its dinner by the»(큰 귀를 써서 박쥐는 ~로 저녁거리를 찾는다). 박쥐가 귀로 듣고 먹이를 찾는 데 쓰는 것이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The sound hits a small insect and comes back as an echo.»(그 소리는 작은 벌레에 부딪혀 메아리가 되어 돌아온다.) 박쥐에게 돌아오는 것이 바로 앞에 나와요. 'comes back as an echo'(메아리가 되어 돌아온다)가 단서예요.",
 "3) 첫 문장 확인: «A bat flies fast through the trees on a dark night.»(박쥐는 어두운 밤에 나무 사이를 빠르게 난다.) 어두운 밤이라 눈으로는 잘 볼 수 없어요. 그래서 귀를 써요.",
 "4) 묶기: 벌레에 부딪혀 돌아오는 소리 = 'echo'(메아리). 셋째 문장의 낱말이 그대로 답이에요."],
 "「냄새」가 끌릴 수 있어요. 냄새로 먹이를 찾는 동물이 많거든요. 하지만 빈칸 문장은 'With its big ears'(큰 귀를 써서)로 시작해요. 귀로 듣는 것은 냄새가 아니라 돌아오는 소리예요.",
 [("바람", "지문에 없는 이야기예요. 바람은 나오지 않아요. 박쥐가 귀로 듣는 것은 돌아오는 소리예요."),
  ("빛", "글과 맞지 않아요. 어두운 밤이라고 했어요. 박쥐는 눈이 아니라 귀를 써요."),
  ("냄새", "글과 맞지 않아요. 박쥐는 큰 귀를 쓴다고 했어요. 냄새는 귀로 맡지 않아요."),
  ("메아리", "셋째 문장 «The sound hits a small insect and comes back as an echo.»가 근거예요. 벌레에 부딪혀 돌아오는 소리가 메아리이고, 박쥐는 그것을 귀로 들어요."),
  ("음악", "지문에 없는 이야기예요. 박쥐가 내는 것은 짧고 높은 소리이지 음악이 아니에요.")])

# ---------- 13번째: 물속에서 꺾여 보이는 연필 (답 direction) ----------
rw(12, 2, "A straight pencil in a glass of water looks strangely bent. Out of the water, the same pencil is perfectly straight again. Light goes straight in water and then bends at the top of the water. On its way out of the water, light changes its ______.",
 "물이 든 유리잔 속의 곧은 연필은 이상하게 꺾여 보인다. 물 밖으로 꺼내면 같은 연필이 다시 아주 반듯하다. 빛은 물속에서 곧게 가다가 물의 맨 위에서 꺾인다. 물 밖으로 나오면서 빛은 ______을 바꾼다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «On its way out of the water, light changes its»(물 밖으로 나오면서 빛은 자기의 ~을 바꾼다). 빛이 물에서 나올 때 무엇이 바뀌는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Light goes straight in water and then bends at the top of the water.»(빛은 물속에서 곧게 가다가 물의 맨 위에서 꺾인다.) 빛이 물의 맨 위에서 어떻게 되는지를 바로 앞에서 말했어요. 'goes straight'(곧게 간다)와 'bends'(꺾인다)가 단서예요.",
 "3) 첫 문장 확인: «A straight pencil in a glass of water looks strangely bent.»(물이 든 유리잔 속의 곧은 연필은 이상하게 꺾여 보인다.) 연필이 꺾여 보이는 것은 빛이 꺾였기 때문이에요.",
 "4) 묶기: 곧게 가다가 꺾인다 = 가는 쪽이 바뀐다 = 'direction'(방향)을 바꾼다."],
 "「크기」가 끌릴 수 있어요. 물속의 물건은 실제보다 커 보이기도 하거든요. 하지만 글은 연필이 커 보인다고 하지 않고 꺾여 보인다고 했어요. 바뀐 것은 빛이 가는 쪽이에요.",
 [("온도", "지문에 없는 이야기예요. 차갑고 뜨거운 것은 나오지 않아요."),
  ("밝기", "지문에 없는 이야기예요. 밝기가 바뀐다는 말은 없어요. 글이 말한 것은 빛이 꺾인다는 것이에요."),
  ("방향", "셋째 문장 «Light goes straight in water and then bends at the top of the water.»가 근거예요. 곧게 가다가 꺾인다는 것은 가는 방향이 바뀐다는 뜻이에요."),
  ("크기", "지문에 없는 이야기예요. 크기는 나오지 않아요. 연필은 커 보이는 것이 아니라 꺾여 보여요."),
  ("무게", "지문에 없는 이야기예요. 무게는 나오지 않아요.")])


# ---------- 14번째: 상하지 않는 꿀 (답 water) ----------
rw(13, 3, "A closed jar of honey can stay good for hundreds of years. Food usually goes bad because of very small living things. These small living things cannot grow in a very dry place. Thick honey is safe from them with very little ______ in it.",
 "뚜껑을 닫은 꿀 한 병은 수백 년 동안 상하지 않을 수 있다. 음식은 보통 아주 작은 생물들 때문에 상한다. 이 작은 생물들은 아주 메마른 곳에서는 자랄 수 없다. 걸쭉한 꿀은 속에 ______이 아주 적어서 그 생물들로부터 안전하다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thick honey is safe from them with very little»(걸쭉한 꿀은 ~이 아주 적어서 그것들로부터 안전하다). 꿀 속에 아주 적게 든 것이 무엇인지를 물어요. 'them'은 작은 생물들이에요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «These small living things cannot grow in a very dry place.»(이 작은 생물들은 아주 메마른 곳에서는 자랄 수 없다.) 작은 생물들이 자랄 수 없는 곳이 바로 앞에 나와요. 'a very dry place'(아주 메마른 곳)가 단서예요.",
 "3) 둘째 문장 확인: «Food usually goes bad because of very small living things.»(음식은 보통 아주 작은 생물들 때문에 상한다.) 작은 생물이 못 자라면 음식이 상하지 않아요.",
 "4) 묶기: 메마른 곳 = 'water'(물)가 거의 없는 곳. 꿀에는 물이 아주 적어서 작은 생물이 자랄 수 없어요."],
 "「공기」가 끌릴 수 있어요. 병에 담긴 음식은 공기가 닿지 않아야 오래간다고 들었거든요. 하지만 글에는 공기 이야기가 없어요. 글이 말한 것은 작은 생물들이 메마른 곳에서 자랄 수 없다는 것이에요.",
 [("설탕", "지문에 없는 이야기예요. 설탕이나 단맛은 나오지 않아요. 글이 말한 것은 작은 생물들이 메마른 곳에서 자랄 수 없다는 것이에요."),
  ("공기", "지문에 없는 이야기예요. 공기는 나오지 않아요. 작은 생물들이 자랄 수 없다고 한 곳은 메마른 곳이에요."),
  ("빛깔", "지문에 없는 이야기예요. 꿀의 빛깔은 나오지 않아요."),
  ("물", "셋째 문장 «These small living things cannot grow in a very dry place.»가 근거예요. 메마르다는 것은 물이 거의 없다는 뜻이에요. 꿀에는 물이 아주 적어요."),
  ("빛", "지문에 없는 이야기예요. 빛은 나오지 않아요.")],
 ch={0: 'sugar', 2: 'colour'})

# ---------- 15번째: 거북의 등딱지 (답 bones) ----------
rw(14, 4, "In some cartoons, a tortoise leaves its shell like a little house. A real tortoise can never do this in its whole life. The shell grows from the hard parts inside its back and chest. In fact, the shell of a tortoise is made of its own ______.",
 "어떤 만화에서는 거북이 작은 집에서 나오듯 등딱지에서 나온다. 진짜 거북은 평생 한 번도 그렇게 할 수 없다. 등딱지는 등과 가슴 속의 단단한 부분에서 자라난다. 사실 거북의 등딱지는 거북 자신의 ______로 되어 있다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the shell of a tortoise is made of its own»(거북의 등딱지는 자기 자신의 ~로 되어 있다). 등딱지가 무엇으로 되어 있는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The shell grows from the hard parts inside its back and chest.»(등딱지는 등과 가슴 속의 단단한 부분에서 자라난다.) 등딱지가 어디에서 자라는지를 바로 앞에서 말했어요. 'the hard parts inside its back and chest'(등과 가슴 속의 단단한 부분)가 단서예요.",
 "3) 둘째 문장 확인: «A real tortoise can never do this in its whole life.»(진짜 거북은 평생 한 번도 그렇게 할 수 없다.) 등딱지는 벗을 수 있는 집이 아니에요. 몸에 붙어 있어요.",
 "4) 묶기: 몸속의 단단한 부분 = 'bones'(뼈). 'the hard parts inside its back and chest'를 한 낱말로 바꾼 것이에요."],
 "「알」이 끌릴 수 있어요. 영어로는 알의 껍데기도 'shell'이라고 하거든요. 하지만 글에는 알 이야기가 없어요. 등딱지가 자라나는 곳은 등과 가슴 속의 단단한 부분이라고 했어요.",
 [("이빨", "지문에 없는 이야기예요. 이빨은 나오지 않아요. 등딱지가 자라나는 곳은 등과 가슴 속이라고 했어요."),
  ("알", "지문에 없는 이야기예요. 알은 나오지 않아요. 등딱지는 등과 가슴 속의 단단한 부분에서 자란다고 했어요."),
  ("먹이", "지문에 없는 이야기예요. 먹이는 나오지 않아요."),
  ("발", "글과 맞지 않아요. 등딱지가 자라나는 곳은 발이 아니라 등과 가슴 속이라고 했어요."),
  ("뼈", "셋째 문장 «The shell grows from the hard parts inside its back and chest.»가 근거예요. 몸속의 단단한 부분이 뼈이고, 등딱지는 거기에서 자라나요.")],
 ch={0: 'teeth', 1: 'eggs', 3: 'feet'})
