# -*- coding: utf-8 -*-
# 342번: 30번(어휘) 레벨1 앞 절반 — 다섯 문장(문장당 10~15낱말 · 단문) · 문맥에 맞지 않는 낱말 하나. 정답 번호는 바탕 그대로, 지문·해석·풀이·해설·올바른 말(correctWord)을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z30rw import maker
rw = maker(E)

# 1번째
rw(0,
   ['Tom was very ①happy on the morning of his tenth birthday.',
 'He ②frowned at the shiny new soccer ball from his father.',
 'His friends were ③glad to see such a nice gift.',
 'They ④kicked it around the park all afternoon with great joy.',
 'That night, Tom felt ⑤thankful for his father and his new ball.'],
   'smiled',
   ['톰은 열 번째 생일 아침에 아주 기뻤다.', '그는 아버지가 준 반짝이는 새 축구공을 보고 얼굴을 찌푸렸다(→ 웃었다).', '그의 친구들은 그렇게 멋진 선물을 보고 기뻐했다.', '그들은 오후 내내 아주 즐겁게 공원에서 그 공을 이리저리 찼다.', '그날 밤 톰은 아버지와 새 공에 고마움을 느꼈다.'],
   ['기쁜', '얼굴을 찌푸렸다', '기쁜', '찼다', '고마운'],
   ['생일 아침이니 기쁜 마음이 문맥에 맞아요.', '앞에서 아주 기뻤다고 했으니 얼굴을 찌푸리는 것은 반대예요. 원래는 smiled(웃었다)가 알맞아요.', '친구들도 선물을 보고 기뻐하는 장면이라 맞아요.', '오후 내내 즐겁게 놀았다는 내용이라 맞아요.', '아버지와 새 공이 고마웠다는 내용이라 맞아요.'],
   'frown 얼굴을 찌푸리다 / shiny 반짝이는 / thankful 고마워하는 / tenth 열 번째의')

# 2번째
rw(1,
   ["It was a ①snowy morning on the hill near Mia's house.",
 'Her small fingers felt ②hot inside her thin wool gloves all morning.',
 'Mia ③pulled a thick red hat down over her ears.',
 'The ④deep white snow made every step slow and hard.',
 'At home, a ⑤warm cup of milk was waiting for her.'],
   'cold',
   ['미아의 집 근처 언덕에 눈이 내리는 아침이었다.', '그녀의 작은 손가락은 얇은 털장갑 속에서 아침 내내 뜨겁게(→ 차갑게) 느껴졌다.', '미아는 두툼한 빨간 모자를 귀를 덮도록 푹 눌러썼다.', '깊이 쌓인 하얀 눈 때문에 걸음마다 느리고 힘들었다.', '집에는 따뜻한 우유 한 잔이 그녀를 기다리고 있었다.'],
   ['눈이 내리는', '뜨거운', '끌어내렸다', '깊은', '따뜻한'],
   ['언덕에 눈이 내리는 날씨라 문맥에 맞아요.',
 '눈 오는 아침에 얇은 장갑을 꼈으니 손가락이 뜨거운 것은 어울리지 않아요. 원래는 cold(차갑게)가 알맞아요.',
 '추운 날 모자로 귀를 덮었으니 맞아요.',
 '눈이 깊게 쌓여 걸음이 느리고 힘들었다는 내용이라 맞아요.',
 '추운 아침을 보내고 집에 오니 따뜻한 우유가 기다리고 있다는 내용이라 맞아요.'],
   'snowy 눈이 내리는 / glove 장갑 / wool 털(양모) / pull ~ down ~을 아래로 끌어내리다')

# 3번째
rw(2,
   ["The airport was ①empty at six o'clock in the morning.",
 'Our family arrived ②late at the airport, long before the first plane.',
 'We ③waited on soft chairs near a big window with Grandma.',
 'The sky ④turned pink over the long gray runway at last.',
 'Soon our big plane ⑤rose into the bright morning sky.'],
   'early',
   ['아침 여섯 시의 공항은 텅 비어 있었다.', '우리 가족은 첫 비행기보다 한참 전에 공항에 늦게(→ 일찍) 도착했다.', '우리는 할머니와 함께 큰 창가의 푹신한 의자에서 기다렸다.', '마침내 길고 회색인 활주로 위로 하늘이 분홍빛으로 변했다.', '곧 우리의 큰 비행기가 밝은 아침 하늘로 떠올랐다.'],
   ['텅 빈', '늦게', '기다렸다', '변했다', '떠올랐다'],
   ['아침 여섯 시의 공항이 텅 비어 있다는 내용이라 맞아요.', '첫 비행기보다 한참 전에 도착했으니 늦게라고 하면 앞뒤가 안 맞아요. 원래는 early(일찍)가 알맞아요.', '비행기를 기다리는 모습이라 맞아요.', '이른 아침이라 하늘이 분홍빛으로 변한다는 내용이라 맞아요.', '비행기가 이륙해 하늘로 올라가는 장면이라 맞아요.'],
   'airport 공항 / runway 활주로 / plane 비행기 / turn pink 분홍빛으로 변하다')

# 4번째
rw(3,
   ["The school race started at ten o'clock on a ①sunny Saturday.",
 'With ②slow steps, Eli reached the finish line before every other runner.',
 'The crowd on the hill ③cheered loudly for the happy winner.',
 'His coach ④gave him a shiny gold medal and a hug.',
 "Eli's mother was very ⑤proud of her son that day."],
   'quick',
   ['학교 달리기 경기는 화창한 토요일 열 시에 시작했다.', '일라이는 느린(→ 빠른) 걸음으로 다른 모든 주자보다 먼저 결승선에 닿았다.', '언덕 위의 관중은 기뻐하는 우승자에게 큰 소리로 환호했다.', '코치는 그에게 반짝이는 금메달을 주고 꼭 안아 주었다.', '그날 일라이의 어머니는 아들이 아주 자랑스러웠다.'],
   ['화창한', '느린', '환호했다', '주었다', '자랑스러운'],
   ['날씨가 좋은 토요일이라 경기가 열리기에 맞아요.', '다른 주자보다 먼저 들어왔으니 느린 걸음은 어울리지 않아요. 원래는 quick(빠른)이 알맞아요.', '우승자에게 환호하는 장면이라 맞아요.', '우승했으니 금메달을 받는 장면이라 맞아요.', '아들이 우승했으니 자랑스러웠다는 내용이라 맞아요.'],
   'race 달리기 경기 / finish line 결승선 / runner 주자 / medal 메달')

# 5번째
rw(4,
   ['The new bakery on Elm Street is ①famous for its fresh bread.',
 'At noon the small shop is ②empty, with a long line outside.',
 'Every customer ③buys a warm roll with butter and jam.',
 'The baker ④works very hard from five in the morning.',
 'By evening, almost every ⑤loaf is gone from the shelves.'],
   'crowded',
   ['엘름가의 새 빵집은 갓 구운 빵으로 유명하다.', '정오에 그 작은 가게 안은 텅 비고(→ 붐비고), 바깥에는 긴 줄이 서 있다.', '손님마다 따뜻한 롤빵을 버터와 잼과 함께 산다.', '제빵사는 새벽 다섯 시부터 아주 열심히 일한다.', '저녁이면 거의 모든 빵이 선반에서 사라진다.'],
   ['유명한', '텅 빈', '산다', '일한다', '빵 한 덩이'],
   ['신선한 빵으로 유명하다는 내용이라 맞아요.', '바깥에 긴 줄이 서 있으니 가게 안이 텅 비었다고 하면 어울리지 않아요. 원래는 crowded(붐비는)가 알맞아요.', '손님이 빵을 사 가는 모습이라 맞아요.', '새벽부터 빵을 구우려면 열심히 일해야 하니 맞아요.', '손님이 많아 저녁에는 빵이 거의 다 팔렸다는 내용이라 맞아요.'],
   'bakery 빵집 / loaf 빵 한 덩이 / butter 버터 / jam 잼')

# 6번째
rw(5,
   ["Lena's ①mother asked her to clean her room on Saturday.",
 'Soon the floor looked ②messy, with no toys on it.',
 'Her books ③stood in a neat line on the shelf.',
 'Her bed was ④made with a soft blue blanket and pillow.',
 'Her mother gave her a ⑤big smile and a sweet snack.'],
   'tidy',
   ['레나의 어머니는 토요일에 레나에게 방을 청소하라고 하셨다.', '곧 바닥은 장난감 하나 없이 어질러져(→ 깔끔해) 보였다.', '그녀의 책들은 선반 위에 줄을 맞추어 가지런히 꽂혀 있었다.', '그녀의 침대는 부드러운 파란 담요와 베개로 정돈되어 있었다.', '어머니는 그녀에게 큰 미소와 달콤한 간식을 주셨다.'],
   ['어머니', '어질러진', '꽂혀 있었다', '정돈된', '큰'],
   ['방을 청소하라고 한 사람이 어머니이니 맞아요.', '방을 치우고 있으니 바닥이 어질러져 보인다는 것은 반대예요. 원래는 tidy(깔끔한)가 알맞아요.', '책이 선반에 줄 맞춰 가지런히 꽂혀 있으니 맞아요.', '침대도 깔끔하게 정돈된 모습이라 맞아요.', '방을 깨끗이 치웠으니 어머니가 환하게 웃어 주는 장면이라 맞아요.'],
   'messy 어질러진 / tidy 깔끔한 / neat 가지런한 / blanket 담요')

# 7번째
rw(6,
   ['Mina left her blue umbrella on the ①bus on Monday.',
 'She ②looked for it at home and at school all week long.',
 'On Friday, a kind bus driver ③called the school office about it.',
 'Mina was ④sad to get her blue umbrella back at last.',
 'Later, Mina ⑤thanked the kind driver with a small card.'],
   'happy',
   ['미나는 월요일에 파란 우산을 버스에 두고 내렸다.', '미나는 일주일 내내 집과 학교에서 그것을 찾아다녔다.', '금요일에 친절한 버스 기사님이 그것에 대해 학교 사무실로 전화하셨다.', '미나는 파란 우산을 마침내 돌려받게 되어 슬펐다(→ 기뻤다).', '나중에 미나는 작은 카드로 친절한 기사님께 고마움을 전했다.'],
   ['버스', '찾았다', '전화했다', '슬픈', '고마워했다'],
   ['우산을 버스에 두고 내렸다는 내용이라 맞아요.',
 '우산을 잃어버렸으니 일주일 내내 찾아다녔다는 내용이라 맞아요.',
 '버스 기사님이 학교에 전화해 우산을 찾아 주었다는 내용이라 맞아요.',
 '일주일 동안 찾던 우산을 마침내 받았으니 슬프다는 것은 반대예요. 원래는 happy(기쁜)가 알맞아요.',
 '우산을 찾아 준 기사님께 고마워하는 장면이라 맞아요.'],
   'umbrella 우산 / driver 운전사(기사) / office 사무실 / thank 고마워하다')

# 8번째
rw(7,
   ['Sam studies in the school ①library every day after class.',
 'Everyone there ②reads at the long wooden tables by the window.',
 'A sign on the wall ③asks students to stay silent.',
 'Sam loves the ④loud room for its calm, peaceful feeling.',
 'He ⑤finishes his math homework there before dinner every single day.'],
   'quiet',
   ['샘은 날마다 방과 후에 학교 도서관에서 공부한다.', '그곳의 모두가 창가의 긴 나무 탁자에서 책을 읽는다.', '벽에 붙은 표지판은 학생들에게 조용히 있어 달라고 부탁한다.', '샘은 그 시끄러운(→ 조용한) 방의 차분하고 평화로운 느낌이 좋다.', '그는 매일 저녁 식사 전에 그곳에서 수학 숙제를 끝낸다.'],
   ['도서관', '읽는다', '부탁한다', '시끄러운', '끝낸다'],
   ['공부하는 장소가 도서관이라 맞아요.', '도서관에서는 탁자에 앉아 책을 읽으니 맞아요.', '조용히 있어 달라고 부탁하는 표지판이라 맞아요.', '표지판이 조용히 하라고 하고 느낌도 차분하고 평화롭다고 했으니 시끄럽다는 것은 반대예요. 원래는 quiet(조용한)가 알맞아요.', '도서관에서 숙제를 끝낸다는 내용이라 맞아요.'],
   'library 도서관 / silent 조용한 / peaceful 평화로운 / homework 숙제')

# 9번째
rw(8,
   ['On land, sea turtles are very ①slow animals with heavy shells.',
 'Their thick shells ②protect them from hungry sharks in the sea.',
 'On the beach, a mother turtle ③digs a deep hole for her eggs.',
 'Then she crawls ④quickly across the warm sand back to the water.',
 'Her eggs stay ⑤safe under the sand for two months.'],
   'slowly',
   ['육지에서 바다거북은 무거운 등딱지를 진 아주 느린 동물이다.', '두꺼운 등딱지는 바다에서 배고픈 상어로부터 거북을 지켜 준다.', '해변에서 어미 거북은 알을 위해 깊은 구멍을 판다.', '그다음 어미 거북은 따뜻한 모래밭을 가로질러 다시 바다로 빠르게(→ 천천히) 기어간다.', '알은 두 달 동안 모래 속에서 안전하게 있다.'],
   ['느린', '지켜 준다', '판다', '빠르게', '안전한'],
   ['거북은 육지에서 느리다는 내용이라 맞아요.', '두꺼운 등딱지가 상어로부터 거북을 지켜 주니 맞아요.', '알을 낳기 위해 모래에 구멍을 파는 모습이라 맞아요.', '육지에서 아주 느린 동물이라고 했으니 빠르게 기어간다는 것은 반대예요. 원래는 slowly(천천히)가 알맞아요.', '알이 모래 속에 있으니 안전하다는 내용이라 맞아요.'],
   'turtle 거북 / shell 등딱지(껍데기) / shark 상어 / crawl 기어가다')

# 10번째
rw(9,
   ['Jina went to the ①market with her grandmother on Sunday.',
 'Fresh red apples were ②piled high on a long table.',
 'Grandmother ③bought three big bags of them for her family.',
 'Each big paper bag was very ④expensive at only two dollars.',
 'At home, they ⑤made a sweet apple pie for dessert.'],
   'cheap',
   ['지나는 일요일에 할머니와 함께 시장에 갔다.', '싱싱한 빨간 사과가 긴 탁자 위에 높이 쌓여 있었다.', '할머니는 가족을 위해 사과를 큰 봉지로 세 봉지 사셨다.', '큰 종이봉투 하나가 겨우 2달러여서 아주 비쌌다(→ 쌌다).', '집에서 그들은 후식으로 달콤한 사과 파이를 만들었다.'],
   ['시장', '쌓여 있었다', '샀다', '비싼', '만들었다'],
   ['할머니와 함께 장을 보러 간 곳이 시장이라 맞아요.', '사과를 높이 쌓아 놓고 파는 시장 풍경이라 맞아요.', '시장에서 사과를 샀다는 내용이라 맞아요.', '겨우 2달러라고 했으니 비싸다는 것은 앞뒤가 안 맞아요. 원래는 cheap(싼)이 알맞아요.', '산 사과로 파이를 만들었다는 내용이라 맞아요.'],
   'market 시장 / pile 쌓다 / dollar 달러 / dessert 후식')

# 11번째
rw(10,
   ["Dan's grandmother lives on the ①top floor of an old building.",
 'The old building has no ②elevator, only a long dark stairway.',
 'Dan ③carried her big bags of rice up the stairs.',
 'After ten floors, the bags felt ④light in his tired arms.',
 'His grandmother ⑤thanked him with a big hug at the door.'],
   'heavy',
   ['댄의 할머니는 오래된 건물의 맨 위층에 사신다.', '그 오래된 건물에는 엘리베이터가 없고 길고 어두운 계단뿐이다.', '댄은 할머니의 큰 쌀 포대를 들고 계단을 올라갔다.', '열 층을 올라가고 나니 지친 팔에 포대가 가볍게(→ 무겁게) 느껴졌다.', '할머니는 문 앞에서 그를 꼭 안아 주며 고마워하셨다.'],
   ['맨 위의', '엘리베이터', '들고 갔다', '가벼운', '고마워했다'],
   ['할머니가 오래된 건물 맨 위층에 산다는 내용이라 맞아요.',
 '건물에 엘리베이터가 없어서 계단만 있다는 내용이라 맞아요.',
 '쌀 포대를 들고 계단을 올랐다는 내용이라 맞아요.',
 '열 층을 오른 뒤 지친 팔에 쌀 포대가 가볍다는 것은 어울리지 않아요. 원래는 heavy(무겁게)가 알맞아요.',
 '포대를 날라 준 댄에게 할머니가 고마워하는 장면이라 맞아요.'],
   'elevator 엘리베이터 / stairway 계단 / floor 층 / rice 쌀')

# 12번째
rw(11,
   ['The school soccer team played its final game of the ①season.',
 'Both teams ②ran hard on the wet green field for ninety minutes.',
 'In the last minute, our best player ③kicked the ball into the net.',
 'Our fans in the crowded seats ④booed the winning goal.',
 'After the long game, the players ⑤shook hands on the field.'],
   'cheered',
   ['학교 축구팀은 이번 시즌의 마지막 경기를 치렀다.', '양 팀은 젖은 초록 운동장에서 90분 동안 열심히 달렸다.', '경기 마지막 순간에 우리 팀의 가장 뛰어난 선수가 공을 골망 안으로 찼다.', '붐비는 관중석의 우리 팬들은 결승골에 야유를 보냈다(→ 환호했다).', '긴 경기가 끝난 뒤 선수들은 운동장에서 악수를 나누었다.'],
   ['시즌', '달렸다', '찼다', '야유를 보냈다', '악수했다'],
   ['시즌의 마지막 경기라는 내용이라 맞아요.', '경기 중에 선수들이 열심히 뛰는 모습이라 맞아요.', '마지막 순간에 골을 넣는 장면이라 맞아요.', '우리 팀이 결승골을 넣었으니 우리 팬이 야유를 보낸다는 것은 반대예요. 원래는 cheered(환호했다)가 알맞아요.', '경기가 끝난 뒤 선수들이 악수하는 장면이라 맞아요.'],
   'season 시즌(한 철) / net 골망(그물) / boo 야유를 보내다 / cheer 환호하다')

# 13번째
rw(12,
   ['Zoe felt very ①calm before her first big piano concert.',
 'Her hands ②shook badly on the way to the big stage.',
 'Her teacher ③smiled kindly at her from the front row.',
 'Zoe ④took a long deep breath at the grand piano.',
 'The music ⑤filled the whole hall with a soft sound.'],
   'nervous',
   ['조이는 첫 큰 피아노 연주회를 앞두고 아주 차분했다(→ 긴장했다).', '그녀의 손은 큰 무대로 가는 길에 심하게 떨렸다.', '선생님은 맨 앞줄에서 그녀를 보고 다정하게 미소 지으셨다.', '조이는 그랜드 피아노 앞에서 길고 깊은 숨을 들이쉬었다.', '음악이 부드러운 소리로 홀 전체를 가득 채웠다.'],
   ['차분한', '떨렸다', '미소 지었다', '들이쉬었다', '채웠다'],
   ['손이 큰 무대로 가는 길에 심하게 떨렸다고 했으니 차분하다는 것은 어울리지 않아요. 원래는 nervous(긴장한)가 알맞아요.', '긴장해서 손이 떨리는 모습이라 맞아요.', '선생님이 응원하듯 미소 짓는 장면이라 맞아요.', '연주를 앞두고 깊은 숨을 들이쉬는 모습이라 맞아요.', '연주가 시작되어 음악이 홀을 채우는 장면이라 맞아요.'],
   'concert 연주회 / shake 떨리다 / breath 숨 / grand piano 그랜드 피아노')

# 14번째
rw(13,
   ['A ①heavy white fog covered the whole town this morning.',
 'Many drivers ②turned on their lights on the main road.',
 'The traffic ③moved slowly through the white mist near the bridge.',
 'Nobody on the busy street could ④see more than a few meters.',
 'By noon, the fog was still too ⑤thin to see through.'],
   'thick',
   ['오늘 아침 짙은 하얀 안개가 온 마을을 덮었다.', '많은 운전자가 큰길에서 전조등을 켰다.', '차들은 다리 근처의 하얀 안갯속을 천천히 움직였다.', '붐비는 길에서는 아무도 몇 미터 앞밖에 볼 수 없었다.', '정오에도 안개는 여전히 너무 옅어서(→ 짙어서) 꿰뚫어 볼 수 없었다.'],
   ['짙은', '켰다', '움직였다', '볼 수 있다', '옅은'],
   ['안개가 짙게 낀 아침이라는 내용이라 맞아요.',
 '안개가 짙어 운전자들이 전조등을 켰다는 내용이라 맞아요.',
 '안개 속이라 차들이 천천히 움직인다는 내용이라 맞아요.',
 '몇 미터 앞밖에 볼 수 없다는 것은 안개가 짙다는 뜻이라 맞아요.',
 '아침에 짙은 안개 때문에 앞이 안 보였으니, 꿰뚫어 볼 수 없을 만큼 옅다는 것은 어울리지 않아요. 원래는 thick(짙은)이 알맞아요.'],
   'fog 안개 / mist 옅은 안개 / traffic 차량 / see through ~을 꿰뚫어 보다')

# 15번째
rw(14,
   ['Sora planted ten bean ①seeds in a small pot in April.',
 'She ②watered them with a little cup every morning before school.',
 'After two weeks, small green ③leaves came up from the soil.',
 'The young plants ④grew a little more every single week.',
 'By July, the biggest plant was ⑤shorter than in early May.'],
   'taller',
   ['소라는 4월에 작은 화분에 콩 씨앗 열 개를 심었다.', '그녀는 아침마다 등교 전에 작은 컵으로 씨앗에 물을 주었다.', '두 주가 지나자 작고 푸른 잎이 흙에서 올라왔다.', '어린 식물들은 매주 조금씩 더 자랐다.', '7월에 가장 큰 식물은 5월 초보다 키가 더 작았다(→ 컸다).'],
   ['씨앗', '물을 주었다', '잎', '자랐다', '더 작은'],
   ['씨앗을 심었다는 내용이라 맞아요.', '씨앗에 매일 아침 물을 주었다는 내용이라 맞아요.', '싹이 터서 잎이 올라온 모습이라 맞아요.', '식물이 매주 조금씩 자랐다는 내용이라 맞아요.', '매주 자랐으니 7월에는 5월 초보다 더 커야 해요. 원래는 taller(키가 더 큰)가 알맞아요.'],
   'seed 씨앗 / bean 콩 / soil 흙 / leaf 잎')
