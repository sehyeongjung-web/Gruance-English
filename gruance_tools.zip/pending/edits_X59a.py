# -*- coding: utf-8 -*-
# 324번: 34번(빈칸 추론 — 긴 구) 레벨1 — 레벨1 기준으로 다시 씀 (앞 절반: 1~15번째)
# 꼴은 31~33번 레벨1과 같음: 네 문장 · 모두 단문 · 문장당 10~15낱말 · 빈칸은 넷째 문장
# 짝꿍 문장: 셋째 아홉 문항 · 둘째 다섯 문항(1·7·8·9·13번째) · 첫째 한 문항(4번째)
# 글감은 두 갈래: ① 한 사람의 버릇 → 좋은 결과(1·2·4·6·8·10·12·14번째) ② 어떤 곳이 한 가지를 바꿈 → 나아짐 → 「그 전의 탈이 무엇이었나」(3·5·7·9·11·13·15번째)
#   옛 ②는 「…, which suggests ______」(관계사절)로 숨은 까닭을 미루어 알게 했음 → 레벨1은 「글에 있는 말 하나를 그대로 확인」이므로 그 까닭을 짝꿍 문장에 다른 말로 적어 줌
# 생각의 단계(추론축 레벨1): 짝꿍 문장의 말을 다른 말로 바꾼 것이 답
#   (saves time in the morning ← out of the kitchen in one minute every morning · keeps colours from mixing ← every white shirt has come out white ·
#    change people's feelings ← now call the café warm and friendly · stops him forgetting things ← has not run back home for his keys ·
#    return their books on time ← the number of late books fell by half · easier to finish ← all three lines are crossed out / never done ·
#    losing track of the time ← had no clock anywhere near them · think about other things ← plans his day and practises English words ·
#    pass more shelves on the way out ← walk back to the door past the fruit and the milk · stops careless mistakes ← wrong answers to easy questions have almost disappeared ·
#    in the order of the line ← put salad on an empty tray / at the very end, stayed almost full · reminds him to drink ← his eyes fall on it / the bottle is empty ·
#    unsure how to use the machines ← takes them to every machine and shows them the buttons · keep her attention from falling ← her mind is as sharp in the last block ·
#    bread from the early morning ← no more talk of old bread)
# 정답 번호·발문은 그대로. **정답 구를 고친 문항 넷** — 정답 구 안에 절이 들어 있어 레벨1의 「단문만」에 맞지 않음(33번 12·20·23·28번째와 같은 까닭). 뜻은 같음
#   3번째 change how people feel about a place → change people's feelings about a place
#   5번째 return books when it is easy to → return their books on time (「쉬울 때」는 빈칸 문장의 With a little help like this로 옮김)
#   11번째 trays fill in the order people meet the food → fill their trays in the order of the line (빈칸 문장의 주어를 pupils로)
#   15번째 everything was baked in the morning → bread from the early morning (빈칸 문장을 saw every loaf as ______로)
# 선택지: 버릇 문항의 옛 오답은 거의 나쁜 결과 → 「같은 버릇의 다른 좋은 결과」로. 곳 문항의 옛 오답은 「다른 까닭」이라 쓸 만함 — 7·13번째는 거의 그대로 둠
# 낱말: queue → line · corridor → hall (LEVEL_GUIDE의 낱말 규칙). 철자는 영국식 그대로(colours · practises · coloured)
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '34', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, c5, ko, steps, traps, cn):
    """문항을 통째로 다시 씀: 지문·선택지·해석·풀이·해설. 정답 번호는 그대로. c5 = 새 선택지 다섯"""
    old = list(_tb[T][LV][n]['choices']); ch = {k: v for k, v in enumerate(c5) if v != old[k]}
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=ans in ch); e = E.pop((T, LV, n))
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(c5)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': list(c5), 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 1번째: 전날 밤에 싸 두는 도시락 (답 saves time in the morning) ----------
rw(0, 2, "Jenny packs her lunch box in the kitchen every night after dinner. She is out of the kitchen in one minute every morning. Her little sister still makes sandwiches there at half past seven. For Jenny, this small job ______.",
 ["saves time in the evening", "saves money on her lunch", "saves time in the morning", "keeps her food warm till noon", "helps her eat a bigger lunch"],
 "제니는 밤마다 저녁을 먹은 뒤 부엌에서 도시락을 싼다. 아침마다 일 분 만에 부엌에서 나온다. 제니의 여동생은 일곱 시 반에도 여전히 거기서 샌드위치를 만든다. 제니에게, 이 작은 일은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For Jenny, this small job»(제니에게, 이 작은 일은). 밤에 도시락을 싸 두는 일이에요. 이 일이 제니에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «She is out of the kitchen in one minute every morning.»(아침마다 일 분 만에 부엌에서 나온다.) 'in one minute'(일 분 만에)과 'every morning'(아침마다)이 단서예요.",
 "3) 셋째 문장 확인: «Her little sister still makes sandwiches there at half past seven.»(제니의 여동생은 일곱 시 반에도 여전히 거기서 샌드위치를 만든다.) 미리 싸 두지 않은 동생은 아침에 부엌에서 시간을 써요. 제니와 반대되는 모습이에요.",
 "4) 묶기: 아침에 부엌에서 일 분이면 된다 = 아침에 시간이 덜 든다. 그래서 'saves time in the morning'(아침 시간을 아껴 준다)이에요. 'saves'는 '아껴 준다'라는 뜻이에요."],
 "「저녁 시간을 아껴 준다」가 끌릴 수 있어요. 도시락을 싸는 때가 저녁을 먹은 뒤이니까요. 하지만 저녁에는 오히려 시간을 써요. 시간이 줄어드는 때는 아침이에요.",
 [("저녁 시간을 아껴 준다", "때가 달라요. 도시락은 저녁을 먹은 뒤에 싸요. 저녁에는 시간을 쓰고, 아침에 시간을 아껴요."),
  ("점심에 드는 돈을 아껴 준다", "지문에 없는 이야기예요. 돈 이야기는 나오지 않아요."),
  ("아침 시간을 아껴 준다", "둘째 문장 «She is out of the kitchen in one minute every morning.»이 근거예요. 아침에 일 분이면 부엌에서 나오니, 아침 시간을 아끼는 것이에요."),
  ("음식을 한낮까지 따뜻하게 해 준다", "지문에 없는 이야기예요. 음식이 따뜻한지는 나오지 않아요."),
  ("점심을 더 많이 먹도록 도와준다", "지문에 없는 이야기예요. 점심을 얼마나 먹는지는 나오지 않아요.")])

# ---------- 2번째: 흰옷과 색깔 옷을 따로 빨기 (답 keeps colours from mixing) ----------
rw(1, 0, "Last year one red sock turned five of Ben's white shirts pink. Now he washes his white clothes and his coloured clothes at different times. Since then every white shirt has come out of the machine white. For Ben's clothes, this simple habit ______.",
 ["keeps colours from mixing", "keeps shirts from getting smaller", "makes them smell much better", "makes them last twice as long", "keeps socks from getting lost"],
 "지난해에 빨간 양말 한 짝이 벤의 흰 셔츠 다섯 벌을 분홍색으로 물들였다. 이제 벤은 흰옷과 색깔 있는 옷을 서로 다른 때에 빤다. 그 뒤로 흰 셔츠는 모두 세탁기에서 흰색 그대로 나왔다. 벤의 옷을 위해, 이 간단한 버릇은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this simple habit»(이 간단한 버릇). 흰옷과 색깔 있는 옷을 따로 빠는 버릇이에요. 이 버릇이 옷에 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Since then every white shirt has come out of the machine white.»(그 뒤로 흰 셔츠는 모두 세탁기에서 흰색 그대로 나왔다.) 끝의 'white'(흰색 그대로)가 단서예요. 흰 셔츠에 다른 색이 묻지 않았어요.",
 "3) 첫 문장 확인: «one red sock turned five of Ben's white shirts pink»(빨간 양말 한 짝이 벤의 흰 셔츠 다섯 벌을 분홍색으로 물들였다). 빨간색이 흰 셔츠에 섞여서 분홍색이 된 것이에요. 따로 빨기 전의 일이에요.",
 "4) 묶기: 흰 셔츠가 흰색 그대로다 = 다른 색이 섞이지 않았다. 그래서 'keeps colours from mixing'(색이 섞이지 않게 해 준다)이에요. keeps 뒤에 「A from -ing」가 오면 「A가 ~하지 않게 해 준다」라는 뜻이에요."],
 "「양말을 잃어버리지 않게 해 준다」가 끌릴 수 있어요. 글에 'sock'(양말)이 나오거든요. 하지만 글의 양말은 잃어버린 것이 아니라 셔츠를 물들인 것이에요.",
 [("색이 섞이지 않게 해 준다", "셋째 문장 «Since then every white shirt has come out of the machine white.»가 근거예요. 흰 셔츠가 흰색 그대로 나오니, 색이 섞이지 않는 것이에요."),
  ("셔츠가 줄어들지 않게 해 준다", "지문에 없는 이야기예요. 옷이 줄어든다는 말은 나오지 않아요."),
  ("옷에서 훨씬 더 좋은 냄새가 나게 해 준다", "지문에 없는 이야기예요. 냄새는 나오지 않아요."),
  ("옷이 두 배 더 오래가게 해 준다", "지문에 없는 이야기예요. 옷이 얼마나 오래가는지는 나오지 않아요."),
  ("양말을 잃어버리지 않게 해 준다", "지문에 없는 이야기예요. 글의 양말은 잃어버린 것이 아니라 흰 셔츠를 분홍색으로 물들인 것이에요.")])

# ---------- 3번째: 물을 거저 주는 카페 (답 change people's feelings about a place — 옛 change how people feel about a place) ----------
rw(2, 0, "Since spring a small café has given free water to every table all day. Each glass of water costs the café owner almost nothing. Customers now call the café warm and friendly and stay much longer. Clearly, small things like this can ______.",
 ["change people's feelings about a place", "change people's taste in food and drink", "make more money than big changes", "bring new customers from far away", "save a small shop from closing"],
 "봄부터 어느 작은 카페는 온종일 탁자마다 물을 거저 준다. 물 한 잔에 카페 주인이 들이는 돈은 거의 없다. 손님들은 이제 그 카페를 따뜻하고 다정한 곳이라고 부르며 훨씬 오래 머문다. 분명히, 이런 작은 일은 ______ 수 있다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «small things like this can»(이런 작은 일은 ~할 수 있다). 물을 거저 주는 것 같은 작은 일이에요. 그런 일이 무엇을 할 수 있는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Customers now call the café warm and friendly and stay much longer.»(손님들은 이제 그 카페를 따뜻하고 다정한 곳이라고 부르며 훨씬 오래 머문다.) «call the café warm and friendly»(그 카페를 따뜻하고 다정한 곳이라고 부른다)가 단서예요. 'now'(이제)가 있으니, 전과 달라진 것이에요.",
 "3) 둘째 문장 확인: «Each glass of water costs the café owner almost nothing.»(물 한 잔에 카페 주인이 들이는 돈은 거의 없다.) 'almost nothing'(거의 없음)이라고 했어요. 그래서 넷째 문장이 'small things'(작은 일)라고 부른 것이에요.",
 "4) 묶기: 따뜻하고 다정한 곳이라고 부른다 = 그 카페를 좋게 느낀다. 이제 그렇게 되었다 = 느낌이 바뀌었다. 그래서 「change people's feelings about a place」(어떤 곳에 대한 사람들의 느낌을 바꾸다)예요. 'a place'(어떤 곳)는 여기서 카페예요."],
 "「큰 변화보다 돈을 더 많이 벌」이 끌릴 수 있어요. 손님이 오래 머물면 돈도 더 벌 것 같거든요. 하지만 글에는 카페가 돈을 얼마나 버는지가 나오지 않아요. 글이 말한 것은 손님들이 카페를 어떻게 부르는지예요.",
 [("어떤 곳에 대한 사람들의 느낌을 바꿀", "셋째 문장 «Customers now call the café warm and friendly and stay much longer.»가 근거예요. 손님들이 이제 카페를 따뜻하고 다정한 곳이라고 부르니, 그곳에 대한 느낌이 바뀐 것이에요."),
  ("먹고 마시는 것에 대한 사람들의 입맛을 바꿀", "지문에 없는 이야기예요. 손님들의 입맛은 나오지 않아요."),
  ("큰 변화보다 돈을 더 많이 벌", "지문에 없는 이야기예요. 카페가 돈을 얼마나 버는지도, 큰 변화도 나오지 않아요."),
  ("먼 곳에서 새 손님을 데려올", "지문에 없는 이야기예요. 손님이 어디에서 오는지는 나오지 않아요."),
  ("작은 가게가 문 닫는 것을 막을", "지문에 없는 이야기예요. 카페가 문을 닫을 뻔했다는 말은 나오지 않아요.")])

# ---------- 4번째: 문 옆에 두는 가방 (답 stops him forgetting things) ----------
rw(3, 1, "Minho has not run back home for his keys or his books all year. Every night he puts his packed bag right next to the front door. His keys, bus card and lunch money always go on top of it. On school mornings, this habit of his ______.",
 ["lets him sleep a bit longer", "stops him forgetting things", "stops him missing his bus", "keeps his room clean and tidy", "makes his bag much lighter"],
 "민호는 한 해 내내 열쇠나 책을 가지러 집으로 다시 뛰어간 적이 없다. 밤마다 다 싼 가방을 현관문 바로 옆에 둔다. 열쇠와 버스 카드와 점심값은 언제나 그 위에 올려 둔다. 학교 가는 아침에, 민호의 이 버릇은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this habit of his»(민호의 이 버릇). 밤에 가방을 문 옆에 두고 열쇠와 카드를 그 위에 올려 두는 버릇이에요. 이 버릇이 아침에 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 첫 문장이에요. «Minho has not run back home for his keys or his books all year.»(민호는 한 해 내내 열쇠나 책을 가지러 집으로 다시 뛰어간 적이 없다.) 'has not run back home'(집으로 다시 뛰어간 적이 없다)이 단서예요. 집으로 다시 뛰어가는 것은 무엇을 두고 나왔을 때예요.",
 "3) 셋째 문장 확인: «His keys, bus card and lunch money always go on top of it.»(열쇠와 버스 카드와 점심값은 언제나 그 위에 올려 둔다.) 두고 나오지 않는 까닭이에요. 챙길 것이 모두 문 옆 가방 위에 있어요.",
 "4) 묶기: 두고 나온 것을 가지러 되돌아간 적이 없다 = 잊고 나온 것이 없다. 그래서 'stops him forgetting things'(물건을 잊지 않게 해 준다)예요. stops him 뒤에 -ing 꼴이 와서 「그가 ~하지 않게 막아 준다」라는 뜻이에요."],
 "「버스를 놓치지 않게 해 준다」가 끌릴 수 있어요. 글에 'bus card'(버스 카드)가 나오거든요. 하지만 글에는 버스를 놓친다는 말이 없어요. 글이 말한 것은 물건을 가지러 되돌아간 적이 없다는 것이에요.",
 [("조금 더 오래 자게 해 준다", "지문에 없는 이야기예요. 몇 시에 일어나는지는 나오지 않아요."),
  ("물건을 잊지 않게 해 준다", "첫 문장 «Minho has not run back home for his keys or his books all year.»가 근거예요. 열쇠나 책을 가지러 되돌아간 적이 없으니, 물건을 잊지 않는 것이에요."),
  ("버스를 놓치지 않게 해 준다", "지문에 없는 이야기예요. 글에 나오는 것은 버스 카드예요. 버스를 놓친다는 말은 없어요."),
  ("방을 깨끗하고 가지런하게 해 준다", "지문에 없는 이야기예요. 방이 어떤지는 나오지 않아요."),
  ("가방을 훨씬 가볍게 해 준다", "지문에 없는 이야기예요. 가방의 무게는 나오지 않아요.")])

# ---------- 5번째: 도서관 밖의 반납함 (답 return their books on time — 옛 return books when it is easy to) ----------
rw(4, 3, "A town library put a big returns box outside its front door. Readers can drop books into the box at any hour, day or night. The number of late books fell by half in one month. With a little help like this, more people ______.",
 ["read more books than before", "borrow books at any hour", "choose only the newest books", "return their books on time", "visit the library more often"],
 "어느 마을 도서관이 정문 밖에 큰 반납함을 놓았다. 책 읽는 사람들은 낮이든 밤이든 어느 때나 그 함에 책을 넣을 수 있다. 늦게 돌아오는 책의 수가 한 달 만에 절반으로 줄었다. 이런 작은 도움이 있으면, 더 많은 사람이 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With a little help like this»(이런 작은 도움이 있으면). 정문 밖의 반납함이 그 작은 도움이에요. 이 도움이 있으면 사람들이 어떻게 하는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The number of late books fell by half in one month.»(늦게 돌아오는 책의 수가 한 달 만에 절반으로 줄었다.) 'late books'(늦게 돌아오는 책)와 'fell by half'(절반으로 줄었다)가 단서예요.",
 "3) 둘째 문장 확인: «Readers can drop books into the box at any hour, day or night.»(책 읽는 사람들은 낮이든 밤이든 어느 때나 그 함에 책을 넣을 수 있다.) 늦는 책이 줄어든 까닭이에요. 돌려주기가 쉬워졌어요.",
 "4) 묶기: 늦게 돌아오는 책이 줄었다 = 제때 돌아오는 책이 늘었다. 그래서 'return their books on time'(책을 제때 돌려준다)이에요. 'on time'은 '제때'라는 뜻이에요."],
 "「어느 때나 책을 빌린다」가 끌릴 수 있어요. 글에 'at any hour'(어느 때나)가 그대로 나오거든요. 하지만 어느 때나 할 수 있는 일은 빌리는 것이 아니라 돌려주는 것이에요. 반납함은 책을 돌려주는 함이에요.",
 [("전보다 책을 더 많이 읽는다", "지문에 없는 이야기예요. 책을 얼마나 읽는지는 나오지 않아요."),
  ("어느 때나 책을 빌린다", "지문에 없는 이야기예요. 어느 때나 할 수 있는 일은 책을 함에 넣는 것, 곧 돌려주는 것이에요. 빌린다는 말은 없어요."),
  ("가장 새로 나온 책만 고른다", "지문에 없는 이야기예요. 어떤 책을 고르는지는 나오지 않아요."),
  ("책을 제때 돌려준다", "셋째 문장 «The number of late books fell by half in one month.»가 근거예요. 늦게 돌아오는 책이 절반으로 줄었으니, 더 많은 사람이 책을 제때 돌려주는 것이에요."),
  ("도서관에 더 자주 간다", "지문에 없는 이야기예요. 도서관에 얼마나 자주 가는지는 나오지 않아요.")])

# ---------- 6번째: 세 가지만 적는 목록 (답 is easier to finish than a long one) ----------
rw(5, 0, "Sora writes only three jobs on her list for the next day. Her old lists of ten jobs were never done by bedtime. Now all three lines are crossed out before dinner on most days. For Sora, a short list ______.",
 ["is easier to finish than a long one", "is easier to remember than a long one", "is easier to change than a long one", "is better for weekends than for school days", "is more fun to write than a long one"],
 "소라는 다음 날 할 일을 목록에 딱 세 가지만 적는다. 열 가지를 적던 예전 목록은 잠잘 때까지 다 해낸 적이 없었다. 이제는 거의 날마다 저녁 먹기 전에 세 줄이 모두 지워진다. 소라에게, 짧은 목록은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For Sora, a short list»(소라에게, 짧은 목록은). 세 가지만 적은 목록이에요. 짧은 목록이 어떠한지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now all three lines are crossed out before dinner on most days.»(이제는 거의 날마다 저녁 먹기 전에 세 줄이 모두 지워진다.) 'all three lines are crossed out'(세 줄이 모두 지워진다)이 단서예요. 적어 둔 할 일을 줄을 그어 지우는 것은 그 일을 끝냈다는 뜻이에요.",
 "3) 둘째 문장 확인: «Her old lists of ten jobs were never done by bedtime.»(열 가지를 적던 예전 목록은 잠잘 때까지 다 해낸 적이 없었다.) 'never done'(다 해낸 적이 없는)이 있어요. 긴 목록은 끝내지 못했어요. 셋째 문장과 맞서요.",
 "4) 묶기: 세 가지 목록은 저녁 전에 다 끝내요. 열 가지 목록은 잠잘 때까지도 못 끝냈어요. 그래서 짧은 목록은 'is easier to finish than a long one'(긴 목록보다 끝내기가 더 쉽다)이에요. 여기서 'one'은 목록을 가리켜요."],
 "「긴 목록보다 기억하기가 더 쉽다」가 끌릴 수 있어요. 세 가지는 열 가지보다 기억하기 쉬울 것 같거든요. 하지만 글에는 목록을 기억한다는 말이 없어요. 글이 견준 것은 다 끝냈는지, 못 끝냈는지예요.",
 [("긴 목록보다 끝내기가 더 쉽다", "셋째 문장 «Now all three lines are crossed out before dinner on most days.»가 근거예요. 세 가지는 저녁 전에 다 끝내고, 열 가지는 잠잘 때까지도 못 끝냈어요."),
  ("긴 목록보다 기억하기가 더 쉽다", "지문에 없는 이야기예요. 목록을 기억한다는 말은 나오지 않아요."),
  ("긴 목록보다 바꾸기가 더 쉽다", "지문에 없는 이야기예요. 목록을 바꾼다는 말은 나오지 않아요."),
  ("학교 가는 날보다 주말에 더 좋다", "지문에 없는 이야기예요. 주말은 나오지 않아요."),
  ("긴 목록보다 쓰는 재미가 더 있다", "지문에 없는 이야기예요. 목록을 쓰는 재미는 나오지 않아요.")])

# ---------- 7번째: 복도마다 단 시계 (답 losing track of the time) ----------
rw(6, 2, "A school put a large clock on the wall of every hall. Before that, pupils at break had no clock anywhere near them. The number of late pupils after break fell from thirty a day to five. Before the change, many of them had been ______.",
 ["taking the wrong stairs", "eating too slowly", "losing track of the time", "talking too much", "arriving late from home"],
 "어느 학교가 복도마다 벽에 큰 시계를 달았다. 그 전에는 쉬는 시간에 학생들 가까이에 시계가 하나도 없었다. 쉬는 시간 뒤에 늦는 학생의 수가 하루 서른 명에서 다섯 명으로 줄었다. 바뀌기 전에, 그 학생들 가운데 여럿은 ______ 있었다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Before the change, many of them had been»(바뀌기 전에, 그 학생들 가운데 여럿은 ~하고 있었다). 「had been -ing」는 「그 전까지 죽 ~하고 있었다」라는 뜻이에요. 시계를 달기 전에 학생들이 왜 늦었는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «pupils at break had no clock anywhere near them»(쉬는 시간에 학생들 가까이에 시계가 하나도 없었다). 'no clock'(시계가 없음)이 단서예요. 시계가 없으면 지금 몇 시인지 알 수 없어요.",
 "3) 셋째 문장 확인: «The number of late pupils after break fell from thirty a day to five.»(쉬는 시간 뒤에 늦는 학생의 수가 하루 서른 명에서 다섯 명으로 줄었다.) 시계를 달자 늦는 학생이 줄었어요. 늦던 까닭이 시계에 있었다는 뜻이에요.",
 "4) 묶기: 가까이에 시계가 없었다 = 몇 시인지 몰랐다. 그래서 'losing track of the time'(시간 가는 줄 모르고)이에요. 「lose track of ~」는 「~이 어떻게 되어 가는지 놓치다」라는 뜻이에요."],
 "「집에서 늦게 오고」가 끌릴 수 있어요. 늦는 학생이라면 집에서 늦게 나온 것 같거든요. 하지만 셋째 문장은 'after break'(쉬는 시간 뒤에)라고 했어요. 아침에 늦는 것이 아니라 쉬는 시간이 끝나고 늦는 것이에요.",
 [("계단을 잘못 찾아가고", "지문에 없는 이야기예요. 계단은 나오지 않아요."),
  ("너무 천천히 먹고", "지문에 없는 이야기예요. 먹는 이야기는 나오지 않아요."),
  ("시간 가는 줄 모르고", "둘째 문장 «pupils at break had no clock anywhere near them»이 근거예요. 쉬는 시간에 가까이에 시계가 없었으니, 시간 가는 줄 몰랐던 것이에요."),
  ("너무 많이 떠들고", "지문에 없는 이야기예요. 떠든다는 말은 나오지 않아요."),
  ("집에서 늦게 오고", "글과 맞지 않아요. 늦는 것은 쉬는 시간 뒤예요. 집에서 오는 아침의 일이 아니에요.")])

# ---------- 8번째: 날마다 같은 길로 가는 자전거 (답 lets him think about other things) ----------
rw(7, 2, "Dae-jung rides his bicycle to school along the same river path every day. On the way he plans his day and practises English words in his head. He knows every turn, every hole and every tree along it. For Dae-jung, the same old path ______.",
 ["makes the ride feel much shorter", "gets him to school before the bell", "lets him think about other things", "lets him ride faster than his friends", "lets him enjoy the trees and birds"],
 "대중이는 날마다 똑같은 강가 길을 따라 자전거로 학교에 간다. 가는 길에 하루의 계획을 세우고 머릿속으로 영어 낱말을 연습한다. 대중이는 그 길의 굽이와 파인 곳과 나무를 하나하나 다 안다. 대중이에게, 늘 다니는 그 길은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For Dae-jung, the same old path»(대중이에게, 늘 다니는 그 길은). 날마다 다니는 똑같은 길이에요. 그 길이 대중이에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On the way he plans his day and practises English words in his head.»(가는 길에 하루의 계획을 세우고 머릿속으로 영어 낱말을 연습한다.) 'plans his day'(하루의 계획을 세운다)와 'practises English words'(영어 낱말을 연습한다)가 단서예요. 둘 다 길과는 상관없는 생각이에요.",
 "3) 셋째 문장 확인: «He knows every turn, every hole and every tree along it.»(대중이는 그 길의 굽이와 파인 곳과 나무를 하나하나 다 안다.) 다른 생각을 할 수 있는 까닭이에요. 길을 다 아니까 길에 마음을 덜 써도 돼요.",
 "4) 묶기: 하루의 계획과 영어 낱말 = 길이 아닌 다른 것들. 그래서 'lets him think about other things'(다른 것들을 생각하게 해 준다)예요. 'other things'는 '다른 것들'이에요."],
 "「나무와 새를 즐기게 해 준다」가 끌릴 수 있어요. 글에 'every tree'(나무 하나하나)가 나오거든요. 하지만 나무를 다 안다는 것이지, 즐긴다는 것이 아니에요. 새는 나오지도 않아요.",
 [("가는 길을 훨씬 짧게 느끼게 해 준다", "지문에 없는 이야기예요. 길이 짧게 느껴진다는 말은 나오지 않아요."),
  ("종이 울리기 전에 학교에 닿게 해 준다", "지문에 없는 이야기예요. 학교에 닿는 시간은 나오지 않아요."),
  ("다른 것들을 생각하게 해 준다", "둘째 문장 «On the way he plans his day and practises English words in his head.»가 근거예요. 가는 길에 계획을 세우고 낱말을 연습하니, 다른 것들을 생각하는 것이에요."),
  ("친구들보다 더 빨리 달리게 해 준다", "지문에 없는 이야기예요. 얼마나 빨리 달리는지는 나오지 않아요."),
  ("나무와 새를 즐기게 해 준다", "지문에 없는 이야기예요. 글은 나무를 다 안다고 했을 뿐이에요. 즐긴다는 말도, 새도 나오지 않아요.")])

# ---------- 9번째: 빵을 안쪽으로 옮긴 가게 (답 pass more shelves on the way out) ----------
rw(8, 4, "A small shop moved its bread from the door to the back wall. Bread buyers now walk back to the door past the fruit and the milk. Sales of fruit and milk have gone up since the move. These days, the shop's bread buyers ______.",
 ["see lower prices on the door", "get a free basket at the door", "see the fruit next to the bread", "come back twice in one day", "pass more shelves on the way out"],
 "어느 작은 가게가 빵을 문 옆에서 안쪽 벽으로 옮겼다. 빵을 사는 사람들은 이제 과일과 우유 앞을 지나 문으로 되돌아간다. 옮긴 뒤로 과일과 우유가 더 많이 팔렸다. 요즘, 이 가게에서 빵을 사는 사람들은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the shop's bread buyers»(이 가게에서 빵을 사는 사람들). 빵을 옮긴 뒤로 그 사람들이 어떻게 하는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Bread buyers now walk back to the door past the fruit and the milk.»(빵을 사는 사람들은 이제 과일과 우유 앞을 지나 문으로 되돌아간다.) 'past the fruit and the milk'(과일과 우유 앞을 지나)가 단서예요.",
 "3) 첫 문장 확인: «A small shop moved its bread from the door to the back wall.»(어느 작은 가게가 빵을 문 옆에서 안쪽 벽으로 옮겼다.) 빵이 안쪽 벽에 있으니, 빵을 들고 문까지 걸어 나와야 해요.",
 "4) 묶기: 과일과 우유 앞을 지나 문으로 간다 = 나가는 길에 다른 선반들을 지난다. 그래서 'pass more shelves on the way out'(나가는 길에 더 많은 선반을 지난다)이에요. 'on the way out'은 '나가는 길에'라는 뜻이에요."],
 "「빵 바로 옆에서 과일을 본다」가 끌릴 수 있어요. 글에 빵도 과일도 나오거든요. 하지만 글은 과일이 문으로 돌아가는 길에 있다고 했을 뿐이에요. 빵 바로 옆에 있다는 말은 없어요.",
 [("문에 붙은 더 싼 값을 본다", "지문에 없는 이야기예요. 값 이야기는 나오지 않아요."),
  ("문에서 바구니를 거저 받는다", "지문에 없는 이야기예요. 바구니는 나오지 않아요."),
  ("빵 바로 옆에서 과일을 본다", "지문에 없는 이야기예요. 과일은 문으로 돌아가는 길에 있다고 했어요. 빵 바로 옆에 있다는 말은 없어요."),
  ("하루에 두 번 다시 온다", "지문에 없는 이야기예요. 가게에 얼마나 자주 오는지는 나오지 않아요."),
  ("나가는 길에 더 많은 선반을 지난다", "둘째 문장 «Bread buyers now walk back to the door past the fruit and the milk.»가 근거예요. 과일과 우유 앞을 지나 문으로 가니, 나가는 길에 선반을 더 지나는 것이에요.")])

# ---------- 10번째: 문제를 두 번 읽기 (답 stops careless mistakes) ----------
rw(9, 3, "Hana reads every test question twice before writing her answer. On the second reading she often notices a missed word. Her wrong answers to easy questions have almost disappeared this year. In every school test, this slow start of hers ______.",
 ["saves her a lot of time", "makes her writing neater", "helps her remember the lesson", "stops careless mistakes", "stops her feeling nervous"],
 "하나는 시험 문제마다 두 번씩 읽은 뒤에 답을 쓴다. 두 번째로 읽을 때 놓친 낱말을 자주 알아차린다. 쉬운 문제에서 틀리는 답이 올해는 거의 사라졌다. 학교 시험 때마다, 하나가 하는 이 느린 시작은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this slow start of hers»(하나가 하는 이 느린 시작). 문제를 두 번씩 읽고 나서 답을 쓰는 것이에요. 이것이 시험에서 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Her wrong answers to easy questions have almost disappeared this year.»(쉬운 문제에서 틀리는 답이 올해는 거의 사라졌다.) 'wrong answers to easy questions'(쉬운 문제에서 틀리는 답)가 단서예요. 쉬운 문제를 틀리는 것은 몰라서가 아니라 주의하지 않아서예요.",
 "3) 둘째 문장 확인: «On the second reading she often notices a missed word.»(두 번째로 읽을 때 놓친 낱말을 자주 알아차린다.) 처음 읽을 때 놓친 낱말을 두 번째에 찾아내요. 그래서 쉬운 문제를 틀리지 않아요.",
 "4) 묶기: 쉬운 문제에서 틀리는 답 = 'careless mistakes'(부주의한 실수). 그것이 거의 사라졌어요. 그래서 'stops careless mistakes'(부주의한 실수를 막아 준다)예요. 'careless'는 '부주의한', 곧 '주의하지 않는'이라는 뜻이에요."],
 "「시간을 많이 아껴 준다」가 끌릴 수 있어요. 실수가 줄면 고치는 시간도 줄 것 같거든요. 하지만 두 번씩 읽으면 시간은 오히려 더 들어요. 넷째 문장도 이것을 'slow start'(느린 시작)라고 불렀어요.",
 [("시간을 많이 아껴 준다", "글과 맞지 않아요. 넷째 문장이 이것을 느린 시작이라고 했어요. 시간을 아낀다는 말은 없어요."),
  ("글씨를 더 가지런하게 해 준다", "지문에 없는 이야기예요. 글씨는 나오지 않아요."),
  ("배운 것을 기억하도록 도와준다", "지문에 없는 이야기예요. 배운 것을 기억한다는 말은 나오지 않아요."),
  ("부주의한 실수를 막아 준다", "셋째 문장 «Her wrong answers to easy questions have almost disappeared this year.»가 근거예요. 쉬운 문제에서 틀리는 답이 거의 사라졌으니, 부주의한 실수를 막아 주는 것이에요."),
  ("긴장하지 않게 해 준다", "지문에 없는 이야기예요. 긴장한다는 말은 나오지 않아요.")])

# ---------- 11번째: 줄 맨 앞으로 옮긴 샐러드 (답 fill their trays in the order of the line — 옛 trays fill in the order people meet the food) ----------
rw(10, 4, "A school canteen moved the salad bowl to the start of the line. Before, it sat at the very end and stayed almost full every day. Pupils now put salad on an empty tray and have less room for meat. At lunch, most pupils ______.",
 ["fill their trays with hot food first", "like salad more than meat and rice", "fill their trays like the pupils before them", "fill their trays with the cheapest dishes", "fill their trays in the order of the line"],
 "어느 학교 급식실이 샐러드 그릇을 줄의 맨 앞으로 옮겼다. 전에는 그것이 맨 끝에 있었고 날마다 거의 가득 찬 채로 남았다. 이제 학생들은 빈 식판에 샐러드를 담고, 고기를 담을 자리는 줄어든다. 점심때, 대부분의 학생은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «At lunch, most pupils»(점심때, 대부분의 학생은). 학생들이 식판을 어떻게 채우는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Pupils now put salad on an empty tray and have less room for meat.»(이제 학생들은 빈 식판에 샐러드를 담고, 고기를 담을 자리는 줄어든다.) 'on an empty tray'(빈 식판에)가 단서예요. 맨 앞에 있는 음식이 빈 식판에 먼저 담겨요.",
 "3) 둘째 문장 확인: «it sat at the very end and stayed almost full every day»(그것이 맨 끝에 있었고 날마다 거의 가득 찬 채로 남았다). 'it'은 샐러드 그릇이에요. 같은 샐러드인데 맨 끝에 있을 때는 거의 담아 가지 않았어요.",
 "4) 묶기: 맨 앞에 있으면 먼저 담고, 맨 끝에 있으면 남아요. 음식이 줄에 놓인 차례가 식판을 정한다는 뜻이에요. 그래서 'fill their trays in the order of the line'(줄에 놓인 차례대로 식판을 채운다)이에요. 'in the order of'는 '~의 차례대로'라는 뜻이에요."],
 "「고기와 밥보다 샐러드를 더 좋아한다」가 끌릴 수 있어요. 이제 샐러드를 먼저 담으니까요. 하지만 같은 샐러드가 맨 끝에 있을 때는 거의 가득 찬 채로 남았어요. 달라진 것은 입맛이 아니라 샐러드의 자리예요.",
 [("뜨거운 음식부터 식판을 채운다", "글과 맞지 않아요. 이제 학생들은 빈 식판에 샐러드부터 담아요."),
  ("고기와 밥보다 샐러드를 더 좋아한다", "글과 맞지 않아요. 같은 샐러드가 맨 끝에 있을 때는 날마다 거의 가득 찬 채로 남았어요. 좋아해서가 아니라 맨 앞에 있어서 담는 것이에요."),
  ("앞사람이 하는 대로 식판을 채운다", "지문에 없는 이야기예요. 앞사람을 따라 한다는 말은 나오지 않아요."),
  ("가장 싼 음식으로 식판을 채운다", "지문에 없는 이야기예요. 음식의 값은 나오지 않아요."),
  ("줄에 놓인 차례대로 식판을 채운다", "셋째 문장 «Pupils now put salad on an empty tray and have less room for meat.»가 근거예요. 맨 앞으로 옮기자 빈 식판에 샐러드부터 담으니, 줄에 놓인 차례대로 식판을 채우는 것이에요.")])

# ---------- 12번째: 책상 위의 물병 (답 reminds him to drink) ----------
rw(11, 0, "Ji-ho keeps a full bottle of water on his desk next to his books. His eyes fall on it every few minutes during his homework. The bottle is empty by the end of the evening every single day. For Ji-ho, this simple thing on the desk ______.",
 ["reminds him to drink", "reminds him to rest", "helps him study longer", "keeps him awake at his desk", "stops him eating snacks"],
 "지호는 물이 가득 든 병을 책상 위 책 옆에 둔다. 숙제를 하는 동안 몇 분마다 눈길이 그 병에 간다. 그 병은 날마다 빠짐없이 저녁이 끝날 때면 비어 있다. 지호에게, 책상 위의 이 간단한 물건은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this simple thing on the desk»(책상 위의 이 간단한 물건). 물병이에요. 물병이 지호에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The bottle is empty by the end of the evening every single day.»(그 병은 날마다 빠짐없이 저녁이 끝날 때면 비어 있다.) 'empty'(비어 있는)가 단서예요. 가득 찼던 병이 비었으니, 지호가 그 물을 다 마신 것이에요.",
 "3) 둘째 문장 확인: «His eyes fall on it every few minutes during his homework.»(숙제를 하는 동안 몇 분마다 눈길이 그 병에 간다.) 병이 자꾸 눈에 보여요. 보일 때마다 물 생각이 나요.",
 "4) 묶기: 병이 자꾸 눈에 보인다 + 병이 날마다 빈다 = 볼 때마다 마신다. 그래서 'reminds him to drink'(마시라고 일깨워 준다)예요. 「remind A to ~」는 「A에게 ~하라고 일깨워 주다」라는 뜻이에요."],
 "「쉬라고 일깨워 준다」가 끌릴 수 있어요. 앞부분이 답과 똑같거든요. 하지만 글에는 쉰다는 말이 없어요. 글이 말한 것은 가득 찼던 병이 날마다 빈다는 것이에요.",
 [("마시라고 일깨워 준다", "셋째 문장 «The bottle is empty by the end of the evening every single day.»가 근거예요. 자꾸 눈에 보이는 병이 날마다 비니, 병이 마시라고 일깨워 주는 것이에요."),
  ("쉬라고 일깨워 준다", "지문에 없는 이야기예요. 쉰다는 말은 나오지 않아요."),
  ("더 오래 공부하도록 도와준다", "지문에 없는 이야기예요. 얼마나 오래 공부하는지는 나오지 않아요."),
  ("책상에서 깨어 있게 해 준다", "지문에 없는 이야기예요. 존다는 말은 나오지 않아요."),
  ("간식을 먹지 않게 해 준다", "지문에 없는 이야기예요. 간식은 나오지 않아요.")])

# ---------- 13번째: 새 회원에게 트레이너를 붙여 주는 체육관 (답 unsure how to use the machines) ----------
rw(12, 2, "A gym now gives every new member two free hours with a trainer. The trainer takes them to every machine and shows them the buttons. Far fewer new members leave in the first month these days. Before the change, many new members had been ______.",
 ["unhappy about the high price", "coming at the busiest hours", "unsure how to use the machines", "living too far away from the gym", "training too hard at first"],
 "어느 체육관은 이제 새 회원 모두에게 트레이너와 함께하는 두 시간을 거저 준다. 트레이너는 새 회원들을 기구마다 데려가서 단추들을 보여 준다. 요즘은 첫 달에 그만두는 새 회원이 훨씬 적다. 바뀌기 전에, 많은 새 회원은 ______ 있었다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Before the change, many new members had been»(바뀌기 전에, 많은 새 회원은 ~하고 있었다). 트레이너와의 두 시간이 생기기 전에 새 회원들이 어떠했는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «The trainer takes them to every machine and shows them the buttons.»(트레이너는 새 회원들을 기구마다 데려가서 단추들을 보여 준다.) 'every machine'(기구마다)과 'shows them the buttons'(단추들을 보여 준다)가 단서예요. 기구를 어떻게 쓰는지 알려 주는 것이에요.",
 "3) 셋째 문장 확인: «Far fewer new members leave in the first month these days.»(요즘은 첫 달에 그만두는 새 회원이 훨씬 적다.) 쓰는 법을 알려 주자 그만두는 사람이 줄었어요. 그만두던 까닭이 거기에 있었다는 뜻이에요.",
 "4) 묶기: 이제는 쓰는 법을 알려 준다 = 전에는 쓰는 법을 몰랐다. 그래서 'unsure how to use the machines'(기구 쓰는 법을 잘 모르고)예요. 'unsure'는 '잘 모르는, 자신이 없는'이라는 뜻이고, 'how to use'는 '쓰는 법'이에요."],
 "「처음에 너무 세게 운동하고」가 끌릴 수 있어요. 트레이너가 있으면 알맞게 운동하도록 잡아 줄 것 같거든요. 하지만 글에서 트레이너가 하는 일은 기구마다 단추를 보여 주는 것이에요. 얼마나 세게 운동하는지는 나오지 않아요.",
 [("비싼 값에 불만을 품고", "지문에 없는 이야기예요. 값이 비싸다는 말도, 불만이 있다는 말도 나오지 않아요."),
  ("가장 붐비는 시간에 오고", "지문에 없는 이야기예요. 몇 시에 오는지는 나오지 않아요."),
  ("기구 쓰는 법을 잘 모르고", "둘째 문장 «The trainer takes them to every machine and shows them the buttons.»가 근거예요. 이제는 기구마다 쓰는 법을 알려 주니, 전에는 그것을 잘 몰랐던 것이에요."),
  ("체육관에서 너무 멀리 떨어져 살고", "지문에 없는 이야기예요. 어디에 사는지는 나오지 않아요."),
  ("처음에 너무 세게 운동하고", "지문에 없는 이야기예요. 얼마나 세게 운동하는지는 나오지 않아요.")])

# ---------- 14번째: 끊어서 하는 공부와 짧은 쉬는 시간 (답 keep her attention from falling) ----------
rw(13, 3, "Yuna studies in blocks of twenty-five minutes with five-minute breaks. In each break she stands up, drinks water and walks around the room. Her mind is as sharp in the last block as in the first. For Yuna, these short breaks ______.",
 ["make her homework much shorter", "help her sleep well at night", "keep her eyes from getting tired", "keep her attention from falling", "let her check her phone messages"],
 "유나는 이십오 분짜리 공부 시간을 여러 번 하고, 그 사이사이에 오 분씩 쉰다. 쉴 때마다 일어나서 물을 마시고 방 안을 걸어 다닌다. 유나의 머리는 마지막 공부 시간에도 첫 시간만큼 맑다. 유나에게, 이 짧은 쉬는 시간들은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For Yuna, these short breaks»(유나에게, 이 짧은 쉬는 시간들은). 공부 사이의 오 분이에요. 이 쉬는 시간이 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Her mind is as sharp in the last block as in the first.»(유나의 머리는 마지막 공부 시간에도 첫 시간만큼 맑다.) 'sharp'(맑은, 또렷한)가 단서예요. 「as ~ as …」는 「…만큼 ~한」이라는 뜻이에요. 마지막 시간에도 첫 시간만큼 머리가 맑다는 말이에요.",
 "3) 둘째 문장 확인: «In each break she stands up, drinks water and walks around the room.»(쉴 때마다 일어나서 물을 마시고 방 안을 걸어 다닌다.) 쉬는 오 분 동안 하는 일이에요. 공부에서 잠깐 떨어져요.",
 "4) 묶기: 마지막까지 머리가 맑다 = 집중력이 처음 그대로다. 그래서 'keep her attention from falling'(집중력이 떨어지지 않게 해 준다)이에요. 'attention'은 '집중력'이에요. keep 뒤에 「A from -ing」가 오면 「A가 ~하지 않게 해 준다」라는 뜻이에요."],
 "「눈이 피곤해지지 않게 해 준다」가 끌릴 수 있어요. 앞부분이 답과 똑같고, 쉬면 눈도 쉴 것 같거든요. 하지만 글에는 눈 이야기가 없어요. 글이 말한 것은 머리가 마지막까지 맑다는 것이에요.",
 [("숙제를 훨씬 짧게 해 준다", "지문에 없는 이야기예요. 숙제가 짧아진다는 말은 나오지 않아요."),
  ("밤에 잘 자도록 도와준다", "지문에 없는 이야기예요. 잠은 나오지 않아요."),
  ("눈이 피곤해지지 않게 해 준다", "지문에 없는 이야기예요. 눈은 나오지 않아요. 글이 말한 것은 머리가 맑다는 것이에요."),
  ("집중력이 떨어지지 않게 해 준다", "셋째 문장 «Her mind is as sharp in the last block as in the first.»가 근거예요. 마지막 시간에도 첫 시간만큼 머리가 맑으니, 집중력이 떨어지지 않는 것이에요."),
  ("전화기 메시지를 확인하게 해 준다", "지문에 없는 이야기예요. 쉴 때 하는 일은 일어나서 물을 마시고 걷는 것이에요. 전화기는 나오지 않아요.")])

# ---------- 15번째: 구운 시각을 적은 카드 (답 bread from the early morning — 옛 everything was baked in the morning) ----------
rw(14, 1, "A bakery now puts a card with the time of baking on each tray. Half of its bread comes out of the oven at two in the afternoon. Since the first card, afternoon sales have doubled, with no more talk of old bread. In the past, many shoppers saw every loaf as ______.",
 ["bread with too much sugar", "bread from the early morning", "bread from another bakery", "bread at double the price", "bread for special days only"],
 "어느 빵집은 이제 판마다 빵을 구운 시각을 적은 카드를 놓는다. 이 빵집 빵의 절반은 오후 두 시에 오븐에서 나온다. 첫 카드를 놓은 뒤로 오후에 팔리는 빵이 두 배가 되었고, 오래된 빵이라는 말은 더는 나오지 않는다. 예전에는, 많은 손님이 빵을 모두 ______으로 보았다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «many shoppers saw every loaf as»(많은 손님이 빵을 모두 ~으로 보았다). 「see A as B」는 「A를 B로 보다, 여기다」라는 뜻이에요. 'loaf'는 빵 한 덩이예요. 카드가 없던 때에 손님들이 빵을 무엇으로 여겼는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «with no more talk of old bread»(오래된 빵이라는 말은 더는 나오지 않는다). 'old bread'(오래된 빵)가 단서예요. 'no more'(더는 ~않다)라고 했으니, 전에는 오래된 빵이라는 말이 나왔던 것이에요.",
 "3) 둘째 문장 확인: «Half of its bread comes out of the oven at two in the afternoon.»(이 빵집 빵의 절반은 오후 두 시에 오븐에서 나온다.) 사실은 빵의 절반이 오후에 갓 나온 빵이에요. 카드가 없을 때는 손님들이 그것을 몰랐어요.",
 "4) 묶기: 오후에 온 손님에게 오래된 빵이란 아침 일찍 구워서 여러 시간이 지난 빵이에요. 그래서 'bread from the early morning'(이른 아침에 구운 빵)이에요. 여기서 'from the early morning'은 '이른 아침에 구운'이라는 뜻이에요."],
 "「값이 두 배인 빵」이 끌릴 수 있어요. 글에 'doubled'(두 배가 되었다)가 나오거든요. 하지만 두 배가 된 것은 값이 아니라 오후에 팔리는 빵이에요.",
 [("설탕이 너무 많이 든 빵", "지문에 없는 이야기예요. 설탕은 나오지 않아요."),
  ("이른 아침에 구운 빵", "셋째 문장 «with no more talk of old bread»가 근거예요. 전에는 오후의 빵을 오래된 빵이라고 했으니, 이른 아침에 구운 빵으로 본 것이에요."),
  ("다른 빵집에서 온 빵", "지문에 없는 이야기예요. 다른 빵집은 나오지 않아요."),
  ("값이 두 배인 빵", "지문에 없는 이야기예요. 글에서 두 배가 된 것은 오후에 팔리는 빵이에요. 값 이야기는 나오지 않아요."),
  ("특별한 날에만 먹는 빵", "지문에 없는 이야기예요. 특별한 날은 나오지 않아요.")])
