# -*- coding: utf-8 -*-
# 317번: 20번(주장) 레벨2 — 레벨2 기준으로 다시 씀 (앞 절반: 1~15번째)
# 선생님 결정(314번 뒤): 「3. 다시 씁시다」 — 스물한 문항이 「…ing은 …. ○○ experts recommend this habit. We should ….」 한 틀이고 마지막 문장이 답을 그대로 말하던 칸
# 레벨2의 기준(LEVEL_GUIDE.md): 기초 생활 낱말 · 단문과 and·but·so로 이은 문장을 섞음 · 문장당 10~15낱말 · 종속절·관계사절·분사구문·명사절 없음
# 지문의 꼴: 두세 문장(22낱말쯤) → 다섯 문장(58낱말쯤 — 레벨2 눈금은 52낱말)
# 틀을 깨려고 문항마다 달리한 것:
#   - 주장 문장의 자리: 첫째 2 · 둘째 3 · 셋째 3 · 넷째 3 · 다섯째 4
#   - 주장 문장의 꼴: 명령문 / You should … / People should … / Every family should … / You must … / The best time to … is … / So copy …
#   - 글머리: 사람 이야기(Jun·Mina) / 물음 / 사실 / 장면 / 명령문으로 떠올려 보게 하기
#   - 세 문항(5·7·13번째)에는 주장이 아닌 명령문이 하나 더 있음(Look at … · Pick up … · Think about …) — 명령문만 찾아서는 못 풀게
# 생각의 단계(추론축 레벨2): 한 가지를 조금 다른 말로 바꾸어 알아보기 — 정답 선택지는 주장 문장을 조금 다른 우리말로 옮긴 것
# 선택지: 다섯 모두 「~해야 한다」로 끝나게 다시 씀(옛 선택지는 정답만 「~해야 한다」이고 오답은 「불필요하다·무관하다·나중에 해도 된다」여서 끝말만 보고 답을 고를 수 있었음)
#   오답의 갈래: 글과 반대 / 글의 낱말만 가져온 딴 이야기 / 그럴듯하지만 글에 없는 말. 정답 번호는 그대로
# 독립 풀이(답을 모르는 채로 두 번): 두 번 모두 15문항 같은 답, 둘째 답이 서는 문항 없음. 지적받은 표현을 고침
AUTO_SYNC = False
E = {}
from z20common import maker
rw = maker(E)

# ---------- 1번째: 날마다 책 읽기 (답 ③) ----------
rw(0, 2, "Jun reads five books in one week of the summer holidays. Then he does not open a book for three months. You should read for about thirty minutes every single day instead. A little reading every day gives you new words, and they stay in your head. Thirty minutes is short, but one year of it means many books.",
 ["한 해에 읽을 책의 수를 정해야 한다", "주말마다 시간을 내어 독서해야 한다", "매일 일정 시간 독서해야 한다", "방학에 읽을 책은 미리 골라 두어야 한다", "방학에 책을 많이 읽어야 한다"],
 "준은 여름 방학 중 한 주 동안 책을 다섯 권 읽는다. 그러고는 석 달 동안 책을 펴지 않는다. 그러지 말고 날마다 삼십 분쯤 책을 읽어야 한다. 날마다 조금씩 읽으면 새 단어를 얻게 되고, 그 단어들은 머릿속에 남는다. 삼십 분은 짧지만, 그렇게 일 년이면 많은 책이 된다.",
 "You should read for about thirty minutes every single day instead.", "그러지 말고 날마다 삼십 분쯤 책을 읽어야 한다.", 3,
 "'should'는 「~해야 한다」는 뜻이에요. 앞의 두 문장은 준이 방학 때 몰아서 읽고 석 달을 쉬는 이야기이고, 'instead'(그 대신)로 그렇게 하지 말라고 해요. 뒤의 두 문장은 날마다 읽으면 좋은 까닭이에요.",
 "'thirty minutes every single day'(날마다 삼십 분)를 「매일 일정 시간」으로 바꾸어 말한 것이에요.",
 "holiday 방학 / instead 그 대신 / stay 남다",
 ["글의 낱말만 본 것이에요. 'one year'(일 년)는 날마다 읽으면 책이 많이 쌓인다는 말에 나와요. 몇 권을 읽을지 정하라는 말은 없어요.",
  "때가 달라요. 필자는 주말마다가 아니라 날마다 삼십 분쯤 읽으라고 했어요.",
  "셋째 문장과 같은 말이에요. 날마다 삼십 분쯤 읽으라는 것을 「매일 일정 시간」으로 바꾸어 말했어요.",
  "글의 낱말만 본 것이에요. 'the summer holidays'(여름 방학)는 준이 책을 몰아서 읽은 때로 나올 뿐, 책을 미리 고르라는 말은 없어요.",
  "옳은 말처럼 들리지만 필자의 주장이 아니에요. 준이 바로 방학에 몰아서 읽었고, 필자는 그 대신 날마다 읽으라고 했어요."])

# ---------- 2번째: 목표를 종이에 적기 (답 ①) ----------
rw(1, 0, "What is your biggest goal for the rest of this year? You probably keep the answer only inside your own head. A busy month comes, and the goal quietly leaves your mind. Words on paper are different, and they meet your eyes every morning. Write your goal on a card, and put the card on your desk.",
 ["목표는 종이에 적어 두어야 한다", "한 번에 하나의 목표만 세워야 한다", "바쁜 때에는 목표를 낮추어야 한다", "목표는 아침마다 소리 내어 말해야 한다", "목표는 가까운 사람에게 알려야 한다"],
 "올해 남은 동안 여러분의 가장 큰 목표는 무엇인가? 아마 여러분은 그 답을 머릿속에만 담아 두고 있을 것이다. 바쁜 달이 오면 그 목표는 슬그머니 마음에서 떠난다. 종이에 쓴 말은 다르고, 아침마다 눈에 들어온다. 목표를 카드에 써서 그 카드를 책상 위에 두어라.",
 "Write your goal on a card, and put the card on your desk.", "목표를 카드에 써서 그 카드를 책상 위에 두어라.", 5,
 "동사로 시작하는 명령문이에요. 앞에서는 머릿속에만 둔 목표는 바쁘면 잊힌다고 했고, 종이에 쓴 말은 아침마다 눈에 들어온다고 했어요. 그래서 마지막에 「써라」고 말해요.",
 "'on a card'(카드에)를 「종이에」로, 'Write'(써라)를 「적어 두어야 한다」로 바꾸어 말한 것이에요.",
 "goal 목표 / leave 떠나다 / different 다른",
 ["마지막 문장과 같은 말이에요. 목표를 카드에 써서 책상에 두라는 것을 「종이에 적어 두어야 한다」로 바꾸어 말했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 첫 문장이 가장 큰 목표를 묻기는 하지만, 하나만 세우라는 말은 없어요.",
  "글의 낱말만 본 것이에요. 'A busy month'(바쁜 달)는 목표를 잊게 되는 때로 나올 뿐이에요.",
  "방법이 달라요. 'every morning'(아침마다)은 종이에 쓴 말이 눈에 들어오는 때로 나올 뿐이에요. 필자는 말하라고 하지 않고 종이에 써 두라고 했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 남에게 알리는 일은 나오지 않아요."])

# ---------- 3번째: 잠들기 전의 화면 (답 ④) ----------
rw(2, 3, "Mina watches short videos on her phone in bed until midnight. The bright screen keeps her brain awake, and sleep comes very late. The next day she feels sleepy and slow in every class. People should put their screens away one hour before bed. A dark and quiet hour before bed brings sleep much faster.",
 ["영상은 숙제를 마친 뒤에 봐야 한다", "영상은 하루에 한 시간만 봐야 한다", "수업 시간에는 휴대폰을 꺼 두어야 한다", "잠들기 전에는 화면을 멀리해야 한다", "밤에는 화면의 밝기를 낮추어야 한다"],
 "미나는 자정까지 침대에서 휴대폰으로 짧은 영상을 본다. 밝은 화면이 뇌를 깨어 있게 해서 잠이 아주 늦게 온다. 다음 날 그녀는 수업 시간마다 졸리고 굼뜨다. 사람들은 잠자리에 들기 한 시간 전에 화면을 치워야 한다. 잠자기 전의 어둡고 조용한 한 시간이 잠을 훨씬 빨리 불러온다.",
 "People should put their screens away one hour before bed.", "사람들은 잠자리에 들기 한 시간 전에 화면을 치워야 한다.", 4,
 "'should'는 「~해야 한다」는 뜻이에요. 앞의 세 문장은 미나가 밤늦게 화면을 보다가 잠을 못 자는 이야기이고, 마지막 문장은 화면 없는 한 시간이 좋은 까닭이에요.",
 "'put their screens away'(화면을 치우다)를 「화면을 멀리하다」로, 'one hour before bed'(잠자리에 들기 한 시간 전)를 「잠들기 전」으로 바꾸어 말한 것이에요.",
 "midnight 자정 / awake 깨어 있는 / put away 치우다",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 숙제는 나오지 않아요. 필자가 말한 때는 잠들기 한 시간 전이에요.",
  "글의 낱말만 본 것이에요. 'one hour'(한 시간)는 영상을 보는 시간이 아니라 잠들기 전에 화면을 치워 두는 시간이에요.",
  "글의 낱말만 본 것이에요. 'class'(수업)는 미나가 다음 날 졸린 곳으로 나올 뿐, 수업 시간에 휴대폰을 끄라는 말은 없어요.",
  "넷째 문장과 같은 말이에요. 잠자리에 들기 한 시간 전에 화면을 치우라는 것을 「잠들기 전에는 화면을 멀리해야 한다」로 바꾸어 말했어요.",
  "방법이 달라요. 밝은 화면이 문제라고는 했지만, 필자는 밝기를 낮추라고 하지 않고 화면을 치우라고 했어요."])

# ---------- 4번째: 적은 돈을 꾸준히 모으기 (답 ①) ----------
rw(3, 0, "Many young people have little money, so they do not save at all. Start today, and put a few coins in a box every week. The money in the box looks very small in the first month. Week after week the box becomes heavier, and the habit becomes stronger. In a few years, this small habit can pay for a big dream.",
 ["적은 돈이라도 꾸준히 모아야 한다", "저축은 매달 금액을 정해 놓고 해야 한다", "모은 돈은 은행에 넣어야 한다", "돈을 모으기 전에 목표부터 정해야 한다", "돈은 꼭 필요한 곳에만 써야 한다"],
 "많은 젊은이가 가진 돈이 적어서 저축을 아예 하지 않는다. 오늘 시작해서 주마다 동전 몇 개를 상자에 넣어라. 첫 달에는 상자 속의 돈이 아주 적어 보인다. 한 주 한 주 지나면서 상자는 더 무거워지고 습관은 더 굳어진다. 몇 해 뒤에는 이 작은 습관이 큰 꿈의 값을 치러 줄 수 있다.",
 "Start today, and put a few coins in a box every week.", "오늘 시작해서 주마다 동전 몇 개를 상자에 넣어라.", 2,
 "동사로 시작하는 명령문이에요. 첫 문장은 돈이 적다고 저축을 하지 않는 사람들 이야기이고, 필자는 바로 다음 문장에서 그러지 말고 오늘 시작하라고 해요. 뒤의 세 문장은 적은 돈도 쌓이면 커진다는 까닭이에요.",
 "'a few coins'(동전 몇 개)를 「적은 돈」으로, 'every week'(주마다)를 「꾸준히」로 바꾸어 말한 것이에요.",
 "save 저축하다 / coin 동전 / habit 습관",
 ["둘째 문장과 같은 말이에요. 주마다 동전 몇 개를 넣으라는 것을 「적은 돈이라도 꾸준히 모아야 한다」로 바꾸어 말했어요.",
  "글의 낱말만 본 것이에요. 'the first month'(첫 달)는 상자 속 돈이 적어 보이는 때로 나올 뿐이에요. 필자는 금액을 정하라고 하지 않고 주마다 동전 몇 개면 된다고 했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글에 나오는 것은 상자이고, 은행은 나오지 않아요.",
  "글의 낱말만 본 것이에요. 'a big dream'(큰 꿈)은 작은 습관이 이루어 주는 것으로 나올 뿐, 목표부터 정하라는 말은 없어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 돈을 쓰는 일이 아니라 모으는 일을 말해요."])

# ---------- 5번째: 일하기 전에 책상부터 (답 ⑤) ----------
rw(4, 4, "Always clean up your desk first, and only then start your work. Old papers and empty cups pull your eyes away from the page. Your mind follows your eyes, and the work becomes slow. Now look at a clean desk with only a book and a pen. Your attention stays in one place, so the work goes faster.",
 ["일을 마친 뒤에는 책상을 정리하고 일어나야 한다", "일하는 동안에는 휴대폰을 멀리 두어야 한다", "한 번에 한 가지 일만 해야 한다", "책상에는 자주 쓰는 물건을 올려 두어야 한다", "일을 시작하기 전에 책상부터 치워야 한다"],
 "언제나 책상부터 치우고, 그런 다음에야 일을 시작하라. 오래된 종이와 빈 컵은 눈길을 읽던 쪽에서 빼앗아 간다. 마음은 눈을 따라가고, 일은 느려진다. 이제 책 한 권과 펜 하나만 놓인 깨끗한 책상을 보라. 주의가 한곳에 머물러서 일이 더 빨리 나아간다.",
 "Always clean up your desk first, and only then start your work.", "언제나 책상부터 치우고, 그런 다음에야 일을 시작하라.", 1,
 "첫 문장이 명령문이고, 'first'(먼저)와 'only then'(그런 다음에야)으로 순서를 정해 줘요. 넷째 문장도 명령문이지만, 깨끗한 책상을 떠올려 보라는 말일 뿐이에요. 나머지 문장은 모두 책상을 치워야 하는 까닭이에요.",
 "'first … only then start your work'(먼저 … 그런 다음에야 일을 시작하라)를 「일을 시작하기 전에」로 바꾸어 말한 것이에요.",
 "clean up 치우다 / empty 빈 / attention 주의",
 ["때가 달라요. 필자는 일을 마친 뒤가 아니라 일을 시작하기에 앞서 책상을 치우라고 했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 휴대폰은 나오지 않아요.",
  "글의 낱말만 본 것이에요. 'in one place'(한곳에)는 책상이 깨끗하면 주의가 한곳에 머문다는 말이에요. 필자가 하라고 한 일은 책상을 치우는 것이에요.",
  "글과 맞지 않아요. 필자는 책 한 권과 펜 하나만 놓인 깨끗한 책상을 보라고 했어요.",
  "첫 문장과 같은 말이에요. 먼저 책상을 치우고 그런 다음에 일을 시작하라는 것을 「일을 시작하기 전에 책상부터 치워야 한다」로 바꾸어 말했어요."])

# ---------- 6번째: 날마다 같은 시간에 자기 (답 ③) ----------
rw(5, 2, "Some students go to bed at ten on Monday and at one on Friday. On Saturday they sleep until noon, and Monday morning feels terrible. The body has its own clock, and the clock likes regular hours. A different bedtime every night slowly breaks this body clock. You should go to bed at the same time every night.",
 ["잠자기 전에는 따뜻한 물로 씻어야 한다", "잠은 하루에 여덟 시간을 채워서 자야 한다", "잠자리에 드는 시간을 일정하게 지켜야 한다", "잠자기 전에는 방을 어둡게 해 두어야 한다", "주말에는 모자란 잠을 넉넉히 보충해야 한다"],
 "어떤 학생들은 월요일에는 열 시에, 금요일에는 한 시에 잠자리에 든다. 토요일에는 정오까지 자고, 월요일 아침은 끔찍하게 느껴진다. 몸에는 제 시계가 있고, 그 시계는 규칙적인 시간을 좋아한다. 밤마다 다른 취침 시간은 이 몸속 시계를 조금씩 망가뜨린다. 밤마다 같은 시간에 잠자리에 들어야 한다.",
 "You should go to bed at the same time every night.", "밤마다 같은 시간에 잠자리에 들어야 한다.", 5,
 "'should'는 「~해야 한다」는 뜻이에요. 앞의 네 문장은 자는 시간이 날마다 다르면 몸속 시계가 망가진다는 까닭이고, 마지막 문장이 그래서 어떻게 하라는 말이에요.",
 "'at the same time every night'(밤마다 같은 시간에)를 「시간을 일정하게 지키다」로 바꾸어 말한 것이에요.",
 "noon 정오 / regular 규칙적인 / bedtime 취침 시간",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 자기 전에 무엇을 하는지가 아니라 몇 시에 잠자리에 드는지를 말해요.",
  "대상이 달라요. 글은 얼마나 오래 자는지가 아니라 언제 잠자리에 드는지를 말해요.",
  "마지막 문장과 같은 말이에요. 밤마다 같은 시간에 자라는 것을 「잠자리에 드는 시간을 일정하게 지켜야 한다」로 바꾸어 말했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 방의 밝기는 나오지 않아요.",
  "글과 반대예요. 토요일에 정오까지 자면 월요일 아침이 끔찍해진다고 했어요."])

# ---------- 7번째: 큰일을 작은 목표로 나누기 (답 ②) ----------
rw(6, 1, "Pick up a thick book of three hundred pages in a bookshop. It looks like a mountain, and many readers put it back. Cut the mountain into small pieces, and set a small goal for each day. Ten pages a day sounds easy, so you start at once. After only one month, the whole mountain is already behind you.",
 ["처음에는 얇고 쉬운 책부터 읽어야 한다", "날마다 이룰 수 있는 작은 목표를 세워야 한다", "책은 서점에서 직접 보고 골라야 한다", "큰 목표는 끝낼 날짜부터 정해야 한다", "읽은 쪽수는 날마다 공책에 적어 두어야 한다"],
 "서점에서 삼백 쪽짜리 두꺼운 책을 집어 들어 보라. 그것은 산처럼 보이고, 많은 독자는 도로 내려놓는다. 그 산을 작은 조각으로 자르고, 날마다 작은 목표를 세워라. 하루 열 쪽은 쉽게 들려서 곧바로 시작하게 된다. 겨우 한 달 뒤에는 그 산 전체가 이미 여러분 뒤에 있다.",
 "Cut the mountain into small pieces, and set a small goal for each day.", "그 산을 작은 조각으로 자르고, 날마다 작은 목표를 세워라.", 3,
 "셋째 문장이 명령문이에요. 첫 문장도 명령문이지만, 두꺼운 책을 떠올려 보라는 말일 뿐이에요. 셋째 문장 뒤의 두 문장이 「하루 열 쪽이면 쉽고, 한 달이면 끝난다」고 그 까닭을 대요. 뒤 문장들이 받쳐 주는 쪽이 주장이에요.",
 "'a small goal for each day'(날마다의 작은 목표)를 「날마다 이룰 수 있는 작은 목표」로 바꾸어 말한 것이에요.",
 "thick 두꺼운 / piece 조각 / at once 곧바로",
 ["방법이 달라요. 필자는 두꺼운 책을 피하라고 하지 않고, 그 책을 작게 나누어 읽으라고 했어요.",
  "셋째 문장과 같은 말이에요. 산을 작은 조각으로 자르고 날마다 작은 목표를 세우라는 것을 「날마다 이룰 수 있는 작은 목표」로 바꾸어 말했어요.",
  "글의 낱말만 본 것이에요. 'a bookshop'(서점)은 두꺼운 책을 집어 드는 곳으로 나올 뿐, 책을 고르는 방법은 나오지 않아요.",
  "방법이 달라요. 필자는 날짜를 정하라고 하지 않고, 큰일을 작은 조각으로 잘라 날마다 조금씩 하라고 했어요.",
  "글의 낱말만 본 것이에요. 'Ten pages a day'(하루 열 쪽)는 작은 목표의 보기로 나올 뿐, 적으라는 말은 없어요."])

# ---------- 8번째: 그날 저녁에 노트 다시 보기 (답 ⑤) ----------
rw(7, 4, "Your memory of a lesson is strong for only one day. A week later, half of the lesson is gone from your head. Many students open their notes only before a test, and the words feel new. The best time to read your notes is the evening of the same day. The lesson is still fresh then, so every line is easy to understand.",
 ["시험 전에는 노트를 처음부터 다시 봐야 한다", "노트는 한 주에 한 번 날을 정해 정리해야 한다", "수업 중에는 중요한 말을 바로 적어 두어야 한다", "수업 중에는 적기보다 듣기에 힘써야 한다", "수업을 들은 그날 노트를 다시 봐야 한다"],
 "수업에 대한 기억은 하루 동안만 또렷하다. 한 주 뒤에는 수업의 절반이 머릿속에서 사라진다. 많은 학생이 시험 전에만 노트를 펴는데, 그러면 적힌 말들이 낯설게 느껴진다. 노트를 읽기에 가장 좋은 때는 같은 날 저녁이다. 그때는 수업이 아직 생생해서 줄마다 이해하기 쉽다.",
 "The best time to read your notes is the evening of the same day.", "노트를 읽기에 가장 좋은 때는 같은 날 저녁이다.", 4,
 "「가장 좋은 때는 ~이다」는 「그때 하라」는 뜻이에요. 앞의 세 문장은 기억이 금방 흐려지고 시험 전에 보면 낯설다는 까닭이고, 마지막 문장은 그날 저녁에 보면 쉬운 까닭이에요.",
 "'the evening of the same day'(같은 날 저녁)를 「수업을 들은 그날」로 바꾸어 말한 것이에요.",
 "memory 기억 / fresh 생생한 / understand 이해하다",
 ["때가 달라요. 시험 전에만 노트를 펴면 적힌 말이 낯설게 느껴진다고 했어요. 필자가 말한 때는 같은 날 저녁이에요.",
  "때가 달라요. 한 주 뒤에는 수업의 절반이 사라진다고 했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 노트를 어떻게 적는지가 아니라 언제 다시 읽는지를 말해요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 수업 중에 무엇을 하는지가 아니라 노트를 언제 다시 읽는지를 말해요.",
  "넷째 문장과 같은 말이에요. 노트를 읽기에 가장 좋은 때가 같은 날 저녁이라는 것을 「수업을 들은 그날 노트를 다시 봐야 한다」로 바꾸어 말했어요."],
 lead="① 이 글에는 '~해야 한다'(should)나 명령문이 없어요. 이럴 때는 필자가 '가장 좋다'(the best)고 말하는 문장에서 주장을 찾아요. 이 글에서는 넷째 문장이에요.")

# ---------- 9번째: 새 파일은 받자마자 제자리에 (답 ②) ----------
rw(8, 1, "New files from the internet arrive on your computer almost every day. You should move each new file into the right folder at once. Most people leave the files on the screen, and the screen fills up. A month later they need one photo, but they cannot find it. Three seconds today can save thirty minutes of looking next month.",
 ["파일은 날을 정해 한꺼번에 정리해야 한다", "새 파일은 받자마자 제자리에 넣어야 한다", "자주 쓰는 파일은 바탕 화면에 두어야 한다", "필요 없는 파일은 그때그때 지워야 한다", "사진은 찍은 날짜별로 나누어 두어야 한다"],
 "인터넷에서 받은 새 파일이 거의 날마다 컴퓨터에 들어온다. 새 파일은 하나하나 곧바로 알맞은 폴더에 옮겨야 한다. 대부분의 사람은 파일을 화면에 그대로 두고, 화면은 가득 찬다. 한 달 뒤 사진 한 장이 필요한데 찾을 수가 없다. 오늘의 삼 초가 다음 달에 찾아 헤맬 삼십 분을 아껴 줄 수 있다.",
 "You should move each new file into the right folder at once.", "새 파일은 하나하나 곧바로 알맞은 폴더에 옮겨야 한다.", 2,
 "'should'는 「~해야 한다」는 뜻이에요. 첫 문장은 새 파일이 날마다 생긴다는 사정이고, 뒤의 세 문장은 미루면 생기는 일과 바로 하면 좋은 까닭이에요.",
 "'at once'(곧바로)를 「받자마자」로, 'into the right folder'(알맞은 폴더에)를 「제자리에」로 바꾸어 말한 것이에요.",
 "arrive 도착하다 / folder 폴더 / at once 곧바로",
 ["때가 달라요. 필자는 날을 정해 몰아서 하지 말고 새 파일이 생기는 대로 곧바로 옮기라고 했어요.",
  "둘째 문장과 같은 말이에요. 새 파일을 곧바로 알맞은 폴더에 옮기라는 것을 「받자마자 제자리에 넣어야 한다」로 바꾸어 말했어요.",
  "글과 맞지 않아요. 파일을 화면에 그대로 두면 화면이 가득 찬다고 했어요.",
  "방법이 달라요. 곧바로 하라는 것은 지우는 일이 아니라 알맞은 폴더에 옮기는 일이에요.",
  "글의 낱말만 본 것이에요. 'one photo'(사진 한 장)는 찾지 못하는 파일의 보기로 나올 뿐이에요."])

# ---------- 10번째: 중요한 파일을 매주 복사해 두기 (답 ②) ----------
rw(9, 1, "A computer can stop working on any day without warning. All your photos and homework are inside, and they can disappear in a second. Hana lost three years of pictures this way last spring. A second copy in another place stays safe on such a day. So copy your important files to another place once every week.",
 ["컴퓨터를 바꿀 때는 파일을 옮겨 두어야 한다", "중요한 파일은 매주 따로 복사해 두어야 한다", "컴퓨터가 멈추면 바로 수리점에 맡겨야 한다", "중요한 파일에는 비밀번호를 걸어 두어야 한다", "숙제를 할 때는 파일을 자주 저장해야 한다"],
 "컴퓨터는 어느 날이든 예고 없이 멈출 수 있다. 사진과 숙제가 모두 그 안에 있고, 그것들은 한순간에 사라질 수 있다. 하나는 지난봄에 이렇게 삼 년 치 사진을 잃었다. 다른 곳에 둔 또 하나의 복사본은 그런 날에도 안전하게 남는다. 그러니 중요한 파일을 일주일에 한 번 다른 곳에 복사해 두어라.",
 "So copy your important files to another place once every week.", "그러니 중요한 파일을 일주일에 한 번 다른 곳에 복사해 두어라.", 5,
 "'So'(그러니) 뒤에 동사 'copy'로 시작하는 명령문이에요. 앞의 세 문장은 컴퓨터가 갑자기 멈추면 안에 든 것이 사라질 수 있다는 이야기이고, 넷째 문장은 다른 곳에 둔 복사본은 안전하다는 까닭이에요. 'So'가 그 까닭을 받아 무엇을 하라고 말해요.",
 "'to another place'(다른 곳에)를 「따로」로, 'once every week'(일주일에 한 번)를 「매주」로 바꾸어 말한 것이에요.",
 "warning 예고, 경고 / disappear 사라지다 / copy 복사하다, 복사본",
 ["때가 달라요. 컴퓨터는 예고 없이 멈춘다고 했어요. 그래서 컴퓨터를 바꿀 때가 아니라 매주 한 번씩 복사해 두라는 것이에요.",
  "마지막 문장과 같은 말이에요. 중요한 파일을 일주일에 한 번 다른 곳에 복사하라는 것을 「매주 따로 복사해 두어야 한다」로 바꾸어 말했어요.",
  "때가 달라요. 필자는 멈춘 뒤의 일이 아니라 멈추기 전에 해 둘 일을 말해요.",
  "방법이 달라요. 글에서 걱정하는 것은 남이 보는 일이 아니라 파일이 사라지는 일이에요. 그래서 다른 곳에 복사해 두라고 했어요.",
  "방법이 달라요. 저장만 해 두면 컴퓨터가 멈출 때 함께 사라질 수 있어요. 그래서 필자는 다른 곳에 복사해 두라고 했어요."])

# ---------- 11번째: 여행 전날 휴대폰 충전 (답 ①) ----------
rw(10, 0, "On a long trip, your phone works harder than usual. It shows maps and takes photos, and the battery goes down fast. You must charge the phone fully on the night before the trip. A dead phone cannot show your ticket or call your family. Buses and trains do not always have a place for charging.",
 ["여행 전날 휴대폰을 가득 충전해야 한다", "여행 중에는 휴대폰 배터리를 아껴 써야 한다", "여행 중에는 틈나는 대로 충전해야 한다", "표는 종이로도 뽑아서 들고 다녀야 한다", "여행 전날에는 표와 지도를 내려받아 두어야 한다"],
 "긴 여행에서는 휴대폰이 평소보다 더 많은 일을 한다. 지도를 보여 주고 사진을 찍어서 배터리가 빨리 닳는다. 여행 전날 밤에 휴대폰을 가득 충전해야 한다. 꺼진 휴대폰은 표를 보여 줄 수도, 가족에게 전화할 수도 없다. 버스와 기차에 충전할 곳이 늘 있는 것은 아니다.",
 "You must charge the phone fully on the night before the trip.", "여행 전날 밤에 휴대폰을 가득 충전해야 한다.", 3,
 "'must'는 「꼭 ~해야 한다」는 뜻이에요. 앞의 두 문장은 여행 중에 배터리가 빨리 닳는다는 사정이고, 뒤의 두 문장은 꺼지면 곤란하고 길에서는 충전하기 어렵다는 까닭이에요.",
 "'fully'(가득)와 'on the night before the trip'(여행 전날 밤에)을 「여행 전날 … 가득」으로 옮긴 것이에요.",
 "trip 여행 / battery 배터리 / charge 충전하다",
 ["셋째 문장과 같은 말이에요. 여행 전날 밤에 휴대폰을 가득 충전하라는 말이에요.",
  "옳은 말처럼 들리지만 필자의 주장이 아니에요. 여행 중에 배터리가 빨리 닳는다고는 했지만, 덜 쓰라는 말은 없어요.",
  "글과 맞지 않아요. 버스와 기차에는 충전할 곳이 늘 있지는 않다고 했어요. 그래서 떠나기 전날 밤에 가득 채우라는 것이에요.",
  "방법이 달라요. 꺼진 휴대폰은 표를 못 보여 준다고 했지만, 필자가 하라고 한 일은 충전이에요.",
  "글의 낱말만 본 것이에요. 'maps'(지도)와 'ticket'(표)은 휴대폰이 하는 일로 나올 뿐이에요. 필자가 전날 밤에 하라고 한 일은 충전이에요."])

# ---------- 12번째: 궁금한 것은 그 자리에서 묻기 (답 ④) ----------
rw(11, 3, "A question comes into your head in the middle of a club meeting. It sounds a little silly to you, so you keep quiet. Two other members have the same question, but they are quiet too. The meeting moves on, and all three of you are lost. Ask your question right away, and do not wait for the end.",
 ["회의에서는 질문을 짧고 분명하게 해야 한다", "회의 전에 물어볼 것을 미리 적어 가야 한다", "궁금한 점은 옆 사람에게 조용히 물어야 한다", "회의 중 궁금한 점은 그 자리에서 물어야 한다", "궁금한 점은 회의가 끝난 뒤에 따로 물어야 한다"],
 "동아리 회의 도중에 궁금한 것이 머리에 떠오른다. 그것이 좀 엉뚱하게 들려서 여러분은 입을 다문다. 다른 회원 둘도 같은 것이 궁금하지만, 그들도 조용하다. 회의는 다음으로 넘어가고, 여러분 셋은 모두 흐름을 놓친다. 궁금한 것은 곧바로 묻고, 끝날 때까지 기다리지 마라.",
 "Ask your question right away, and do not wait for the end.", "궁금한 것은 곧바로 묻고, 끝날 때까지 기다리지 마라.", 5,
 "동사 'Ask'로 시작하는 명령문이에요. 앞의 네 문장은 묻지 않고 넘어가면 여러 사람이 함께 흐름을 놓친다는 까닭이에요.",
 "'right away'(곧바로)를 「그 자리에서」로 바꾸어 말한 것이에요.",
 "silly 엉뚱한, 어리석은 / member 회원 / lost 흐름을 놓친, 길을 잃은",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 질문을 어떻게 하는지가 아니라 언제 하는지를 말해요.",
  "지문에 없는 이야기예요. 글의 질문은 회의 도중에 떠오른 것이에요.",
  "글과 맞지 않아요. 다른 두 회원도 같은 것을 몰라서 조용히 있다고 했어요. 그래서 필자는 옆 사람에게가 아니라 회의에서 곧바로 물으라고 해요.",
  "마지막 문장과 같은 말이에요. 곧바로 묻고 끝까지 기다리지 말라는 것을 「그 자리에서 물어야 한다」로 바꾸어 말했어요.",
  "때가 달라요. 필자는 곧바로 묻고 끝날 때까지 기다리지 말라고 했어요."])

# ---------- 13번째: 짐 쌀 때 상자에 적기 (답 ②) ----------
rw(12, 1, "Think about ten brown boxes in the middle of a new house. You need one cup, and you open five boxes for it. A pen can save you from this trouble on packing day. On each box, write a few words about the things inside. In the new house, you will walk straight to the right box.",
 ["이사할 때는 상자를 크기별로 쌓아야 한다", "짐을 쌀 때 상자마다 내용물을 적어야 한다", "깨지기 쉬운 컵은 따로 싸서 직접 옮겨야 한다", "새집에 가면 자주 쓰는 물건부터 꺼내야 한다", "짐을 쌀 때 물건의 목록을 공책에 적어야 한다"],
 "새집 한가운데에 놓인 갈색 상자 열 개를 떠올려 보라. 컵 하나가 필요해서 상자 다섯 개를 열게 된다. 짐 싸는 날에 펜 하나가 이런 수고를 덜어 줄 수 있다. 상자마다 안에 든 물건에 대해 몇 마디를 적어라. 새집에서 여러분은 맞는 상자로 곧장 걸어갈 것이다.",
 "On each box, write a few words about the things inside.", "상자마다 안에 든 물건에 대해 몇 마디를 적어라.", 4,
 "넷째 문장이 명령문이에요. 첫 문장도 명령문이지만, 이사한 날의 상자를 떠올려 보라는 말일 뿐이에요. 셋째 문장의 'on packing day'(짐 싸는 날에)가 언제 적는지를 알려 줘요.",
 "'a few words about the things inside'(안에 든 물건에 대한 몇 마디)를 「내용물」로, 'on packing day'를 「짐을 쌀 때」로 바꾸어 말한 것이에요.",
 "trouble 수고, 곤란 / packing 짐 싸기 / straight 곧장",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 상자를 쌓는 방법은 나오지 않아요.",
  "넷째 문장과 같은 말이에요. 상자마다 안에 든 물건을 몇 마디 적으라는 것을 「상자마다 내용물을 적어야 한다」로 바꾸어 말했어요.",
  "글의 낱말만 본 것이에요. 'one cup'(컵 하나)은 찾으려는 물건의 보기로 나올 뿐이에요.",
  "때가 달라요. 필자는 새집에 간 뒤의 일이 아니라 짐을 싸는 날에 할 일을 말해요.",
  "적는 곳이 달라요. 필자는 공책이 아니라 상자마다 그 위에 적으라고 했어요. 그래야 맞는 상자로 곧장 갈 수 있어요."])

# ---------- 14번째: 화재경보기를 매달 확인하기 (답 ⑤) ----------
rw(13, 4, "Every family should test its smoke alarm once a month. The alarm sits quietly on the ceiling for many years. Dust and time slowly make it weak, and nobody in the house notices. A fire can start at night, and a broken alarm cannot wake anyone. One push of the test button tells you the truth.",
 ["화재경보기는 방마다 하나씩 달아야 한다", "화재경보기의 건전지는 해마다 갈아 주어야 한다", "자기 전에는 가스 불이 꺼졌는지 살펴야 한다", "화재경보기가 울리면 곧바로 집 밖으로 나가야 한다", "화재경보기가 잘 작동하는지 매달 확인해야 한다"],
 "어느 집이나 한 달에 한 번 화재경보기를 시험해 보아야 한다. 경보기는 여러 해 동안 천장에 조용히 붙어 있다. 먼지와 시간이 조금씩 그것을 약하게 만드는데, 집 안의 누구도 알아차리지 못한다. 불은 밤에 날 수 있고, 고장 난 경보기는 아무도 깨우지 못한다. 시험 단추를 한 번 눌러 보면 사실을 알 수 있다.",
 "Every family should test its smoke alarm once a month.", "어느 집이나 한 달에 한 번 화재경보기를 시험해 보아야 한다.", 1,
 "'should'는 「~해야 한다」는 뜻이에요. 필자는 첫 문장에서 하고 싶은 말을 먼저 하고, 뒤의 네 문장에서 그 까닭을 대요. 경보기는 모르는 사이에 고장 날 수 있어요.",
 "'test'(시험해 보다)를 「잘 작동하는지 확인하다」로, 'once a month'(한 달에 한 번)를 「매달」로 바꾸어 말한 것이에요.",
 "smoke alarm 화재경보기 / ceiling 천장 / notice 알아차리다",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 경보기를 몇 개 다는지는 나오지 않아요.",
  "방법이 달라요. 글은 건전지를 갈라고 하지 않고 한 달에 한 번 시험해 보라고 했어요.",
  "글의 낱말만 본 것이에요. 'at night'(밤에)은 불이 날 수 있는 때로 나올 뿐, 가스 불 이야기는 없어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 경보기가 울린 뒤의 일이 아니라 울리는지 미리 시험하는 일을 말해요.",
  "첫 문장과 같은 말이에요. 한 달에 한 번 경보기를 시험해 보라는 것을 「잘 작동하는지 매달 확인해야 한다」로 바꾸어 말했어요."])

# ---------- 15번째: 알아보기 쉬운 파일 이름 (답 ④) ----------
rw(14, 3, "Many files on a computer have short names like Final or New. Always save each of your files with a clear and full name. A name like Final tells you nothing, so you open every file. A good name shows the subject and the date together. With such names, you can find any file in a few seconds.",
 ["파일 이름에는 만든 사람의 이름을 넣어야 한다", "파일은 만든 날짜순으로 정리해 두어야 한다", "파일 이름은 한눈에 들어오게 짧게 지어야 한다", "파일을 저장할 때 알아보기 쉬운 이름을 붙여야 한다", "파일은 과목마다 서로 다른 폴더에 나누어 넣어야 한다"],
 "컴퓨터의 많은 파일이 Final이나 New 같은 짧은 이름을 달고 있다. 파일은 언제나 하나하나 또렷하고 온전한 이름으로 저장하라. Final 같은 이름은 아무것도 알려 주지 않아서, 파일을 모두 열어 보게 된다. 좋은 이름은 과목과 날짜를 함께 보여 준다. 그런 이름이 있으면 어떤 파일이든 몇 초 만에 찾을 수 있다.",
 "Always save each of your files with a clear and full name.", "파일은 언제나 하나하나 또렷하고 온전한 이름으로 저장하라.", 2,
 "'Always'(언제나) 뒤에 동사 'save'가 오는 명령문이에요. 첫 문장은 이름을 대충 짓는 사정이고, 뒤의 세 문장은 그러면 불편하고 좋은 이름은 편리하다는 까닭이에요.",
 "'a clear and full name'(또렷하고 온전한 이름)을 「알아보기 쉬운 이름」으로 바꾸어 말한 것이에요.",
 "save 저장하다 / clear 또렷한 / subject 과목",
 ["글과 달라요. 좋은 이름이 보여 주는 것은 과목과 날짜라고 했어요. 만든 사람의 이름은 나오지 않아요.",
  "글의 낱말만 본 것이에요. 'the date'(날짜)는 좋은 이름이 보여 주는 것으로 나올 뿐이에요.",
  "글과 반대예요. Final 같은 짧은 이름은 아무것도 알려 주지 않는다고 했어요.",
  "둘째 문장과 같은 말이에요. 또렷하고 온전한 이름으로 저장하라는 것을 「저장할 때 알아보기 쉬운 이름을 붙여야 한다」로 바꾸어 말했어요.",
  "글의 낱말만 본 것이에요. 'the subject'(과목)는 좋은 이름이 보여 주는 것으로 나올 뿐, 폴더는 나오지 않아요."])
