# -*- coding: utf-8 -*-
# 319번: 20번(주장) 레벨2 — 레벨2 기준으로 다시 씀 (뒤 절반: 16~30번째)
# 꼴은 앞 절반(edits_X56a.py)과 같음: 다섯 문장 · 문장당 10~15낱말 · 단문과 and·but·so·or로 이은 문장 · 선택지 다섯 모두 「~해야 한다」
# 318번에 정한 것을 처음부터 지킴:
#   - 선택지 쓰는 다섯 가지 방법(LEVEL_GUIDE.md) — 오답도 그럴듯한 조언 / 한 가지만 비틂 / 글과 반대인 오답은 하나까지 / 글의 낱말은 오답에 / 끌리는 오답 하나
#   - 주장의 방향을 섞음: 「조금만」(16) · 「쉬었다가」(17) · 「시간을 두고」(19) · 「모아서」(21) · 「비워 두고」(30)는 「꾸준히·바로·미리」와 다른 쪽
#   - 오답끼리 맞서는 짝: 25번째(④ 적어 둔다 ↔ ⑤ 적지 않는다) · 30번째(① 전날 밤 ↔ ③ 아침). 정답과 한 가지만 다른 쌍둥이 오답: 19번째 ③·④ · 24번째 ① · 28번째 ④ · 29번째 ③
#   - 주장이 아닌 명령문이 하나 더 있는 문항: 18 · 23 · 30번째(Think about … · Look at … · Imagine …)
#   - 주장 문장의 자리: 첫째 3 · 둘째 3 · 셋째 3 · 넷째 3 · 다섯째 3
#   - 글감: 앞 절반(파일·잠·독서)과 겹치지 않게. 옛 글감을 지킨 문항 22(감사) · 23(물) · 24(문 잠그기) · 26(서명 전 읽기) · 28(공유 전 확인) · 29(약속 확인),
#     주장을 바꾼 문항 16 · 17 · 18 · 19 · 20 · 21 · 25 · 27 · 30(앞 절반과 겹치거나 서로 겹치던 글감 — 인계문서 319번에 표)
AUTO_SYNC = False
E = {}
from z20common import maker
rw = maker(E)

# ---------- 16번째: 여행 짐은 꼭 필요한 것만 (답 ①) ----------
rw(15, 0, "Sora packs three jackets and four pairs of shoes for a short trip. The bag is very heavy, and her arms hurt on the stairs. She wears only one jacket and one pair of shoes on the trip. You should put only a few important things in your travel bag. A light bag is easy on your arms, and your trip becomes fun.",
 ["여행 짐은 꼭 필요한 것만 챙겨야 한다", "여행 짐은 떠나기 며칠 전부터 챙겨야 한다", "여행 짐은 만일에 대비해 넉넉히 챙겨야 한다", "여행 짐은 가방 여러 개에 나누어 담아야 한다", "여행 짐은 그곳 날씨에 맞추어 챙겨야 한다"],
 "소라는 짧은 여행에 겉옷 세 벌과 신발 네 켤레를 챙긴다. 가방이 아주 무거워서 계단에서 팔이 아프다. 여행하는 동안 그녀가 쓰는 것은 겉옷 한 벌과 신발 한 켤레뿐이다. 여행 가방에는 중요한 것 몇 가지만 넣어야 한다. 가벼운 가방은 팔이 편하고, 여행이 즐거워진다.",
 "You should put only a few important things in your travel bag.", "여행 가방에는 중요한 것 몇 가지만 넣어야 한다.", 4,
 "'should'는 「~해야 한다」는 뜻이에요. 앞의 세 문장은 소라의 이야기예요. 짐을 많이 싸서 고생했는데, 정작 쓴 것은 조금뿐이었어요. 마지막 문장은 짐이 가벼우면 좋은 까닭이에요.",
 "'only a few important things'(중요한 것 몇 가지만)를 「꼭 필요한 것만」으로 바꾸어 말한 것이에요.",
 "pack 짐을 싸다 / stairs 계단 / light 가벼운",
 ["넷째 문장과 같은 말이에요. 중요한 것 몇 가지만 넣으라는 것을 「꼭 필요한 것만 챙겨야 한다」로 바꾸어 말했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 짐을 언제 싸는지가 아니라 얼마나 싸는지를 말해요.",
  "글과 반대예요. 소라는 넉넉히 챙겼다가 가방이 무거워 고생했고, 그 가운데 조금만 썼어요.",
  "방법이 달라요. 필자는 짐을 나누어 담으라고 하지 않고 짐을 줄이라고 했어요.",
  "글의 낱말만 본 것이에요. 'jackets'(겉옷)는 소라가 너무 많이 챙긴 물건으로 나올 뿐, 날씨 이야기는 없어요."])

# ---------- 17번째: 안 풀릴 때는 쉬었다가 (답 ⑤) ----------
rw(16, 4, "Minho looks at one hard math problem for a whole hour. His head begins to hurt, and the numbers mean nothing to him. He goes out for a short walk and thinks about nothing. Ten minutes later the answer comes to him on the way home. Leave a hard problem for a while, and come back with a clear head.",
 ["어려운 문제는 풀이를 보기 전에 오래 고민해 봐야 한다", "수학 문제는 날마다 조금씩 풀어야 한다", "어려운 문제는 친구와 함께 풀어야 한다", "수학 공부는 머리가 맑은 아침 시간에 해야 한다", "문제가 안 풀릴 때는 잠시 쉬었다가 다시 해야 한다"],
 "민호는 어려운 수학 문제 하나를 한 시간 내내 들여다본다. 머리가 아파 오고, 숫자들이 아무 뜻도 없어 보인다. 그는 잠깐 걸으러 나가서 아무 생각도 하지 않는다. 십 분 뒤 집으로 돌아오는 길에 답이 떠오른다. 어려운 문제는 잠시 놓아두었다가, 맑은 머리로 돌아와라.",
 "Leave a hard problem for a while, and come back with a clear head.", "어려운 문제는 잠시 놓아두었다가, 맑은 머리로 돌아와라.", 5,
 "동사 'Leave'로 시작하는 명령문이에요. 앞의 네 문장은 민호의 이야기예요. 한 시간을 붙잡아도 안 풀리던 문제의 답이, 잠깐 걷고 돌아오는 길에 떠올랐어요. 필자는 이 이야기를 까닭으로 삼아 마지막에 하고 싶은 말을 해요.",
 "'Leave … for a while'(잠시 놓아두다)을 「잠시 쉬었다가」로, 'come back'(돌아오다)을 「다시 해야 한다」로 바꾸어 말한 것이에요.",
 "whole 온, 전체의 / for a while 잠시 동안 / clear 맑은",
 ["글과 맞지 않아요. 민호는 한 시간 내내 붙잡고 있었지만 머리만 아팠어요. 답은 문제를 놓아둔 뒤에 떠올랐어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 날마다 얼마나 푸는지는 나오지 않아요.",
  "방법이 달라요. 민호는 친구를 찾아가지 않고 잠깐 걷고 왔어요.",
  "글의 낱말만 본 것이에요. 'a clear head'(맑은 머리)는 아침의 머리가 아니라 잠깐 쉬고 온 뒤의 머리를 말해요.",
  "마지막 문장과 같은 말이에요. 잠시 놓아두었다가 돌아오라는 것을 「잠시 쉬었다가 다시 해야 한다」로 바꾸어 말했어요."])

# ---------- 18번째: 손전등은 정해 둔 자리에 (답 ③) ----------
rw(17, 2, "Think about a night without any power or lights in your house. A flashlight must have its own special place near the front door. In the dark, nobody can look through ten drawers for it. Everyone passes the front door every day, so nobody forgets that place. A small light in your hand makes a dark house safe again.",
 ["손전등의 건전지는 정기적으로 갈아야 한다", "손전등은 식구마다 하나씩 갖고 있어야 한다", "손전등은 현관 가까이 정해 둔 자리에 두어야 한다", "손전등은 밝고 가벼운 것으로 골라서 사 두어야 한다", "손전등은 침대 옆 서랍에 넣어 두어야 한다"],
 "집에 전기도 불빛도 없는 밤을 떠올려 보라. 손전등은 현관문 가까이에 제자리가 따로 있어야 한다. 어둠 속에서는 누구도 서랍 열 개를 뒤져 그것을 찾을 수 없다. 누구나 날마다 현관문을 지나다니므로 아무도 그 자리를 잊지 않는다. 손에 든 작은 불빛 하나가 어두운 집을 다시 안전하게 만든다.",
 "A flashlight must have its own special place near the front door.", "손전등은 현관문 가까이에 제자리가 따로 있어야 한다.", 2,
 "'must'는 「꼭 ~해야 한다」는 뜻이에요. 첫 문장도 명령문이지만, 불이 나간 밤을 떠올려 보라는 말일 뿐이에요. 뒤의 세 문장은 까닭이에요. 어둠 속에서는 서랍을 뒤져서 찾을 수 없고, 현관문은 누구나 날마다 지나다니는 곳이라 아무도 그 자리를 잊지 않아요.",
 "'its own special place'(따로 마련한 제자리)를 「정해 둔 자리」로, 'near the front door'(현관문 가까이에)를 「현관 가까이」로 바꾸어 말한 것이에요.",
 "flashlight 손전등 / power 전기 / drawer 서랍",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 건전지는 나오지 않아요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 손전등을 몇 개 두는지가 아니라 손전등 하나의 자리를 어디로 정하는지를 말해요.",
  "둘째 문장과 같은 말이에요. 손전등은 현관문 가까이에 제자리가 따로 있어야 한다는 것을 「현관 가까이 정해 둔 자리에 두어야 한다」로 바꾸어 말했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 어떤 손전등을 고르는지가 아니라 어디에 두는지를 말해요.",
  "곳이 달라요. 필자가 말한 자리는 침대 옆이 아니라 현관문 가까이예요. 서랍은 어둠 속에서 뒤지기 어려운 곳으로 나와요."])

# ---------- 19번째: 화날 때 쓴 메시지는 시간을 두고 (답 ⑤) ----------
rw(18, 4, "A friend says something bad about you, and your face turns red. You write a long and angry message to her in two minutes. Keep that message on your phone for one night, and do not send it yet. In the morning the same words look too strong, and you change them. A late message hurts nobody, but a fast one can end a friendship.",
 ["화가 났을 때는 그 자리를 잠시 떠나 있어야 한다", "화가 났을 때는 그 마음을 바로 말해야 한다", "화가 났을 때 쓴 메시지는 지우고 말로 풀어야 한다", "화가 났을 때 쓴 메시지는 다른 사람에게 먼저 보여야 한다", "화가 났을 때 쓴 메시지는 시간을 두고 보내야 한다"],
 "친구가 여러분에 대해 나쁜 말을 해서 얼굴이 붉어진다. 여러분은 2분 만에 친구에게 보낼 길고 화난 메시지를 쓴다. 그 메시지는 하룻밤 휴대폰에 그대로 두고, 아직 보내지 마라. 아침이 되면 같은 말이 너무 세 보여서 고치게 된다. 늦은 메시지는 아무도 다치게 하지 않지만, 빠른 메시지는 우정을 끝낼 수 있다.",
 "Keep that message on your phone for one night, and do not send it yet.", "그 메시지는 하룻밤 휴대폰에 그대로 두고, 아직 보내지 마라.", 3,
 "동사 'Keep'으로 시작하는 명령문이에요. 앞의 두 문장은 화가 나서 메시지를 쓰는 장면이에요. 뒤의 두 문장은 까닭이에요. 아침에 보면 말이 너무 세서 고치게 되고, 늦게 보내서 탈이 나는 일은 없어요.",
 "'for one night'(하룻밤 동안)를 「시간을 두고」로 바꾸어 말한 것이에요.",
 "angry 화난 / strong 센, 강한 / friendship 우정",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 필자가 말한 것은 자리를 떠나는 일이 아니라 쓴 메시지를 하룻밤 두는 일이에요.",
  "글과 반대예요. 빠른 메시지는 우정을 끝낼 수 있다고 했어요.",
  "글과 맞지 않아요. 필자는 메시지를 지우라고 하지 않고 하룻밤 휴대폰에 그대로 두라고 했어요. 말로 하라는 이야기도 없어요.",
  "방법이 달라요. 다른 사람은 나오지 않아요. 필자는 하룻밤 그대로 두라고 했어요. 아침이 되면 같은 말이 너무 세 보여서 스스로 고치게 돼요.",
  "셋째 문장과 같은 말이에요. 하룻밤 그대로 두고 아직 보내지 말라는 것을 「시간을 두고 보내야 한다」로 바꾸어 말했어요."])

# ---------- 20번째: 외국어는 틀리더라도 말하기 (답 ⑤) ----------
rw(19, 4, "Speak your new language out loud every day, and do not fear mistakes. Many learners know a thousand words, but they stay silent in class. They wait for a perfect sentence, and the chance passes by. A baby makes many funny mistakes and still learns to talk. Every wrong sentence from your mouth teaches you a better one.",
 ["새 단어는 날마다 조금씩 외워야 한다", "외국어는 짧고 쉬운 문장으로 말해야 한다", "외국어는 아기처럼 듣기부터 시작해야 한다", "외국어는 원어민과 자주 이야기해야 한다", "외국어는 틀리더라도 소리 내어 말해야 한다"],
 "새로 배우는 말은 날마다 소리 내어 말하고, 틀리는 것을 두려워하지 마라. 많은 학습자가 단어를 천 개나 알지만 수업 시간에는 입을 다문다. 완벽한 문장을 기다리다가 기회가 지나가 버린다. 아기는 우스운 실수를 많이 하면서도 말을 배운다. 입에서 나온 틀린 문장 하나하나가 더 나은 문장을 가르쳐 준다.",
 "Speak your new language out loud every day, and do not fear mistakes.", "새로 배우는 말은 날마다 소리 내어 말하고, 틀리는 것을 두려워하지 마라.", 1,
 "첫 문장이 동사 'Speak'로 시작하는 명령문이에요. 필자는 하고 싶은 말을 먼저 하고, 뒤의 네 문장에서 까닭을 대요. 완벽한 문장만 기다리면 기회를 놓치고, 아기도 틀리면서 말을 배운다는 것이에요.",
 "'do not fear mistakes'(틀리는 것을 두려워하지 마라)를 「틀리더라도」로, 'your new language'(새로 배우는 말)를 「외국어」로 바꾸어 말한 것이에요.",
 "out loud 소리 내어 / silent 말이 없는 / mistake 실수, 틀림",
 ["글의 낱말만 본 것이에요. 'a thousand words'(단어 천 개)는 단어를 많이 알아도 입을 다무는 사람들 이야기에 나와요.",
  "글의 낱말만 본 것이에요. 'a perfect sentence'(완벽한 문장)는 그것을 기다리다 기회를 놓친다는 말에 나와요. 문장을 짧게 하라는 말은 없어요.",
  "글의 낱말만 본 것이에요. 'A baby'(아기)는 틀리면서도 말을 배우는 보기로 나와요. 듣기부터 하라는 말은 없어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 누구와 말하는지는 나오지 않아요. 필자가 말한 것은 틀려도 소리 내어 말하라는 것이에요.",
  "첫 문장과 같은 말이에요. 날마다 소리 내어 말하고 틀리는 것을 두려워하지 말라는 것을 「틀리더라도 소리 내어 말해야 한다」로 바꾸어 말했어요."])

# ---------- 21번째: 메시지는 모아서 (답 ③) ----------
rw(20, 2, "Yuna's phone makes a sound for a new message every few minutes. She looks at each one, and one hour of homework becomes two hours. You should leave your messages alone and read them only three times a day. Your friends can wait a little, and nothing bad happens to them. This way your homework ends early, and your evening becomes free.",
 ["친구에게는 메시지보다 전화를 해야 한다", "공부할 때는 휴대폰을 다른 방에 두어야 한다", "메시지는 하루에 몇 번만 모아서 봐야 한다", "휴대폰의 메시지 알림 소리는 늘 꺼 두어야 한다", "메시지에는 받는 대로 바로 답해야 한다"],
 "유나의 휴대폰은 몇 분마다 새 메시지가 왔다고 소리를 낸다. 유나가 그때마다 들여다보느라 한 시간짜리 숙제가 두 시간이 된다. 메시지는 그냥 두었다가 하루에 세 번만 읽어야 한다. 친구들은 조금 기다릴 수 있고, 그래도 나쁜 일은 생기지 않는다. 이렇게 하면 숙제가 일찍 끝나고 저녁 시간이 자유로워진다.",
 "You should leave your messages alone and read them only three times a day.", "메시지는 그냥 두었다가 하루에 세 번만 읽어야 한다.", 3,
 "'should'는 「~해야 한다」는 뜻이에요. 앞의 두 문장은 유나의 이야기예요. 메시지가 올 때마다 보느라 숙제가 두 배로 길어져요. 뒤의 두 문장은 까닭이에요. 친구는 조금 기다려도 괜찮고, 내 저녁 시간이 생겨요.",
 "'only three times a day'(하루에 세 번만)를 「하루에 몇 번만」으로, 'leave … alone'(그냥 두다)을 「모아서」로 바꾸어 말한 것이에요. 그냥 두면 메시지가 쌓이니까 모아서 보는 셈이에요.",
 "message 메시지 / homework 숙제 / free 자유로운",
 ["방법이 달라요. 전화는 나오지 않아요. 필자는 메시지를 그냥 두었다가 하루에 세 번만 읽으라고 했어요.",
  "방법이 달라요. 그럴듯한 말이지만, 필자는 휴대폰을 치우라고 하지 않고 메시지를 하루에 세 번만 읽으라고 했어요.",
  "셋째 문장과 같은 말이에요. 메시지를 그냥 두었다가 하루에 세 번만 읽으라는 것을 「하루에 몇 번만 모아서 봐야 한다」로 바꾸어 말했어요.",
  "글의 낱말만 본 것이에요. 'a sound'(소리)는 유나의 휴대폰이 자꾸 울린다는 말에 나올 뿐이에요. 필자가 하라고 한 일은 메시지 읽는 횟수를 줄이는 것이에요.",
  "글과 반대예요. 친구들은 조금 기다릴 수 있고, 그래도 나쁜 일은 생기지 않는다고 했어요."])

# ---------- 22번째: 고마운 마음은 말로 (답 ③) ----------
rw(21, 2, "Your mother cooks dinner for you almost every evening after work. You eat it quietly and go back to your room. Of course you are thankful, but she cannot see inside your heart. Two short words from you can make her whole evening happy. Say thank you out loud more often, and start at dinner tonight.",
 ["고마운 마음은 작은 선물로 전해야 한다", "고마운 마음은 일기에 적어 두어야 한다", "고마운 마음은 말로 자주 표현해야 한다", "고마운 마음은 특별한 날 편지로 전해야 한다", "고마운 마음은 집안일을 도우며 보여 주어야 한다"],
 "어머니는 일을 마치고 거의 매일 저녁 여러분을 위해 저녁밥을 짓는다. 여러분은 말없이 먹고 방으로 돌아간다. 물론 고마워하고 있지만, 어머니는 여러분의 마음속을 볼 수 없다. 여러분의 짧은 두 마디가 어머니의 저녁을 온통 행복하게 만들 수 있다. 고맙다는 말을 더 자주 소리 내어 하고, 오늘 저녁 식사 때부터 시작하라.",
 "Say thank you out loud more often, and start at dinner tonight.", "고맙다는 말을 더 자주 소리 내어 하고, 오늘 저녁 식사 때부터 시작하라.", 5,
 "동사 'Say'로 시작하는 명령문이에요. 앞의 두 문장은 어머니가 지어 준 저녁을 말없이 먹고 방으로 가는 장면이에요. 셋째·넷째 문장은 까닭이에요. 고마워도 말하지 않으면 어머니는 그 마음을 볼 수 없고, 짧은 두 마디면 어머니가 행복해져요.",
 "'Say thank you out loud'(고맙다고 소리 내어 말하다)를 「말로 표현하다」로, 'more often'(더 자주)을 「자주」로 바꾸어 말한 것이에요.",
 "quietly 말없이, 조용히 / thankful 고마워하는 / heart 마음",
 ["방법이 달라요. 선물은 나오지 않아요. 필자가 말한 것은 짧은 두 마디, 곧 고맙다는 말이에요.",
  "방법이 달라요. 일기에 적으면 어머니는 여전히 그 마음을 볼 수 없어요. 필자는 소리 내어 말하라고 했어요.",
  "마지막 문장과 같은 말이에요. 고맙다는 말을 더 자주 소리 내어 하라는 것을 「말로 자주 표현해야 한다」로 바꾸어 말했어요.",
  "때와 방법이 달라요. 필자는 특별한 날이 아니라 오늘 저녁 식사 때부터, 편지가 아니라 말로 하라고 했어요.",
  "방법이 달라요. 집안일을 돕는 이야기는 나오지 않아요. 필자가 하라고 한 일은 고맙다고 말하는 것이에요."])

# ---------- 23번째: 탄산음료 대신 물 (답 ①) ----------
rw(22, 0, "Look at the long row of sweet drinks in any shop. Choose water for your thirsty body, and leave the soda on the shelf. One can of soda holds a lot of sugar, and your teeth hate it. Your blood and your brain need a lot of water every day. Water also costs less than soda, so you save money every week.",
 ["탄산음료 대신 물을 마셔야 한다", "탄산음료 대신 우유를 마셔야 한다", "탄산음료를 마신 뒤에는 이를 닦아야 한다", "탄산음료는 하루에 한 캔만 마셔야 한다", "탄산음료는 식사할 때에만 마셔야 한다"],
 "어느 가게에서든 길게 늘어선 단 음료들을 보라. 목마른 몸을 위해서는 물을 고르고, 탄산음료는 선반에 그대로 두어라. 탄산음료 한 캔에는 설탕이 많이 들어 있고, 여러분의 이는 그것을 아주 싫어한다. 피와 뇌는 날마다 많은 물이 필요하다. 물은 탄산음료보다 값도 싸서 주마다 돈을 아낄 수 있다.",
 "Choose water for your thirsty body, and leave the soda on the shelf.", "목마른 몸을 위해서는 물을 고르고, 탄산음료는 선반에 그대로 두어라.", 2,
 "둘째 문장이 동사 'Choose'로 시작하는 명령문이에요. 첫 문장도 명령문이지만, 가게에 늘어선 단 음료를 보라는 말일 뿐이에요. 뒤의 세 문장은 까닭이에요. 탄산음료는 설탕이 많아 이에 나쁘고, 피와 뇌에는 물이 필요하고, 물은 값도 싸요.",
 "'Choose water … leave the soda'(물을 고르고 탄산음료는 두어라)를 「탄산음료 대신 물」로 바꾸어 말한 것이에요.",
 "thirsty 목마른 / shelf 선반 / sugar 설탕",
 ["둘째 문장과 같은 말이에요. 물을 고르고 탄산음료는 선반에 두라는 것을 「탄산음료 대신 물을 마셔야 한다」로 바꾸어 말했어요.",
  "대상이 달라요. 우유는 나오지 않아요. 필자가 고르라고 한 것은 물이에요.",
  "글의 낱말만 본 것이에요. 'your teeth'(이)는 설탕이 이에 나쁘다는 말에 나올 뿐, 이를 닦으라는 말은 없어요.",
  "글과 맞지 않아요. 필자는 한 캔만 마시라고 하지 않고, 탄산음료는 선반에 그대로 두라고 했어요.",
  "글과 맞지 않아요. 필자는 식사할 때에는 마셔도 된다고 하지 않고, 탄산음료는 선반에 그대로 두라고 했어요."])

# ---------- 24번째: 자기 전에 문 잠그기 (답 ④) ----------
rw(23, 3, "Lock the front door as your last job of the day, right before bed. Many people lock it only in the morning on their way out. At night they feel safe at home, and they forget about the lock. A thief likes dark and quiet hours, and an unlocked door invites him. After that last job, everyone in the house can sleep without worry.",
 ["집을 나설 때는 문을 꼭 잠그고 나가야 한다", "밤에는 현관 불을 켜 두어야 한다", "현관문에는 튼튼한 자물쇠를 하나 더 달아야 한다", "매일 밤 자기 전에 현관문을 잠가야 한다", "집을 비울 때는 이웃에게 알려야 한다"],
 "현관문은 하루의 마지막 일로, 잠자리에 들기 바로 전에 잠가라. 많은 사람이 아침에 집을 나설 때에만 문을 잠근다. 밤에는 집에 있으니 안전하다고 느껴서 자물쇠를 잊어버린다. 도둑은 어둡고 조용한 시간을 좋아하고, 잠기지 않은 문은 도둑을 불러들인다. 그 마지막 일을 하고 나면 집 안의 모두가 걱정 없이 잘 수 있다.",
 "Lock the front door as your last job of the day, right before bed.", "현관문은 하루의 마지막 일로, 잠자리에 들기 바로 전에 잠가라.", 1,
 "첫 문장이 동사 'Lock'으로 시작하는 명령문이에요. 둘째·셋째 문장은 사람들이 아침에는 잠그지만 밤에는 잊는다는 사정이고, 넷째·다섯째 문장은 밤에 잠가야 하는 까닭이에요.",
 "'as your last job of the day, right before bed'(하루의 마지막 일로, 잠자리에 들기 바로 전에)를 「매일 밤 자기 전에」로 바꾸어 말한 것이에요.",
 "lock 잠그다, 자물쇠 / thief 도둑 / worry 걱정",
 ["때가 달라요. 집을 나설 때 잠그는 것은 사람들이 이미 하는 일로 나와요. 필자가 말한 때는 밤, 잠자리에 들기 전이에요.",
  "글의 낱말만 본 것이에요. 'dark'(어두운)는 도둑이 좋아하는 시간을 말할 때 나올 뿐, 불을 켜 두라는 말은 없어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 어떤 자물쇠를 다는지가 아니라 언제 잠그는지를 말해요.",
  "첫 문장과 같은 말이에요. 하루의 마지막 일로 잠자리에 들기 전에 잠그라는 것을 「매일 밤 자기 전에 현관문을 잠가야 한다」로 바꾸어 말했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 이웃은 나오지 않아요. 글은 집을 비울 때가 아니라 밤에 집에 있을 때를 말해요."])

# ---------- 25번째: 비밀번호는 곳마다 다르게 (답 ②) ----------
rw(24, 1, "Many people have only one password, and they use it everywhere. A hacker gets that password from one weak site in a second. Then he opens their mail, their games and their bank accounts with it. You must use a different password for every website and every app. With different passwords, one stolen key opens only one door.",
 ["비밀번호는 정기적으로 바꾸어야 한다", "비밀번호는 쓰는 곳마다 다르게 해야 한다", "비밀번호는 길고 어렵게 만들어야 한다", "비밀번호는 종이에 적어 따로 두어야 한다", "비밀번호는 어디에도 적어 두지 말아야 한다"],
 "많은 사람이 비밀번호를 하나만 가지고 어디에서나 그것을 쓴다. 해커는 허술한 사이트 한 곳에서 그 비밀번호를 순식간에 알아낸다. 그러고는 그것으로 그들의 메일과 게임과 은행 계좌를 연다. 웹사이트마다, 앱마다 서로 다른 비밀번호를 써야 한다. 비밀번호가 서로 다르면 도둑맞은 열쇠 하나는 문 하나만 연다.",
 "You must use a different password for every website and every app.", "웹사이트마다, 앱마다 서로 다른 비밀번호를 써야 한다.", 4,
 "'must'는 「꼭 ~해야 한다」는 뜻이에요. 앞의 세 문장은 까닭이에요. 비밀번호 하나를 어디에나 쓰면, 한 곳에서 새어 나간 것으로 모든 곳이 열려요. 마지막 문장은 서로 다르면 한 곳만 열린다는 말이에요.",
 "'for every website and every app'(웹사이트마다, 앱마다)을 「쓰는 곳마다」로 바꾸어 말한 것이에요.",
 "password 비밀번호 / everywhere 어디에서나 / weak 허술한, 약한",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 비밀번호를 언제 바꾸는지가 아니라 곳마다 다르게 쓰는지를 말해요.",
  "넷째 문장과 같은 말이에요. 웹사이트마다, 앱마다 다른 비밀번호를 쓰라는 것을 「쓰는 곳마다 다르게 해야 한다」로 바꾸어 말했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글에서 탈이 되는 것은 쉬운 비밀번호가 아니라 하나를 어디에나 쓰는 일이에요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 비밀번호를 적어 두는 일은 나오지 않아요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 적어 두지 말라는 말도 글에는 없어요. 필자가 말한 것은 곳마다 다른 비밀번호예요."])

# ---------- 26번째: 서명하기 전에 끝까지 읽기 (답 ①) ----------
rw(25, 0, "A man at the phone shop puts a long form in front of you. He smiles and points at the line for your name. The tiny words at the bottom often hide two years of extra costs. Your name on the form means a promise, and the promise is hard to break. So read every line first, and sign your name last.",
 ["서명하기 전에 내용을 끝까지 읽어야 한다", "서명한 문서는 한 부를 받아 두어야 한다", "모르는 내용은 직원에게 물어봐야 한다", "서명하기 전에 가족과 의논해야 한다", "서명은 하루 더 생각한 뒤에 해야 한다"],
 "휴대폰 가게의 한 남자가 여러분 앞에 긴 서류를 내민다. 그는 웃으면서 이름을 쓰는 줄을 가리킨다. 맨 아래의 아주 작은 글씨에는 두 해 동안 더 내야 할 돈이 숨어 있는 일이 많다. 서류에 쓴 이름은 약속을 뜻하고, 그 약속은 깨기 어렵다. 그러니 먼저 줄마다 다 읽고, 이름은 맨 나중에 써라.",
 "So read every line first, and sign your name last.", "그러니 먼저 줄마다 다 읽고, 이름은 맨 나중에 써라.", 5,
 "'So'(그러니) 뒤에 동사 'read'가 오는 명령문이에요. 앞의 두 문장은 가게에서 긴 서류를 받고 이름 쓸 곳을 안내받는 장면이에요. 셋째·넷째 문장은 까닭이에요. 작은 글씨에 돈 이야기가 숨어 있고, 이름을 쓰면 깨기 어려운 약속이 돼요. 'So'가 그 까닭을 받아 무엇을 하라고 말해요.",
 "'read every line first'(먼저 줄마다 다 읽다)를 「내용을 끝까지 읽다」로, 'sign your name last'(이름은 맨 나중에 쓰다)를 「서명하기 전에」로 바꾸어 말한 것이에요.",
 "form 서류, 양식 / tiny 아주 작은 / sign 서명하다",
 ["마지막 문장과 같은 말이에요. 먼저 줄마다 다 읽고 이름은 맨 나중에 쓰라는 것을 「서명하기 전에 내용을 끝까지 읽어야 한다」로 바꾸어 말했어요.",
  "때가 달라요. 서명한 뒤의 일은 나오지 않아요. 필자는 서명하기 전에 할 일을 말해요.",
  "방법이 달라요. 가게 사람에게 물으라는 말은 없어요. 필자가 하라고 한 일은 줄마다 스스로 읽는 것이에요.",
  "방법이 달라요. 가족은 나오지 않아요. 필자는 서명하기 전에 줄마다 다 읽으라고 했어요.",
  "때가 달라요. 하루를 미루라는 말은 없어요. 필자가 말한 순서는 먼저 다 읽고, 그다음에 서명하는 것이에요."])

# ---------- 27번째: 변명보다 사과 먼저 (답 ③) ----------
rw(26, 2, "You lose your friend's new book, and she looks very upset. Your head is already full of reasons, like the late bus and your heavy bag. Say sorry to her first, and keep your reasons for later. Reasons at the start sound like excuses, and your friend becomes more upset. A simple sorry opens her ears, and then she listens to your story.",
 ["사과는 얼굴을 보고 직접 해야 한다", "친구가 화났을 때는 화가 풀릴 때까지 기다려야 한다", "잘못했을 때는 변명보다 사과를 먼저 해야 한다", "사과할 때는 무엇을 잘못했는지 자세히 말해야 한다", "사과는 말보다 행동으로 보여 주어야 한다"],
 "여러분이 친구의 새 책을 잃어버려서 친구가 몹시 속상해 보인다. 여러분의 머릿속은 벌써 늦게 온 버스와 무거운 가방 같은 까닭들로 가득하다. 먼저 친구에게 미안하다고 말하고, 까닭은 나중을 위해 남겨 두어라. 처음부터 대는 까닭은 변명처럼 들리고, 친구는 더 속상해진다. 미안하다는 한마디가 친구의 귀를 열고, 그러면 친구는 여러분의 이야기를 듣는다.",
 "Say sorry to her first, and keep your reasons for later.", "먼저 친구에게 미안하다고 말하고, 까닭은 나중을 위해 남겨 두어라.", 3,
 "동사 'Say'로 시작하는 명령문이에요. 앞의 두 문장은 책을 잃어버리고 까닭부터 대고 싶어지는 장면이에요. 뒤의 두 문장은 까닭이에요. 처음부터 대는 까닭은 변명처럼 들리고, 사과를 먼저 해야 친구가 이야기를 들어 줘요.",
 "'Say sorry … first'(먼저 미안하다고 말하다)를 「사과를 먼저」로, 'keep your reasons for later'(까닭은 나중으로 남겨 두다)를 「변명보다」로 바꾸어 말한 것이에요.",
 "upset 속상한 / reason 까닭, 이유 / excuse 변명",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 사과를 어떤 방법으로 하는지가 아니라 무엇을 먼저 말하는지를 말해요.",
  "방법이 달라요. 필자는 기다리라고 하지 않고 먼저 미안하다고 말하라고 했어요.",
  "셋째 문장과 같은 말이에요. 먼저 미안하다고 말하고 까닭은 나중으로 남겨 두라는 것을 「변명보다 사과를 먼저 해야 한다」로 바꾸어 말했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 무엇을 자세히 말하는지가 아니라 사과와 까닭 가운데 무엇을 먼저 말하는지를 이야기해요.",
  "글과 맞지 않아요. 미안하다는 한마디가 친구의 귀를 연다고 했어요. 필자가 하라고 한 일은 먼저 말로 사과하는 것이에요."])

# ---------- 28번째: 공유하기 전에 확인 (답 ②) ----------
rw(27, 1, "A strange story appears on your phone, and your finger moves to the share button. Stories like this travel fast, and many of them are not true. One false story can hurt a real person or a small shop. Check the writer and the facts first, and only then press the button. One minute of care can stop a lie at your phone.",
 ["소식은 제목만 보지 말고 내용을 끝까지 읽어야 한다", "소식을 공유하기 전에 믿을 만한지 확인해야 한다", "거짓 소식을 보면 바로 신고해야 한다", "소식을 공유할 때는 출처를 함께 밝혀야 한다", "소식을 공유할 때는 내 의견을 덧붙이지 말아야 한다"],
 "이상한 이야기가 휴대폰에 뜨고, 여러분의 손가락은 공유 단추로 간다. 이런 이야기는 빨리 퍼지는데, 그 가운데 많은 것이 사실이 아니다. 거짓 이야기 하나가 실제 사람이나 작은 가게에 해를 끼칠 수 있다. 먼저 글쓴이와 사실을 확인하고, 그런 다음에야 단추를 눌러라. 일 분만 마음을 쓰면 거짓말을 여러분의 휴대폰에서 멈출 수 있다.",
 "Check the writer and the facts first, and only then press the button.", "먼저 글쓴이와 사실을 확인하고, 그런 다음에야 단추를 눌러라.", 4,
 "동사 'Check'로 시작하는 명령문이고, 'first'(먼저)와 'only then'(그런 다음에야)으로 순서를 정해 줘요. 첫 문장은 이상한 이야기를 보고 바로 공유하려는 장면이에요. 둘째·셋째 문장은 까닭이에요. 이런 이야기는 거짓이 많고, 거짓 이야기는 사람에게 해를 끼쳐요. 마지막 문장은 일 분만 확인하면 거짓말이 내 휴대폰에서 멈춘다는 말이에요.",
 "'Check the writer and the facts'(글쓴이와 사실을 확인하다)를 「믿을 만한지 확인하다」로, 'only then press the button'(그런 다음에야 단추를 누르다)을 「공유하기 전에」로 바꾸어 말한 것이에요.",
 "share 공유하다 / false 거짓의 / fact 사실",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 소식을 어디까지 읽는지가 아니라 공유하기 전에 무엇을 확인하는지를 말해요.",
  "넷째 문장과 같은 말이에요. 먼저 글쓴이와 사실을 확인하고 그다음에 단추를 누르라는 것을 「공유하기 전에 믿을 만한지 확인해야 한다」로 바꾸어 말했어요.",
  "방법이 달라요. 신고하라는 말은 없어요. 필자가 하라고 한 일은 공유하기 전에 확인하는 것이에요.",
  "방법이 달라요. 출처를 적어서 공유하라는 말은 없어요. 필자는 공유하기 전에 글쓴이와 사실을 먼저 확인하라고 했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 의견을 덧붙이는 일은 나오지 않아요. 필자가 말한 것은 공유하기 전의 확인이에요."])

# ---------- 29번째: 약속은 하루 전에 다시 확인 (답 ④) ----------
rw(28, 3, "You should check the day and the time again one day before every meeting. People write them down, but they still mix them up. Dana waits at the station on Tuesday, and Jin comes on Thursday. One short call on Monday night can save both of them a lost afternoon. The call takes one minute, and nobody waits alone at the station.",
 ["약속은 정하자마자 바로 적어 두어야 한다", "약속을 바꿀 때는 미리 알려야 한다", "약속은 만나는 날 아침에 확인해야 한다", "약속은 하루 전에 다시 확인해야 한다", "약속 장소에는 조금 일찍 나가 있어야 한다"],
 "모든 약속은 하루 전에 날짜와 시간을 다시 확인해야 한다. 사람들은 그것을 적어 두지만, 그래도 헷갈린다. 다나는 화요일에 역에서 기다리고, 진은 목요일에 온다. 월요일 밤에 짧게 전화 한 통만 하면 두 사람 모두 오후를 버리지 않아도 된다. 전화는 일 분이면 되고, 아무도 역에서 혼자 기다리지 않는다.",
 "You should check the day and the time again one day before every meeting.", "모든 약속은 하루 전에 날짜와 시간을 다시 확인해야 한다.", 1,
 "'should'는 「~해야 한다」는 뜻이에요. 필자는 첫 문장에서 하고 싶은 말을 먼저 하고, 뒤의 네 문장에서 까닭을 대요. 적어 두어도 헷갈려서 다나와 진처럼 엇갈리는데, 전날 전화 한 통이면 막을 수 있어요.",
 "'check the day and the time again'(날짜와 시간을 다시 확인하다)을 「다시 확인하다」로, 'one day before every meeting'(모든 약속의 하루 전에)을 「하루 전에」로 옮긴 것이에요.",
 "check 확인하다 / mix up 헷갈리다 / alone 혼자",
 ["글과 맞지 않아요. 사람들은 약속을 적어 두지만 그래도 헷갈린다고 했어요. 그래서 하루 전에 다시 확인하라는 것이에요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 약속을 바꾸는 일은 나오지 않아요.",
  "때가 달라요. 필자가 말한 때는 만나는 날 아침이 아니라 하루 전이에요. 글에서도 전화는 월요일 밤에, 곧 다나가 기다린 화요일의 하루 전에 해요.",
  "첫 문장과 같은 말이에요. 모든 약속의 하루 전에 날짜와 시간을 다시 확인하라는 말이에요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 얼마나 일찍 나가는지가 아니라 날짜와 시간을 언제 다시 확인하는지를 말해요."])

# ---------- 30번째: 계획에는 여유 시간을 (답 ④) ----------
rw(29, 3, "Imagine a Saturday plan with study or housework in every single hour. Leave one or two empty hours in your plan for the day. A bus comes late, or one job takes twice the time. In a full plan, one small problem pushes every later job back. But with empty hours, small problems fit in, and your day ends on time.",
 ["하루 계획은 전날 밤에 미리 세워야 한다", "계획은 시간 단위로 꼼꼼하게 짜야 한다", "하루 계획은 아침에 일어나서 세워야 한다", "계획에는 여유 시간을 남겨 두어야 한다", "하루 계획에는 중요한 일 세 가지만 넣어야 한다"],
 "시간마다 공부나 집안일이 들어찬 토요일 계획표를 떠올려 보라. 하루 계획에는 빈 시간을 한두 시간 남겨 두어라. 버스가 늦게 오기도 하고, 한 가지 일이 시간이 두 배로 걸리기도 한다. 꽉 찬 계획에서는 작은 탈 하나가 뒤의 모든 일을 뒤로 밀어 버린다. 그러나 빈 시간이 있으면 작은 탈들이 그 안으로 들어가고, 하루가 제때 끝난다.",
 "Leave one or two empty hours in your plan for the day.", "하루 계획에는 빈 시간을 한두 시간 남겨 두어라.", 2,
 "둘째 문장이 동사 'Leave'로 시작하는 명령문이에요. 첫 문장도 명령문이지만, 꽉 찬 계획표를 떠올려 보라는 말일 뿐이에요. 뒤의 세 문장은 까닭이에요. 꽉 찬 계획은 작은 탈 하나에 모두 밀리고, 빈 시간이 있으면 그 탈을 받아 내요.",
 "'empty hours'(빈 시간)를 「여유 시간」으로 바꾸어 말한 것이에요.",
 "empty 빈 / twice 두 배 / on time 제때",
 ["옳은 말처럼 들리지만 지문에 없는 이야기예요. 글은 계획을 언제 세우는지가 아니라 무엇을 남겨 두는지를 말해요.",
  "글과 반대예요. 시간마다 일이 들어찬 계획은 작은 탈 하나에 뒤의 일이 모두 밀린다고 했어요.",
  "옳은 말처럼 들리지만 지문에 없는 이야기예요. 계획을 아침에 세우라는 말은 없어요. 필자가 말한 것은 빈 시간이에요.",
  "둘째 문장과 같은 말이에요. 빈 시간을 한두 시간 남겨 두라는 것을 「여유 시간을 남겨 두어야 한다」로 바꾸어 말했어요.",
  "방법이 달라요. 일을 세 가지로 줄이라는 말은 없어요. 필자는 일을 줄이라고 하지 않고 빈 시간을 한두 시간 두라고 했어요."])
