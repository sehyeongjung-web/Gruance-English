# -*- coding: utf-8 -*-
# 323번: 33번(빈칸 추론 — 구) 레벨1 — 레벨1 기준으로 다시 씀 (뒤 절반: 16~30번째)
# 꼴은 앞 절반(edits_X58a.py)과 같음: 네 문장 · 모두 단문 · 문장당 10~15낱말 · 빈칸은 넷째 문장
# 짝꿍 문장: 셋째 열 문항 · 둘째 네 문항(19·21·22·27번째) · 첫째 한 문항(25번째)
# 생각의 단계(추론축 레벨1): 글에 있는 말 하나를 그대로 확인 — 짝꿍 문장의 말을 다른 말로 바꾼 것이 답
#   (without deciding ← no time on the choice · ready ten minutes sooner ← at seven, not at ten past seven · reaching for it ← his hand used to go to it / stays on his pen ·
#    a rush into a walk ← ran all the way / goes slowly · understands her own spending ← half of her pocket money goes on snacks · calmly ← slowly, with an easy smile ·
#    falls asleep more easily ← eyes close within ten minutes, not an hour · argues about past decisions ← a fight over an old plan · never leaves anything behind ← all four are in his bag ·
#    misses a single one ← has gone to every appointment · without worrying ← his mind is quiet · never been taken ← has been in its place ·
#    knows the week ahead ← nothing comes as a surprise · without something to eat ← every plate has safe food · get out of bed ← five steps away from her bed)
# 글감(버릇 → 좋은 결과)·정답 번호는 그대로. **정답 구를 고친 문항 셋** — 정답 구 안에 절이 들어 있어 레벨1의 「단문만」에 맞지 않음(12번째와 같은 까닭). 뜻은 같음
#   20번째 knows where her money goes → understands her own spending · 23번째 argues about what was agreed → argues about past decisions · 28번째 knows what is coming → knows the week ahead
# 선택지: 옛 오답은 거의 모두 나쁜 결과 → 「같은 버릇에서 나올 법한 다른 좋은 결과」로 다시 씀(앞 절반과 같은 법)
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '33', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, c5, ko, steps, traps, cn):
    """문항을 통째로 다시 씀: 지문·선택지·해석·풀이·해설. 정답 번호는 그대로. c5 = 새 선택지 다섯"""
    old = list(_tb[T][LV][n]['choices']); ch = {k: v for k, v in enumerate(c5) if v != old[k]}
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=ans in ch); e = E.pop((T, LV, n))
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(c5)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': list(c5), 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 16번째: 자기 전에 적는 내일의 할 일 (답 start the day without deciding) ----------
rw(15, 1, "Lina writes down three jobs for the next day on a small card before bed. In the morning she reads the card and begins the first job at once. She spends no time on the choice of her first job. The card from the night before lets her ______.",
 ["sleep longer in the morning", "start the day without deciding", "finish her work before lunch", "fall asleep with a clear head", "add new jobs during the day"],
 "리나는 자기 전에 다음 날 할 일 세 가지를 작은 카드에 적는다. 아침이면 그 카드를 읽고 첫 번째 일을 바로 시작한다. 첫 일을 고르는 데 시간을 조금도 쓰지 않는다. 전날 밤에 쓴 그 카드는 리나가 ______ 해 준다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «The card from the night before lets her»(전날 밤에 쓴 그 카드는 리나가 ~하게 해 준다). 카드 덕분에 리나가 무엇을 할 수 있는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «She spends no time on the choice of her first job.»(첫 일을 고르는 데 시간을 조금도 쓰지 않는다.) 'no time on the choice'(고르는 데 쓰는 시간이 없음)가 단서예요.",
 "3) 둘째 문장 확인: «she reads the card and begins the first job at once»(그 카드를 읽고 첫 번째 일을 바로 시작한다). 'at once'(바로)가 있어요. 무엇부터 할지는 전날 밤에 이미 적어 두었어요.",
 "4) 묶기: 고르는 데 시간을 쓰지 않는다 = 정하지 않아도 된다. 그래서 'start the day without deciding'(정하는 일 없이 하루를 시작하다)이에요. 'deciding'은 '정하는 것'이에요. 글의 'choice'(고르기)를 다른 말로 바꾼 것이에요."],
 "「점심 전에 일을 끝내게」가 끌릴 수 있어요. 일을 바로 시작하면 일찍 끝날 것 같거든요. 하지만 글에는 일을 언제 끝내는지가 나오지 않아요. 글이 말한 것은 첫 일을 고르는 데 시간을 쓰지 않는다는 것이에요.",
 [("아침에 더 오래 자게", "지문에 없는 이야기예요. 몇 시에 일어나는지는 나오지 않아요."),
  ("정하는 일 없이 하루를 시작하게", "셋째 문장 «She spends no time on the choice of her first job.»이 근거예요. 첫 일을 고르는 데 시간을 쓰지 않으니, 정하는 일 없이 하루를 시작하는 것이에요."),
  ("점심 전에 일을 끝내게", "지문에 없는 이야기예요. 일을 언제 끝내는지는 나오지 않아요."),
  ("맑은 머리로 잠들게", "지문에 없는 이야기예요. 글에서 자기 전에 하는 일은 카드를 쓰는 것이에요. 밤에 어떻게 잠드는지는 나오지 않아요."),
  ("낮 동안 새 일을 더 보태게", "지문에 없는 이야기예요. 카드에 적은 일은 세 가지예요. 낮에 일을 더 보탠다는 말은 없어요.")])

# ---------- 17번째: 전날 저녁에 꺼내 두는 옷 (답 is ready ten minutes sooner) ----------
rw(16, 2, "This year Omar puts his school shirt, trousers and socks on a chair every evening. He still gets up at half past six, just like last year. Now he sits down to breakfast at seven, not at ten past seven. Thanks to this evening habit, in the morning he ______.",
 ["gets up a little earlier", "looks tidier at school", "is ready ten minutes sooner", "has time for a longer shower", "feels calmer before school"],
 "올해 오마르는 저녁마다 학교에 입고 갈 셔츠와 바지와 양말을 의자 위에 올려 둔다. 지난해와 똑같이 여전히 여섯 시 반에 일어난다. 이제는 일곱 시 십 분이 아니라 일곱 시에 아침 식탁에 앉는다. 저녁의 이 버릇 덕분에, 아침에 오마르는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to this evening habit»(저녁의 이 버릇 덕분에). 입을 옷을 전날 저녁에 의자에 올려 두는 버릇이에요. 그 덕분에 아침이 어떻게 달라졌는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now he sits down to breakfast at seven, not at ten past seven.»(이제는 일곱 시 십 분이 아니라 일곱 시에 아침 식탁에 앉는다.) 'at seven, not at ten past seven'(일곱 시 십 분이 아니라 일곱 시에)이 단서예요. 'ten past seven'은 일곱 시 십 분이에요.",
 "3) 둘째 문장 확인: «He still gets up at half past six, just like last year.»(지난해와 똑같이 여전히 여섯 시 반에 일어난다.) 일어나는 시간은 그대로예요. 'still'(여전히)이 그것을 알려 줘요.",
 "4) 묶기: 일어나는 시간은 같은데 식탁에 앉는 시간이 십 분 빨라졌어요. 준비가 십 분 일찍 끝난 것이에요. 그래서 'is ready ten minutes sooner'(십 분 더 일찍 준비를 마친다)예요. 'sooner'는 '더 일찍'이에요."],
 "「조금 더 일찍 일어난다」가 끌릴 수 있어요. 아침 식탁에 더 일찍 앉으니 더 일찍 일어난 것 같거든요. 하지만 둘째 문장에서 'still gets up at half past six'(여전히 여섯 시 반에 일어난다)라고 했어요. 빨라진 것은 일어나는 시간이 아니라 준비를 마치는 시간이에요.",
 [("조금 더 일찍 일어난다", "글과 맞지 않아요. 둘째 문장에서 지난해와 똑같이 여섯 시 반에 일어난다고 했어요."),
  ("학교에서 더 단정해 보인다", "지문에 없는 이야기예요. 학교에서 어떻게 보이는지는 나오지 않아요."),
  ("십 분 더 일찍 준비를 마친다", "셋째 문장 «Now he sits down to breakfast at seven, not at ten past seven.»이 근거예요. 일어나는 시간은 같은데 식탁에 십 분 일찍 앉으니, 준비를 십 분 일찍 마치는 것이에요."),
  ("더 오래 샤워할 시간이 있다", "지문에 없는 이야기예요. 샤워 이야기는 나오지 않아요."),
  ("학교 가기 전에 마음이 더 차분하다", "지문에 없는 이야기예요. 오마르의 기분은 나오지 않아요.")])

# ---------- 18번째: 서랍에 넣어 두는 전화기 (답 stops him reaching for it) ----------
rw(17, 4, "Jae shuts his phone in the bottom drawer of his desk before studying. With the phone on the desk, his hand used to go to it very often. Now his hand stays on his pen for the whole study hour. During study time, this small step with his phone ______.",
 ["keeps it clean and dry", "keeps it quiet for the hour", "stops him losing it", "helps him finish much sooner", "stops him reaching for it"],
 "재는 공부하기 전에 전화기를 책상 맨 아래 서랍에 넣고 닫는다. 전화기가 책상 위에 있을 때는 손이 아주 자주 전화기로 가곤 했다. 이제 재의 손은 공부하는 한 시간 내내 펜 위에 머문다. 공부하는 동안, 전화기를 가지고 하는 이 작은 일은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this small step with his phone»(전화기를 가지고 하는 이 작은 일). 전화기를 서랍에 넣고 닫는 일이에요. 이 일이 재에게 무엇을 해 주는지를 물어요. 선택지의 'it'은 전화기예요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now his hand stays on his pen for the whole study hour.»(이제 재의 손은 공부하는 한 시간 내내 펜 위에 머문다.) 'his hand stays on his pen'(손이 펜 위에 머문다)이 단서예요.",
 "3) 둘째 문장 확인: «his hand used to go to it very often»(손이 아주 자주 전화기로 가곤 했다). 'used to'는 '전에는 ~하곤 했다'라는 뜻이에요. 셋째 문장의 'Now'(이제)와 맞서요.",
 "4) 묶기: 전에는 손이 전화기로 갔는데 이제는 펜 위에 머물러요. 손이 전화기로 가지 않게 된 것이에요. 그래서 'stops him reaching for it'(전화기로 손을 뻗지 않게 해 준다)이에요. 'reaching for it'은 '그것을 잡으려고 손을 뻗는 것'이에요. stops him 뒤에 -ing 꼴이 와서 「그가 ~하지 않게 막아 준다」라는 뜻이에요."],
 "「훨씬 일찍 끝내도록 도와준다」가 끌릴 수 있어요. 전화기를 안 보면 공부가 빨리 끝날 것 같거든요. 하지만 셋째 문장에서 재는 'the whole study hour'(공부하는 한 시간 내내) 펜을 잡고 있어요. 공부가 일찍 끝난다는 말은 없어요.",
 [("전화기를 깨끗하고 젖지 않게 해 준다", "지문에 없는 이야기예요. 전화기가 더러워지거나 젖는다는 말은 나오지 않아요."),
  ("그 한 시간 동안 전화기를 조용하게 해 준다", "지문에 없는 이야기예요. 전화기가 울리는지 조용한지는 나오지 않아요."),
  ("전화기를 잃어버리지 않게 해 준다", "지문에 없는 이야기예요. 전화기를 잃어버린다는 말은 나오지 않아요."),
  ("훨씬 일찍 끝내도록 도와준다", "지문에 없는 이야기예요. 재는 한 시간 내내 공부한다고 했어요. 더 일찍 끝낸다는 말은 없어요."),
  ("전화기로 손을 뻗지 않게 해 준다", "셋째 문장 «Now his hand stays on his pen for the whole study hour.»가 근거예요. 손이 펜 위에 머무니, 전화기로 손을 뻗지 않는 것이에요.")])

# ---------- 19번째: 오 분 일찍 나서기 (답 turn a rush into a walk) ----------
rw(18, 0, "Sana now leaves home five minutes earlier than last year. These days she goes slowly to the stop and takes the same bus. Last year she ran all the way there every single morning. For Sana, those five extra minutes ______.",
 ["turn a rush into a walk", "turn a wait into a chat", "turn a bus ride into a rest", "get her onto an earlier bus", "put her first in the bus line"],
 "사나는 이제 지난해보다 오 분 일찍 집을 나선다. 요즘은 정류장까지 천천히 가서 같은 버스를 탄다. 지난해에는 아침마다 빠짐없이 거기까지 내내 뛰었다. 사나에게, 더 생긴 그 오 분은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «those five extra minutes»(더 생긴 그 오 분). 일찍 나서서 생긴 오 분이에요. 이 오 분이 사나에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «These days she goes slowly to the stop and takes the same bus.»(요즘은 정류장까지 천천히 가서 같은 버스를 탄다.) 'goes slowly'(천천히 간다)가 단서예요.",
 "3) 셋째 문장 확인: «Last year she ran all the way there every single morning.»(지난해에는 아침마다 빠짐없이 거기까지 내내 뛰었다.) 'ran all the way'(내내 뛰었다)가 있어요. 둘째 문장의 'goes slowly'와 맞서요.",
 "4) 묶기: 지난해에는 뛰었다 = 'a rush'(서두르던 길). 요즘은 천천히 간다 = 'a walk'(걷는 길). 뛰던 길이 걷는 길로 바뀌었어요. 그래서 'turn a rush into a walk'(서두르던 길을 걷는 길로 바꾸어 준다)예요. 「turn A into B」는 「A를 B로 바꾸다」라는 뜻이에요."],
 "「더 이른 버스를 타게 해 준다」가 끌릴 수 있어요. 일찍 나서면 앞 버스를 탈 것 같거든요. 하지만 둘째 문장에서 'the same bus'(같은 버스)를 탄다고 했어요. 버스는 그대로이고, 가는 걸음만 느긋해졌어요.",
 [("서두르던 길을 걷는 길로 바꾸어 준다", "둘째 문장 «These days she goes slowly to the stop and takes the same bus.»가 근거예요. 지난해에는 뛰던 길을 요즘은 천천히 가요."),
  ("기다리는 시간을 이야기 나누는 시간으로 바꾸어 준다", "지문에 없는 이야기예요. 정류장에서 기다린다는 말도, 누구와 이야기한다는 말도 나오지 않아요."),
  ("버스 타는 시간을 쉬는 시간으로 바꾸어 준다", "지문에 없는 이야기예요. 버스 안에서 무엇을 하는지는 나오지 않아요."),
  ("더 이른 버스를 타게 해 준다", "글과 맞지 않아요. 둘째 문장에서 같은 버스를 탄다고 했어요."),
  ("버스 줄의 맨 앞에 서게 해 준다", "지문에 없는 이야기예요. 버스 줄은 나오지 않아요.")])

# ---------- 20번째: 한 달 동안 적는 쓴 돈 (답 understands her own spending — 옛 knows where her money goes) ----------
rw(19, 2, "Aria keeps a note of all her shopping for one whole month. Then she adds up the numbers for snacks, clothes and games. To her surprise, half of her pocket money goes on snacks. At the end of the month, Aria ______.",
 ["has saved half of her money", "knows the best shop for snacks", "understands her own spending", "has a plan for next month", "buys fewer things than before"],
 "아리아는 꼬박 한 달 동안 산 것을 모두 적어 둔다. 그런 다음 간식, 옷, 게임에 쓴 돈을 따로따로 더한다. 놀랍게도 용돈의 절반이 간식에 나간다. 그달 말에, 아리아는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «At the end of the month, Aria»(그달 말에, 아리아는). 한 달 동안 적은 뒤에 아리아가 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «half of her pocket money goes on snacks»(용돈의 절반이 간식에 나간다). 'goes on snacks'(간식에 나간다)가 단서예요. 돈이 어디에 나가는지 알게 되었어요. 'To her surprise'(놀랍게도)라고 했으니, 전에는 몰랐던 것이에요.",
 "3) 둘째 문장 확인: «she adds up the numbers for snacks, clothes and games»(간식, 옷, 게임에 쓴 돈을 따로따로 더한다). 무엇에 얼마를 썼는지 갈라서 본 것이에요.",
 "4) 묶기: 돈이 어디에 얼마나 나가는지 알게 되었다 = 'understands her own spending'(자기가 돈을 어떻게 쓰는지 이해한다). 'spending'은 '돈을 쓰는 것'이에요."],
 "「자기 돈의 절반을 모았다」가 끌릴 수 있어요. 글에 'half of her pocket money'(용돈의 절반)가 나오거든요. 하지만 그 절반은 모은 돈이 아니라 간식에 나간 돈이에요.",
 [("자기 돈의 절반을 모았다", "지문에 없는 이야기예요. 글에 나온 「절반」은 모은 돈이 아니라 간식에 나간 돈이에요. 돈을 모았다는 말은 나오지 않아요."),
  ("간식을 사기에 가장 좋은 가게를 안다", "지문에 없는 이야기예요. 어느 가게가 좋은지는 나오지 않아요."),
  ("자기가 돈을 어떻게 쓰는지 이해한다", "셋째 문장 «half of her pocket money goes on snacks»가 근거예요. 용돈의 절반이 간식에 나간다는 것을 알게 되었으니, 자기가 돈을 어떻게 쓰는지 이해한 것이에요."),
  ("다음 달 계획을 세워 두었다", "지문에 없는 이야기예요. 다음 달 이야기는 나오지 않아요."),
  ("전보다 물건을 덜 산다", "지문에 없는 이야기예요. 덜 산다는 말은 나오지 않아요. 글이 말한 것은 돈이 어디에 나가는지 알게 되었다는 것이에요.")])

# ---------- 21번째: 아침 식탁의 이야기 한 쪽 (답 start the day calmly) ----------
rw(20, 4, "Dan's mornings used to be full of hurry and loud voices. These days he leaves home slowly, with an easy smile on his face. The change began with one page of a story at breakfast every day. This small morning habit helps him ______.",
 ["enjoy stories more than before", "learn a new word each day", "talk more with his family", "eat a bigger breakfast", "start the day calmly"],
 "댄의 아침은 전에는 서두름과 큰 목소리로 가득했다. 요즘 댄은 편안한 미소를 띠고 천천히 집을 나선다. 이 변화는 날마다 아침 식탁에서 읽는 이야기 한 쪽에서 비롯되었다. 아침의 이 작은 버릇은 댄이 ______ 도와준다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «This small morning habit helps him»(아침의 이 작은 버릇은 댄이 ~하도록 도와준다). 아침 식탁에서 이야기 한 쪽을 읽는 버릇이에요. 이 버릇이 무엇을 도와주는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «These days he leaves home slowly, with an easy smile on his face.»(요즘 댄은 편안한 미소를 띠고 천천히 집을 나선다.) 'slowly'(천천히)와 'an easy smile'(편안한 미소)이 단서예요.",
 "3) 첫 문장 확인: «Dan's mornings used to be full of hurry and loud voices.»(댄의 아침은 전에는 서두름과 큰 목소리로 가득했다.) 'used to be'는 '전에는 ~했다'라는 뜻이에요. 둘째 문장의 'These days'(요즘)와 맞서요.",
 "4) 묶기: 서두름과 큰 목소리 → 천천히, 편안한 미소. 아침이 차분해졌어요. 그래서 'start the day calmly'(하루를 차분하게 시작하다)예요. 'calmly'는 '차분하게'라는 뜻이에요."],
 "「전보다 이야기를 더 즐기도록」이 끌릴 수 있어요. 날마다 이야기를 읽으니까요. 하지만 글에는 이야기가 재미있다는 말이 없어요. 글이 견준 것은 전의 아침과 요즘의 아침이에요.",
 [("전보다 이야기를 더 즐기도록", "지문에 없는 이야기예요. 이야기를 얼마나 즐기는지는 나오지 않아요."),
  ("날마다 새 낱말을 하나씩 배우도록", "지문에 없는 이야기예요. 낱말을 배운다는 말은 나오지 않아요."),
  ("식구들과 더 많이 말하도록", "지문에 없는 이야기예요. 식구들과 말을 나눈다는 말은 나오지 않아요."),
  ("아침을 더 많이 먹도록", "지문에 없는 이야기예요. 아침을 얼마나 먹는지는 나오지 않아요."),
  ("하루를 차분하게 시작하도록", "둘째 문장 «These days he leaves home slowly, with an easy smile on his face.»가 근거예요. 서두르던 아침이 천천히, 편안하게 바뀌었으니, 하루를 차분하게 시작하는 것이에요.")])

# ---------- 22번째: 잠자리에 들기 한 시간 전에 끄는 화면 (답 falls asleep more easily) ----------
rw(21, 1, "Nara turns off her phone and computer an hour before bed. In bed, her eyes now close in ten minutes, not in an hour like before. She spends the last hour of the day with quiet music and warm milk. Thanks to this habit of hers, Nara now ______.",
 ["goes to bed an hour earlier", "falls asleep more easily", "finishes her homework sooner", "has far fewer bad dreams", "feels less tired at school"],
 "나라는 잠자리에 들기 한 시간 전에 전화기와 컴퓨터를 끈다. 잠자리에 누우면 이제는 전처럼 한 시간이 아니라 십 분 만에 눈이 감긴다. 하루의 마지막 한 시간은 조용한 음악과 따뜻한 우유와 함께 보낸다. 이 버릇 덕분에, 나라는 이제 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to this habit of hers»(이 버릇 덕분에). 잠자리에 들기 한 시간 전에 전화기와 컴퓨터를 끄는 버릇이에요. 그 덕분에 나라가 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «her eyes now close in ten minutes, not in an hour like before»(이제는 전처럼 한 시간이 아니라 십 분 만에 눈이 감긴다). 'in ten minutes'(십 분 만에)가 단서예요. 눈이 감긴다는 것은 잠이 든다는 뜻이에요.",
 "3) 첫 문장 확인: «Nara turns off her phone and computer an hour before bed.»(나라는 잠자리에 들기 한 시간 전에 전화기와 컴퓨터를 끈다.) 넷째 문장의 'this habit'(이 버릇)이 바로 이 일이에요.",
 "4) 묶기: 한 시간 걸리던 것이 십 분으로 줄었어요. 잠드는 일이 쉬워진 것이에요. 그래서 'falls asleep more easily'(더 쉽게 잠든다)예요. 'falls asleep'은 '잠든다'라는 뜻이에요."],
 "「한 시간 더 일찍 잠자리에 든다」가 끌릴 수 있어요. 글에 'an hour before bed'(잠자리에 들기 한 시간 전)가 나오거든요. 하지만 한 시간 전에 하는 일은 전화기와 컴퓨터를 끄는 것이에요. 잠자리에 드는 시간이 빨라졌다는 말은 없어요.",
 [("한 시간 더 일찍 잠자리에 든다", "지문에 없는 이야기예요. 한 시간 전에 하는 것은 전화기와 컴퓨터를 끄는 일이에요. 잠자리에 드는 시간이 바뀌었다는 말은 없어요."),
  ("더 쉽게 잠든다", "둘째 문장 «her eyes now close in ten minutes, not in an hour like before»가 근거예요. 전에는 한 시간이 걸렸는데 이제는 십 분 만에 눈이 감기니, 더 쉽게 잠드는 것이에요."),
  ("숙제를 더 일찍 끝낸다", "지문에 없는 이야기예요. 숙제는 나오지 않아요."),
  ("나쁜 꿈을 훨씬 덜 꾼다", "지문에 없는 이야기예요. 꿈은 나오지 않아요."),
  ("학교에서 덜 피곤하다", "지문에 없는 이야기예요. 학교에서 어떤지는 나오지 않아요.")])

# ---------- 23번째: 정한 것을 적는 동아리 공책 (답 argues about past decisions — 옛 argues about what was agreed) ----------
rw(22, 0, "This year the chess club writes every decision in a blue notebook after each meeting. Last year two members remembered the same plan in different ways. With the notebook, no meeting has started with a fight over an old plan. These days, nobody in the chess club ______.",
 ["argues about past decisions", "misses any club news", "comes late to the meetings", "forgets the day of a game", "talks for too long"],
 "올해 체스 동아리는 모임이 끝날 때마다 결정한 것을 모두 파란 공책에 적는다. 지난해에는 두 회원이 같은 계획을 서로 다르게 기억했다. 공책이 생긴 뒤로는 옛 계획을 두고 다투며 시작한 모임이 한 번도 없다. 요즘 체스 동아리에는 ______ 사람이 아무도 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «nobody in the chess club»(체스 동아리에는 ~하는 사람이 아무도 없다). 'nobody'는 '아무도 ~않다'라는 뜻이에요. 요즘 동아리에서 아무도 하지 않는 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «no meeting has started with a fight over an old plan»(옛 계획을 두고 다투며 시작한 모임이 한 번도 없다). 'a fight over an old plan'(옛 계획을 두고 벌이는 다툼)이 단서예요.",
 "3) 둘째 문장 확인: «Last year two members remembered the same plan in different ways.»(지난해에는 두 회원이 같은 계획을 서로 다르게 기억했다.) 다툼이 생기던 까닭이에요. 적어 두지 않아서 기억이 서로 달랐어요.",
 "4) 묶기: 'a fight'(다툼)를 다른 말로 하면 'argues'(다툰다)예요. 'an old plan'(옛 계획)을 다른 말로 하면 'past decisions'(지난 결정)예요. 그래서 'argues about past decisions'(지난 결정을 두고 다툰다)가 들어가서, 「지난 결정을 두고 다투는 사람이 아무도 없다」가 돼요."],
 "「경기 날을 잊는」이 끌릴 수 있어요. 공책에 적어 두면 날짜도 잊지 않을 것 같거든요. 하지만 글에는 경기가 나오지 않아요. 글이 말한 것은 옛 계획을 두고 다투는 일이 없어졌다는 것이에요.",
 [("지난 결정을 두고 다투는", "셋째 문장 «no meeting has started with a fight over an old plan»이 근거예요. 옛 계획을 두고 다투며 시작한 모임이 없으니, 지난 결정을 두고 다투는 사람이 없는 것이에요."),
  ("동아리 소식을 하나라도 놓치는", "지문에 없는 이야기예요. 동아리 소식은 나오지 않아요."),
  ("모임에 늦게 오는", "지문에 없는 이야기예요. 모임에 오는 시간은 나오지 않아요."),
  ("경기 날을 잊는", "지문에 없는 이야기예요. 경기는 나오지 않아요. 글에서 서로 다르게 기억한 것은 계획이에요."),
  ("너무 오래 말하는", "지문에 없는 이야기예요. 누가 얼마나 오래 말하는지는 나오지 않아요.")])

# ---------- 24번째: 일요일 밤에 세어 넣는 수영 준비물 (답 never leaves anything behind) ----------
rw(23, 2, "Min puts his swimming things on his bed every Sunday night. He counts them into his bag one by one: towel, cap, shorts and goggles. At the pool on Monday, all four are in his bag every single week. Thanks to this habit, on Mondays he ______.",
 ["arrives first at the pool", "swims faster every week", "never leaves anything behind", "keeps his swimming things dry", "gets ready without any help"],
 "민은 일요일 밤마다 수영 준비물을 침대 위에 올려놓는다. 수건, 수영모, 수영 바지, 물안경을 하나씩 세면서 가방에 넣는다. 월요일에 수영장에 가면 주마다 빠짐없이 네 가지가 모두 가방 안에 있다. 이 버릇 덕분에, 월요일마다 민은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to this habit, on Mondays he»(이 버릇 덕분에, 월요일마다 민은). 일요일 밤에 준비물을 세면서 가방에 넣는 버릇이에요. 그 덕분에 월요일에 어떠한지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «all four are in his bag every single week»(주마다 빠짐없이 네 가지가 모두 가방 안에 있다). 'all four'(네 가지 모두)와 'every single week'(주마다 빠짐없이)가 단서예요.",
 "3) 둘째 문장 확인: «He counts them into his bag one by one»(하나씩 세면서 가방에 넣는다). 네 가지가 늘 다 들어 있는 까닭이에요.",
 "4) 묶기: 네 가지가 모두 가방에 있다 = 집에 두고 온 것이 없다. 그래서 'never leaves anything behind'(결코 아무것도 두고 오지 않는다)예요. 「leave ~ behind」는 「~을 두고 오다」라는 뜻이에요."],
 "「누구의 도움도 없이 준비한다」가 끌릴 수 있어요. 민이 준비물을 직접 세어 넣으니까요. 하지만 글에는 누가 돕는다는 말도, 돕지 않는다는 말도 없어요. 글이 말한 것은 네 가지가 모두 가방 안에 있다는 것이에요.",
 [("수영장에 가장 먼저 도착한다", "지문에 없는 이야기예요. 수영장에 도착하는 순서는 나오지 않아요."),
  ("주마다 더 빨리 헤엄친다", "지문에 없는 이야기예요. 얼마나 빨리 헤엄치는지는 나오지 않아요."),
  ("결코 아무것도 두고 오지 않는다", "셋째 문장 «all four are in his bag every single week»가 근거예요. 주마다 네 가지가 모두 가방에 있으니, 두고 오는 것이 없는 것이에요."),
  ("수영 준비물을 젖지 않게 해 둔다", "지문에 없는 이야기예요. 준비물이 젖는다는 말은 나오지 않아요."),
  ("누구의 도움도 없이 준비한다", "지문에 없는 이야기예요. 누가 돕는다는 말도, 돕지 않는다는 말도 나오지 않아요.")])

# ---------- 25번째: 부엌 벽의 달력 (답 misses a single one) ----------
rw(24, 4, "This year the Park family has gone to every appointment on the right day. Last year Dad forgot the dentist twice in one month. In January they hung a big calendar on the kitchen wall for such visits. With all these appointments, nobody in the family ______.",
 ["complains about a single one", "pays for a single one", "is afraid of a single one", "has to drive far for one", "misses a single one"],
 "올해 박씨네 가족은 예약마다 제날짜에 맞춰 갔다. 지난해에는 아빠가 한 달에 두 번이나 치과 예약을 잊었다. 1월에 가족은 그런 일정을 챙기려고 부엌 벽에 큰 달력을 걸었다. 예약이 이렇게 많은데도, 가족 가운데 ______ 사람은 아무도 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «nobody in the family»(가족 가운데 ~하는 사람은 아무도 없다). 가족 가운데 아무도 하지 않는 일이 무엇인지를 물어요. 선택지의 'one'은 앞에 나온 'appointments'(예약) 가운데 하나를 가리켜요.",
 "2) 짝꿍 문장: 첫 문장이에요. «the Park family has gone to every appointment on the right day»(박씨네 가족은 예약마다 제날짜에 맞춰 갔다). 'every appointment'(예약마다)가 단서예요.",
 "3) 둘째 문장 확인: «Last year Dad forgot the dentist twice in one month.»(지난해에는 아빠가 한 달에 두 번이나 치과 예약을 잊었다.) 지난해에는 예약을 놓쳤어요. 첫 문장의 'This year'(올해)와 맞서요.",
 "4) 묶기: 예약마다 갔다 = 하나도 놓치지 않았다. 그래서 'misses a single one'(예약을 하나라도 놓친다)이 들어가서, 「예약을 하나라도 놓치는 사람은 아무도 없다」가 돼요. 'a single one'은 '단 하나'라는 뜻이에요."],
 "「예약을 하나라도 무서워하는」이 끌릴 수 있어요. 글에 'the dentist'(치과)가 나오거든요. 치과라면 무서워하는 사람이 많으니까요. 하지만 글에는 무섭다는 말이 없어요. 글이 말한 것은 예약마다 제날짜에 갔다는 것이에요.",
 [("예약 하나에라도 불평하는", "지문에 없는 이야기예요. 불평한다는 말은 나오지 않아요."),
  ("예약 하나에라도 돈을 내는", "지문에 없는 이야기예요. 돈 이야기는 나오지 않아요."),
  ("예약을 하나라도 무서워하는", "지문에 없는 이야기예요. 무섭다는 말은 나오지 않아요. 글이 말한 것은 예약에 갔는지예요."),
  ("예약 때문에 멀리 운전해야 하는", "지문에 없는 이야기예요. 얼마나 멀리 가는지는 나오지 않아요."),
  ("예약을 하나라도 놓치는", "첫 문장 «the Park family has gone to every appointment on the right day»가 근거예요. 올해는 예약마다 제날짜에 갔으니, 하나라도 놓치는 사람이 없는 것이에요.")])

# ---------- 26번째: 자기 전에 확인하는 뒷문 (답 sleep without worrying) ----------
rw(25, 4, "Jun checks the lock on the back door every night before bed. As a small boy, he often stayed awake with thoughts of an open door. Now his mind is quiet from the first minute in bed. Every night, this ten-second habit helps him ______.",
 ["sleep a little longer", "feel warm in bed", "wake up fresh", "remember his dreams", "sleep without worrying"],
 "준은 밤마다 자기 전에 뒷문의 자물쇠를 확인한다. 어린아이였을 때 준은 열린 문 생각 때문에 자주 깨어 있었다. 이제는 잠자리에 누운 첫 일 분부터 마음이 고요하다. 밤마다, 십 초면 되는 이 버릇은 준이 ______ 도와준다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this ten-second habit helps him»(십 초면 되는 이 버릇은 준이 ~하도록 도와준다). 자기 전에 뒷문 자물쇠를 확인하는 버릇이에요. 이 버릇이 무엇을 도와주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now his mind is quiet from the first minute in bed.»(이제는 잠자리에 누운 첫 일 분부터 마음이 고요하다.) 'his mind is quiet'(마음이 고요하다)가 단서예요.",
 "3) 둘째 문장 확인: «he often stayed awake with thoughts of an open door»(열린 문 생각 때문에 자주 깨어 있었다). 전에는 문 걱정을 했어요. 'thoughts of an open door'(열린 문 생각)가 바로 그 걱정이에요.",
 "4) 묶기: 열린 문 생각이 없다 = 걱정이 없다. 마음이 고요하다 = 걱정이 없다. 그래서 'sleep without worrying'(걱정 없이 자다)이에요."],
 "「조금 더 오래 자도록」이 끌릴 수 있어요. 전에는 자주 깨어 있었으니 이제는 더 오래 잘 것 같거든요. 하지만 글에는 얼마나 오래 자는지가 나오지 않아요. 글이 말한 것은 마음이 고요하다는 것이에요.",
 [("조금 더 오래 자도록", "지문에 없는 이야기예요. 얼마나 오래 자는지는 나오지 않아요."),
  ("잠자리에서 따뜻하게 느끼도록", "지문에 없는 이야기예요. 따뜻한지 추운지는 나오지 않아요."),
  ("개운하게 깨어나도록", "지문에 없는 이야기예요. 아침에 어떻게 깨는지는 나오지 않아요."),
  ("꿈을 기억하도록", "지문에 없는 이야기예요. 꿈은 나오지 않아요."),
  ("걱정 없이 자도록", "셋째 문장 «Now his mind is quiet from the first minute in bed.»가 근거예요. 열린 문 생각 없이 마음이 고요하니, 걱정 없이 자는 것이에요.")])

# ---------- 27번째: 기둥에 잠가 두는 자전거 (답 has never been taken) ----------
rw(26, 1, "Hana's first bicycle disappeared from the street outside a shop. Her new one has been in its place at the end of every shopping trip. She always locks it to a metal post or a strong fence. In two years of shopping trips, her new bicycle ______.",
 ["has never had a flat tyre", "has never been taken", "has never been left in the rain", "has never lost its front light", "has never fallen over"],
 "하나가 처음 타던 자전거는 가게 밖 길에서 사라졌다. 새 자전거는 장을 보고 나올 때마다 늘 제자리에 있었다. 하나는 언제나 새 자전거를 쇠기둥이나 튼튼한 울타리에 잠가 둔다. 장을 보러 다닌 두 해 동안, 하나가 타는 새 자전거는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «In two years of shopping trips, her new bicycle»(장을 보러 다닌 두 해 동안, 하나가 타는 새 자전거는). 두 해 동안 새 자전거에 한 번도 일어나지 않은 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Her new one has been in its place at the end of every shopping trip.»(새 자전거는 장을 보고 나올 때마다 늘 제자리에 있었다.) 'in its place'(제자리에)와 'every'(~마다)가 단서예요. 여기서 'one'은 자전거를 가리켜요.",
 "3) 첫 문장 확인: «Hana's first bicycle disappeared from the street outside a shop.»(하나가 처음 타던 자전거는 가게 밖 길에서 사라졌다.) 'disappeared'(사라졌다)가 있어요. 첫 자전거는 누가 가져간 것으로 볼 수 있어요.",
 "4) 묶기: 늘 제자리에 있었다 = 사라진 적이 없다 = 누가 가져간 적이 없다. 그래서 'has never been taken'(누가 가져간 적이 한 번도 없다)이에요. 'been taken'은 '누가 가져갔다'라는 뜻이에요."],
 "「넘어진 적이 한 번도 없다」가 끌릴 수 있어요. 기둥이나 울타리에 잠가 두면 넘어지지도 않을 것 같거든요. 하지만 글에는 자전거가 넘어진다는 말이 없어요. 글이 말한 것은 자전거가 늘 제자리에 있었다는 것이에요.",
 [("바퀴에 바람이 빠진 적이 한 번도 없다", "지문에 없는 이야기예요. 바퀴 이야기는 나오지 않아요."),
  ("누가 가져간 적이 한 번도 없다", "둘째 문장 «Her new one has been in its place at the end of every shopping trip.»이 근거예요. 장을 보고 나올 때마다 제자리에 있었으니, 누가 가져간 적이 없는 것이에요."),
  ("빗속에 세워 둔 적이 한 번도 없다", "지문에 없는 이야기예요. 비는 나오지 않아요."),
  ("앞 등을 잃어버린 적이 한 번도 없다", "지문에 없는 이야기예요. 자전거의 등은 나오지 않아요."),
  ("넘어진 적이 한 번도 없다", "지문에 없는 이야기예요. 자전거가 넘어진다는 말은 나오지 않아요.")])

# ---------- 28번째: 일요일 저녁에 펴 보는 수첩 (답 knows the week ahead — 옛 knows what is coming) ----------
rw(27, 3, "Chen opens his diary for ten minutes every Sunday evening. He looks at the tests, club meetings and birthdays for the next seven days. On Monday morning, nothing at school comes as a surprise to him. At the start of every school week, Chen ______.",
 ["has studied for every test", "has his homework ready", "feels well rested", "knows the week ahead", "has his bag by the door"],
 "첸은 일요일 저녁마다 십 분 동안 수첩을 펼친다. 앞으로 7일 동안 있을 시험과 동아리 모임과 생일을 살펴본다. 월요일 아침, 학교에서 첸을 놀라게 하는 일은 하나도 없다. 학교의 한 주가 시작될 때마다, 첸은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «At the start of every school week»(학교의 한 주가 시작될 때마다). 한 주가 시작될 때 첸이 어떠한지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On Monday morning, nothing at school comes as a surprise to him.»(월요일 아침, 학교에서 첸을 놀라게 하는 일은 하나도 없다.) 'comes as a surprise'(놀라운 일로 다가오다) 앞에 'nothing'(아무것도 ~않다)이 있어요. 놀랄 일이 하나도 없다는 뜻이에요.",
 "3) 둘째 문장 확인: «He looks at the tests, club meetings and birthdays for the next seven days.»(앞으로 7일 동안 있을 시험과 동아리 모임과 생일을 살펴본다.) 놀랄 일이 없는 까닭이에요. 'the next seven days'(앞으로 7일)는 다가올 한 주예요.",
 "4) 묶기: 놀랄 일이 없다 = 무슨 일이 있을지 이미 안다. 그래서 'knows the week ahead'(다가올 한 주를 알고 있다)예요. 'ahead'는 '앞에 있는, 다가올'이라는 뜻이에요."],
 "「시험마다 공부를 해 두었다」가 끌릴 수 있어요. 글에 'tests'(시험)가 나오거든요. 하지만 첸이 일요일 저녁에 하는 일은 시험이 언제 있는지 살펴보는 것이에요. 공부를 했다는 말은 없어요.",
 [("시험마다 공부를 해 두었다", "지문에 없는 이야기예요. 첸은 시험이 언제 있는지 살펴볼 뿐이에요. 공부를 했다는 말은 없어요."),
  ("숙제를 다 해 두었다", "지문에 없는 이야기예요. 숙제는 나오지 않아요."),
  ("푹 쉰 느낌이다", "지문에 없는 이야기예요. 얼마나 쉬었는지는 나오지 않아요."),
  ("다가올 한 주를 알고 있다", "셋째 문장 «On Monday morning, nothing at school comes as a surprise to him.»이 근거예요. 놀랄 일이 하나도 없으니, 다가올 한 주를 알고 있는 것이에요."),
  ("가방을 문 옆에 두었다", "지문에 없는 이야기예요. 가방은 나오지 않아요.")])

# ---------- 29번째: 못 먹는 음식을 미리 묻는 주인 (답 is left without something to eat) ----------
rw(28, 3, "Before every dinner party, Mrs Lee sends a short question to each guest. The question is about problem foods, like meat, milk or fish. On the night, every plate has safe and tasty food on it. At her dinners, nobody at the table ______.",
 ["sits next to a stranger", "is left without somebody to talk to", "goes home before dessert", "is left without something to eat", "waits long for the first dish"],
 "저녁 모임을 열기 전에는 언제나, 리 부인은 손님 한 사람 한 사람에게 짧은 물음을 보낸다. 그 물음은 고기나 우유나 생선처럼 먹으면 탈이 나는 음식에 관한 것이다. 모임 날 밤, 접시마다 마음 놓고 먹을 수 있는 맛있는 음식이 담겨 있다. 리 부인의 저녁 모임에서는 식탁에 ______ 사람이 아무도 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «nobody at the table»(식탁에 ~하는 사람이 아무도 없다). 저녁 모임의 식탁에서 아무에게도 일어나지 않는 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «every plate has safe and tasty food on it»(접시마다 마음 놓고 먹을 수 있는 맛있는 음식이 담겨 있다). 'every plate'(접시마다)와 'safe'(마음 놓고 먹을 수 있는)가 단서예요.",
 "3) 둘째 문장 확인: «The question is about problem foods, like meat, milk or fish.»(그 물음은 고기나 우유나 생선처럼 먹으면 탈이 나는 음식에 관한 것이다.) 손님마다 못 먹는 음식을 미리 물어요. 그래서 접시마다 그 손님이 먹을 수 있는 음식을 담을 수 있어요.",
 "4) 묶기: 접시마다 먹을 수 있는 음식이 있다 = 먹을 것이 없는 손님이 없다. 그래서 'is left without something to eat'(먹을 것 없이 남겨진다)가 들어가서, 「먹을 것 없이 남겨지는 사람이 아무도 없다」가 돼요. 'is left without'은 '~ 없이 남겨진다'라는 뜻이에요."],
 "「이야기 나눌 사람 없이 남겨지는」이 끌릴 수 있어요. 앞부분이 답과 똑같거든요. 하지만 글에서 리 부인이 미리 묻는 것은 음식이에요. 누구와 이야기하는지는 나오지 않아요.",
 [("낯선 사람 옆에 앉는", "지문에 없는 이야기예요. 누가 어디에 앉는지는 나오지 않아요."),
  ("이야기 나눌 사람 없이 남겨지는", "지문에 없는 이야기예요. 누구와 이야기하는지는 나오지 않아요. 글에서 미리 묻는 것은 음식이에요."),
  ("후식 전에 집에 가는", "지문에 없는 이야기예요. 후식도, 집에 가는 시간도 나오지 않아요."),
  ("먹을 것 없이 남겨지는", "셋째 문장 «every plate has safe and tasty food on it»이 근거예요. 접시마다 먹을 수 있는 음식이 있으니, 먹을 것 없이 남겨지는 사람이 없는 것이에요."),
  ("첫 음식을 오래 기다리는", "지문에 없는 이야기예요. 음식을 기다리는 시간은 나오지 않아요.")])

# ---------- 30번째: 침대에서 먼 자명종 (답 has to get out of bed) ----------
rw(29, 3, "Rin's alarm clock used to sit right next to her pillow. She turned it off with one hand and slept for another hour. Now the clock rings from a shelf five steps away from her bed. At six every morning, Rin now ______.",
 ["has to walk the family dog", "has to make her own breakfast", "has to use both hands", "has to get out of bed", "has to wake her little brother"],
 "린의 자명종은 전에는 베개 바로 옆에 놓여 있었다. 린은 한 손으로 자명종을 끄고 한 시간을 더 잤다. 이제 자명종은 침대에서 다섯 걸음 떨어진 선반에서 울린다. 아침마다 여섯 시에, 린은 이제 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «At six every morning, Rin now»(아침마다 여섯 시에, 린은 이제). 'now'(이제)가 있어요. 자명종 자리를 바꾼 뒤로 아침마다 무엇을 해야 하는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now the clock rings from a shelf five steps away from her bed.»(이제 자명종은 침대에서 다섯 걸음 떨어진 선반에서 울린다.) 'five steps away from her bed'(침대에서 다섯 걸음 떨어진)가 단서예요.",
 "3) 둘째 문장 확인: «She turned it off with one hand and slept for another hour.»(린은 한 손으로 자명종을 끄고 한 시간을 더 잤다.) 전에는 누운 채로 한 손만 뻗으면 끌 수 있었어요. 그래서 다시 잠들었어요.",
 "4) 묶기: 자명종이 침대에서 다섯 걸음 떨어져 있어요. 누운 채로는 손이 닿지 않아요. 끄려면 일어나서 걸어가야 해요. 그래서 'has to get out of bed'(침대에서 나와야 한다)예요. 'has to'는 '~해야 한다'라는 뜻이에요."],
 "「두 손을 다 써야 한다」가 끌릴 수 있어요. 둘째 문장에 'one hand'(한 손)가 나오거든요. 하지만 한 손으로 끈 것은 전의 일이에요. 지금 달라진 것은 손의 수가 아니라 자명종까지의 거리예요.",
 [("집에서 기르는 개를 산책시켜야 한다", "지문에 없는 이야기예요. 개는 나오지 않아요."),
  ("아침밥을 손수 차려야 한다", "지문에 없는 이야기예요. 아침밥은 나오지 않아요."),
  ("두 손을 다 써야 한다", "지문에 없는 이야기예요. 글의 'one hand'(한 손)는 전에 자명종을 끄던 모습이에요. 지금 두 손을 쓴다는 말은 없어요."),
  ("침대에서 나와야 한다", "셋째 문장 «Now the clock rings from a shelf five steps away from her bed.»가 근거예요. 자명종이 침대에서 다섯 걸음 떨어져 있으니, 끄려면 침대에서 나와야 해요."),
  ("남동생을 깨워야 한다", "지문에 없는 이야기예요. 남동생은 나오지 않아요.")])
