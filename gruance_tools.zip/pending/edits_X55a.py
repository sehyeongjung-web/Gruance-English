# -*- coding: utf-8 -*-
# 315번: 31번(빈칸 추론) 레벨1 — 새 레벨 기준으로 다시 씀 (앞 절반: 1~15번째)
# 선생님 결정(314번 뒤): 「1. 레벨 1부터. 2. 문장 수도 늘립시다. 3. 다시 씁시다」
# 레벨1의 기준(LEVEL_GUIDE.md): 중학 기초 생활 낱말 · 단문(접속사로 절을 잇지 않음) · 문장당 10~15낱말
#   - to부정사·동명사·비교급·전치사구는 씀. 종속접속사(because·when·if)·관계사절·분사구문·명사절은 쓰지 않음
#   - Because of·Thanks to·With·After + 명사는 전치사구라서 씀
# 지문의 꼴: 두 문장(14낱말쯤) → **네 문장(45낱말쯤)**. 첫 문장 = 하는 일 / 둘째·셋째 = 그 일의 모습과 결과(셋째가 짝꿍 문장) / 넷째 = 빈칸 문장
#   - 45낱말은 레벨 사다리의 레벨1 눈금(45/52/60/…)에 맞춘 것
# 생각의 단계(추론축 레벨1): 글에 있는 말 하나를 그대로 확인 — 빈칸의 답이 바로 앞 문장에 다른 말로 나옴
# 글감·정답 번호는 그대로. 정답 낱말도 그대로(3번째만 reliable → safe: 중학 기초 낱말이 아니어서). 선택지를 바꾼 문항은 3·13번째뿐
# 낱말: 한국 중학생에게 낯선 영국식 낱말(queue·lift·corridor·by post)은 line·elevator·hall·in boxes로 씀. 철자(practises·colourful)는 그대로
# 독립 풀이(답을 모르는 채로 한 번): 15문항 모두 같은 답, 둘째 답이 서는 문항 없음. 지적받은 어색한 표현 열 군데를 고침
# zlevel.py로 재 봄: 문장 60개가 모두 단문, 10~13낱말, 지문 평균 45낱말쯤(인계문서 315번에 적음)
# 해석·풀이·선택지별 해설도 새로 씀(「~어요」, 31~34번의 두터운 꼴 — z8common.py)
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '31', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, ko, steps, traps, cn, ch=None):
    """문항을 통째로 다시 씀: 지문·해석·풀이·해설. 정답 번호는 그대로. ch = {자리: 새 선택지}(바꾸는 문항만)"""
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=bool(ch and ans in ch)); e = E.pop((T, LV, n))
    choices = list(_tb[T][LV][n]['choices'])
    for k, v in (ch or {}).items(): choices[k] = v
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(choices)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': choices, 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 1번째: 날마다 물을 준 식물 (답 healthy) ----------
rw(0, 0, "Tom waters the plants in his room every morning before school. He also keeps them near the window for the sunlight. Their leaves are green and strong all through the year. Because of his daily care, the plants always stay ______.",
 "톰은 학교에 가기 전 아침마다 자기 방의 식물에 물을 준다. 그는 또 햇빛을 받도록 식물을 창가에 둔다. 식물의 잎은 일 년 내내 푸르고 튼튼하다. 그가 날마다 돌본 덕분에 식물은 늘 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the plants always stay»(그 식물들은 늘 ~하게 지낸다). 톰이 돌본 식물이 어떤 모습인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Their leaves are green and strong all through the year.»(그것들의 잎은 일 년 내내 푸르고 튼튼하다.) 식물의 모습을 바로 앞에서 이미 말했어요. 'green and strong'(푸르고 튼튼한)이 단서예요.",
 "3) 첫 문장 확인: «Tom waters the plants in his room every morning before school.»(톰은 학교에 가기 전 아침마다 자기 방의 식물에 물을 준다.) 날마다 물을 주고 햇빛도 받게 해요. 잘 돌본 식물 이야기예요.",
 "4) 묶기: 잎이 푸르고 튼튼하다 = 'healthy'(건강한). 'green and strong'을 한 낱말로 바꾼 것이에요."],
 "「아주 작은」이 끌릴 수 있어요. 방 안에서 기르는 식물은 작을 것 같거든요. 하지만 식물의 크기는 글에 나오지 않아요. 글이 말한 것은 잎이 푸르고 튼튼하다는 것이에요.",
 [("건강한", "셋째 문장 «Their leaves are green and strong all through the year.»가 근거예요. 잎이 일 년 내내 푸르고 튼튼하다는 것은 식물이 건강하다는 뜻이에요."),
  ("비싼", "지문에 없는 이야기예요. 식물의 값은 나오지 않아요. 물을 주는 일과 값은 상관이 없어요."),
  ("시끄러운", "지문에 없는 이야기예요. 식물은 소리를 내지 않아요. 글은 잎의 모습을 말했어요."),
  ("드문", "지문에 없는 이야기예요. 이 식물이 보기 드문 식물인지는 나오지 않아요."),
  ("아주 작은", "지문에 없는 이야기예요. 식물의 크기는 나오지 않아요. 글이 말한 것은 잎이 푸르고 튼튼하다는 것이에요.")])

# ---------- 2번째: 숙제를 한 번 더 보는 습관 (답 steady) ----------
rw(1, 3, "Mia checks her homework once more before giving it to her teacher. She finds small mistakes and fixes them with a red pen. This year her homework scores are almost the same every week. With this simple habit, her homework scores have become very ______.",
 "미아는 숙제를 선생님께 내기 전에 한 번 더 살펴본다. 그녀는 작은 실수를 찾아내어 빨간 펜으로 고친다. 올해 그녀의 숙제 점수는 주마다 거의 같다. 이 간단한 습관으로 그녀의 숙제 점수는 아주 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «her homework scores have become very»(그녀의 숙제 점수는 아주 ~해졌다). 미아의 숙제 점수가 어떻게 되었는지를 물어요. 'scores'는 점수예요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «This year her homework scores are almost the same every week.»(올해 그녀의 숙제 점수는 주마다 거의 같다.) 점수가 어떤지를 바로 앞에서 이미 말했어요. 'almost the same'(거의 같은)이 단서예요.",
 "3) 첫 문장 확인: «Mia checks her homework once more before giving it to her teacher.»(미아는 숙제를 선생님께 내기 전에 한 번 더 살펴본다.) 실수를 미리 고치니 점수가 갑자기 떨어지는 일이 없어요.",
 "4) 묶기: 주마다 거의 같다 = 오르내리지 않는다 = 'steady'(고른, 꾸준한). 'almost the same'을 한 낱말로 바꾼 것이에요."],
 "「짧은」이 끌릴 수 있어요. 실수가 줄었다는 말에서 「줄다」를 떠올리기 쉽거든요. 하지만 빈칸은 점수가 어떤지를 물어요. 점수가 짧다는 말은 쓰지 않아요. 글이 말한 것은 점수가 주마다 거의 같다는 것이에요.",
 [("시끄러운", "지문에 없는 이야기예요. 점수는 소리를 내지 않아요. 글은 점수가 주마다 거의 같다고 했어요."),
  ("값비싼", "지문에 없는 이야기예요. 돈이 드는 일은 나오지 않아요."),
  ("이상한", "글과 맞지 않아요. 점수가 주마다 거의 같다고 했으니 이상한 점이 없어요."),
  ("고른", "셋째 문장 «This year her homework scores are almost the same every week.»가 근거예요. 점수가 주마다 거의 같다는 것은 점수가 고르다는 뜻이에요."),
  ("짧은", "점수에는 쓰지 않는 말이에요. 글이 말한 것은 점수의 길이가 아니라 점수가 주마다 거의 같다는 것이에요.")])

# ---------- 3번째: 컵과 접시를 싸는 부드러운 종이 (답 safe) ----------
rw(2, 3, "A small shop sends cups and plates to customers in boxes. The workers now put soft paper around every cup and plate. Since last month, no cup has broken on the way. Inside the soft paper, every cup and plate is ______ in the box.",
 "작은 가게가 컵과 접시를 상자에 담아 손님에게 보낸다. 직원들은 이제 컵과 접시마다 부드러운 종이를 두른다. 지난달부터 가는 길에 깨진 컵이 없다. 부드러운 종이 안에서 컵과 접시는 모두 상자 속에서 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Inside the soft paper, every cup and plate is»(부드러운 종이 안에서 모든 컵과 접시는 ~하다). 종이로 싼 컵과 접시가 상자 속에서 어떤지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Since last month, no cup has broken on the way.»(지난달부터 가는 길에 깨진 컵이 없다.) 종이로 싼 뒤의 결과를 바로 앞에서 이미 말했어요. 'no cup has broken'(어떤 컵도 깨지지 않았다)이 단서예요.",
 "3) 둘째 문장 확인: «The workers now put soft paper around every cup and plate.»(직원들은 이제 컵과 접시마다 부드러운 종이를 두른다.) 부드러운 종이가 컵과 접시를 지켜 줘요.",
 "4) 묶기: 하나도 깨지지 않는다 = 'safe'(안전한). 'no cup has broken'을 한 낱말로 바꾼 것이에요."],
 "「무거운」이 끌릴 수 있어요. 종이를 더 넣으면 상자가 무거워질 것 같거든요. 하지만 무게는 글에 나오지 않아요. 글이 말한 것은 컵이 하나도 깨지지 않았다는 것이에요.",
 [("시끄러운", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("값싼", "지문에 없는 이야기예요. 컵과 접시의 값은 나오지 않아요."),
  ("알록달록한", "지문에 없는 이야기예요. 컵과 접시의 빛깔은 나오지 않아요."),
  ("안전한", "셋째 문장 «Since last month, no cup has broken on the way.»가 근거예요. 가는 길에 하나도 깨지지 않았다는 것은 컵과 접시가 안전하다는 뜻이에요."),
  ("무거운", "지문에 없는 이야기예요. 무게는 나오지 않아요. 글이 말한 것은 컵이 하나도 깨지지 않았다는 것이에요.")],
 ch={3: 'safe'})

# ---------- 4번째: 십 분 일찍 나서는 벤 (답 late) ----------
rw(3, 4, "Ben leaves his house ten minutes early every school day. He walks slowly and still reaches the gate before the bell. His teacher always sees him in his seat at nine o'clock. Thanks to this habit, Ben is never ______ for class.",
 "벤은 학교 가는 날마다 집에서 십 분 일찍 나선다. 그는 천천히 걷고도 종이 울리기 전에 교문에 닿는다. 선생님은 아홉 시에 늘 자리에 앉아 있는 그를 본다. 이 습관 덕분에 벤은 수업에 ______ 일이 한 번도 없다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to this habit, Ben is never»(이 습관 덕분에 벤은 한 번도 ~하지 않다). 'never'(한 번도 ~않다)가 있어요. 벤에게 없는 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «He walks slowly and still reaches the gate before the bell.»(그는 천천히 걷고도 종이 울리기 전에 교문에 닿는다.) 'before the bell'(종이 울리기 전에)이 단서예요. 늘 종보다 먼저 와요.",
 "3) 셋째 문장 확인: «His teacher always sees him in his seat at nine o'clock.»(선생님은 아홉 시에 늘 자리에 앉아 있는 그를 본다.) 수업이 시작될 때 벤은 이미 자리에 있어요.",
 "4) 묶기: 늘 종이 울리기 전에 온다 = 'late'(늦은)인 일이 없다. 'before the bell'을 뒤집어 말한 것이에요."],
 "「피곤한」이 끌릴 수 있어요. 천천히 걸으니 피곤하지 않을 것 같거든요. 하지만 벤이 피곤한지는 글에 나오지 않아요. 글이 두 번이나 말한 것은 벤이 제시간에 와 있다는 것이에요.",
 [("피곤한", "지문에 없는 이야기예요. 벤이 피곤한지는 나오지 않아요. 글이 말한 것은 벤이 종이 울리기 전에 온다는 것이에요."),
  ("배고픈", "지문에 없는 이야기예요. 먹는 이야기는 나오지 않아요."),
  ("행복한", "빈칸에 넣으면 벤이 행복한 일이 한 번도 없다는 말이 돼요. 그런 이야기는 글에 없어요."),
  ("바쁜", "지문에 없는 이야기예요. 벤은 오히려 천천히 걸어요."),
  ("늦은", "둘째 문장 «He walks slowly and still reaches the gate before the bell.»이 근거예요. 늘 종이 울리기 전에 오니 수업에 늦는 일이 없어요.")])

# ---------- 5번째: 문 옆에 놓은 새 책 (답 often) ----------
rw(4, 1, "The school library puts its new books on a table by the door. Every student sees these books first on the way in. Many students pick one up and take it home the same day. For this reason, the new books are borrowed much more ______ than before.",
 "학교 도서관은 새 책을 문 옆의 탁자에 놓는다. 학생들은 누구나 들어오는 길에 이 책들을 가장 먼저 본다. 많은 학생이 한 권을 집어 그날로 집에 가져간다. 이런 까닭으로 새 책은 전보다 훨씬 더 ______ 빌려 간다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the new books are borrowed much more»(새 책들은 훨씬 더 ~ 빌려진다). 'borrowed'는 「빌려지는」이에요. 새 책을 어떻게 빌려 가는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Many students pick one up and take it home the same day.»(많은 학생이 한 권을 집어 그날로 집에 가져간다.) 'Many students'(많은 학생)가 단서예요. 빌려 가는 학생이 많아요.",
 "3) 둘째 문장 확인: «Every student sees these books first on the way in.»(학생들은 누구나 들어오는 길에 이 책들을 가장 먼저 본다.) 문 옆에 있어서 모두의 눈에 띄어요.",
 "4) 묶기: 많은 학생이 가져간다 = 빌려 가는 일이 잦다 = 'often'(자주). 'Many students'를 「자주」로 바꾸어 말한 것이에요."],
 "「조심스럽게」가 끌릴 수 있어요. 새 책은 아껴서 볼 것 같거든요. 하지만 책을 어떻게 다루는지는 글에 나오지 않아요. 글이 말한 것은 많은 학생이 그 책을 가져간다는 것이에요.",
 [("천천히", "글과 반대예요. 학생들은 책을 집어 그날로 집에 가져가요."),
  ("자주", "셋째 문장 «Many students pick one up and take it home the same day.»가 근거예요. 많은 학생이 가져가니 새 책을 빌려 가는 일이 훨씬 잦아요."),
  ("조용히", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("싸게", "지문에 없는 이야기예요. 도서관에서 책을 빌리는 데 드는 돈은 나오지 않아요."),
  ("조심스럽게", "지문에 없는 이야기예요. 책을 어떻게 다루는지는 나오지 않아요. 글이 말한 것은 많은 학생이 책을 가져간다는 것이에요.")])

# ---------- 6번째: 할 일을 적는 공책 (답 forgets) ----------
rw(5, 2, "Ana carries a small notebook in her pocket all day. She writes down every new task in it right away. With one look at the list, she remembers every task. Thanks to this little notebook, Ana rarely ______ anything important these days.",
 "아나는 하루 종일 주머니에 작은 공책을 넣고 다닌다. 그녀는 새로 생긴 할 일을 모두 곧바로 거기에 적는다. 그 목록을 한 번만 보면 그녀는 할 일을 모두 기억해 낸다. 이 작은 공책 덕분에 아나는 요즘 중요한 것을 ______ 일이 드물다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to this little notebook, Ana rarely»(이 작은 공책 덕분에 아나는 드물게 ~한다). 'rarely'는 「거의 ~않다」예요. 아나가 요즘 거의 하지 않는 일을 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «With one look at the list, she remembers every task.»(그 목록을 한 번만 보면 그녀는 할 일을 모두 기억해 낸다.) 'remembers every task'(모든 할 일을 기억한다)가 단서예요. 'task'는 할 일이에요.",
 "3) 둘째 문장 확인: «She writes down every new task in it right away.»(그녀는 새로 생긴 할 일을 모두 곧바로 거기에 적는다.) 적어 두니 나중에 다시 볼 수 있어요.",
 "4) 묶기: 모두 기억한다 = 'forgets'(잊는다)인 일이 드물다. 'remembers'를 뒤집어 말한 것이에요."],
 "「잃어버린다」가 가장 끌려요. 「잊다」와 「잃다」는 우리말로도 비슷하게 들리거든요. 하지만 물건을 잃어버리는 이야기는 글에 나오지 않아요. 글이 말한 것은 할 일을 기억한다는 것이에요.",
 [("잃어버린다", "지문에 없는 이야기예요. 물건을 잃어버리는 일은 나오지 않아요. 글이 말한 것은 할 일을 기억한다는 것이에요."),
  ("쓴다", "지문에 없는 이야기예요. 돈이나 시간을 쓰는 일은 나오지 않아요."),
  ("잊는다", "셋째 문장 «With one look at the list, she remembers every task.»가 근거예요. 할 일을 모두 기억하니 잊는 일이 드물어요."),
  ("읽는다", "글과 맞지 않아요. 아나는 공책의 목록을 들여다봐요. 읽는 일이 드물지 않아요."),
  ("옮긴다", "지문에 없는 이야기예요. 무엇을 옮기는 일은 나오지 않아요.")])

# ---------- 7번째: 복도마다 건 시계 (답 common) ----------
rw(6, 1, "The school put a big clock on the wall in every hall. Students can now see the time on their way to class. Last month only two students came late to their classes. With the new clocks on the walls, coming late has become much less ______.",
 "학교가 복도마다 벽에 큰 시계를 걸었다. 학생들은 이제 교실로 가는 길에 시간을 볼 수 있다. 지난달에는 두 학생만 수업에 늦게 왔다. 벽에 새 시계가 걸린 뒤로 늦게 오는 일은 훨씬 덜 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «coming late has become much less»(늦게 오는 일은 훨씬 덜 ~해졌다). 'less'(덜)가 있어요. 늦게 오는 일이 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Last month only two students came late to their classes.»(지난달에는 두 학생만 수업에 늦게 왔다.) 'only two students'(두 학생만)가 단서예요. 늦는 학생이 아주 적어요.",
 "3) 둘째 문장 확인: «Students can now see the time on their way to class.»(학생들은 이제 교실로 가는 길에 시간을 볼 수 있다.) 시간을 보고 걸음을 서두를 수 있어요.",
 "4) 묶기: 늦는 학생이 둘뿐이다 = 늦는 일이 덜 'common'(흔한)하다. 'only two students'를 「덜 흔하다」로 바꾸어 말한 것이에요."],
 "「쓸모 있는」이 끌릴 수 있어요. 시계가 쓸모 있다는 생각이 들거든요. 하지만 빈칸 앞의 말은 시계가 아니라 늦게 오는 일이에요. 늦게 오는 일이 얼마나 있는지를 말해야 해요.",
 [("쓸모 있는", "빈칸 앞의 말은 시계가 아니라 늦게 오는 일이에요. 늦게 오는 일이 쓸모 있다는 이야기는 글에 없어요."),
  ("흔한", "셋째 문장 «Last month only two students came late to their classes.»가 근거예요. 늦은 학생이 둘뿐이니 늦게 오는 일이 훨씬 덜 흔해졌어요."),
  ("값비싼", "지문에 없는 이야기예요. 돈이 드는 일은 나오지 않아요."),
  ("시끄러운", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("조심스러운", "지문에 없는 이야기예요. 글이 말한 것은 늦는 학생의 수예요.")])

# ---------- 8번째: 문 밖에 내건 차림표 (답 quickly) ----------
rw(7, 4, "A small café put its menu on a board outside the door. People in the line read the menu before their turn. At the counter, each person now orders in a few seconds. With the menu outside, the morning line now moves much more ______.",
 "작은 카페가 문 밖 판에 차림표를 내걸었다. 줄을 선 사람들은 자기 차례가 오기 전에 차림표를 읽는다. 계산대에서 이제 사람마다 몇 초 만에 주문한다. 차림표가 밖에 있어서 아침의 줄은 이제 훨씬 더 ______ 움직인다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the morning line now moves much more»(아침의 줄은 이제 훨씬 더 ~ 움직인다). 'line'은 사람들이 선 줄이에요. 줄이 어떻게 움직이는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «At the counter, each person now orders in a few seconds.»(계산대에서 이제 사람마다 몇 초 만에 주문한다.) 'in a few seconds'(몇 초 만에)가 단서예요. 주문이 금방 끝나요.",
 "3) 둘째 문장 확인: «People in the line read the menu before their turn.»(줄을 선 사람들은 자기 차례가 오기 전에 차림표를 읽는다.) 미리 읽어 두니 계산대에서 고르느라 머뭇거리지 않아요.",
 "4) 묶기: 사람마다 몇 초 만에 주문한다 = 줄이 'quickly'(빨리) 움직인다. 'in a few seconds'를 한 낱말로 바꾼 것이에요."],
 "「조용히」가 끌릴 수 있어요. 사람들이 차림표를 읽고 있으니 줄이 조용할 것 같거든요. 하지만 소리는 글에 나오지 않아요. 글이 말한 것은 주문이 몇 초 만에 끝난다는 것이에요.",
 [("천천히", "글과 반대예요. 사람마다 몇 초 만에 주문하니 줄은 느려지지 않아요."),
  ("시끄럽게", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("이상하게", "지문에 없는 이야기예요. 줄이 이상하게 움직인다는 말은 없어요."),
  ("조용히", "지문에 없는 이야기예요. 소리는 나오지 않아요. 글이 말한 것은 주문에 걸리는 시간이에요."),
  ("빨리", "셋째 문장 «At the counter, each person now orders in a few seconds.»가 근거예요. 사람마다 몇 초 만에 주문하니 줄이 훨씬 빨리 움직여요.")])

# ---------- 9번째: 계단으로 다니는 샘 (답 stronger) ----------
rw(8, 4, "Sam's classroom is on the fourth floor of the school. He takes the stairs every day instead of the elevator. Now he climbs all four floors without a single rest. After three months on the stairs, his legs have grown much ______.",
 "샘의 교실은 학교 사 층에 있다. 그는 날마다 승강기 대신 계단으로 다닌다. 이제 그는 한 번도 쉬지 않고 네 층을 모두 올라간다. 석 달 동안 계단을 다닌 뒤 그의 다리는 훨씬 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «his legs have grown much»(그의 다리는 훨씬 ~해졌다). 샘의 다리가 어떻게 달라졌는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now he climbs all four floors without a single rest.»(이제 그는 한 번도 쉬지 않고 네 층을 모두 올라간다.) 'without a single rest'(한 번도 쉬지 않고)가 단서예요. 다리에 힘이 붙었어요.",
 "3) 둘째 문장 확인: «He takes the stairs every day instead of the elevator.»(그는 날마다 승강기 대신 계단으로 다닌다.) 'stairs'는 계단이에요. 날마다 사 층까지 걸어 올라가요.",
 "4) 묶기: 쉬지 않고 네 층을 오른다 = 다리가 'stronger'(더 튼튼한)해졌다. 'without a single rest'를 한 낱말로 바꾼 것이에요."],
 "「더 가벼운」이 끌릴 수 있어요. 운동을 하면 몸이 가벼워진다고들 하거든요. 하지만 다리의 무게는 글에 나오지 않아요. 글이 말한 것은 쉬지 않고 사 층까지 오른다는 것, 곧 다리의 힘이에요.",
 [("더 짧은", "지문에 없는 이야기예요. 계단을 다닌다고 다리가 짧아지지는 않아요."),
  ("더 부드러운", "지문에 없는 이야기예요. 다리가 부드러워졌다는 말은 없어요."),
  ("더 가벼운", "지문에 없는 이야기예요. 다리의 무게는 나오지 않아요. 글이 말한 것은 쉬지 않고 오르는 힘이에요."),
  ("더 시끄러운", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("더 튼튼한", "셋째 문장 «Now he climbs all four floors without a single rest.»가 근거예요. 한 번도 쉬지 않고 네 층을 오르니 다리가 훨씬 튼튼해진 것이에요.")])

# ---------- 10번째: 어두운 길에 단 불 (답 unsafe) ----------
rw(9, 1, "The path behind the school was very dark in the evening. Many students were afraid of the path after their evening lessons. Last week the school put bright lights along the whole path. Students now walk along the path in the evening without feeling ______.",
 "학교 뒤의 길은 저녁에 아주 어두웠다. 많은 학생이 저녁 수업 뒤에 그 길을 무서워했다. 지난주에 학교가 그 길 내내 밝은 등을 달았다. 학생들은 이제 저녁에도 ______ 느끼지 않고 그 길을 걷는다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Students now walk along the path in the evening without feeling»(학생들은 이제 저녁에 ~하다고 느끼지 않고 그 길을 걷는다). 'without'(~없이)이 있어요. 이제는 느끼지 않는 것이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Many students were afraid of the path after their evening lessons.»(많은 학생이 저녁 수업 뒤에 그 길을 무서워했다.) 'afraid'(무서워하는)가 단서예요. 전에는 무서움을 느꼈어요.",
 "3) 셋째 문장 확인: «Last week the school put bright lights along the whole path.»(지난주에 학교가 그 길 내내 밝은 등을 달았다.) 길이 밝아져서 무서울 까닭이 없어졌어요.",
 "4) 묶기: 전에 느끼던 무서움이 사라졌다 = 'unsafe'(안전하지 않은)하다고 느끼지 않는다. 'afraid'를 다른 낱말로 바꾼 것이에요."],
 "「피곤한」이 끌릴 수 있어요. 저녁 수업 뒤라서 피곤할 것 같거든요. 하지만 등을 단다고 피곤이 풀리지는 않아요. 등이 바꾼 것은 어두운 길에서 느끼던 무서움이에요.",
 [("지루한", "지문에 없는 이야기예요. 길이 지루하다는 말은 없어요."),
  ("안전하지 않은", "둘째 문장 «Many students were afraid of the path after their evening lessons.»가 근거예요. 어두워서 무서워하던 길이 밝아졌으니, 이제는 안전하지 않다고 느끼지 않아요."),
  ("배고픈", "지문에 없는 이야기예요. 먹는 이야기는 나오지 않아요."),
  ("따뜻한", "지문에 없는 이야기예요. 등이 길을 밝힌다고만 했고 따뜻함은 나오지 않아요."),
  ("피곤한", "지문에 없는 이야기예요. 저녁 수업 뒤라서 떠올리기 쉽지만, 등이 바꾼 것은 피곤이 아니라 무서움이에요.")])

# ---------- 11번째: 자기 전의 책 읽기 (답 easily) ----------
rw(10, 2, "Lena reads a paper book in bed for twenty minutes every night. Her phone stays on a desk in the living room all night. After a few quiet pages, her eyes begin to close by themselves. Thanks to her bedtime reading, Lena now falls asleep much more ______.",
 "레나는 밤마다 침대에서 이십 분 동안 종이책을 읽는다. 그녀의 전화기는 밤새 거실 책상 위에 있다. 조용히 몇 쪽을 읽고 나면 그녀의 눈이 저절로 감기기 시작한다. 자기 전의 책 읽기 덕분에 레나는 이제 훨씬 더 ______ 잠든다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Lena now falls asleep much more»(레나는 이제 훨씬 더 ~ 잠든다). 'falls asleep'은 「잠든다」예요. 레나가 어떻게 잠드는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «After a few quiet pages, her eyes begin to close by themselves.»(조용히 몇 쪽을 읽고 나면 그녀의 눈이 저절로 감기기 시작한다.) 'by themselves'(저절로)가 단서예요. 애쓰지 않아도 눈이 감겨요.",
 "3) 첫 문장 확인: «Lena reads a paper book in bed for twenty minutes every night.»(레나는 밤마다 침대에서 이십 분 동안 종이책을 읽는다.) 이 책 읽기가 잠을 불러요.",
 "4) 묶기: 눈이 저절로 감긴다 = 'easily'(쉽게) 잠든다. 'by themselves'를 한 낱말로 바꾼 것이에요."],
 "「천천히」가 끌릴 수 있어요. 이십 분 동안 책을 읽으니 잠드는 데 시간이 걸릴 것 같거든요. 하지만 글은 몇 쪽만 읽어도 눈이 저절로 감긴다고 했어요. 잠이 더디게 오는 것이 아니에요.",
 [("시끄럽게", "지문에 없는 이야기예요. 레나는 조용히 책을 읽어요."),
  ("천천히", "글과 반대예요. 몇 쪽만 읽어도 눈이 저절로 감긴다고 했어요."),
  ("쉽게", "셋째 문장 «After a few quiet pages, her eyes begin to close by themselves.»가 근거예요. 눈이 저절로 감기니 훨씬 쉽게 잠들어요."),
  ("드물게", "글과 맞지 않아요. 레나는 밤마다 책을 읽고 잠들어요. 잠드는 일이 드물지 않아요."),
  ("화를 내며", "지문에 없는 이야기예요. 화가 나는 일은 나오지 않아요.")])

# ---------- 12번째: 문 앞으로 옮긴 장바구니 (답 more) ----------
rw(11, 1, "A supermarket moved its shopping baskets to the front door. Almost every customer now picks up a basket on the way in. A basket can hold many more things than two hands. With a basket in hand, customers now buy ______ than before.",
 "슈퍼마켓이 장바구니를 앞문 쪽으로 옮겼다. 이제 거의 모든 손님이 들어오는 길에 바구니를 집어 든다. 바구니는 두 손보다 훨씬 많은 물건을 담을 수 있다. 바구니를 손에 든 손님들은 이제 전보다 ______ 산다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With a basket in hand, customers now buy»(바구니를 손에 들고 손님들은 이제 ~ 산다). 뒤에 'than before'(전보다)가 있어요. 손님이 사는 양이 전과 어떻게 다른지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «A basket can hold many more things than two hands.»(바구니는 두 손보다 훨씬 많은 물건을 담을 수 있다.) 'many more things'(훨씬 많은 물건)가 단서예요.",
 "3) 둘째 문장 확인: «Almost every customer now picks up a basket on the way in.»(이제 거의 모든 손님이 들어오는 길에 바구니를 집어 든다.) 거의 모두가 바구니를 들고 물건을 골라요.",
 "4) 묶기: 바구니에는 더 많이 담긴다 = 손님이 'more'(더 많이) 산다. 셋째 문장의 낱말이 그대로 답이에요."],
 "「더 싸게」가 끌릴 수 있어요. 가게 이야기라서 값을 떠올리기 쉽거든요. 하지만 값은 글에 나오지 않아요. 글이 말한 것은 바구니에 담기는 물건의 양이에요.",
 [("더 적게", "글과 반대예요. 바구니에는 두 손보다 훨씬 많은 물건이 담겨요."),
  ("더 많이", "셋째 문장 «A basket can hold many more things than two hands.»가 근거예요. 바구니에 더 많이 담을 수 있으니 손님이 전보다 더 많이 사요."),
  ("더 느리게", "지문에 없는 이야기예요. 물건을 사는 빠르기는 나오지 않아요."),
  ("더 늦게", "지문에 없는 이야기예요. 물건을 사는 때는 나오지 않아요."),
  ("더 싸게", "지문에 없는 이야기예요. 물건의 값은 나오지 않아요. 글이 말한 것은 담기는 양이에요.")])

# ---------- 13번째: 날마다 십 분씩 치는 기타 (답 smooth) ----------
rw(12, 0, "Jun practises the guitar for ten minutes every day after dinner. In the first week, his fingers stopped between the notes. Now his fingers move from one note to the next without stopping. After a month of daily practice, his playing sounds very ______.",
 "준은 날마다 저녁을 먹은 뒤 십 분 동안 기타를 연습한다. 첫 주에는 그의 손가락이 음과 음 사이에서 멈추었다. 이제 그의 손가락은 멈추지 않고 한 음에서 다음 음으로 움직인다. 한 달 동안 날마다 연습한 뒤 그의 연주는 아주 ______ 들린다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «his playing sounds very»(그의 연주는 아주 ~하게 들린다). 준의 연주가 어떻게 들리는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now his fingers move from one note to the next without stopping.»(이제 그의 손가락은 멈추지 않고 한 음에서 다음 음으로 움직인다.) 'without stopping'(멈추지 않고)이 단서예요. 음이 끊기지 않고 이어져요.",
 "3) 둘째 문장 확인: «In the first week, his fingers stopped between the notes.»(첫 주에는 그의 손가락이 음과 음 사이에서 멈추었다.) 처음에는 뚝뚝 끊겼어요. 지금은 그 반대예요.",
 "4) 묶기: 멈추지 않고 음이 이어진다 = 'smooth'(매끄러운)하게 들린다. 'without stopping'을 한 낱말로 바꾼 것이에요."],
 "「짧은」이 끌릴 수 있어요. 첫 문장의 'ten minutes'(십 분)에서 짧다는 생각이 들거든요. 하지만 짧은 것은 연습 시간이에요. 빈칸은 연주가 어떻게 들리는지를 물어요. 「큰」도 조심해요. 소리가 얼마나 큰지는 글에 나오지 않아요.",
 [("매끄러운", "셋째 문장 «Now his fingers move from one note to the next without stopping.»이 근거예요. 손가락이 멈추지 않으니 연주가 끊기지 않고 매끄럽게 들려요."),
  ("소리가 큰", "지문에 없는 이야기예요. 소리가 얼마나 큰지는 나오지 않아요. 글이 말한 것은 음이 끊기지 않는다는 것이에요."),
  ("값싼", "지문에 없는 이야기예요. 돈 이야기는 나오지 않아요."),
  ("짧은", "첫 문장의 십 분에서 떠올린 것이에요. 짧은 것은 날마다 하는 연습 시간이에요. 연주가 어떻게 들리는지와는 달라요."),
  ("무거운", "지문에 없는 이야기예요. 무게는 나오지 않아요.")],
 ch={1: 'loud', 2: 'cheap', 3: 'short', 4: 'heavy'})

# ---------- 14번째: 구운 시간을 적은 빵집 (답 well) ----------
rw(13, 0, "A bakery writes the baking time on a card next to its bread. In the afternoon, customers can find the freshest bread with one look. By five o'clock, the shelves of the bakery are almost empty. Thanks to the little cards, the bakery's bread now sells very ______.",
 "빵집이 빵 옆의 카드에 구운 시간을 적는다. 오후에 손님들은 가장 갓 구운 빵을 한눈에 찾을 수 있다. 다섯 시가 되면 빵집의 선반이 거의 빈다. 작은 카드 덕분에 이 빵집의 빵은 이제 아주 ______ 팔린다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the bakery's bread now sells very»(그 빵집의 빵은 이제 아주 ~ 팔린다). 'sells'는 「팔린다」예요. 빵이 어떻게 팔리는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «By five o'clock, the shelves of the bakery are almost empty.»(다섯 시가 되면 빵집의 선반이 거의 빈다.) 'almost empty'(거의 빈)가 단서예요. 빵이 거의 다 나갔어요.",
 "3) 둘째 문장 확인: «In the afternoon, customers can find the freshest bread with one look.»(오후에 손님들은 가장 갓 구운 빵을 한눈에 찾을 수 있다.) 언제 구웠는지 보이니 마음 놓고 사요.",
 "4) 묶기: 선반이 거의 빈다 = 빵이 'well'(잘) 팔린다. 'almost empty'를 「잘 팔린다」로 바꾸어 말한 것이에요."],
 "「늦게」가 끌릴 수 있어요. 오후와 다섯 시라는 말에서 늦은 시간을 떠올리기 쉽거든요. 하지만 빈칸은 빵이 언제 팔리는지가 아니라 얼마나 팔리는지를 물어요. 선반이 거의 비었다는 것이 답을 알려 줘요.",
 [("잘", "셋째 문장 «By five o'clock, the shelves of the bakery are almost empty.»가 근거예요. 다섯 시에 선반이 거의 비니 빵이 아주 잘 팔리는 것이에요."),
  ("나쁘게", "글과 반대예요. 선반이 거의 빈다고 했으니 빵은 안 팔리는 것이 아니에요."),
  ("천천히", "글과 반대예요. 다섯 시가 되면 벌써 선반이 거의 비어요."),
  ("드물게", "글과 반대예요. 빵이 드물게 팔리면 선반이 빌 수 없어요."),
  ("늦게", "빈칸은 언제 팔리는지를 묻지 않아요. 선반이 거의 빈다는 것은 빵이 얼마나 팔리는지를 말해요.")])

# ---------- 15번째: 문 옆의 열쇠 고리 (답 losing) ----------
rw(14, 3, "Nina looked for her keys for ten minutes almost every morning. Last month she put a small hook on the wall by the door. Now her keys hang in the same place every single day. With the help of the hook, Nina has stopped ______ her keys.",
 "니나는 거의 아침마다 십 분씩 열쇠를 찾았다. 지난달에 그녀는 문 옆의 벽에 작은 고리를 달았다. 이제 그녀의 열쇠는 하루도 빠짐없이 같은 자리에 걸려 있다. 고리의 도움으로 니나는 열쇠를 ______ 일을 그만두었다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With the help of the hook, Nina has stopped»(고리의 도움으로 니나는 ~하기를 그만두었다). 'has stopped'는 「그만두었다」예요. 니나가 이제 하지 않는 일을 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now her keys hang in the same place every single day.»(이제 그녀의 열쇠는 하루도 빠짐없이 같은 자리에 걸려 있다.) 'in the same place'(같은 자리에)가 단서예요. 열쇠가 어디 있는지 늘 알아요.",
 "3) 첫 문장 확인: «Nina looked for her keys for ten minutes almost every morning.»(니나는 거의 아침마다 십 분씩 열쇠를 찾았다.) 'looked for'는 「찾았다」예요. 전에는 열쇠가 어디 있는지 몰랐어요.",
 "4) 묶기: 열쇠가 늘 같은 자리에 있다 = 'losing'(잃어버리기)을 그만두었다. 'in the same place'를 뒤집어 말한 것이에요."],
 "「숨기기」가 끌릴 수 있어요. 열쇠를 어디 두었는지 모르는 것이 숨긴 것과 비슷해 보이거든요. 하지만 니나가 열쇠를 일부러 숨겼다는 말은 글에 없어요. 둔 곳을 몰라서 찾아다녔을 뿐이에요.",
 [("사기", "지문에 없는 이야기예요. 열쇠를 사는 일은 나오지 않아요."),
  ("닦기", "지문에 없는 이야기예요. 열쇠를 닦는 일은 나오지 않아요."),
  ("세기", "지문에 없는 이야기예요. 열쇠의 수를 세는 일은 나오지 않아요."),
  ("잃어버리기", "셋째 문장 «Now her keys hang in the same place every single day.»가 근거예요. 열쇠가 늘 같은 자리에 있으니 잃어버리는 일을 그만두었어요."),
  ("숨기기", "지문에 없는 이야기예요. 니나가 열쇠를 일부러 숨겼다는 말은 없어요. 둔 곳을 몰라서 찾았을 뿐이에요.")])
