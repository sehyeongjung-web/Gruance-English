# -*- coding: utf-8 -*-
# 322번: 33번(빈칸 추론 — 구) 레벨1 — 레벨1 기준으로 다시 씀 (앞 절반: 1~15번째)
# 꼴은 31번·32번 레벨1과 같음: 네 문장 · 모두 단문 · 문장당 10~15낱말 · 빈칸은 넷째 문장
# 짝꿍 문장: 셋째 열 문항 · 둘째 네 문항(2·5·6·13번째) · 첫째 한 문항(11번째)
# 생각의 단계(추론축 레벨1): 글에 있는 말 하나를 그대로 확인 — 짝꿍 문장의 말을 다른 말로 바꾼 것이 답
#   (easier to understand ← gets the meaning quickly · saves an hour ← one hour, not two · without worrying ← without any fear ·
#    rarely too cold or too warm ← almost always warm enough or cool enough · hungry before lunch ← stomach stays quiet until the lunch bell ·
#    grows straight instead of leaning ← stands up like a pencil, does not bend · waiting in the cold ← stands at the stop on winter mornings ·
#    forgets far fewer ← forgot almost every day / forgotten only one(이 문항만 같은 낱말) · ready to use ← completely green ·
#    never left in the dark ← light works from the first night to the last · tripping ← falls / fell over a bag ·
#    never forgets a book ← the right book is always on her desk · mind on the page ← no message pulls his eyes away ·
#    wake up properly ← does not feel sleepy any more · still has battery left ← never turns off)
# 글감(버릇 → 좋은 결과)·정답 번호·정답 구는 그대로. **12번째만 정답 구를 고침**: means she never forgets one → never forgets a book
#   (means 뒤에 절이 와서 레벨1의 「단문만」에 맞지 않음. 뜻은 같음. 빈칸 문장의 주어를 Mila로 바꾸어 구만 남김)
# 선택지: 옛 오답은 거의 모두 나쁜 결과(takes her longer · makes her feel sick · needs twice as much water)여서 좋은 결과 하나만 고르면 답이었음.
#   → 오답도 「같은 버릇에서 나올 법한 다른 좋은 결과」로 다시 씀. 글이 말한 것은 하나뿐. 문항마다 하나는 글의 낱말을 비튼 것(끌리는 오답)
# 낱말: torch → flashlight · marks → scores (LEVEL_GUIDE의 낱말 규칙). 철자는 영국식 그대로(towards)
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '33', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, c5, ko, steps, traps, cn):
    """문항을 통째로 다시 씀: 지문·선택지·해석·풀이·해설. 정답 번호는 그대로. c5 = 새 선택지 다섯"""
    old = list(_tb[T][LV][n]['choices']); ch = {k: v for k, v in enumerate(c5) if v != old[k]}
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=ans in ch); e = E.pop((T, LV, n))
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(c5)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': list(c5), 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 1번째: 학교가 끝나자마자 하는 숙제 (답 makes it easier to understand) ----------
rw(0, 2, "Maria starts her homework at her desk right after school every day. At that time, the lessons of the day are still fresh in her head. She gets the meaning of every question quickly but still needs a full hour. For Maria, this early start on her homework ______.",
 ["makes it quicker to finish", "leaves her more time to play", "makes it easier to understand", "makes it more fun to do", "helps her go to bed earlier"],
 "마리아는 날마다 학교가 끝나자마자 책상에서 숙제를 시작한다. 그때는 그날 배운 것이 아직 머릿속에 생생하다. 문제마다 뜻을 금방 알아차리지만, 여전히 꼬박 한 시간이 걸린다. 마리아에게, 숙제를 이렇게 일찍 시작하는 것은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this early start on her homework»(숙제를 이렇게 일찍 시작하는 것). 일찍 시작하면 숙제가 어떻게 되는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «She gets the meaning of every question quickly»(문제마다 뜻을 금방 알아차린다). 'gets the meaning'(뜻을 알아차린다)이 단서예요.",
 "3) 둘째 문장 확인: «the lessons of the day are still fresh in her head»(그날 배운 것이 아직 머릿속에 생생하다). 뜻을 금방 알아차리는 까닭이에요.",
 "4) 묶기: 문제의 뜻을 금방 알아차린다 = 'makes it easier to understand'(숙제를 이해하기 더 쉽게 해 준다). 여기서 'it'은 숙제예요."],
 "「숙제를 더 빨리 끝내게 해 준다」가 끌릴 수 있어요. 셋째 문장에 'quickly'(금방)가 있거든요. 하지만 금방 하는 것은 문제의 뜻을 알아차리는 일이에요. 숙제는 여전히 꼬박 한 시간이 걸린다고 했어요.",
 [("숙제를 더 빨리 끝내게 해 준다", "글과 맞지 않아요. 셋째 문장에서 숙제는 여전히 꼬박 한 시간이 걸린다고 했어요. 'quickly'(금방)는 문제의 뜻을 알아차리는 데 붙은 말이에요."),
  ("놀 시간을 더 많이 남겨 준다", "지문에 없는 이야기예요. 노는 시간은 나오지 않아요."),
  ("숙제를 이해하기 더 쉽게 해 준다", "셋째 문장 «She gets the meaning of every question quickly»가 근거예요. 문제의 뜻을 금방 알아차리니, 숙제를 이해하기가 더 쉬운 것이에요."),
  ("숙제를 하기 더 재미있게 해 준다", "지문에 없는 이야기예요. 숙제가 재미있다는 말은 나오지 않아요."),
  ("더 일찍 잠자리에 들도록 도와준다", "지문에 없는 이야기예요. 잠자는 시간은 나오지 않아요.")])

# ---------- 2번째: 버스에서 다시 읽는 공책 (답 saves an hour before the test) ----------
rw(1, 0, "Nina reads her class notes again during the ten-minute bus ride home. Before the test each month, she now studies her notes for one hour, not two. The words from each lesson stay clear in her head for weeks. For Nina, this short reading time on the bus ______.",
 ["saves an hour before the test", "makes the ride feel shorter", "gets her homework done early", "keeps her awake on the bus", "saves an hour every evening"],
 "니나는 집으로 가는 버스를 타는 십 분 동안 수업 공책을 다시 읽는다. 달마다 있는 시험 전에, 니나는 이제 공책으로 두 시간이 아니라 한 시간 공부한다. 수업마다 배운 말이 몇 주 동안 머릿속에 또렷이 남는다. 니나에게, 버스에서 공책을 읽는 이 짧은 시간은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this short reading time on the bus»(버스에서 공책을 읽는 이 짧은 시간). 이 짧은 시간이 니나에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «she now studies her notes for one hour, not two»(이제 공책으로 두 시간이 아니라 한 시간 공부한다). 'one hour, not two'(두 시간이 아니라 한 시간)가 단서예요.",
 "3) 첫 문장 확인: «Nina reads her class notes again during the ten-minute bus ride home.»(니나는 집으로 가는 버스를 타는 십 분 동안 수업 공책을 다시 읽는다.) 버스에서 십 분씩 다시 읽는 것이 'this short reading time'(공책을 읽는 이 짧은 시간)이에요.",
 "4) 묶기: 두 시간이 한 시간으로 줄었어요. 한 시간을 아낀 것이에요. 그때는 시험 전이에요. 그래서 'saves an hour before the test'(시험 전에 한 시간을 아껴 준다)예요."],
 "「저녁마다 한 시간을 아껴 준다」가 끌릴 수 있어요. 한 시간을 아낀다는 말이 같거든요. 하지만 둘째 문장은 'Before the test each month'(달마다 있는 시험 전에)라고 했어요. 한 시간이 줄어드는 때는 저녁마다가 아니라 시험 전이에요.",
 [("시험 전에 한 시간을 아껴 준다", "둘째 문장 «she now studies her notes for one hour, not two»가 근거예요. 시험 전에 두 시간 하던 공부가 한 시간이 되었으니, 한 시간을 아낀 것이에요."),
  ("버스 타는 시간이 더 짧게 느껴지게 해 준다", "지문에 없는 이야기예요. 버스 타는 시간이 짧게 느껴진다는 말은 나오지 않아요."),
  ("숙제를 일찍 끝내게 해 준다", "지문에 없는 이야기예요. 숙제는 나오지 않아요. 니나가 버스에서 읽는 것은 수업 공책이에요."),
  ("버스에서 깨어 있게 해 준다", "지문에 없는 이야기예요. 버스에서 존다는 말은 나오지 않아요."),
  ("저녁마다 한 시간을 아껴 준다", "때가 달라요. 한 시간이 줄어드는 것은 달마다 있는 시험 전이에요. 저녁마다 그렇다는 말은 없어요.")])

# ---------- 3번째: 재료를 다 적어 두는 빵집 (답 lets them buy without worrying) ----------
rw(2, 2, "A small bakery prints every ingredient on the label of each bag. Some children in the town get very sick from nuts or eggs. Their parents read the label first and then pay without any fear. For these parents, this habit of the bakery ______.",
 ["helps them choose healthier bread", "lets them shop much more quickly", "lets them buy without worrying", "lets their children shop alone", "helps them learn new recipes"],
 "어느 작은 빵집은 봉지마다 붙은 표에, 빵에 들어간 재료를 빠짐없이 찍어 둔다. 이 마을의 어떤 아이들은 견과나 달걀을 먹으면 몹시 아프다. 그 아이들의 부모는 먼저 표를 읽고, 그런 다음 아무 두려움 없이 값을 치른다. 이 부모들에게, 빵집의 이 습관은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this habit of the bakery»(빵집의 이 습관). 재료를 표에 찍어 두는 습관이에요. 이 습관이 부모들에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Their parents read the label first and then pay without any fear.»(그 아이들의 부모는 먼저 표를 읽고, 그런 다음 아무 두려움 없이 값을 치른다.) 'pay without any fear'(아무 두려움 없이 값을 치른다)가 단서예요.",
 "3) 둘째 문장 확인: «Some children in the town get very sick from nuts or eggs.»(이 마을의 어떤 아이들은 견과나 달걀을 먹으면 몹시 아프다.) 부모들이 왜 두려워하는지 알 수 있어요. 아이를 아프게 하는 것이 빵에 들었을까 봐서예요.",
 "4) 묶기: 값을 치른다 = 산다. 두려움 없이 = 걱정 없이. 그래서 'lets them buy without worrying'(걱정 없이 사게 해 준다)이에요."],
 "「몸에 더 좋은 빵을 고르도록 도와준다」가 끌릴 수 있어요. 재료를 보고 빵을 고르는 것은 맞거든요. 하지만 글의 부모들이 살피는 것은 어느 빵이 몸에 더 좋은지가 아니에요. 아이를 아프게 하는 견과나 달걀이 들었는지예요.",
 [("몸에 더 좋은 빵을 고르도록 도와준다", "지문에 없는 이야기예요. 어느 빵이 몸에 더 좋은지는 나오지 않아요. 부모들이 살피는 것은 아이를 아프게 하는 재료가 들었는지예요."),
  ("장을 훨씬 더 빨리 보게 해 준다", "지문에 없는 이야기예요. 부모들은 먼저 표를 읽는다고 했어요. 더 빨리 장을 본다는 말은 없어요."),
  ("걱정 없이 사게 해 준다", "셋째 문장 «Their parents read the label first and then pay without any fear.»가 근거예요. 표를 읽고 두려움 없이 값을 치르니, 걱정 없이 빵을 사는 것이에요."),
  ("아이들이 혼자 장을 보게 해 준다", "지문에 없는 이야기예요. 표를 읽고 값을 치르는 사람은 부모예요. 아이들이 혼자 장을 본다는 말은 나오지 않아요."),
  ("새 요리법을 배우도록 도와준다", "지문에 없는 이야기예요. 요리법을 배운다는 말은 나오지 않아요.")])

# ---------- 4번째: 하늘을 보고 고르는 외투 (답 is rarely too cold or too warm) ----------
rw(3, 1, "Ana looks at the sky and feels the air at her window every morning. She then picks either her thick coat or her thin one. Her coat is almost always warm enough or cool enough for the day. Because of this morning habit, Ana ______.",
 ["is rarely late for school", "is rarely too cold or too warm", "is rarely wet on rainy days", "rarely loses her coat", "rarely catches a cold in winter"],
 "아나는 아침마다 창가에서 하늘을 보고 바깥 공기를 느껴 본다. 그런 다음 두꺼운 외투와 얇은 외투 가운데 하나를 고른다. 아나의 외투는 거의 언제나 그날에 맞게 충분히 따뜻하거나 충분히 시원하다. 이 아침 버릇 덕분에, 아나는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Because of this morning habit»(이 아침 버릇 덕분에). 하늘을 보고 공기를 느껴 본 뒤 외투를 고르는 버릇이에요. 그 덕분에 아나가 어떠한지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Her coat is almost always warm enough or cool enough for the day.»(아나의 외투는 거의 언제나 그날에 맞게 충분히 따뜻하거나 충분히 시원하다.) 'almost always'(거의 언제나)와 'warm enough or cool enough'(충분히 따뜻하거나 충분히 시원한)가 단서예요.",
 "3) 둘째 문장 확인: «She then picks either her thick coat or her thin one.»(그런 다음 두꺼운 외투와 얇은 외투 가운데 하나를 고른다.) 아나가 고르는 것은 외투예요. 둘 가운데 그날에 맞는 것을 골라요.",
 "4) 묶기: 충분히 따뜻하다 = 너무 춥지 않다. 충분히 시원하다 = 너무 덥지 않다. 거의 언제나 그렇다 = 그렇지 않은 날이 드물다. 그래서 'is rarely too cold or too warm'(너무 춥거나 너무 더운 일이 드물다)이에요. 'rarely'는 '드물게, 좀처럼 ~않는'이라는 뜻이에요."],
 "「비 오는 날 젖는 일이 드물다」가 끌릴 수 있어요. 아침에 하늘을 보면 비가 올지도 알 수 있으니까요. 하지만 아나가 고르는 것은 우산이 아니라 외투예요. 글이 말한 것도 외투가 따뜻한지 시원한지뿐이에요.",
 [("학교에 늦는 일이 드물다", "지문에 없는 이야기예요. 학교에 가는 시간은 나오지 않아요."),
  ("너무 춥거나 너무 더운 일이 드물다", "셋째 문장 «Her coat is almost always warm enough or cool enough for the day.»가 근거예요. 외투가 거의 언제나 충분히 따뜻하거나 시원하니, 너무 춥거나 너무 더운 날이 드문 것이에요."),
  ("비 오는 날 젖는 일이 드물다", "지문에 없는 이야기예요. 비나 우산은 나오지 않아요. 글이 말한 것은 외투가 따뜻한지 시원한지예요."),
  ("외투를 잃어버리는 일이 드물다", "지문에 없는 이야기예요. 외투를 잃어버린다는 말은 나오지 않아요."),
  ("겨울에 감기에 걸리는 일이 드물다", "지문에 없는 이야기예요. 감기도, 겨울도 나오지 않아요.")])

# ---------- 5번째: 열한 시의 사과 (답 feeling hungry before lunch) ----------
rw(4, 3, "Tom eats an apple during the short break at eleven every day. His stomach then stays quiet until the lunch bell at half past twelve. Last year, without the apple, his stomach made noises in the last class before lunch. This small habit at break stops him ______.",
 ["buying sweets at the school shop", "eating too fast at lunch", "feeling sleepy in the afternoon", "feeling hungry before lunch", "getting a headache in class"],
 "톰은 날마다 열한 시 짧은 쉬는 시간에 사과를 하나 먹는다. 그러면 톰의 배는 열두 시 반 점심 종이 울릴 때까지 조용하다. 사과가 없던 지난해에는 점심 전 마지막 수업 시간에 배에서 소리가 났다. 쉬는 시간의 이 작은 버릇은 톰이 ______ 것을 막아 준다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «This small habit at break stops him»(쉬는 시간의 이 작은 버릇은 톰이 ~하는 것을 막아 준다). stops him 뒤에 -ing 꼴이 오면 「그가 ~하지 않게 막아 준다」라는 뜻이에요. 사과를 먹으면 무엇을 안 하게 되는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «His stomach then stays quiet until the lunch bell at half past twelve.»(그러면 톰의 배는 열두 시 반 점심 종이 울릴 때까지 조용하다.) 'stays quiet'(조용하다)과 'until the lunch bell'(점심 종이 울릴 때까지)이 단서예요.",
 "3) 셋째 문장 확인: «his stomach made noises in the last class before lunch»(점심 전 마지막 수업 시간에 배에서 소리가 났다). 배에서 소리가 나는 것은 배가 고플 때예요. 사과가 없던 때에는 점심 전에 배가 고팠어요.",
 "4) 묶기: 배가 점심 종까지 조용하다 = 점심 전에 배가 고프지 않다. 그래서 막아 주는 것은 'feeling hungry before lunch'(점심 전에 배고파지는 것)예요."],
 "「학교 매점에서 단것을 사는」이 끌릴 수 있어요. 배가 고프지 않으면 군것질도 안 할 것 같거든요. 하지만 글에는 매점도 단것도 나오지 않아요. 글이 말한 것은 배가 점심 종까지 조용하다는 것뿐이에요.",
 [("학교 매점에서 단것을 사는", "지문에 없는 이야기예요. 매점이나 단것은 나오지 않아요."),
  ("점심을 너무 빨리 먹는", "지문에 없는 이야기예요. 점심을 어떻게 먹는지는 나오지 않아요."),
  ("오후에 졸리는", "지문에 없는 이야기예요. 글이 말한 것은 점심 종이 울리기 전까지의 일이에요. 점심 뒤의 일도, 졸린다는 말도 나오지 않아요."),
  ("점심 전에 배고파지는", "둘째 문장 «His stomach then stays quiet until the lunch bell at half past twelve.»가 근거예요. 배가 점심 종까지 조용하니, 점심 전에 배가 고프지 않은 것이에요."),
  ("수업 시간에 머리가 아픈", "지문에 없는 이야기예요. 머리가 아프다는 말은 나오지 않아요.")])

# ---------- 6번째: 일요일마다 돌려 주는 화분 (답 grows straight instead of leaning) ----------
rw(5, 1, "Mina's plant sits next to the only window in her room. Its stem stands up like a pencil and does not bend towards the glass. Every Sunday morning she gives the pot a small turn. Thanks to this small job, the plant ______.",
 ["needs water only once a week", "grows straight instead of leaning", "flowers earlier than her other plants", "stays green all through winter", "grows new leaves every week"],
 "미나의 식물은 방에 하나뿐인 창문 옆에 놓여 있다. 그 줄기는 연필처럼 꼿꼿이 서 있고 유리창 쪽으로 휘지 않는다. 일요일 아침마다 미나는 화분을 조금 돌려 준다. 이 작은 일 덕분에, 그 식물은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to this small job»(이 작은 일 덕분에). 그 덕분에 식물이 어떠한지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Its stem stands up like a pencil and does not bend towards the glass.»(그 줄기는 연필처럼 꼿꼿이 서 있고 유리창 쪽으로 휘지 않는다.) 'stands up like a pencil'(연필처럼 꼿꼿이 서 있다)과 'does not bend'(휘지 않는다)가 단서예요.",
 "3) 셋째 문장 확인: «Every Sunday morning she gives the pot a small turn.»(일요일 아침마다 미나는 화분을 조금 돌려 준다.) 넷째 문장의 'this small job'(이 작은 일)이 바로 이 일이에요.",
 "4) 묶기: 연필처럼 서 있다 = 'grows straight'(곧게 자란다). 유리창 쪽으로 휘지 않는다 = 'instead of leaning'(기울지 않고). 둘째 문장을 다른 말로 바꾼 것이에요."],
 "「한 주에 한 번만 물을 주면 된다」가 끌릴 수 있어요. 글에 'Every Sunday'(일요일마다)가 나오거든요. 하지만 일요일마다 하는 일은 물을 주는 것이 아니라 화분을 돌리는 것이에요.",
 [("한 주에 한 번만 물을 주면 된다", "지문에 없는 이야기예요. 물 이야기는 나오지 않아요. 일요일마다 하는 일은 화분을 돌리는 것이에요."),
  ("기울지 않고 곧게 자란다", "둘째 문장 «Its stem stands up like a pencil and does not bend towards the glass.»가 근거예요. 줄기가 연필처럼 서 있고 휘지 않으니, 기울지 않고 곧게 자라는 것이에요."),
  ("미나의 다른 식물들보다 일찍 꽃이 핀다", "지문에 없는 이야기예요. 꽃도, 다른 식물도 나오지 않아요."),
  ("겨울 내내 푸르다", "지문에 없는 이야기예요. 겨울이나 잎의 빛깔은 나오지 않아요."),
  ("주마다 새잎이 난다", "지문에 없는 이야기예요. 새잎이 난다는 말은 나오지 않아요. 주마다 하는 것은 화분을 돌리는 일이에요.")])

# ---------- 7번째: 자기 전에 보는 버스 시간 (답 stops her waiting in the cold) ----------
rw(6, 0, "Zoe checks the bus times on her phone every night before bed. In the morning she walks out to the stop just in time for her bus. She never stands at the stop for long on winter mornings. For Zoe, this small check at night ______.",
 ["stops her waiting in the cold", "lets her sleep longer", "gives her time for a hot breakfast", "gets her to school before her friends", "helps her pick a quiet bus"],
 "조이는 밤마다 자기 전에 전화기로 버스 시간을 확인한다. 아침이면 버스가 올 때에 딱 맞추어 정류장으로 걸어 나간다. 겨울 아침에 정류장에 오래 서 있는 일이 결코 없다. 조이에게, 밤에 하는 이 작은 확인은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this small check at night»(밤에 하는 이 작은 확인). 자기 전에 버스 시간을 확인하는 일이에요. 이 확인이 조이에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «She never stands at the stop for long on winter mornings.»(겨울 아침에 정류장에 오래 서 있는 일이 결코 없다.) 'never stands at the stop for long'(정류장에 오래 서 있는 일이 결코 없다)과 'winter mornings'(겨울 아침)가 단서예요.",
 "3) 둘째 문장 확인: «she walks out to the stop just in time for her bus»(버스가 올 때에 딱 맞추어 정류장으로 걸어 나간다). 오래 서 있지 않는 까닭이에요. 버스 시간을 아니까 딱 맞추어 나가요.",
 "4) 묶기: 정류장에 서 있다 = 기다린다. 겨울 아침 = 추운 때. 그래서 'stops her waiting in the cold'(추운 데서 기다리지 않게 해 준다)예요. stops her 뒤에 -ing 꼴이 오면 「그녀가 ~하지 않게 막아 준다」라는 뜻이에요."],
 "「더 오래 자게 해 준다」가 끌릴 수 있어요. 딱 맞추어 나가면 그만큼 더 잘 수 있을 것 같거든요. 하지만 글에는 몇 시에 일어나는지, 얼마나 자는지가 나오지 않아요. 글이 말한 것은 겨울 아침에 정류장에 오래 서 있지 않는다는 것이에요.",
 [("추운 데서 기다리지 않게 해 준다", "셋째 문장 «She never stands at the stop for long on winter mornings.»가 근거예요. 겨울 아침에 정류장에 오래 서 있지 않으니, 추운 데서 기다리지 않는 것이에요."),
  ("더 오래 자게 해 준다", "지문에 없는 이야기예요. 몇 시에 일어나는지는 나오지 않아요."),
  ("따뜻한 아침을 먹을 시간을 준다", "지문에 없는 이야기예요. 아침밥은 나오지 않아요."),
  ("친구들보다 먼저 학교에 닿게 해 준다", "지문에 없는 이야기예요. 친구들도, 학교에 닿는 시간도 나오지 않아요."),
  ("조용한 버스를 고르도록 도와준다", "지문에 없는 이야기예요. 조이가 확인하는 것은 버스가 오는 시간이에요. 조용한 버스를 고른다는 말은 없어요.")])

# ---------- 8번째: 할 일을 적는 종이 (답 forgets far fewer things) ----------
rw(7, 2, "Every morning Leo writes down five small jobs on a piece of paper. Before the list, he forgot one of his five jobs almost every day. This month, with the list, he has forgotten only one small job. Thanks to this piece of paper, Leo ______.",
 ["finishes his jobs far sooner", "feels far less tired at night", "forgets far fewer things", "worries far less about school", "has far more free time"],
 "아침마다 레오는 작은 할 일 다섯 가지를 종이 한 장에 적는다. 이렇게 적기 전에는 거의 날마다 다섯 가지 가운데 하나를 잊었다. 할 일을 적은 종이가 있는 이번 달에는 작은 할 일 딱 하나만 잊었다. 이 종이 한 장 덕분에, 레오는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to this piece of paper»(이 종이 한 장 덕분에). 할 일을 적은 종이예요. 그 덕분에 레오가 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «This month, with the list, he has forgotten only one small job.»(할 일을 적은 종이가 있는 이번 달에는 작은 할 일 딱 하나만 잊었다.) 'only one'(딱 하나만)이 단서예요.",
 "3) 둘째 문장 확인: «he forgot one of his five jobs almost every day»(거의 날마다 다섯 가지 가운데 하나를 잊었다). 'almost every day'(거의 날마다)를 셋째 문장의 'only one'과 견주어 보아요.",
 "4) 묶기: 거의 날마다 하나 → 이번 달에는 딱 하나. 잊는 일이 훨씬 줄었어요. 그래서 'forgets far fewer things'(훨씬 적게 잊어버린다)예요. 'far fewer'는 '훨씬 더 적은'이라는 뜻이에요."],
 "「할 일을 훨씬 일찍 끝낸다」가 끌릴 수 있어요. 할 일을 적어 두면 일도 빨리 끝날 것 같거든요. 하지만 글에는 일을 언제 끝내는지가 나오지 않아요. 글이 견준 것은 잊은 일의 수예요.",
 [("할 일을 훨씬 일찍 끝낸다", "지문에 없는 이야기예요. 일을 언제 끝내는지는 나오지 않아요."),
  ("밤에 훨씬 덜 피곤하다", "지문에 없는 이야기예요. 피곤하다는 말은 나오지 않아요."),
  ("훨씬 적게 잊어버린다", "셋째 문장 «This month, with the list, he has forgotten only one small job.»이 근거예요. 거의 날마다 하나씩 잊던 것이 이번 달에는 하나로 줄었어요."),
  ("학교 걱정을 훨씬 덜 한다", "지문에 없는 이야기예요. 걱정도, 학교도 나오지 않아요."),
  ("자유 시간이 훨씬 더 많다", "지문에 없는 이야기예요. 자유 시간은 나오지 않아요.")])

# ---------- 9번째: 밤마다 꽂아 두는 전화기 (답 is always ready to use) ----------
rw(8, 3, "Jae plugs in his phone before brushing his teeth every night. It then charges slowly during his eight hours of sleep. At seven, the little battery picture on the screen is completely green. In the morning, Jae's phone ______.",
 ["always wakes him up on time", "is always full of new messages", "is always half charged", "is always ready to use", "is always easy to find"],
 "재는 밤마다 이를 닦기 전에 전화기를 충전기에 꽂는다. 그러면 전화기는 재가 자는 여덟 시간 동안 천천히 충전된다. 일곱 시에는 화면의 작은 배터리 그림이 온통 초록색이다. 아침에, 재의 전화기는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «In the morning, Jae's phone»(아침에, 재의 전화기는). 아침에 전화기가 어떤 모습인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «At seven, the little battery picture on the screen is completely green.»(일곱 시에는 화면의 작은 배터리 그림이 온통 초록색이다.) 'completely green'(온통 초록색)이 단서예요. 배터리 그림이 온통 초록색이면 배터리가 가득 찼다는 뜻이에요.",
 "3) 첫 문장 확인: «Jae plugs in his phone before brushing his teeth every night.»(재는 밤마다 이를 닦기 전에 전화기를 충전기에 꽂는다.) 'every night'(밤마다)라고 했어요. 그래서 아침마다 같은 일이 일어나요.",
 "4) 묶기: 배터리가 가득 찼다 = 바로 쓸 수 있다. 밤마다 꽂으니 아침마다 그래요. 그래서 'is always ready to use'(언제나 바로 쓸 수 있다)예요."],
 "「언제나 반쯤 충전되어 있다」가 끌릴 수 있어요. 둘째 문장에 'slowly'(천천히)가 있어서 다 차지 못했을 것 같거든요. 하지만 셋째 문장에서 배터리 그림은 'completely green'(온통 초록색)이라고 했어요. 여덟 시간 동안 가득 찬 것이에요.",
 [("언제나 제때 재를 깨워 준다", "지문에 없는 이야기예요. 전화기가 재를 깨운다는 말은 나오지 않아요."),
  ("언제나 새 메시지로 가득하다", "지문에 없는 이야기예요. 메시지는 나오지 않아요."),
  ("언제나 반쯤 충전되어 있다", "글과 맞지 않아요. 셋째 문장에서 배터리 그림이 온통 초록색이라고 했어요. 반이 아니라 가득 찬 것이에요."),
  ("언제나 바로 쓸 수 있다", "셋째 문장 «At seven, the little battery picture on the screen is completely green.»이 근거예요. 아침에 배터리가 가득 차 있으니, 바로 쓸 수 있는 것이에요."),
  ("언제나 찾기 쉽다", "지문에 없는 이야기예요. 전화기를 찾는다는 말은 나오지 않아요.")])

# ---------- 10번째: 떠나기 전에 켜 보는 손전등 (답 is never left in the dark) ----------
rw(9, 3, "Sam tests his flashlight at home before every camping trip. He changes weak batteries for new ones on the same day. At camp, his light works well from the first night to the last. Because of this habit, Sam ______.",
 ["never wastes a battery", "never buys a new flashlight", "is never afraid at camp", "is never left in the dark", "never packs a heavy bag"],
 "샘은 캠핑을 갈 때마다 떠나기 전에 집에서 손전등을 켜 본다. 약해진 건전지는 그날로 새것으로 바꾼다. 캠핑장에서 샘의 손전등은 첫날 밤부터 마지막 날 밤까지 잘 켜진다. 이 버릇 덕분에, 샘은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Because of this habit, Sam»(이 버릇 덕분에, 샘은). 떠나기 전에 손전등을 켜 보는 버릇이에요. 그 덕분에 샘이 어떠한지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «At camp, his light works well from the first night to the last.»(캠핑장에서 샘의 손전등은 첫날 밤부터 마지막 날 밤까지 잘 켜진다.) 'from the first night to the last'(첫날 밤부터 마지막 날 밤까지)가 단서예요.",
 "3) 둘째 문장 확인: «He changes weak batteries for new ones on the same day.»(약해진 건전지는 그날로 새것으로 바꾼다.) 손전등이 밤마다 잘 켜지는 까닭이에요.",
 "4) 묶기: 밤마다 불이 잘 켜진다 = 어두운 데 있게 되는 일이 없다. 그래서 'is never left in the dark'(어둠 속에 남겨지는 일이 결코 없다)예요. 'the dark'는 '어둠'이에요."],
 "「새 손전등을 사는 일이 결코 없다」가 끌릴 수 있어요. 글에 'new'(새)라는 말이 나오거든요. 하지만 샘이 새것으로 바꾸는 것은 건전지예요. 손전등을 산다는 말도, 안 산다는 말도 없어요.",
 [("건전지를 낭비하는 일이 결코 없다", "지문에 없는 이야기예요. 건전지를 아낀다는 말은 나오지 않아요. 글이 말한 것은 약해진 건전지를 새것으로 바꾼다는 것이에요."),
  ("새 손전등을 사는 일이 결코 없다", "지문에 없는 이야기예요. 글에서 새것으로 바꾸는 것은 건전지예요. 손전등을 사는 이야기는 없어요."),
  ("캠핑장에서 결코 무서워하지 않는다", "지문에 없는 이야기예요. 무섭다는 말은 나오지 않아요."),
  ("어둠 속에 남겨지는 일이 결코 없다", "셋째 문장 «At camp, his light works well from the first night to the last.»가 근거예요. 손전등이 밤마다 잘 켜지니, 어둠 속에 남겨지는 일이 없는 것이에요."),
  ("무거운 가방을 싸는 일이 결코 없다", "지문에 없는 이야기예요. 가방의 무게는 나오지 않아요.")])

# ---------- 11번째: 저녁마다 치우는 계단 (답 stops anybody tripping) ----------
rw(10, 4, "Nobody in Emma's family falls on the stairs these days. Last winter her little brother fell over a school bag there. Since that day, Emma has taken every shoe and bag off the stairs each evening. In their house, this small evening job of hers ______.",
 ["makes the house look bigger", "helps them find their shoes", "saves her mother money", "makes dinner earlier", "stops anybody tripping"],
 "요즘 에마네 식구는 아무도 계단에서 넘어지지 않는다. 지난겨울에 에마의 남동생이 거기서 책가방에 걸려 넘어졌다. 그날부터 에마는 저녁마다 계단에서 신발과 가방을 모두 치워 왔다. 에마네 집에서, 에마가 저녁에 하는 이 작은 일은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this small evening job of hers»(에마가 저녁에 하는 이 작은 일). 저녁마다 계단을 치우는 일이에요. 이 일이 집에서 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 첫 문장이에요. «Nobody in Emma's family falls on the stairs these days.»(요즘 에마네 식구는 아무도 계단에서 넘어지지 않는다.) 'Nobody'(아무도 ~않다)와 'falls'(넘어지다)가 단서예요.",
 "3) 둘째 문장 확인: «Last winter her little brother fell over a school bag there.»(지난겨울에 에마의 남동생이 거기서 책가방에 걸려 넘어졌다.) 'fell over a school bag'(책가방에 걸려 넘어졌다)이 있어요. 계단에 놓인 물건에 발이 걸려서 넘어진 것이에요.",
 "4) 묶기: 'tripping'은 '발이 걸려 넘어지는 것'이에요. 계단에서 아무도 넘어지지 않는다 = 'stops anybody tripping'(누구도 걸려 넘어지지 않게 해 준다). stops anybody 뒤에 -ing 꼴이 와서 「누구도 ~하지 않게 막아 준다」라는 뜻이에요."],
 "「식구들이 자기 신발을 찾도록 도와준다」가 끌릴 수 있어요. 글에 'shoe'(신발)가 나오고, 치워 두면 찾기도 쉬울 것 같거든요. 하지만 글에는 신발을 찾는 이야기가 없어요. 글이 말한 것은 계단에서 아무도 넘어지지 않는다는 것이에요.",
 [("집을 더 넓어 보이게 해 준다", "지문에 없는 이야기예요. 집이 넓어 보인다는 말은 나오지 않아요."),
  ("식구들이 자기 신발을 찾도록 도와준다", "지문에 없는 이야기예요. 신발을 찾는다는 말은 나오지 않아요. 글이 말한 것은 계단에서 아무도 넘어지지 않는다는 것이에요."),
  ("어머니의 돈을 아껴 준다", "지문에 없는 이야기예요. 돈 이야기는 나오지 않아요."),
  ("저녁을 더 일찍 먹게 해 준다", "지문에 없는 이야기예요. 저녁 먹는 시간은 나오지 않아요."),
  ("누구도 걸려 넘어지지 않게 해 준다", "첫 문장 «Nobody in Emma's family falls on the stairs these days.»가 근거예요. 에마가 계단을 치운 뒤로 아무도 넘어지지 않아요.")])

# ---------- 12번째: 자기 전에 싸 두는 가방 (답 never forgets a book — 옛 means she never forgets one) ----------
rw(11, 1, "Every night Mila reads the next day's subjects from a list on the wall. She then puts the books for those subjects in her bag. In class, the right book is always on her desk. Because of this small job before bed, Mila ______.",
 ["leaves home without hurrying", "never forgets a book", "keeps her books like new", "never loses her homework", "sleeps a little longer"],
 "밤마다 밀라는 벽에 붙은 표에서 다음 날 과목을 읽는다. 그런 다음 그 과목의 책들을 가방에 넣는다. 수업 시간에 밀라의 책상 위에는 언제나 맞는 책이 놓여 있다. 자기 전에 하는 이 작은 일 덕분에, 밀라는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Because of this small job before bed»(자기 전에 하는 이 작은 일 덕분에). 다음 날 책을 가방에 넣어 두는 일이에요. 그 덕분에 밀라가 어떠한지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «In class, the right book is always on her desk.»(수업 시간에 밀라의 책상 위에는 언제나 맞는 책이 놓여 있다.) 'the right book'(맞는 책)과 'always'(언제나)가 단서예요.",
 "3) 둘째 문장 확인: «She then puts the books for those subjects in her bag.»(그런 다음 그 과목의 책들을 가방에 넣는다.) 맞는 책이 언제나 책상에 있는 까닭이에요.",
 "4) 묶기: 맞는 책이 언제나 책상에 있다 = 책을 집에 두고 오는 날이 없다. 그래서 'never forgets a book'(책을 잊고 오는 일이 결코 없다)이에요. 「언제나 있다」를 「결코 잊지 않는다」로 바꾸어 말한 것이에요."],
 "「서두르지 않고 집을 나선다」가 끌릴 수 있어요. 가방을 미리 싸 두면 아침이 느긋할 것 같거든요. 하지만 글에는 아침에 집을 나서는 이야기가 없어요. 글이 말한 것은 수업 시간의 책상 위예요.",
 [("서두르지 않고 집을 나선다", "지문에 없는 이야기예요. 아침에 집을 나서는 모습은 나오지 않아요."),
  ("책을 잊고 오는 일이 결코 없다", "셋째 문장 «In class, the right book is always on her desk.»가 근거예요. 맞는 책이 언제나 책상에 있으니, 책을 잊고 오는 일이 없는 것이에요."),
  ("책을 새것처럼 간직한다", "지문에 없는 이야기예요. 책이 얼마나 깨끗한지는 나오지 않아요."),
  ("숙제를 잃어버리는 일이 결코 없다", "지문에 없는 이야기예요. 숙제는 나오지 않아요. 가방에 넣는 것은 다음 날 과목의 책이에요."),
  ("조금 더 오래 잔다", "지문에 없는 이야기예요. 얼마나 오래 자는지는 나오지 않아요.")])

# ---------- 13번째: 부엌에 두는 전화기 (답 keep his mind on the page) ----------
rw(12, 4, "Ben leaves his phone in the kitchen during his homework time. At his desk, no message or game pulls his eyes away. He reads a whole chapter of his history book without stopping once. This simple habit helps him ______.",
 ["finish his homework sooner", "remember more history", "enjoy his book much more", "go to bed much earlier", "keep his mind on the page"],
 "벤은 숙제하는 동안 전화기를 부엌에 둔다. 책상에서는 어떤 메시지도 게임도 벤의 눈길을 빼앗지 않는다. 벤은 역사책 한 단원을 한 번도 멈추지 않고 다 읽는다. 이 간단한 버릇은 벤이 ______ 도와준다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «This simple habit helps him»(이 간단한 버릇은 벤이 ~하도록 도와준다). 숙제하는 동안 전화기를 부엌에 두는 버릇이에요. 이 버릇이 무엇을 도와주는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «At his desk, no message or game pulls his eyes away.»(책상에서는 어떤 메시지도 게임도 벤의 눈길을 빼앗지 않는다.) 'no message or game'(어떤 메시지도 게임도 ~않다)이 단서예요. 눈길을 빼앗는 것이 하나도 없다는 뜻이에요.",
 "3) 셋째 문장 확인: «He reads a whole chapter of his history book without stopping once.»(벤은 역사책 한 단원을 한 번도 멈추지 않고 다 읽는다.) 'without stopping once'(한 번도 멈추지 않고)가 그 결과예요.",
 "4) 묶기: 눈길을 빼앗기지 않고, 멈추지 않고 읽는다 = 'keep his mind on the page'(읽고 있는 글에 마음을 붙들어 두다). 'the page'는 벤이 읽고 있는 책의 쪽이에요. 거기 적힌 글에 마음을 모은다는 뜻이에요."],
 "「숙제를 더 일찍 끝내도록」이 끌릴 수 있어요. 멈추지 않고 읽으면 빨리 끝날 것 같거든요. 하지만 글에는 숙제를 언제 끝내는지가 나오지 않아요. 글이 말한 것은 눈길을 빼앗기지 않고 읽는다는 것이에요.",
 [("숙제를 더 일찍 끝내도록", "지문에 없는 이야기예요. 숙제를 언제 끝내는지는 나오지 않아요."),
  ("역사를 더 많이 기억하도록", "지문에 없는 이야기예요. 읽은 것을 얼마나 기억하는지는 나오지 않아요."),
  ("책을 훨씬 더 즐기도록", "지문에 없는 이야기예요. 책이 재미있다는 말은 나오지 않아요."),
  ("훨씬 일찍 잠자리에 들도록", "지문에 없는 이야기예요. 잠자는 시간은 나오지 않아요."),
  ("읽고 있는 글에 마음을 붙들어 두도록", "둘째 문장 «At his desk, no message or game pulls his eyes away.»가 근거예요. 눈길을 빼앗는 것이 없으니, 읽고 있는 글에 마음을 붙들어 둘 수 있는 것이에요.")])

# ---------- 14번째: 일어나자마자 여는 커튼 (답 wake up properly) ----------
rw(13, 0, "On summer mornings Yuna opens her curtains straight after her alarm. Bright light from the sun fills the whole room in a second. After a minute in the light, she does not feel sleepy any more. On those mornings, this first job of the day helps her ______.",
 ["wake up properly", "feel happy all day", "leave on time", "keep the room warm", "enjoy breakfast"],
 "여름 아침이면 유나는 자명종이 울리자마자 커튼을 연다. 밝은 햇빛이 순식간에 온 방을 채운다. 그 빛 속에서 일 분이 지나면 유나는 더는 졸리지 않다. 그런 아침에, 하루의 이 첫 일은 유나가 ______ 도와준다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this first job of the day helps her»(하루의 이 첫 일은 유나가 ~하도록 도와준다). 하루의 첫 일은 커튼을 여는 것이에요. 이 일이 유나가 무엇을 하도록 도와주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «she does not feel sleepy any more»(더는 졸리지 않다). 'not'과 'any more'가 함께 쓰여서 「더는 ~않다」라는 뜻이 돼요. 'sleepy'(졸린)가 단서예요.",
 "3) 둘째 문장 확인: «Bright light from the sun fills the whole room in a second.»(밝은 햇빛이 순식간에 온 방을 채운다.) 커튼을 열자 밝은 빛이 들어와요. 셋째 문장의 'the light'(그 빛)가 바로 이 빛이에요.",
 "4) 묶기: 더는 졸리지 않다 = 잠이 제대로 깼다. 그래서 'wake up properly'(잠에서 제대로 깨다)예요. 'properly'는 '제대로'라는 뜻이에요."],
 "「방을 따뜻하게 유지하도록」이 끌릴 수 있어요. 여름 햇빛이 들어오면 방이 따뜻해질 것 같거든요. 하지만 글에는 방이 따뜻하다는 말이 없어요. 글이 말한 것은 빛 속에서 졸음이 사라진다는 것이에요.",
 [("잠에서 제대로 깨도록", "셋째 문장 «she does not feel sleepy any more»가 근거예요. 빛 속에서 일 분이 지나면 더는 졸리지 않으니, 잠에서 제대로 깨는 것이에요."),
  ("온종일 기분이 좋도록", "지문에 없는 이야기예요. 글이 말한 것은 일어난 바로 뒤의 일이에요. 온종일의 기분은 나오지 않아요."),
  ("제시간에 집을 나서도록", "지문에 없는 이야기예요. 집을 나서는 시간은 나오지 않아요."),
  ("방을 따뜻하게 유지하도록", "지문에 없는 이야기예요. 방이 따뜻한지는 나오지 않아요. 햇빛이 한 일은 방을 밝게 채운 것이에요."),
  ("아침밥을 맛있게 먹도록", "지문에 없는 이야기예요. 아침밥은 나오지 않아요.")])

# ---------- 15번째: 역에서 십 분 충전 (답 still has battery left) ----------
rw(14, 0, "Kai's phone battery is almost empty after a long day at school. At the station he plugs it in for ten minutes before his train. The phone plays music all the way home and never turns off. At his front door an hour later, he ______.",
 ["still has battery left", "has a full battery again", "has no battery left at all", "has left his charger behind", "has used up all his data"],
 "학교에서 긴 하루를 보낸 뒤, 카이의 전화기 배터리는 거의 비어 있다. 역에서 카이는 기차를 타기 전에 십 분 동안 전화기를 충전기에 꽂아 둔다. 전화기는 집까지 가는 내내 음악을 들려주고 한 번도 꺼지지 않는다. 한 시간 뒤 현관문 앞에서, 카이는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «At his front door an hour later»(한 시간 뒤 현관문 앞에서). 집에 닿았을 때 카이의 전화기가 어떤지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The phone plays music all the way home and never turns off.»(전화기는 집까지 가는 내내 음악을 들려주고 한 번도 꺼지지 않는다.) 'all the way home'(집까지 가는 내내)과 'never turns off'(한 번도 꺼지지 않는다)가 단서예요.",
 "3) 둘째 문장 확인: «he plugs it in for ten minutes before his train»(기차를 타기 전에 십 분 동안 전화기를 충전기에 꽂아 둔다). 꽂아 둔 시간은 십 분뿐이에요. 그 뒤로는 집까지 내내 음악을 틀었어요.",
 "4) 묶기: 집까지 한 번도 꺼지지 않았다 = 배터리가 다 떨어지지 않았다. 그래서 'still has battery left'(배터리가 아직 남아 있다)예요. 'still'은 '아직', 'left'는 '남아 있는'이라는 뜻이에요."],
 "「배터리가 다시 가득 차 있다」가 끌릴 수 있어요. 역에서 충전을 했으니까요. 하지만 꽂아 둔 것은 십 분뿐이고, 그 뒤로 집까지 내내 음악을 틀었어요. 글이 말한 것은 꺼지지 않았다는 것이지, 가득 찼다는 것이 아니에요.",
 [("배터리가 아직 남아 있다", "셋째 문장 «The phone plays music all the way home and never turns off.»가 근거예요. 집까지 한 번도 꺼지지 않았으니, 배터리가 아직 남아 있는 것이에요."),
  ("배터리가 다시 가득 차 있다", "글과 맞지 않아요. 거의 빈 배터리를 십 분만 충전했고, 그 뒤로 집까지 내내 음악을 틀었어요. 그러니 다시 가득 차 있을 수 없어요."),
  ("배터리가 하나도 남아 있지 않다", "글과 반대예요. 셋째 문장에서 전화기는 집까지 한 번도 꺼지지 않는다고 했어요."),
  ("충전기를 두고 왔다", "지문에 없는 이야기예요. 충전기를 두고 왔다는 말은 나오지 않아요. 여기서 'left'는 '두고 왔다'라는 뜻이에요."),
  ("데이터를 다 써 버렸다", "지문에 없는 이야기예요. 데이터는 나오지 않아요.")])
