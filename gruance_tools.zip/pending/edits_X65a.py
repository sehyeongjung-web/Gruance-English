# -*- coding: utf-8 -*-
# 340번: 29번(어법) 레벨1 앞 절반 — 다섯 문장(문장당 10~15낱말 · 단문) · 틀린 곳 하나. 정답 번호는 바탕 그대로, 지문·해석·풀이·해설·올바른 꼴(correctWord)을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z29rw import maker
rw = maker(E)

# 1번째
rw(0, 'sv',
   ['My grandfather ①walks along the river near our house every morning.',
 'He ②carries a small bag of bread for the hungry ducks.',
 'The white ducks ③swims toward him across the cold river water.',
 'Grandfather slowly ④gives each duck a little piece of bread.',
 'Then the happy ducks ⑤eat quietly under the big tree near the bridge.'],
   'swim',
   ['우리 할아버지는 아침마다 우리 집 근처 강을 따라 걸으신다.', '할아버지는 배고픈 오리들을 위해 작은 빵 봉지를 들고 가신다.', '하얀 오리들이 차가운 강물을 가로질러 할아버지 쪽으로 헤엄쳐 온다.', '할아버지는 오리마다 작은 빵 조각 하나씩을 천천히 주신다.', '그러고 나면 행복한 오리들은 다리 근처의 큰 나무 아래에서 조용히 먹는다.'],
   ['주어 My grandfather: 하나(단수) → walks (○)',
 '주어 He: 하나(단수) → carries (○)',
 '주어 The white ducks: 여럿(복수)이니 동사에 -s를 붙이지 않아요. swims (×) → swim (○)',
 '주어 Grandfather: 하나(단수) → gives (○)',
 '주어 the happy ducks: 여럿(복수) → 동사 원형 eat (○)'],
   'bread 빵 / duck 오리 / bridge 다리 / hungry 배고픈')

# 2번째
rw(1, 'past',
   ['My family ①went to the lake for a picnic yesterday.',
 'My father ②carried a heavy bag of food from the car.',
 'In the afternoon, my little sister ③find a pretty stone by the water.',
 'We ④ate sandwiches and fruit on the soft grass by the lake.',
 'Everyone in the car ⑤was very happy on the long drive home.'],
   'found',
   ['우리 가족은 어제 호수로 소풍을 갔다.', '아버지는 차에서 음식이 든 무거운 가방을 나르셨다.', '오후에 내 여동생은 물가에서 예쁜 돌을 발견했다.', '우리는 호숫가의 부드러운 풀밭에서 샌드위치와 과일을 먹었다.', '차에 탄 모두가 집으로 돌아오는 긴 드라이브 내내 아주 행복했다.'],
   ['어제(yesterday) 일: 과거형 went (○)', '어제 일: 과거형 carried (○)', '어제 오후 일이니 과거형으로 써야 해요. find (×) → found (○)', '어제 일: 과거형 ate (○)', '어제 일: 과거형 was (○)'],
   'picnic 소풍 / heavy 무거운 / pretty 예쁜 / grass 풀밭')

# 3번째
rw(2, 'sv',
   ['Mr. Kim ①drives a big yellow bus to our school every day.',
 'He ②knows the name of every child on the bus.',
 'The children ③wave to him at the corner each morning.',
 'Mr. Kim ④smile at the children from his seat by the door.',
 'Every child ⑤feels very safe on his big yellow bus.'],
   'smiles',
   ['김 아저씨는 날마다 큰 노란 버스를 몰고 우리 학교에 온다.', '그는 버스에 탄 아이들의 이름을 모두 안다.', '아이들은 아침마다 길모퉁이에서 그에게 손을 흔든다.', '김 아저씨는 문 옆 자기 자리에서 아이들에게 미소를 짓는다.', '아이들은 모두 그의 큰 노란 버스에서 아주 안전하다고 느낀다.'],
   ['주어 Mr. Kim: 하나(단수) → drives (○)',
 '주어 He: 하나(단수) → knows (○)',
 '주어 The children: 여럿(복수) → 동사 원형 wave (○)',
 '주어 Mr. Kim: 하나(단수)이니 동사에 -s를 붙여야 해요. smile (×) → smiles (○)',
 '주어 Every child: 하나(단수) → feels (○)'],
   'drive 몰다 / corner 모퉁이 / seat 자리 / safe 안전한')

# 4번째
rw(3, 'modal',
   ['My little brother can ①read many short books by himself.',
 'He ②plays the guitar in our school band on Fridays.',
 'He still cannot ③plays the piano very well in front of people.',
 'Next year, he will ④join the school soccer team with his friends.',
 'My parents ⑤are very proud of his hard work and good grades.'],
   'play',
   ['내 남동생은 짧은 책을 많이 혼자 읽을 수 있다.', '그는 금요일마다 학교 밴드에서 기타를 친다.', '그는 아직 사람들 앞에서 피아노를 잘 치지 못한다.', '내년에 그는 친구들과 함께 학교 축구부에 들어갈 것이다.', '부모님은 그의 노력과 좋은 성적이 아주 자랑스럽다.'],
   ['can 뒤: 동사 원형 read (○)', '주어 He: 하나(단수) → plays (○)', 'cannot 뒤에는 주어가 누구든 동사 원형을 써야 해요. plays (×) → play (○)', 'will 뒤: 동사 원형 join (○)', '주어 My parents: 여럿(복수) → are (○)'],
   'guitar 기타 / band 밴드 / proud 자랑스러운 / grades 성적')

# 5번째
rw(4, 'plural',
   ['My large classroom has two big ①windows near the school playground.',
 'There are thirty ②desks in long rows on the floor.',
 'The back wall has four large ③poster with pictures of animals.',
 'Each ④student keeps a small box under the desk in class.',
 'Many ⑤books stand on the long shelf beside the door.'],
   'posters',
   ['우리 넓은 교실에는 학교 운동장 가까이에 큰 창문이 두 개 있다.', '바닥에는 책상 서른 개가 긴 줄로 놓여 있다.', '뒤쪽 벽에는 동물 그림이 있는 커다란 포스터가 네 장 있다.', '학생마다 교실 책상 아래에 작은 상자를 하나씩 둔다.', '많은 책이 문 옆의 긴 선반에 놓여 있다.'],
   ['two 뒤: 여럿 → windows (○)', 'thirty 뒤: 여럿 → desks (○)', 'four 뒤이니 여럿을 나타내는 -s를 붙여야 해요. poster (×) → posters (○)', 'Each 뒤: 하나 → student (○)', 'Many 뒤: 여럿 → books (○)'],
   'classroom 교실 / playground 운동장 / poster 포스터 / shelf 선반')

# 6번째
rw(5, 'pron',
   ['My cousin Anna ①lives in a small town by the sea.',
 '②She visits our house in the summer with her mother and father.',
 'I always show ③she the best shops near my house.',
 '④We walk along the long beach near my house every evening.',
 'My friends at school ask ⑤me about our fun days with her.'],
   'her',
   ['내 사촌 애나는 바닷가의 작은 마을에 산다.', '그녀는 여름에 어머니, 아버지와 함께 우리 집에 온다.', '나는 늘 그녀에게 우리 집 근처의 가장 좋은 가게들을 보여 준다.', '우리는 저녁마다 우리 집 근처의 긴 해변을 따라 걷는다.', '학교 친구들은 그녀와 함께한 우리의 즐거운 날들에 대해 나에게 묻는다.'],
   ['주어 Anna: 하나(단수) → lives (○)', '문장의 주어 자리: She (○)', "show 뒤(~에게 자리)는 주어 자리가 아니에요. '그녀에게'는 her로 써야 해요. she (×) → her (○)", '문장의 주어 자리: We (○)', 'ask 뒤(~에게 자리): me (○)'],
   'cousin 사촌 / sea 바다 / beach 해변 / show 보여 주다')

# 7번째
rw(6, 'sv',
   ['The town library ①opens its big doors at nine every morning.',
 'Many young students ②come there to read interesting books after school.',
 'The librarian ③helps them find books about animals and space.',
 'She always ④keep the reading room very clean for every visitor.',
 'The students ⑤enjoy their quiet time in this warm place.'],
   'keeps',
   ['마을 도서관은 날마다 아침 아홉 시에 큰 문을 연다.', '많은 어린 학생이 방과 후에 재미있는 책을 읽으러 그곳에 온다.', '사서는 학생들이 동물과 우주에 관한 책을 찾도록 도와준다.', '그녀는 모든 방문객을 위해 열람실을 늘 아주 깨끗하게 유지한다.', '학생들은 이 따뜻한 곳에서 보내는 조용한 시간을 즐긴다.'],
   ['주어 The town library: 하나(단수) → opens (○)',
 '주어 Many young students: 여럿(복수) → 동사 원형 come (○)',
 '주어 The librarian: 하나(단수) → helps (○)',
 '주어 She: 하나(단수)이니 동사에 -s를 붙여야 해요. keep (×) → keeps (○)',
 '주어 The students: 여럿(복수) → 동사 원형 enjoy (○)'],
   'library 도서관 / librarian 사서 / visitor 방문객 / reading room 열람실')

# 8번째
rw(7, 'past',
   ['Our school ①held its big sports day on the large field last Friday.',
 'My class ②ran in the first race in the morning.',
 'Our team ③won the second race by only a few seconds.',
 'My best friend ④fall down near the last turn of the race.',
 'Our teacher ⑤gave all of us a small prize after the race.'],
   'fell',
   ['우리 학교는 지난 금요일에 넓은 운동장에서 큰 운동회를 열었다.', '우리 반은 아침에 첫 번째 경주에서 달렸다.', '우리 팀은 두 번째 경주에서 겨우 몇 초 차이로 이겼다.', '내 가장 친한 친구는 경주 마지막 모퉁이 근처에서 넘어졌다.', '선생님은 경주가 끝난 뒤 우리 모두에게 작은 상을 주셨다.'],
   ['지난 금요일(last Friday) 일: 과거형 held (○)', '같은 지난 일: 과거형 ran (○)', '지난 일: 과거형 won (○)', '지난 일이니 과거형으로 써야 해요. fall (×) → fell (○)', '지난 일: 과거형 gave (○)'],
   'sports day 운동회 / field 운동장 / race 경주 / prize 상')

# 9번째
rw(8, 'modal',
   ['Dolphins ①live in the warm water near the beach all year.',
 'They can ②swim very fast through the deep blue sea.',
 'They can also ③jump very high above the water in the sun.',
 'Dolphins cannot ④walks on land like a dog or a cat.',
 'Many visitors will ⑤see them from the boat next summer.'],
   'walk',
   ['돌고래는 일 년 내내 해변 가까운 따뜻한 물에서 산다.', '돌고래는 깊고 푸른 바다를 아주 빠르게 헤엄칠 수 있다.', '돌고래는 햇빛 아래 물 위로 아주 높이 뛰어오를 수도 있다.', '돌고래는 개나 고양이처럼 땅 위를 걸을 수는 없다.', '많은 방문객이 다음 여름에 배에서 돌고래를 볼 것이다.'],
   ['주어 Dolphins: 여럿(복수) → 동사 원형 live (○)', 'can 뒤: 동사 원형 swim (○)', 'can also 뒤: 동사 원형 jump (○)', 'cannot 뒤에는 주어가 누구든 동사 원형을 써야 해요. walks (×) → walk (○)', 'will 뒤: 동사 원형 see (○)'],
   'dolphin 돌고래 / beach 해변 / visitor 방문객 / boat 배')

# 10번째
rw(9, 'past',
   ['Yesterday morning, my father ①woke up very early to make breakfast.',
 'He ②make eggs and toast for the whole family in the kitchen.',
 'My mother ③thanked him with a big smile at the table.',
 'I ④drank two glasses of cold milk with my toast.',
 'We all ⑤felt very happy after that big breakfast at home.'],
   'made',
   ['어제 아침 우리 아버지는 아침 식사를 만들려고 아주 일찍 일어나셨다.', '아버지는 부엌에서 온 가족을 위해 달걀과 토스트를 만드셨다.', '어머니는 식탁에서 환한 미소로 아버지께 고마워하셨다.', '나는 토스트와 함께 차가운 우유 두 잔을 마셨다.', '우리 모두는 집에서 먹은 그 푸짐한 아침 식사 뒤에 아주 행복했다.'],
   ['어제(Yesterday) 일: 과거형 woke (○)', '어제 일이니 과거형으로 써야 해요. make (×) → made (○)', '어제 일: 과거형 thanked (○)', '어제 일: 과거형 drank (○)', '어제 일: 과거형 felt (○)'],
   'breakfast 아침 식사 / toast 토스트 / whole 온, 전체의 / glass 잔')

# 11번째
rw(10, 'plural',
   ['Our big farm has ten ①cows in a green field.',
 'There are also two ②horses and one old sheep near the house.',
 'Many white ③chickens walk around the yard all day long.',
 'The farmer collects six ④egg from the nest every morning.',
 'Each fresh ⑤egg goes into a small paper box for the market.'],
   'eggs',
   ['우리의 큰 농장에는 초록 들판에 소가 열 마리 있다.', '집 근처에는 말 두 마리와 늙은 양 한 마리도 있다.', '많은 흰 닭이 하루 종일 마당을 돌아다닌다.', '농부는 아침마다 둥지에서 달걀 여섯 개를 거둔다.', '싱싱한 달걀은 하나씩 시장에 내다 팔 작은 종이 상자에 들어간다.'],
   ['ten 뒤: 여럿 → cows (○)', 'two 뒤: 여럿 → horses (○)', 'Many 뒤: 여럿 → chickens (○)', 'six 뒤이니 여럿을 나타내는 -s를 붙여야 해요. egg (×) → eggs (○)', 'Each 뒤: 하나 → egg (○)'],
   'farm 농장 / cow 소 / sheep 양 / nest 둥지')

# 12번째
rw(11, 'sv',
   ['In summer, the sun ①rises very early in the morning.',
 'My mother ②wakes up with the first light of the sun.',
 'She ③opens all the windows in our small house for fresh air.',
 'My two brothers ④help her with the morning work in the kitchen.',
 "On Sundays, I ⑤sleeps until eight o'clock in my soft bed."],
   'sleep',
   ['여름에는 해가 아침 아주 일찍 뜬다.', '어머니는 아침 첫 햇살에 일어나신다.', '어머니는 신선한 공기를 위해 우리 작은 집의 창문을 모두 여신다.', '내 두 형제는 부엌에서 어머니의 아침 일을 돕는다.', '일요일마다 나는 포근한 침대에서 여덟 시까지 잔다.'],
   ['주어 the sun: 하나(단수) → rises (○)', '주어 My mother: 하나(단수) → wakes (○)', '주어 She: 하나(단수) → opens (○)', '주어 My two brothers: 여럿(복수) → 동사 원형 help (○)', '주어 I는 -s를 붙이지 않는 주어예요. sleeps (×) → sleep (○)'],
   'rise 뜨다 / light 빛 / fresh 신선한 / until ~까지')

# 13번째
rw(12, 'past',
   ['Last summer, my class ①went to a camp in the mountains.',
 'We ②slept in small green tents near a quiet river.',
 'Our guide ③showed us the stars on the first night.',
 'Some of the boys ④swam in the cold river every afternoon.',
 'Everybody ⑤come home with a big smile on the last day.'],
   'came',
   ['지난여름 우리 반은 산속 캠프에 갔다.', '우리는 조용한 강 근처의 작은 초록 텐트에서 잤다.', '안내자는 첫날 밤 우리에게 별들을 보여 주었다.', '남자아이들 중 몇몇은 오후마다 차가운 강에서 수영했다.', '마지막 날 모두 큰 미소를 지으며 집에 돌아왔다.'],
   ['지난여름(Last summer) 일: 과거형 went (○)', '지난 일: 과거형 slept (○)', '지난 일: 과거형 showed (○)', '지난 일: 과거형 swam (○)', '지난 일이니 과거형으로 써야 해요. come (×) → came (○)'],
   'camp 캠프(야영) / tent 텐트 / guide 안내자 / quiet 조용한')

# 14번째
rw(13, 'modal',
   ['My grandmother ①has a new phone from my uncle in Busan.',
 'She can ②call all of her friends with just one button.',
 'She can also ③take pictures of the flowers in her garden.',
 'She will ④send the best pictures to our family tonight.',
 'She cannot ⑤reads small letters on the screen without her glasses.'],
   'read',
   ['우리 할머니는 부산에 사는 삼촌에게서 받은 새 휴대전화가 있다.', '할머니는 버튼 하나로 친구들에게 모두 전화를 걸 수 있다.', '할머니는 정원의 꽃 사진도 찍을 수 있다.', '할머니는 오늘 밤 가장 좋은 사진들을 우리 가족에게 보낼 것이다.', '할머니는 안경 없이는 화면의 작은 글씨를 읽지 못한다.'],
   ['주어 My grandmother: 하나(단수) → has (○)', 'can 뒤: 동사 원형 call (○)', 'can also 뒤: 동사 원형 take (○)', 'will 뒤: 동사 원형 send (○)', 'cannot 뒤에는 주어가 누구든 동사 원형을 써야 해요. reads (×) → read (○)'],
   'phone 휴대전화 / button 버튼 / screen 화면 / glasses 안경')

# 15번째
rw(14, 'plural',
   ['My small room has one big ①window above my old bed.',
 'Two ②shelves hold all of my favorite books and toys.',
 'A large ③map of the world hangs on the wall.',
 'Three green ④plants stand on the table near the door.',
 'My mother gives me five new ⑤book every year as a gift.'],
   'books',
   ['내 작은 방에는 오래된 침대 위쪽으로 큰 창문이 하나 있다.', '선반 두 개에 내가 좋아하는 책과 장난감이 모두 놓여 있다.', '커다란 세계 지도가 벽에 걸려 있다.', '초록 식물 세 포기가 문 가까운 탁자 위에 놓여 있다.', '어머니는 해마다 선물로 새 책 다섯 권을 주신다.'],
   ['one 뒤: 하나 → window (○)', 'Two 뒤: 여럿 → shelves (○)', 'A 뒤: 하나 → map (○)', 'Three 뒤: 여럿 → plants (○)', 'five 뒤이니 여럿을 나타내는 -s를 붙여야 해요. book (×) → books (○)'],
   'shelf(shelves) 선반 / map 지도 / plant 식물 / gift 선물')
