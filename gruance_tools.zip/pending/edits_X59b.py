# -*- coding: utf-8 -*-
# 325번: 34번(빈칸 추론 — 긴 구) 레벨1 — 레벨1 기준으로 다시 씀 (뒤 절반: 16~30번째)
# 꼴은 앞 절반(edits_X59a.py)과 같음: 네 문장 · 모두 단문 · 문장당 10~15낱말 · 빈칸은 넷째 문장
# 짝꿍 문장: 셋째 여덟 문항 · 둘째 일곱 문항(17·19·23·25·27·29·30번째)
# 글감의 두 갈래: ① 버릇 → 결과(16·18·20·22·24·26·28·30번째) ② 어떤 곳이 한 가지를 바꿈 → 「그 전의 탈」(17·19·21·23·25·27·29번째)
# 생각의 단계(추론축 레벨1): 짝꿍 문장의 말을 다른 말로 바꾼 것이 답
#   (wakes both of them up ← sleepy eyes → bright eyes · cancel in time for somebody else ← give their place back / another patient ·
#    saves her searching ← her hand goes straight to the right book · no way in before ← just a long wall · makes waking up harder ← the next wake-up felt even worse ·
#    the surprise rather than the cost ← came as a shock / the same prices · helps her remember them ← still knows them all a week later ·
#    everybody arriving at once ← two hundred guests in the same minute · the same mistake ← not wrong a second time · their working hours ← still at work ·
#    stops the food sticking ← hold on to the bottom → slide out · people and vehicles sharing space ← workers on foot and small trucks crossed the same open floor ·
#    make the ride much harder ← the easy road felt like a steep hill · go to a separate case ← stood alone in one bookcase · pulls her attention away ← drew her eyes)
# 정답 번호·발문은 그대로. **정답 구를 고친 문항 둘** — 정답 구 안에 절이 들어 있어 레벨1의 「단문만」에 맞지 않음. 뜻은 같거나 조금 좁아짐
#   17번째 cancel so somebody else can come → cancel in time for somebody else
#   25번째 whether parents could get there → their working hours (「올 수 있는지」 → 「일하는 시간」으로 좁아짐)
# 23번째 everybody arriving at once · 27번째 people and vehicles sharing space는 재 보니 걸리지 않아 그대로 둠
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '34', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, c5, ko, steps, traps, cn):
    """문항을 통째로 다시 씀: 지문·선택지·해석·풀이·해설. 정답 번호는 그대로. c5 = 새 선택지 다섯"""
    old = list(_tb[T][LV][n]['choices']); ch = {k: v for k, v in enumerate(c5) if v != old[k]}
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=ans in ch); e = E.pop((T, LV, n))
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(c5)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': list(c5), 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 16번째: 학교 가기 전의 개 산책 (답 wakes both of them up) ----------
rw(15, 1, "Tae-min walks his dog around the block before school every morning. At the door, both the boy and the dog still have sleepy eyes. After ten minutes in the fresh air, the two friends have bright eyes. For the boy and his dog, this short walk ______.",
 ["makes both of them hungry", "wakes both of them up", "keeps the dog quiet", "tires both of them out", "gets him to school early"],
 "태민이는 아침마다 학교에 가기 전에 개를 데리고 동네를 한 바퀴 돈다. 문 앞에서는 태민이도 개도 아직 졸린 눈이다. 맑은 공기 속에서 십 분이 지나면 두 친구의 눈은 초롱초롱하다. 태민이와 개에게, 이 짧은 산책은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For the boy and his dog, this short walk»(태민이와 개에게, 이 짧은 산책은). 학교 가기 전의 십 분 산책이에요. 이 산책이 둘에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «After ten minutes in the fresh air, the two friends have bright eyes.»(맑은 공기 속에서 십 분이 지나면 두 친구의 눈은 초롱초롱하다.) 'bright eyes'(초롱초롱한 눈)가 단서예요. 'the two friends'(두 친구)는 태민이와 개예요.",
 "3) 둘째 문장 확인: «both the boy and the dog still have sleepy eyes»(태민이도 개도 아직 졸린 눈이다). 'sleepy eyes'(졸린 눈)가 있어요. 산책하기 전의 모습이에요. 셋째 문장의 'bright eyes'와 반대예요.",
 "4) 묶기: 졸린 눈이 초롱초롱한 눈이 되었어요. 잠이 깬 것이에요. 태민이도 개도 그래요. 그래서 'wakes both of them up'(둘 다 잠에서 깨운다)이에요. 「wake A up」은 「A를 잠에서 깨우다」라는 뜻이에요."],
 "「둘 다 지치게 한다」가 끌릴 수 있어요. 아침부터 걸으면 힘이 빠질 것 같거든요. 하지만 셋째 문장에서 둘의 눈은 초롱초롱해요. 지친 것이 아니라 잠이 깬 것이에요.",
 [("둘 다 배고프게 한다", "지문에 없는 이야기예요. 배가 고프다는 말은 나오지 않아요."),
  ("둘 다 잠에서 깨운다", "셋째 문장 «After ten minutes in the fresh air, the two friends have bright eyes.»가 근거예요. 졸린 눈이던 둘이 십 분 뒤에는 눈이 초롱초롱하니, 산책이 둘 다 잠에서 깨우는 것이에요."),
  ("개를 조용하게 해 준다", "지문에 없는 이야기예요. 개가 시끄럽다는 말도, 조용하다는 말도 나오지 않아요."),
  ("둘 다 지치게 한다", "글과 맞지 않아요. 산책 뒤에 둘의 눈은 초롱초롱해요. 지친 모습이 아니에요."),
  ("태민이를 학교에 일찍 가게 해 준다", "지문에 없는 이야기예요. 학교에 닿는 시간은 나오지 않아요.")])

# ---------- 17번째: 이틀 전에 보내는 문자 메시지 (답 cancel in time for somebody else — 옛 cancel so somebody else can come) ----------
rw(16, 3, "A clinic sends a text message two days before every visit. Busy patients often answer it and give their place back. The doctor then sees another patient from the waiting list, not an empty chair. With such an early message, busy patients can ______.",
 ["prepare a list of questions", "see the doctor two days earlier", "ask a friend to come with them", "cancel in time for somebody else", "pay for the visit before the day"],
 "어느 병원은 진료 때마다 이틀 전에 문자 메시지를 보낸다. 바쁜 환자들은 자주 그 메시지에 답하며 자기 자리를 내놓는다. 그러면 의사는 빈 의자가 아니라 대기 명단에 있던 다른 환자를 본다. 이렇게 일찍 온 메시지가 있으면, 바쁜 환자들은 ______ 수 있다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With such an early message, busy patients can»(이렇게 일찍 온 메시지가 있으면, 바쁜 환자들은 ~할 수 있다). 이틀 전에 오는 문자 메시지예요. 그 덕분에 바쁜 환자들이 무엇을 할 수 있는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Busy patients often answer it and give their place back.»(바쁜 환자들은 자주 그 메시지에 답하며 자기 자리를 내놓는다.) 'give their place back'(자기 자리를 내놓는다)이 단서예요. 못 가게 된 진료를 취소하는 것이에요.",
 "3) 셋째 문장 확인: «The doctor then sees another patient from the waiting list, not an empty chair.»(그러면 의사는 빈 의자가 아니라 대기 명단에 있던 다른 환자를 본다.) 'another patient'(다른 환자)가 있어요. 이틀 전에 내놓은 자리라서 다른 환자가 그 자리에 올 수 있어요.",
 "4) 묶기: 자리를 내놓는다는 것은 'cancel'(취소하다)이에요. 다른 환자가 그 자리에 오니 'for somebody else'(다른 사람을 위해)예요. 이틀 전이라 늦지 않으니 'in time'(제때)이에요. 그래서 'cancel in time for somebody else'(다른 사람을 위해 제때 취소하다)예요."],
 "「이틀 더 일찍 의사를 볼」이 끌릴 수 있어요. 글에 'two days'(이틀)가 나오거든요. 하지만 이틀 일찍 오는 것은 문자 메시지예요. 진료가 앞당겨진다는 말은 없어요.",
 [("질문 목록을 마련할", "지문에 없는 이야기예요. 질문을 적는다는 말은 나오지 않아요."),
  ("이틀 더 일찍 의사를 볼", "지문에 없는 이야기예요. 이틀 일찍 오는 것은 문자 메시지예요. 진료 날이 바뀐다는 말은 없어요."),
  ("친구에게 함께 가 달라고 부탁할", "지문에 없는 이야기예요. 친구는 나오지 않아요."),
  ("다른 사람을 위해 제때 취소할", "둘째 문장 «Busy patients often answer it and give their place back.»이 근거예요. 메시지를 받고 자리를 내놓으니, 다른 환자가 그 자리에 올 수 있어요."),
  ("그날이 되기 전에 진료비를 낼", "지문에 없는 이야기예요. 돈을 낸다는 말은 나오지 않아요.")])

# ---------- 18번째: 책을 한 선반에 두기 (답 saves her searching) ----------
rw(17, 4, "Eun-ji keeps all her school books on one shelf by her desk. Her little brother hunts for his books in three rooms every morning. Her own hand goes straight to the right book in a second. For Eun-ji every morning, this simple habit ______.",
 ["saves her buying new ones", "keeps her books clean", "helps her read faster", "makes her room bigger", "saves her searching"],
 "은지는 학교 책을 모두 책상 옆 선반 한 칸에 둔다. 은지의 남동생은 아침마다 방 세 곳에서 책을 찾아다닌다. 은지의 손은 일 초 만에 맞는 책으로 곧장 간다. 아침마다 은지에게, 이 간단한 버릇은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this simple habit»(이 간단한 버릇). 책을 모두 선반 한 칸에 두는 버릇이에요. 이 버릇이 아침마다 은지에게 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Her own hand goes straight to the right book in a second.»(은지의 손은 일 초 만에 맞는 책으로 곧장 간다.) 'goes straight to the right book'(맞는 책으로 곧장 간다)이 단서예요. 찾을 것 없이 바로 집는다는 뜻이에요.",
 "3) 둘째 문장 확인: «Her little brother hunts for his books in three rooms every morning.»(은지의 남동생은 아침마다 방 세 곳에서 책을 찾아다닌다.) 'hunts for'(찾아다닌다)가 있어요. 동생은 아침마다 방 세 곳을 돌며 책을 찾아다녀요. 은지와 반대예요.",
 "4) 묶기: 손이 곧장 맞는 책으로 간다 = 찾아다니지 않는다. 그래서 'saves her searching'(찾아다니지 않아도 되게 해 준다)이에요. saves her 뒤에 -ing 꼴이 오면 「그녀가 ~하지 않아도 되게 해 준다」라는 뜻이에요."],
 "「새 책을 사지 않아도 되게 해 준다」가 끌릴 수 있어요. 앞부분이 답과 똑같고, 책을 잃어버리지 않으면 다시 살 일도 없을 것 같거든요. 하지만 글에는 책을 잃어버린다는 말도, 산다는 말도 없어요. 글이 말한 것은 책을 찾는 모습이에요.",
 [("새 책을 사지 않아도 되게 해 준다", "지문에 없는 이야기예요. 책을 산다는 말은 나오지 않아요."),
  ("책을 깨끗하게 해 준다", "지문에 없는 이야기예요. 책이 깨끗한지는 나오지 않아요."),
  ("더 빨리 읽도록 도와준다", "지문에 없는 이야기예요. 얼마나 빨리 읽는지는 나오지 않아요."),
  ("방을 더 넓게 해 준다", "지문에 없는 이야기예요. 방의 넓이는 나오지 않아요."),
  ("찾아다니지 않아도 되게 해 준다", "셋째 문장 «Her own hand goes straight to the right book in a second.»가 근거예요. 손이 곧장 맞는 책으로 가니, 찾아다니지 않아도 되는 것이에요.")])

# ---------- 19번째: 공원에 새로 낸 문 (답 no way in before) ----------
rw(18, 1, "A city park added new gates on its south and east sides. Before that, those two sides were just a long wall. Since then, the park has had twice as many visitors every day. The streets on those two sides had ______.",
 ["no bus stop before", "no way in before", "no wall before", "no lights before", "no shops before"],
 "어느 시립 공원이 남쪽과 동쪽에 새 문을 냈다. 그 전에는 그 두 쪽이 그저 긴 담이었다. 그 뒤로 공원에는 날마다 찾아오는 사람이 두 배로 늘었다. 그 두 쪽에 있는 거리들에는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «The streets on those two sides had»(그 두 쪽에 있는 거리들에는). 'those two sides'(그 두 쪽)는 남쪽과 동쪽이에요. 그쪽 거리들에 전에 무엇이 없었는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Before that, those two sides were just a long wall.»(그 전에는 그 두 쪽이 그저 긴 담이었다.) 'just a long wall'(그저 긴 담)이 단서예요. 담뿐이면 그쪽에서는 공원으로 들어갈 수 없어요.",
 "3) 첫 문장 확인: «A city park added new gates on its south and east sides.»(어느 시립 공원이 남쪽과 동쪽에 새 문을 냈다.) 그 두 쪽에 문이 생겼어요. 이제는 그쪽에서도 들어갈 수 있어요.",
 "4) 묶기: 그저 긴 담이었다 = 들어가는 문이 없었다. 그래서 'no way in before'(전에는 들어가는 길이 없었다)예요. 'way in'은 '들어가는 길'이에요."],
 "「전에는 담이 없었다」가 끌릴 수 있어요. 글에 'wall'(담)이 나오거든요. 하지만 글과 거꾸로예요. 전에는 그 두 쪽이 온통 담이었어요.",
 [("전에는 버스 정류장이 없었다", "지문에 없는 이야기예요. 버스 정류장은 나오지 않아요."),
  ("전에는 들어가는 길이 없었다", "둘째 문장 «Before that, those two sides were just a long wall.»이 근거예요. 그 두 쪽이 그저 긴 담이었으니, 그쪽 거리에서는 들어가는 길이 없었던 것이에요."),
  ("전에는 담이 없었다", "글과 반대예요. 전에는 그 두 쪽이 그저 긴 담이었다고 했어요."),
  ("전에는 등이 없었다", "지문에 없는 이야기예요. 등은 나오지 않아요."),
  ("전에는 가게가 없었다", "지문에 없는 이야기예요. 가게는 나오지 않아요.")])

# ---------- 20번째: 다시 울림 단추를 누르지 않기 (답 makes waking up harder) ----------
rw(19, 3, "Chan-woo sets one alarm for half past six and gets up at once. Last year he pressed the snooze button three or four times every morning. After each extra sleep of nine minutes, the next wake-up felt even worse. For Chan-woo, a snooze button on an alarm ______.",
 ["makes him feel fresh", "makes the morning feel longer", "wakes his family early", "makes waking up harder", "makes him late for class"],
 "찬우는 자명종을 여섯 시 반에 한 번만 맞추고 바로 일어난다. 지난해에는 아침마다 다시 울림 단추를 서너 번씩 눌렀다. 구 분씩 더 잘 때마다 다음에 깨는 일이 더욱 괴롭게 느껴졌다. 찬우에게, 자명종의 다시 울림 단추는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «a snooze button on an alarm»(자명종의 다시 울림 단추). 누르면 몇 분 뒤에 다시 울리는 단추예요. 찬우에게 이 단추가 어떤 것인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «the next wake-up felt even worse»(다음에 깨는 일이 더욱 괴롭게 느껴졌다). 'even worse'(더욱 괴롭게)가 단서예요. 'wake-up'은 '잠에서 깨는 일'이에요.",
 "3) 둘째 문장 확인: «he pressed the snooze button three or four times every morning»(아침마다 다시 울림 단추를 서너 번씩 눌렀다). 지난해의 버릇이에요. 누를 때마다 구 분씩 더 잤어요.",
 "4) 묶기: 다음에 깨는 일이 더욱 괴롭다 = 깨기가 더 어렵다. 그래서 'makes waking up harder'(잠에서 깨기를 더 어렵게 한다)예요. 'waking up'은 '잠에서 깨는 것'이에요."],
 "「개운하게 해 준다」가 끌릴 수 있어요. 구 분을 더 자면 더 개운할 것 같거든요. 하지만 셋째 문장은 더 자고 나면 깨는 일이 더욱 괴롭게 느껴졌다고 했어요. 글과 반대예요.",
 [("개운하게 해 준다", "글과 반대예요. 더 자고 나면 다음에 깨는 일이 더욱 괴롭게 느껴졌다고 했어요."),
  ("아침을 더 길게 느끼게 한다", "지문에 없는 이야기예요. 아침이 길게 느껴진다는 말은 나오지 않아요."),
  ("식구들을 일찍 깨운다", "지문에 없는 이야기예요. 식구들은 나오지 않아요."),
  ("잠에서 깨기를 더 어렵게 한다", "셋째 문장 «the next wake-up felt even worse»가 근거예요. 더 잘 때마다 다음에 깨는 일이 더욱 괴로웠으니, 깨기를 더 어렵게 하는 것이에요."),
  ("수업에 늦게 한다", "지문에 없는 이야기예요. 수업에 늦는다는 말은 나오지 않아요.")])

# ---------- 21번째: 먼저 전화로 값을 알리는 수리점 (답 the surprise rather than the cost) ----------
rw(20, 4, "A bicycle repair shop now phones every customer with the price first. Before, the number on the bill came as a shock at the counter. The same prices now bring no angry faces at all. Customers had been angry about ______.",
 ["the cost rather than the surprise", "the wait rather than the cost", "the work rather than the wait", "the staff rather than the work", "the surprise rather than the cost"],
 "어느 자전거 수리점은 이제 손님 모두에게 먼저 전화로 값을 알려 준다. 전에는 계산대에서 본 청구서의 숫자가 큰 놀라움이었다. 이제는 똑같은 값인데도 화난 얼굴이 하나도 없다. 손님들은 ______에 화가 나 있었다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Customers had been angry about»(손님들은 ~에 화가 나 있었다). 전화를 하기 전에 손님들이 무엇에 화가 났는지를 물어요. 「A rather than B」는 「B가 아니라 A」라는 뜻이에요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The same prices now bring no angry faces at all.»(이제는 똑같은 값인데도 화난 얼굴이 하나도 없다.) 'The same prices'(똑같은 값)가 단서예요. 값은 그대로인데 화는 사라졌어요. 그러니 화의 까닭은 값이 아니에요.",
 "3) 둘째 문장 확인: «the number on the bill came as a shock at the counter»(계산대에서 본 청구서의 숫자가 큰 놀라움이었다). 'a shock'(큰 놀라움)이 있어요. 전에는 값을 계산대에서 처음 알았어요. 이제는 전화로 먼저 알아요.",
 "4) 묶기: 값은 그대로예요. 달라진 것은 값을 미리 아는지, 갑자기 아는지예요. 그러니 화의 까닭은 놀라움이에요. 그래서 'the surprise rather than the cost'(값이 아니라 놀라움)예요. 글의 'a shock'을 'the surprise'로, 'prices'를 'the cost'로 바꾸어 말한 것이에요."],
 "「놀라움이 아니라 값」이 끌릴 수 있어요. 낱말은 답과 똑같고 차례만 거꾸로거든요. 수리비 때문에 화가 났다고 생각하기도 쉬워요. 하지만 셋째 문장에서 값은 전과 똑같다고 했어요. 값이 까닭이라면 지금도 화가 나야 해요.",
 [("놀라움이 아니라 값", "글과 반대예요. 값은 전과 똑같은데 화난 얼굴이 없어졌어요. 까닭은 값이 아니에요."),
  ("값이 아니라 기다림", "지문에 없는 이야기예요. 기다린다는 말은 나오지 않아요."),
  ("기다림이 아니라 일", "지문에 없는 이야기예요. 수리를 어떻게 했는지도, 기다린다는 말도 나오지 않아요."),
  ("일이 아니라 직원", "지문에 없는 이야기예요. 직원이 어떠한지는 나오지 않아요."),
  ("값이 아니라 놀라움", "셋째 문장 «The same prices now bring no angry faces at all.»이 근거예요. 값이 똑같은데 화가 사라졌으니, 화의 까닭은 값이 아니라 갑자기 알게 되는 놀라움이었어요.")])

# ---------- 22번째: 소리 내어 읽기 (답 helps her remember them) ----------
rw(21, 4, "Seo-yeon reads her history notes out loud in her room before a test. After silent reading, the names and dates used to leave her head overnight. After reading them aloud, she still knows them all a week later. For Seo-yeon, the sound of the words ______.",
 ["helps her read them faster", "helps her spell them", "helps her say them clearly", "keeps her awake", "helps her remember them"],
 "서연이는 시험 전에 방에서 역사 필기를 소리 내어 읽는다. 소리 없이 읽은 뒤에는 이름과 연도가 하룻밤 사이에 머리에서 빠져나가곤 했다. 소리 내어 읽은 뒤에는 한 주가 지나도 그것들을 모두 안다. 서연이에게, 낱말의 소리는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the sound of the words»(낱말의 소리). 소리 내어 읽을 때 귀에 들리는 소리예요. 그 소리가 서연이에게 무엇을 해 주는지를 물어요. 선택지의 'them'은 낱말들이에요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «After reading them aloud, she still knows them all a week later.»(소리 내어 읽은 뒤에는 한 주가 지나도 그것들을 모두 안다.) 'still knows'(여전히 안다)와 'a week later'(한 주 뒤에)가 단서예요.",
 "3) 둘째 문장 확인: «the names and dates used to leave her head overnight»(이름과 연도가 하룻밤 사이에 머리에서 빠져나가곤 했다). 소리 없이 읽을 때의 일이에요. 'overnight'(하룻밤 사이에)를 셋째 문장의 'a week later'와 견주어 보아요.",
 "4) 묶기: 한 주가 지나도 안다 = 잊지 않는다 = 기억한다. 그래서 'helps her remember them'(그것들을 기억하도록 도와준다)이에요."],
 "「그것들을 또렷이 말하도록 도와준다」가 끌릴 수 있어요. 소리 내어 읽으면 말하는 연습이 될 것 같거든요. 하지만 글에는 말을 잘하게 된다는 말이 없어요. 글이 견준 것은 얼마나 오래 아는지예요.",
 [("그것들을 더 빨리 읽도록 도와준다", "지문에 없는 이야기예요. 읽는 빠르기는 나오지 않아요."),
  ("그것들의 철자를 쓰도록 도와준다", "지문에 없는 이야기예요. 철자는 나오지 않아요."),
  ("그것들을 또렷이 말하도록 도와준다", "지문에 없는 이야기예요. 말을 또렷이 한다는 말은 나오지 않아요."),
  ("깨어 있게 해 준다", "지문에 없는 이야기예요. 존다는 말은 나오지 않아요."),
  ("그것들을 기억하도록 도와준다", "셋째 문장 «After reading them aloud, she still knows them all a week later.»가 근거예요. 소리 없이 읽으면 하룻밤에 잊고, 소리 내어 읽으면 한 주 뒤에도 알고 있으니, 소리가 기억을 도와주는 것이에요.")])

# ---------- 23번째: 아침 식사 시간을 늘린 호텔 (답 everybody arriving at once) ----------
rw(22, 2, "A hotel now serves breakfast from seven to nine, not only at eight. At eight, two hundred guests used to come down in the same minute. The cooks now make the same food little by little and throw away far less. For years, the hotel's problem had been ______.",
 ["the taste of the hotel food", "the number of kitchen staff", "everybody arriving at once", "guests taking too much food", "the price of the breakfast"],
 "어느 호텔은 이제 아침 식사를 여덟 시에만이 아니라 일곱 시부터 아홉 시까지 낸다. 여덟 시에는 손님 이백 명이 같은 일 분 사이에 내려오곤 했다. 요리사들은 이제 똑같은 음식을 조금씩 만들고 훨씬 덜 버린다. 여러 해 동안, 이 호텔의 문제는 ______에 있었다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the hotel's problem had been»(이 호텔의 문제는 ~에 있었다). 시간을 늘리기 전에 무엇이 문제였는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «At eight, two hundred guests used to come down in the same minute.»(여덟 시에는 손님 이백 명이 같은 일 분 사이에 내려오곤 했다.) 'in the same minute'(같은 일 분 사이에)이 단서예요. 같은 일 분 사이에 내려온다는 것은 한꺼번에 온다는 뜻이에요.",
 "3) 셋째 문장 확인: «The cooks now make the same food little by little and throw away far less.»(요리사들은 이제 똑같은 음식을 조금씩 만들고 훨씬 덜 버린다.) 손님이 나뉘어 오니 음식을 조금씩 만들 수 있어요. 그래서 버리는 것이 줄었어요. 'the same food'(똑같은 음식)라고 했으니, 음식은 바뀌지 않았어요.",
 "4) 묶기: 이백 명이 같은 일 분 사이에 내려온다 = 모두가 한꺼번에 온다. 그래서 'everybody arriving at once'(모두가 한꺼번에 오는 것)예요. 'at once'는 여기서 '한꺼번에'라는 뜻이에요."],
 "「손님들이 음식을 너무 많이 가져가는 것」이 끌릴 수 있어요. 버리는 음식이 줄었다고 했으니까요. 하지만 글에는 손님이 음식을 얼마나 가져가는지가 나오지 않아요. 글에서 달라진 것은 손님이 오는 때와 요리사가 만드는 법이에요.",
 [("호텔 음식의 맛", "글과 맞지 않아요. 셋째 문장에서 음식은 전과 똑같다고 했어요."),
  ("주방 직원의 수", "지문에 없는 이야기예요. 직원이 몇 명인지는 나오지 않아요."),
  ("모두가 한꺼번에 오는 것", "둘째 문장 «At eight, two hundred guests used to come down in the same minute.»이 근거예요. 이백 명이 같은 일 분 사이에 내려왔고, 나누어 오게 하자 버리는 음식이 줄었어요."),
  ("손님들이 음식을 너무 많이 가져가는 것", "지문에 없는 이야기예요. 손님이 음식을 얼마나 가져가는지는 나오지 않아요."),
  ("아침 식사의 값", "지문에 없는 이야기예요. 값은 나오지 않아요.")])

# ---------- 24번째: 틀린 낱말을 적는 공책 (답 stops him making the same mistake) ----------
rw(23, 0, "Min-jun writes every wrong word from his English tests in a small notebook. He looks through the notebook for five minutes before each new test. Not one of those old words has been wrong a second time. For Min-jun, this short look at the notebook ______.",
 ["stops him making the same mistake", "stops him forgetting new words", "helps him finish the test early", "makes his handwriting much neater", "helps him feel calm before a test"],
 "민준이는 영어 시험에서 틀린 낱말을 모두 작은 공책에 적는다. 새 시험을 보기 전마다 오 분 동안 그 공책을 훑어본다. 그 예전 낱말들 가운데 두 번 틀린 것은 하나도 없다. 민준이에게, 공책을 잠깐 훑어보는 이 일은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this short look at the notebook»(공책을 잠깐 훑어보는 이 일). 시험 전에 오 분 동안 공책을 보는 일이에요. 이 일이 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Not one of those old words has been wrong a second time.»(그 예전 낱말들 가운데 두 번 틀린 것은 하나도 없다.) 'wrong a second time'(두 번 틀린)과 'Not one'(하나도 ~않다)이 단서예요.",
 "3) 첫 문장 확인: «Min-jun writes every wrong word from his English tests in a small notebook.»(민준이는 영어 시험에서 틀린 낱말을 모두 작은 공책에 적는다.) 공책에 있는 것은 새 낱말이 아니라 한 번 틀린 낱말이에요.",
 "4) 묶기: 한 번 틀린 낱말을 두 번 틀리지 않는다 = 같은 실수를 되풀이하지 않는다. 그래서 'stops him making the same mistake'(같은 실수를 하지 않게 해 준다)예요. stops him 뒤에 -ing 꼴이 와서 「그가 ~하지 않게 막아 준다」라는 뜻이에요."],
 "「새 낱말을 잊지 않게 해 준다」가 끌릴 수 있어요. 낱말 공책이라면 새 낱말을 외우는 데 쓸 것 같거든요. 하지만 이 공책에 적는 것은 시험에서 틀린 낱말이에요. 새 낱말 이야기는 없어요.",
 [("같은 실수를 하지 않게 해 준다", "셋째 문장 «Not one of those old words has been wrong a second time.»이 근거예요. 한 번 틀린 낱말을 두 번 틀린 적이 없으니, 같은 실수를 하지 않는 것이에요."),
  ("새 낱말을 잊지 않게 해 준다", "지문에 없는 이야기예요. 공책에 적는 것은 시험에서 틀린 낱말이에요. 새 낱말은 나오지 않아요."),
  ("시험을 일찍 끝내도록 도와준다", "지문에 없는 이야기예요. 시험을 언제 끝내는지는 나오지 않아요."),
  ("글씨를 훨씬 가지런하게 해 준다", "지문에 없는 이야기예요. 글씨는 나오지 않아요."),
  ("시험 전에 차분하도록 도와준다", "지문에 없는 이야기예요. 민준이의 기분은 나오지 않아요.")])

# ---------- 25번째: 일곱 시로 옮긴 학부모의 밤 (답 their working hours — 옛 whether parents could get there) ----------
rw(24, 1, "A school moved its parents' evening from four o'clock to seven. At four, most mothers and fathers were still at work. At seven, the hall was full for the first time in years. For years, the number of parents there had depended on ______.",
 ["letters from the school", "their working hours", "the evening's subjects", "the size of the hall", "the evening's length"],
 "어느 학교가 학부모의 밤을 네 시에서 일곱 시로 옮겼다. 네 시에는 어머니와 아버지 대부분이 아직 일터에 있었다. 일곱 시에는 여러 해 만에 처음으로 강당이 가득 찼다. 여러 해 동안, 거기에 오는 학부모의 수는 ______에 달려 있었다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the number of parents there had depended on»(거기에 오는 학부모의 수는 ~에 달려 있었다). 「depend on ~」은 「~에 달려 있다」라는 뜻이에요. 학부모가 얼마나 오는지가 무엇에 달려 있었는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «At four, most mothers and fathers were still at work.»(네 시에는 어머니와 아버지 대부분이 아직 일터에 있었다.) 'still at work'(아직 일터에)가 단서예요. 일하는 시간이라 올 수 없었어요.",
 "3) 셋째 문장 확인: «At seven, the hall was full for the first time in years.»(일곱 시에는 여러 해 만에 처음으로 강당이 가득 찼다.) 일이 끝난 일곱 시로 옮기자 강당이 가득 찼어요.",
 "4) 묶기: 네 시에는 일하느라 못 오고, 일이 끝난 일곱 시에는 와요. 오는지 못 오는지를 일하는 시간이 정했어요. 그래서 'their working hours'(학부모의 일하는 시간)예요. 'their'는 학부모들을 가리켜요."],
 "「강당의 크기」가 끌릴 수 있어요. 글에 'the hall was full'(강당이 가득 찼다)이 나오거든요. 하지만 강당은 그대로예요. 바뀐 것은 시간뿐이에요.",
 [("학교에서 보낸 편지", "지문에 없는 이야기예요. 편지는 나오지 않아요."),
  ("학부모의 일하는 시간", "둘째 문장 «At four, most mothers and fathers were still at work.»가 근거예요. 네 시에는 일터에 있어서 못 왔고, 일곱 시에는 강당이 가득 찼어요."),
  ("그 모임에서 다루는 내용", "지문에 없는 이야기예요. 그날 무엇을 다루는지는 나오지 않아요."),
  ("강당의 크기", "지문에 없는 이야기예요. 강당의 크기가 바뀌었다는 말은 없어요. 바뀐 것은 시간이에요."),
  ("그 모임의 길이", "지문에 없는 이야기예요. 모임이 얼마나 긴지는 나오지 않아요.")])

# ---------- 26번째: 먼저 달구는 팬 (답 stops the food sticking) ----------
rw(25, 2, "Ha-eun heats her pan for a minute before the oil and the eggs. In a cold pan, her eggs used to hold on to the bottom. Now they slide out onto her plate in one clean piece. For Ha-eun, this one minute of heat ______.",
 ["saves a little cooking gas", "makes the eggs taste sweeter", "stops the food sticking", "stops the food drying out", "keeps the food warm longer"],
 "하은이는 기름과 달걀을 넣기 전에 팬을 일 분 동안 달군다. 차가운 팬에서는 달걀이 바닥을 붙잡고 놓지 않곤 했다. 이제 달걀은 깔끔하게 한 덩이로 접시 위로 미끄러져 나온다. 하은이에게, 이 일 분의 열은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «this one minute of heat»(이 일 분의 열). 기름을 넣기 전에 팬을 달구는 일 분이에요. 이 일 분이 무엇을 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now they slide out onto her plate in one clean piece.»(이제 달걀은 깔끔하게 한 덩이로 접시 위로 미끄러져 나온다.) 'slide out'(미끄러져 나온다)이 단서예요. 팬에 붙지 않으니 미끄러져 나와요.",
 "3) 둘째 문장 확인: «In a cold pan, her eggs used to hold on to the bottom.»(차가운 팬에서는 달걀이 바닥을 붙잡고 놓지 않곤 했다.) 'hold on to the bottom'(바닥을 붙잡고 놓지 않다)이 있어요. 팬을 달구지 않았을 때의 일이에요. 셋째 문장의 'slide out'과 반대예요.",
 "4) 묶기: 바닥을 붙잡고 놓지 않는다 = 달라붙는다. 미끄러져 나온다 = 달라붙지 않는다. 그래서 'stops the food sticking'(음식이 달라붙지 않게 해 준다)이에요. 'sticking'은 '달라붙는 것'이에요."],
 "「음식이 마르지 않게 해 준다」가 끌릴 수 있어요. 앞부분이 답과 똑같거든요. 하지만 글에는 음식이 마른다는 말이 없어요. 글이 견준 것은 바닥에 붙는지, 미끄러져 나오는지예요.",
 [("요리용 가스를 조금 아껴 준다", "지문에 없는 이야기예요. 가스는 나오지 않아요."),
  ("달걀 맛을 더 달게 해 준다", "지문에 없는 이야기예요. 맛은 나오지 않아요."),
  ("음식이 달라붙지 않게 해 준다", "셋째 문장 «Now they slide out onto her plate in one clean piece.»가 근거예요. 차가운 팬에서는 바닥을 붙잡던 달걀이 이제 미끄러져 나오니, 달라붙지 않는 것이에요."),
  ("음식이 마르지 않게 해 준다", "지문에 없는 이야기예요. 음식이 마른다는 말은 나오지 않아요."),
  ("음식을 더 오래 따뜻하게 해 준다", "지문에 없는 이야기예요. 음식이 얼마나 오래 따뜻한지는 나오지 않아요.")])

# ---------- 27번째: 공장 바닥의 노란 길 (답 people and vehicles sharing space) ----------
rw(26, 1, "A factory painted a yellow path for people on foot across its floor. Before, workers on foot and small trucks crossed the same open floor. Nobody has come close to an accident since that day. Clearly, the danger had come from ______.",
 ["trucks moving too quickly", "people and vehicles sharing space", "boxes blocking the main door", "machines standing too close together", "workers wearing the wrong shoes"],
 "어느 공장이 바닥을 가로질러 걸어 다니는 사람을 위한 노란 길을 칠했다. 전에는 걸어 다니는 일꾼들과 작은 트럭들이 똑같은 트인 바닥을 가로질렀다. 그날 뒤로는 사고가 날 뻔한 사람이 아무도 없다. 분명히, 위험은 ______에서 나왔던 것이다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the danger had come from»(위험은 ~에서 나왔던 것이다). 「come from ~」은 「~에서 나오다」라는 뜻이에요. 노란 길을 칠하기 전에 무엇이 위험했는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «workers on foot and small trucks crossed the same open floor»(걸어 다니는 일꾼들과 작은 트럭들이 똑같은 트인 바닥을 가로질렀다). 'the same open floor'(똑같은 트인 바닥)가 단서예요. 사람과 트럭이 한 바닥을 같이 썼어요.",
 "3) 셋째 문장 확인: «Nobody has come close to an accident since that day.»(그날 뒤로는 사고가 날 뻔한 사람이 아무도 없다.) 사람이 다니는 길을 따로 칠하자 위험한 일이 없어졌어요.",
 "4) 묶기: 걸어 다니는 일꾼들은 'people'(사람)이에요. 작은 트럭들은 'vehicles'(차)예요. 똑같은 바닥을 가로질렀다는 것은 'sharing space'(자리를 함께 쓰는 것)예요. 그래서 'people and vehicles sharing space'(사람과 차가 자리를 함께 쓰는 것)예요."],
 "「트럭이 너무 빨리 움직이는 것」이 끌릴 수 있어요. 글에 'trucks'(트럭)가 나오고, 빠른 트럭은 위험하니까요. 하지만 글에는 트럭의 빠르기가 나오지 않아요. 길을 칠한 뒤에 달라진 것은 사람과 트럭이 다니는 자리예요.",
 [("트럭이 너무 빨리 움직이는 것", "지문에 없는 이야기예요. 트럭이 얼마나 빠른지는 나오지 않아요."),
  ("사람과 차가 자리를 함께 쓰는 것", "둘째 문장 «workers on foot and small trucks crossed the same open floor»가 근거예요. 일꾼들과 트럭이 같은 바닥을 가로질렀고, 길을 따로 칠하자 위험이 사라졌어요."),
  ("상자가 정문을 막는 것", "지문에 없는 이야기예요. 상자도, 정문도 나오지 않아요."),
  ("기계들이 너무 가까이 붙어 서 있는 것", "지문에 없는 이야기예요. 기계는 나오지 않아요."),
  ("일꾼들이 맞지 않는 신발을 신는 것", "지문에 없는 이야기예요. 신발은 나오지 않아요.")])

# ---------- 28번째: 일요일마다 살펴보는 자전거 타이어 (답 make the ride much harder) ----------
rw(27, 0, "Jae-min checks and pumps up his bicycle tyres every Sunday evening. One week he forgot and rode to school on soft tyres. That day the easy road to school felt like a steep hill. For Jae-min on a bicycle, soft tyres ______.",
 ["make the ride much harder", "make the brakes much weaker", "make the chain fall off", "make the bicycle too noisy", "make the bicycle look old"],
 "재민이는 일요일 저녁마다 자전거 타이어를 살펴보고 바람을 넣는다. 어느 주에는 잊어버리고 바람 빠진 타이어로 학교에 갔다. 그날은 학교 가는 쉬운 길이 가파른 언덕처럼 느껴졌다. 자전거를 타는 재민이에게, 바람 빠진 타이어는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For Jae-min on a bicycle, soft tyres»(자전거를 타는 재민이에게, 바람 빠진 타이어는). 'soft tyres'는 바람이 빠져서 말랑한 타이어예요. 그런 타이어가 어떠한지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «That day the easy road to school felt like a steep hill.»(그날은 학교 가는 쉬운 길이 가파른 언덕처럼 느껴졌다.) 'felt like a steep hill'(가파른 언덕처럼 느껴졌다)이 단서예요. 'easy road'(쉬운 길)가 그렇게 느껴졌어요.",
 "3) 둘째 문장 확인: «One week he forgot and rode to school on soft tyres.»(어느 주에는 잊어버리고 바람 빠진 타이어로 학교에 갔다.) 셋째 문장의 'That day'(그날)는 바람 빠진 타이어로 간 날이에요.",
 "4) 묶기: 쉬운 길이 가파른 언덕처럼 느껴졌다 = 타기가 훨씬 힘들었다. 그래서 'make the ride much harder'(타기를 훨씬 더 힘들게 한다)예요. 'the ride'는 '자전거를 타고 가는 일'이에요."],
 "「브레이크를 훨씬 약하게 한다」가 끌릴 수 있어요. 타이어가 말랑하면 잘 서지 않을 것 같거든요. 하지만 글에는 브레이크가 나오지 않아요. 글이 말한 것은 길이 언덕처럼 힘들게 느껴졌다는 것이에요.",
 [("타기를 훨씬 더 힘들게 한다", "셋째 문장 «That day the easy road to school felt like a steep hill.»이 근거예요. 쉬운 길이 가파른 언덕처럼 느껴졌으니, 타기가 훨씬 힘들어진 것이에요."),
  ("브레이크를 훨씬 약하게 한다", "지문에 없는 이야기예요. 브레이크는 나오지 않아요."),
  ("체인이 빠지게 한다", "지문에 없는 이야기예요. 체인은 나오지 않아요."),
  ("자전거를 너무 시끄럽게 한다", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("자전거를 낡아 보이게 한다", "지문에 없는 이야기예요. 자전거가 어떻게 보이는지는 나오지 않아요.")])

# ---------- 29번째: 큰 글씨 책을 다른 책과 섞어 꽂기 (답 go to a separate case) ----------
rw(28, 4, "A library moved its large-print books onto the same shelves as the others. Before, they stood alone in one bookcase under a big sign. Older readers now borrow three times as many of them. Before the move, many readers had not wanted to ______.",
 ["pay extra for the books", "ask a librarian for help", "carry such heavy books", "wait in a long line", "go to a separate case"],
 "어느 도서관이 큰 글씨 책들을 다른 책들과 같은 선반으로 옮겼다. 전에는 그 책들이 큰 표지판 아래 책장 하나에 따로 서 있었다. 이제 나이 든 독자들은 그 책을 세 배나 많이 빌린다. 옮기기 전에, 많은 독자는 ______ 싶어 하지 않았다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «many readers had not wanted to»(많은 독자는 ~하고 싶어 하지 않았다). 옮기기 전에 독자들이 하기 싫어한 일이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Before, they stood alone in one bookcase under a big sign.»(전에는 그 책들이 큰 표지판 아래 책장 하나에 따로 서 있었다.) 'alone in one bookcase'(책장 하나에 따로)가 단서예요. 'they'는 큰 글씨 책들이에요.",
 "3) 셋째 문장 확인: «Older readers now borrow three times as many of them.»(이제 나이 든 독자들은 그 책을 세 배나 많이 빌린다.) 다른 책과 섞어 놓자 세 배나 빌려 가요. 따로 있을 때는 그 책장으로 가기를 꺼렸다는 뜻이에요.",
 "4) 묶기: 책장 하나에 따로 있었다 = 'a separate case'(따로 떨어진 책장). 독자들은 그리로 가기를 꺼렸어요. 그래서 'go to a separate case'(따로 떨어진 책장으로 가다)예요. 여기서 'case'는 'bookcase'(책장)를 줄인 말이에요."],
 "「사서에게 도와 달라고 하고」가 끌릴 수 있어요. 따로 둔 책은 물어봐야 찾을 것 같거든요. 하지만 글에서 그 책장은 큰 표지판 아래에 있었어요. 글에는 사서도 나오지 않아요.",
 [("책값을 더 내고", "지문에 없는 이야기예요. 돈 이야기는 나오지 않아요."),
  ("사서에게 도와 달라고 하고", "지문에 없는 이야기예요. 사서는 나오지 않아요. 그 책장은 큰 표지판 아래에 있었어요."),
  ("그렇게 무거운 책을 들고 다니고", "지문에 없는 이야기예요. 책의 무게는 나오지 않아요."),
  ("긴 줄에 서서 기다리고", "지문에 없는 이야기예요. 줄을 선다는 말은 나오지 않아요."),
  ("따로 떨어진 책장으로 가고", "둘째 문장 «Before, they stood alone in one bookcase under a big sign.»이 근거예요. 책장 하나에 따로 있을 때는 덜 빌렸고, 섞어 놓자 세 배나 빌리니, 따로 떨어진 책장으로 가기를 꺼린 것이에요.")])

# ---------- 30번째: 무음으로 해 두어도 눈길을 끄는 전화기 (답 pulls her attention away) ----------
rw(29, 3, "Na-eun always puts her phone on silent before her evening homework. Last year the silent phone on her desk still drew her eyes every few minutes. This year it stays in a closed drawer during study time. For Na-eun, a phone on the desk ______.",
 ["makes her eyes very tired", "helps her check the time", "helps her find hard words", "pulls her attention away", "fills the room with noise"],
 "나은이는 저녁 숙제를 하기 전에 언제나 전화기를 무음으로 해 둔다. 지난해에는 책상 위의 무음으로 해 둔 전화기가 그래도 몇 분마다 나은이의 눈길을 끌었다. 올해는 공부하는 동안 전화기가 닫힌 서랍 안에 있다. 나은이에게, 책상 위의 전화기는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «For Na-eun, a phone on the desk»(나은이에게, 책상 위의 전화기는). 공부할 때 책상 위에 놓인 전화기예요. 그 전화기가 나은이에게 어떤 일을 하는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «the silent phone on her desk still drew her eyes every few minutes»(책상 위의 무음으로 해 둔 전화기가 그래도 몇 분마다 나은이의 눈길을 끌었다). 'drew her eyes'(눈길을 끌었다)가 단서예요. 'still'(그래도)이 있으니, 소리가 나지 않아도 그랬다는 뜻이에요.",
 "3) 셋째 문장 확인: «This year it stays in a closed drawer during study time.»(올해는 공부하는 동안 전화기가 닫힌 서랍 안에 있다.) 그래서 올해는 전화기를 아예 눈에 보이지 않는 곳에 둬요.",
 "4) 묶기: 공부하다가 눈길이 전화기로 간다 = 주의가 공부에서 떠난다. 그래서 'pulls her attention away'(주의를 빼앗아 간다)예요. 'attention'은 '주의'예요. 글의 'drew her eyes'를 다른 말로 바꾼 것이에요."],
 "「눈을 몹시 피곤하게 한다」가 끌릴 수 있어요. 글에 'eyes'(눈)가 나오거든요. 하지만 글은 눈이 피곤하다고 하지 않았어요. 눈길이 전화기로 간다고 했어요.",
 [("눈을 몹시 피곤하게 한다", "지문에 없는 이야기예요. 눈이 피곤하다는 말은 나오지 않아요. 글이 말한 것은 눈길이 전화기로 간다는 것이에요."),
  ("시간을 확인하도록 도와준다", "지문에 없는 이야기예요. 시간을 본다는 말은 나오지 않아요."),
  ("어려운 낱말을 찾도록 도와준다", "지문에 없는 이야기예요. 낱말을 찾는다는 말은 나오지 않아요."),
  ("주의를 빼앗아 간다", "둘째 문장 «the silent phone on her desk still drew her eyes every few minutes»가 근거예요. 무음으로 해 두어도 몇 분마다 눈길이 가니, 전화기가 주의를 빼앗아 가는 것이에요."),
  ("방을 시끄러운 소리로 채운다", "글과 맞지 않아요. 전화기는 무음으로 해 두었어요. 소리가 나지 않아요.")])
