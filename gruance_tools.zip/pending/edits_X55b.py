# -*- coding: utf-8 -*-
# 316번: 31번(빈칸 추론) 레벨1 — 새 레벨 기준으로 다시 씀 (뒤 절반: 16~30번째). 앞 절반은 edits_X55a.py(315번)
# 꼴·기준은 앞 절반과 같음: 네 문장 · 45낱말쯤 · 모두 단문 · 문장당 10~15낱말 · 중학 기초 낱말
#   첫 문장 = 하는 일 / 둘째 = 그 모습 / 셋째 = 결과(짝꿍 문장) / 넷째 = 빈칸 문장. 답이 지문에 다른 말로 한 번 더 나옴
# 글감·정답 번호는 그대로. 정답 낱말을 바꾼 문항 둘(중학 기초 낱말이 아니어서): 22번째 stiff → tired · 30번째 confidently → easily
# 오답을 바꾼 문항 둘: 28번째(두 낱말짜리 pay more·come late → pay·wait) · 30번째(reluctantly·carelessly → sadly·angrily)
# 독립 풀이(답을 모르는 채로 한 번): 15문항 모두 같은 답, 둘째 답이 서는 문항 없음. 지적받은 어색한 표현을 고친 뒤 다시 잼
AUTO_SYNC = False
E = {}
from z8common import maker, _tb
T, LV = '31', '1'
mk = maker(E, T, lv=LV)
def rw(n, ans, text, ko, steps, traps, cn, ch=None):
    """문항을 통째로 다시 씀: 지문·해석·풀이·해설. 정답 번호는 그대로. ch = {자리: 새 선택지}(바꾸는 문항만)"""
    mk(n, ans, steps, traps, cn, ch=ch, ans_ok=bool(ch and ans in ch)); e = E.pop((T, LV, n))
    choices = list(_tb[T][LV][n]['choices'])
    for k, v in (ch or {}).items(): choices[k] = v
    assert text.count('______') == 1 and ko.count('______') == 1 and len(set(choices)) == 5, n
    E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                     'rewrite': {'text': text, 'choices': choices, 'ko': ko, 'walk': e['walk'], 'cn': [e['cn'][k] for k in range(5)]}}

# ---------- 16번째: 책상 가까이 옮긴 인쇄기 (답 time) ----------
rw(15, 4, "An office moved its printer to a table near the desks. Before the move, every trip to the printer took two minutes. Now the workers get their pages in just ten seconds. With the printer so close, the workers waste far less ______ every day.",
 "한 사무실이 인쇄기를 책상 가까이의 탁자로 옮겼다. 옮기기 전에는 인쇄기까지 한 번 다녀오는 데 이 분이 걸렸다. 이제 직원들은 단 십 초 만에 인쇄한 종이를 가져온다. 인쇄기가 아주 가까이 있어서 직원들은 날마다 ______을 훨씬 덜 버린다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the workers waste far less»(직원들은 ~을 훨씬 덜 버린다). 'waste'는 「헛되이 쓰다」예요. 직원들이 무엇을 덜 버리게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now the workers get their pages in just ten seconds.»(이제 직원들은 단 십 초 만에 인쇄한 종이를 가져온다.) 'in just ten seconds'(단 십 초 만에)가 단서예요. 걸리는 시간을 말해요.",
 "3) 둘째 문장 확인: «Before the move, every trip to the printer took two minutes.»(옮기기 전에는 인쇄기까지 한 번 다녀오는 데 이 분이 걸렸다.) 이 분이 십 초로 줄었어요. 줄어든 것은 시간이에요.",
 "4) 묶기: 이 분이 십 초가 되었다 = 'time'(시간)을 덜 버린다. 'two minutes'와 'ten seconds'를 한 낱말로 묶은 것이에요."],
 "「종이」가 가장 끌려요. 인쇄기 이야기라서 종이가 먼저 떠오르거든요. 하지만 종이를 얼마나 쓰는지는 글에 나오지 않아요. 글이 견준 것은 이 분과 십 초, 곧 걸리는 시간이에요.",
 [("종이", "지문에 없는 이야기예요. 종이를 얼마나 쓰는지는 나오지 않아요. 글이 견준 것은 이 분과 십 초예요."),
  ("돈", "지문에 없는 이야기예요. 돈이 드는 일은 나오지 않아요."),
  ("공간", "지문에 없는 이야기예요. 인쇄기를 옮겼다고만 했고 자리가 넓어졌다는 말은 없어요."),
  ("잉크", "지문에 없는 이야기예요. 인쇄기에서 떠올리기 쉽지만 잉크는 나오지 않아요."),
  ("시간", "셋째 문장 «Now the workers get their pages in just ten seconds.»가 근거예요. 이 분 걸리던 일이 십 초면 끝나니 시간을 훨씬 덜 버려요.")])

# ---------- 17번째: 아침에 물을 주는 정원사 (답 dry) ----------
rw(16, 3, "A gardener now waters his plants early in the morning. The warm morning sun dries all the leaves in an hour. In the past, his evening watering left the leaves wet all night. Thanks to the morning watering, the leaves are ______ long before the evening.",
 "한 정원사는 이제 이른 아침에 식물에 물을 준다. 따뜻한 아침 해가 한 시간 만에 모든 잎을 말린다. 전에는 저녁에 물을 주어서 잎이 밤새 젖어 있었다. 아침에 물을 준 덕분에 잎은 저녁이 되기 한참 전에 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to the morning watering, the leaves are»(아침에 물을 준 덕분에 그 잎들은 ~하다). 아침에 물을 주면 잎이 저녁 전에 어떤지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «The warm morning sun dries all the leaves in an hour.»(따뜻한 아침 해가 한 시간 만에 모든 잎을 말린다.) 'dries'(말린다)가 단서예요. 해가 잎의 물기를 없애요.",
 "3) 셋째 문장 확인: «In the past, his evening watering left the leaves wet all night.»(전에는 저녁에 물을 주어서 잎이 밤새 젖어 있었다.) 'wet'(젖은)은 전의 일이에요. 지금은 그 반대예요.",
 "4) 묶기: 해가 잎을 말린다 = 잎이 'dry'(마른)하다. 'dries'를 모양만 바꾼 낱말이에요."],
 "「젖은」이 끌릴 수 있어요. 물을 주는 이야기이고, 지문에도 'wet'이 나오거든요. 하지만 'wet'은 'In the past'(전에는)로 시작하는 문장에 있어요. 저녁에 물을 주던 때의 이야기예요.",
 [("젖은", "전의 이야기예요. 잎이 밤새 젖어 있던 것은 저녁에 물을 주던 때예요. 지금은 아침 해가 잎을 말려요."),
  ("차가운", "지문에 없는 이야기예요. 잎이 차가운지는 나오지 않아요."),
  ("어두운", "지문에 없는 이야기예요. 잎의 빛깔은 나오지 않아요."),
  ("마른", "둘째 문장 «The warm morning sun dries all the leaves in an hour.»가 근거예요. 아침 해가 한 시간 만에 잎을 말리니 저녁이 되기 한참 전에 잎이 말라 있어요."),
  ("무거운", "지문에 없는 이야기예요. 잎의 무게는 나오지 않아요.")])

# ---------- 18번째: 숙제를 적어 두는 반 (답 rare) ----------
rw(17, 0, "Every student in the class now writes down the day's homework in a notebook. They do this at their desks before the last bell. This month only one student has come to school without homework. With this new habit, forgotten homework has become very ______ in the class.",
 "그 반의 학생들은 이제 모두 그날의 숙제를 공책에 적는다. 그들은 마지막 종이 울리기 전에 자기 책상에서 이 일을 한다. 이번 달에는 한 학생만 숙제 없이 학교에 왔다. 이 새 습관으로 그 반에서 숙제를 잊는 일은 아주 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «forgotten homework has become very»(잊은 숙제는 아주 ~해졌다). 'forgotten homework'는 「잊어버린 숙제」예요. 숙제를 잊는 일이 얼마나 있는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «This month only one student has come to school without homework.»(이번 달에는 한 학생만 숙제 없이 학교에 왔다.) 'only one student'(한 학생만)가 단서예요. 한 달에 한 명뿐이에요.",
 "3) 첫 문장 확인: «Every student in the class now writes down the day's homework in a notebook.»(그 반의 학생들은 이제 모두 그날의 숙제를 공책에 적는다.) 적어 두니 잊지 않아요.",
 "4) 묶기: 한 달에 한 명뿐이다 = 'rare'(드문)하다. 'only one student'를 한 낱말로 바꾼 것이에요."],
 "「흔한」을 조심해요. 「드문」과 뜻이 반대인 낱말이에요. 숙제 이야기가 계속 나오니 숙제를 잊는 일도 많은 것처럼 보일 수 있어요. 하지만 글은 한 학생만 숙제 없이 왔다고 했어요.",
 [("드문", "셋째 문장 «This month only one student has come to school without homework.»가 근거예요. 한 달에 한 학생뿐이니 숙제를 잊는 일이 아주 드물어요."),
  ("흔한", "글과 반대예요. 숙제 없이 온 학생은 한 달에 한 명뿐이에요."),
  ("시끄러운", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("값비싼", "지문에 없는 이야기예요. 돈이 드는 일은 나오지 않아요."),
  ("쓸모 있는", "글과 맞지 않아요. 쓸모 있는 것은 숙제를 적어 두는 습관이에요. 숙제를 잊는 일이 쓸모 있다는 말은 없어요.")])

# ---------- 19번째: 자전거로 학교에 가는 댄 (답 awake) ----------
rw(18, 2, "Dan rides his bike to school instead of taking the bus. The fresh morning air and the exercise wake up his body. In the first class, his eyes are bright and wide open. After the morning ride, Dan feels ______ in class all morning.",
 "댄은 버스를 타는 대신 자전거를 타고 학교에 간다. 상쾌한 아침 공기와 운동이 그의 몸을 깨운다. 첫 수업 시간에 그의 눈은 초롱초롱하고 크게 떠져 있다. 아침에 자전거를 타고 나면 댄은 오전 내내 수업 시간에 ______ 느낀다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «After the morning ride, Dan feels»(아침에 자전거를 타고 난 뒤 댄은 ~하다고 느낀다). 자전거를 타고 온 댄이 수업 시간에 어떤지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «The fresh morning air and the exercise wake up his body.»(상쾌한 아침 공기와 운동이 그의 몸을 깨운다.) 'wake up'(깨우다)이 단서예요.",
 "3) 셋째 문장 확인: «In the first class, his eyes are bright and wide open.»(첫 수업 시간에 그의 눈은 초롱초롱하고 크게 떠져 있다.) 눈이 크게 떠져 있어요. 졸지 않아요.",
 "4) 묶기: 몸이 깨어났다 = 'awake'(깨어 있는)하다고 느낀다. 'wake up'을 모양만 바꾼 낱말이에요."],
 "「피곤한」이 가장 끌려요. 아침부터 운동을 하면 피곤할 것 같거든요. 하지만 글은 반대로 말해요. 운동이 몸을 깨우고, 수업 시간에 눈이 크게 떠져 있다고 했어요.",
 [("피곤한", "글과 반대예요. 운동이 몸을 깨운다고 했고, 수업 시간에 눈이 크게 떠져 있어요."),
  ("배고픈", "지문에 없는 이야기예요. 운동을 하면 배가 고플 것 같지만, 먹는 이야기는 나오지 않아요."),
  ("깨어 있는", "둘째 문장 «The fresh morning air and the exercise wake up his body.»가 근거예요. 아침 공기와 운동이 몸을 깨우니 수업 시간 내내 깨어 있어요."),
  ("늦은", "지문에 없는 이야기예요. 댄이 학교에 늦는지는 나오지 않아요."),
  ("추운", "지문에 없는 이야기예요. 아침 공기는 상쾌하다고만 했고 춥다는 말은 없어요.")])

# ---------- 20번째: 선반마다 붙인 이름표 (답 asking) ----------
rw(19, 1, "The cooks in a busy restaurant put a label on every shelf. Each label shows the name of the food on that shelf. New cooks no longer need help from the other cooks. With the labels on the shelves, new cooks now find everything without ______.",
 "바쁜 식당의 요리사들이 선반마다 이름표를 붙였다. 이름표마다 그 선반에 있는 음식의 이름이 적혀 있다. 새로 온 요리사들은 더는 다른 요리사들의 도움이 필요 없다. 선반의 이름표 덕분에 새 요리사들은 이제 ______ 않고도 무엇이든 찾는다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «new cooks now find everything without»(새 요리사들은 이제 ~하지 않고 모든 것을 찾는다). 'without'(~하지 않고)이 있어요. 이제는 하지 않아도 되는 일을 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «New cooks no longer need help from the other cooks.»(새로 온 요리사들은 더는 다른 요리사들의 도움이 필요 없다.) 'no longer need help'(더는 도움이 필요 없다)가 단서예요.",
 "3) 둘째 문장 확인: «Each label shows the name of the food on that shelf.»(이름표마다 그 선반에 있는 음식의 이름이 적혀 있다.) 'label'은 이름표예요. 이름표만 읽으면 어디에 무엇이 있는지 알아요.",
 "4) 묶기: 도움이 필요 없다 = 'asking'(묻기)을 하지 않는다. 'need help'를 「묻다」로 바꾸어 말한 것이에요."],
 "「움직이기」가 끌릴 수 있어요. 물건을 찾아 돌아다니지 않아도 된다는 생각이 들거든요. 하지만 선반까지 가야 물건을 꺼낼 수 있어요. 글이 없어졌다고 한 것은 다른 요리사의 도움이에요.",
 [("요리하기", "글과 맞지 않아요. 요리사는 요리를 하는 사람이에요. 요리하지 않고 물건을 찾는다는 말은 없어요."),
  ("묻기", "셋째 문장 «New cooks no longer need help from the other cooks.»가 근거예요. 다른 요리사의 도움이 필요 없으니 묻지 않고도 무엇이든 찾아요."),
  ("돈 내기", "지문에 없는 이야기예요. 돈을 내는 일은 나오지 않아요."),
  ("웃기", "지문에 없는 이야기예요. 웃는 일은 나오지 않아요."),
  ("움직이기", "지문에 없는 이야기예요. 글이 없어졌다고 한 것은 움직이는 일이 아니라 다른 요리사의 도움이에요.")])

# ---------- 21번째: 낮은 선반으로 내린 장난감 (답 rose) ----------
rw(20, 4, "A toy shop moved its small toys to the lowest shelves. Young children can now reach all the small toys by themselves. Last month the shop sold twice as many small toys as before. After the change, sales of the small toys quickly ______.",
 "한 장난감 가게가 작은 장난감을 가장 낮은 선반으로 옮겼다. 어린아이들은 이제 작은 장난감에 모두 혼자서 손이 닿는다. 지난달에 가게는 작은 장난감을 전보다 두 배나 많이 팔았다. 이렇게 바꾼 뒤 작은 장난감의 판매는 빠르게 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «sales of the small toys quickly»(작은 장난감의 판매는 빠르게 ~했다). 'sales'는 「팔린 양」이에요. 팔린 양이 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Last month the shop sold twice as many small toys as before.»(지난달에 가게는 작은 장난감을 전보다 두 배나 많이 팔았다.) 'twice as many'(두 배나 많이)가 단서예요.",
 "3) 둘째 문장 확인: «Young children can now reach all the small toys by themselves.»(어린아이들은 이제 작은 장난감에 모두 혼자서 손이 닿는다.) 아이들이 직접 집을 수 있으니 더 많이 팔려요.",
 "4) 묶기: 두 배나 많이 팔았다 = 판매가 'rose'(올랐다). 'twice as many'를 한 낱말로 바꾼 것이에요."],
 "「떨어졌다」를 조심해요. 장난감을 낮은 선반으로 내렸다는 말에서 내려간다는 느낌을 받기 쉽거든요. 하지만 내려간 것은 장난감이 놓인 자리예요. 팔린 양은 두 배가 되었어요.",
 [("떨어졌다", "글과 반대예요. 내려간 것은 장난감이 놓인 자리이고, 팔린 양은 두 배가 되었어요."),
  ("멈추었다", "글과 반대예요. 가게는 전보다 두 배나 많이 팔았어요."),
  ("느려졌다", "글과 반대예요. 팔린 양이 줄지 않고 두 배가 되었어요."),
  ("사라졌다", "글과 반대예요. 판매가 없어진 것이 아니라 두 배가 되었어요."),
  ("올랐다", "셋째 문장 «Last month the shop sold twice as many small toys as before.»가 근거예요. 전보다 두 배나 많이 팔았으니 판매가 오른 것이에요.")])

# ---------- 22번째: 달린 뒤의 다리 풀기 (답 tired) ----------
rw(21, 3, "Mira stretches her legs for five minutes after every run. She holds each stretch and counts slowly to twenty every time. The next morning her legs feel fresh and ready to run again. Thanks to the stretching, her legs feel far less ______ the next day.",
 "미라는 달리기를 한 뒤마다 오 분 동안 다리를 쭉 펴 준다. 그녀는 펼 때마다 그대로 멈추고 천천히 스물까지 센다. 다음 날 아침 그녀의 다리는 가뿐하고 다시 달릴 준비가 되어 있다. 다리를 펴 준 덕분에 그녀의 다리는 다음 날 훨씬 덜 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «her legs feel far less»(그녀의 다리는 훨씬 덜 ~하게 느껴진다). 'less'(덜)가 있어요. 다음 날 다리에 무엇이 줄었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «The next morning her legs feel fresh and ready to run again.»(다음 날 아침 그녀의 다리는 가뿐하고 다시 달릴 준비가 되어 있다.) 'fresh'(가뿐한)가 단서예요. 다리에 힘이 남아 있어요.",
 "3) 첫 문장 확인: «Mira stretches her legs for five minutes after every run.»(미라는 달리기를 한 뒤마다 오 분 동안 다리를 쭉 펴 준다.) 'stretches'는 「쭉 편다」예요. 달린 뒤에 다리를 풀어 주는 이야기예요.",
 "4) 묶기: 다리가 가뿐하다 = 덜 'tired'(피곤한)하다. 'fresh'를 뒤집어 말한 것이에요."],
 "「튼튼한」이 끌릴 수 있어요. 운동을 하면 다리가 튼튼해진다고 생각하기 쉽거든요. 하지만 빈칸 앞에 'less'(덜)가 있어요. 넣으면 다리가 덜 튼튼하다는 말이 되어 글과 반대예요.",
 [("따뜻한", "지문에 없는 이야기예요. 다리가 따뜻한지는 나오지 않아요."),
  ("가벼운", "빈칸 앞에 「덜」이 있어요. 넣으면 다리가 덜 가볍다는 말이 되어, 가뿐하다는 글과 반대예요."),
  ("튼튼한", "빈칸 앞에 「덜」이 있어요. 넣으면 다리가 덜 튼튼하다는 말이 되어 글과 맞지 않아요."),
  ("피곤한", "셋째 문장 «The next morning her legs feel fresh and ready to run again.»이 근거예요. 다음 날 아침 다리가 가뿐하니 훨씬 덜 피곤한 것이에요."),
  ("빠른", "빈칸 앞에 「덜」이 있어요. 넣으면 다리가 덜 빠르다는 말이 되어, 다시 달릴 준비가 되었다는 글과 맞지 않아요.")],
 ch={3: 'tired'})

# ---------- 23번째: 교실에서 먹는 아침밥 (답 eats) ----------
rw(22, 4, "The school now serves a free breakfast in every classroom. Students take a plate and finish the food at their desks. In the past, many students came to school on an empty stomach. With breakfast in the classroom, almost every student now ______ in the morning.",
 "학교는 이제 교실마다 아침밥을 거저 내준다. 학생들은 접시를 받아 자기 책상에서 음식을 다 먹는다. 전에는 많은 학생이 빈속으로 학교에 왔다. 교실에 아침밥이 있어서 이제 거의 모든 학생이 아침에 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With breakfast in the classroom, almost every student now»(교실에 아침밥이 있어서 거의 모든 학생이 이제 ~한다). 학생들이 아침에 무엇을 하게 되었는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Students take a plate and finish the food at their desks.»(학생들은 접시를 받아 자기 책상에서 음식을 다 먹는다.) 'finish the food'(음식을 다 먹다)가 단서예요.",
 "3) 셋째 문장 확인: «In the past, many students came to school on an empty stomach.»(전에는 많은 학생이 빈속으로 학교에 왔다.) 'an empty stomach'는 빈속이에요. 전에는 안 먹고 왔어요. 지금은 그 반대예요.",
 "4) 묶기: 책상에서 음식을 다 먹는다 = 'eats'(먹는다). 'finish the food'를 한 낱말로 바꾼 것이에요."],
 "「기다린다」가 끌릴 수 있어요. 음식을 받으려면 기다려야 할 것 같거든요. 하지만 기다리는 일은 글에 나오지 않아요. 글이 말한 것은 학생들이 책상에서 음식을 다 먹는다는 것이에요.",
 [("떠난다", "지문에 없는 이야기예요. 학생들이 교실을 떠난다는 말은 없어요."),
  ("잔다", "지문에 없는 이야기예요. 자는 일은 나오지 않아요."),
  ("읽는다", "지문에 없는 이야기예요. 책을 읽는 일은 나오지 않아요."),
  ("기다린다", "지문에 없는 이야기예요. 기다리는 일은 나오지 않아요. 글이 말한 것은 음식을 다 먹는다는 것이에요."),
  ("먹는다", "둘째 문장 «Students take a plate and finish the food at their desks.»가 근거예요. 교실에서 접시를 받아 다 먹으니 거의 모든 학생이 아침에 먹어요.")])

# ---------- 24번째: 두 시간으로 늘린 호텔 아침 식사 (답 disappeared) ----------
rw(23, 1, "A hotel now serves breakfast for two hours every morning. In the past, the breakfast room was open for only forty minutes. Now guests come at different times and walk straight to a table. With the longer breakfast time, the long line at the door has ______.",
 "한 호텔은 이제 아침마다 두 시간 동안 아침 식사를 낸다. 전에는 아침 식당이 사십 분 동안만 열려 있었다. 이제 손님들은 저마다 다른 시간에 와서 곧장 식탁으로 걸어간다. 아침 식사 시간이 길어져서 문 앞의 긴 줄은 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the long line at the door has»(문 앞의 긴 줄은 ~했다). 'line'은 사람들이 선 줄이에요. 그 줄이 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Now guests come at different times and walk straight to a table.»(이제 손님들은 저마다 다른 시간에 와서 곧장 식탁으로 걸어간다.) 'walk straight to a table'(곧장 식탁으로 걸어간다)이 단서예요. 줄을 서지 않아요.",
 "3) 둘째 문장 확인: «In the past, the breakfast room was open for only forty minutes.»(전에는 아침 식당이 사십 분 동안만 열려 있었다.) 시간이 짧아서 모두 한꺼번에 몰렸어요. 그래서 줄이 길었어요.",
 "4) 묶기: 기다리지 않고 곧장 식탁으로 간다 = 줄이 'disappeared'(사라졌다). 'walk straight to a table'을 한 낱말로 바꾼 것이에요."],
 "「길어졌다」를 조심해요. 넷째 문장에 'longer'(더 긴)가 있어서 끌리거든요. 하지만 길어진 것은 아침 식사 시간이에요. 줄은 그 반대가 되었어요. 손님들이 곧장 식탁으로 가요.",
 [("두 배가 되었다", "글과 반대예요. 두 시간으로 늘어난 것은 식사 시간이고, 줄은 없어졌어요."),
  ("사라졌다", "셋째 문장 «Now guests come at different times and walk straight to a table.»이 근거예요. 손님들이 곧장 식탁으로 가니 문 앞의 긴 줄이 사라진 것이에요."),
  ("돌아왔다", "글과 반대예요. 손님들이 곧장 식탁으로 간다고 했으니 줄이 다시 생기지 않았어요."),
  ("길어졌다", "글과 반대예요. 길어진 것은 아침 식사 시간이에요. 줄은 없어졌어요."),
  ("옮겨 갔다", "지문에 없는 이야기예요. 줄이 다른 곳으로 옮겨 갔다는 말은 없어요.")])

# ---------- 25번째: 전화기를 부엌에 두고 하는 공부 (답 improved) ----------
rw(24, 3, "Leo leaves his phone in the kitchen during his study time. No messages or games can take his eyes off his books. He now reads ten pages without looking up even once. Without the phone nearby, Leo's focus on his books has clearly ______.",
 "레오는 공부하는 시간에 전화기를 부엌에 둔다. 어떤 메시지나 게임도 그의 눈을 책에서 떼어 놓지 못한다. 그는 이제 한 번도 고개를 들지 않고 열 쪽을 읽는다. 전화기가 곁에 없어서 레오가 책에 쏟는 집중은 눈에 띄게 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Leo's focus on his books has clearly»(레오가 책에 쏟는 집중은 눈에 띄게 ~했다). 'focus'는 「집중」이에요. 레오의 집중이 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «He now reads ten pages without looking up even once.»(그는 이제 한 번도 고개를 들지 않고 열 쪽을 읽는다.) 'without looking up even once'(한 번도 고개를 들지 않고)가 단서예요. 책에서 눈을 떼지 않아요.",
 "3) 둘째 문장 확인: «No messages or games can take his eyes off his books.»(어떤 메시지나 게임도 그의 눈을 책에서 떼어 놓지 못한다.) 전화기가 없으니 방해하는 것이 없어요.",
 "4) 묶기: 한 번도 고개를 들지 않고 열 쪽을 읽는다 = 집중이 'improved'(나아졌다). 셋째 문장을 한 낱말로 묶은 것이에요."],
 "「멈추었다」가 끌릴 수 있어요. 메시지와 게임이 멈추었다는 생각이 들거든요. 하지만 빈칸 앞의 말은 레오의 집중이에요. 집중이 멈추었다면 열 쪽을 내리 읽을 수 없어요.",
 [("떨어졌다", "글과 반대예요. 레오는 한 번도 고개를 들지 않고 열 쪽을 읽어요."),
  ("멈추었다", "글과 반대예요. 멈춘 것은 메시지와 게임의 방해예요. 집중은 멈추지 않았어요."),
  ("느려졌다", "글과 맞지 않아요. 집중이 약해졌다는 말은 없고, 오히려 열 쪽을 내리 읽어요."),
  ("나아졌다", "셋째 문장 «He now reads ten pages without looking up even once.»가 근거예요. 한 번도 고개를 들지 않고 열 쪽을 읽으니 집중이 나아진 것이에요."),
  ("사라졌다", "글과 반대예요. 집중이 없어졌다면 열 쪽을 내리 읽을 수 없어요.")])

# ---------- 26번째: 오후로 옮긴 길 청소 (답 stopped) ----------
rw(25, 0, "A loud cleaning truck came to one street at five every morning. Many families called the city office about the early noise. Since the change to afternoon cleaning, no family has called. Thanks to the new cleaning time, the calls about the noise have ______.",
 "시끄러운 청소차가 아침마다 다섯 시에 어느 길에 왔다. 많은 집이 이른 아침의 소음 때문에 시청에 전화했다. 청소를 오후로 바꾼 뒤로는 어느 집도 전화하지 않았다. 새 청소 시간 덕분에 소음 때문에 걸려 오던 전화는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the calls about the noise have»(소음에 대한 전화는 ~했다). 'calls'는 걸려 오는 전화예요. 그 전화가 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Since the change to afternoon cleaning, no family has called.»(청소를 오후로 바꾼 뒤로는 어느 집도 전화하지 않았다.) 'no family has called'(어느 집도 전화하지 않았다)가 단서예요.",
 "3) 둘째 문장 확인: «Many families called the city office about the early noise.»(많은 집이 이른 아침의 소음 때문에 시청에 전화했다.) 전에는 전화가 많았어요. 지금은 그 반대예요.",
 "4) 묶기: 어느 집도 전화하지 않는다 = 전화가 'stopped'(멈추었다). 'no family has called'를 한 낱말로 바꾼 것이에요."],
 "「계속되었다」를 조심해요. 청소차는 오후에도 여전히 오니까 전화도 이어질 것처럼 보일 수 있어요. 하지만 글은 어느 집도 전화하지 않았다고 했어요. 사람들이 싫어한 것은 청소가 아니라 새벽의 소음이었어요.",
 [("멈추었다", "셋째 문장 «Since the change to afternoon cleaning, no family has called.»가 근거예요. 어느 집도 전화하지 않으니 전화가 멈춘 것이에요."),
  ("늘었다", "글과 반대예요. 청소 시간을 바꾼 뒤로는 어느 집도 전화하지 않았어요."),
  ("두 배가 되었다", "글과 반대예요. 전화는 많아지지 않고 없어졌어요."),
  ("계속되었다", "글과 반대예요. 청소 시간을 바꾼 뒤로는 어느 집도 전화하지 않았어요."),
  ("퍼졌다", "지문에 없는 이야기예요. 전화가 다른 길로 퍼졌다는 말은 없어요.")])

# ---------- 27번째: 벽 옆의 느린 줄 (답 ended) ----------
rw(26, 2, "A swimming pool added a slow lane next to the wall. Slow swimmers now stay in that lane all the time. Fast swimmers no longer have to wait behind the slow ones. With the new slow lane, the problems between swimmers have ______.",
 "한 수영장이 벽 옆에 느린 사람들의 줄을 하나 더 만들었다. 천천히 헤엄치는 사람들은 이제 늘 그 줄에 있다. 빨리 헤엄치는 사람들은 더는 느린 사람들 뒤에서 기다리지 않아도 된다. 새 느린 줄 덕분에 헤엄치는 사람들 사이의 문제는 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «the problems between swimmers have»(헤엄치는 사람들 사이의 문제는 ~했다). 사람들 사이의 문제가 어떻게 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Fast swimmers no longer have to wait behind the slow ones.»(빨리 헤엄치는 사람들은 더는 느린 사람들 뒤에서 기다리지 않아도 된다.) 'no longer'(더는 ~않다)가 단서예요. 전에 있던 불편이 없어졌어요.",
 "3) 둘째 문장 확인: «Slow swimmers now stay in that lane all the time.»(천천히 헤엄치는 사람들은 이제 늘 그 줄에 있다.) 'lane'은 수영장의 줄이에요. 느린 사람과 빠른 사람이 따로 헤엄쳐요.",
 "4) 묶기: 더는 뒤에서 기다리지 않는다 = 문제가 'ended'(끝났다). 'no longer'를 한 낱말로 바꾼 것이에요."],
 "「계속되었다」를 조심해요. 수영장에는 여전히 느린 사람과 빠른 사람이 함께 있으니 문제도 그대로일 것처럼 보일 수 있어요. 하지만 글은 빠른 사람들이 더는 기다리지 않아도 된다고 했어요.",
 [("늘었다", "글과 반대예요. 빠른 사람들이 더는 기다리지 않아도 되니 문제는 많아지지 않았어요."),
  ("두 배가 되었다", "글과 반대예요. 문제는 많아지지 않고 없어졌어요."),
  ("끝났다", "셋째 문장 «Fast swimmers no longer have to wait behind the slow ones.»가 근거예요. 더는 뒤에서 기다리지 않아도 되니 사람들 사이의 문제가 끝난 것이에요."),
  ("계속되었다", "글과 반대예요. 빠른 사람들이 더는 기다리지 않아도 된다고 했어요."),
  ("퍼졌다", "지문에 없는 이야기예요. 문제가 다른 곳으로 퍼졌다는 말은 없어요.")])

# ---------- 28번째: 새 회원의 짝 (답 stay) ----------
rw(27, 2, "A tennis club gives every new member a partner with many years in the club. The partner plays tennis with the new member every single week. For the last three years, no new member has left the club. With a partner by their side, new members now ______ in the club.",
 "한 테니스 모임은 새 회원마다 모임에 여러 해 있었던 짝을 정해 준다. 그 짝은 한 주도 빠짐없이 새 회원과 테니스를 친다. 지난 삼 년 동안 모임을 떠난 새 회원은 한 명도 없다. 곁에 짝이 있어서 새 회원들은 이제 모임에 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «With a partner by their side, new members now»(곁에 짝이 있어서 새 회원들은 이제 ~한다). 짝이 생긴 새 회원들이 모임에서 어떻게 하는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «For the last three years, no new member has left the club.»(지난 삼 년 동안 모임을 떠난 새 회원은 한 명도 없다.) 'no new member has left'(떠난 새 회원이 없다)가 단서예요.",
 "3) 둘째 문장 확인: «The partner plays tennis with the new member every single week.»(그 짝은 한 주도 빠짐없이 새 회원과 테니스를 친다.) 함께 칠 사람이 늘 있으니 혼자 겉돌지 않아요.",
 "4) 묶기: 아무도 떠나지 않는다 = 'stay'(머문다). 'no new member has left'를 뒤집어 말한 것이에요."],
 "「떠난다」를 조심해요. 셋째 문장에 'left'(떠났다)가 있어서 눈에 띄거든요. 하지만 그 앞에 'no'(아무도 ~않다)가 있어요. 떠난 사람이 없다는 말이에요.",
 [("떠난다", "글과 반대예요. 지난 삼 년 동안 떠난 새 회원은 한 명도 없어요."),
  ("불평한다", "지문에 없는 이야기예요. 새 회원이 불평한다는 말은 없어요."),
  ("머문다", "셋째 문장 «For the last three years, no new member has left the club.»이 근거예요. 떠난 새 회원이 한 명도 없으니 새 회원들이 모임에 머무는 것이에요."),
  ("돈을 낸다", "지문에 없는 이야기예요. 돈을 내는 일은 나오지 않아요."),
  ("기다린다", "지문에 없는 이야기예요. 짝이 매주 함께 치니 기다릴 일이 없어요.")],
 ch={3: 'pay', 4: 'wait'})

# ---------- 29번째: 방마다 놓은 긴 의자 (답 long) ----------
rw(28, 0, "A small museum put a soft bench in every room. Visitors can now sit down and rest their tired legs. A visit to the museum now takes two hours, not one. Thanks to the benches, a visit is now twice as ______ as before.",
 "작은 박물관이 방마다 푹신한 긴 의자를 놓았다. 관람객들은 이제 앉아서 지친 다리를 쉴 수 있다. 박물관을 둘러보는 데 이제 한 시간이 아니라 두 시간이 걸린다. 긴 의자 덕분에 한 번의 관람은 이제 전보다 두 배로 ______.", [
 "1) 빈칸 문장: 넷째 문장이에요. «Thanks to the benches, a visit is now twice as»(긴 의자 덕분에 한 번의 관람은 이제 두 배로 ~하다). 'twice'(두 배)가 있어요. 무엇이 두 배가 되었는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «A visit to the museum now takes two hours, not one.»(박물관을 둘러보는 데 이제 한 시간이 아니라 두 시간이 걸린다.) 'two hours, not one'(한 시간이 아니라 두 시간)이 단서예요. 두 배가 된 것은 시간이에요.",
 "3) 둘째 문장 확인: «Visitors can now sit down and rest their tired legs.»(관람객들은 이제 앉아서 지친 다리를 쉴 수 있다.) 'bench'는 긴 의자예요. 쉴 수 있으니 더 오래 머물러요.",
 "4) 묶기: 한 시간이 두 시간이 되었다 = 두 배로 'long'(긴)하다. 'two hours, not one'을 한 낱말로 바꾼 것이에요."],
 "「붐비는」이 끌릴 수 있어요. 사람들이 오래 머물면 박물관이 붐빌 것 같거든요. 하지만 사람이 얼마나 많은지는 글에 나오지 않아요. 글이 말한 것은 한 번 둘러보는 데 걸리는 시간이에요.",
 [("긴", "셋째 문장 «A visit to the museum now takes two hours, not one.»이 근거예요. 한 시간이던 관람이 두 시간이 되었으니 두 배로 길어진 것이에요."),
  ("짧은", "글과 반대예요. 관람은 한 시간에서 두 시간으로 늘었어요."),
  ("조용한", "지문에 없는 이야기예요. 소리는 나오지 않아요."),
  ("값싼", "지문에 없는 이야기예요. 표의 값은 나오지 않아요."),
  ("붐비는", "지문에 없는 이야기예요. 사람이 얼마나 많은지는 나오지 않아요. 글이 말한 것은 걸리는 시간이에요.")])

# ---------- 30번째: 백 그램 값을 적은 가격표 (답 easily) ----------
rw(29, 2, "A market now shows the price of one hundred grams of food on every tag. Shoppers can find the cheapest pack with one quick look. In the past, they stood in front of the shelf for several minutes. With the new price tags, shoppers now choose a pack much more ______.",
 "한 가게는 이제 가격표마다 식품 백 그램의 값을 보여 준다. 손님들은 한 번 얼른 보고 가장 싼 묶음을 찾을 수 있다. 전에는 그들이 선반 앞에 몇 분씩 서 있었다. 새 가격표 덕분에 손님들은 이제 훨씬 더 ______ 묶음을 고른다.", [
 "1) 빈칸 문장: 넷째 문장이에요. «shoppers now choose a pack much more»(손님들은 이제 훨씬 더 ~ 묶음을 고른다). 'pack'은 물건 한 묶음이에요. 손님들이 어떻게 고르는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Shoppers can find the cheapest pack with one quick look.»(손님들은 한 번 얼른 보고 가장 싼 묶음을 찾을 수 있다.) 'with one quick look'(한 번 얼른 보고)이 단서예요. 힘들이지 않고 찾아요.",
 "3) 셋째 문장 확인: «In the past, they stood in front of the shelf for several minutes.»(전에는 그들이 선반 앞에 몇 분씩 서 있었다.) 전에는 고르기가 어려워서 오래 서 있었어요. 지금은 그 반대예요.",
 "4) 묶기: 한 번 보고 찾는다 = 'easily'(쉽게) 고른다. 'with one quick look'을 한 낱말로 바꾼 것이에요."],
 "「천천히」를 조심해요. 셋째 문장에 선반 앞에 몇 분씩 서 있었다는 말이 있거든요. 하지만 그 문장은 'In the past'(전에는)로 시작해요. 지금은 한 번 얼른 보고 찾아요.",
 [("드물게", "지문에 없는 이야기예요. 손님들이 물건을 고르는 일이 줄었다는 말은 없어요."),
  ("천천히", "전의 이야기예요. 선반 앞에 몇 분씩 서 있던 것은 전의 일이고, 지금은 한 번 얼른 보고 찾아요."),
  ("쉽게", "둘째 문장 «Shoppers can find the cheapest pack with one quick look.»이 근거예요. 한 번 얼른 보고 가장 싼 묶음을 찾으니 훨씬 쉽게 고르는 것이에요."),
  ("슬프게", "지문에 없는 이야기예요. 슬픈 일은 나오지 않아요."),
  ("화를 내며", "지문에 없는 이야기예요. 화가 나는 일은 나오지 않아요.")],
 ch={2: 'easily', 3: 'sadly', 4: 'angrily'})
