# -*- coding: utf-8 -*-
# 341번: 29번(어법) 레벨1 뒤 절반 — 다섯 문장(문장당 10~15낱말 · 단문) · 틀린 곳 하나. 정답 번호는 바탕 그대로, 지문·해석·풀이·해설·올바른 꼴(correctWord)을 통째로 다시 씀
AUTO_SYNC = False
E = {}
from z29rw import maker
rw = maker(E)

# 16번째
rw(15, 'pron',
   ['My father ①cooks a big dinner for our family on Saturdays.',
 '②Him makes the best noodle soup in our whole town.',
 'My cousin and I ③help him in the busy kitchen every week.',
 'He always gives ④us easy jobs like washing the vegetables.',
 '⑤We love his noodle soup more than any other food.'],
   'He',
   ['우리 아버지는 토요일마다 가족을 위해 푸짐한 저녁을 요리하신다.', '아버지는 우리 마을 전체에서 가장 맛있는 국수 수프를 만드신다.', '내 사촌과 나는 매주 북적이는 부엌에서 아버지를 돕는다.', '아버지는 늘 우리에게 채소 씻기 같은 쉬운 일을 주신다.', '우리는 어떤 다른 음식보다 아버지의 국수 수프를 좋아한다.'],
   ['주어 My father: 하나(단수) → cooks (○)', '문장의 주어 자리이니 He로 써야 해요. Him (×) → He (○)', '주어 My cousin and I: 여럿(복수) → 동사 원형 help (○)', 'gives 뒤(~에게 자리): us (○)', '문장의 주어 자리: We (○)'],
   'noodle 국수 / soup 수프 / kitchen 부엌 / vegetable 채소')

# 17번째
rw(16, 'modal',
   ['Tomorrow, my friends and I will ①ride our bikes to the big park.',
 'Kate can ②carry all the water bottles in her blue bag.',
 'Her father will ③bring some fruit and bread for lunch.',
 'Jun cannot ④ride fast on the hill with a broken bike.',
 'He can ⑤walks to the park with his own small dog.'],
   'walk',
   ['내일 내 친구들과 나는 큰 공원까지 자전거를 타고 갈 것이다.', '케이트는 파란 가방에 물병을 모두 담아 나를 수 있다.', '그녀의 아버지는 점심으로 먹을 과일과 빵을 가져오실 것이다.', '준은 고장 난 자전거로는 언덕에서 빨리 달릴 수 없다.', '준은 자기 작은 개와 함께 공원까지 걸어갈 수 있다.'],
   ['will 뒤: 동사 원형 ride (○)', 'can 뒤: 동사 원형 carry (○)', 'will 뒤: 동사 원형 bring (○)', 'cannot 뒤: 동사 원형 ride (○)', 'can 뒤에는 주어가 누구든 동사 원형을 써야 해요. walks (×) → walk (○)'],
   'ride 타다 / bottle 병 / broken 고장 난 / hill 언덕')

# 18번째
rw(17, 'sv',
   ['My aunt ①owns a small bakery near the train station.',
 'The bakery ②are always full of people in the morning.',
 'Her fresh bread ③smells wonderful to everyone on the street.',
 'Two workers ④make cakes and cookies in the back room.',
 'The small cookies ⑤are very cheap for students after school.'],
   'is',
   ['우리 이모는 기차역 근처에 작은 빵집을 가지고 계신다.', '그 빵집은 아침마다 늘 사람들로 가득하다.', '이모의 갓 구운 빵은 길에 있는 모든 사람에게 아주 좋은 냄새가 난다.', '직원 두 명이 뒷방에서 케이크와 쿠키를 만든다.', '작은 쿠키는 방과 후 학생들에게 아주 싸다.'],
   ['주어 My aunt: 하나(단수) → owns (○)',
 '주어 The bakery: 하나(단수)이니 be동사는 is예요. are (×) → is (○)',
 '주어 Her fresh bread: 하나로 다루는 말 → smells (○)',
 '주어 Two workers: 여럿(복수) → 동사 원형 make (○)',
 '주어 The small cookies: 여럿(복수) → are (○)'],
   'bakery 빵집 / station 역 / own 가지고 있다 / cheap 싼')

# 19번째
rw(18, 'sv',
   ['My school ①has a large garden behind the main building.',
 'Many students ②grow tomatoes and peppers there in the spring.',
 'Our teacher ③have a small room for the garden tools.',
 'The students ④use these tools after their last lesson on Wednesday.',
 'Every vegetable from the garden ⑤tastes better after hard work.'],
   'has',
   ['우리 학교에는 본관 건물 뒤에 큰 정원이 있다.', '많은 학생이 봄에 그곳에서 토마토와 고추를 기른다.', '우리 선생님은 정원 도구를 두는 작은 방을 가지고 계신다.', '학생들은 수요일 마지막 수업 뒤에 이 도구들을 쓴다.', '정원에서 난 채소는 모두 열심히 일한 뒤에 더 맛있다.'],
   ['주어 My school: 하나(단수) → has (○)',
 '주어 Many students: 여럿(복수) → 동사 원형 grow (○)',
 '주어 Our teacher: 하나(단수)이니 have가 아니라 has예요. have (×) → has (○)',
 '주어 The students: 여럿(복수) → 동사 원형 use (○)',
 '주어 Every vegetable: 하나(단수) → tastes (○)'],
   'garden 정원 / vegetable 채소 / tool 도구 / lesson 수업')

# 20번째
rw(19, 'pron',
   ['Sora and her little brother ①walk to school together every day.',
 '②Her carries both school bags up the long hill on rainy days.',
 'The little boy ③thanks her with a big smile at the gate.',
 '④They stop at a small shop near the school gate.',
 'The kind old owner gives ⑤them some free candy on Fridays.'],
   'She',
   ['소라와 소라의 어린 남동생은 날마다 함께 걸어서 학교에 간다.', '소라는 비 오는 날 책가방 두 개를 모두 들고 긴 언덕을 오른다.', '그 어린 소년은 문 앞에서 환한 미소로 그녀에게 고마워한다.', '그들은 학교 문 근처의 작은 가게에 들른다.', '친절한 나이 많은 주인은 금요일마다 그들에게 공짜 사탕을 조금 준다.'],
   ['주어 Sora and her little brother: 여럿(복수) → 동사 원형 walk (○)', '문장의 주어 자리이니 She로 써야 해요. Her (×) → She (○)', '주어 The little boy: 하나(단수) → thanks (○)', '문장의 주어 자리: They (○)', 'gives 뒤(~에게 자리): them (○)'],
   'carry 나르다 / hill 언덕 / gate 문 / candy 사탕')

# 21번째
rw(20, 'past',
   ['Last night, a strong wind ①blew across our small town for hours.',
 'Heavy rain ②fell on the old roof of our house until midnight.',
 'My little sister ③hid under a thick blanket on my bed.',
 'I ④hold her hand for a long time that night.',
 'The storm ⑤ended at six on the next sunny morning.'],
   'held',
   ['어젯밤 강한 바람이 몇 시간 동안 우리 작은 마을에 불었다.', '굵은 비가 자정까지 우리 집의 낡은 지붕 위로 쏟아졌다.', '내 여동생은 내 침대 위의 두꺼운 담요 속에 숨었다.', '나는 그날 밤 오랫동안 동생의 손을 잡아 주었다.', '폭풍은 다음 날 맑은 아침 여섯 시에 끝났다.'],
   ['지난밤(Last night) 일: 과거형 blew (○)', '지난밤 일: 과거형 fell (○)', '지난밤 일: 과거형 hid (○)', '지난밤 일이니 과거형으로 써야 해요. hold (×) → held (○)', '지난 일: 과거형 ended (○)'],
   'wind 바람 / roof 지붕 / blanket 담요 / storm 폭풍')

# 22번째
rw(21, 'sv',
   ['My baby sister ①sleeps for ten hours every night in her bed.',
 'She ②wakes up with a loud cry at six in the morning.',
 'My mother ③gives her warm milk in a small bottle.',
 'My father ④plays soft music for her in the quiet room.',
 'The baby ⑤reach for her toys with both small hands.'],
   'reaches',
   ['내 아기 여동생은 밤마다 자기 침대에서 열 시간을 잔다.', '동생은 아침 여섯 시에 큰 울음소리와 함께 깬다.', '어머니는 동생에게 작은 병에 담은 따뜻한 우유를 주신다.', '아버지는 조용한 방에서 동생을 위해 부드러운 음악을 틀어 주신다.', '아기는 작은 두 손으로 장난감을 향해 손을 뻗는다.'],
   ['주어 My baby sister: 하나(단수) → sleeps (○)',
 '주어 She: 하나(단수) → wakes (○)',
 '주어 My mother: 하나(단수) → gives (○)',
 '주어 My father: 하나(단수) → plays (○)',
 '주어 The baby: 하나(단수)이니 동사에 -s(-es)를 붙여야 해요. reach (×) → reaches (○)'],
   'cry 울음 / bottle 병 / reach 손을 뻗다 / quiet 조용한')

# 23번째
rw(22, 'sv',
   ['My two cousins ①lives in a big city far from my town.',
 'Their new house in the city ②has a big window in every room.',
 'Every month, they ③visit us by train with their parents.',
 'My aunt ④brings us fresh cheese from the city market.',
 'We ⑤eat it with warm bread at home after each visit.'],
   'live',
   ['내 사촌 둘은 우리 마을에서 멀리 떨어진 큰 도시에 산다.', '도시에 있는 그들의 새 집에는 방마다 큰 창문이 있다.', '그들은 매달 부모님과 함께 기차로 우리를 찾아온다.', '이모는 도시 시장에서 산 신선한 치즈를 우리에게 가져오신다.', '우리는 방문이 끝날 때마다 집에서 그것을 따뜻한 빵과 함께 먹는다.'],
   ['주어 My two cousins: 여럿(복수)이니 동사에 -s를 붙이지 않아요. lives (×) → live (○)',
 '주어 Their new house: 하나(단수) → has (○)',
 '주어 they: 여럿(복수) → 동사 원형 visit (○)',
 '주어 My aunt: 하나(단수) → brings (○)',
 '주어 We: 여럿(복수) → 동사 원형 eat (○)'],
   'cousin 사촌 / market 시장 / cheese 치즈 / visit 방문')

# 24번째
rw(23, 'past',
   ['I ①visit my grandparents in their country house last winter.',
 'We ②built a big snowman in the front yard that week.',
 'My grandfather ③made it a hat from an old newspaper.',
 'My grandmother ④took many photos of us in the white snow.',
 'That night, we all ⑤drank hot tea by the warm fire.'],
   'visited',
   ['나는 지난겨울 시골집에 계신 조부모님을 찾아뵈었다.', '우리는 그 주에 앞마당에서 큰 눈사람을 만들었다.', '할아버지는 낡은 신문지로 눈사람에게 씌울 모자를 만들어 주셨다.', '할머니는 하얀 눈 속의 우리를 사진으로 많이 찍어 주셨다.', '그날 밤 우리는 모두 따뜻한 불가에서 뜨거운 차를 마셨다.'],
   ['지난겨울(last winter) 일이니 과거형으로 써야 해요. visit (×) → visited (○)', '지난 일: 과거형 built (○)', '지난 일: 과거형 made (○)', '지난 일: 과거형 took (○)', '지난 일: 과거형 drank (○)'],
   'grandparents 조부모님 / snowman 눈사람 / newspaper 신문(지) / fire 불')

# 25번째
rw(24, 'modal',
   ['Our science club ①meets every Thursday after school in room ten.',
 'Members can ②uses the new computers on the big table in the room.',
 'New members must always ③ask the teacher for help first.',
 'Everyone should ④wear a white coat in the science room.',
 'Next month, our club will ⑤visit a big science museum together.'],
   'use',
   ['우리 과학 동아리는 목요일마다 방과 후에 10호실에서 모인다.', '회원들은 그 방의 큰 탁자 위에 있는 새 컴퓨터를 쓸 수 있다.', '새 회원은 늘 먼저 선생님께 도움을 청해야 한다.', '모두가 과학실에서 흰 가운을 입어야 한다.', '다음 달에 우리 동아리는 함께 큰 과학관에 갈 것이다.'],
   ['주어 Our science club: 하나(단수) → meets (○)', 'can 뒤에는 주어가 누구든 동사 원형을 써야 해요. uses (×) → use (○)', 'must 뒤: 동사 원형 ask (○)', 'should 뒤: 동사 원형 wear (○)', 'will 뒤: 동사 원형 visit (○)'],
   'club 동아리 / member 회원 / museum 박물관(과학관) / coat 가운')

# 26번째
rw(25, 'plural',
   ['At the zoo, I see four ①monkey in the tall tree near the gate.',
 'One small ②monkey eats a yellow banana on a high branch.',
 'Two ③babies hold on to their mother with both arms.',
 'Many happy ④visitors take pictures of the monkeys all day long.',
 'Each ⑤monkey has its own name on a sign by the fence.'],
   'monkeys',
   ['동물원에서 나는 문 근처의 키 큰 나무에 원숭이 네 마리가 있는 것을 본다.', '작은 원숭이 한 마리가 높은 가지에서 노란 바나나를 먹는다.', '아기 원숭이 두 마리가 두 팔로 어미에게 매달려 있다.', '많은 행복한 방문객이 하루 종일 원숭이들의 사진을 찍는다.', '원숭이마다 울타리 옆 안내판에 자기 이름이 있다.'],
   ['four 뒤이니 여럿을 나타내는 -s를 붙여야 해요. monkey (×) → monkeys (○)', 'One 뒤: 하나 → monkey (○)', 'Two 뒤: 여럿 → babies (○)', 'Many 뒤: 여럿 → visitors (○)', 'Each 뒤: 하나 → monkey (○)'],
   'zoo 동물원 / banana 바나나 / branch 나뭇가지 / fence 울타리')

# 27번째
rw(26, 'pron',
   ['Tom and ①I are in the same class this year.',
 '②Us sit together in the last row near the window.',
 'Our kind teacher knows ③us very well after many long months.',
 '④She often gives us hard questions about math on Fridays.',
 'Tom always helps ⑤me with the hard ones after school.'],
   'We',
   ['톰과 나는 올해 같은 반이다.', '우리는 창문 근처 맨 뒷줄에 함께 앉는다.', '우리의 친절한 선생님은 여러 달이 지난 뒤 우리를 아주 잘 아신다.', '선생님은 금요일마다 우리에게 어려운 수학 문제를 자주 내 주신다.', '톰은 방과 후에 내가 어려운 문제를 푸는 것을 늘 도와준다.'],
   ['Tom and 뒤의 주어 자리: I (○)', '문장의 주어 자리이니 We로 써야 해요. Us (×) → We (○)', 'knows 뒤(~을/를 자리): us (○)', '문장의 주어 자리: She (○)', 'helps 뒤(~을/를 자리): me (○)'],
   'same 같은 / row 줄 / question 문제 / month 달')

# 28번째
rw(27, 'pron',
   ['①Me like swimming in the big pool with my cousin Mia.',
 '②She teaches me new tricks in the water every weekend.',
 'Our new coach tells ③us to practice hard every night.',
 '④We swim together in the same lane at the city pool.',
 'My mother watches ⑤me from the seats near the pool.'],
   'I',
   ['나는 사촌 미아와 함께 큰 수영장에서 수영하기를 좋아한다.', '미아는 주말마다 물속에서 나에게 새로운 요령을 가르쳐 준다.', '새 코치는 우리에게 밤마다 열심히 연습하라고 말한다.', '우리는 시립 수영장의 같은 레인에서 함께 수영한다.', '어머니는 수영장 근처 관람석에서 나를 지켜보신다.'],
   ['문장의 주어 자리이니 I로 써야 해요. Me (×) → I (○)', '문장의 주어 자리: She (○)', 'tells 뒤(~에게 자리): us (○)', '문장의 주어 자리: We (○)', 'watches 뒤(~을/를 자리): me (○)'],
   'pool 수영장 / trick 요령 / coach 코치 / lane 레인')

# 29번째
rw(28, 'plural',
   ['I have two ①box of colored pencils in my school bag.',
 'Each ②box holds twelve long pencils in many different colors.',
 'I use red and blue ③pencils for my science notes.',
 'My best friend borrows three ④pencils from me each week.',
 'She always gives back every ⑤pencil on the next day.'],
   'boxes',
   ['내 책가방에는 색연필이 든 상자가 두 개 있다.', '상자마다 여러 색의 긴 연필이 열두 자루씩 들어 있다.', '나는 과학 공책에 빨간색과 파란색 연필을 쓴다.', '내 가장 친한 친구는 매주 나에게서 연필 세 자루를 빌린다.', '그 친구는 빌린 연필을 늘 하나도 빠짐없이 다음 날 돌려준다.'],
   ['two 뒤이니 여럿을 나타내는 꼴로 써야 해요(box는 -es). box (×) → boxes (○)', 'Each 뒤: 하나 → box (○)', '빨간 연필과 파란 연필, 여럿 → pencils (○)', 'three 뒤: 여럿 → pencils (○)', 'every 뒤: 하나 → pencil (○)'],
   'colored pencil 색연필 / borrow 빌리다 / science note 과학 공책 / give back 돌려주다')

# 30번째
rw(29, 'there',
   ['There ①is two parks near the school in my town.',
 'One park ②has a small pond with many white ducks.',
 'The other park ③has a big playground for little children.',
 'Many families ④visit these two parks on warm sunny days.',
 'My little brother ⑤runs around the pond for a long time.'],
   'are',
   ['우리 마을에는 학교 근처에 공원이 두 개 있다.', '한 공원에는 흰 오리가 많이 사는 작은 연못이 있다.', '다른 공원에는 어린이를 위한 큰 놀이터가 있다.', '많은 가족이 날씨 좋은 따뜻한 날 이 두 공원을 찾는다.', '내 어린 남동생은 오랫동안 연못 둘레를 뛰어다닌다.'],
   ['There ~ 문장은 뒤에 오는 two parks가 주어예요. 여럿(복수)이니 are로 써야 해요. is (×) → are (○)',
 '주어 One park: 하나(단수) → has (○)',
 '주어 The other park: 하나(단수) → has (○)',
 '주어 Many families: 여럿(복수) → 동사 원형 visit (○)',
 '주어 My little brother: 하나(단수) → runs (○)'],
   'pond 연못 / duck 오리 / playground 놀이터 / family 가족')
