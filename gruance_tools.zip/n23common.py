# -*- coding: utf-8 -*-
# 23번(주제) 레벨9 선택지를 수능식 명사구로 바꾸기 — 공통 도우미 (203번~, 선생님 승인: 202번 시범을 보시고 "계속")
#   R(E, n, ch, ko, subs=None, walk_sub=None, lv='9')   — 레벨6~8은 lv='8' 따위로(206번~)
#     ch   : {자리: 새 선택지}            — 정답 자리도 바뀌므로 ans_ok
#     ko   : {자리: 새 우리말 해석}       — 선택지별 해설 맨 앞 괄호 속
#     subs : {자리: [(옛 조각, 새 조각)]} — 해설 글 안에서 옛 선택지의 영어를 옮긴 대목
#     walk_sub : [(옛 조각, 새 조각)]     — 풀이의 「묶기」 줄·【끌리는 오답】에서 옛 선택지의 영어를 옮긴 대목
# 해설 글의 나머지는 한 글자도 건드리지 않음(176번에 쓴 것 그대로)
import re, sys; sys.path.insert(0, '.')
from lib import load as _load
_s, _tb, _te = _load()
def R(E, n, ch, ko, subs=None, walk_sub=None, lv='9'):
    it = _tb['23'][lv][n]; ex = _te['23'][lv][n]; subs = subs or {}
    assert set(ch) == set(ko), (n, '선택지와 해석의 자리가 다름')
    cn = {}
    for k in ch:
        m = re.match(r"^(정답입니다\. )?'(.*?)' \((.*?)\) — (.*)$", ex['cn'][k], re.S)
        assert m and m.group(2) == it['choices'][k], (n, k, '해설 머리가 선택지와 다름')
        assert bool(m.group(1)) == (k == it['answer']), (n, k)
        body = m.group(4)
        for a, b in subs.get(k, []):
            assert body.count(a) >= 1, (n, k, '해설에 그 조각이 없음', a); body = body.replace(a, b)
        cn[k] = (m.group(1) or '') + "'%s' (%s) — %s" % (ch[k], ko[k], body)
    for k in subs: assert k in ch, (n, k, '선택지를 바꾸지 않은 자리의 해설을 고치려 함')
    for a, b in (walk_sub or []): assert ex['walk'].count(a) == 1, (n, '풀이에 그 조각이 없거나 여럿', a)
    assert ('23', lv, n) not in E
    E[('23', lv, n)] = {'ch': dict(ch), 'ans_ok': True, 'cn': cn, 'walk_sub': list(walk_sub or [])}
