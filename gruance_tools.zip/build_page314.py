# -*- coding: utf-8 -*-
# 314번: 측정표 페이지에 넣을 자료를 만듦 → page_data.json
import json, statistics as st
from verdict314 import R, I, ORDER, NAME, GROUP, judge, kinds
def clip(t, n=230): return t if len(t) <= n else t[:n - 1].rstrip() + '…'
def samples(T, L):
    lv = int(L); items = I[T][L]; fit = []; unfit = []
    allS = [(n + 1, a) for n, it in enumerate(items) for a in it['sents']]
    def tag(a): return ' · '.join(kinds(a) or ['단문']) + ' · %d낱말' % a['n']
    def pick(pool, k, key=None):
        pool = sorted(pool, key=key) if key else pool
        seen = set(); out = []
        for n, a in pool:
            if n in seen: continue
            seen.add(n); out.append({'n': n, 't': clip(a['text']), 'g': tag(a)})
            if len(out) >= k: break
        return out
    if lv == 1:
        fit = pick([(n, a) for n, a in allS if not kinds(a) and 10 <= a['n'] <= 15], 2)
        unfit = pick([(n, a) for n, a in allS if kinds(a)], 2, key=lambda x: -len(kinds(x[1])) * 100 - x[1]['n']) + pick([(n, a) for n, a in allS if a['n'] < 8], 2, key=lambda x: x[1]['n'])
    elif lv == 2:
        fit = pick([(n, a) for n, a in allS if a['coord'] and not (a['sub'] or a['rel'] or a['rel0'] or a['ptc'] or a['noun']) and 10 <= a['n'] <= 15], 2)
        unfit = pick([(n, a) for n, a in allS if a['sub'] or a['rel'] or a['rel0'] or a['ptc'] or a['noun']], 2, key=lambda x: -len(kinds(x[1])) * 100 - x[1]['n']) + pick([(n, a) for n, a in allS if a['n'] < 8], 1, key=lambda x: x[1]['n'])
    elif lv == 3:
        fit = pick([(n, a) for n, a in allS if a['sub'] and not (a['rel'] or a['rel0']) and 10 <= a['n'] <= 15], 2)
        unfit = pick([(n, a) for n, a in allS if a['rel'] or a['rel0']], 2, key=lambda x: -x[1]['n']) + pick([(n, a) for n, a in allS if a['n'] < 8], 1, key=lambda x: x[1]['n'])
    else:
        want = {4: lambda a: a['rel'], 5: lambda a: a['ptc'], 6: lambda a: a['ptc'], 7: lambda a: a['rel0'] or any('+' in p for p in a['ptc']),
                8: lambda a: len(kinds(a)) >= 3, 9: lambda a: a['n'] >= 25 and len(kinds(a)) >= 2}[lv]
        fit = pick([(n, a) for n, a in allS if want(a)], 2, key=lambda x: -x[1]['n'] if lv >= 8 else x[1]['n'])
        lack = [(n + 1, it) for n, it in enumerate(items) if not any(want(a) for a in it['sents'])]
        for n, it in lack[:2]:
            a = max(it['sents'], key=lambda a: a['n'])
            unfit.append({'n': n, 't': clip(a['text']), 'g': tag(a) + ' (이 문항에서 가장 긴 문장)'})
    return fit, unfit
KEYS = ['words_per_item', 'sent_per_item', 'wps', 'p10_15', 'p_lt8', 'p25', 'simple', 'coord', 'sub', 'noun', 'rel', 'ptc', 'it_coord', 'it_sub', 'it_rel', 'it_rel_any', 'it_rel0', 'it_ptc', 'it_pv', 'it_inv',
        'clauses', 'deep2', 'acad_per_100', 'it_acad1', 'it_acad2', 'it_acad3', 'zipf_lt35', 'out_basic', 'mix3', 'hi2', 'hi3', 'it_ell']
cells = {}
for T in ORDER:
    cells[T] = {}
    for L in '123456789':
        r, v, notes = judge(T, L); fit, unfit = samples(T, L)
        cells[T][L] = {'v': v, 'notes': notes, 'm': {k: r[k] for k in KEYS}, 'fit': fit, 'unfit': unfit}
def avg(types, k): return [round(st.mean(R[T][l][k] for T in types), 1) for l in '123456789']
EXPO = [T for T in ORDER if GROUP[T] == 'expo']; NARR = [T for T in ORDER if GROUP[T] == 'narr']
ladder = {g: {k: avg(ts, k) for k in ('wps', 'clauses', 'simple', 'acad_per_100', 'zipf_lt35', 'out_basic')} for g, ts in (('expo', EXPO), ('narr', NARR))}
counts = {l: {v: sum(1 for T in ORDER if cells[T][l]['v'] == v) for v in ('ok', 'part', 'off', 'na')} for l in '123456789'}
json.dump({'order': ORDER, 'name': NAME, 'group': GROUP, 'cells': cells, 'ladder': ladder, 'counts': counts}, open('page_data.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print(len(open('page_data.json', encoding='utf-8').read()), counts)
