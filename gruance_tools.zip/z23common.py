# -*- coding: utf-8 -*-
# 23번(주제) 해설 두텁게 — 레벨8용 공통 도우미 (209번~)
#   mk = maker(E, lv='8')
#   mk(n, 정답 자리(0~4), [적용 네 줄], 끌리는 오답, [까닭 × 5])
# - 꼴은 레벨9(176번)와 같음: 【주제 찾기 요령】 네 줄 + 【이 문제에 적용】 1) 되풀이 2) 꺾이는 곳 3) 끝 문장 4) 묶기 + 【끌리는 오답】
# - 선택지 영어와 우리말 해석(해설 머리)은 지금 있는 것을 그대로 가져옴. 아직 GitHub에 안 올라간 명사구 수정안(edits_N8.py)이
#   폴더에 있으면 그 선택지·해석을, 없으면 바탕의 것을 씀 → 해설 머리가 늘 지금의 선택지와 같음
# - 원고의 «…»는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜
import re, sys, os, importlib; sys.path.insert(0, '.')
from lib import load as _load
_s, _tb, _te = _load()
PAT = r"^(정답입니다\. )?'(.*?)' \((.*?)\) — (.*)$"
TIP = ("【주제 찾기 요령】\n"
       "첫째, 같은 생각이 모양만 바꿔 되풀이되는 곳을 찾습니다. 가장 많이 되풀이된 생각이 주제입니다.\n"
       "둘째, 흐름이 꺾이는 말(but, yet, not A but B) 뒤가 글쓴이의 생각입니다.\n"
       "셋째, 끝까지 읽습니다. 주제가 마지막 문장에만 나오는 글도 있습니다.\n"
       "넷째, 되풀이된 생각을 다른 낱말로 묶은 선택지를 고릅니다. 지문 낱말이 그대로 들어 있다고 고르지 않습니다.")
HEADS = ('1) 되풀이:', '2) 꺾이는 곳:', '3) 끝 문장:', '4) 묶기:')
def _q(x): return x.replace('«', '"').replace('»', '"')
def current(lv):
    """지금의 선택지와 해설 머리(우리말 해석): 바탕 + (폴더에 있으면) 명사구 수정안"""
    ch = {n: list(it['choices']) for n, it in enumerate(_tb['23'][lv])}
    ko = {n: [re.match(PAT, c, re.S).group(3) for c in ex['cn']] for n, ex in enumerate(_te['23'][lv])}
    name = 'edits_N' + lv
    if os.path.exists(name + '.py'):
        for (t, l, n), ed in importlib.import_module(name).E.items():
            if (t, l) != ('23', lv): continue
            for k, v in ed.get('ch', {}).items(): ch[n][k] = v
            for k, v in ed.get('cn', {}).items(): ko[n][k] = re.match(PAT, v, re.S).group(3)
    return ch, ko
def maker(E, lv='8'):
    CH, KO = current(lv)
    def mk(n, ans, steps, traps, why, kofix=None):
        # kofix: 해설 머리의 우리말 해석이 영어 선택지와 어긋난 것을 바로잡을 때 {자리: '새 해석'}
        it = _tb['23'][lv][n]
        for kk, vv in (kofix or {}).items(): KO[n][kk] = vv
        assert it['answer'] == ans, ('원고의 정답 자리가 문항과 다름', n, it['answer'], ans)
        assert len(why) == 5 and len(steps) == 4, (n, '개수')
        assert all(s.startswith(h) for s, h in zip(steps, HEADS)), (n, '적용 줄의 머리말')
        out = {}
        for k, w in enumerate(why):
            assert '정답' not in w, (n, k, '까닭에 "정답"이라는 말')
            out[k] = ("정답입니다. " if k == ans else "") + "'%s' (%s) — %s" % (CH[n][k], KO[n][k], _q(w))
        assert ('23', lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[('23', lv, n)] = {'walk': TIP + "\n\n【이 문제에 적용】\n" + "\n".join(_q(x) for x in steps) + "\n\n【끌리는 오답】\n" + _q(traps), 'cn': out}
    return mk
