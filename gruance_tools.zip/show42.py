# -*- coding: utf-8 -*-
# 42번 읽기: python3 show42.py 7 0 10
import sys; sys.path.insert(0, '.')
from lib import *
lv, a, b = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
s, tb, te = load()
for n in range(a, b):
    it = tb['42'][lv][n]
    print('=====', n + 1, 'ans', 'abcde'[it['answer']]); print(it['text'].replace('\n\n', '\n'))
