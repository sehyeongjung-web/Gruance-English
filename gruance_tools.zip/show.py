# -*- coding: utf-8 -*-
# 빈칸 문항(31~34번) 읽기: python3 show.py 31 8 10 20  → 11~20번째의 지문·선택지·옛 해설 속 선택지 해석
import sys, re; sys.path.insert(0, '.')
from lib import *
t, lv, a, b = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
s, tb, te = load()
for n in range(a, b):
    it = tb[t][lv][n]; ex = te[t][lv][n]
    print('=====', n + 1, '정답', it['answer'], '(%d낱말)' % len(it['text'].split())); print(it['text'])
    for k, c in enumerate(it['choices']):
        m = re.match(r"(?:정답입니다\. )?'([^']*)'", ex['cn'][k]); ko = m.group(1) if m else ''
        print('   %s%d %s  ‖ %s' % ('*' if k == it['answer'] else ' ', k, c, ko))
