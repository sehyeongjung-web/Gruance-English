#!/bin/bash
# 한 묶음 끝내기: bash fin.sh "<수정안 목록>" <유형> <레벨>   → 만들기 + 자체 검사 + 종합 점검(간추려 보여 줌)
cd /home/claude/work
python3 build.py "$1" out/index.html > /tmp/b.txt 2>&1
python3 -c "
t=open('/tmp/b.txt',encoding='utf-8',errors='replace').read()
print('\n'.join(l for l in t.split('\n') if '수정 문항' in l or 'Error' in l or 'ssert' in l or 'Traceback' in l)); print(t[-700:] if 'Traceback' in t else '')"
python3 zcheck31.py $2 $3 > /tmp/z.txt 2>&1; python3 -c "print(open('/tmp/z.txt',encoding='utf-8',errors='replace').read()[:2500])"
python3 check_all.py > /tmp/c.txt 2>&1; python3 -c "
t=open('/tmp/c.txt',encoding='utf-8',errors='replace').read(); i=t.find('② 바탕'); k=t.find('③'); print(t[i:k][:600]); print(t[k:][:330])"
