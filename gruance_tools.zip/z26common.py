# -*- coding: utf-8 -*-
# 366번: 26번(내용 일치) 레벨1 — 공통 도우미 (z24common을 본뜸)
#   rw(n, 정답 자리, 지문(다섯 문장), [보기 다섯], [문장마다 한글 해석 다섯], 풀이(비튼 곳), 낱말)
# 해설의 꼴은 26번이 써 오던 꼴(① 내용 일치 요령 → ② 정답 보기와 관련된 문장 → ③ 나머지는 맞음 → 📌 낱말)을 따르고,
# 보기마다 「'보기' — 본문과 맞아요. "영어 문장" (한글)」로 씀(정답은 「정답이에요! … 본문과 맞지 않아요. 풀이」). 말끝은 「~어요」
import sys, re; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
def maker(E, T='26', LV='1'):
    def rw(n, ans, text, choices, ko_s, why, words):
        it = _tb[T][LV][n]
        assert it['answer'] == ans, (n, '정답 자리가 문항과 다름')
        assert len(choices) == 5 == len(set(choices)) == len(ko_s), n
        sents = [s.strip() for s in re.split(r'(?<=[.?!])\s+', text)]
        assert len(sents) == 5, (n, '문장 수', len(sents))
        assert all(c.endswith('다') for c in choices), (n, '보기는 「~다」로 끝남')   # 아래 「~와」 조사가 맞으려면 받침 없는 끝(다)이어야 함
        assert '정답' not in why, (n, '풀이에 정답이라는 말')
        for q in re.findall(r"'([A-Za-z][^']*)'", why): assert q.lower() in sents[ans].lower(), (n, '풀이의 영어가 비튼 문장에 없음', q)
        walk = ("① 내용 일치 문제는 선택지를 하나씩 본문 문장과 맞춰 봐요. 이 문제는 본문과 맞지 않는 것을 찾아야 해요.\n"
                "② 선택지 '%s'와 관련된 문장을 보세요.\n\"%s\" (%s)\n→ %s\n"
                "③ 나머지 네 선택지는 모두 본문과 맞아요. 그러니까 정답은 이 선택지예요 → '%s'\n📌 낱말: %s") % (choices[ans], sents[ans], ko_s[ans].strip(), why, choices[ans], words)
        out = []
        for k in range(5):
            if k == ans: out.append("정답이에요! '%s' — 본문과 맞지 않아요. %s" % (choices[k], why))
            else: out.append("'%s' — 본문과 맞아요. \"%s\" (%s)" % (choices[k], sents[k], ko_s[k].strip()))
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(choices), 'ko': ' '.join(x.strip() for x in ko_s), 'walk': walk, 'cn': out}}
    return rw
