#!/bin/bash
# 358번: 34번 레벨1(단문 · 정답 긴 구가 글에 그대로 나오는 꼴) — 원고에서 수정안 만들기 → 조사 → 빌드 (바탕 5c14ac4 위에 X74만)
cd /home/claude/work
python3 draft/gen74.py a && python3 draft/gen74.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X74a.py pending/edits_X74b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X74a,edits_X74b out/index.html | tail -3
