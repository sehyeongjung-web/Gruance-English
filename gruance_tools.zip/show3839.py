# -*- coding: utf-8 -*-
# 38-39번 읽기: python3 show3839.py 7 0 10  (삽입 문장과 조각 S0~S5)
import sys; sys.path.insert(0, '.')
from lib import *
from z5common import seg
lv, a, b = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
s, tb, te = load()
for n in range(a, b):
    it = tb['38_39'][lv][n]; ins, S = seg(it['text'])
    print('=====', n + 1, '답', it['answer'] + 1); print('  [삽입]', ins)
    for i, x in enumerate(S): print('  S%d: %s' % (i, x))
