# -*- coding: utf-8 -*-
# 31~34번(빈칸) 레벨9 두텁게 — 자체 엄격 검사 (verify_explain보다 엄함)
#   python3 zcheck31.py 31        (유형 코드. 기본 31)
import re, sys; sys.path.insert(0, '.')
from lib import *
from lowstyle import has_nida
T = sys.argv[1] if len(sys.argv) > 1 else '31'
LV = sys.argv[2] if len(sys.argv) > 2 else '9'   # 226번: 레벨 인자 — python3 zcheck31.py 31 8
s, tb, te = load('out/index.html'); s0, tb0, te0 = load()
KO_FIX9 = {('32', 18): ('그 악기를 바꿔 놓는데', '그 도구를 바꿔 놓는데')}   # 187번: instrument를 「악기」로 옮긴 것(이 글의 bow는 쏘는 활)
ITEM_FIX9 = {('31', 0), ('31', 27), ('32', 29), ('33', 2), ('33', 27), ('34', 13), ('34', 18)}   # 188번: 31번 1번째 지문 늘림·28번째 오답 앞뒤 바꿈(승인), 32번 30번째 오답 하나 바꿈 / 190번: 33번 3번째 오답 하나 바꿈(승인) / 192번: 33번 28번째 오답 하나 바꿈 / 194번: 34번 14·19번째 오답 하나씩 바꿈
ITEM_FIX8 = {('31', 18), ('32', 8), ('32', 16), ('32', 22), ('33', 22), ('33', 24), ('34', 8)}   # 227번: 31번 19번째 오답 하나 바꿈 / 228번: 32번 9번째 오답 하나 바꿈   # 레벨8에서 지문·오답을 고친 문항(인계문서에 적은 것만): (유형, 몇째-1)
KO_FIX8 = {}
ITEM_FIX7 = {('31', 3), ('31', 6), ('31', 21), ('32', 8), ('32', 24), ('32', 26), ('33', 5), ('33', 6), ('33', 14), ('33', 15), ('34', 3), ('34', 7), ('34', 11), ('34', 13), ('34', 14), ('34', 15), ('34', 21)}   # 레벨7에서 지문·오답을 고친 문항(인계문서에 적은 것만) — 239번: 31번 4번째(지문에 한 구절 보탬)·7번째(오답 하나)
KO_FIX7 = {}
ITEM_FIX6 = {('33', 5), ('33', 20), ('33', 25), ('34', 3), ('34', 25), ('32', 2), ('32', 4), ('32', 10), ('32', 14), ('31', 12), ('31', 24)}   # 257번: 레벨6 검토에서 고친 문항
ITEM_FIX5 = {('31', 22), ('32', 6), ('32', 7), ('32', 16), ('32', 19), ('32', 8), ('32', 10), ('32', 12), ('32', 17), ('32', 20), ('32', 21), ('32', 24), ('32', 25), ('33', 6), ('33', 13), ('33', 14), ('33', 20), ('33', 21), ('33', 23), ('33', 27), ('34', 3), ('34', 4), ('34', 7), ('34', 8), ('34', 11), ('34', 14), ('34', 16), ('34', 17), ('34', 19)}   # 267번: 레벨5 검토에서 고친 문항
KO_ONLY4 = {('33', 5)}   # 279번: 본문 해석만 바로잡은 문항
ITEM_FIX4 = {('31', 21), ('32', 0), ('32', 6), ('32', 8), ('32', 9), ('32', 15), ('33', 6), ('33', 13), ('33', 16), ('33', 18), ('34', 2), ('34', 7), ('34', 16), ('34', 18), ('34', 26)}   # 278번: 레벨4 검토에서 고친 문항
ITEM_FIX3 = {('31', 2), ('31', 11), ('31', 26), ('31', 28), ('32', 7), ('32', 14), ('33', 16), ('33', 22), ('33', 26), ('34', 9), ('34', 14), ('34', 16), ('34', 20), ('34', 21), ('34', 24)}   # 293번: 레벨3 검토에서 고친 문항
ITEM_FIX1 = {('31', n) for n in range(30)}   # 315·316번: 31번 레벨1 서른 문항을 새 레벨 기준으로 다시 씀(네 문장·단문·10~15낱말)
ITEM_FIX1 |= {('32', n) for n in range(30)}   # 320·321번: 32번 레벨1 서른 문항을 같은 꼴로 다시 씀
ITEM_FIX1 |= {('33', n) for n in range(30)}   # 322·323번: 33번 레벨1 서른 문항을 같은 꼴로 다시 씀
ITEM_FIX1 |= {('34', n) for n in range(30)}   # 324·325번: 34번 레벨1 서른 문항을 같은 꼴로 다시 씀
ITEM_FIX2 = {('31', n) for n in range(30)}   # 352·353번: 31번 레벨2 서른 문항을 A/B 꼴로 다시 씀(네 문장·평균 55낱말·and/but/so/or로 이은 단문)
ITEM_FIX2 |= {('32', n) for n in range(30)}   # 350·351번: 32번 레벨2 서른 문항을 349번의 새 꼴(A/B 두 조건 + 결과를 견주는 빈칸 문장)로 다시 씀
ITEM_FIX = {'2': ITEM_FIX2, '1': ITEM_FIX1, '9': ITEM_FIX9, '8': ITEM_FIX8, '7': ITEM_FIX7, '6': ITEM_FIX6, '5': ITEM_FIX5, '4': ITEM_FIX4, '3': ITEM_FIX3}.get(LV, set())
ANS_FIX = {('7', '34', 15): 'everyone who wants work and does not have it', ('6', '33', 25): 'an existing pattern spreading to more verbs', ('6', '32', 10): 'what they compare the result with', ('6', '32', 14): 'tasks that were left unfinished', ('6', '31', 12): 'a small valve that must stay clear', ('6', '31', 24): 'heat that cannot escape', ('5', '32', 12): 'giving each thing a place', ('3', '34', 21): 'no gate near them', ('4', '33', 18): 'the idea of narrowing down', ('5', '33', 6): 'the sun, the moon and the five visible planets', ('5', '34', 3): 'a buyer who could not examine them', ('5', '34', 7): 'recovering the book rather than punishing the borrower'}   # 246번: 레벨7 34번 16번째 — 정답 선택지가 빈칸에 맞지 않아 선택지 다섯을 다시 씀(정답 번호는 그대로)
ANS_FIX[('1', '31', 2)] = 'safe'   # 315번: 3번째 — reliable은 중학 기초 낱말이 아니어서 safe로(다시 쓰기 승인 안에서)
ANS_FIX[('1', '31', 21)] = 'tired'; ANS_FIX[('1', '31', 29)] = 'easily'   # 316번: 22번째 stiff → tired · 30번째 confidently → easily(같은 까닭)
ANS_FIX[('1', '32', 10)] = 'spread'   # 320번: 11번째 scatter → spread(중학 기초 낱말이 아니어서)
ANS_FIX[('1', '33', 11)] = 'never forgets a book'   # 322번: 12번째 means she never forgets one → never forgets a book(means 뒤의 절이 레벨1의 단문에 맞지 않아서. 뜻은 같음)
ANS_FIX[('1', '33', 19)] = 'understands her own spending'; ANS_FIX[('1', '33', 22)] = 'argues about past decisions'; ANS_FIX[('1', '33', 27)] = 'knows the week ahead'   # 323번: 20·23·28번째 — 정답 구 안의 절(where her money goes · what was agreed · what is coming)이 레벨1의 단문에 맞지 않아서. 뜻은 같음
ANS_FIX[('1', '34', 2)] = "change people's feelings about a place"; ANS_FIX[('1', '34', 4)] = 'return their books on time'; ANS_FIX[('1', '34', 10)] = 'fill their trays in the order of the line'; ANS_FIX[('1', '34', 14)] = 'bread from the early morning'   # 324번: 3·5·11·15번째 — 정답 구 안의 절(how people feel · when it is easy to · people meet the food · everything was baked)이 레벨1의 단문에 맞지 않아서. 뜻은 같음
ANS_FIX[('1', '34', 16)] = 'cancel in time for somebody else'; ANS_FIX[('1', '34', 24)] = 'their working hours'   # 325번: 17·25번째 — 정답 구 안의 절(so somebody else can come · whether parents could get there)이 레벨1의 단문에 맞지 않아서
ANS_FIX.update({('2', '31', n): w for n, w in [(0, 'noise'), (1, 'morning'), (2, 'clean'), (3, 'returned'), (4, 'traffic'), (5, 'soil'), (6, 'heavier'), (7, 'bedroom'), (8, 'east'), (9, 'water'), (10, 'place'), (11, 'bend'), (12, 'cover'), (13, 'warmer'), (14, 'pale'), (15, 'sugar'), (16, 'afternoon'), (17, 'softer'), (18, 'air'), (19, 'under'), (20, 'seat'), (21, 'name'), (22, 'weather'), (23, 'coat'), (24, 'days'), (25, 'saves'), (26, 'closed'), (27, 'loose'), (28, 'dark'), (29, 'passing')]})   # 352·353번: 31번 레벨2 다시 쓰기(A/B 꼴) — 정답 선택지는 낱말 하나(정답 번호는 그대로)
ANS_FIX.update({('1', '31', n): w for n, w in [(0, 'aunt'), (1, 'yard'), (2, 'hat'), (3, 'Thursday'), (4, 'oven'), (5, 'cold'), (6, 'walked'), (7, 'always'), (8, 'blue'), (9, 'Yeji'), (10, 'officer'), (11, 'airport'), (12, 'ham'), (13, 'Sunday'), (14, 'fox'), (15, 'windy'), (16, 'jump'), (17, 'slowly'), (18, 'blankets'), (19, 'October'), (20, 'box'), (21, 'man'), (22, 'clock'), (23, 'October'), (24, 'music'), (25, 'yellow'), (26, 'swam'), (27, 'alone'), (28, 'mouse'), (29, 'clear')]})   # 354번: 31번 레벨1 서른 문항을 새 꼴(단문 · 정답 낱말이 글에 그대로 나오되 빈칸 문장만으로는 정해지지 않음)로 다시 씀 — 정답 낱말 서른을 새로 정함(정답 번호는 그대로)
ANS_FIX.update({('1', '32', n): w for n, w in [(0, 'star'), (1, 'potato'), (2, 'Thursday'), (3, 'flew'), (4, 'key'), (5, 'door'), (6, 'soft'), (7, 'black'), (8, 'rock'), (9, 'Nari'), (10, 'ten'), (11, 'cheese'), (12, 'boat'), (13, 'field'), (14, 'switch'), (15, 'yellow'), (16, 'left'), (17, 'mouse'), (18, 'nurse'), (19, 'potato'), (20, 'bird'), (21, 'orange'), (22, 'church'), (23, 'Mina'), (24, 'pulling'), (25, 'May'), (26, 'cat'), (27, 'green'), (28, 'shells'), (29, 'never')]})   # 356번: 32번 레벨1 서른 문항을 새 꼴(단문 · 정답 낱말이 글에 그대로 나오되 빈칸 문장만으로는 정해지지 않음)로 다시 씀 — 정답 낱말 서른을 새로 정함(정답 번호는 그대로)
ANS_FIX.update({('2', '32', n): w for n, w in [(0, 'darker'), (1, 'kneading'), (2, 'slower'), (3, 'fewer'), (4, 'water'), (5, 'hear'), (6, 'walls'), (7, 'drier'), (8, 'drier'), (9, 'white'), (10, 'direction'), (11, 'ears'), (12, 'more'), (13, 'faster'), (14, 'paint'), (15, 'tired'), (16, 'heat'), (17, 'harder'), (18, 'cooler'), (19, 'faster'), (20, 'stickier'), (21, 'size'), (22, 'older'), (23, 'direction'), (24, 'soap'), (25, 'wilder'), (26, 'circle'), (27, 'softer'), (28, 'longer'), (29, 'outside')]})   # 350·351번: 32번 레벨2 다시 쓰기(349번의 새 꼴) — 정답 선택지는 낱말 하나(정답 번호는 그대로)
KO_FIX = {'9': KO_FIX9, '8': KO_FIX8, '7': KO_FIX7}.get(LV, {})
FRAMES = ('not A but B', 'A rather than B', 'less A than B', 'X over Y')   # 틀을 가리키는 말(지문에 없어도 됨)
ORD = {'첫': 1, '둘째': 2, '셋째': 3, '넷째': 4, '다섯째': 5, '여섯째': 6, '일곱째': 7, '여덟째': 8}
done = 0; soft = []; bare = []; lens_w = []; lens_c = []
for n in range(30):
    it = tb[T][LV][n]; ex = te[T][LV][n]; P = it['text']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done += 1; lens_w.append(len(ex['walk'])); lens_c += [len(c) for c in ex['cn']]
    src = (P + ' || ' + ' || '.join(it['choices'])).lower()
    sents = re.split(r'(?<=[.?]) ', P)
    for tx in [ex['walk']] + ex['cn']:
        assert '«' not in tx and '»' not in tx, (n, '꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"') % 2 == 0, (n, line)
            for q in re.findall(r'"([^"]*)"', line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"' % (n + 1, q))
                if len(q) < 12: print('!! 짧은 큰따옴표: %d번째 "%s"' % (n + 1, q))
        # 작은따옴표 속 영어가 지문·선택지 어디에도 없으면 눈으로 볼 목록에(틀은 빼고)
        body = tx
        for c in it['choices']: body = body.replace("'" + c + "'", '')
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])", body):
            if re.search(r'[가-힣]', q) or not re.search(r'[A-Za-z]{3,}', q): continue
            if any(f in q for f in FRAMES) or re.search(r'\b[AB]\b', q): continue
            parts = [p.strip() for p in re.split(r'…', q) if p.strip()]
            if not all(p.lower().strip('.,') in src for p in parts): soft.append((n + 1, q))
        # 따옴표 없이 쓴 영어 낱말(4자 이상)이 지문에 없으면 목록에: 「지문에 없는 말」이라고 한 것만 남아야 함
        plain = re.sub(r'"[^"]*"|\'[^\'\n]*\'', ' ', body.split('【이 문제에 적용】')[-1])   # 요령 네 줄(공통)은 빼고 봄
        for w in set(re.findall(r'[A-Za-z]{4,}', plain)):
            if w.lower() not in P.lower(): bare.append((n + 1, w, w.lower() in src))
        # "몇째 문장"이라고 한 자리 뒤에 바로 온 인용이 그 문장에 있는지
        for m in re.finditer(r'(첫|둘째|셋째|넷째|다섯째|여섯째|일곱째|여덟째) 문장[^.\n]{0,25}?[\'"]([^\'"\n]+)[\'"]', tx):
            k = ORD[m.group(1)]; q = m.group(2)
            if re.search(r'[A-Za-z]{3,}', q) and not any(f in q for f in FRAMES):
                ok = k <= len(sents) and all(p.strip().lower() in sents[k - 1].lower() for p in q.split('…') if p.strip())
                if not ok: print('!! 문장 자리 어긋남: %d번째 「%s 문장」 — %s' % (n + 1, m.group(1), q))
    for k, c in enumerate(it['choices']):
        assert ex['cn'][k].startswith((("정답이에요. " if LV in '123' else "정답입니다. ") if k == it['answer'] else "") + "'" + c + "' ("), (n, k, '선택지 인용 꼴')
        if LV in '123': assert not has_nida(ex['cn'][k]) and not has_nida(ex['walk'].split('【이 문제에 적용】')[1]), (n, k, '레벨1~3인데 「~니다」 말끝')
        assert ex['cn'][k].count('정답') == (1 if k == it['answer'] else 0), (n, k, '정답이라는 말')
    w = ex['walk']
    assert not re.search(r'[①②③④⑤]|\d번', w), (n, '풀이에 번호')
    assert '정답' not in w, (n, '풀이에 "정답"')
    assert w.startswith('【빈칸 추론 요령】') and w.count('【') == 3 and '【끌리는 오답】' in w, (n, '세 단락 꼴')
    assert all(('\n%d) ' % i) in w for i in (1, 2, 3, 4)) and '\n1) 빈칸 문장:' in w and '\n4) 묶기:' in w and '짝꿍 문장' in w.split('【이 문제에 적용】')[1], (n, '적용 꼴')
    b0 = tb0[T][LV][n]
    if (T, n) in ITEM_FIX:   # 지문·오답을 고친 문항(인계문서에 적은 것만): 정답 번호·정답 문구·발문은 그대로여야 함
        assert it['answer'] == b0['answer'] and it.get('q') == b0.get('q') and (it['choices'][it['answer']] == b0['choices'][b0['answer']] or ANS_FIX.get((LV, T, n)) == it['choices'][it['answer']]), (n, '정답 변동')
    else: assert it['text'] == b0['text'] and it['answer'] == b0['answer'] and it.get('q') == b0.get('q') and it['choices'] == b0['choices'], (n, '문항 변동')
    if (T, n) in ITEM_FIX and (T, n) not in KO_FIX: pass   # 지문을 늘린 문항은 해석도 함께 늘어남
    elif (T, n) in KO_FIX:   # 해석의 틀린 낱말 하나를 바로잡은 문항(인계문서에 적은 것만)
        a, b = KO_FIX[(T, n)]; assert te0[T][LV][n]['ko'].count(a) == 1 and ex['ko'] == te0[T][LV][n]['ko'].replace(a, b), (n, '해석 변동(허용한 것과 다름)')
    else: assert ex['ko'] == te0[T][LV][n]['ko'], (n, '해석 변동')
# 손대지 않은 문항은 바탕과 같아야 함
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']:
        e1 = dict(te[T][LV][n]); e0 = dict(te0[T][LV][n])
        if LV == '4' and (T, n) in KO_ONLY4: e1['ko'] = e0['ko'] = ''   # 해석만 바로잡은 문항(인계문서에 적은 것만)
        assert e1 == e0 and tb[T][LV][n] == tb0[T][LV][n], (n, '안 쓴 문항이 바뀜')
print('두텁게 쓴 문항: %d / 30' % done)
if lens_w: print('풀이 평균 %d자(최소 %d, 최대 %d) / 선택지 해설 평균 %d자(최소 %d, 최대 %d)' % (sum(lens_w) / len(lens_w), min(lens_w), max(lens_w), sum(lens_c) / len(lens_c), min(lens_c), max(lens_c)))
for x in soft: print("  눈으로 볼 것(작은따옴표 영어가 지문·선택지에 없음): %d번째 '%s'" % x)
for x in sorted(set(bare)): print('  눈으로 볼 것(따옴표 없는 영어가 지문에 없음): %d번째 %s %s' % (x[0], x[1], '(선택지에는 있음)' if x[2] else '(선택지에도 없음)'))
