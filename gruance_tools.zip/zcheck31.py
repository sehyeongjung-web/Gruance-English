# -*- coding: utf-8 -*-
# 31~34번(빈칸) 레벨9 두텁게 — 자체 엄격 검사 (verify_explain보다 엄함)
#   python3 zcheck31.py 31        (유형 코드. 기본 31)
import re, sys; sys.path.insert(0, '.')
from lib import *
T = sys.argv[1] if len(sys.argv) > 1 else '31'
s, tb, te = load('out/index.html'); s0, tb0, te0 = load()
FRAMES = ('not A but B', 'A rather than B', 'less A than B', 'X over Y')   # 틀을 가리키는 말(지문에 없어도 됨)
ORD = {'첫': 1, '둘째': 2, '셋째': 3, '넷째': 4, '다섯째': 5, '여섯째': 6, '일곱째': 7, '여덟째': 8}
done = 0; soft = []; bare = []; lens_w = []; lens_c = []
for n in range(30):
    it = tb[T]['9'][n]; ex = te[T]['9'][n]; P = it['text']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done += 1; lens_w.append(len(ex['walk'])); lens_c += [len(c) for c in ex['cn']]
    src = (P + ' || ' + ' || '.join(it['choices'])).lower()
    sents = re.split(r'(?<=[.?]) ', P)
    for tx in [ex['walk']] + ex['cn']:
        assert '«' not in tx and '»' not in tx, (n, '꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"') % 2 == 0, (n, line)
            for q in re.findall(r'"([^"]*)"', line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"' % (n + 1, q))
                if len(q) < 12: print('!! 짧은 큰따옴표: %d번째 "%s"' % (n + 1, q))
        # 작은따옴표 속 영어가 지문·선택지 어디에도 없으면 눈으로 볼 목록에(틀은 빼고)
        body = tx
        for c in it['choices']: body = body.replace("'" + c + "'", '')
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])", body):
            if re.search(r'[가-힣]', q) or not re.search(r'[A-Za-z]{3,}', q): continue
            if any(f in q for f in FRAMES) or re.search(r'\b[AB]\b', q): continue
            parts = [p.strip() for p in re.split(r'…', q) if p.strip()]
            if not all(p.lower().strip('.,') in src for p in parts): soft.append((n + 1, q))
        # 따옴표 없이 쓴 영어 낱말(4자 이상)이 지문에 없으면 목록에: 「지문에 없는 말」이라고 한 것만 남아야 함
        plain = re.sub(r'"[^"]*"|\'[^\'\n]*\'', ' ', body.split('【이 문제에 적용】')[-1])   # 요령 네 줄(공통)은 빼고 봄
        for w in set(re.findall(r'[A-Za-z]{4,}', plain)):
            if w.lower() not in P.lower(): bare.append((n + 1, w, w.lower() in src))
        # "몇째 문장"이라고 한 자리 뒤에 바로 온 인용이 그 문장에 있는지
        for m in re.finditer(r'(첫|둘째|셋째|넷째|다섯째|여섯째|일곱째|여덟째) 문장[^.\n]{0,25}?[\'"]([^\'"\n]+)[\'"]', tx):
            k = ORD[m.group(1)]; q = m.group(2)
            if re.search(r'[A-Za-z]{3,}', q) and not any(f in q for f in FRAMES):
                ok = k <= len(sents) and all(p.strip().lower() in sents[k - 1].lower() for p in q.split('…') if p.strip())
                if not ok: print('!! 문장 자리 어긋남: %d번째 「%s 문장」 — %s' % (n + 1, m.group(1), q))
    for k, c in enumerate(it['choices']):
        assert ex['cn'][k].startswith(("정답입니다. " if k == it['answer'] else "") + "'" + c + "' ("), (n, k, '선택지 인용 꼴')
        assert ex['cn'][k].count('정답') == (1 if k == it['answer'] else 0), (n, k, '정답이라는 말')
    w = ex['walk']
    assert not re.search(r'[①②③④⑤]|\d번', w), (n, '풀이에 번호')
    assert '정답' not in w, (n, '풀이에 "정답"')
    assert w.startswith('【빈칸 추론 요령】') and w.count('【') == 3 and '【끌리는 오답】' in w, (n, '세 단락 꼴')
    assert all(('\n%d) ' % i) in w for i in (1, 2, 3, 4)) and '\n1) 빈칸 문장:' in w and '\n4) 묶기:' in w and '짝꿍 문장' in w.split('【이 문제에 적용】')[1], (n, '적용 꼴')
    b0 = tb0[T]['9'][n]
    assert it['text'] == b0['text'] and it['answer'] == b0['answer'] and it.get('q') == b0.get('q') and it['choices'] == b0['choices'], (n, '문항 변동')
    assert ex['ko'] == te0[T]['9'][n]['ko'], (n, '해석 변동')
# 손대지 않은 문항은 바탕과 같아야 함
for n in range(30):
    if '【이 문제에 적용】' not in te[T]['9'][n]['walk']:
        assert te[T]['9'][n] == te0[T]['9'][n] and tb[T]['9'][n] == tb0[T]['9'][n], (n, '안 쓴 문항이 바뀜')
print('두텁게 쓴 문항: %d / 30' % done)
if lens_w: print('풀이 평균 %d자(최소 %d, 최대 %d) / 선택지 해설 평균 %d자(최소 %d, 최대 %d)' % (sum(lens_w) / len(lens_w), min(lens_w), max(lens_w), sum(lens_c) / len(lens_c), min(lens_c), max(lens_c)))
for x in soft: print("  눈으로 볼 것(작은따옴표 영어가 지문·선택지에 없음): %d번째 '%s'" % x)
for x in sorted(set(bare)): print('  눈으로 볼 것(따옴표 없는 영어가 지문에 없음): %d번째 %s %s' % (x[0], x[1], '(선택지에는 있음)' if x[2] else '(선택지에도 없음)'))
