# -*- coding: utf-8 -*-
# 369번: 44번(지칭 대상이 다른 것) 레벨1 — 해설 도우미 (z42common 꼴 · 풀이 + 선택지별 해설)
#   from z44common import maker;  rw = maker(E)
#   rw(n, 지문(일곱 문장 한 단락, 표시 (a)~(e)가 한 번씩), 해석(일곱 문장, 표시 그대로), M(주인공 한글 이름), H(도우미 한글 말), 설명 다섯, 낱말 줄)
#   - 정답 자리는 바탕 그대로(어기면 멈춤). 정답 자리만 도우미 H, 나머지 넷은 주인공 M
#   - 설명 다섯: 표시마다 「왜 그 사람인지」 한두 문장(해요체). 지문을 그대로 옮길 때는 «…»(영어)로 쓰면 큰따옴표로 바뀌고, 지문에 없으면 멈춤
#   - 풀이(walk) · 선택지별 해설(cn)은 바탕 44번 레벨1의 꼴(① ② ③)을 따름
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
_s, _tb, _te = load()
LET = 'abcde'
def jong(w):
    c = w.rstrip()[-1]
    return (ord(c) - 0xAC00) % 28 != 0 if '가' <= c <= '힣' else False
def ye(w): return w + ('이에요' if jong(w) else '예요')
def eun(w): return w + ('은' if jong(w) else '는')
def wa(w): return w + ('과' if jong(w) else '와')
def reul(w): return w + ('을' if jong(w) else '를')
PJOSA = {'she': '는', 'he': '는', 'her': '는', 'his': '는', 'him': '은'}
def maker(E, T='44', LV='1'):
    def rw(n, text, ko, M, H, notes, words):
        base = _tb[T][LV][n]; a = base['answer']
        assert list(base['choices']) == ['(%s)' % c for c in LET], (n, '선택지는 (a)~(e)')
        assert len(ko) == 7 and len(notes) == 5, (n, '해석은 일곱 · 설명은 다섯')
        sents = [s.strip() for s in re.split(r'(?<=[.?!])\s+', text)]
        assert len(sents) == 7, (n, '문장 수', len(sents))
        for c in LET:
            assert text.count('(%s)' % c) == 1 and ' '.join(ko).count('(%s)' % c) == 1, (n, c, '표시는 영어 · 해석에 한 번씩')
        sk = {}; kk = {}; tok = {}
        for i, s in enumerate(sents):
            for c in LET:
                if '(%s)' % c in s:
                    sk[c] = s; kk[c] = ko[i]
                    m = re.search(r'\(%s\)(\w+)' % c, s); assert m, (n, c, '표시 뒤 낱말'); tok[c] = m.group(1)
        assert sorted(sk) == list(LET), (n, '표시를 모두 못 찾음')
        for c in LET:
            assert '(%s)' % c in kk[c], (n, c, '해석 문장이 영어 문장과 같은 자리가 아님')
        assert re.search(r'[가-힣]', M) and re.search(r'[가-힣]', H) and M != H, (n, 'M · H 한글 이름')
        def q(tx):
            for m in re.findall(r'«([^»]*)»', tx): assert m in text.replace('(a)', '').replace('(b)', '').replace('(c)', '').replace('(d)', '').replace('(e)', '') or m in text, (n, '지문에 없는 인용', m)
            return tx.replace('«', '"').replace('»', '"')
        def clean(s): return re.sub(r'\([a-e]\)', '', s)
        def cleank(s): return re.sub(r'\([a-e]\)\s*', '', s)
        for k, c in enumerate(LET):
            who = H if k == a else M
            assert who in notes[k], (n, c, '설명에 %s(누구인지)가 있어야 함' % who)
            assert '정답' not in notes[k], (n, c, '설명에 「정답」이라는 말')
        pron = '여자' if any(t.lower() in ('she', 'her') for t in tok.values()) else '남자'
        head = ("① 이 문제는 (a)~(e)가 각각 누구를 가리키는지 확인하는 문제예요. 글에는 %s %s 두 사람이 나오는데 둘 다 %s라서, 모양만 봐서는 누구인지 구별할 수 없어요. "
                "표시된 말이 들어 있는 문장의 주어와 앞 문장을 보고 판단해요." % (wa(M), H, pron))
        rows = []
        for k, c in enumerate(LET):
            rows.append('(%s) "%s" (%s)\n→ %s' % (c, clean(sk[c]), cleank(kk[c]), q(notes[k])))
        others = ''.join('(%s)' % c for k, c in enumerate(LET) if k != a)
        walk = head + '\n② 하나씩 확인해요.\n' + '\n'.join(rows) + '\n③ %s는 모두 %s 가리키고, (%s)만 %s 가리켜요. 그러니까 정답은 (%s)예요.' % (others, reul(M), LET[a], reul(H), LET[a])
        if words: walk += '\n📌 낱말: ' + words
        cn = []
        for k, c in enumerate(LET):
            who = H if k == a else M; t = tok[c]
            cn.append(('정답이에요! ' if k == a else '') + '(%s) — 이 %s%s %s. %s "%s" (%s)' % (c, t, PJOSA[t.lower()], ye(who), q(notes[k]), clean(sk[c]), cleank(kk[c])))
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True,
                         'rewrite': {'text': text, 'choices': ['(%s)' % c for c in LET], 'ko': ' '.join(ko), 'walk': walk, 'cn': cn}}
    return rw
