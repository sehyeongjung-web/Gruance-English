# -*- coding: utf-8 -*-
# 이 방의 환산 사용량: 읽기 0.1배 · 쓰기 2배 · 입력 1배 · 출력 5배. python3 measure85.py [since ISO]
import json, glob, os, sys
base = '/root/.claude/projects/-home-claude/66a7c868-2c15-51bf-bdd1-62bd10ca9c7b'
since = sys.argv[1] if len(sys.argv) > 1 else ''
def tally(path):
    best = {}
    for l in open(path, encoding='utf-8'):
        try: o = json.loads(l)
        except Exception: continue
        if o.get('type') != 'assistant': continue
        if since and o.get('timestamp', '') < since: continue
        m = o.get('message') or {}; u = m.get('usage')
        if not u: continue
        k = m.get('id') or o.get('uuid')
        v = (u.get('output_tokens', 0), u)
        if k not in best or v[0] >= best[k][0]: best[k] = v
    tot = 0
    for _, u in best.values():
        tot += u.get('input_tokens', 0) + 0.1 * u.get('cache_read_input_tokens', 0) + 2 * u.get('cache_creation_input_tokens', 0) + 5 * u.get('output_tokens', 0)
    return tot, len(best)
mt, mc = tally(base + '.jsonl')
st = 0; sc = 0; n = 0
for p in glob.glob(base + '/subagents/*.jsonl'):
    t, c = tally(p); st += t; sc += c; n += 1
print('주 대화 %d번 호출 %.0f만 · 도우미 %d명 %d번 호출 %.0f만 · 합계 %.0f만' % (mc, mt / 1e4, n, sc, st / 1e4, (mt + st) / 1e4))
