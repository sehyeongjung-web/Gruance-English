#!/bin/bash
# 359번: 40번 레벨1(두 경우를 맞세운 일상 장면 + 요약문) — 원고에서 수정안 만들기 → 조사 → 빌드 (바탕 5bf74b1 위에 X75만)
cd /home/claude/work
python3 draft/gen75.py a && python3 draft/gen75.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X75a.py pending/edits_X75b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X75a,edits_X75b out/index.html | tail -3
