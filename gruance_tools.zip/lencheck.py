# 길이 점검표 규칙을 원고(d 파일)의 ch로 바로 검사: python3 lencheck.py <유형> <레벨> <d파일>
# 정답 자리·정답 낱말은 out/index.html 에서 읽는다(원고에서 정답 낱말은 바꾸면 안 됨).
import sys, importlib.util
sys.path.insert(0,'/home/claude/work'); sys.path.insert(0,'/home/claude/work/draft')
sp=importlib.util.spec_from_file_location('v','/home/claude/Gruance-English/verify.py'); v=importlib.util.module_from_spec(sp); sp.loader.exec_module(v)
from lib import load
T,L,dfile=sys.argv[1],sys.argv[2],sys.argv[3]
_,tb,_=load('/home/claude/work/out/index.html')
base=tb[T][L]
sp=importlib.util.spec_from_file_location('d',dfile); d=importlib.util.module_from_spec(sp); sp.loader.exec_module(d)
items=[]
for n,it in enumerate(base):
    k=it['answer']; ch=[d.I[n]['ch'][i] for i in range(5)]
    assert ch[k]==it['choices'][k],('정답 낱말이 바뀜',n,ch[k],it['choices'][k])
    items.append(dict(choices=ch,answer=k))
bad,cnt=v.length_cell(items)
print('판정:',repr(bad),'(A: 정답이 첫째·둘째로 긴 문항 %d (16 이하), 정답이 가장 긴(동률 포함) 문항 %d (8 이하) / B: 혼자 튀게 긴 %d (2 이하) / C: %d / E: %d)'%(cnt[0],sum(1+sum(len(x)>len(it['choices'][it['answer']]) for i,x in enumerate(it['choices']) if i!=it['answer'])==1 for it in items),cnt[1],cnt[3],cnt[4]))
for n,it in enumerate(items):
    ch=it['choices'];k=it['answer'];Lk=len(ch[k]);r=1+sum(len(x)>Lk for i,x in enumerate(ch) if i!=k)
    ls=sorted((len(x) for x in ch),reverse=True);b=ls[1] and ls[0]/ls[1]>=1.3
    print('%2d R%d%s key=%-12s %s'%(n,r,' B' if b else '  ',ch[k],' '.join('%s(%d)'%(x,len(x)) for x in ch)))
