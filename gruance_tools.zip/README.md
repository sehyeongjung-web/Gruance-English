# 그루앙스 AI 수능영어코치 — 작업 도구 묶음

문항(index.html 안의 `TYPE_BANK`·`TYPE_EXPLAIN` 두 상수)을 고칠 때 쓰는 도구입니다.
방이 바뀌면 작업 폴더가 사라지므로, 이 묶음을 GitHub에 올려 두고 새 방에서 풀어 씁니다.

## 새 방에서 시작하는 법

```bash
git clone https://github.com/sehyeongjung-web/Gruance-English.git /home/claude/Gruance-English
unzip -o /home/claude/Gruance-English/gruance_tools.zip -d /home/claude/work
bash /home/claude/work/setup.sh
```

`setup.sh`가 저장소를 최신으로 맞추고, `out/`에 index.html·인계문서를 복사하고, 두 검증 도구를 돌려 현재 상태를 보여 줍니다.
그다음 **인계문서의 마지막 항목**을 읽고 이어서 작업합니다.

`setup.sh`는 맨 끝에 **`절약방식.md`**(레벨 1~2 칸의 작업 순서 · 도우미 규칙 · 가벼운 감사 지침 — 새 방에서 가장 먼저 읽을 것)와 **`DEFERRED.md`**(나중에 하기로 미뤄 둔 일의 목록)도 보여 줍니다. 차례가 온 일이 있는지 먼저 보고, 한 가지를 끝내면 그 줄을 지운 뒤 인계문서에 적습니다. 새로 미루는 일은 그 파일에 보탭니다.

## 폴더 구조

| 자리 | 내용 |
|---|---|
| `/home/claude/Gruance-English/` | GitHub 복사본(바탕). 직접 고치지 않음 |
| `/home/claude/work/` | 이 도구들과 수정안 파일(`edits_*.py`) |
| `/home/claude/work/out/` | 만들어진 누적본(index.html)과 인계문서 |
| `/mnt/user-data/outputs/` | 선생님께 전달하는 파일 |

## 도구

| 파일 | 하는 일 |
|---|---|
| `lib.py` | index.html에서 두 상수를 읽고(`load`) 다시 써넣음(`save`). `span`은 상수의 범위 |
| `apply.py` | 수정안 파일을 바탕 파일에 적용. 정답·지문을 건드리면 멈춤(승인 표시가 있어야 통과) · **정답 자리 이동(329번)**: `rewrite`에 `'answer': 새 답(0~4)`과 수정안에 `'answer_ok': True`가 있고 그 칸이 `ans_move.py`의 `APPROVED`에 있을 때만 정답 자리를 바꿈(그 밖의 칸은 멈춤) |
| `ans_move.py` | **정답 자리를 옮겨도 된다고 선생님이 승인하신 칸**(329번: `('38_39','1')` 하나 — 「정답 자리 옮기더라도 수정하는 게 좋을 것 같습니다」). `apply.py` · `zcheck3839.py` · `check_all.py`가 이 목록을 봄. 승인 없이 칸을 보태지 말 것 |
| `qr.py` | **점검 출력 줄이기**(절약 방식): `python3 qr.py 이름 -- 명령…` — 전체 출력은 `/tmp/qr_logs/이름.log`에 두고 화면에는 문제 줄과 마지막 줄만. 도우미(글쓴이 · 감사꾼)가 점검 결과를 통째로 되읽는 값을 줄임 |
| `절약방식.md` | **레벨 1~2 칸의 작업 방식**(366번~): 점검 코드 먼저 → 시범 3문항 → 글쓴이 3명 한 번에(호출 25번 안) → 시험 → 걸린 문항만 부분 교체 → 가벼운 감사 한 번 → 한글 · 교정. 쓰는 양을 줄이되 통과선은 그대로 |
| `build.py` | **누적본 만들기**: `python3 build.py edits_A,edits_B out/index.html` — 바탕(GitHub) 위에 수정안들을 차례로 적용 |
| `check_all.py` | **한 번에 점검**: 앱 코드 불변, 바뀐 문항 수, node --check, verify.py, verify_explain.py · 승인된 칸의 정답 자리 이동은 「승인된 칸의 정답 자리 이동」 줄에 따로 보여 줌(그 밖의 이동은 여전히 「정답 번호 변동」으로 멈춤) |
| `dump.py` | 문항 읽기: `python3 dump.py 24 3 200 all 60` (유형, 레벨, 지문 길이, all=전체, 해설 길이) |
| `qcheck.py` | 길이 작업용 인용 대조(레벨별): `python3 qcheck.py out/index.html 3` |
| `zcheck.py`·`zcheck35.py`·`zcheck3637.py` | 레벨9 해설 두텁게(176번~) 자체 검사(23번용·35번용·36-37번용): 큰따옴표 인용 전부 지문 대조, 오답 해설에 '정답' 없음, 풀이에 번호 없음, 문항 불변. 유형 코드만 바꿔 씀 |
| `z3common.py` | 36-37번 레벨9 해설 두텁게(178번)의 공통 도우미 — `edits_Z3`이 불러 씀. 정답 순서와 풀이의 글 차례가 다르면 멈춤 |
| `pending/` | **아직 GitHub에 올라가지 않았을 수 있는 수정안.** 인계문서 마지막 항목의 「다음에 시작할 때」를 보고, 안 올라갔으면 작업 폴더로 복사해 `build.py`에 함께 넘김 |
| `done/` | 이미 GitHub에 반영된 지난 수정안(다시 얹지 말 것 — 형식 참고용) |
| `examples/` | 실제로 쓴 수정안 파일 12개(`edits_Z1`·`edits_Z2`·`edits_Z3`은 176~178번 해설 두텁게 본보기. `edits_Z3`은 work 폴더에 `edits_Z3.py`로 복사해 씀)(형식 참고용). `edits_Y1~Y5`는 170~174번 틀 재작성(순서·지칭·일치, 레벨3·4) 본보기 — 도우미 함수로 본문·해석·풀이·해설을 자동 조립하는 방식 |

`verify.py`(형식·길이 점검표)와 `verify_explain.py`(선택지-해설 대조)는 저장소에 있는 것을 씁니다.

## 표준 절차

1. `git fetch`로 GitHub 최신 커밋을 확인한다. 지난번 파일이 올라갔으면 바탕을 그 커밋으로 옮긴다(`git reset --hard origin/main`). 안 올라갔으면 지난 수정안 파일들을 계속 함께 적용한다.
2. 고칠 칸을 **전부 읽는다**(`dump.py` 또는 직접 출력). 범위가 예상과 다르면 먼저 선생님께 말씀드린다.
3. 수정안 파일 `edits_이름.py`를 쓴다(아래 형식).
4. `python3 build.py (아직 안 올라간 수정안들),edits_이름 out/index.html`
5. `python3 check_all.py` — 다섯 항목이 모두 깨끗해야 한다.
6. 인계문서(`out/그루앙스_작업인계문서.md`) 끝에 새 번호 항목을 덧붙인다.
7. `out/index.html`과 인계문서를 `/mnt/user-data/outputs/`로 복사해 전달한다.

## 수정안 파일 형식

```python
AUTO_SYNC = True      # 해설이 선택지를 글자 그대로 인용한 곳을 함께 바꿈 (주의: 아래 '교훈' 참고)
E = {}
# 열쇠는 (유형, 레벨, 문항 번호) — 문항 번호는 0부터 센다(1번째 문항 = 0)
E[('24','3',5)] = {
    'ch': {1: '새 선택지', 3: '새 선택지'},          # 선택지 바꾸기(0~4 자리). 정답 자리는 'ans_ok': True가 있어야 함
    'kp': {1: '새 한글 해석'},                        # 해설의 "'영어' (한글 해석) — 설명"에서 괄호 속 해석
    'kq': {3: '새 한글 해석'},                        # 해설 맨 앞 따옴표 속 한글 해석 통째로
    'cn': {1: ('옛 조각', '새 조각'),                 # 해설의 한 조각 바꾸기(튜플 또는 튜플 목록)
           3: '해설 전체를 이 글로 바꿈'},            # 문자열이면 통째로 바꿈
    'walk_sub': [('옛 조각', '새 조각')],             # 풀이(walk)의 조각 바꾸기
    'ko': ('옛 조각', '새 조각'),                     # 해석(ko)의 조각 바꾸기
    'cw': 'smiled',                                   # 틀렸을 때 보여 주는 correctWord 바로잡기
    'text': ('옛 조각', '새 조각'), 'passage_ok': True,   # 지문 수정 — 선생님 승인이 있을 때만
}
# 문항을 통째로 새로 쓸 때(승인 필요): 정답 번호는 그대로, correctWord가 있는 문항은 'cw'도 함께
E[('44','3',7)] = {'passage_ok': True, 'ans_ok': True,
    'rewrite': {'text': '...', 'choices': [...5개...], 'ko': '...', 'walk': '...', 'cn': [...5개...]}}
```

## 지켜야 할 규칙

- **정답 번호·발문은 절대 바꾸지 않는다.** 지문과 정답 문구는 선생님 승인이 있을 때만(코드에서 `passage_ok`·`ans_ok`).
- 한 유형에서 10문항 이상 고칠 때, 지문을 고칠 때는 먼저 승인을 받는다.
- 길이 점검표(verify.py)의 다섯 조건 — A 정답이 긴 쪽에 과다(칸마다 정답 1~2위 ≤16문항, 1위 ≤8문항) · B 혼자 튀게 긴 선택지 · C 나머지보다 1.4배 이상 긴 선택지 · D 정답이 긴 쪽에 거의 안 옴(1~2위 ≥5문항) · E 정답만 혼자 짧음. 지금은 144칸 전부 ✅.
- 지문 길이는 칸 평균이 `LEN9 × RATIO`의 ±35% 안이어야 경고가 없다(verify.py 안에 표가 있음).
- 레벨1~3 해설은 "~어요" 말투, 레벨4 이상은 "~입니다" 말투.
- 선생님께 드리는 말은 쉬운 말로, 결론부터, 올릴 파일과 바이트 수를 밝힌다.

## 교훈 (같은 사고를 되풀이하지 않기 위해)

1. **자동 맞춤(AUTO_SYNC)은 해설 안의 '지문 인용'까지 바꿀 수 있다.** 선택지가 지문 문장과 글자까지 같은 칸(45번 레벨1·2)에서 일어났다 → 선택지를 고친 뒤 반드시 `verify_explain.py`를 돌린다(검사 9번이 잡아냄).
2. **정답 문구를 바꾸면 풀이(walk)도 본다.** 풀이가 옛 정답 문구를 인용하고 있으면 `walk_sub`으로 함께 고친다.
3. **correctWord**는 29번 레벨1·레벨2와 30번 레벨1·레벨2에 있다(387번에 29번 L2, 389번에 30번 L2 추가). 문항을 다시 쓰면 함께 바꾼다(`rewrite`가 빠뜨리면 멈춤).
4. 틀 문제(같은 구조의 문항 반복)는 칸 전체를 읽어야 보인다. 견본 몇 개만 보고 범위를 말하지 않는다.

## 레벨9 해설 두텁게 도구 (176번~)

| 파일 | 유형 | 쓰는 법 |
|---|---|---|
| `zcheck.py` · examples의 `edits_Z1` | 23번 | 도우미 `mk`가 수정안 파일 안에 들어 있음 |
| `zcheck35.py` · `edits_Z2` | 35번 | 위와 같음 |
| `z3common.py` · `zcheck3637.py` · `edits_Z3` | 36-37번 | `mk(n, 'CAB', [적용 네 줄], 헷갈리는 곳, {순서: 설명})` |
| `z8common.py` · `zcheck31.py` · `edits_Z8_31L9.py` | 31번(32·33·34번도 같은 꼴) | `mk = maker(E, '31')` → `mk(n, 정답 자리(0~4), [적용 네 줄], 끌리는 오답, [(선택지 해석, 까닭)×5])` / `python3 zcheck31.py 31` |
| `z8common.py` · `zcheck31.py` · `edits_Z9_32L9.py` | 32번 | `mk = maker(E, '32')` → 나머지는 31번과 같음 / `python3 zcheck31.py 32` |
| `z8common.py` · `zcheck31.py` · `edits_Z11_33L9.py` | 33번 | `mk = maker(E, '33')` / `python3 zcheck31.py 33`. 오답을 바꾼 문항은 `mk` 뒤에 `E[...]['ch']`와 `E[...]['cn'][k]`를 덮어씀(3·28번째가 본보기) |
| `z8common.py` · `zcheck31.py` · `edits_Z12_34L9.py` | 34번 | `mk = maker(E, '34')` / `python3 zcheck31.py 34`. 14·19번째가 오답을 바꾼 본보기 |
| `z40common.py` · `zcheck40.py` · `edits_Z13_40L9.py` | 40번(요약문) | `mk = maker(E)` / `python3 zcheck40.py`. 요령 네 줄과 적용 줄 머리말(1) 요약문: / 2) (A) 찾기: / 3) (B) 찾기: / 4) 묶기:)이 40번용. 오답을 바꾸는 자리는 `FILL`을 넣고 뒤에서 `E[...]['ch']`·`['cn'][k]`를 덮어씀 |
| `z41common.py` · `zcheck41.py` · `edits_Z14_41L9.py` | 41번(장문 제목) | `mk = maker(E)` / `python3 zcheck41.py`. 요령 네 줄이 장문 제목용, 적용 줄 머리말은 23번과 같음(1) 되풀이: / 2) 꺾이는 곳: / 3) 끝 문장: / 4) 묶기:). 문장 자리는 문단을 넘어 열두째까지 셈. 「끝에서 둘째 문장」이라고 쓰지 말고 「끝에서 두 번째 문장」으로 쓸 것 |
| `edits_Z10_31L9_승인수정.py` | 31번 1·28번째 | 두텁게 쓴 뒤에 지문·오답을 고친 본보기(`text`+`passage_ok`, `ko`, `ch`, `walk_sub`, `cn`) |

- 38-39번(`z5common`·`zcheck3839`)과 42번(`z7common`·`zcheck42`) 도구는 182번 때 zip이 GitHub에 올라가지 않아 이 묶음에 없음. 해설 자체는 index.html에 들어 있고, 꼴은 인계문서 180번·182번에 적혀 있음
- `zcheck31.py` 맨 위의 `ITEM_FIX`(지문·오답을 고친 문항)와 `KO_FIX`(해석의 낱말 하나를 바로잡은 문항)에 적은 문항만 「문항·해석 불변」 검사에서 빼 줌. 새로 고치면 여기에 적고 인계문서에도 적을 것
- examples의 수정안은 **기록**임. GitHub에 반영된 뒤에는 다시 적용하지 않음(바탕이 이미 바뀌어 있어 멈춤)
- 원고에서 아포스트로피가 든 영어(object's 등)와 두 글자 낱말('no')은 작은따옴표로 옮기지 않음(따옴표 짝 검사가 어긋남). 「셋째 문장 … '영어'」처럼 문장 자리 말 뒤 25자 안에 온 인용은 그 문장에서 찾으므로, 다른 문장의 인용을 바로 뒤에 두지 말 것
- 쓰기 전에 「오답도 참이 될 수 있는 빈칸」을 먼저 살필 것: 'only one of them …', 'only if …'처럼 조건·한쪽만을 묻는 빈칸에서 오답이 지문과 어긋나지 않으면 답이 둘이 됨(32번 30번째, 33번 28번째에서 오답을 바꿈)
- 40번은 쓰기 전에 선택지를 요약문에 넣어 소리 내어 읽듯 확인할 것: ① 넣으면 말이 깨지는 오답(길이를 맞추려고 덧붙인 것) ② 한쪽 낱말이 지문과 같은 뜻이 되어 답으로도 읽히는 오답
- 한 답변에 10문항(읽기 → 쓰기 → 점검). 원고는 10문항씩 나눠 쓰고 끝에 하나로 합침
- 원고의 `«…»`는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜(12자 이상만). 그 밖의 영어는 작은따옴표나 괄호

### 수정안에서 쓸 수 있는 항목(202번에 보탠 것)
- `'text': [(옛, 새), ...]` — 한 문항의 지문 여러 군데를 고칠 때(`passage_ok: True`가 있어야 함). 한 군데면 예전처럼 `(옛, 새)` 하나도 됨
- `'cw_new': '낱말'` — 「올바른 낱말」(correctWord) 칸이 비어 있던 문항에 새로 넣기. 같은 칸(유형·레벨)의 다른 문항에 그 칸이 있을 때만. 이미 있는 칸을 고칠 때는 `'cw'`
- 본보기: `examples/edits_S1_번호자리_correctWord.py`(29·30번 번호 자리 옮기기 35곳 + 30번 레벨1 일곱 문항)

### 23번 레벨9 선택지를 명사구로(203번~)
- `n23common.py`의 `R(E, n, ch, ko, subs, walk_sub)` — 선택지와 해설 머리(영어·우리말 해석)를 함께 바꾸고, 해설 글과 풀이에서 옛 선택지의 영어를 옮긴 조각만 맞춤. 정답 문구가 바뀌므로 `ans_ok`(선생님 승인: 202번)
- `python3 zcheck.py` — 승인 목록을 폴더의 `edits_N1*.py`에서 읽어 옴. 「눈으로 볼 것」에는 'not A but B' 같은 틀만 남아야 함(옛 선택지의 영어 조각이 남으면 여기에 뜸)
- 고칠 때 볼 것: 다섯 선택지의 길이 차례·정답의 길이 순위(build 출력의 「정답순위」와 레벨9 칸별 표)
- 본보기: `examples/edits_N1a·b·c_23L9_명사구.py`(30문항, 선택지 116개). **a·b는 이미 바탕에 들어가 있어 다시 돌리면 멈춤**(옛 조각이 없으므로) — 꼴을 보는 본보기로만 쓸 것. 23번 레벨9에는 이제 how·why로 시작하는 선택지가 없음
- 레벨6~8(206번~): `from n23common import R as _R` 뒤 `_R(E, n, ch, ko, lv='8')`. 이 레벨들은 해설이 짧아 머리(영어 인용·우리말 해석)만 맞추면 됨 — 본보기 `examples/edits_N8_23L8_명사구.py`. 검사는 `python3 zcheckN.py 8`(해설 글·풀이·해석이 한 글자도 안 바뀌었는지, why·how 꼴이 남았는지)

### 레벨8 해설 두텁게(209번~)
- 23번: `z23common.py`의 `mk = maker(E, lv='8')` → `mk(n, 정답 자리, [적용 네 줄], 끌리는 오답, [까닭 × 5])`. 선택지 영어와 우리말 해석은 지금 있는 것을 그대로 가져옴(폴더에 `edits_N8.py`가 있으면 그 명사구 선택지를 씀). 검사는 `python3 zcheck23.py 8`
- 꼴과 글투는 레벨9 때와 같음(인계문서 176번). 레벨8은 지문이 100낱말쯤이라 풀이가 조금 짧음(평균 1,400자쯤)
- 35번: `z35common.py`의 `mk = maker(E, lv='8')` → `mk(n, [적용 네 줄], 헷갈리는 곳, [번호 문장 다섯 개의 설명])`(177번의 도우미에 레벨 인자를 단 것). 검사는 `python3 zcheck35.py 8`(레벨9는 `python3 zcheck35.py 9`) — 따옴표 없는 영어 낱말, 「③의 also」처럼 번호와 함께 든 낱말이 그 번호 문장에 있는지도 봄
- 36-37번: `z3common.py`의 `maker(E, lv='8')`(레벨 인자를 달았음 — 안 주면 레벨9). 검사는 `python3 zcheck3637.py 8` — 「(A)의 them」「주어진 글의 signs」처럼 글을 지목한 영어가 그 글에 있는지, 적용 2)~4) 줄의 인용이 그 줄의 글에 있는지도 봄
- 36-37번 레벨8 본보기는 셋으로 나뉘어 있음: `examples/edits_Y3a·b·c_3637L8.py`(b가 a의 2·7번째를 다시 쓰므로 하나로 합치지 않음 — 차례대로 `edits_Y3a,edits_Y3b,edits_Y3c`). 지문과 해석을 함께 고칠 때는 `fix(n, (옛, 새) 또는 [(옛, 새), …], (옛 해석, 새 해석) 또는 [ … ])` — `'text'`와 `'ko'` 둘 다 여러 군데를 받음
- 38-39번: `z5common.py`의 `mk = maker(E, lv='8')` → `mk(n, 답 자리(1~5), [적용 네 줄], 헷갈리는 곳, [자리별 설명 5개])`, `seg(지문)`은 삽입 문장과 조각 여섯을 돌려줌. 검사는 `python3 zcheck3839.py 8`(레벨9는 9). **레벨9 때(180번) 만든 `z5common.py`·`seg.py`·`zcheck3839.py`는 도구 묶음에서 빠져 있어 220번에 다시 만들었음**(레벨9의 30문항에 돌려 통과 확인). 42번용 도우미도 같은 까닭으로 없을 수 있으니, 42번을 시작할 때 앱에 들어 있는 레벨9 해설의 꼴을 보고 다시 만들 것
- 42번: `z7common.py`의 `mk = maker(E, lv='8')` → `mk(n, 답 기호('a'~'e'), [뜻풀이 5개], [바꾸어 넣을 낱말], [적용 네 줄], 헷갈리는 곳, [낱말별 설명 5개])`. 낱말별 해설의 머리(기호·낱말·뜻풀이·「문맥에 맞습니다.」/「정답입니다.」)는 자동. 검사는 `python3 zcheck42.py 8 edits_Y5a,edits_Y5b`(뒤의 수정안 이름은 바꾸어 넣을 낱말을 읽어 오려는 것 — 안 주면 그 낱말들이 「지문에 없는 영어」로 뜸). 큰따옴표로 옮길 때 밑줄 기호 (a)~(e)는 빼고 옮길 것. **레벨9 때의 `z7common.py`·`zcheck42.py`도 도구 묶음에서 빠져 있어 223번에 다시 만들었음**
- 31~34번 레벨8: `mk = maker(E, '31', lv='8')`. 오답 선택지를 바꾸는 문항은 `mk(..., ch={자리: '새 선택지'})`(해설 머리와 문항에 함께 반영). 검사는 `python3 zcheck31.py 31 8`(유형, 레벨) — 레벨8에서 오답을 바꾼 문항은 `ITEM_FIX8`에 적음. `show.py`(지문·선택지·옛 해석 한꺼번에 읽기: `python3 show.py 33 8 10 20`), `fin.sh`(만들기+자체 검사+종합 점검: `bash fin.sh "edits_Y8a,edits_Y8b" 33 8`)
- 40·41번 레벨8: `from z40common import maker; mk = maker(E, lv='8')`, `from z41common import maker; mk = maker(E, lv='8')`. 오답을 바꾸면 `mk(..., ch={자리: '새 선택지'})`, 정답 낱말까지 고치면 `ans_ok=True`를 함께(인계문서에 까닭을 적은 문항만). 검사는 `python3 zcheck40.py 40 8`, `python3 zcheck41.py 41 8`. `show41.py`(41번 읽기: `python3 show41.py 8 0 10`), `fin40.sh`(`bash fin40.sh "edits_Y10,edits_Y11" zcheck41.py 41 8`). **선택지를 고친 뒤에는 verify.py의 길이 점검표(144/144칸)를 꼭 볼 것** — 정답이 가장 긴 선택지가 되면 그 칸이 A에 걸림
- **pending/ 폴더**(256번~): 아직 GitHub에 올라가지 않았을 수 있는 수정안을 낱개로 넣어 둠(레벨7: `edits_W5b`~`edits_W11c` 스무 개). GitHub의 index.html이 인계문서 마지막 항목의 크기와 다르면, 이 폴더의 파일을 작업 폴더로 복사해 `python3 build.py <목록> out/index.html`로 다시 만들 수 있음. examples/의 유형별 합본(`edits_W1_…`~`edits_W11_…`)은 보관용 — **이미 얹힌 바탕에 `ch=`가 든 합본을 다시 얹으면 apply가 막으니**, 다시 만들 때는 pending/의 낱개를 쓸 것
- 레벨7 읽기 도구: `show3637.py`·`show3839.py`·`show40.py`·`show42.py`·`show23.py`·`show35.py`(모두 `python3 <도구> 7 0 10` 꼴), 31~34번은 `show.py 31 7 0 10`, 41번은 `show41.py 7 0 10`. 한 묶음 끝내기 `fin7.sh`·`fin42.sh`
- **X 계열 수정안(257번~)**: 레벨6 아래를 「검토해서 탈이 있는 문항만 고치는」 일. 30문항을 다 읽고(`show3839.py`·`show3637.py`·`showb.py <유형> <레벨> 0 30`) 답이 둘로 읽히는 문항만 `mk(...)`로 고침 — 고친 문항은 해설도 두터운 꼴로 새로 씀. 검사는 유형별 zcheck에 레벨 인자(`python3 zcheck3839.py 6`, `python3 zcheck31.py 33 6`)를 주고, 고친 문항을 그 도구의 예외 목록(ITEM_FIX…)에 ('6', 몇째-1)로 적을 것

## 레벨 기준으로 재기 (314번~)

| 파일 | 하는 일 |
|---|---|
| `levelgauge2.py` | 문장을 구문 분석해 짜임(이은 문장·종속절·명사절·관계사절·분사구문)과 낱말 수준을 잼. `python3 levelgauge2.py 31 1`(한 칸, 문장마다 짜임이 붙어 나옴) / `python3 levelgauge2.py`(전체, 20분쯤 → `gauge_all.json`·`gauge_items.json`) |
| `wordlists.json` | 낱말 목록: NGSL 2,800(기초) · AWL 570족 + NAWL 963(학술) |
| `verdict314.py` | 칸마다 ○·△·× 판정(선은 인계문서 314번에 적어 둠) |
| `build_page314.py` + `page/template.html` | 측정표 페이지 자료(`page_data.json`)와 페이지(`page/level-gauge.html`)를 만듦. 페이지 주소: https://claude.ai/artifact/9qawWZ94DbUKWsS7Ahpmu4 (다시 재면 이 주소를 갱신) |
| `gauge_all.json` · `gauge_items.json` | 314번에 잰 값(바탕 `6ed6ca6`). 문항을 고치면 그 칸은 다시 잴 것 |
| `finish314.py` | 메모 갱신 → 페이지 만들기 → zip·인계문서를 `/home/claude/outputs/`에 둠 (경로를 모두 절대 경로로 적음) |

설치: `pip install spacy wordfreq cefrpy --break-system-packages` → `pip install --break-system-packages "spacy-curated-transformers>=0.3,<0.4"` → `pip install --break-system-packages https://github.com/explosion/spacy-models/releases/download/en_core_web_trf-3.8.0/en_core_web_trf-3.8.0-py3-none-any.whl`
(setup.sh는 이것을 설치하지 않음 — 잴 때만 설치)

## 레벨 기준에 맞게 다시 쓰기 (315번~)

| 파일 | 하는 일 |
|---|---|
| `zlevel.py` | 새로 쓴 지문을 문장마다 재서 레벨 기준에 어긋난 문장을 보여 줌. `python3 zlevel.py 31 1 0-14 4` |
| `zsolve.py` | 독립 풀이에 줄 문제지(지문 + 선택지 / 선택지만 / 빈칸 문장 + 선택지 / 해설 교정용)를 만들고 정답 줄·정답 길이 순위를 보여 줌(318번 · 320번). `PYTHONPATH=pending python3 zsolve.py edits_X56a 20 2 0-14 <폴더>` |
| `regauge.py` | 한 칸을 다시 재서 `gauge_all.json`·`gauge_items.json`의 그 칸만 바꿔 넣음(319번). `python3 /home/claude/work/regauge.py 20 2` → 틀의 「그 뒤 맞춘 칸」 줄 → `build_page314.py` → 페이지를 **주소(`url`)와 함께** 올림 |
| `pending/edits_X55a.py` | 31번 레벨1 앞 절반 — 빈칸 유형을 통째로 다시 쓰는 `rw()` 꼴의 본보기(z8common의 두터운 해설 + rewrite) |
| `pending/edits_X58a.py` · `edits_X58b.py` | 33번 레벨1 앞 절반(322번)·뒤 절반(323번) — 선택지 다섯을 통째로 넘기는 `rw(n, ans, text, c5, ko, steps, traps, cn)` 꼴(바뀐 자리는 스스로 가려냄). 오답을 모두 다시 쓰는 칸의 본보기 |
| `pending/edits_X59a.py` · `edits_X59b.py` | 34번 레벨1 앞 절반(324번)·뒤 절반(325번) — 「곳이 한 가지를 바꿈 → 그 전의 탈」 갈래를 레벨1로 쓴 본보기(관계사절 which suggests를 풀어 짝꿍 문장으로) |
| `done/edits_X60a.py` · `edits_X60b.py` (330번 파일이 GitHub `38a4f49`에 올라가 331번에 done/으로 옮김 — `edits_X55a`~`X59b`도 함께) | 38-39번(문장 넣기) 레벨1 앞 절반(327번)·뒤 절반(328번) — `rw(n, 답 자리, 주어진 문장, [지문 다섯 문장], 해석(주어진 문장), [해석 다섯 문장], [적용 네 줄], 헷갈리는 곳, [자리별 해설 다섯])` 꼴. `z5common.maker(E, lv='1')`의 두터운 해설 + rewrite · **329번**: 두 파일의 `rw`가 `mk(..., moved=True)`로 답 자리를 수정안이 정함(`'answer': ans-1`). 앞 절반(`edits_X60a`)은 329번에 다시 손봄(답 줄 431342523514521) · 뒤 절반은 아직 328번 그대로 · **330번**: 뒤 절반(`edits_X60b`)도 정답 자리를 옮겨 다시 씀(답 줄 341534225312514). 문항의 자리를 맞바꿀 때는 `rw(n, …)`의 n만 바꾸면 됨(선택지는 문항마다 같음) · 앞 절반은 풀이 1)의 말 열한 곳만 맞춤 |
| `done/edits_X61a.py` (331번 파일이 GitHub `33c7629`에 올라가 332번에 done/으로 옮김 — 지금 `pending/`은 빔) | 38-39번(문장 넣기) 레벨1 앞 절반(331번 — 여섯 가지의 2·3·4번). 바탕 `38a4f49` 위에 얹었던 수정안. 열다섯 문항 모두 rewrite(답 줄 423143552314521). 덩이의 꼴은 `edits_X60a`와 같음 |
| `paper/extract.py` · `paper/make.js` · `paper/scrub.py` · `paper/items.json` | **학생용 시험지와 선생님용 답·채점표 만들기(332번 — 38-39번 한 칸).** `python3 /home/claude/work/paper/extract.py 1` (out/index.html의 38-39번 레벨1 서른 문항 → `items.json`) → `cd /home/claude/work/paper && node make.js <폴더>` (Word 둘) → `python3 /home/claude/work/paper/scrub.py <폴더>` (숨은 정보 비우기 · 문단 테두리 차례를 규격대로). 「답 적는 곳」은 첫 쪽에 둘 것(맨 뒤에 두면 표가 갈라짐). 다른 유형은 선택지가 있어 꼴을 새로 잡아야 함 |
| `z3839draft.py` | 38-39번 원고 도구(327번). ① `PYTHONPATH=pending python3 z3839draft.py match edits_X60a 1 0 15` — 낱말 맞추기 검사(답 자리가 혼자 가장 많이 겹치는 문항 0이 목표) + 재기 (「자리 규칙」 줄: 가리키는 말이 든 첫/둘째/마지막 문장의 앞 자리가 답인 문항 수 — 어느 것도 절반을 넘지 않게) ② `python3 z3839draft.py sheets 1 0 15 <폴더> <꼬리표>` — 독립 검사에 줄 문제지 셋(_full: 답 모르고 풀기 · _skip: 주어진 문장을 뺀 지문 · _explain: 해설 교정) |
| `pending/edits_X62a.py` | **36-37번(글의 순서) 레벨1 앞 절반(333번 — 1~15번째).** `rw(n, 주어진 글, {'A':[문장…],'B':[…],'C':[…]}, 주어진 글 해석, {'A':[해석…],…}, [풀이 네 줄], 헷갈리는 곳, [선택지별 해설 다섯], 낱말 줄)` 꼴. `z3637common.maker(E,'1')`이 정답 번호·선택지·발문은 바탕 그대로 두고 지문·해석·풀이·해설만 통째로 바꿈. 바탕 `e2ceda8` 위에 얹음 |
| `pending/edits_X62b.py` | **36-37번(글의 순서) 레벨1 뒤 절반(334번 — 16~30번째).** 꼴은 `edits_X62a.py`와 같음. `edits_X62a`와 함께 바탕 `e2ceda8` 위에 얹음: `PYTHONPATH=pending python3 build.py edits_X62a,edits_X62b out/index.html`. 만든 법: `draft/d62b.py`(영어) + `draft/ko62b_1.py` · `ko62b_2.py`(한글) → `python3 draft/gen62.py b` |
| `pending/edits_X63a.py` | **21번(함축 의미) 레벨1 앞 절반(335번 — 1~15번째).** `rw(n, 지문(밑줄 <u>…</u>), [선택지 다섯], 해석, [풀이 1)~4)], 헷갈리는 곳, [선택지별 까닭 다섯], [선택지 우리말 다섯], 낱말 줄)` 꼴. `z21common.maker(E,'1')`이 정답 번호는 바탕 그대로 두고 지문 · 선택지 · 해석 · 풀이 · 해설을 통째로 바꿈. 바탕 `e2ceda8` 위에 `edits_X62a,edits_X62b`와 함께 얹음: `PYTHONPATH=pending python3 build.py edits_X62a,edits_X62b,edits_X63a out/index.html`. 만든 법: `draft/d63a.py`(영어: 지문 · 선택지 · 정답 자리) + `draft/ko63a_1.py` · `ko63a_2.py`(한글) → `python3 draft/gen63.py a` |
| `pending/edits_X63b.py` | **21번(함축 의미) 레벨1 뒤 절반(337번 — 16~30번째).** 꼴은 `edits_X63a.py`와 같음. 바탕 `e2ceda8` 위에 `edits_X62a,edits_X62b,edits_X63a,edits_X63b`를 모두 얹음: `PYTHONPATH=pending python3 build.py edits_X62a,edits_X62b,edits_X63a,edits_X63b out/index.html`. 만든 법: `draft/d63b.py`(영어) + `draft/ko63b_1.py` · `ko63b_2.py`(한글) → `python3 draft/gen63.py b`. 길이 순위는 `python3 zrank.py b` |
| `done/edits_X64a.py` (GitHub `45c0790`에 올라가 344번에 done/으로 옮김 — 다시 얹지 말 것) | **40번(요약문 완성) 레벨1 앞 절반(338번 — 1~15번째).** `rw(n, [지문 네 문장], 요약문(영어, (A) ______ · (B) ______ 하나씩), [선택지 다섯: 'a - b'], 지문 해석, 요약문 해석, [풀이 1)~4)], 끌리는 오답, [선택지별 까닭 다섯], [선택지 우리말 다섯], 낱말 줄)` 꼴. `z40rw.maker(E,'1')`이 정답 번호는 바탕 그대로 두고 지문 · 요약문 · 선택지 · 해석 · 풀이 · 해설을 통째로 바꿈(인용 «…»이 지문에 없으면 · 문장 자리가 어긋나면 · 풀이 4)에 정답 선택지가 없으면 멈춤). 바탕 `58a8f22` 위에 얹음: `PYTHONPATH=pending python3 build.py edits_X64a,edits_X64b out/index.html`. 만든 법: `draft/d64a.py`(영어: `I[n]=(지문, 요약문, 선택지, 정답 자리)`) + `draft/k64a_1.py` · `k64a_2.py`(한글 `K[n]=dict(kop, kosm, steps, trap, reasons, gl, words)`) → `python3 draft/gen64.py a` → `PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X64a.py` |
| `done/edits_X64b.py` (GitHub `45c0790`에 올라가 344번에 done/으로 옮김 — 다시 얹지 말 것) | **40번 레벨1 뒤 절반(339번 — 16~30번째).** 꼴은 `edits_X64a.py`와 같음. 만든 법: `draft/d64b.py`(영어) + `draft/k64b_1.py`(15~21) · `k64b_2.py`(22~29)(한글) → `python3 draft/gen64.py b`. 길이 순위는 `from apply import rank`(1 + 더 긴 선택지 수) 또는 `zlevel.py 40 1 0-29 5` |
| `done/edits_X65a.py` (GitHub `45c0790`에 올라가 344번에 done/으로 옮김 — 다시 얹지 말 것) | **29번(어법) 레벨1 앞 절반(340번 — 1~15번째).** `rw(n, 갈래, [지문 다섯 문장(밑줄 ①~⑤, 정답 자리는 틀린 꼴)], 올바른 꼴(cw), [해석 다섯], [선택지별 해설 다섯], '낱말 줄')` 꼴. `z29rw.maker(E)`가 정답 번호 · 발문은 바탕 그대로 두고 지문 · 해석 · 풀이 · 해설을 통째로 바꿈(밑줄 개수 · 정답 자리가 바탕과 다르면 · `correctWord`가 틀린 꼴과 같으면 · 노트 꼴이 어긋나면 멈춤). 갈래: sv · there · past · modal · plural · pron(`INTRO` · `RULE`). 바탕 `58a8f22` 위에 얹음: `PYTHONPATH=pending python3 build.py edits_X64a,edits_X64b,edits_X65a,edits_X65b out/index.html`. 만든 법: `draft/d65a.py`(영어: `I[n]=dict(cat, cw, S)`) + `draft/k65a.py`(한글: `K[n]=dict(ko, notes, words)`) → `python3 draft/gen65.py a` → `PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X65a.py` |
| `done/edits_X65b.py` (GitHub `45c0790`에 올라가 344번에 done/으로 옮김 — 다시 얹지 말 것) | **29번 레벨1 뒤 절반(341번 — 16~30번째).** 꼴은 `edits_X65a.py`와 같음. 만든 법: `draft/d65b.py` + `draft/k65b.py` → `python3 draft/gen65.py b` |
| `done/edits_X66a.py` (GitHub `45c0790`에 올라가 344번에 done/으로 옮김 — 다시 얹지 말 것) | **30번(어휘) 레벨1 앞 절반(342번 — 1~15번째).** `rw(n, [지문 다섯 문장(표시 ①~⑤, 정답 자리는 틀린 말)], 올바른 말(cw), [해석 다섯(정답 자리는 「틀린 뜻(→ 올바른 뜻)」)], [표시 낱말의 뜻 다섯], [자리별 설명 다섯], '낱말 줄')` 꼴. `z30rw.maker(E)`가 정답 번호 · 발문은 바탕 그대로 두고 지문 · 해석 · 풀이 · 해설을 통째로 바꿈(표시 개수 · 정답 자리가 바탕과 다르면 · 틀린 말과 올바른 말이 같으면 · 설명 꼴(정답 자리 「원래는 cw(뜻)」, 나머지 「맞아요.」로 끝)이 어긋나면 멈춤). 바탕 `58a8f22` 위에 얹음: `PYTHONPATH=pending python3 build.py edits_X64a,edits_X64b,edits_X65a,edits_X65b,edits_X66a,edits_X66b out/index.html`. 만든 법: `draft/d66a.py`(영어: `I[n]=dict(cw, S)`) + `draft/k66a.py`(한글: `K[n]=dict(ko, gl, notes, words)`) → `python3 draft/gen66.py a` → `PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X66a.py` |
| `done/edits_X66b.py` (GitHub `45c0790`에 올라가 344번에 done/으로 옮김 — 다시 얹지 말 것) | **30번 레벨1 뒤 절반(343번 — 16~30번째).** 꼴은 `edits_X66a.py`와 같음. 만든 법: `draft/d66b.py` + `draft/k66b.py` → `python3 draft/gen66.py b` |
| `pending/edits_X67a.py` | **(버림 — 349번)** 31번 레벨2 첫 판 앞 절반(345번). 마지막 문장만 보면 30/30 풀려 353번에 `edits_X70a.py`로 대체됨. 빌드에 넣지 말 것 |
| `pending/edits_X67b.py` | **(버림 — 349번)** 31번 레벨2 첫 판 뒤 절반(346번). `edits_X70b.py`로 대체됨 |
| `pending/edits_X68a.py` | **(버림 — 349번)** 32번 레벨2 첫 판 앞 절반. 마지막 문장만 보면 30/30 풀려 351번에 `edits_X69a.py`로 대체됨. 빌드에 넣지 말 것 |
| `pending/edits_X68b.py` | **(버림 — 349번)** 32번 레벨2 첫 판 뒤 절반. `edits_X69b.py`로 대체됨 |
| `pending/edits_X69a.py` | **32번(빈칸 — 낱말) 레벨2 앞 절반(351번 — 1~15번째), A/B 두 조건 꼴.** 꼴은 `edits_X67a.py`와 같음(`rw(n, 정답 번호, 지문(네 문장), 해석, [풀이 1)~4)], 끌리는 오답, [(선택지 뜻, 까닭)×5], ch={…})`, `z8common.maker(E,'32',lv='2')`). 영어는 `draft/d69.py`(서른 문항 한 파일), 한글은 `draft/k69_1.py`~`k69_6.py`(다섯 문항씩) → `python3 draft/gen69.py a` |
| `pending/edits_X69b.py` | **32번 레벨2 뒤 절반(351번 — 16~30번째).** 만든 법: `python3 draft/gen69.py b` |
| `pending/edits_X70a.py` | **31번(빈칸 추론) 레벨2 앞 절반(353번 — 1~15번째), A/B 두 조건 꼴.** 꼴은 `edits_X69a.py`와 같음(`rw(n, 정답 번호, 지문(네 문장), 해석, [풀이 1)~4)], 끌리는 오답, [(선택지 뜻, 까닭)×5], ch={…})`, `z8common.maker(E,'31',lv='2')`). 영어는 `draft/d70.py`(서른 문항 한 파일), 한글은 `draft/k70_1.py`~`k70_6.py`(다섯 문항씩) → `python3 draft/gen70.py a` |
| `pending/edits_X70b.py` | **31번 레벨2 뒤 절반(353번 — 16~30번째).** 만든 법: `python3 draft/gen70.py b` |
| `pending/edits_X71a.py` | **31번(빈칸 추론) 레벨1 앞 절반(354번 — 1~15번째), 단문 100%에 정답 낱말이 글에 그대로 나오는 새 꼴.** 영어 `draft/d71.py`(서른 문항 한 파일), 한글 `draft/k71_1.py`~`k71_6.py`(다섯 문항씩) → `python3 draft/gen71.py a` |
| `pending/edits_X71b.py` | **31번 레벨1 뒤 절반(354번 — 16~30번째).** 만든 법: `python3 draft/gen71.py b` |
| `pending/edits_X72a.py` | **32번(빈칸 — 낱말) 레벨1 앞 절반(356번 — 1~15번째), 자연 · 과학 관찰 이야기 · 단문 100% · 정답 낱말이 글에 그대로 나오는 새 꼴.** 영어 `draft/d72.py`(서른 문항 한 파일), 한글 `draft/k72_1.py`~`k72_6.py`(다섯 문항씩) → `python3 draft/gen72.py a` |
| `pending/edits_X72b.py` | **32번 레벨1 뒤 절반(356번 — 16~30번째).** 만든 법: `python3 draft/gen72.py b`. 한꺼번에: `./fin73.sh`(gen72 a/b → zjosa2 → 빌드 `edits_X72a,edits_X72b` — 바탕 52750ec에는 X69~X71이 이미 들어 있음) |
| `pending/edits_X73a.py` | **33번(빈칸 — 구) 레벨1 앞 절반(357번 — 1~15번째), 한 사람의 일과 · 버릇 이야기 · 단문 100% · 정답 구가 글에 그대로 나오는 새 꼴(지문과 빈칸 문장에 only 등으로 닫음).** 영어 `draft/d73.py`(서른 문항 한 파일), 한글 `draft/k73_1.py`~`k73_6.py`(다섯 문항씩) → `python3 draft/gen73.py a` |
| `pending/edits_X73b.py` | **33번 레벨1 뒤 절반(357번 — 16~30번째).** 만든 법: `python3 draft/gen73.py b`. 한꺼번에: `./fin74.sh`(gen73 a/b → zjosa2 → 빌드 `edits_X73a,edits_X73b` — 바탕 510e17c에는 X69~X72가 이미 들어 있음) |
| `pending/edits_X74a.py` | **34번(빈칸 — 긴 구) 레벨1 앞 절반(358번 — 1~15번째), 조건 대비 꼴(두 경우에 각각 다른 긴 구) · 단문 100% · 정답 긴 구가 글에 그대로.** 영어 `draft/d74.py`, 한글 `draft/k74_1.py`~`k74_6.py` → `python3 draft/gen74.py a` |
| `pending/edits_X74b.py` | **34번 레벨1 뒤 절반(358번 — 16~30번째).** 만든 법: `python3 draft/gen74.py b`. 한꺼번에: `./fin75.sh`(gen74 a/b → zjosa2 → 빌드 `edits_X74a,edits_X74b` — 바탕 5c14ac4에는 X69~X73이 이미 들어 있음) |
| `pending/edits_X75a.py` | **40번(요약문 완성) 레벨1 앞 절반(359번 — 1~15번째), 지어낸 일상 장면 · 두 경우를 맞세우고 요약문이 조건으로 한 경우를 골라 (A)·(B)를 물음.** `z40rw.maker` 꼴(`rw(n, [지문], 요약문, [보기], 해석, 요약문 해석, [풀이 4줄], 끌리는 오답, [까닭 5], [짝 뜻 5], 낱말 줄)`). 영어 `draft/d75.py`, 한글 `draft/k75_1.py`~`k75_6.py` → `python3 draft/gen75.py a` |
| `pending/edits_X75b.py` | **40번 레벨1 뒤 절반(359번 — 16~30번째).** 만든 법: `python3 draft/gen75.py b`. 한꺼번에: `./fin76.sh`(gen75 a/b → zjosa2 → 빌드 `edits_X75a,edits_X75b` — 바탕 5bf74b1에는 X69~X74가 이미 들어 있음) |
| `pending/edits_X82a.py` · `edits_X82b.py` | **26번(내용 일치) 레벨1(366번)** — 다섯 문장 · 단문 · 지어낸 사람 이야기, 보기 다섯은 문장 순서대로 하나씩(정답만 한 가지를 비틂). `z26common.maker(E)`의 `rw(n, 정답 자리, 지문, [보기], [해석], 풀이, 낱말)`. 영어 `draft/d83.py`, 점검 `draft/chk83.py` → `python3 draft/gen83.py a|b` · `./fin83.sh`(GitHub 최신본을 받고 그 위에 X82만) |
| `pending/edits_X83a.py` · `edits_X83b.py` | **41-42번(장문 제목 · 낱말 쓰임) 레벨1(367번)** — 다섯 문장 · 단문 · 지어낸 이야기(17) + 설명형(13), 41번 보기는 쌍둥이 제목, 42번은 같은 글에서 한 낱말을 반의어로 바꿈. 41번 `z24common.maker(E, '41', '1', NS=5)`, 42번 `z42common.maker(E)`의 `rw(n, 지문, [해석], [뜻], [설명], 틀린 낱말, 낱말)`. 영어 `draft/d84.py`(+ `d84_new.py`), 점검 `draft/chk84.py`, 한글 `draft/k84_*.py` · `zk84.py` → `python3 draft/gen84.py a|b` · `./fin84.sh`(GitHub 최신본을 받고 그 위에 X83만) |
| `pending/edits_X84a.py` · `edits_X84b.py` | **43번(글의 순서 · 장문 세트) 레벨1(368번)** — 주어진 글 한 문장 + 세 덩이 × 두 문장 · 단문 · 잠금 chain(앞 덩이 끝에서 처음 나온 것을 다음 덩이의 가리키는 말이 받음, 갈래 T/R/P/C/O/M 섞음). `z43common.maker(E, '1')`의 `rw(n, 주어진 글, {B,C,D: [문장 둘]}, 해석, {B,C,D: [해석 둘]}, [풀이 네 줄], 헷갈리는 곳, [해설 다섯], 낱말)`. 영어 `draft/d85.py`, 점검 `draft/chk85.py` · `plan85.txt` · `z43draft.py`, 시험지 `draft/mksheet85.py` · `score85.py`, 한글 `draft/k85_*.py` · `zk85.py` → `python3 draft/gen85.py a|b` · `./fin85.sh`(GitHub 최신본을 받고 그 위에 X84만) · 교정 시트 `draft/mkproof85.py` · 사용량 `measure85.py` |
| `pending/edits_X85a.py` · `edits_X85b.py` | **44번(지칭 대상이 나머지와 다른 것 · 장문 세트) 레벨1(369번)** — 같은 성별 두 사람(주인공 M · 도우미 H) 한 단락 일곱 문장 · 표시 (a)~(e) 다섯 가운데 넷은 M, 하나(바탕 정답 자리)만 H. `z44common.maker(E)`의 `rw(n, 지문, [해석 일곱], M, H, [설명 다섯], 낱말)`. 영어 `draft/d86.py`(= `rework87.py`가 만든 최종본) · 점검 `draft/chk86.py` · 자리표 `plan86.txt` · 시험지 `draft/mksheet86.py`(글 전체 full.txt / **표시 문장만** marks.txt) · `score86.py`, 한글 `draft/k86_*.py` · `zk86.py` → `python3 draft/gen86.py a|b` · `./fin86.sh`(GitHub 최신본을 받고 그 위에 X85만) · 교정 시트 `draft/mkproof86.py` · `proof86_lean.txt` · 사용량 `measure86.py` |
| `pending/edits_X80a.py` · `edits_X80b.py` | **23번(주제) 레벨1(364번)** — 네 문장 · 단문 · 지어낸 이야기 + 주제문 하나 · 보기 다섯은 「how/why + 요인 + 같은 결과」(맞수는 오답). `z23common.maker(E)`의 `rw(n, 정답 자리, 지문, [보기], 해석, 주제문, 해석, 자리, 풀이, 바꾸어 말함, 낱말, [까닭], [보기 해석])`. 영어 `draft/d81.py`, 한글 `draft/k81_1~3.py` → `python3 draft/gen81.py a|b` · `./fin81.sh`(GitHub 최신본을 받고 그 위에 X80만) |
| `pending/edits_X79a.py` · `edits_X79b.py` | **22번(요지) 레벨1(363번)** — 네 문장 · 단문 · 지어낸 이야기 + 교훈 문장 하나 · 보기 다섯은 같은 틀 · 다른 요인. `z22common.maker(E)`의 `rw(n, 정답 자리, 지문, [보기], 해석, 요지 문장, 해석, 자리, 풀이, 바꾸어 말함, 낱말, [까닭])`. 영어 `draft/d80.py`, 한글 `draft/k80_1~6.py` → `python3 draft/gen80.py a|b` · `./fin80.sh`(GitHub 최신본을 받고 그 위에 X79만) · 검사 `draft/chk80.py` · `draft/zk80.py` · 시험지 `python3 draft/mksheet80.py d80 <폴더>` · 점수 `python3 score_any.py <폴더> 22 1` |
| `pending/edits_X78a.py` · `edits_X78b.py` | **20번(주장) 레벨1(362번)** — 네 문장 · 단문 · 주장 문장 하나(명령문 · should · must) + 필자가 흔한 조언을 물리치는 꼴. `z20common.maker(E)`의 `rw(n, 정답 자리, 지문, [보기], 해석, 주장 문장, 해석, 자리, 풀이, 바꾸어 말함, 낱말, [까닭])`. 영어 `draft/d79.py`, 한글 `draft/k79_1~6.py` → `python3 draft/gen79.py a|b` · `./fin79.sh`(바탕 27d580d 위에 X78만) · 검사 `draft/chk79.py` · `draft/zk79.py` · 점수 `python3 score_any.py <폴더> 20 1` |
| `pending/edits_X77a.py` · `edits_X77b.py` | **19번(심경 변화) 레벨1(361번)** — 네 문장 · 단문 · 주인공의 마음 낱말 그대로 + 다른 사람의 마음 낱말 미끼. `z19common.maker(E)`의 `rw(n, 정답 자리, 지문, [보기], 해석, 처음 문장, 해석, 풀이, 나중 문장, 해석, 풀이, [보기 뜻], 낱말, [까닭])`. 영어 `draft/d78.py`, 한글 `draft/k78_1~6.py` → `python3 draft/gen78.py a|b` · `./fin78.sh`(바탕 7b287fb 위에 X77만) · 검사 `draft/chk78.py` · `draft/zk78.py` · 점수 `python3 score_any.py <폴더> 19 1` |
| `pending/edits_X76a.py` · `edits_X76b.py` | **18번(글의 목적) 레벨1(360번)** — 편지 본문 네 문장(단문) · 목적 문장 + 곁가지. `z18common.maker(E, '18', '1')`의 `rw(n, 정답 자리, 편지, [보기 다섯], 해석, 목적 문장, 그 해석, 몇째, 풀이 ②, 낱말, [까닭 다섯])`. 영어 `draft/d76.py`, 한글 `draft/k76_1~6.py` → `python3 draft/gen77.py a|b` · 한꺼번에 `./fin77.sh`(바탕 3735e9a 위에 X76만) |
| `z21common.py` · `zcheck21.py` · `zjosa2.py` · `zjosacmp.py` | 21번 다시 쓰기 도구(335번). `zcheck21.py 1`: 밑줄 하나 · 풀이 1)에 밑줄 친 말 · 4)에 정답 선택지 · 큰따옴표 인용이 지문에 있는지 · 「~니다」 말끝 없음 · 정답 번호 불변 · 정답 선택지의 길이 순위. `zjosa2.py --strict [--fix] 원고.py…` / `zjosa2.py --data 쪽.html`: 괄호 · 「」 뒤 조사(은/는 · 이/가 · 을/를 · 와/과 · (으)로 · (이)라고 · 이에요/예요)가 **괄호 바로 앞 낱말**(영어는 CMU 발음사전, 숫자·A/B/C는 읽는 소리)의 받침과 맞는지 — **어느 유형이든 해설 원고를 쓴 뒤 `--strict --fix`로 돌릴 것**(336번 선생님 결정; `build.py`가 둘 다 어긋난 진짜 오류는 자동으로 고침; `cmudict` 필요 — `pip install cmudict --break-system-packages`). `zjosacmp.py 앞.html 뒤.html 이름`: 두 쪽 사이에 바뀐 해설 글이 조사뿐인지 칸별로 보여 줌. 옛 `zjosa.py`는 **쓰지 말 것**(괄호 안 기준 — 잘못) |
| `z3637common.py` · `z3637draft.py` · `draft/d62a.py` · `draft/ko62a_*.py` · `draft/gen62.py` | 36-37번 다시 쓰기 도구(333번). `z3637draft.py match <원고 모듈>` — 낱말 맞추기 검사(통째 · 맞물림) + `zlevel` 재기. `d62a.py`는 영어 원고 `I[n]=(주어진 글,{A,B,C},정답 순서)`, `ko62a_*.py`는 한글(해석 · 풀이 · 헷갈리는 곳 · 선택지별 해설 · 낱말), `python3 draft/gen62.py a`가 이 둘을 합쳐 `pending/edits_X62a.py`를 만듦(뒤 절반은 `d62b.py` · `ko62b_*.py`를 같은 꼴로 만들고 `gen62.py b`) |
| `pack.py` | 내보내기: zip·index.html·인계문서를 `/home/claude/outputs/`에 둠. `python3 /home/claude/work/pack.py` |

순서: 원고(지문) → `zlevel`로 재기 → 해설 쓰기 → `PYTHONPATH=pending python3 build.py (수정안들) out/index.html` → `zcheck31.py`·`check_all.py` → 독립 풀이 세 가지(답 모르고 풀기 · 선택지만 보고 찍기 · 해설 교정 — `LEVEL_GUIDE.md` 「선택지를 쓰는 법」) → 인계문서 → `pack.py`
명령은 `cd /home/claude/work && …`로 시작하되, 먼저 `pwd`로 자리를 확인할 것

- 36-37번을 레벨 기준으로 다시 쓸 때(333번): 검사는 `python3 zcheck3637.py 1`(다시 쓴 문항은 `ITEM_FIX`에 `('1', n)`이 들어 있음 — 레벨1 서른 문항 모두) · `PYTHONPATH=pending python3 z3637draft.py match edits_X62a`(문장 수 일곱 = 주어진 글 + 세 덩이 × 두 문장) · `python3 regauge.py 36_37 1`. 해설 교정용 문제지는 `PYTHONPATH=pending python3 zsolve.py edits_X62a 36_37 1 0-14 <폴더>`(뒤 절반은 `edits_X62b 36_37 1 15-29`)(explain.txt). 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「36-37번 레벨1의 꼴」

- 38-39번을 레벨 기준으로 다시 쓸 때(327번): 검사는 `python3 zcheck3839.py 1`(다시 쓴 문항은 `ITEM_FIX`에 `('1', n)`을 넣어야 함) · `python3 zlevel.py 38_39 1 0-14 6`(문장 수 6 = 주어진 문장 + 지문 다섯) · 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「38-39번(문장 넣기) 레벨1의 꼴」
- `z20common.py` · `zcheck20.py`(317번): 20번(주장)을 레벨 기준으로 다시 쓸 때의 도우미와 검사. `pending/edits_X56a.py`가 본보기 — 지문·선택지 다섯·해석·주장 문장·까닭·선택지별 까닭을 한 번에 적음
- 21번을 레벨 기준으로 다시 쓸 때(335번): 검사는 `python3 zcheck21.py 1`(다시 쓴 문항은 `ITEM_FIX`에 `('1', n)`) · 문장 재기는 `zlevel.check_texts('21','1',{n:(지문,정답)},5)`. 해설 교정용 문제지는 `PYTHONPATH=pending python3 zsolve.py edits_X63a 21 1 0-14 <폴더>`(explain.txt) · 뒤 절반은 `zsolve.py edits_X63b 21 1 15-29 <폴더>`. 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「21번 레벨1의 꼴」
- 40번(요약문)을 레벨 기준으로 다시 쓸 때(338·339번): 검사는 `python3 zcheck40.py 1`(다시 쓴 문항은 `ITEM_FIX1`/`ANS_FIX1`이 `draft/d64a.py` · `d64b.py`에서 가져옴) · `python3 zlevel.py 40 1 0-29 5`(문장 수 5 = 지문 넷 + 요약문) · `python3 regauge.py 40 1`. 해설 교정용 문제지는 `PYTHONPATH=pending python3 zsolve.py edits_X64b 40 1 15-29 <폴더>`(solve_full.txt = 답 가림 풀이용 · explain.txt = 교정용; 범위는 `a-b` 하나만 받음). 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「40번(요약문 완성) 레벨1의 꼴」
- 29번(어법)을 레벨 기준으로 다시 쓸 때(340·341번): 검사는 `python3 zcheck29.py out/index.html`(밑줄 · 정답 자리 · 틀린 꼴/올바른 꼴 · 노트 꼴 · 문장 수 · 오차 교정한 지문의 낱말 수 · `Mr.` 처리) · `python3 zlevel.py 29 1 0-29 5` · `python3 regauge.py 29 1`. 독립 풀이 문제지는 `python3 solve65.py <폴더> ab explain`(blind.txt = 답 가림 풀이용 · audit.txt = 우겨 보기용 · explain.txt = 교정용). 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「29번(어법) 레벨1의 꼴」
- 30번(어휘)을 레벨 기준으로 다시 쓸 때(342·343번): 영어 원고만 보는 검사는 `python3 zcheck30.py`(표시 · 정답 자리 · 틀린 말 ≠ 올바른 말 · 올바른 말로 고친 지문의 단문 · 문장 10~15낱말), 빌드 뒤 검사는 `python3 zcheck30b.py out/index.html`(해설 머리 «① 낱말(뜻) — » · 「원래는 cw(」 · 풀이 인용 · 「(→ …)」 한 번) · `python3 regauge.py 30 1`. 독립 풀이 문제지는 `python3 solve66.py <폴더> ab`(blind.txt · audit.txt), `python3 solve66.py <폴더> ab explain`이 해설 교정용 explain.txt도 씀(빌드한 out/index.html에서 읽음). 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「30번(어휘) 레벨1의 꼴」
- 31번(빈칸 추론)을 레벨1로 **새 꼴**로 다시 쓸 때(354·355번): 영어 `python3 draft/chk71.py draft/d71.py`(정답 낱말이 둘째 · 셋째 문장에 글자 그대로 있는지 · 넷째에는 없는지 · `zlevel` RULE 1) · 한글 `python3 draft/zk69.py draft/k71_N.py draft/d71.py` · 한 번에 `./fin71.sh`, 그다음 `python3 zcheck31.py 31 1`(`ANS_FIX[('1','31',n)]` 서른 개) · `check_all.py` · `regauge.py 31 1`. 마지막 문장만 푸는 시험: `python3 solve72.py <폴더> <유형> <레벨> <d파일 이름>`(blind · last · audit 시트 — 예 `python3 solve72.py sheets72c 31 1 d71`) → 풀이꾼 답(`ans_last1.txt` · `ans_last2.txt` · `ans_blind.txt` · `ans_audit.txt`) → `python3 score72.py <폴더> <유형> <레벨>`(옛 `solve71.py` · `score71.py`는 31번 L1 바탕 고정). 교정용 문제지 `python3 mkproof.py 31 1 <출력>`
- **길이 점검표**(355번): 새로 쓴 칸은 `python3 lencheck.py <유형> <레벨> draft/dNN.py`(원고의 ch만으로 verify.py와 같은 규칙) → 빌드 뒤 `python3 lenfix.py <유형> <레벨>`(문항별 R1~R5 · B · C 표시) → `check_all.py` ④의 「전체 N/144칸 끝남」이 **143**(바탕과 같음)인지. 세 칸을 한꺼번에 다시 만들 때 `./fin72.sh`(gen69 · gen70 · gen71 a/b → zjosa2 → 빌드 `edits_X69a,edits_X69b,edits_X70a,edits_X70b,edits_X71a,edits_X71b`)
- 32번 레벨1(356번): 영어 `python3 draft/chk72.py draft/d72.py`(chk71과 같음, 유형 32) · 초안을 쓰는 중에는 `python3 draft/lenpart.py 32 1 draft/d72_N.py`(부분 원고의 보기 길이: 문항별 R · 합계) · 한글 `python3 draft/zk69.py draft/k72_N.py draft/d72.py` · 한 번에 `./fin73.sh` → `python3 zcheck31.py 32 1`(`ANS_FIX[('1','32',n)]` 서른 개) · `check_all.py`(④ 143) · `lenfix.py 32 1` · `regauge.py 32 1`. 풀이꾼: `python3 solve72.py sheets73a 32 1 d72` → `score72.py sheets73a 32 1`. 교정용 문제지 `python3 mkproof.py 32 1 <출력>`
- 33번 레벨1(357번): 영어 `python3 draft/chk73.py draft/d73.py`(chk72와 같음, 유형 33) · 초안 길이 `python3 draft/lenpart.py 33 1 draft/d73.py` · 한글 `python3 draft/zk69.py draft/k73_N.py draft/d73.py` · 한 번에 `./fin74.sh` → `python3 zcheck31.py 33 1`(`ANS_FIX[('1','33',n)]` 서른 개 — 옛 322 · 323번의 네 항목을 뒤의 `update`가 덮어씀) · `check_all.py`(④ 143) · `lenfix.py 33 1` · `regauge.py 33 1`. 풀이꾼: `python3 solve72.py sheets76 33 1 d73`(세 번째 인자는 .py 없이) → `score72.py sheets76 33 1`. 교정용 문제지 `python3 mkproof.py 33 1 <출력>`
- 34번 레벨1(358번): 영어 `python3 draft/chk74.py draft/d74.py` · 초안 길이 `python3 draft/lenpart.py 34 1 draft/d74.py` · 한글 `python3 draft/zk69.py draft/k74_N.py draft/d74.py` · 한 번에 `./fin75.sh` → `python3 zcheck31.py 34 1` · `check_all.py`(④ 143) · `lenfix.py 34 1` · `regauge.py 34 1`. 풀이꾼: `python3 solve72.py sheets80 34 1 d74` → `score72.py sheets80 34 1`. **지금 판을 먼저 재는 법**(다시 쓰기 전): 빌드한 out/index.html에서 마지막 문장 · 보기만 뽑는 짧은 코드는 인계문서 358번(`sheets77/`). 교정 지적을 고침꾼에게 맡길 때는 지적 번호 [n] = 원고 K[n-1], 원고의 «…»가 문제지에는 "…"로 보인다는 것을 알려 줄 것. 문자열 치환 도우미 `patch75.py`(`patch(파일, [(옛, 새), …])` — 하나라도 없으면 아무것도 안 씀)
- 40번 레벨1(359번): 영어 `python3 draft/chk75.py draft/d75.py`(정답 낱말이 지문에 그대로 · (A)(B) 순서 · `zlevel` 문장 다섯) · 초안 길이 `python3 draft/lenpart.py 40 1 draft/d75.py` · 한글 `python3 draft/zk75.py draft/k75_N.py`(z40rw 확인 + 해요체 · 인용 · 길이 480~900자) · 한 번에 `./fin76.sh` → `python3 zcheck40.py 40 1`(이제 `draft/d75.py`를 읽음) · `python3 zlevel.py 40 1 0-29 5` · `check_all.py`(④ 143) · `regauge.py 40 1`. 지금 판 시험 문제지는 `sheets81/`처럼 빌드한 out/index.html에서 요약문(text를 빈 줄로 나눈 뒷부분)과 보기만 뽑음(인계문서 359번). 풀이꾼 점수 `score72.py <폴더> 40 1`
- 18번 레벨1(360번): 영어 `python3 draft/chk76.py draft/d76.py`(편지 꼴 · 본문 네 문장 · 보기 「~하려고」) · `python3 draft/lenpart.py 18 1 draft/d76.py` · 한글 `python3 draft/zk76.py draft/k76_N.py`(z18common 확인 + 해요체 · 인용 · 풀이 ② 길이) · `./fin77.sh` → `check_all.py`(④ 143) · `regauge.py 18 1` · `lenfix.py 18 1`. 빈칸이 없는 유형의 시험: **보기만 보고 찍기**(sheets84 · sheets85의 last.txt = 보기만) + 편지 전체 풀기 + 감사꾼. 점수는 sheets85의 짧은 코드(인계문서 360번)
- 31번(빈칸 추론)을 레벨2로 **A/B 꼴**로 다시 쓸 때(353번): 영어 `python3 draft/chk70.py draft/d70.py` · 한글 `python3 draft/zk69.py draft/k70_N.py draft/d70.py`(둘째 인자를 빼면 d69와 대조해 거짓 경고가 쏟아짐) · 한 번에 `./fin70.sh`(gen70 a/b → zjosa2 → 빌드는 `edits_X69a,edits_X69b,edits_X70a,edits_X70b`), 그다음 `python3 zcheck31.py 31 2` · `check_all.py` · `regauge.py 31 2`. 마지막 문장만 푸는 시험: `python3 solve70.py <폴더> d70` → 풀이꾼 답 → `python3 score70.py <폴더>`. 교정용 문제지: `python3 mkproof.py 31 2 <출력파일>`(빌드한 out/index.html에서 뽑음). (아래는 버린 첫 판의 도구) 345·346번: 영어 원고만 보는 검사는 `python3 draft/chk67.py a|b`(`zlevel.check_texts`로 문장 수 4 · 문장당 10~15낱말 · 단문/이은 문장만 · 선택지를 바꾼 문항은 바꾼 정답으로), 빌드 뒤 검사는 `python3 zcheck31.py 31 2`(`ITEM_FIX2` · `ANS_FIX` 넷) · `python3 zlevel.py 31 2 0-29 4` · `python3 regauge.py 31 2`. 독립 풀이 문제지는 `python3 solve67.py <폴더> ab`(blind.txt · audit.txt, 원고 d67a/b에서 만듦). 빌드한 out/index.html에서 blind/explain 문제지를 뽑는 짧은 코드는 인계문서 346번. 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「31번(빈칸 추론) 레벨2의 꼴」
- 32번(빈칸 — 낱말)을 레벨2로 **A/B 꼴**로 다시 쓸 때(351번): 영어 `python3 draft/chk69.py draft/d69.py` · 한글 `python3 draft/zk69.py draft/k69_N.py` · 한 번에 `./fin69.sh`(gen69 a/b → zjosa2 → 빌드 → 빌드는 `edits_X67a,edits_X67b,edits_X69a,edits_X69b`), 그다음 `python3 zcheck31.py 32 2` · `check_all.py` · `regauge.py 32 2`. 마지막 문장만 푸는 시험: `python3 solve69.py <폴더> d69`(blind.txt · last.txt · audit.txt) → 풀이꾼 답 `ans_*.txt` → `python3 score69.py <폴더>`. 교정용 문제지는 빌드한 out/index.html에서 뽑음(인계문서 351번). (아래는 버린 첫 판의 도구) 347·348번: 영어 원고만 보는 검사는 `python3 draft/chk68.py a|b`, 한 번에 돌리기는 `./fin68.sh`(gen68 a/b → zjosa2 → 빌드 → `zcheck31.py 32 2`), 그다음 `python3 check_all.py` · `python3 regauge.py 32 2`. 독립 풀이 문제지는 `python3 solve68.py <폴더> ab`(blind.txt · audit.txt, 원고 d68a/b에서 만듦). 빌드한 out/index.html에서 교정용 문제지(영어 · 선택지 · 해석 · 풀이 · 선택지 해설)를 뽑는 코드는 인계문서 348번. 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「32번(빈칸 — 낱말) 레벨2의 꼴」
- 33번(빈칸 — 구) 레벨2(377번): 영어 `python3 draft/chk90.py draft/d90.py`(「같은 것 넷 + 다른 하나」 짝 · 보기 다섯의 np 꼴 · 정답 구 낱말이 모두 글에 있는지 · 길이 점검표 · 다른 칸과 글감 겹침) · 시험지 `python3 draft/mksheet90.py s2NN`(마지막 문장만 `last1|last2` · 지문 전체 `blind1|blind2` · 감사 `audit.txt`) → 풀이를 `ans.txt`에 받아 `python3 draft/score90.py s2NN`으로 채점 · 한글 `python3 draft/chkk90.py draft/k90_N.py`(= `zk90.py` + maker 확인 + 해요체 말끝 + A–E 표시 외 영어 금지; 본보기 `draft/k90_model.py`, 영어 원고 보기 `draft/d90_view.txt`) · 한 번에 `./fin90.sh`(gen90 a/b → zjosa2 → 빌드) → **`python3 restore90.py out/index.html`**(build.py의 fix_josa가 건드린 맡은 칸 밖을 GitHub 최신본으로 되돌림 — 이것을 빠뜨리면 `guard.py`가 막음) → `check_all.py`(④ 143) · `regauge.py 33 2` · 사용량 `python3 measure90.py`
- 23번(주제) 레벨7~9(375 · 378번): 수정안 `pending/edits_Z23e · f · g · h`(L9) · `edits_Z23L8a~c`(L8) · `edits_Z23L7a~c`(L7) → 빌드 `python3 build.py edits_Z23e,edits_Z23f,edits_Z23g,edits_Z23h,edits_Z23L8a,edits_Z23L8b,edits_Z23L8c,edits_Z23L7a,edits_Z23L7b,edits_Z23L7c out/index.html` · 점검 `python3 m23r.py <한 레벨의 수정안들>`(문항별 ◀ · 머리말 줄 · 묶음 줄) · 기출 견주기 `python3 draft/measure_level.py <레벨> [index]` · 보기 훑기 `python3 show23r.py` · 채점 `python3 score.py 답파일:정답표:이름`(정답표는 `s192/` · `s193/`). patch5~9는 이미 수정안에 들어가 있으니 다시 돌리지 말 것.
- 35번(무관한 문장) 레벨7~9(380번): 수정안 `pending/edits_Z35P`(시범) · `edits_Z35L9a · L9b · L8a · L8b · L7a · L7b` → 빌드 `python3 build.py edits_Z35P,edits_Z35L9a,edits_Z35L9b,edits_Z35L8a,edits_Z35L8b,edits_Z35L7a,edits_Z35L7b out/index.html`(정답 자리 이동은 `ans_move.py` 승인 칸) · 점검 `python3 m35r.py <한 레벨의 수정안들>` · 기출 견주기 `cd draft && python3 analysis35.py [index]` · 눈가림 시험지 `python3 draft/mk35sheet.py shuf|full <real|L9|index:레벨> <폴더>` → 채점 `python3 draft/score35.py 답:정답표:이름`(시험 기록 `s194/`).
- 34번(빈칸 — 긴 구) 레벨2(379번): 영어 `python3 draft/chk91.py draft/d91.py`(「같은 것 넷 + 다른 하나」 짝 · 보기 다섯의 np 꼴과 전치사 하나 · 정답 구 낱말이 모두 글에 있는지 · 머리말 흔함 비율 · 길이 점검표 · 다른 칸과 글감 겹침) · 시험지 `python3 draft/mksheet91.py s2NN`(마지막 문장만 `last1|last2` · 지문 전체 `blind1|blind2` · 감사 `audit.txt`) → 풀이를 `ans.txt`에 받아 `python3 draft/score91.py s2NN`으로 채점 · 한글 `python3 draft/chkk91.py draft/k91_N.py`(= `zk91.py` + maker 확인 + 해요체 말끝 + A–E 표시 외 영어 금지; 본보기 `draft/k91_model.py`, 영어 원고 보기 `draft/d91_view.txt`) · 한 번에 `./fin91.sh`(gen91 a/b → zjosa2 → 빌드) → **`python3 restore91.py out/index.html`**(build.py의 fix_josa가 건드린 맡은 칸 밖을 GitHub 최신본으로 되돌림 — 빠뜨리면 `guard.py`가 막음) → `check_all.py`(④ 143) · `regauge.py 34 2` · 사용량 `python3 measure91.py` · 도구 묶음 `python3 draft/pack91.py <출력 zip>`
- 38-39번(문장 넣기) 레벨2(381번): 영어 `python3 draft/chk92.py draft/d92.py`(문장 10~15낱말 · 레벨2 문법 · 낱말 맞추기가 답을 혼자 고름 0 · 자리 규칙 · 삽입 문장 꼴/때가 답 자리에 묶이지 않음 · 다른 칸과 글감 겹침) · 시험지 `python3 draft/mksheet92.py <폴더>`(전체 `full.txt` · 건너뛴 곳 `skip.txt` · 정답표 `key.txt`) → 풀이를 `ans.txt`에 받아 `python3 draft/score92.py <key.txt> <ans.txt> [이름]`으로 채점(맞힘 · 확신 · 둘째 답) · 한글 `python3 draft/zk92.py draft/k92_N.py draft/d92.py`(본보기 `draft/k92_probe.py`, 작성자 지침 `draft/brief_k92.txt`) · 한 번에 `./fin92.sh`(GitHub 최신본 받기 → gen92 a/b → zjosa2 → 빌드 → **`restore92.py`**: fix_josa가 건드린 맡은 칸 밖을 GitHub 최신본으로 되돌림 — 빠뜨리면 `guard.py`가 막음) → `check_all.py` · `regauge.py 38_39 2` · 사용량 `python3 measure92.py` · 도구 묶음 `python3 draft/pack92.py <출력 zip>`
- 31~34번(빈칸) 레벨7~9(382번): 수정안 `pending/edits_W31L7a · L7b · L8a · L8b · L9a · L9b`(32 · 33 · 34번도 같은 이름 꼴, 모두 24개) → 빌드 `python3 build.py edits_W31L7a,…,edits_W34L9b out/index.html` · 점검 `python3 m3134r.py <한 칸의 a · b>` · 기출 견주기 `draft/analysis3134.py`(기출 `draft/real3134.py`) · 눈가림 시험지 `python3 draft/mk3134sheet.py co|bs|full <real|index:레벨> <폴더>`(TYPES=32 로 유형 거르기) → 채점 `python3 draft/score3134.py <폴더> co sonnet` · 되먹임 `draft/fb3134.py` · `draft/flag3134.py` · 고친 문항만 `draft/recheck3134.py` · 철자 `draft/usspell3134.py`(시험 기록 `s195/`).
- 36-37번(글의 순서) · 38-39번(문장 넣기) 레벨7~9(383번): 수정안 `pending/edits_V36L7a · L7b · L8a · L8b · L9a · L9b`(38번은 `edits_V38…` 같은 꼴, 모두 12개) → 빌드 `python3 build.py edits_V36L7a,…,edits_V38L9b out/index.html`(정답 자리 이동은 `ans_move.py` 승인 칸 여섯) · 지침 `BRIEF_3639R.md` · 본보기 `example3639.py` · 표 보기 `python3 show3639.py 36_37 8 0 15` · 점검 `python3 m3639r.py <한 칸의 a · b>`(문항별 ◀) · 고친 문항 바꿔 넣기 `python3 splice3639.py <원래 모듈.py> <바꿀 모듈.py>`(같은 n만 바꿈, `.bak` 남김) · 기출 견주기 `python3 draft/analysis3639.py [real]`(기출 `draft/real3639.py` — 내부 통계용) · 눈가림 시험지 `MODE=full|open|adj python3 draft/mk3639sheet.py "<모듈+모듈>:레벨" <폴더>` → 채점 `python3 draft/rep3639.py <폴더>` · 바꾼 문항만 `draft/mkch3639.py` · 고친 문항만 `draft/mkfx3639.py` · 표본 점검 `draft/mkaudit3639.py` · 글감 `draft/topics3639.py`(→ `used_topics3639.txt`) · 겹침 `draft/dup3639.py`(시험 기록 `s196/`).
- 21번(함축 의미) 레벨2(386번): 영어 `python3 draft/chk93.py draft/d93.py`(문장 10~15낱말 · 레벨2 문법 · 보기 길이 순위 · 센 말 · 끝말 · 같은 원고 + 다른 칸과 글감 겹침; 영어 원고는 이야기 `draft/d93_S.py`(짝수 n) + 설명글 `draft/d93_E.py`(홀수 n)를 `draft/merge93.py`로 합쳐 `d93.py`) · 시험지 `python3 draft/mksheet93.py <폴더> [d파일]`(`full.txt` 전체 · `last.txt` 밑줄 문장만 · `cue.txt` 보기만 · `key.txt`) → 채점 `python3 draft/score93.py <key> <ans> <이름>`(답 줄 `[n] <1~5> sure|unsure [second=<k|none>]`) · 한글 `python3 draft/zk93.py draft/k93_a.py draft/d93.py`(a=n0~9 · b=n10~19 · c=n20~29; 본보기 `draft/k93_probe.py`, 지침 `draft/brief_e93.txt` · `draft/brief_k93.txt`) · 빌드 `NUM=<번호> ./fin93.sh`(gen93 → zjosa2 → build → restore93; 편집 도우미 `z93common.py`) · 사용량 `python3 measure93.py`. **길이표**: 보기를 쓸 때 `python3 lencheck.py 21 2 <d파일>`을 먼저(355번 이후 규칙; 이번엔 빌드 뒤에야 보고 142/144로 떨어져 오답 보기 다섯 곳을 줄임).
- 29번(어법) 레벨2(387번): 영어 `python3 draft/chk94.py draft/d94.py`(문장 5개 · 10~15낱말 · 레벨2 문법 · 갈래별 규칙; 영어 원고는 이야기 + 설명글을 `draft/d94_T.py`(때) + `draft/d94_P.py`(가리키는 말)로 나눠 쓰고 `draft/merge94.py`로 `d94.py`) · 시험지 `python3 draft/mksheet94.py <폴더> [d파일]`(`full.txt` 전체 · `alone.txt` 문장 하나씩 · 키는 `<폴더>_key/`) → 채점 `python3 draft/score94.py full|alone <key> <ans> <이름>`(답 줄 `[n] <1~5> sure|unsure second=<k|none> wrong=certain|arguable`, 문장 시험은 `[n.k] right|wrong sure|unsure`) · 한글 `python3 draft/zk94.py draft/k94_a.py draft/d94.py`(a=n0~9 · b=n10~19 · c=n20~29; 본보기 `draft/k94_probe.py`, 지침 `draft/brief_e94.txt` · `draft/brief_k94.txt`) · 빌드 `NUM=<번호> ./fin94.sh`(gen94 → zjosa2 → build → restore94(맡은 칸 밖 되돌림 + correctWord 넣기); 편집 도우미 `z94common.py`) · 사용량 `python3 measure94.py`. **correctWord는 이제 29번 레벨1 · 레벨2와 30번 레벨1에 있다**(위 「주의」 3번 갱신).
- 30번(어휘) 레벨2(389번): 영어 `python3 draft/chk95.py draft/d95.py [처음 끝]`(문장 5개 · 10~15낱말 · 레벨2 문법 · 표시 위치와 품사 · 틀린 낱말/올바른 낱말 · 같은 어근 · S/E 시제 · 낱말 쌍 되풀이 · 다른 칸과 글감 겹침; 영어 원고는 `draft/d95_pilot.py` · `d95_W1~W3.py`를 `draft/merge95.py`로 `d95.py`) · 시험지 `python3 draft/mksheet95.py <폴더> [d파일]`(`full.txt` 전체 · `alone.txt` 문장 하나씩 · 키는 `<폴더>_key/`) → 채점 `python3 draft/score95.py full|alone <key> <ans> <이름>`(답 줄 `[n] <1~5> sure|unsure second=<k|none> wrong=certain|arguable`, 문장 시험은 `[n.k] right|wrong sure|unsure`) · 한글 `python3 draft/zk95.py draft/k95_a.py draft/d95.py`(a=n0~9 · b=n10~19 · c=n20~29; 본보기 `draft/k95_probe.py`, 지침 `draft/brief_e95.txt` · `draft/brief_k95.txt`; 교정꾼 지적을 한꺼번에 반영한 `draft/fix95_k.py`와 조사를 괄호 안 한글에 맞추는 `draft/josa95_k.py`) · 빌드 `NUM=<번호> ./fin95.sh`(gen95 → zjosa2 → build → restore95(맡은 칸 밖 되돌림 + correctWord 넣기); 편집 도우미 `z95common.py`) · 사용량 `python3 measure95.py`. **correctWord는 이제 29번 레벨1 · 레벨2와 30번 레벨1 · 레벨2에 있다**(위 「주의」 3번 갱신).
- 35번(무관한 문장) 레벨2(390번): 영어 `python3 draft/chk96.py draft/d96.py [처음 끝]`(첫 문장 + 번호 문장 5개 · 10~15낱말 · 레벨2 문법 · 쉬운 낱말 · 무관한 문장의 갈래 · 핵심어 · 겹침비 · 사고팔기 낱말 · 첫 낱말 · 길이 순위 · 다음 문장 이음; 영어 원고는 `draft/d96_pilot.py` · `d96_W1~W3.py`를 `draft/merge96.py`로 `d96.py`) · 시험지 `python3 draft/mksheet96.py <폴더> [d파일]`(`full.txt` 전체 · `shuf.txt` 섞은 여섯 문장 · 키는 `<폴더>_key/`) → 채점 `python3 draft/score96.py full|shuf <key> <ans> [이름]` · 한글 `python3 draft/zk96.py draft/k96_a.py draft/d96.py`(본보기 `draft/k96_probe.py`, 지침 `draft/brief_e96.txt` · `draft/brief_k96.txt` · 교정꾼 지침 `draft/brief_p96*.txt`; 교정꾼 지적을 한꺼번에 반영한 `draft/fix96_k.py`와 조사 `draft/josa96_k.py`) · 빌드 `NUM=<번호> ./fin96.sh`(gen96 → zjosa2 → build → restore96(맡은 칸 밖 되돌림); 편집 도우미 `z96common.py`). 35번에는 correctWord가 없다.
- 40번(요약문 완성) 레벨2(391번): 영어 `python3 draft/chk97.py draft/d97.py [처음 끝]`(지문 다섯 문장 + 요약문 · 문장당 10~15낱말 · 레벨2 문법 · 쉬운 낱말 · 정답 낱말이 지문에 없는지 · 반쪽 함정 · 보기 짜임 · 요약문 되풀이 · but 비율 · 이름/낱말 겹침; 영어 원고는 `draft/d97_W1~W3.py` + `d97_fix.py`를 `draft/merge97.py`로 `d97.py`) · 시험지 `python3 draft/mksheet97.py <폴더> d97`(`full.txt` 전체 · `sumonly.txt` 요약문과 보기만 · 키는 `<폴더>_key/`) → 채점 `python3 draft/score97.py full|sumonly <key> <ans> [이름]` · 한글 `python3 draft/zk97.py draft/k97_1.py`(k97_1~6, 도우미 `z97rw.py`; 지침 `draft/brief_e97.txt` · `brief_k97.txt` · 교정꾼 지침 `brief_p97*.txt` · 풀이꾼 지침 `prompt97*.txt`; 교정꾼 지적을 한꺼번에 반영한 `draft/fix97_k.py`) · 빌드 `./fin97.sh`(cmudict 확인 → gen97 → zjosa2 → build → restore97(맡은 칸 밖 되돌림)). 정답 문구는 보기 글자(`'a - b'`) 그대로.
- 36-37번(글의 순서) 레벨2(392번): 영어 `python3 draft/chk98.py draft/d98.py [처음 끝]`(주어진 글 한 문장 + (A)(B)(C) × 2문장 · 문장당 10~15낱말 · 레벨2 문법 · 쉬운 낱말 · 잠금 분포 · 단서 위치 · 낱말 맞추기 · 다른 칸과 글감 겹침; 영어 원고는 `draft/d98_W1~W3.py` + `fix98.py`를 `draft/merge98.py`로 `d98.py`) · 시험지 `python3 draft/mksheet98.py <폴더> d98 [1부터 센 번호 쉼표목록]`(`full.txt` 전체 · `open.txt` 덩이 첫 문장만 · 키는 `<폴더>_key/key.txt`) → 채점 `python3 draft/score98.py <key> <ans> [이름]` · 한글 `python3 draft/zk98.py draft/k98_1.py draft/d98.py`(k98_1~6; 교정 반영 `draft/fix98_k.py` · `fix98_k2.py`; 지침 `draft/brief_e98.txt` · `brief_k98.txt` · 교정꾼 `brief_p98*.txt` · 풀이꾼 `prompt98*.txt`) · 빌드 `./fin98.sh`(cmudict 확인 → gen98 → zjosa2 → build → restore98(맡은 칸 밖 되돌림)). 정답 번호는 바탕 그대로(보기 ①(A)-(C)-(B) ②(B)-(A)-(C) ③(B)-(C)-(A) ④(C)-(A)-(B) ⑤(C)-(B)-(A) 고정). 지시문에서 문항 번호는 0부터 센 열쇠인지 1부터 센 번호인지 꼭 적을 것.
