# 그루앙스 AI 수능영어코치 — 작업 도구 묶음

문항(index.html 안의 `TYPE_BANK`·`TYPE_EXPLAIN` 두 상수)을 고칠 때 쓰는 도구입니다.
방이 바뀌면 작업 폴더가 사라지므로, 이 묶음을 GitHub에 올려 두고 새 방에서 풀어 씁니다.

## 새 방에서 시작하는 법

```bash
git clone https://github.com/sehyeongjung-web/Gruance-English.git /home/claude/Gruance-English
unzip -o /home/claude/Gruance-English/gruance_tools.zip -d /home/claude/work
bash /home/claude/work/setup.sh
```

`setup.sh`가 저장소를 최신으로 맞추고, `out/`에 index.html·인계문서를 복사하고, 두 검증 도구를 돌려 현재 상태를 보여 줍니다.
그다음 **인계문서의 마지막 항목**을 읽고 이어서 작업합니다.

`setup.sh`는 맨 끝에 **`DEFERRED.md`**(나중에 하기로 미뤄 둔 일의 목록)도 보여 줍니다. 차례가 온 일이 있는지 먼저 보고, 한 가지를 끝내면 그 줄을 지운 뒤 인계문서에 적습니다. 새로 미루는 일은 그 파일에 보탭니다.

## 폴더 구조

| 자리 | 내용 |
|---|---|
| `/home/claude/Gruance-English/` | GitHub 복사본(바탕). 직접 고치지 않음 |
| `/home/claude/work/` | 이 도구들과 수정안 파일(`edits_*.py`) |
| `/home/claude/work/out/` | 만들어진 누적본(index.html)과 인계문서 |
| `/mnt/user-data/outputs/` | 선생님께 전달하는 파일 |

## 도구

| 파일 | 하는 일 |
|---|---|
| `lib.py` | index.html에서 두 상수를 읽고(`load`) 다시 써넣음(`save`). `span`은 상수의 범위 |
| `apply.py` | 수정안 파일을 바탕 파일에 적용. 정답·지문을 건드리면 멈춤(승인 표시가 있어야 통과) · **정답 자리 이동(329번)**: `rewrite`에 `'answer': 새 답(0~4)`과 수정안에 `'answer_ok': True`가 있고 그 칸이 `ans_move.py`의 `APPROVED`에 있을 때만 정답 자리를 바꿈(그 밖의 칸은 멈춤) |
| `ans_move.py` | **정답 자리를 옮겨도 된다고 선생님이 승인하신 칸**(329번: `('38_39','1')` 하나 — 「정답 자리 옮기더라도 수정하는 게 좋을 것 같습니다」). `apply.py` · `zcheck3839.py` · `check_all.py`가 이 목록을 봄. 승인 없이 칸을 보태지 말 것 |
| `build.py` | **누적본 만들기**: `python3 build.py edits_A,edits_B out/index.html` — 바탕(GitHub) 위에 수정안들을 차례로 적용 |
| `check_all.py` | **한 번에 점검**: 앱 코드 불변, 바뀐 문항 수, node --check, verify.py, verify_explain.py · 승인된 칸의 정답 자리 이동은 「승인된 칸의 정답 자리 이동」 줄에 따로 보여 줌(그 밖의 이동은 여전히 「정답 번호 변동」으로 멈춤) |
| `dump.py` | 문항 읽기: `python3 dump.py 24 3 200 all 60` (유형, 레벨, 지문 길이, all=전체, 해설 길이) |
| `qcheck.py` | 길이 작업용 인용 대조(레벨별): `python3 qcheck.py out/index.html 3` |
| `zcheck.py`·`zcheck35.py`·`zcheck3637.py` | 레벨9 해설 두텁게(176번~) 자체 검사(23번용·35번용·36-37번용): 큰따옴표 인용 전부 지문 대조, 오답 해설에 '정답' 없음, 풀이에 번호 없음, 문항 불변. 유형 코드만 바꿔 씀 |
| `z3common.py` | 36-37번 레벨9 해설 두텁게(178번)의 공통 도우미 — `edits_Z3`이 불러 씀. 정답 순서와 풀이의 글 차례가 다르면 멈춤 |
| `pending/` | **아직 GitHub에 올라가지 않았을 수 있는 수정안.** 인계문서 마지막 항목의 「다음에 시작할 때」를 보고, 안 올라갔으면 작업 폴더로 복사해 `build.py`에 함께 넘김 |
| `done/` | 이미 GitHub에 반영된 지난 수정안(다시 얹지 말 것 — 형식 참고용) |
| `examples/` | 실제로 쓴 수정안 파일 12개(`edits_Z1`·`edits_Z2`·`edits_Z3`은 176~178번 해설 두텁게 본보기. `edits_Z3`은 work 폴더에 `edits_Z3.py`로 복사해 씀)(형식 참고용). `edits_Y1~Y5`는 170~174번 틀 재작성(순서·지칭·일치, 레벨3·4) 본보기 — 도우미 함수로 본문·해석·풀이·해설을 자동 조립하는 방식 |

`verify.py`(형식·길이 점검표)와 `verify_explain.py`(선택지-해설 대조)는 저장소에 있는 것을 씁니다.

## 표준 절차

1. `git fetch`로 GitHub 최신 커밋을 확인한다. 지난번 파일이 올라갔으면 바탕을 그 커밋으로 옮긴다(`git reset --hard origin/main`). 안 올라갔으면 지난 수정안 파일들을 계속 함께 적용한다.
2. 고칠 칸을 **전부 읽는다**(`dump.py` 또는 직접 출력). 범위가 예상과 다르면 먼저 선생님께 말씀드린다.
3. 수정안 파일 `edits_이름.py`를 쓴다(아래 형식).
4. `python3 build.py (아직 안 올라간 수정안들),edits_이름 out/index.html`
5. `python3 check_all.py` — 다섯 항목이 모두 깨끗해야 한다.
6. 인계문서(`out/그루앙스_작업인계문서.md`) 끝에 새 번호 항목을 덧붙인다.
7. `out/index.html`과 인계문서를 `/mnt/user-data/outputs/`로 복사해 전달한다.

## 수정안 파일 형식

```python
AUTO_SYNC = True      # 해설이 선택지를 글자 그대로 인용한 곳을 함께 바꿈 (주의: 아래 '교훈' 참고)
E = {}
# 열쇠는 (유형, 레벨, 문항 번호) — 문항 번호는 0부터 센다(1번째 문항 = 0)
E[('24','3',5)] = {
    'ch': {1: '새 선택지', 3: '새 선택지'},          # 선택지 바꾸기(0~4 자리). 정답 자리는 'ans_ok': True가 있어야 함
    'kp': {1: '새 한글 해석'},                        # 해설의 "'영어' (한글 해석) — 설명"에서 괄호 속 해석
    'kq': {3: '새 한글 해석'},                        # 해설 맨 앞 따옴표 속 한글 해석 통째로
    'cn': {1: ('옛 조각', '새 조각'),                 # 해설의 한 조각 바꾸기(튜플 또는 튜플 목록)
           3: '해설 전체를 이 글로 바꿈'},            # 문자열이면 통째로 바꿈
    'walk_sub': [('옛 조각', '새 조각')],             # 풀이(walk)의 조각 바꾸기
    'ko': ('옛 조각', '새 조각'),                     # 해석(ko)의 조각 바꾸기
    'cw': 'smiled',                                   # 틀렸을 때 보여 주는 correctWord 바로잡기
    'text': ('옛 조각', '새 조각'), 'passage_ok': True,   # 지문 수정 — 선생님 승인이 있을 때만
}
# 문항을 통째로 새로 쓸 때(승인 필요): 정답 번호는 그대로, correctWord가 있는 문항은 'cw'도 함께
E[('44','3',7)] = {'passage_ok': True, 'ans_ok': True,
    'rewrite': {'text': '...', 'choices': [...5개...], 'ko': '...', 'walk': '...', 'cn': [...5개...]}}
```

## 지켜야 할 규칙

- **정답 번호·발문은 절대 바꾸지 않는다.** 지문과 정답 문구는 선생님 승인이 있을 때만(코드에서 `passage_ok`·`ans_ok`).
- 한 유형에서 10문항 이상 고칠 때, 지문을 고칠 때는 먼저 승인을 받는다.
- 길이 점검표(verify.py)의 다섯 조건 — A 정답이 긴 쪽에 과다(칸마다 정답 1~2위 ≤16문항, 1위 ≤8문항) · B 혼자 튀게 긴 선택지 · C 나머지보다 1.4배 이상 긴 선택지 · D 정답이 긴 쪽에 거의 안 옴(1~2위 ≥5문항) · E 정답만 혼자 짧음. 지금은 144칸 전부 ✅.
- 지문 길이는 칸 평균이 `LEN9 × RATIO`의 ±35% 안이어야 경고가 없다(verify.py 안에 표가 있음).
- 레벨1~3 해설은 "~어요" 말투, 레벨4 이상은 "~입니다" 말투.
- 선생님께 드리는 말은 쉬운 말로, 결론부터, 올릴 파일과 바이트 수를 밝힌다.

## 교훈 (같은 사고를 되풀이하지 않기 위해)

1. **자동 맞춤(AUTO_SYNC)은 해설 안의 '지문 인용'까지 바꿀 수 있다.** 선택지가 지문 문장과 글자까지 같은 칸(45번 레벨1·2)에서 일어났다 → 선택지를 고친 뒤 반드시 `verify_explain.py`를 돌린다(검사 9번이 잡아냄).
2. **정답 문구를 바꾸면 풀이(walk)도 본다.** 풀이가 옛 정답 문구를 인용하고 있으면 `walk_sub`으로 함께 고친다.
3. **correctWord**는 29번·30번 레벨1에만 있다. 문항을 다시 쓰면 함께 바꾼다(`rewrite`가 빠뜨리면 멈춤).
4. 틀 문제(같은 구조의 문항 반복)는 칸 전체를 읽어야 보인다. 견본 몇 개만 보고 범위를 말하지 않는다.

## 레벨9 해설 두텁게 도구 (176번~)

| 파일 | 유형 | 쓰는 법 |
|---|---|---|
| `zcheck.py` · examples의 `edits_Z1` | 23번 | 도우미 `mk`가 수정안 파일 안에 들어 있음 |
| `zcheck35.py` · `edits_Z2` | 35번 | 위와 같음 |
| `z3common.py` · `zcheck3637.py` · `edits_Z3` | 36-37번 | `mk(n, 'CAB', [적용 네 줄], 헷갈리는 곳, {순서: 설명})` |
| `z8common.py` · `zcheck31.py` · `edits_Z8_31L9.py` | 31번(32·33·34번도 같은 꼴) | `mk = maker(E, '31')` → `mk(n, 정답 자리(0~4), [적용 네 줄], 끌리는 오답, [(선택지 해석, 까닭)×5])` / `python3 zcheck31.py 31` |
| `z8common.py` · `zcheck31.py` · `edits_Z9_32L9.py` | 32번 | `mk = maker(E, '32')` → 나머지는 31번과 같음 / `python3 zcheck31.py 32` |
| `z8common.py` · `zcheck31.py` · `edits_Z11_33L9.py` | 33번 | `mk = maker(E, '33')` / `python3 zcheck31.py 33`. 오답을 바꾼 문항은 `mk` 뒤에 `E[...]['ch']`와 `E[...]['cn'][k]`를 덮어씀(3·28번째가 본보기) |
| `z8common.py` · `zcheck31.py` · `edits_Z12_34L9.py` | 34번 | `mk = maker(E, '34')` / `python3 zcheck31.py 34`. 14·19번째가 오답을 바꾼 본보기 |
| `z40common.py` · `zcheck40.py` · `edits_Z13_40L9.py` | 40번(요약문) | `mk = maker(E)` / `python3 zcheck40.py`. 요령 네 줄과 적용 줄 머리말(1) 요약문: / 2) (A) 찾기: / 3) (B) 찾기: / 4) 묶기:)이 40번용. 오답을 바꾸는 자리는 `FILL`을 넣고 뒤에서 `E[...]['ch']`·`['cn'][k]`를 덮어씀 |
| `z41common.py` · `zcheck41.py` · `edits_Z14_41L9.py` | 41번(장문 제목) | `mk = maker(E)` / `python3 zcheck41.py`. 요령 네 줄이 장문 제목용, 적용 줄 머리말은 23번과 같음(1) 되풀이: / 2) 꺾이는 곳: / 3) 끝 문장: / 4) 묶기:). 문장 자리는 문단을 넘어 열두째까지 셈. 「끝에서 둘째 문장」이라고 쓰지 말고 「끝에서 두 번째 문장」으로 쓸 것 |
| `edits_Z10_31L9_승인수정.py` | 31번 1·28번째 | 두텁게 쓴 뒤에 지문·오답을 고친 본보기(`text`+`passage_ok`, `ko`, `ch`, `walk_sub`, `cn`) |

- 38-39번(`z5common`·`zcheck3839`)과 42번(`z7common`·`zcheck42`) 도구는 182번 때 zip이 GitHub에 올라가지 않아 이 묶음에 없음. 해설 자체는 index.html에 들어 있고, 꼴은 인계문서 180번·182번에 적혀 있음
- `zcheck31.py` 맨 위의 `ITEM_FIX`(지문·오답을 고친 문항)와 `KO_FIX`(해석의 낱말 하나를 바로잡은 문항)에 적은 문항만 「문항·해석 불변」 검사에서 빼 줌. 새로 고치면 여기에 적고 인계문서에도 적을 것
- examples의 수정안은 **기록**임. GitHub에 반영된 뒤에는 다시 적용하지 않음(바탕이 이미 바뀌어 있어 멈춤)
- 원고에서 아포스트로피가 든 영어(object's 등)와 두 글자 낱말('no')은 작은따옴표로 옮기지 않음(따옴표 짝 검사가 어긋남). 「셋째 문장 … '영어'」처럼 문장 자리 말 뒤 25자 안에 온 인용은 그 문장에서 찾으므로, 다른 문장의 인용을 바로 뒤에 두지 말 것
- 쓰기 전에 「오답도 참이 될 수 있는 빈칸」을 먼저 살필 것: 'only one of them …', 'only if …'처럼 조건·한쪽만을 묻는 빈칸에서 오답이 지문과 어긋나지 않으면 답이 둘이 됨(32번 30번째, 33번 28번째에서 오답을 바꿈)
- 40번은 쓰기 전에 선택지를 요약문에 넣어 소리 내어 읽듯 확인할 것: ① 넣으면 말이 깨지는 오답(길이를 맞추려고 덧붙인 것) ② 한쪽 낱말이 지문과 같은 뜻이 되어 답으로도 읽히는 오답
- 한 답변에 10문항(읽기 → 쓰기 → 점검). 원고는 10문항씩 나눠 쓰고 끝에 하나로 합침
- 원고의 `«…»`는 지문을 글자 그대로 옮긴 큰따옴표 인용으로 바뀜(12자 이상만). 그 밖의 영어는 작은따옴표나 괄호

### 수정안에서 쓸 수 있는 항목(202번에 보탠 것)
- `'text': [(옛, 새), ...]` — 한 문항의 지문 여러 군데를 고칠 때(`passage_ok: True`가 있어야 함). 한 군데면 예전처럼 `(옛, 새)` 하나도 됨
- `'cw_new': '낱말'` — 「올바른 낱말」(correctWord) 칸이 비어 있던 문항에 새로 넣기. 같은 칸(유형·레벨)의 다른 문항에 그 칸이 있을 때만. 이미 있는 칸을 고칠 때는 `'cw'`
- 본보기: `examples/edits_S1_번호자리_correctWord.py`(29·30번 번호 자리 옮기기 35곳 + 30번 레벨1 일곱 문항)

### 23번 레벨9 선택지를 명사구로(203번~)
- `n23common.py`의 `R(E, n, ch, ko, subs, walk_sub)` — 선택지와 해설 머리(영어·우리말 해석)를 함께 바꾸고, 해설 글과 풀이에서 옛 선택지의 영어를 옮긴 조각만 맞춤. 정답 문구가 바뀌므로 `ans_ok`(선생님 승인: 202번)
- `python3 zcheck.py` — 승인 목록을 폴더의 `edits_N1*.py`에서 읽어 옴. 「눈으로 볼 것」에는 'not A but B' 같은 틀만 남아야 함(옛 선택지의 영어 조각이 남으면 여기에 뜸)
- 고칠 때 볼 것: 다섯 선택지의 길이 차례·정답의 길이 순위(build 출력의 「정답순위」와 레벨9 칸별 표)
- 본보기: `examples/edits_N1a·b·c_23L9_명사구.py`(30문항, 선택지 116개). **a·b는 이미 바탕에 들어가 있어 다시 돌리면 멈춤**(옛 조각이 없으므로) — 꼴을 보는 본보기로만 쓸 것. 23번 레벨9에는 이제 how·why로 시작하는 선택지가 없음
- 레벨6~8(206번~): `from n23common import R as _R` 뒤 `_R(E, n, ch, ko, lv='8')`. 이 레벨들은 해설이 짧아 머리(영어 인용·우리말 해석)만 맞추면 됨 — 본보기 `examples/edits_N8_23L8_명사구.py`. 검사는 `python3 zcheckN.py 8`(해설 글·풀이·해석이 한 글자도 안 바뀌었는지, why·how 꼴이 남았는지)

### 레벨8 해설 두텁게(209번~)
- 23번: `z23common.py`의 `mk = maker(E, lv='8')` → `mk(n, 정답 자리, [적용 네 줄], 끌리는 오답, [까닭 × 5])`. 선택지 영어와 우리말 해석은 지금 있는 것을 그대로 가져옴(폴더에 `edits_N8.py`가 있으면 그 명사구 선택지를 씀). 검사는 `python3 zcheck23.py 8`
- 꼴과 글투는 레벨9 때와 같음(인계문서 176번). 레벨8은 지문이 100낱말쯤이라 풀이가 조금 짧음(평균 1,400자쯤)
- 35번: `z35common.py`의 `mk = maker(E, lv='8')` → `mk(n, [적용 네 줄], 헷갈리는 곳, [번호 문장 다섯 개의 설명])`(177번의 도우미에 레벨 인자를 단 것). 검사는 `python3 zcheck35.py 8`(레벨9는 `python3 zcheck35.py 9`) — 따옴표 없는 영어 낱말, 「③의 also」처럼 번호와 함께 든 낱말이 그 번호 문장에 있는지도 봄
- 36-37번: `z3common.py`의 `maker(E, lv='8')`(레벨 인자를 달았음 — 안 주면 레벨9). 검사는 `python3 zcheck3637.py 8` — 「(A)의 them」「주어진 글의 signs」처럼 글을 지목한 영어가 그 글에 있는지, 적용 2)~4) 줄의 인용이 그 줄의 글에 있는지도 봄
- 36-37번 레벨8 본보기는 셋으로 나뉘어 있음: `examples/edits_Y3a·b·c_3637L8.py`(b가 a의 2·7번째를 다시 쓰므로 하나로 합치지 않음 — 차례대로 `edits_Y3a,edits_Y3b,edits_Y3c`). 지문과 해석을 함께 고칠 때는 `fix(n, (옛, 새) 또는 [(옛, 새), …], (옛 해석, 새 해석) 또는 [ … ])` — `'text'`와 `'ko'` 둘 다 여러 군데를 받음
- 38-39번: `z5common.py`의 `mk = maker(E, lv='8')` → `mk(n, 답 자리(1~5), [적용 네 줄], 헷갈리는 곳, [자리별 설명 5개])`, `seg(지문)`은 삽입 문장과 조각 여섯을 돌려줌. 검사는 `python3 zcheck3839.py 8`(레벨9는 9). **레벨9 때(180번) 만든 `z5common.py`·`seg.py`·`zcheck3839.py`는 도구 묶음에서 빠져 있어 220번에 다시 만들었음**(레벨9의 30문항에 돌려 통과 확인). 42번용 도우미도 같은 까닭으로 없을 수 있으니, 42번을 시작할 때 앱에 들어 있는 레벨9 해설의 꼴을 보고 다시 만들 것
- 42번: `z7common.py`의 `mk = maker(E, lv='8')` → `mk(n, 답 기호('a'~'e'), [뜻풀이 5개], [바꾸어 넣을 낱말], [적용 네 줄], 헷갈리는 곳, [낱말별 설명 5개])`. 낱말별 해설의 머리(기호·낱말·뜻풀이·「문맥에 맞습니다.」/「정답입니다.」)는 자동. 검사는 `python3 zcheck42.py 8 edits_Y5a,edits_Y5b`(뒤의 수정안 이름은 바꾸어 넣을 낱말을 읽어 오려는 것 — 안 주면 그 낱말들이 「지문에 없는 영어」로 뜸). 큰따옴표로 옮길 때 밑줄 기호 (a)~(e)는 빼고 옮길 것. **레벨9 때의 `z7common.py`·`zcheck42.py`도 도구 묶음에서 빠져 있어 223번에 다시 만들었음**
- 31~34번 레벨8: `mk = maker(E, '31', lv='8')`. 오답 선택지를 바꾸는 문항은 `mk(..., ch={자리: '새 선택지'})`(해설 머리와 문항에 함께 반영). 검사는 `python3 zcheck31.py 31 8`(유형, 레벨) — 레벨8에서 오답을 바꾼 문항은 `ITEM_FIX8`에 적음. `show.py`(지문·선택지·옛 해석 한꺼번에 읽기: `python3 show.py 33 8 10 20`), `fin.sh`(만들기+자체 검사+종합 점검: `bash fin.sh "edits_Y8a,edits_Y8b" 33 8`)
- 40·41번 레벨8: `from z40common import maker; mk = maker(E, lv='8')`, `from z41common import maker; mk = maker(E, lv='8')`. 오답을 바꾸면 `mk(..., ch={자리: '새 선택지'})`, 정답 낱말까지 고치면 `ans_ok=True`를 함께(인계문서에 까닭을 적은 문항만). 검사는 `python3 zcheck40.py 40 8`, `python3 zcheck41.py 41 8`. `show41.py`(41번 읽기: `python3 show41.py 8 0 10`), `fin40.sh`(`bash fin40.sh "edits_Y10,edits_Y11" zcheck41.py 41 8`). **선택지를 고친 뒤에는 verify.py의 길이 점검표(144/144칸)를 꼭 볼 것** — 정답이 가장 긴 선택지가 되면 그 칸이 A에 걸림
- **pending/ 폴더**(256번~): 아직 GitHub에 올라가지 않았을 수 있는 수정안을 낱개로 넣어 둠(레벨7: `edits_W5b`~`edits_W11c` 스무 개). GitHub의 index.html이 인계문서 마지막 항목의 크기와 다르면, 이 폴더의 파일을 작업 폴더로 복사해 `python3 build.py <목록> out/index.html`로 다시 만들 수 있음. examples/의 유형별 합본(`edits_W1_…`~`edits_W11_…`)은 보관용 — **이미 얹힌 바탕에 `ch=`가 든 합본을 다시 얹으면 apply가 막으니**, 다시 만들 때는 pending/의 낱개를 쓸 것
- 레벨7 읽기 도구: `show3637.py`·`show3839.py`·`show40.py`·`show42.py`·`show23.py`·`show35.py`(모두 `python3 <도구> 7 0 10` 꼴), 31~34번은 `show.py 31 7 0 10`, 41번은 `show41.py 7 0 10`. 한 묶음 끝내기 `fin7.sh`·`fin42.sh`
- **X 계열 수정안(257번~)**: 레벨6 아래를 「검토해서 탈이 있는 문항만 고치는」 일. 30문항을 다 읽고(`show3839.py`·`show3637.py`·`showb.py <유형> <레벨> 0 30`) 답이 둘로 읽히는 문항만 `mk(...)`로 고침 — 고친 문항은 해설도 두터운 꼴로 새로 씀. 검사는 유형별 zcheck에 레벨 인자(`python3 zcheck3839.py 6`, `python3 zcheck31.py 33 6`)를 주고, 고친 문항을 그 도구의 예외 목록(ITEM_FIX…)에 ('6', 몇째-1)로 적을 것

## 레벨 기준으로 재기 (314번~)

| 파일 | 하는 일 |
|---|---|
| `levelgauge2.py` | 문장을 구문 분석해 짜임(이은 문장·종속절·명사절·관계사절·분사구문)과 낱말 수준을 잼. `python3 levelgauge2.py 31 1`(한 칸, 문장마다 짜임이 붙어 나옴) / `python3 levelgauge2.py`(전체, 20분쯤 → `gauge_all.json`·`gauge_items.json`) |
| `wordlists.json` | 낱말 목록: NGSL 2,800(기초) · AWL 570족 + NAWL 963(학술) |
| `verdict314.py` | 칸마다 ○·△·× 판정(선은 인계문서 314번에 적어 둠) |
| `build_page314.py` + `page/template.html` | 측정표 페이지 자료(`page_data.json`)와 페이지(`page/level-gauge.html`)를 만듦. 페이지 주소: https://claude.ai/artifact/9qawWZ94DbUKWsS7Ahpmu4 (다시 재면 이 주소를 갱신) |
| `gauge_all.json` · `gauge_items.json` | 314번에 잰 값(바탕 `6ed6ca6`). 문항을 고치면 그 칸은 다시 잴 것 |
| `finish314.py` | 메모 갱신 → 페이지 만들기 → zip·인계문서를 `/home/claude/outputs/`에 둠 (경로를 모두 절대 경로로 적음) |

설치: `pip install spacy wordfreq cefrpy --break-system-packages` → `pip install --break-system-packages "spacy-curated-transformers>=0.3,<0.4"` → `pip install --break-system-packages https://github.com/explosion/spacy-models/releases/download/en_core_web_trf-3.8.0/en_core_web_trf-3.8.0-py3-none-any.whl`
(setup.sh는 이것을 설치하지 않음 — 잴 때만 설치)

## 레벨 기준에 맞게 다시 쓰기 (315번~)

| 파일 | 하는 일 |
|---|---|
| `zlevel.py` | 새로 쓴 지문을 문장마다 재서 레벨 기준에 어긋난 문장을 보여 줌. `python3 zlevel.py 31 1 0-14 4` |
| `zsolve.py` | 독립 풀이에 줄 문제지(지문 + 선택지 / 선택지만 / 빈칸 문장 + 선택지 / 해설 교정용)를 만들고 정답 줄·정답 길이 순위를 보여 줌(318번 · 320번). `PYTHONPATH=pending python3 zsolve.py edits_X56a 20 2 0-14 <폴더>` |
| `regauge.py` | 한 칸을 다시 재서 `gauge_all.json`·`gauge_items.json`의 그 칸만 바꿔 넣음(319번). `python3 /home/claude/work/regauge.py 20 2` → 틀의 「그 뒤 맞춘 칸」 줄 → `build_page314.py` → 페이지를 **주소(`url`)와 함께** 올림 |
| `pending/edits_X55a.py` | 31번 레벨1 앞 절반 — 빈칸 유형을 통째로 다시 쓰는 `rw()` 꼴의 본보기(z8common의 두터운 해설 + rewrite) |
| `pending/edits_X58a.py` · `edits_X58b.py` | 33번 레벨1 앞 절반(322번)·뒤 절반(323번) — 선택지 다섯을 통째로 넘기는 `rw(n, ans, text, c5, ko, steps, traps, cn)` 꼴(바뀐 자리는 스스로 가려냄). 오답을 모두 다시 쓰는 칸의 본보기 |
| `pending/edits_X59a.py` · `edits_X59b.py` | 34번 레벨1 앞 절반(324번)·뒤 절반(325번) — 「곳이 한 가지를 바꿈 → 그 전의 탈」 갈래를 레벨1로 쓴 본보기(관계사절 which suggests를 풀어 짝꿍 문장으로) |
| `done/edits_X60a.py` · `edits_X60b.py` (330번 파일이 GitHub `38a4f49`에 올라가 331번에 done/으로 옮김 — `edits_X55a`~`X59b`도 함께) | 38-39번(문장 넣기) 레벨1 앞 절반(327번)·뒤 절반(328번) — `rw(n, 답 자리, 주어진 문장, [지문 다섯 문장], 해석(주어진 문장), [해석 다섯 문장], [적용 네 줄], 헷갈리는 곳, [자리별 해설 다섯])` 꼴. `z5common.maker(E, lv='1')`의 두터운 해설 + rewrite · **329번**: 두 파일의 `rw`가 `mk(..., moved=True)`로 답 자리를 수정안이 정함(`'answer': ans-1`). 앞 절반(`edits_X60a`)은 329번에 다시 손봄(답 줄 431342523514521) · 뒤 절반은 아직 328번 그대로 · **330번**: 뒤 절반(`edits_X60b`)도 정답 자리를 옮겨 다시 씀(답 줄 341534225312514). 문항의 자리를 맞바꿀 때는 `rw(n, …)`의 n만 바꾸면 됨(선택지는 문항마다 같음) · 앞 절반은 풀이 1)의 말 열한 곳만 맞춤 |
| `done/edits_X61a.py` (331번 파일이 GitHub `33c7629`에 올라가 332번에 done/으로 옮김 — 지금 `pending/`은 빔) | 38-39번(문장 넣기) 레벨1 앞 절반(331번 — 여섯 가지의 2·3·4번). 바탕 `38a4f49` 위에 얹었던 수정안. 열다섯 문항 모두 rewrite(답 줄 423143552314521). 덩이의 꼴은 `edits_X60a`와 같음 |
| `paper/extract.py` · `paper/make.js` · `paper/scrub.py` · `paper/items.json` | **학생용 시험지와 선생님용 답·채점표 만들기(332번 — 38-39번 한 칸).** `python3 /home/claude/work/paper/extract.py 1` (out/index.html의 38-39번 레벨1 서른 문항 → `items.json`) → `cd /home/claude/work/paper && node make.js <폴더>` (Word 둘) → `python3 /home/claude/work/paper/scrub.py <폴더>` (숨은 정보 비우기 · 문단 테두리 차례를 규격대로). 「답 적는 곳」은 첫 쪽에 둘 것(맨 뒤에 두면 표가 갈라짐). 다른 유형은 선택지가 있어 꼴을 새로 잡아야 함 |
| `z3839draft.py` | 38-39번 원고 도구(327번). ① `PYTHONPATH=pending python3 z3839draft.py match edits_X60a 1 0 15` — 낱말 맞추기 검사(답 자리가 혼자 가장 많이 겹치는 문항 0이 목표) + 재기 (「자리 규칙」 줄: 가리키는 말이 든 첫/둘째/마지막 문장의 앞 자리가 답인 문항 수 — 어느 것도 절반을 넘지 않게) ② `python3 z3839draft.py sheets 1 0 15 <폴더> <꼬리표>` — 독립 검사에 줄 문제지 셋(_full: 답 모르고 풀기 · _skip: 주어진 문장을 뺀 지문 · _explain: 해설 교정) |
| `pending/edits_X62a.py` | **36-37번(글의 순서) 레벨1 앞 절반(333번 — 1~15번째).** `rw(n, 주어진 글, {'A':[문장…],'B':[…],'C':[…]}, 주어진 글 해석, {'A':[해석…],…}, [풀이 네 줄], 헷갈리는 곳, [선택지별 해설 다섯], 낱말 줄)` 꼴. `z3637common.maker(E,'1')`이 정답 번호·선택지·발문은 바탕 그대로 두고 지문·해석·풀이·해설만 통째로 바꿈. 바탕 `e2ceda8` 위에 얹음 |
| `pending/edits_X62b.py` | **36-37번(글의 순서) 레벨1 뒤 절반(334번 — 16~30번째).** 꼴은 `edits_X62a.py`와 같음. `edits_X62a`와 함께 바탕 `e2ceda8` 위에 얹음: `PYTHONPATH=pending python3 build.py edits_X62a,edits_X62b out/index.html`. 만든 법: `draft/d62b.py`(영어) + `draft/ko62b_1.py` · `ko62b_2.py`(한글) → `python3 draft/gen62.py b` |
| `pending/edits_X63a.py` | **21번(함축 의미) 레벨1 앞 절반(335번 — 1~15번째).** `rw(n, 지문(밑줄 <u>…</u>), [선택지 다섯], 해석, [풀이 1)~4)], 헷갈리는 곳, [선택지별 까닭 다섯], [선택지 우리말 다섯], 낱말 줄)` 꼴. `z21common.maker(E,'1')`이 정답 번호는 바탕 그대로 두고 지문 · 선택지 · 해석 · 풀이 · 해설을 통째로 바꿈. 바탕 `e2ceda8` 위에 `edits_X62a,edits_X62b`와 함께 얹음: `PYTHONPATH=pending python3 build.py edits_X62a,edits_X62b,edits_X63a out/index.html`. 만든 법: `draft/d63a.py`(영어: 지문 · 선택지 · 정답 자리) + `draft/ko63a_1.py` · `ko63a_2.py`(한글) → `python3 draft/gen63.py a` |
| `pending/edits_X63b.py` | **21번(함축 의미) 레벨1 뒤 절반(337번 — 16~30번째).** 꼴은 `edits_X63a.py`와 같음. 바탕 `e2ceda8` 위에 `edits_X62a,edits_X62b,edits_X63a,edits_X63b`를 모두 얹음: `PYTHONPATH=pending python3 build.py edits_X62a,edits_X62b,edits_X63a,edits_X63b out/index.html`. 만든 법: `draft/d63b.py`(영어) + `draft/ko63b_1.py` · `ko63b_2.py`(한글) → `python3 draft/gen63.py b`. 길이 순위는 `python3 zrank.py b` |
| `z21common.py` · `zcheck21.py` · `zjosa2.py` · `zjosacmp.py` | 21번 다시 쓰기 도구(335번). `zcheck21.py 1`: 밑줄 하나 · 풀이 1)에 밑줄 친 말 · 4)에 정답 선택지 · 큰따옴표 인용이 지문에 있는지 · 「~니다」 말끝 없음 · 정답 번호 불변 · 정답 선택지의 길이 순위. `zjosa2.py --strict [--fix] 원고.py…` / `zjosa2.py --data 쪽.html`: 괄호 · 「」 뒤 조사(은/는 · 이/가 · 을/를 · 와/과 · (으)로 · (이)라고 · 이에요/예요)가 **괄호 바로 앞 낱말**(영어는 CMU 발음사전, 숫자·A/B/C는 읽는 소리)의 받침과 맞는지 — **어느 유형이든 해설 원고를 쓴 뒤 `--strict --fix`로 돌릴 것**(336번 선생님 결정; `build.py`가 둘 다 어긋난 진짜 오류는 자동으로 고침; `cmudict` 필요 — `pip install cmudict --break-system-packages`). `zjosacmp.py 앞.html 뒤.html 이름`: 두 쪽 사이에 바뀐 해설 글이 조사뿐인지 칸별로 보여 줌. 옛 `zjosa.py`는 **쓰지 말 것**(괄호 안 기준 — 잘못) |
| `z3637common.py` · `z3637draft.py` · `draft/d62a.py` · `draft/ko62a_*.py` · `draft/gen62.py` | 36-37번 다시 쓰기 도구(333번). `z3637draft.py match <원고 모듈>` — 낱말 맞추기 검사(통째 · 맞물림) + `zlevel` 재기. `d62a.py`는 영어 원고 `I[n]=(주어진 글,{A,B,C},정답 순서)`, `ko62a_*.py`는 한글(해석 · 풀이 · 헷갈리는 곳 · 선택지별 해설 · 낱말), `python3 draft/gen62.py a`가 이 둘을 합쳐 `pending/edits_X62a.py`를 만듦(뒤 절반은 `d62b.py` · `ko62b_*.py`를 같은 꼴로 만들고 `gen62.py b`) |
| `pack.py` | 내보내기: zip·index.html·인계문서를 `/home/claude/outputs/`에 둠. `python3 /home/claude/work/pack.py` |

순서: 원고(지문) → `zlevel`로 재기 → 해설 쓰기 → `PYTHONPATH=pending python3 build.py (수정안들) out/index.html` → `zcheck31.py`·`check_all.py` → 독립 풀이 세 가지(답 모르고 풀기 · 선택지만 보고 찍기 · 해설 교정 — `LEVEL_GUIDE.md` 「선택지를 쓰는 법」) → 인계문서 → `pack.py`
명령은 `cd /home/claude/work && …`로 시작하되, 먼저 `pwd`로 자리를 확인할 것

- 36-37번을 레벨 기준으로 다시 쓸 때(333번): 검사는 `python3 zcheck3637.py 1`(다시 쓴 문항은 `ITEM_FIX`에 `('1', n)`이 들어 있음 — 레벨1 서른 문항 모두) · `PYTHONPATH=pending python3 z3637draft.py match edits_X62a`(문장 수 일곱 = 주어진 글 + 세 덩이 × 두 문장) · `python3 regauge.py 36_37 1`. 해설 교정용 문제지는 `PYTHONPATH=pending python3 zsolve.py edits_X62a 36_37 1 0-14 <폴더>`(뒤 절반은 `edits_X62b 36_37 1 15-29`)(explain.txt). 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「36-37번 레벨1의 꼴」

- 38-39번을 레벨 기준으로 다시 쓸 때(327번): 검사는 `python3 zcheck3839.py 1`(다시 쓴 문항은 `ITEM_FIX`에 `('1', n)`을 넣어야 함) · `python3 zlevel.py 38_39 1 0-14 6`(문장 수 6 = 주어진 문장 + 지문 다섯) · 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「38-39번(문장 넣기) 레벨1의 꼴」
- `z20common.py` · `zcheck20.py`(317번): 20번(주장)을 레벨 기준으로 다시 쓸 때의 도우미와 검사. `pending/edits_X56a.py`가 본보기 — 지문·선택지 다섯·해석·주장 문장·까닭·선택지별 까닭을 한 번에 적음
- 21번을 레벨 기준으로 다시 쓸 때(335번): 검사는 `python3 zcheck21.py 1`(다시 쓴 문항은 `ITEM_FIX`에 `('1', n)`) · 문장 재기는 `zlevel.check_texts('21','1',{n:(지문,정답)},5)`. 해설 교정용 문제지는 `PYTHONPATH=pending python3 zsolve.py edits_X63a 21 1 0-14 <폴더>`(explain.txt) · 뒤 절반은 `zsolve.py edits_X63b 21 1 15-29 <폴더>`. 꼴과 배운 것은 `LEVEL_GUIDE.md`의 「21번 레벨1의 꼴」
