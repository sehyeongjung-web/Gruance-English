# -*- coding: utf-8 -*-
# 40번(요약문 완성) 레벨1~3을 레벨 기준으로 다시 쓸 때의 도우미 (338번)
#   from z40rw import maker;  rw = maker(E, '1')
#   rw(n, [지문 네 문장], 요약문(영어, (A) ______ · (B) ______ 하나씩), [선택지 다섯: 'a - b'], 지문 해석(네 문장), 요약문 해석((A) ______ · (B) ______ 포함),
#      [적용 1)~4) 네 줄], 끌리는 오답, [선택지별 까닭 다섯], [선택지 우리말 다섯: '낱말 - 낱말'], 낱말 줄)
#   - 정답 번호는 바탕 그대로(어기면 멈춤) · 발문은 건드리지 않음
#   - 풀이·해설에서 지문(또는 요약문)을 그대로 옮긴 말은 «…»로 쓰면 큰따옴표로 바뀌고, 지문에 없으면 멈춤
#   - 「첫·둘째·셋째·넷째 문장」 바로 뒤에 «…»가 오면 그 문장 안에 있는 말인지도 봄(요약문은 지문 문장에 세지 않음)
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
from z40common import TIP3, HEADS
_s, _tb, _te = load()
T = '40'
ORDW = {'첫': 0, '둘째': 1, '셋째': 2, '넷째': 3, '마지막': -1}
def sents(plain):
    return re.split(r'(?<=[.!?])\s+', plain.strip())
def maker(E, lv='1'):
    def rw(n, P, SM, ch, ko_p, ko_sm, steps, trap, reasons, gl, words=None):
        base = _tb[T][lv][n]; a = base['answer']
        assert len(ch) == 5 == len(set(ch)) == len(reasons) == len(gl), (n, '선택지·해설 개수')
        assert all(re.fullmatch(r'[a-z\' ]+ - [a-z\' ]+', c) for c in ch), (n, '선택지는 「낱말 - 낱말」', ch)
        assert all(' - ' in g for g in gl), (n, '우리말 선택지는 「낱말 - 낱말」')
        assert len(P) == 4 and all(p.endswith('.') for p in P), (n, '지문은 네 문장')
        assert SM.count('(A) ______') == 1 and SM.count('(B) ______') == 1, (n, '요약문의 빈칸')
        assert '(A) ______' in ko_sm and '(B) ______' in ko_sm, (n, '해석 요약문의 빈칸')
        plain = ' '.join(P); full = plain + ' ' + SM
        text = plain + '\n\n' + SM
        assert len(steps) == 4 and all(s.startswith(h) for s, h in zip(steps, HEADS)), (n, '적용 네 줄의 머리말')
        assert any('짝꿍 문장' in s for s in steps), (n, '짝꿍 문장')
        q1, q2 = ch[a].split(' - ')
        assert ("'%s'" % q1 in steps[3]) and ("'%s'" % q2 in steps[3]) and ("'%s'" % ch[a] in steps[3]), (n, '풀이 4)에 정답 낱말·정답 선택지')
        ss = sents(plain)
        def q(tx):
            for m in re.findall(r'«([^»]*)»', tx): assert m in full, (n, '지문에 없는 인용', m)
            for who, m in re.findall(r'(첫|둘째|셋째|넷째|마지막) 문장[^«\n]{0,14}«([^»]*)»', tx):
                assert m in ss[ORDW[who]], (n, '문장 자리가 어긋남', who, m)
            return tx.replace('«', '"').replace('»', '"')
        walk = TIP3 + '\n\n【이 문제에 적용】\n' + '\n'.join(q(x) for x in steps) + '\n\n【끌리는 오답】\n' + q(trap)
        if words: walk += '\n\n📌 낱말: ' + words
        cns = []
        for k in range(5):
            assert '정답' not in reasons[k] and '정답' not in gl[k], (n, k, '까닭에 "정답"이라는 말')
            cns.append(("정답이에요. " if k == a else "") + "'%s' (%s) — %s" % (ch[k], gl[k], q(reasons[k])))
        assert (T, lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, lv, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(ch), 'ko': ko_p + '\n\n[요약문] ' + ko_sm, 'walk': walk, 'cn': cns}}
    return rw
