# 36-37번(글의 순서) 레벨9 두텁게 — 자체 엄격 검사 (verify_explain보다 엄함)
import re,sys; sys.path.insert(0,'.')
from lib import *
s,tb,te=load('out/index.html'); s0,tb0,te0=load()
T='36_37'; done=0; soft=[]; wl=[]; cl=[]
for n in range(30):
    it=tb[T]['9'][n]; ex=te[T]['9'][n]; P=it['text']; a=it['answer']; ch=it['choices']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done+=1
    for tx in [ex['walk']]+ex['cn']:
        assert '«' not in tx and '»' not in tx, (n,'꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"')%2==0, (n,line)
            for q in re.findall(r'"([^"]*)"',line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"'%(n+1,q))
                if len(q)<12: print('!! 짧은 큰따옴표: %d번째 "%s"'%(n+1,q))
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])",tx):
            if re.search(r'[가-힣]',q) or not re.search(r'[A-Za-z]{3,}',q): continue
            if re.fullmatch(r'\([ABC]\)-\([ABC]\)-\([ABC]\)',q): continue
            if q.lower().strip('.,') not in P.lower(): soft.append((n+1,q))
    # 따옴표 없이 쓴 영어 낱말(괄호 앞)도 지문에 있는지: 예) therefore(그러므로)
    for tx in [ex['walk']]+ex['cn']:
        for w in re.findall(r"(?<![A-Za-z'\"])([A-Za-z][A-Za-z ]{2,30}?)\(", tx):
            w=w.strip()
            if w and w.lower() not in P.lower(): soft.append((n+1,'(따옴표 없음) '+w))
    for k,c in enumerate(ch):
        head=("정답입니다. " if k==a else "")+"'"+c+"' — "
        assert ex['cn'][k].startswith(head), (n,k,'머리말')
        assert ex['cn'][k].count('정답')==(1 if k==a else 0), (n,k,'정답이라는 말')
    w=ex['walk']
    assert not re.search(r'[①②③④⑤]|\d번', w), (n,'번호')
    assert w.count('【')==3 and all(('\n%d) '%i) in w for i in (1,2,3,4)), (n,'꼴')
    seqs=re.findall(r'\([A-C]\)-\([A-C]\)-\([A-C]\)', w)
    assert seqs==[ch[a]], (n,'풀이에 나온 순서 문자열',seqs)
    # 정답 해설·오답 해설 본문에 다른 선택지의 순서 문자열이 섞이지 않았는지
    for k in range(5):
        assert re.findall(r'\([A-C]\)-\([A-C]\)-\([A-C]\)', ex['cn'][k])==[ch[k]], (n,k,'해설 속 순서 문자열')
    b0=tb0[T]['9'][n]
    assert it==b0, (n,'문항 변동'); assert ex['ko']==te0[T]['9'][n]['ko'], (n,'해석 변동')
    wl.append(len(w)); cl+= [len(c) for c in ex['cn']]
print('두텁게 쓴 문항:',done,'/ 30')
import statistics as st
w0=[len(e['walk']) for e in te0[T]['9']]; c0=[len(c) for e in te0[T]['9'] for c in e['cn']]
print('풀이 평균 %d자 → %d자 (최소 %d, 최대 %d) / 선택지 해설 평균 %d자 → %d자'%(st.mean(w0),st.mean(wl),min(wl),max(wl),st.mean(c0),st.mean(cl)))
for x in soft: print('  눈으로 볼 것: %d번째 \'%s\''%x)
