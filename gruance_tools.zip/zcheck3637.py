# 36-37번(글의 순서) 두텁게 — 자체 엄격 검사 (verify_explain보다 엄함)   python3 zcheck3637.py [레벨, 기본 9]
# 215번에 보탠 것: 레벨 인자 / 「(A)의 them」「주어진 글의 signs」처럼 글을 지목한 영어가 그 글에 있는지 / 적용 2)~4) 줄의 큰따옴표 인용이 그 줄의 글(또는 주어진 글)에 있는지
#                 / 지문을 고친 문항(ITEM_FIX)은 정답 번호·선택지만 그대로인지 봄 / 손대지 않은 문항 불변
import re,sys; sys.path.insert(0,'.')
from lib import *
from lowstyle import has_nida
LV=sys.argv[1] if len(sys.argv)>1 else '9'
s,tb,te=load('out/index.html'); s0,tb0,te0=load()
ITEM_FIX={('8',n) for n in (1,6,8,10,14,17,18, 20,21,22,23,26,29)} | {('7',n) for n in (0,1,10,18,23)} | {('6',n) for n in (0,3,7,15,16,20,22)} | {('5',n) for n in (6,7,9,11,17,19,21,26)} | {('4',0),('4',1)} | {('3',n) for n in (0,1,3,6,8,9,11,13,15,17,18,21,22,27,28,29)}   # 215번: 9번째 / 218번: 2·7·11·15·18·19번째 / 219번: 21·22·23·24·27·30번째 — 다른 순서로도 읽히던 것을 가리키는 말로 막음   # 234번: 레벨7 1·2번째
KO_ONLY={('5',2),('5',4)}   # 266번: 해석만 고친 문항
T='36_37'; done=0; soft=[]; wl=[]; cl=[]
for n in range(30):
    it=tb[T][LV][n]; ex=te[T][LV][n]; P=it['text']; a=it['answer']; ch=it['choices']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done+=1
    for tx in [ex['walk']]+ex['cn']:
        assert '«' not in tx and '»' not in tx, (n,'꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"')%2==0, (n,line)
            for q in re.findall(r'"([^"]*)"',line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"'%(n+1,q))
                if len(q)<12: print('!! 짧은 큰따옴표: %d번째 "%s"'%(n+1,q))
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])",tx):
            if re.search(r'[가-힣]',q) or not re.search(r'[A-Za-z]{3,}',q): continue
            if re.fullmatch(r'\([ABC]\)-\([ABC]\)-\([ABC]\)',q): continue
            if q.lower().strip('.,') not in P.lower(): soft.append((n+1,q))
    # 따옴표 없이 쓴 영어 낱말(괄호 앞)도 지문에 있는지: 예) therefore(그러므로)
    for tx in [ex['walk']]+ex['cn']:
        for w in re.findall(r"(?<![A-Za-z'\"])([A-Za-z][A-Za-z ]{2,30}?)\(", tx):
            w=w.strip()
            if w and w.lower() not in P.lower(): soft.append((n+1,'(따옴표 없음) '+w))
    for k,c in enumerate(ch):
        head=((("정답이에요. " if LV in "123" else "정답입니다. ")) if k==a else "")+"'"+c+"' — "
        assert ex['cn'][k].startswith(head), (n,k,'머리말')
        assert ex['cn'][k].count('정답')==(1 if k==a else 0), (n,k,'정답이라는 말')
    w=ex['walk']
    if LV in '123': assert not has_nida(w.split('【이 문제에 적용】')[1]) and not any(has_nida(c) for c in ex['cn']), (n,'레벨1~3인데 「~니다」 말끝')
    assert not re.search(r'[①②③④⑤]|\d번', w), (n,'번호')
    assert w.count('【')==3 and all(('\n%d) '%i) in w for i in (1,2,3,4)), (n,'꼴')
    seqs=re.findall(r'\([A-C]\)-\([A-C]\)-\([A-C]\)', w)
    assert seqs==[ch[a]], (n,'풀이에 나온 순서 문자열',seqs)
    # 정답 해설·오답 해설 본문에 다른 선택지의 순서 문자열이 섞이지 않았는지
    for k in range(5):
        assert re.findall(r'\([A-C]\)-\([A-C]\)-\([A-C]\)', ex['cn'][k])==[ch[k]], (n,k,'해설 속 순서 문자열')
    b0=tb0[T][LV][n]
    if (LV,n) in ITEM_FIX: assert it['answer']==b0['answer'] and it['choices']==b0['choices'], (n,'정답·선택지 변동')
    else:
        assert it==b0, (n,'문항 변동'); assert ex['ko']==te0[T][LV][n]['ko'], (n,'해석 변동')
    # 글 넷으로 나누기: 주어진 글 / (A) / (B) / (C)
    m=re.match(r'^(.*?)\n\n\(A\) (.*?)\n\(B\) (.*?)\n\(C\) (.*)$',P,re.S); assert m,(n,'지문 꼴')
    part={'주어진 글':m.group(1),'(A)':m.group(2),'(B)':m.group(3),'(C)':m.group(4)}
    alltx=w.split('【이 문제에 적용】')[-1]+' '+' '.join(ex['cn'])
    for who,wd in re.findall(r"(주어진 글|\([ABC]\))의 '?([A-Za-z][A-Za-z ]*?)'?[\(가-힣,]",alltx):
        if wd.strip().lower() not in part[who].lower(): print('!! %d번째: %s의 %s — 그 글에 없음'%(n+1,who,wd))
    for line in w.split('\n'):
        mm=re.match(r'^[234]\) (?:첫째|둘째|셋째) 글 \(([ABC])\)',line)
        if mm:
            for q in re.findall(r'"([^"]*)"',line):
                if q not in part['('+mm.group(1)+')'] and q not in part['주어진 글']: soft.append((n+1,'(%s 줄의 인용이 다른 글의 것) %s'%(mm.group(1),q[:40])))
    wl.append(len(w)); cl+= [len(c) for c in ex['cn']]
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']:
        if (LV,n) in KO_ONLY:   # 해석만 고친 문항: 지문·풀이·해설은 바탕과 같고 해석만 달라야 함
            e1,e0=te[T][LV][n],te0[T][LV][n]
            assert tb[T][LV][n]==tb0[T][LV][n] and e1['walk']==e0['walk'] and e1['cn']==e0['cn'], (n,'해석만 고친 문항')   # 바탕에 이미 반영된 뒤에는 해석도 바탕과 같음
        else: assert tb[T][LV][n]==tb0[T][LV][n] and te[T][LV][n]==te0[T][LV][n], (n,'안 쓴 문항이 바뀜')
print('두텁게 쓴 문항:',done,'/ 30')
import statistics as st
w0=[len(e['walk']) for e in te0[T][LV]]; c0=[len(c) for e in te0[T][LV] for c in e['cn']]
print('풀이 평균 %d자 → %d자 (최소 %d, 최대 %d) / 선택지 해설 평균 %d자 → %d자'%(st.mean(w0),st.mean(wl),min(wl),max(wl),st.mean(c0),st.mean(cl)))
for x in soft: print('  눈으로 볼 것: %d번째 \'%s\''%x)
