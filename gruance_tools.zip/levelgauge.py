# -*- coding: utf-8 -*-
# 307번: 낱말 수준과 문장 짜임을 「대강」 재는 도구 (LEVEL_GUIDE.md의 기준에 견주어 볼 때 씀. 마지막 판단은 선생님)
# - 낱말: wordfreq의 빈도(Zipf). 숫자가 작을수록 드문 낱말. 레벨1·2는 3.9 아래, 레벨3은 3.5 아래를 「드문 낱말」로 보여 줌
# - 짜임: 종속접속사·관계사·분사구문·절을 잇는 and/but/so를 글자 모양으로 찾음(틀릴 수 있음 — 예: 전치사 after, 지시어 that)
# 쓰는 법: python3 levelgauge.py 35 1      (유형 레벨)  /  from levelgauge import gauge
import re, sys
try:
    from wordfreq import zipf_frequency as _z
except Exception:
    _z = None   # pip install wordfreq --break-system-packages
SUB = {'because','when','if','although','though','while','since','unless','until','whereas','whether','once','as'}
REL = {'which','who','whose','whom','where','that'}
RARE = {'1': 3.9, '2': 3.9, '3': 3.5}
def sentences(text):
    t = re.sub(r'[①②③④⑤]|\([a-eA-E]\)|\(\s*[A-C]\s*\)|_{3,}', ' ', text)
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', t) if len(s.strip().split()) >= 2]
def gauge(text, lv='1'):
    out = {'sent': [], 'rare': [], 'sub': [], 'rel': [], 'ptc': [], 'coord': []}
    for s in sentences(text):
        ws = re.findall(r"[A-Za-z']+", s); low = [w.lower() for w in ws]
        out['sent'].append(len(ws))
        if _z:
            for w in set(low):
                if len(w) > 2 and _z(w, 'en') < RARE.get(lv, 3.5): out['rare'].append(w)
        out['sub'] += [w for w in low if w in SUB]
        out['rel'] += [w for w in low if w in REL]
        if re.search(r"^(?:[A-Z][a-z]+ing|[A-Z][a-z]+ed|Having)\b[^.]*?,", s) or re.search(r",\s+[a-z]+ing\b", s): out['ptc'].append(s[:40])
        out['coord'] += re.findall(r",\s+(and|but|so|or|yet)\s", s)
    return out
if __name__ == '__main__':
    sys.path.insert(0, '.'); from lib import load
    T, LV = sys.argv[1], sys.argv[2]; _, tb, _te = load('out/index.html')
    import statistics as st
    tot = {'sent': [], 'rare': {}, 'sub': 0, 'rel': 0, 'ptc': 0, 'coord': 0}; ns = 0
    for n, it in enumerate(tb[T][LV]):
        g = gauge(it['text'], LV); tot['sent'] += g['sent']; ns += len(g['sent'])
        for w in g['rare']: tot['rare'].setdefault(w, []).append(n + 1)
        for k in ('sub', 'rel', 'ptc', 'coord'): tot[k] += len(g[k])
    print('%s번 레벨%s — 문장 %d개, 문장당 평균 %.1f낱말(가장 짧은 %d, 가장 긴 %d), 10~15낱말인 문장 %d%%' % (T, LV, ns, st.mean(tot['sent']), min(tot['sent']), max(tot['sent']), 100 * sum(1 for x in tot['sent'] if 10 <= x <= 15) / ns))
    print('문장 100개에: 종속접속사 %.0f · 관계사(that 포함) %.0f · 분사구문 %.0f · 절을 잇는 and/but/so %.0f' % tuple(100 * tot[k] / ns for k in ('sub', 'rel', 'ptc', 'coord')))
    print('드문 낱말 %d가지:' % len(tot['rare']), ', '.join('%s(%s)' % (w, ','.join(map(str, v))) for w, v in sorted(tot['rare'].items())))
