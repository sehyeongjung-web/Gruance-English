#!/bin/bash
# 357번: 31·32번 레벨2 길이 고침 + 31번 레벨1 교정 반영 — 세 칸 원고에서 수정안 다시 만들기 → 조사 → 빌드
cd /home/claude/work
for g in 69 70 71; do python3 draft/gen$g.py a && python3 draft/gen$g.py b || exit 1; done
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X69a.py pending/edits_X69b.py pending/edits_X70a.py pending/edits_X70b.py pending/edits_X71a.py pending/edits_X71b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X69a,edits_X69b,edits_X70a,edits_X70b,edits_X71a,edits_X71b out/index.html | tail -3
