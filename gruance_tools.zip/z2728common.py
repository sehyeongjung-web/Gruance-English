# -*- coding: utf-8 -*-
# 372번: 27-28번(안내문 내용 불일치) 레벨1 — 공통 도우미
#   rw(n, L, K, P, ch, why, words)
#   · L = 안내문 줄들(영어, 빈 줄은 ''), K = 줄마다 한글(빈 줄은 '') — 지문은 '\n'.join(L), 해석은 '\n'.join(K)
#   · P = 보기 다섯이 가리키는 곳: [(줄 번호, 영어 조각, 한글 조각)] — 영어 조각은 그 줄에 글자 그대로 있어야 함, 줄 번호는 커지는 차례
#   · ch = 우리말 보기 다섯(「~다」로 끝), 정답(바탕 자리) 하나만 안내문의 한 가지를 비틂
#   · why = 정답 풀이(해요체, 인용한 영어는 정답 줄에 있어야 함)
# 해설 꼴은 27-28번 레벨1이 써 오던 꼴 그대로: ① 안내문 요령 → ② 정답 보기와 관련된 부분 인용 → ③ 나머지는 맞음 → 📌 낱말
import sys, re; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
def maker(E, T='27_28', LV='1'):
    def rw(n, L, K, P, ch, why, words):
        it = _tb[T][LV][n]; ans = it['answer']
        assert len(L) == len(K) and all((a == '') == (b == '') for a, b in zip(L, K)), (n, '줄 수 · 빈 줄이 영어와 한글이 같아야 함')
        assert len(P) == 5 == len(ch) == len(set(ch)), n
        idx = [p[0] for p in P]; assert idx == sorted(idx), (n, '보기는 안내문 차례대로')
        for i, en, ko in P: assert en in L[i], (n, '조각이 그 줄에 없음', en, L[i])
        assert all(c.endswith('다') for c in ch), (n, '보기는 「~다」로 끝')
        assert '정답' not in why and why.rstrip().endswith('요.'), (n, '풀이')
        sa = L[P[ans][0]]
        for q in re.findall(r"'([A-Za-z0-9][^']*)'", why): assert q in sa, (n, '풀이의 영어가 정답 줄에 없음', q)
        assert "'" not in ''.join(L), (n, '안내문에 아포스트로피')
        walk = ("① 안내문 문제는 선택지를 안내문의 한 부분 한 부분과 맞춰 봐요. 이 문제는 안내문과 맞지 않는 것을 찾아야 해요.\n"
                "② 선택지 '%s'와 관련된 부분을 보세요.\n\"%s\" (%s)\n→ %s\n"
                "③ 나머지 네 선택지는 모두 안내문과 맞아요. 그러니까 정답은 이 선택지예요 → '%s'\n📌 낱말: %s") % (ch[ans], P[ans][1], P[ans][2], why, ch[ans], words)
        cn = [("정답이에요! '%s' — 안내문과 맞지 않아요. %s" % (ch[k], why)) if k == ans else ("'%s' — 안내문과 맞아요. \"%s\" (%s)" % (ch[k], P[k][1], P[k][2])) for k in range(5)]
        assert (T, LV, n) not in E
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': '\n'.join(L), 'choices': list(ch), 'ko': '\n'.join(K), 'walk': walk, 'cn': cn}}
    return rw
