#!/bin/bash
# 354번: 31번 레벨1(단문 · 정답 낱말이 글에 그대로 나오는 꼴) — 원고에서 수정안 만들기 → 조사 → 빌드
cd /home/claude/work
python3 draft/gen71.py a && python3 draft/gen71.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X71a.py pending/edits_X71b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X69a,edits_X69b,edits_X70a,edits_X70b,edits_X71a,edits_X71b out/index.html | tail -3
