# -*- coding: utf-8 -*-
"""한 칸을 다시 재서 gauge_all.json · gauge_items.json의 그 칸만 바꿔 넣는다 (319번).
  python3 /home/claude/work/regauge.py 20 2      (out/index.html의 20번 레벨2를 다시 잼)
그런 다음: page/template.html의 「그 뒤 맞춘 칸」 줄에 보탬 → python3 /home/claude/work/build_page314.py → page/level-gauge.html을 같은 주소로 다시 올림"""
import sys, os, json
HERE = '/home/claude/work'; sys.path.insert(0, HERE)
import levelgauge2 as g
from lib import load
T, LV = sys.argv[1], sys.argv[2]
_, tb, _ = load(os.path.join(HERE, 'out/index.html'))
items = [g.gauge_item(T, it) for it in tb[T][LV]]
A = json.load(open(os.path.join(HERE, 'gauge_all.json'), encoding='utf-8')); B = json.load(open(os.path.join(HERE, 'gauge_items.json'), encoding='utf-8'))
old = A[T][LV]; new = g.summarize(items); A[T][LV] = new; B[T][LV] = items
json.dump(A, open(os.path.join(HERE, 'gauge_all.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(B, open(os.path.join(HERE, 'gauge_items.json'), 'w', encoding='utf-8'), ensure_ascii=False)
for k in ('sent_per_item', 'words_per_item', 'wps', 'p10_15', 'simple', 'coord', 'it_coord', 'it_sub', 'it_rel_any', 'it_ptc', 'out_basic'):
    print('%-14s %s → %s' % (k, old.get(k), new.get(k)))
try:
    import verdict314 as v
    print('판정:', v.judge(T, LV))
except Exception as e:
    print('(판정은 build_page314.py에서 봄)', e)
