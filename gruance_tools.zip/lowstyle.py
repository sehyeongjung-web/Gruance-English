# -*- coding: utf-8 -*-
# 레벨1~3 해설의 말끝 확인: 「~ㅂ니다」(입니다·습니다·합니다·됩니다 …)가 섞였는지 봄.
# 「아니다」처럼 받침 ㅂ이 없는 「니다」는 해석문의 평서형이므로 걸지 않음 (300번에서 고침)
import re
def has_nida(text):
    for m in re.finditer('니다', text):
        if m.start() == 0: continue
        c = ord(text[m.start() - 1])
        if 0xAC00 <= c <= 0xD7A3 and (c - 0xAC00) % 28 == 17: return True   # 앞 글자의 받침이 ㅂ
    return False
