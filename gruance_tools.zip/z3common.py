# -*- coding: utf-8 -*-
# 178번: 36-37번(글의 순서) 레벨9 해설 두텁게 — 공통 도우미
import re, sys; sys.path.insert(0, '.')
from lib import load as _load
_tb = _load()[1]
ORD = {'ACB': 0, 'BAC': 1, 'BCA': 2, 'CAB': 3, 'CBA': 4}
TIP = ("【글의 순서 요령】\n"
       "첫째, 주어진 글을 읽고 「다음에 무슨 말이 와야 하는가」를 먼저 짐작합니다.\n"
       "둘째, (A)·(B)·(C)의 첫머리를 봅니다. 가리키는 말(this, that, such, these)과 이어 주는 말(however, therefore, then)은 바로 앞에 무엇이 있어야 하는지를 알려 줍니다.\n"
       "셋째, 가리키는 말마다 「무엇을 가리키는가」를 찾아 짝을 짓습니다. 가리킬 것이 든 글이 바로 앞에 옵니다.\n"
       "넷째, 정한 순서대로 이어 읽으며, 앞 글의 끝과 뒤 글의 처음이 맞물리는지 확인합니다.")
# 292번: 레벨1~3은 해설의 말끝이 「~어요」(README) — 요령·머리말·맺음을 그 말끝으로
TIP3 = ("【글의 순서 요령】\n"
        "첫째, 주어진 글을 읽고 「다음에 무슨 말이 와야 하는가」를 먼저 짐작해요.\n"
        "둘째, (A)·(B)·(C)의 첫머리를 봐요. 가리키는 말(this, that, such, these)과 이어 주는 말(however, therefore, then)은 바로 앞에 무엇이 있어야 하는지를 알려 줘요.\n"
        "셋째, 가리키는 말마다 「무엇을 가리키는가」를 찾아 짝을 지어요. 가리킬 것이 든 글이 바로 앞에 와요.\n"
        "넷째, 정한 순서대로 이어 읽으며, 앞 글의 끝과 뒤 글의 처음이 맞물리는지 확인해요.")
def low(lv): return lv in ('1', '2', '3')
def _q(x): return x.replace('«', '"').replace('»', '"')
def maker(E, lv='9'):   # 215번: 레벨 인자(레벨8 해설 두텁게) — 안 주면 레벨9
    def mk(n, ans, steps, confuse, cn):
        # ans: 정답 순서('CAB' 꼴) — 문항의 정답과 다르면 멈춤
        # steps: 적용 네 줄(주어진 글 / 첫째 글 / 둘째 글 / 셋째 글과 확인), confuse: 헷갈리는 곳
        # cn: {'ACB':…, 'BAC':…, 'BCA':…, 'CAB':…, 'CBA':…} — 선택지 인용과 "정답입니다."는 자동
        it = _tb['36_37'][lv][n]; a = it['answer']; ch = it['choices']
        assert ORD[ans] == a, (n, '정답 순서가 문항과 다름')
        assert len(steps) == 4 and set(cn) == set(ORD), n
        assert steps[0].startswith('1) 주어진 글: '), n
        assert steps[1].startswith('2) 첫째 글 (%s): ' % ans[0]), (n, '첫째 글')
        assert steps[2].startswith('3) 둘째 글 (%s): ' % ans[1]), (n, '둘째 글')
        assert steps[3].startswith('4) 셋째 글 (%s)와 확인: ' % ans[2]), (n, '셋째 글')
        assert steps[3].endswith(('순서는 %s예요.' if low(lv) else '순서는 %s입니다.') % ch[a]), (n, '맺는 순서')
        out = {}
        for key, body in cn.items():
            k = ORD[key]; assert ch[k] == '(%s)-(%s)-(%s)' % tuple(key), (n, key)
            assert '정답' not in body, (n, key, '해설 본문에 정답이라는 말')
            out[k] = (("정답이에요. " if low(lv) else "정답입니다. ") if k == a else "") + "'" + ch[k] + "' — " + _q(body)
        walk = (TIP3 if low(lv) else TIP) + "\n\n【이 문제에 적용】\n" + "\n".join(_q(x) for x in steps) + "\n\n【헷갈리는 곳】\n" + _q(confuse)
        assert ('36_37', lv, n) not in E, (n, '같은 문항을 두 번 씀')
        E[('36_37', lv, n)] = {'walk': walk, 'cn': out}
    return mk
