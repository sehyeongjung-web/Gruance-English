# -*- coding: utf-8 -*-
# 357번 문서 갱신(일회용): LEVEL_GUIDE · README · DEFERRED · 인계문서 · 측정표 페이지 템플릿
import re, os
def rd(p): return open(p, encoding='utf-8').read()
def wr(p, s): open(p, 'w', encoding='utf-8').write(s)
def rep(s, old, new, cnt=1):
    assert s.count(old) == cnt, (old[:70], s.count(old))
    return s.replace(old, new)
W = '/home/claude/work/'
SIZE = '{:,}'.format(os.path.getsize(W + 'out/index.html'))
ANS = "after her dinner · in the music room · with her best friend · to get warm rice cakes · drawing funny pictures · watch one TV show · on Thursday nights · on the flat roof · on the slow train · to study English words · sitting on his chest · the big black bag · on Tuesday evenings · in the blue bowl · on her older brother's bike · to feed the birds · cracking the eggs · take the pictures · after dinner · on the front steps · with his older sister · to open the windows · playing word games · dry the front windows · at seven in the evening · in the living room · in her aunt's small car · a pair of warm socks · a bag of milk bread · a bowl of fresh fruit"

# ================= LEVEL_GUIDE.md =================
g = rd(W + 'LEVEL_GUIDE.md')
g = rep(g, '32번 레벨1은 356번에서 다시 써서 **5 · 6 · 7/30(확신 0 · 1 · 4 — 맞힌 것 중 확신한 것 0)**(이 표에 있던 30은 모두 옛 판의 값)',
        '32번 레벨1은 356번에서 다시 써서 **5 · 6 · 7/30(확신 0 · 1 · 4 — 맞힌 것 중 확신한 것 0)**, 33번 레벨1은 357번에서 다시 써서 **10 · 11 · 10 · 15/30(확신 0)**(이 표에 있던 26~30은 모두 옛 판의 값)')
g = rep(g, '→ 32번 레벨1(**356번에 마침**) → 33 · 34 · 40번 레벨1(감사표에서',
        '→ 32번 레벨1(**356번에 마침**) → 33번 레벨1(**357번에 마침**) → 34 · 40번 레벨1(감사표에서')
a = g.index('## 33번(빈칸 — 구) 레벨1의 꼴 (322·323번'); b = g.index('## 34번')
new33 = '''## 33번(빈칸 — 구) 레벨1의 꼴 (357번 — 서른 문항 다시 씀)
※ 322 · 323번의 첫 판(꾸민 버릇 이야기: 버릇 → 좋은 결과)은 감사표에서 마지막 문장만 보면 26/30(확신 10)이라 357번에 이 꼴로 다시 씀(통과선 20/30 이하 · 확신 6 이하는 위 「정답 문장만으로 풀리면 고친다」).
- 틀: 31 · 32번 레벨1과 같음 — **네 문장 · 평균 48.8낱말 · 문장당 평균 12.2낱말(10~15) · 단문 100%**(`zlevel.RULE['1']`, `draft/chk73.py` 걸린 것 0, `regauge.py 33 1` 판정 맞음). 정답 **구**는 첫째~셋째 문장(대개 둘째 · 셋째)에 글자 그대로 나오고(-s/-ed/-ing만 달라도 됨) 넷째에는 없음. 넷째는 「So …」로 그 정보를 묻는 빈칸 하나
- **글감은 한 사람의 되풀이되는 일과 · 버릇**(현재 시제): 토끼 상자 청소 · 드럼 연습 · 배드민턴 · 시장 가기 · 편지 부치기 · 강아지 같은 장면 등. **빈칸 종류를 섞음**: 때 전치사구 · 곳 전치사구 · 함께하는 사람(수단) 전치사구 · to부정사(목적) · -ing구 · 동사구 · 명사구. 글에는 **다른 날 · 다른 사람의 같은 종류 구**가 하나 더 있음(끌리는 오답: 토요일의 때 · 동생이 하는 일 · 겨울의 장소)
- 오답: 글에 나오는 다른 날 · 다른 사람의 구 하나 + 글에 아예 없는 구(「글이 말하는 것은 …」으로 가려짐). 풀이는 서수 + «인용»으로만, 상식으로 물리치지 않음
- **열린 빈칸 틀의 함정(이번에 배운 것)**: 「can」 · 「lets her」 · 「helps by」 · 「habit helps him」 같은 열린 틀은 글에 없는 보기도 둘째 답으로 통과함(감사꾼이 첫판에 6건 · 둘째 판에 2건 잡음). **닫는 법**: 지문 쪽에 only를 넣고(「Hojin helps his dad only by cracking the eggs」 · 「Hyeri only takes the pictures」 · 「she cleans the box only after her dinner」) 빈칸 문장에도 only · always · 「only job」 · 「own job」(「…kicks only ______」 · 「…her parents only let her ______」). **빈칸 문장에 only가 있으면 지문에도 근거가 있어야 함** — 지문이 always만 말하면 「only」는 글을 한 걸음 넘음(번역자가 16 · 17번째에서 알림 → 지문 쪽에 only를 넣음). 보기 다섯은 서로 겹치지 않게(「late at night」 ↔ 「after dinner」 같은 쌍 금지)
- 정답 구 서른: ''' + ANS + '''
- 정답 번호는 바탕 그대로(변동 0건). `zcheck31.py`의 `ANS_FIX[('1','33',n)]` 서른 개가 위 구. 영어 `draft/d73.py`(초안 `d73_1~3.py`, 규칙 `draft/brief_d73.txt`, 모양 `d73_probe.py`, 검사 `chk73.py`), 한글 `draft/k73_1~6.py`(규칙 `draft/brief_k73.txt`), `./fin74.sh` → `pending/edits_X73a|b.py`
- **보기 길이는 영어 초안에서 같이 맞춤**(`draft/lenpart.py 33 1 draft/d73.py`): 정답이 가장 긴 3 · 첫째 · 둘째로 긴 12 · B 0 · C 0 · E 0. `check_all` ④ 143/144 유지
- **한글 틀과 해설**(이번에 배운 것)
  - 빈칸 틀 뒤에 조사를 남기지 말고 CN의 뜻 쪽에 조사 · 어미를 포함(to부정사 「~하려고」 · -ing 「~하면서」 · 명사구 「…한 켤레」). 보기 뜻 다섯을 하나씩 틀에 넣어 읽어 문법을 확인(PP · to · -ing · 동사구 · 명사구가 문항마다 다름)
  - 「그의 · 자기」가 한 문장에서 같은 사람을 섞어 부르면 어색함: 틀에 「자기 드럼」이 있으면 보기 뜻은 「삼촌네 차고에서 · 자기 작은 침실에서」. 주어가 사람이 아닌 문장(고양이가 준을 깨움)에서는 「그의 가슴」이 주어 것으로 읽히므로 「준의 가슴 위에 앉아서 그를 깨운다」로 풀고, 보기 뜻에서는 소유어를 뺌
  - 영어에 older가 없는 brother를 「오빠」로 못 정함 → 영어에 older를 넣음(14번째 「her older brother's bike」). 「older cousin」은 「나이 많은 사촌」이 늙은 사촌으로 읽힘 → 「자기보다 나이 많은 사촌」
  - **괄호 뜻에 영어에 없는 때 · 사람을 섞지 않음**: 「'a bag of milk bread'(우유빵 한 봉지, 현우가 매주 토요일 아침)」 ✗ → 「셋째 문장에서 현우가 매주 토요일 아침 사는 «a bag of milk bread»(우유빵 한 봉지)」. 인용 뒤 괄호는 그 영어의 뜻만, 'only takes'(사진만 찍는다)도 pictures가 영어에 없으니 'only takes the pictures'로
  - 「글에 나온 것은 이것들뿐」식 차단은 영어 인용을 빠뜨리기 쉬움 → 보기 해설도 서수 + «인용» + 정답 구의 날 · 사람을 맺어야 함(교정꾼이 26~30번째에서 6곳)
  - 「5번 버스」처럼 숫자 + 「번」이 풀이에 들어가면 `zcheck31.py`가 문항 번호로 잡음 → 보기를 「on the city bus」로 바꿈(보기 길이 22 → 15, 순위 영향 없음)
  - 설명 한 곳을 늘리면 풀이 + 끌리는 오답이 900자를 넘기 쉬움(여섯 문항이 줄여야 했음): 풀이 1)은 빈칸 문장을 「…」 한 번 보이고 2) 짝꿍에서 같은 말을 되풀이하지 않기
- 독립 풀이: 마지막 문장만 푸는 풀이꾼 **10 · 11 · 10/30(확신 0, 영어 최종 판) → 한글 단계에서 영어 네 곳을 고친 뒤 15/30(확신 0)** · 지문 전체 풀이꾼 **30/30**(전부 high) · 감사꾼 첫판 6건 → 둘째 판 2건 → 셋째 판 문제 없음 → 최종 판도 문제 없음(`sheets74a|b|c/` · `sheets76/`). 교정꾼 넷(번역 둘 · 논리 둘): 번역 6건 + 논리 32건을 모두 반영, 고친 것 확인 한 판에서 6건을 더 고침
- **남은 한계(숨기지 않고)**: ① 마지막 문장만 주어도 10~15문항은 맞음(통과선 20 이내) ② 목적(to + 동사) 문항 셋(10 · 16 · 22번째)은 감사꾼이 이론상 글에 없는 목적도 가능하다고 지적했으나 글의 문장으로는 방어되지 않아 둠 ③ 학생이 실제로 푼 결과는 없음(풀이꾼 · 감사꾼 · 교정꾼은 같은 종류의 모델) ④ 옛 판에서 이어받는 것: 해설의 우리말에서 「산다(사다/살다)」 · 「자기 전」 · 「하나의」처럼 두 가지로 읽히는 말을 피할 것

'''
g = g[:a] + new33 + g[b:]
wr(W + 'LEVEL_GUIDE.md', g)

# ================= README.md =================
r = rd(W + 'README.md')
r = rep(r, "| `pending/edits_X72b.py` | **32번 레벨1 뒤 절반(356번 — 16~30번째).** 만든 법: `python3 draft/gen72.py b`. 한꺼번에: `./fin73.sh`(gen72 a/b → zjosa2 → 빌드 `edits_X72a,edits_X72b` — 바탕 52750ec에는 X69~X71이 이미 들어 있음) |",
 "| `pending/edits_X72b.py` | **32번 레벨1 뒤 절반(356번 — 16~30번째).** 만든 법: `python3 draft/gen72.py b`. 한꺼번에: `./fin73.sh`(gen72 a/b → zjosa2 → 빌드 `edits_X72a,edits_X72b` — 바탕 52750ec에는 X69~X71이 이미 들어 있음) |\n"
 "| `pending/edits_X73a.py` | **33번(빈칸 — 구) 레벨1 앞 절반(357번 — 1~15번째), 한 사람의 일과 · 버릇 이야기 · 단문 100% · 정답 구가 글에 그대로 나오는 새 꼴(지문과 빈칸 문장에 only 등으로 닫음).** 영어 `draft/d73.py`(서른 문항 한 파일), 한글 `draft/k73_1.py`~`k73_6.py`(다섯 문항씩) → `python3 draft/gen73.py a` |\n"
 "| `pending/edits_X73b.py` | **33번 레벨1 뒤 절반(357번 — 16~30번째).** 만든 법: `python3 draft/gen73.py b`. 한꺼번에: `./fin74.sh`(gen73 a/b → zjosa2 → 빌드 `edits_X73a,edits_X73b` — 바탕 510e17c에는 X69~X72가 이미 들어 있음) |")
i = r.index('- 32번 레벨1(356번): 영어'); j = r.index('\n', i)
r = r[:j+1] + ("- 33번 레벨1(357번): 영어 `python3 draft/chk73.py draft/d73.py`(chk72와 같음, 유형 33) · 초안 길이 `python3 draft/lenpart.py 33 1 draft/d73.py` · 한글 `python3 draft/zk69.py draft/k73_N.py draft/d73.py` · 한 번에 `./fin74.sh` → `python3 zcheck31.py 33 1`(`ANS_FIX[('1','33',n)]` 서른 개 — 옛 322 · 323번의 네 항목을 뒤의 `update`가 덮어씀) · `check_all.py`(④ 143) · `lenfix.py 33 1` · `regauge.py 33 1`. 풀이꾼: `python3 solve72.py sheets76 33 1 d73`(세 번째 인자는 .py 없이) → `score72.py sheets76 33 1`. 교정용 문제지 `python3 mkproof.py 33 1 <출력>`\n") + r[j+1:]
wr(W + 'README.md', r)

# ================= DEFERRED.md =================
d = rd(W + 'DEFERRED.md')
d = rep(d, '→ 33 · 34 · 40번 레벨1을 다시 씀(통과선 20/30 이하 · 확신 6 이하) → 레벨2 줄을 33번부터',
        '→ ~~33번 레벨1~~(**357번에 마침** — 마지막 문장만 푸는 풀이꾼 10 · 11 · 10 · 15/30, 확신 0, 지문 전체 30/30, 감사꾼 마지막 판 문제 없음, 교정꾼 번역 6건 + 논리 32건 + 확인 6건 반영, `pending/edits_X73a|b.py`, 빌드는 바탕 510e17c 위에 `edits_X73a,edits_X73b`) → 34 · 40번 레벨1을 다시 씀(통과선 20/30 이하 · 확신 6 이하) → 레벨2 줄을 33번부터')
d = rep(d, '33번 레벨1에서 정답 구를 고친 넷(12·20·23·28번째 — 정답 구 안의 절)을 그대로 둘지',
        '33번 레벨1에서 정답 구를 고친 넷(12·20·23·28번째 — 정답 구 안의 절)을 그대로 둘지(357번에 33번 레벨1을 처음부터 다시 써서 이 넷은 사라짐)')
wr(W + 'DEFERRED.md', d)

# ================= 인계문서 =================
h = rd(W + 'out/그루앙스_작업인계문서.md')
e357 = '''

## 357. 33번(빈칸 — 구) 레벨1을 새 꼴로 다시 씀 (2026-10-12, 같은 방)

선생님 「진행」(06:08) → 순서대로 **33번 레벨1.** 322 · 323번의 첫 판(꾸민 버릇 이야기)은 감사표에서 마지막 문장만 보면 26/30(확신 10)이라 서른 문항을 새로 씀. 수정안 `pending/edits_X73a.py`(1~15번째) · `pending/edits_X73b.py`(16~30번째).

### 꼴 (LEVEL_GUIDE.md 「33번(빈칸 — 구) 레벨1의 꼴」)
- 31 · 32번 레벨1과 같은 틀(네 문장 · 평균 48.8낱말 · 문장당 평균 12.2 · 단문 100% · 정답 **구**가 첫째~셋째 문장에 글자 그대로, 넷째에는 없음)에 **글감은 한 사람의 되풀이되는 일과 · 버릇**. 빈칸 종류를 섞음(때 · 곳 · 함께하는 사람 · to부정사 · -ing · 동사구 · 명사구). 오답은 글에 나오는 다른 날 · 다른 사람의 구 하나 + 글에 없는 구
- 정답 번호는 바탕 그대로(변동 0건). 정답 구 서른: ''' + ANS + '''

### 무엇을 했나
- **영어**: 지침 `draft/brief_d73.txt` → 세 opus 초안(`draft/d73_1~3.py`) → 합본 `draft/d73.py`. 독립 풀이 세 판(`sheets74a|b|c/`): 첫판 감사꾼이 **열린 빈칸 틀 6건**(can · lets her · helps by · habit helps him 등 — 글에 없는 보기도 통과)을 잡음 → 지문 · 빈칸 문장에 only · always · 「only job」으로 닫음 → 둘째 판 2건 → 셋째 판 문제 없음. 최종: 마지막 문장만 **10 · 11 · 10/30(확신 0)** · 지문 전체 **30/30**
- **한글**: 여섯 opus가 다섯 문항씩(`draft/k73_1~6.py`, 규칙 `draft/brief_k73.txt`), `draft/zk69.py` 걸린 것 0. 쓰는 중 보고로 **영어 세 곳을 고침**: 14번째 「her brother's old bike」 → 「her older brother's bike」(오빠인지 동생인지 글에 없음) · 16번째 「always helps his dad by」 → 「helps his dad only by」 · 17번째 「always takes」 → 「only takes」(빈칸 문장의 only를 지문이 받치지 못함)
- **교정꾼 넷**(번역 둘 · 논리 둘, 30문항을 15씩): 번역 6건(2번째 「그의 / 자기」 섞임 · 3번째 「나이 많은 사촌」 · 11번째 「그의」가 고양이를 가리키는 듯 읽힘 두 곳 · 18번째 괄호에 영어에 없는 「사진」 두 곳) + 논리 32건(6 · 11 · 12번째 「오직」을 only가 없는 둘째 문장에서 끌어냄 · 15번째 오답을 상식 · 셋째 문장만으로 막음 · 16번째 서수 · 17 · 18번째 「하나뿐」의 근거 · 23 · 26~30번째 「글에 나온 것은 이것들뿐」식 차단) → 모두 반영(풀이 길이가 900자를 넘는 여섯 문항은 줄임). **고친 것 확인 한 판**에서 6건이 더 나와 고침(6번째 「자기」 둘 · 26 · 27 · 29 · 30번째 괄호 안의 때 · 사람)
- 마지막으로 `zcheck31.py`가 「5번 버스」의 「5번」을 문항 번호로 잡아 보기를 「on the city bus」로 바꿈(27번째)
- 마지막 판 독립 풀이(`sheets76/`): 마지막 문장만 **15/30(확신 0)** · 지문 전체 **30/30** · 감사꾼 문제 없음

### 점검
- `draft/chk73.py` 걸린 것 0 · `draft/lenpart.py 33 1` 정답이 가장 긴 3 · 첫째 · 둘째로 긴 12 · B 0 · C 0 · E 0 · `zcheck31.py 33 1` 두텁게 쓴 문항 30/30(문장 자리 어긋남 0건) · `regauge.py 33 1` 판정 맞음 · `zjosa2.py --strict --fix` 둘 다 어긋난 곳 0 · `check_all.py` 통과(② 정답 번호 변동 0건 · ④ **143/144**)

### 아직 하지 않은 것 (숨기지 않고 적어 둠)
- 학생이 실제로 푼 결과는 없음(풀이꾼 · 감사꾼 · 교정꾼은 같은 종류의 모델)
- 목적(to + 동사) 문항 셋(10 · 16 · 22번째)은 감사꾼이 「이론상 글에 없는 목적도 가능」이라 지적했으나 글의 문장으로는 방어되지 않아 둠
- 32번 L2의 확신 4 · 31번 L2의 통과선 걸침 · 바탕의 관사 탈(32번 L8 19번째) · 21번 L1의 C · D (DEFERRED 7번)
- 레벨1이 「맞음」이 아닌 나머지 약 열네 유형을 어떻게 할지는 아직 여쭙지 못했음

### 새 도구와 바뀐 문서
- `draft/chk73.py` · `draft/gen73.py` · `fin74.sh` · `docs357.py`(일회용) · `patch75.py`(문자열 치환 도우미) · `sheets74a|b|c/` · `sheets75/`(교정꾼 기록) · `sheets76/`(마지막 판 풀이) · `bak73/` · `bak75/`(고치기 전 한글 원고)
- `LEVEL_GUIDE.md`(「33번 레벨1의 꼴」 새 절) · `README.md` · `DEFERRED.md` 7 · 13번 · `page/template.html`(33번 L1 칸 10~15/30)

### 다음에 시작할 때
- `git pull` 뒤 index.html 크기를 볼 것: **25,007,765바이트(`510e17c`, X69~X72까지)**이면 아직 → `PYTHONPATH=pending python3 build.py edits_X73a,edits_X73b out/index.html` → **''' + SIZE + '''바이트**(바탕에 X69~X72가 이미 들어 있으므로 X73만 얹음). 그보다 이전 판(`52750ec` 24,975,878바이트)이면 `edits_X72a,edits_X72b,edits_X73a,edits_X73b`를 차례로
- 다음은 **34번 레벨1을 다시 씀**(통과선 20/30 이하 · 확신 6 이하; 감사표 30/30 — 먼저 마지막 문장 시험부터 돌려 보고 필요한 만큼 고칠 것). 그다음 40번 레벨1 → 레벨2 줄을 33번부터(칸마다 마지막 문장 시험, 통과선 16/30 이하 · 확신 3 이하) → 위쪽 한 칸 시험 → 레벨3 이후
- 한 칸 순서: 영어 원고(**오답을 정답보다 한두 글자 길게 섞어 씀, 초안이 `draft/lenpart.py`로 직접 맞춤; 열린 빈칸 틀은 only · always로 닫고 지문에도 근거를 둠**) → 독립 풀이(`solve72.py`/`score72.py`: 마지막 문장만 푸는 사람 · 전체 풀이꾼 · 감사꾼) → 한글 원고 → 교정꾼(번역 · 논리, 「조사 · 말투 지적 금지」) → 고친 것 확인 한 판 → `zjosa2.py --strict --fix` → `check_all.py`(**④ 「전체 N/144칸 끝남」이 143인지**) · `lenfix.py` · `regauge.py` · `zcheck31.py` → 영어를 바꿨으면 마지막 풀이 한 판 → 문서 → `pack.py` → 측정표 페이지 → 내보내기(GitHub 최신 다시 확인 · push)
- (학생용 시험지는 필요 없다고 하셨음 — 만들지도 묻지도 말 것. 특허 일은 다른 방)
- 새 방은 `LEVEL_GUIDE.md`부터 읽을 것. **새 방 첫 줄**: 「인계문서 357번까지 올렸습니다. 34번 레벨1을 다시 봅니다.」
'''
h = h.rstrip('\n') + e357
wr(W + 'out/그루앙스_작업인계문서.md', h)

# ================= 측정표 페이지 템플릿 =================
t = rd(W + 'page/template.html')
t = rep(t, '· 33번 레벨1 (10-09, 인계문서 323번) ·',
        '· <b style="color:var(--fg)">33번 레벨1</b> (10-09, 인계문서 323번 → 10-12 인계문서 357번에서 <b>다시 씀</b> — 한 사람의 일과·버릇 이야기, 네 문장 · 단문 100% · 정답 구가 글에 그대로 나옴. 마지막 문장만 보여 주고 풀게 하면 10~15/30(처음 판은 26/30)) ·')
def cell_repl(t, rowname, idx, old_num, new_html):
    i = t.index('<b>%s</b></td>' % rowname); j = t.index('</tr>', i)
    row = t[i:j]; cells = row.split('<td class="g">')
    assert old_num in cells[idx], (rowname, idx, cells[idx][:200])
    cells[idx] = new_html
    return t[:i] + '<td class="g">'.join(cells) + t[j:]
def cell(cls, num, sure):
    return ('<span class="%s" style="display:inline-block;min-width:52px;border-radius:4px;padding:3px 6px;font-weight:700">%s</span><br><small style="color:var(--muted);font-size:11.5px">확신 %s</small></td>' % (cls, num, sure))
t = cell_repl(t, '33번 빈칸(구)', 1, '>26<', cell('v-ok', '10~15 *', '0'))
t = rep(t, '* 31번 레벨1(6~7/30)과 32번 레벨1(5~7/30)은 10월 11일 새 꼴',
        '* 31번 레벨1(6~7/30) · 32번 레벨1(5~7/30) · 33번 레벨1(10~15/30)은 10월 11~12일 새 꼴')
wr(W + 'page/template.html', t)
print('docs357 완료', SIZE)
