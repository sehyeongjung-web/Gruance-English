#!/bin/bash
# 347·348번: 32번 레벨2 — 원고에서 수정안 만들기 → 조사 → 빌드 → 자체 검사
cd /home/claude/work
python3 draft/gen68.py a && python3 draft/gen68.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X68a.py pending/edits_X68b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X67a,edits_X67b,edits_X68a,edits_X68b out/index.html | tail -3
python3 zcheck31.py 32 2 | tail -12
