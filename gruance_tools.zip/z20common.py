# -*- coding: utf-8 -*-
# 317번: 20번(주장) 레벨2를 레벨 기준으로 다시 쓰기 — 공통 도우미
#   rw(n, 정답 자리, 지문, [선택지 다섯], 해석, 주장 문장, 그 해석, 몇째, 까닭, 바꾸어 말한 곳, 낱말, [선택지별 까닭 다섯], lead=None)
# 해설의 꼴은 20번이 써 오던 꼴(① 주장 문장 찾기 → ② 까닭 → ③ 선택지와 잇기 → 📌 낱말)을 그대로 따르되 조금 넉넉하게 씀. 말끝은 「~어요」
import sys; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
ORD = {1: '첫', 2: '둘째', 3: '셋째', 4: '넷째', 5: '다섯째'}
LEAD = "① 필자의 주장은 '~해야 한다'(should·must)나 '~하라'(명령문)처럼 무엇을 하라고 말하는 문장에서 찾아요. 이 글에서는 %s 문장이에요."
def maker(E, T='20', LV='2'):
    def rw(n, ans, text, choices, ko, claim, claim_ko, pos, why, mapping, words, cn, lead=None):
        it = _tb[T][LV][n]
        assert it['answer'] == ans, (n, '정답 자리가 문항과 다름')
        assert len(choices) == 5 == len(set(choices)) == len(cn), n
        sents = [s.strip() for s in __import__('re').split(r'(?<=[.?!])\s+', text)]
        assert len(sents) == 5, (n, '문장 수', len(sents))
        assert sents[pos - 1] == claim, (n, '주장 문장의 자리', sents[pos - 1])
        assert all('정답' not in c for c in cn) and '정답' not in why + mapping, (n, '까닭에 정답이라는 말')
        walk = (lead or LEAD % ORD[pos]) + '\n"%s" (%s)\n② %s\n③ 그러니까 필자의 주장은 \'%s\'는 거예요. %s\n📌 낱말: %s' % (claim, claim_ko, why, choices[ans], mapping, words)
        out = [("정답이에요! " if k == ans else "") + "'%s' — %s" % (choices[k], cn[k]) for k in range(5)]
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(choices), 'ko': ko, 'walk': walk, 'cn': out}}
    return rw
