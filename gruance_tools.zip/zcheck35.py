# 35번 두텁게 — 자체 엄격 검사   python3 zcheck35.py [레벨, 기본 9]
# 212번에 보탠 것: 레벨 인자 / 따옴표 없이 쓴 영어 낱말이 지문에 있는지 / 「③의 also」처럼 번호와 함께 든 낱말이 그 번호 문장에 있는지
#                 / 지문을 고친 문항(ITEM_FIX)은 정답 번호·선택지만 그대로인지 봄 / 손대지 않은 문항 불변
import re,sys; sys.path.insert(0,'.')
from lib import *
T='35'; LV=sys.argv[1] if len(sys.argv)>1 else '9'; s,tb,te=load('out/index.html'); s0,tb0,te0=load()
ITEM_FIX={('8',0)}   # 212번: 레벨8 1번째 — 무관한 문장이 둘이던 것(③)을 흐름에 맞는 문장으로 바꿈
OKW=set('but yet and or so not if'.split())
C='①②③④⑤'; done=0; soft=[]
for n in range(30):
    it=tb[T][LV][n]; ex=te[T][LV][n]; P=it['text']; a=it['answer']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done+=1
    for tx in [ex['walk']]+ex['cn']:
        assert '«' not in tx and '»' not in tx, (n,'꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"')%2==0, (n,line)
            for q in re.findall(r'"([^"]*)"',line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"'%(n+1,q))
                if len(q)<12: print('!! 짧은 큰따옴표: %d번째 "%s"'%(n+1,q))
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])",tx):
            if re.search(r'[가-힣]',q) or not re.search(r'[A-Za-z]{3,}',q): continue
            parts=[p.strip() for p in re.split(r'…',q) if p.strip()]
            if not all(p.lower().strip('.,') in P.lower() for p in parts): soft.append((n+1,q))
        # 괄호 없이 쓴 영어 낱말도 지문에 있는지(한 낱말짜리 언급)
    for k in range(5):
        c=ex['cn'][k]
        assert c.startswith(C[k]+('번이 정답입니다. ' if k==a else '번은 흐름에 맞습니다. ')), (n,k,'머리말')
        assert c.count('정답')==(1 if k==a else 0), (n,k,'정답이라는 말')
        assert len(c)>=70, (n,k,'너무 짧음')
    w=ex['walk']
    said=re.findall(r'([①②③④⑤])번?(?:이|가)? ?(?:정답|답입니다)',w)
    assert said==[C[a]], (n,'풀이가 말한 답',said)
    assert ('3) 어긋나는 문장: %s'%C[a]) in w and w.count('【')==3 and all(('%d) '%i) in w for i in (1,2,3,4)), (n,'꼴')
    if (LV,n) in ITEM_FIX: assert it['answer']==tb0[T][LV][n]['answer'] and it['choices']==tb0[T][LV][n]['choices'], (n,'정답·선택지 변동')
    else: assert it==tb0[T][LV][n] and ex['ko']==te0[T][LV][n]['ko'], (n,'문항·해석 변동')
    # 번호 문장 나누기(번호 뒤에 번호 없는 끝 문장이 붙어 있어도 그 번호의 몫으로 봄)
    seg=dict((p[0],p) for p in re.split(r'(?=[①②③④⑤])',P)[1:])
    body=w.split('【이 문제에 적용】')[-1]+' '+' '.join(ex['cn'])
    for num,wd in re.findall(r"([①②③④⑤])의 '?([A-Za-z][A-Za-z ]*?)'?[\(가-힣]",body):
        if wd.strip().lower() not in seg[num].lower(): print('!! %d번째: %s의 %s — 그 번호 문장에 없음'%(n+1,num,wd))
    plain=re.sub(r'"[^"]*"','',body); plain=re.sub(r"'[^'\n]*'",'',plain)
    for wd in set(re.findall(r'[A-Za-z]{3,}',plain)):
        if wd.lower() not in P.lower() and wd.lower() not in OKW: print('!! %d번째: 따옴표 없는 영어 낱말 %s — 지문에 없음'%(n+1,wd))
    # 2)의 흐름 줄에는 답 번호가 없어야 하고 나머지 네 번호가 다 있어야 함
    flow=[l for l in w.split('\n') if l.startswith('2) ')][0]
    assert C[a] not in flow and all(C[k] in flow for k in range(5) if k!=a), (n,'흐름 줄 번호')
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']: assert tb[T][LV][n]==tb0[T][LV][n] and te[T][LV][n]==te0[T][LV][n], (n,'안 쓴 문항이 바뀜')
import statistics as _st
_w=[len(e['walk']) for e in te[T][LV] if '【이 문제에 적용】' in e['walk']]; _c=[len(c) for e in te[T][LV] if '【이 문제에 적용】' in e['walk'] for c in e['cn']]
print('두텁게 쓴 문항:',done,'/ 30')
if _w: print('풀이 평균 %d자(최소 %d, 최대 %d) / 문장별 해설 평균 %d자(최소 %d, 최대 %d)'%(_st.mean(_w),min(_w),max(_w),_st.mean(_c),min(_c),max(_c)))
for x in soft: print("  눈으로 볼 것(작은따옴표 영어가 지문에 없음): %d번째 '%s'"%x)
