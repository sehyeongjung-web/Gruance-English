# 35번 레벨9 두텁게 — 자체 엄격 검사
import re,sys; sys.path.insert(0,'.')
from lib import *
T='35'; s,tb,te=load('out/index.html'); s0,tb0,te0=load()
C='①②③④⑤'; done=0; soft=[]
for n in range(30):
    it=tb[T]['9'][n]; ex=te[T]['9'][n]; P=it['text']; a=it['answer']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done+=1
    for tx in [ex['walk']]+ex['cn']:
        assert '«' not in tx and '»' not in tx, (n,'꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"')%2==0, (n,line)
            for q in re.findall(r'"([^"]*)"',line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"'%(n+1,q))
                if len(q)<12: print('!! 짧은 큰따옴표: %d번째 "%s"'%(n+1,q))
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])",tx):
            if re.search(r'[가-힣]',q) or not re.search(r'[A-Za-z]{3,}',q): continue
            parts=[p.strip() for p in re.split(r'…',q) if p.strip()]
            if not all(p.lower().strip('.,') in P.lower() for p in parts): soft.append((n+1,q))
        # 괄호 없이 쓴 영어 낱말도 지문에 있는지(한 낱말짜리 언급)
    for k in range(5):
        c=ex['cn'][k]
        assert c.startswith(C[k]+('번이 정답입니다. ' if k==a else '번은 흐름에 맞습니다. ')), (n,k,'머리말')
        assert c.count('정답')==(1 if k==a else 0), (n,k,'정답이라는 말')
        assert len(c)>=70, (n,k,'너무 짧음')
    w=ex['walk']
    said=re.findall(r'([①②③④⑤])번?(?:이|가)? ?(?:정답|답입니다)',w)
    assert said==[C[a]], (n,'풀이가 말한 답',said)
    assert ('3) 어긋나는 문장: %s'%C[a]) in w and w.count('【')==3 and all(('%d) '%i) in w for i in (1,2,3,4)), (n,'꼴')
    assert it==tb0[T]['9'][n] and ex['ko']==te0[T]['9'][n]['ko'], (n,'문항·해석 변동')
    # 2)의 흐름 줄에는 답 번호가 없어야 하고 나머지 네 번호가 다 있어야 함
    flow=[l for l in w.split('\n') if l.startswith('2) ')][0]
    assert C[a] not in flow and all(C[k] in flow for k in range(5) if k!=a), (n,'흐름 줄 번호')
print('두텁게 쓴 문항:',done,'/ 30')
for x in soft: print("  눈으로 볼 것(작은따옴표 영어가 지문에 없음): %d번째 '%s'"%x)
