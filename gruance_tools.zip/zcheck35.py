# 35번 두텁게 — 자체 엄격 검사   python3 zcheck35.py [레벨, 기본 9]
# 212번에 보탠 것: 레벨 인자 / 따옴표 없이 쓴 영어 낱말이 지문에 있는지 / 「③의 also」처럼 번호와 함께 든 낱말이 그 번호 문장에 있는지
#                 / 지문을 고친 문항(ITEM_FIX)은 정답 번호·선택지만 그대로인지 봄 / 손대지 않은 문항 불변
import re,sys; sys.path.insert(0,'.')
from lib import *
from lowstyle import has_nida
T='35'; LV=sys.argv[1] if len(sys.argv)>1 else '9'; s,tb,te=load('out/index.html'); s0,tb0,te0=load()
ITEM_FIX={('8',0),('7',10),('6',4),('6',15)} | {('3',n) for n in range(30)} | {('2',n) for n in range(30)} | {('1',n) for n in range(30)}   # 300번: 레벨3은 지문을 목표 길이에 맞추어 다시 씀(선생님 결정 「1번」)   # 212번: 레벨8 1번째 — 무관한 문장이 둘이던 것(③)을 흐름에 맞는 문장으로 바꿈
KO_CN={}   # 299번의 두 문항(12·14번째)은 300번에서 지문을 다시 쓰면서 함께 바로잡혀 `edits_X45`를 거두어들임
try:
    import edits_X53 as _x53
    SENT_FIX={('4',n):v for n,v in _x53.SENT.items()}   # 313번: 레벨4 — 관계사절이 든 문장으로 바꿔 넣은 열두 문항
except Exception: SENT_FIX={}
try:
    import edits_X54 as _x54
    SENT_FIX.update({('5',n):v for n,v in _x54.SENT.items()})   # 313번: 레벨5 — 분사구문이 든 문장으로 바꿔 넣은 스물아홉 문항
except Exception: pass
KO_ONLY={('5',4),('5',14),('5',26),('4',0),('4',28)}   # 273번: 본문 해석만 바로잡은 문항
OKW=set('but yet and or so not if'.split())
C='①②③④⑤'; done=0; soft=[]
# 306번: 레벨1~3은 「줄이기 전」 지문으로 되돌린 칸(restore35.py) — 선생님 결정: 길이로 레벨을 나누지 않음.
# 되돌린 레벨은 누적본이 되돌리기 자료(탈 넷을 고친 것)와 글자까지 같은지, 정답 번호·선택지가 바탕과 같은지만 봄
RESTORED = {'1', '2', '3'}   # 레벨을 새 기준으로 다시 쓰면 여기서 빼고 ITEM_FIX로 볼 것
REWRITTEN = {'1': set(range(30)), '2': set(range(30)), '3': set(range(30))}   # 307번: 새 레벨 기준으로 다시 쓴 문항(되돌리기 자료와 견주지 않고 두터운 꼴로 검사)
if LV in RESTORED:
    from restore35 import snapshot, FIXES
    S = snapshot()[LV]; same = 0
    for n in range(30):
        if n in REWRITTEN.get(LV, set()): continue
        it=tb[T][LV][n]; ex=te[T][LV][n]; x=S[n]
        assert it['answer']==tb0[T][LV][n]['answer']==x['answer'] and it['choices']==tb0[T][LV][n]['choices']==x['choices'], (n,'정답·선택지 변동')
        assert it['text']==x['text'] and ex['ko']==x['ko'] and ex['walk']==x['walk'] and ex['cn']==x['cn'], (n,'되돌리기 자료와 다름')
        assert all(c in it['text'] for c in C) and all(c in ex['ko'] for c in C), (n,'번호')
        same += 1
    import statistics as _st
    w=[len(x['text'].split()) for x in tb[T][LV]]
    print('줄이기 전으로 되돌린 문항: %d / 30 (탈을 고친 문항 %d)' % (same, sum(1 for f in FIXES if f[0]==LV)))
    print('평균 %.1f낱말(번호 포함), 문장당 %.1f낱말' % (_st.mean(w), (_st.mean(w)-5)/6))
    if not REWRITTEN.get(LV): sys.exit(0)
    print('새 기준으로 다시 쓴 문항: %d / 30' % len(REWRITTEN[LV]))
for n in range(30):
    it=tb[T][LV][n]; ex=te[T][LV][n]; P=it['text']; a=it['answer']
    if '【이 문제에 적용】' not in ex['walk']: continue
    done+=1
    for tx in [ex['walk']]+ex['cn']:
        assert '«' not in tx and '»' not in tx, (n,'꺾쇠 남음')
        for line in tx.split('\n'):
            assert line.count('"')%2==0, (n,line)
            for q in re.findall(r'"([^"]*)"',line):
                if q not in P: print('!! 지문에 없음: %d번째 "%s"'%(n+1,q))
                if len(q)<12: print('!! 짧은 큰따옴표: %d번째 "%s"'%(n+1,q))
        for q in re.findall(r"'([^'\n]{3,}?)'(?![a-z])",tx):
            if re.search(r'[가-힣]',q) or not re.search(r'[A-Za-z]{3,}',q): continue
            parts=[p.strip() for p in re.split(r'…',q) if p.strip()]
            if not all(p.lower().strip('.,') in P.lower() for p in parts): soft.append((n+1,q))
        # 괄호 없이 쓴 영어 낱말도 지문에 있는지(한 낱말짜리 언급)
    for k in range(5):
        c=ex['cn'][k]
        LOW=LV in '123'
        assert c.startswith(C[k]+((('번이 정답이에요. ' if k==a else '번은 흐름에 맞아요. ')) if LOW else ('번이 정답입니다. ' if k==a else '번은 흐름에 맞습니다. '))), (n,k,'머리말')
        if LOW: assert not has_nida(c) and not has_nida(ex['walk'].split('【이 문제에 적용】')[1]), (n,k,'레벨1~3인데 「~니다」 말끝')
        assert c.count('정답')==(1 if k==a else 0), (n,k,'정답이라는 말')
        assert len(c)>=(60 if LV in '123' else 70), (n,k,'너무 짧음')   # 302번: 레벨1~3은 지문 문장이 대여섯 낱말이라 해설도 조금 짧아짐(60자 이상이면 됨)
    w=ex['walk']
    said=re.findall(r'([①②③④⑤])번?(?:이|가)? ?(?:정답|답입니다|답이에요)',w)
    assert said==[C[a]], (n,'풀이가 말한 답',said)
    assert ('3) 어긋나는 문장: %s'%C[a]) in w and w.count('【')==3 and all(('%d) '%i) in w for i in (1,2,3,4)), (n,'꼴')
    if (LV,n) in ITEM_FIX: assert it['answer']==tb0[T][LV][n]['answer'] and it['choices']==tb0[T][LV][n]['choices'], (n,'정답·선택지 변동')
    else: assert it==tb0[T][LV][n] and ex['ko']==te0[T][LV][n]['ko'], (n,'문항·해석 변동')
    # 번호 문장 나누기(번호 뒤에 번호 없는 끝 문장이 붙어 있어도 그 번호의 몫으로 봄)
    seg=dict((p[0],p) for p in re.split(r'(?=[①②③④⑤])',P)[1:])
    body=w.split('【이 문제에 적용】')[-1]+' '+' '.join(ex['cn'])
    for num,wd in re.findall(r"([①②③④⑤])의 '?([A-Za-z][A-Za-z ]*?)'?[\(가-힣]",body):
        if wd.strip().lower() not in seg[num].lower(): print('!! %d번째: %s의 %s — 그 번호 문장에 없음'%(n+1,num,wd))
    plain=re.sub(r'"[^"]*"','',body); plain=re.sub(r"'[^'\n]*'",'',plain)
    for wd in set(re.findall(r'[A-Za-z]{3,}',plain)):
        if wd.lower() not in P.lower() and wd.lower() not in OKW: print('!! %d번째: 따옴표 없는 영어 낱말 %s — 지문에 없음'%(n+1,wd))
    # 2)의 흐름 줄에는 답 번호가 없어야 하고 나머지 네 번호가 다 있어야 함
    flow=[l for l in w.split('\n') if l.startswith('2) ')][0]
    assert C[a] not in flow and all(C[k] in flow for k in range(5) if k!=a), (n,'흐름 줄 번호')
for n in range(30):
    if '【이 문제에 적용】' not in te[T][LV][n]['walk']:
        e1=dict(te[T][LV][n]); e0=dict(te0[T][LV][n])
        if (LV,n) in KO_ONLY: e1['ko']=e0['ko']=''   # 해석만 바로잡은 문항(인계문서에 적은 것만)
        if (LV,n) in SENT_FIX:   # 313번: 문장 하나만 바꿔 넣은 문항 — 지문은 그 문장만, 해석은 그 문장의 해석만 달라졌는지 봄. 풀이·해설·정답·선택지는 그대로
            sa,sb,ka,kb=SENT_FIX[(LV,n)]; i1=dict(tb[T][LV][n]); i0=dict(tb0[T][LV][n])
            assert i0['text'].count(sa)==1 and i1['text']==i0['text'].replace(sa,sb), (n,'지문 변동(허용한 것과 다름)')
            assert e1['ko']==(e0['ko'].replace(ka,kb) if ka else e0['ko']), (n,'해석 변동(허용한 것과 다름)')
            i1['text']=i0['text']=''; e1['ko']=e0['ko']=''
            assert i1==i0 and e1==e0, (n,'문장 하나 말고 다른 것이 바뀜'); continue
        if (LV,n) in KO_CN:   # 299번: 레벨3은 해설이 문장의 해석을 괄호에 넣어 보여 줌 — 해석과 해설 속의 같은 해석만 바뀐 문항
            old,new=KO_CN[(LV,n)]; assert e0['ko'].count(old)==1 and e1['ko']==e0['ko'].replace(old,new), (n,'해석 변동(허용한 것과 다름)')
            assert e1['cn']==[c.replace(old,new) for c in e0['cn']] and e1['cn']!=e0['cn'], (n,'해설 변동(허용한 것과 다름)')
            e1['ko']=e0['ko']=''; e1['cn']=e0['cn']=[]
        assert tb[T][LV][n]==tb0[T][LV][n] and e1==e0, (n,'안 쓴 문항이 바뀜')
import statistics as _st
_w=[len(e['walk']) for e in te[T][LV] if '【이 문제에 적용】' in e['walk']]; _c=[len(c) for e in te[T][LV] if '【이 문제에 적용】' in e['walk'] for c in e['cn']]
print('두텁게 쓴 문항:',done,'/ 30')
if _w: print('풀이 평균 %d자(최소 %d, 최대 %d) / 문장별 해설 평균 %d자(최소 %d, 최대 %d)'%(_st.mean(_w),min(_w),max(_w),_st.mean(_c),min(_c),max(_c)))
for x in soft: print("  눈으로 볼 것(작은따옴표 영어가 지문에 없음): %d번째 '%s'"%x)
