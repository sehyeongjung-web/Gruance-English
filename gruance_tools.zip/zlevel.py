# -*- coding: utf-8 -*-
# 315번: 새로 쓴 지문이 레벨 기준(LEVEL_GUIDE.md)에 맞는지 문장마다 잼 — levelgauge2.py를 씀
#   python3 zlevel.py 31 1            → out/index.html의 그 칸(다시 쓴 문항만 보려면 셋째 인자에 '0-14')
#   from zlevel import check_texts    → 원고 단계에서 {n: (지문, 정답)}을 바로 재 봄
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import levelgauge2 as g
RULE = {'1': dict(lo=10, hi=15, ban=('coord', 'sub', 'noun', 'rel', 'rel0', 'ptc')),
        '2': dict(lo=10, hi=15, ban=('sub', 'noun', 'rel', 'rel0', 'ptc')),
        '3': dict(lo=10, hi=15, ban=('rel', 'rel0'))}
def check_item(T, lv, it, nsent=None):
    R = RULE[lv]; gi = g.gauge_item(T, it); bad = []
    if nsent and len(gi['sents']) != nsent: bad.append('문장 수 %d' % len(gi['sents']))
    for a in gi['sents']:
        if not (R['lo'] <= a['n'] <= R['hi']): bad.append('%d낱말: %s' % (a['n'], a['text']))
        for k in R['ban']:
            if a[k]: bad.append('%s=%s: %s' % (k, a[k], a['text']))
    return gi, bad
def check_texts(T, lv, texts, nsent=None, choices=None):
    tot = 0; allbad = 0; words = []
    for n, (text, ans) in sorted(texts.items()):
        it = {'text': text, 'choices': [ans], 'answer': 0}
        gi, bad = check_item(T, lv, it, nsent)
        ns = [a['n'] for a in gi['sents']]; tot += sum(ns); words += ns
        print('%2d번째 %s 낱말 %s  기초 밖: %s' % (n + 1, sum(ns), ns, ', '.join(sorted(set(gi['out_basic']))) or '-'))
        for b in bad: print('     !!', b); allbad += 1
    print('문항 %d · 지문 평균 %.1f낱말 · 문장당 %.1f낱말(%d~%d) · 걸린 것 %d' % (len(texts), tot / len(texts), sum(words) / len(words), min(words), max(words), allbad))
    return allbad
if __name__ == '__main__':
    from lib import load
    T, lv = sys.argv[1], sys.argv[2]; _, tb, _ = load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out/index.html'))
    rng = range(30)
    if len(sys.argv) > 3: a, b = sys.argv[3].split('-'); rng = range(int(a), int(b) + 1)
    nsent = int(sys.argv[4]) if len(sys.argv) > 4 else None
    check_texts(T, lv, {n: (tb[T][lv][n]['text'], tb[T][lv][n]['choices'][tb[T][lv][n]['answer']]) for n in rng}, nsent)
