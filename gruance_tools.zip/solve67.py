# -*- coding: utf-8 -*-
# 31번 L2 원고(d67a/d67b)로 풀이꾼·감사꾼에게 줄 문제지.  python3 solve67.py <폴더> [a|b|ab]
import sys, os
sys.path.insert(0, '/home/claude/work/draft'); sys.path.insert(0, '/home/claude/work')
from lib import load
_, tb, _ = load('/home/claude/work/out/index.html')
def items(tags):
    out = []
    for tag in tags:
        d = __import__('d67' + tag)
        for n in sorted(d.I):
            it = d.I[n]; b = tb['31']['2'][n]; ch = list(b['choices'])
            for k, v in it.get('ch', {}).items(): ch[k] = v
            out.append((n, ' '.join(it['S']), ch, b['answer']))
    return out
if __name__ == '__main__':
    out = sys.argv[1]; tags = sys.argv[2] if len(sys.argv) > 2 else 'ab'
    os.makedirs(out, exist_ok=True); bl = []; au = []
    for n, t, ch, a in items(tags):
        cs = '  '.join('%s %s' % ('①②③④⑤'[k], c) for k, c in enumerate(ch))
        bl.append('[%d]\n%s\n%s\n' % (n + 1, t, cs))
        au.append('[%d] 의도한 정답 %s %s\n%s\n%s\n' % (n + 1, '①②③④⑤'[a], ch[a], t, cs))
    open(os.path.join(out, 'blind.txt'), 'w', encoding='utf-8').write('\n'.join(bl))
    open(os.path.join(out, 'audit.txt'), 'w', encoding='utf-8').write('\n'.join(au))
    print('문항', len(bl), '→', out)
