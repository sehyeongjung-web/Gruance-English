#!/bin/bash
# 357번: 33번 레벨1(단문 · 정답 구가 글에 그대로 나오는 꼴) — 원고에서 수정안 만들기 → 조사 → 빌드 (바탕 510e17c 위에 X73만)
cd /home/claude/work
python3 draft/gen73.py a && python3 draft/gen73.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X73a.py pending/edits_X73b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X73a,edits_X73b out/index.html | tail -3
