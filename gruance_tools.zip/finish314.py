# -*- coding: utf-8 -*-
# 314번 마무리: 메모 세 곳 갱신 → 페이지 다시 만들기 → 도구 묶음(zip)과 인계문서를 내보낼 폴더에 둠
import os, zipfile, shutil, sys
W = '/home/claude/work'; os.chdir(W)
def patch_notes():
    p = 'DEFERRED.md'; s = open(p, encoding='utf-8').read()
    if '8. **[314번에서 찾음' not in s:
        a = s[s.index('7. **[35번은 마침'):]
        new = '''7. **[35번은 마침 — 레벨 기준에 맞추기]** 선생님 결정(306~308번): 레벨은 길이가 아니라 낱말 수준과 문장 짜임으로 나눔(`LEVEL_GUIDE.md`). 35번 레벨1~5를 모두 맞춤(308·310·312·313번). ㉠(다른 스물네 유형을 재서 표로)은 **314번에서 마침** — 판정표: 인계문서 314번 · 페이지 「레벨 기준 측정표」(https://claude.ai/artifact/9qawWZ94DbUKWsS7Ahpmu4). **남은 일**: ㉡ 선생님이 고르신 순서대로 다른 유형을 맞추기(314번에 여쭘 — 답을 기다림) ㉢ 빈칸처럼 레벨1~3 지문이 두 문장뿐인 유형은 문장 수도 늘릴지(314번에 여쭘) ㉣ 35번 레벨6~9, 레벨6~9를 맞추는 방식은 정한 적이 없음
8. **[314번에서 찾음 — 선생님 답을 기다림]** 20번 레벨2의 틀 되풀이: 스물한 문항(1~11 · 13~15 · 24~30번째)이 「…ing은 …. ○○ experts recommend this habit. We should ….」 한 틀이고 마지막 문장이 답을 그대로 말함. 낱말도 레벨2답지 않음(cybersecurity · misinformation · retention). 다시 쓸지 여쭘
'''
        open(p, 'w', encoding='utf-8').write(s.replace(a, new))
    p = 'LEVEL_GUIDE.md'; s = open(p, encoding='utf-8').read()
    if 'levelgauge2.py' not in s:
        s = s.rstrip('\n') + '''
- **더 정확한 도구(314번)**: `python3 levelgauge2.py 유형 레벨` — 구문 분석기로 절의 종류(이은 문장·종속절·명사절·관계사절·분사구문)를 가림. 35번 레벨1~5에서 손으로 센 값과 문항 하나 차이 안. 전 유형을 잰 값은 `gauge_all.json`·`gauge_items.json`, 판정은 `verdict314.py`(판정 선은 클로이가 그은 것). 설치법은 `levelgauge2.py` 맨 위와 인계문서 314번

## 다른 유형의 지금 모습 (314번에 잰 것 — 바탕 `6ed6ca6`)
- 레벨1~5가 기준대로 선 유형은 35번뿐. 레벨4의 관계사절만 여섯 유형(30·32·35·41·42·43번)이 맞음
- 레벨1: 문장이 짧은 유형 열넷(문장당 5~9낱말), 단문이 아닌 문장이 섞인 유형 열셋 — 유형마다 반대쪽으로 어긋나 있으니 칸을 고치기 전에 반드시 먼저 재 볼 것
- 층: 문장당 낱말·절 수는 레벨을 따라 오르나 레벨5·6·7이 같고, 드문 낱말은 레벨2~8이 같음
'''
        open(p, 'w', encoding='utf-8').write(s)
    p = 'README.md'; s = open(p, encoding='utf-8').read()
    if '레벨 기준으로 재기 (314번~)' not in s:
        s = s.rstrip('\n') + '''

## 레벨 기준으로 재기 (314번~)

| 파일 | 하는 일 |
|---|---|
| `levelgauge2.py` | 문장을 구문 분석해 짜임(이은 문장·종속절·명사절·관계사절·분사구문)과 낱말 수준을 잼. `python3 levelgauge2.py 31 1`(한 칸, 문장마다 짜임이 붙어 나옴) / `python3 levelgauge2.py`(전체, 20분쯤 → `gauge_all.json`·`gauge_items.json`) |
| `wordlists.json` | 낱말 목록: NGSL 2,800(기초) · AWL 570족 + NAWL 963(학술) |
| `verdict314.py` | 칸마다 ○·△·× 판정(선은 인계문서 314번에 적어 둠) |
| `build_page314.py` + `page/template.html` | 측정표 페이지 자료(`page_data.json`)와 페이지(`page/level-gauge.html`)를 만듦. 페이지 주소: https://claude.ai/artifact/9qawWZ94DbUKWsS7Ahpmu4 (다시 재면 이 주소를 갱신) |
| `gauge_all.json` · `gauge_items.json` | 314번에 잰 값(바탕 `6ed6ca6`). 문항을 고치면 그 칸은 다시 잴 것 |
| `finish314.py` | 메모 갱신 → 페이지 만들기 → zip·인계문서를 `/home/claude/outputs/`에 둠 (경로를 모두 절대 경로로 적음) |

설치: `pip install spacy wordfreq cefrpy --break-system-packages` → `pip install --break-system-packages "spacy-curated-transformers>=0.3,<0.4"` → `pip install --break-system-packages https://github.com/explosion/spacy-models/releases/download/en_core_web_trf-3.8.0/en_core_web_trf-3.8.0-py3-none-any.whl`
(setup.sh는 이것을 설치하지 않음 — 잴 때만 설치)
'''
        open(p, 'w', encoding='utf-8').write(s)
def page():
    t = open('page/template.html', encoding='utf-8').read()
    d = open('page_data.json', encoding='utf-8').read().replace('</', '<\\/')
    open('page/level-gauge.html', 'w', encoding='utf-8').write(t.replace('/*DATA*/', d))
def bundle():
    OUT = '/home/claude/outputs'; os.makedirs(OUT, exist_ok=True)
    zp = os.path.join(OUT, 'gruance_tools.zip')
    if os.path.exists(zp): os.remove(zp)
    SKIP_DIR = {'out', '__pycache__'}; SKIP = {'gauge_run.err', 'gauge_run.log', '_local.html', 'desk.png', 'phone.png', 'shot.js'}
    n = 0
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for root, dirs, files in os.walk(W):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIR)
            for f in sorted(files):
                if f in SKIP or f.endswith('.pyc'): continue
                full = os.path.join(root, f); z.write(full, os.path.relpath(full, W)); n += 1
    shutil.copy(os.path.join(W, 'out', '그루앙스_작업인계문서.md'), OUT)
    print('zip에 든 파일', n, '·', os.path.getsize(zp), '바이트 /', '인계문서', os.path.getsize(os.path.join(OUT, '그루앙스_작업인계문서.md')), '바이트')
if __name__ == '__main__':
    patch_notes(); page(); bundle()
