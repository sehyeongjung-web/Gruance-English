# 풀이꾼용 문제지 셋: python3 solve72.py <폴더> <유형> <레벨> <d파일 이름(확장자 없이)>
import sys, os, importlib.util
sys.path.insert(0,'/home/claude/work')
from lib import load
folder,T,L,f = sys.argv[1:5]
_,tb,_ = load('/home/claude/work/out/index.html')
spec = importlib.util.spec_from_file_location(f, '/home/claude/work/draft/%s.py' % f); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); I=m.I
os.makedirs(folder, exist_ok=True)
B=[];Lr=[];A=[]
for n in sorted(I):
    it = I[n]; ans = tb[T][L][n]['answer']
    ch = '  '.join('%s %s' % ('①②③④⑤'[k], it['ch'][k]) for k in range(5))
    B.append('[%d]\n%s\n%s\n' % (n+1, ' '.join(it['S']), ch))
    Lr.append('[%d] %s\n   %s\n' % (n+1, it['S'][3], ch))
    A.append('[%d]  KEY=%s %s\n%s\n%s\n' % (n+1, '①②③④⑤'[ans], it['ch'][ans], ' '.join(it['S']), ch))
for name, rows in (('blind', B), ('last', Lr), ('audit', A)):
    open(os.path.join(folder, name + '.txt'), 'w', encoding='utf-8').write('\n'.join(rows))
print('ok', len(I), 'answers', [tb[T][L][n]['answer']+1 for n in range(len(I))])
