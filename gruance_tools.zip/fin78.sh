#!/bin/bash
# 361번: 19번 레벨1 — 원고에서 수정안 만들기 → 조사 → 빌드 (바탕 7b287fb 위에 X77만)
cd /home/claude/work
python3 draft/gen78.py a && python3 draft/gen78.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X77a.py pending/edits_X77b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X77a,edits_X77b out/index.html | tail -3
