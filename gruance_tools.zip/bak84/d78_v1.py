# -*- coding: utf-8 -*-
# 19번(심경 변화) 레벨1 다시 쓰기(361번) — I[n] = dict(S=[네 문장], ch={0..4: "a → b"})
I = {}
I[0] = dict(S=['Before her first piano recital, Harin felt scared of the big stage.', 'Her piano teacher in the front row looked calm and gave her a smile.', 'Harin played her song without a single mistake in front of everyone.', 'At the end, Harin felt very proud and bowed to her family.'],
 ch={0: 'scared → proud', 1: 'calm → proud', 2: 'scared → upset', 3: 'calm → upset', 4: 'excited → upset'})
I[1] = dict(S=['On a windy hill, Doha felt very excited about his new red kite.', 'His younger brother looked bored on a bench under a tall tree.', 'Suddenly, a strong wind broke the string and carried the kite away.', 'Doha felt very sad on the long walk home without his kite.'],
 ch={0: 'bored → sad', 1: 'excited → angry', 2: 'bored → angry', 3: 'excited → sad', 4: 'curious → angry'})
I[2] = dict(S=['On Saturday, Seri felt bored in her room during the heavy rain.', 'Her older brother was happy with his new video game in the living room.', 'On Sunday, her best friend Yuna canceled their plans for a movie.', 'Seri felt very lonely by the window for the rest of the day.'],
 ch={0: 'happy → lonely', 1: 'bored → upset', 2: 'happy → upset', 3: 'tired → upset', 4: 'bored → lonely'})
I[3] = dict(S=['On Sunday morning, Eunho was curious about a loud knock at the door.', 'His uncle from Jeju stood at the door and looked tired after the long trip.', "Eunho's mother looked surprised at the sight of her younger brother.", 'All day long, Eunho felt very happy with his funny uncle.'],
 ch={0: 'curious → happy', 1: 'surprised → happy', 2: 'curious → tired', 3: 'surprised → tired', 4: 'scared → tired'})
I[4] = dict(S=['Gyuri gave a speech for class president in front of her whole class.', 'Before the speech, Gyuri felt very nervous and held her notes tightly.', 'Her best friend Dabin in the front row looked calm and gave her a smile.', 'After the speech, Gyuri felt relieved at the loud cheers from her classmates.'],
 ch={0: 'calm → relieved', 1: 'nervous → disappointed', 2: 'calm → disappointed', 3: 'nervous → relieved', 4: 'bored → disappointed'})
I[5] = dict(S=['Siwan felt excited about his first trip to a baseball stadium with his dad.', 'On Saturday morning, the stadium canceled the game because of heavy rain.', 'Siwan was very disappointed and stayed in his room until lunch.', 'His younger sister felt relieved about a quiet day at home with her dolls.'],
 ch={0: 'curious → disappointed', 1: 'excited → relieved', 2: 'curious → relieved', 3: 'nervous → relieved', 4: 'excited → disappointed'})
I[6] = dict(S=['On Monday, Yeseul felt worried about the new route of her school bus.', 'The bus driver looked a little tired on the first morning of the route.', 'The new route went past a beautiful lake with many white birds.', 'Yeseul was glad about the new view from her window seat.'],
 ch={0: 'tired → glad', 1: 'worried → bored', 2: 'worried → glad', 3: 'tired → bored', 4: 'scared → bored'})
I[7] = dict(S=['Minha was very happy with her new phone from her parents.', 'Her older sister looked curious about the new phone at dinner.', 'On Friday, the phone fell from her hand and broke on the bus floor.', 'Minha felt very upset and cried quietly all the way home from school.'],
 ch={0: 'curious → upset', 1: 'happy → angry', 2: 'curious → angry', 3: 'happy → upset', 4: 'excited → angry'})
I[8] = dict(S=["On Sunday morning, Taerin's little puppy Coco was not in the yard.", 'Taerin felt very scared and looked for Coco all over town.', 'Her older brother looked calm and put up posters on every street.', 'By night, Taerin was very sad without any news of her puppy.'],
 ch={0: 'calm → sad', 1: 'scared → relieved', 2: 'scared → sad', 3: 'calm → relieved', 4: 'tired → relieved'})
I[9] = dict(S=['Jaeyun was excited about the school cooking contest on Friday afternoon.', 'His partner Sohyun looked nervous in front of the three judges.', 'The two friends made spicy kimchi soup together for the judges.', 'With the first prize in his hands, Jaeyun felt very proud of their soup.'],
 ch={0: 'nervous → proud', 1: 'excited → proud', 2: 'excited → lonely', 3: 'nervous → lonely', 4: 'bored → lonely'})
I[10] = dict(S=['On her first day at a new school, Seyeon felt very nervous in the hallway.', 'Her mother at the school gate looked worried about her shy daughter.', 'At lunch, her new desk partner looked excited about sharing snacks with Seyeon.', 'By the end of the day, Seyeon was happy with her new school.'],
 ch={0: 'worried → happy', 1: 'nervous → excited', 2: 'worried → excited', 3: 'scared → excited', 4: 'nervous → happy'})
I[11] = dict(S=['Before the soccer game, Jaeha was excited about his new red shoes.', 'In the heavy rain, he slipped in the mud and missed an easy goal.', 'After the game, Jaeha felt very disappointed and sat alone on the bench.', 'His coach looked worried about him and gave him a dry towel.'],
 ch={0: 'nervous → disappointed', 1: 'excited → worried', 2: 'excited → disappointed', 3: 'nervous → worried', 4: 'proud → worried'})
I[12] = dict(S=['In the waiting room at the dentist, Woobin felt scared of the loud drill.', 'His older sister next to him looked calm and read a comic book.', 'The dentist found two holes in his teeth and gave him a shot.', 'On the way home, Woobin was upset about a month with no candy.'],
 ch={0: 'calm → upset', 1: 'scared → relieved', 2: 'calm → relieved', 3: 'bored → relieved', 4: 'scared → upset'})
I[13] = dict(S=['On Saturday morning, Nayun was excited about building a birdhouse with her dad.', 'Her little brother stayed home with a cold and felt lonely in his room.', 'Nayun and her dad built a small birdhouse in the yard before lunch.', 'In the evening, Nayun felt proud of their new birdhouse on the old tree.'],
 ch={0: 'lonely → proud', 1: 'excited → tired', 2: 'lonely → tired', 3: 'thankful → tired', 4: 'excited → proud'})
I[14] = dict(S=['Hayul was worried about the big math test on Friday morning.', 'Her best friend Yewon was calm about the test and smiled at her.', 'In the test, Hayul solved every problem with the tips from her teacher.', 'On Monday, Hayul got a perfect score and felt very relieved.'],
 ch={0: 'calm → relieved', 1: 'worried → relieved', 2: 'worried → disappointed', 3: 'calm → disappointed', 4: 'scared → disappointed'})
I[15] = dict(S=['On the boat ride across the big lake, Juha was happy about the sunny day.', 'His little sister on the bench looked tired after the long drive.', 'Suddenly, a strong wind blew his new hat into the cold water.', 'Juha felt very upset about the hat for the rest of the day.'],
 ch={0: 'tired → upset', 1: 'happy → upset', 2: 'happy → bored', 3: 'tired → bored', 4: 'curious → bored'})
I[16] = dict(S=['In the long line for the big roller coaster, Yuchan felt very scared.', 'His older cousin next to him was excited about the first big drop.', 'The fast ride went up and down the tall tracks for two minutes.', 'At the exit, Yuchan felt proud of himself and wanted another ride.'],
 ch={0: 'scared → proud', 1: 'excited → proud', 2: 'scared → sad', 3: 'excited → sad', 4: 'bored → sad'})
I[17] = dict(S=["On Friday, Doha was happy about a sleepover at her best friend's house.", 'That night, her friend Hyewon told Doha about her move to Canada.', 'Hyewon looked curious about her new school and a big house in Toronto.', 'Doha felt sad in her bed for the rest of the night.'],
 ch={0: 'curious → sad', 1: 'happy → angry', 2: 'curious → angry', 3: 'happy → sad', 4: 'calm → angry'})
I[18] = dict(S=['At the bank with his mom, Gunwoo was bored in the long line.', 'His mom looked worried about the time and checked her watch.', 'After forty minutes, a worker closed the window right in front of them.', 'Gunwoo felt very angry and wanted to go home with his mom.'],
 ch={0: 'worried → angry', 1: 'bored → tired', 2: 'worried → tired', 3: 'bored → angry', 4: 'lonely → tired'})
I[19] = dict(S=['Yebin felt curious about her first fireworks show by the river.', 'Her little brother was scared of the loud noise and covered his ears.', 'At nine, hundreds of bright flowers of fire filled the night sky.', 'Yebin felt excited and clapped her hands for every big flower.'],
 ch={0: 'scared → excited', 1: 'curious → disappointed', 2: 'curious → excited', 3: 'scared → disappointed', 4: 'calm → disappointed'})
I[20] = dict(S=['Dohun felt very tired on the long bike ride to the beach.', 'His older sister Yena looked excited about the ride from the very start.', 'Near the end, Dad looked proud of his two kids on the last hill.', 'At the sight of the sea, Dohun felt happy and ran into the water.'],
 ch={0: 'excited → proud', 1: 'tired → happy', 2: 'excited → happy', 3: 'bored → proud', 4: 'tired → proud'})
I[21] = dict(S=["Eunji felt excited about her mom's birthday cake from the bakery.", 'Her little brother Juno looked curious about the big white box on the table.', 'On the way to the table, Eunji dropped the cake on the kitchen floor.', 'Eunji felt very sad and sat on the floor next to the cake.'],
 ch={0: 'curious → sad', 1: 'excited → angry', 2: 'calm → angry', 3: 'excited → sad', 4: 'curious → angry'})
I[22] = dict(S=['Gunwoo felt worried about the time on the slow bus to the station.', "At the station, he missed the train to his grandmother's town by two minutes.", 'His father stayed calm and bought tickets for the next train.', 'Gunwoo still felt disappointed on a cold bench for the next hour.'],
 ch={0: 'worried → disappointed', 1: 'calm → disappointed', 2: 'worried → relieved', 3: 'calm → relieved', 4: 'excited → relieved'})
I[23] = dict(S=['Yeseo was curious about the other projects at the school science fair.', 'Her best friend Mina looked nervous next to her own small robot.', 'In the afternoon, the judges gave Yeseo the second prize for her robot.', 'Yeseo felt very proud and showed the prize to her parents at home.'],
 ch={0: 'nervous → proud', 1: 'curious → proud', 2: 'bored → disappointed', 3: 'curious → disappointed', 4: 'nervous → disappointed'})
I[24] = dict(S=['Siyun felt scared of the big audience before the school play.', 'Her drama teacher looked calm in the dark corner of the stage.', 'Siyun said all her lines in the play without a single mistake.', 'After the play, Siyun felt relieved and laughed with her friends backstage.'],
 ch={0: 'scared → relieved', 1: 'calm → relieved', 2: 'scared → proud', 3: 'calm → proud', 4: 'bored → proud'})
I[25] = dict(S=['Hyunjin was happy about the hike to the top of Mount Seorak.', 'His uncle looked tired after the first hour on the steep path.', 'At the top, thick gray fog covered the whole view of the valley.', 'Hyunjin felt upset and put his new camera back into his bag.'],
 ch={0: 'tired → upset', 1: 'tired → angry', 2: 'happy → upset', 3: 'happy → angry', 4: 'excited → angry'})
I[26] = dict(S=['Chaerin felt bored at the start of her first painting class.', 'Her best friend Dain looked happy with her bright yellow sunflower picture.', 'Then the teacher showed Chaerin a new way to paint the night sky.', 'Chaerin felt excited and painted a big blue sky full of stars.'],
 ch={0: 'happy → excited', 1: 'bored → excited', 2: 'bored → thankful', 3: 'happy → thankful', 4: 'tired → thankful'})
I[27] = dict(S=['Juwon felt calm at the start of the class relay on sports day.', 'His teammate Seungho looked very nervous at the start line.', 'In the middle of the race, Juwon dropped the baton on the track.', 'Juwon felt upset about his mistake for the rest of the day.'],
 ch={0: 'nervous → upset', 1: 'nervous → lonely', 2: 'calm → upset', 3: 'calm → lonely', 4: 'happy → lonely'})
I[28] = dict(S=['Seyeon felt scared in the dark living room during the power cut.', 'Her older brother Jiho stayed calm and lit two candles on the table.', 'The power did not come back for the next three hours.', "By ten o'clock, Seyeon felt bored without her phone or the TV."],
 ch={0: 'calm → bored', 1: 'scared → relieved', 2: 'calm → relieved', 3: 'happy → relieved', 4: 'scared → bored'})
I[29] = dict(S=['Hayul felt curious about the old houses in Hahoe Village.', 'Her younger brother looked bored on the long walk between the houses.', 'An old woman in the village gave the two children some warm rice cakes.', 'Hayul felt thankful for her kindness and said goodbye with a big smile.'],
 ch={0: 'curious → thankful', 1: 'bored → thankful', 2: 'curious → tired', 3: 'bored → tired', 4: 'disappointed → tired'})
