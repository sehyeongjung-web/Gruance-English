# -*- coding: utf-8 -*-
# 365번: 24번(제목) 레벨1 — 공통 도우미 (z23common을 본뜸)
#   rw(n, 정답 자리, 지문, [보기 다섯], 해석(네 줄), 핵심 문장, 그 해석, 몇째, 까닭, 바꾸어 말한 곳, 낱말, [보기별 까닭 다섯], [보기 해석 다섯], lead=None)
# 해설의 꼴은 23번이 써 오던 꼴(① 핵심 문장 → ② 까닭 → ③ 알맞은 제목 → 📌 낱말)을 따르고, 보기마다 「'영어' (해석) — 까닭」으로 씀. 말끝은 「~어요」
import sys, re; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
ORD = {1: '첫째', 2: '둘째', 3: '셋째', 4: '넷째', 5: '다섯째'}
LEAD = "① 제목은 글 전체를 짧게 나타낸 거예요. 겪은 일을 묶어 누구에게나 통하는 말로 정리한 문장이 핵심 문장이에요. 이 글에서는 %s 문장이에요."
def maker(E, T='24', LV='1', NS=4):
    def rw(n, ans, text, choices, ko, claim, claim_ko, pos, why, mapping, words, cn, ch_ko, lead=None):
        it = _tb[T][LV][n]
        assert it['answer'] == ans, (n, '정답 자리가 문항과 다름')
        assert len(choices) == 5 == len(set(choices)) == len(cn) == len(ch_ko), n
        sents = [s.strip() for s in re.split(r'(?<=[.?!])\s+', text)]
        assert len(sents) == NS, (n, '문장 수', len(sents))
        assert sents[pos - 1] == claim, (n, '핵심 문장의 자리', sents[pos - 1])
        assert all('정답' not in c for c in cn) and '정답' not in why + mapping, (n, '까닭에 정답이라는 말')
        W4 = ['첫째', '둘째', '셋째', '넷째', '다섯째']
        def q(tx):
            for m in re.findall(r'«([^»]*)»', tx): assert m in text, (n, '지문에 없는 인용', m)
            for who, m in re.findall(r'(첫째|둘째|셋째|넷째|다섯째) 문장[^«\n]{0,14}«([^»]*)»', tx):
                assert m in sents[W4.index(who)], (n, '문장 자리가 어긋남', who, m)
            return tx.replace('«', '"').replace('»', '"')
        why, mapping, cn = q(why), q(mapping), [q(c) for c in cn]
        walk = (lead or LEAD % ORD[pos]) + '\n"%s" (%s)\n② %s\n③ 그러니까 알맞은 제목은 이것이에요. → \'%s\' (%s) %s\n📌 낱말: %s' % (claim, claim_ko, why, choices[ans], ch_ko[ans], mapping, words)
        out = [("정답이에요! " if k == ans else "") + "'%s' (%s) — %s" % (choices[k], ch_ko[k], cn[k]) for k in range(5)]
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(choices), 'ko': ko, 'walk': walk, 'cn': out}}
    return rw
