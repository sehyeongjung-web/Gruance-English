# -*- coding: utf-8 -*-
# 35번 읽기: python3 show35.py 7 0 10
import sys; sys.path.insert(0, '.')
from lib import *
lv, a, b = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
s, tb, te = load()
for n in range(a, b):
    it = tb['35'][lv][n]
    print('=====', n + 1, 'ans', '①②③④⑤'[it['answer']], '(%d)' % len(it['text'].split())); print(it['text'])
