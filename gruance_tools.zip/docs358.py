# -*- coding: utf-8 -*-
# 358번 문서 갱신(일회용): LEVEL_GUIDE · README · DEFERRED · 인계문서 · 측정표 페이지 템플릿
import os, sys
sys.path.insert(0, '/home/claude/work/draft')
def rd(p): return open(p, encoding='utf-8').read()
def wr(p, s): open(p, 'w', encoding='utf-8').write(s)
def rep(s, old, new, cnt=1):
    assert s.count(old) == cnt, (old[:70], s.count(old))
    return s.replace(old, new)
W = '/home/claude/work/'
SIZE = '{:,}'.format(os.path.getsize(W + 'out/index.html'))
import d74
KEY = [2,0,0,1,3,0,2,2,4,3,4,0,2,3,1,1,3,4,1,3,4,4,2,0,1,2,1,0,4,3]
ANS = ' · '.join(d74.I[n]['ch'][KEY[n]] for n in range(30))

# ================= LEVEL_GUIDE.md =================
g = rd(W + 'LEVEL_GUIDE.md')
g = rep(g, '33번 레벨1은 357번에서 다시 써서 **10 · 11 · 10 · 15/30(확신 0)**(이 표에 있던 26~30은 모두 옛 판의 값)',
        '33번 레벨1은 357번에서 다시 써서 **10 · 11 · 10 · 15/30(확신 0)**, 34번 레벨1은 358번에서 다시 써서 **11 · 12 · 14/30(확신 0)**(다시 쓰기 전 판은 29/30)(이 표에 있던 26~30은 모두 옛 판의 값)')
g = rep(g, '→ 33번 레벨1(**357번에 마침**) → 34 · 40번 레벨1(감사표에서',
        '→ 33번 레벨1(**357번에 마침**) → 34번 레벨1(**358번에 마침**) → 40번 레벨1(감사표에서')
a = g.index('## 34번(빈칸 — 긴 구) 레벨1의 꼴 (324·325번'); b = g.index('## 38-39번(문장 넣기) 레벨1의 꼴')
new34 = '''## 34번(빈칸 — 긴 구) 레벨1의 꼴 (358번 — 서른 문항 다시 씀)
※ 324 · 325번의 첫 판(버릇 → 좋은 결과 · 바꾼 뒤 나아짐 → 그 전의 탈: 「For Jenny, this small job ______.」)은 358번에 마지막 문장만 보여 주고 풀게 하니 **29/30(확신 2)** — 정답이 가장 그럴듯한 「일반적인 좋은 결과」라 상식으로 풀림. 그래서 이 꼴로 다시 씀(통과선 20/30 이하 · 확신 6 이하).
- 틀: 31~33번 레벨1과 같음 — **네 문장 · 평균 50.7낱말 · 문장당 평균 12.7낱말(10~15) · 단문 100%**(`zlevel.RULE['1']`, `draft/chk74.py` 걸린 것 0, `regauge.py 34 1` 판정 맞음). 정답은 **긴 구(4~7낱말, 대개 5~6)**이고 둘째 또는 셋째 문장에 글자 그대로 나옴. 넷째에는 없음
- **조건 대비 꼴**: 첫째 = 일과 · 규칙의 배경, 둘째 · 셋째 = **두 경우**(월~금 ↔ 일요일 · 학교 가는 날 ↔ 토요일 · 새 회원 ↔ 작년 회원 · 첫날 ↔ 둘째 날 …)에 각각 다른 긴 구, 넷째 = 정답 쪽 조건을 다시 말하고 빈칸. 다른 경우의 구가 끌리는 오답, 나머지 셋은 글에 없는 구
- 빈칸 종류 여섯을 다섯 문항씩: K1 목적 to부정사구 · K2 「helps/lets + 사람」 뒤 원형동사구 · K3 「by + -ing」 · K4 명사구 · K5 전치사구(장소 · 때) · K6 조동사(can/may) 뒤 동사구. **「이 습관 덕분에 …」식 결과 문장은 쓰지 않음**(상식으로 풀림)
- 정답 긴 구 서른: ''' + ANS + '''
- 정답 번호는 바탕 그대로(변동 0건). `zcheck31.py`의 `ANS_FIX[('1','34',n)]` 서른 개(옛 324 · 325번의 여섯 항목은 뒤의 `update`가 덮어씀). 영어 `draft/d74.py`(초안 `d74_1~3.py`, 규칙 `draft/brief_d74.txt`, 모양 `d74_probe.py`, 검사 `chk74.py`), 한글 `draft/k74_1~6.py`(규칙 `draft/brief_k74.txt`), `./fin75.sh` → `pending/edits_X74a|b.py`
- 보기 길이: 정답이 가장 긴 3 · 첫째 · 둘째로 긴 13 · B 0 · C 0 · E 0(`draft/lenpart.py 34 1`). `check_all` ④ 143/144 유지
- **이번에 배운 것**
  - **「only job」은 「가는 목적이 하나」를 받치지 못함**: 「Hyobin's only job there is to …」인데 빈칸 문장이 「Hyobin goes to the shelter only ______」이면 일이 아닌 목적(새끼 고양이와 놀러)이 막히지 않음 → 글도 「Hyobin goes there only to …」로(3 · 14 · 19번째). **빈칸 문장의 only와 글의 only가 같은 것(목적 · 방법 · 할 수 있는 일)에 걸려야 함**
  - 한 문항에 only가 두 사람에게 걸리면(일기장이 엄마도 「only」, 할아버지도 「only」) 서로 부딪침 → 한쪽을 also로(20번째)
  - 정답 구가 다른 문항과 같으면(「to give the cats fresh water」 둘) 하나를 바꿈(19번째 → 「to clean the small rabbit cages」)
  - 교정꾼 논리 지적 43건의 대부분이 같은 꼴: **오답 해설이 두 경우를 늘어놓기만 하거나(「글에 나온 것은 이것들뿐」) 「때가 다르니 빠져요」로 막음** — 다른 경우는 그 경우의 일일 뿐, 이 경우에 그 일을 안 한다는 근거는 only · always 문장. 해설마다 그 문장을 «인용» + 'only'로 댈 것(브리프에 넣을 것)
  - 우리말: 「오직 하준이 ______ 도와준다」는 오직이 사람에 걸려 읽힘 → 「하준이 오직 ______」 · 「her poem」을 「자기 시」로 옮기면 지은 시로 읽힘 → 「시」 · 「The older members」(New members와 맞섬)는 「기존 회원들」(나이 이야기 아님) · 주어가 일기장 · 영상인 문장의 「자기 정원」은 「정원」
- 독립 풀이: 마지막 문장만 푸는 풀이꾼 **11 · 12/30(확신 0) → 고친 뒤 14/30(확신 0)** · 지문 전체 **30/30** · 감사꾼 첫판 1건(두 only가 부딪침) → 마지막 판 문제 없음(`sheets77/`(옛 판 29/30) · `sheets78a/` · `sheets80/`). 교정꾼 넷: 번역 16건 + 논리 43건을 고침꾼 셋이 모두 반영, 고친 것 확인 한 판에서 1건(3번째 「only job」) 더 고침
- **남은 한계(숨기지 않고)**: ① 마지막 문장만 주어도 11~14문항은 맞음(통과선 20 이내) ② 학생이 실제로 푼 결과는 없음(풀이꾼 · 감사꾼 · 교정꾼은 같은 종류의 모델) ③ 34번 레벨1이 33번 레벨1과 짜임이 아주 닮음(정답 구의 길이만 다름) — 34번다운 「긴 구 · 넓은 말」은 레벨2 이상에서 살릴 것 ④ `check_all`의 「34번 L1: 평균 46단어(목표 약 16단어)」 경고는 레벨1~3의 옛 길이 기준이라 그대로 둠

'''
g = g[:a] + new34 + g[b:]
wr(W + 'LEVEL_GUIDE.md', g)

# ================= README.md =================
r = rd(W + 'README.md')
old = "| `pending/edits_X73b.py` | **33번 레벨1 뒤 절반(357번 — 16~30번째).** 만든 법: `python3 draft/gen73.py b`. 한꺼번에: `./fin74.sh`(gen73 a/b → zjosa2 → 빌드 `edits_X73a,edits_X73b` — 바탕 510e17c에는 X69~X72가 이미 들어 있음) |"
r = rep(r, old, old + "\n"
 "| `pending/edits_X74a.py` | **34번(빈칸 — 긴 구) 레벨1 앞 절반(358번 — 1~15번째), 조건 대비 꼴(두 경우에 각각 다른 긴 구) · 단문 100% · 정답 긴 구가 글에 그대로.** 영어 `draft/d74.py`, 한글 `draft/k74_1.py`~`k74_6.py` → `python3 draft/gen74.py a` |\n"
 "| `pending/edits_X74b.py` | **34번 레벨1 뒤 절반(358번 — 16~30번째).** 만든 법: `python3 draft/gen74.py b`. 한꺼번에: `./fin75.sh`(gen74 a/b → zjosa2 → 빌드 `edits_X74a,edits_X74b` — 바탕 5c14ac4에는 X69~X73이 이미 들어 있음) |")
i = r.index('- 33번 레벨1(357번): 영어'); j = r.index('\n', i)
r = r[:j+1] + ("- 34번 레벨1(358번): 영어 `python3 draft/chk74.py draft/d74.py` · 초안 길이 `python3 draft/lenpart.py 34 1 draft/d74.py` · 한글 `python3 draft/zk69.py draft/k74_N.py draft/d74.py` · 한 번에 `./fin75.sh` → `python3 zcheck31.py 34 1` · `check_all.py`(④ 143) · `lenfix.py 34 1` · `regauge.py 34 1`. 풀이꾼: `python3 solve72.py sheets80 34 1 d74` → `score72.py sheets80 34 1`. **지금 판을 먼저 재는 법**(다시 쓰기 전): 빌드한 out/index.html에서 마지막 문장 · 보기만 뽑는 짧은 코드는 인계문서 358번(`sheets77/`). 교정 지적을 고침꾼에게 맡길 때는 지적 번호 [n] = 원고 K[n-1], 원고의 «…»가 문제지에는 \"…\"로 보인다는 것을 알려 줄 것. 문자열 치환 도우미 `patch75.py`(`patch(파일, [(옛, 새), …])` — 하나라도 없으면 아무것도 안 씀)\n") + r[j+1:]
wr(W + 'README.md', r)

# ================= DEFERRED.md =================
d = rd(W + 'DEFERRED.md')
d = rep(d, '→ 34 · 40번 레벨1을 다시 씀(통과선 20/30 이하 · 확신 6 이하) → 레벨2 줄을 33번부터',
        '→ ~~34번 레벨1~~(**358번에 마침** — 다시 쓰기 전 판은 마지막 문장만 보여 줘도 29/30, 새 판은 11 · 12 · 14/30, 확신 0, 지문 전체 30/30, 감사꾼 마지막 판 문제 없음, 교정꾼 59건 + 확인 1건 반영, `pending/edits_X74a|b.py`, 빌드는 바탕 5c14ac4 위에 `edits_X74a,edits_X74b`) → 40번 레벨1을 다시 씀(통과선 20/30 이하 · 확신 6 이하; 먼저 지금 판을 마지막 문장 시험으로 잴 것) → 레벨2 줄을 33번부터')
d = rep(d, '325번: 34번 뒤 절반에서 둘(17·25번째)을 더 고쳐 34번은 여섯, 33·34번 합쳐 열. 뜻이 움직인 것은 34번 5·25번째',
        '325번: 34번 뒤 절반에서 둘(17·25번째)을 더 고쳐 34번은 여섯, 33·34번 합쳐 열. 뜻이 움직인 것은 34번 5·25번째(357 · 358번에 33 · 34번 레벨1을 처음부터 다시 써서 이 열은 모두 사라짐)')
wr(W + 'DEFERRED.md', d)

# ================= 인계문서 =================
h = rd(W + 'out/그루앙스_작업인계문서.md')
e358 = '''

## 358. 34번(빈칸 — 긴 구) 레벨1을 새 꼴로 다시 씀 (2026-10-12, 같은 방)

선생님 「진행」(07:25) → 순서대로 **34번 레벨1.** 먼저 지금 판(324 · 325번)을 마지막 문장 · 보기만 보여 주고 풀게 함(`sheets77/` — 빌드한 out/index.html의 `tb['34']['1'][n]['text']`를 문장으로 나눠 마지막 문장만 뽑음) → **29/30(확신 2)**로 통과선(20)을 크게 넘어 서른 문항을 새로 씀. 수정안 `pending/edits_X74a.py`(1~15번째) · `pending/edits_X74b.py`(16~30번째).

### 꼴 (LEVEL_GUIDE.md 「34번(빈칸 — 긴 구) 레벨1의 꼴」)
- 31~33번 레벨1과 같은 틀(네 문장 · 평균 50.7낱말 · 문장당 평균 12.7 · 단문 100%)에 **조건 대비 꼴**: 둘째 · 셋째 문장이 두 경우(월~금 ↔ 일요일, 새 회원 ↔ 작년 회원 …)에 각각 다른 **긴 구(4~7낱말)**를 말하고, 넷째가 한 경우를 골라 빈칸. 빈칸 종류 여섯(목적 to · helps 뒤 동사구 · by -ing · 명사구 · 전치사구 · 조동사 뒤 동사구)을 다섯 문항씩
- 정답 번호는 바탕 그대로(변동 0건). 정답 긴 구 서른: ''' + ANS + '''

### 무엇을 했나
- **영어**: 지침 `draft/brief_d74.txt`(33번에서 배운 「열린 틀은 only로 닫고 글에도 근거」를 넣음) · 본보기 `draft/d74_probe.py` 세 문항 → 세 opus 초안(`draft/d74_1~3.py`, 열 문항씩, 빈칸 종류 · 글감 영역을 문항마다 배정) → 합본 `draft/d74.py`. 첫 시험(`sheets78a/`): 마지막 문장만 **11 · 12/30(확신 0)** · 지문 전체 **30/30** · 감사꾼 1건(20번째: 일기장이 엄마도 only, 할아버지도 only → 엄마 쪽을 also로). 19번째의 정답 구가 7번째와 같아(「to give the cats fresh water」) 「to clean the small rabbit cages」로 바꿈
- **한글**: 여섯 opus가 다섯 문항씩(`draft/k74_1~6.py`, 규칙 `draft/brief_k74.txt`), `draft/zk69.py` 걸린 것 0
- **교정꾼 넷**(번역 둘 · 논리 둘): 번역 16건 + 논리 43건 = 59건. 논리 지적의 대부분은 「오답 해설이 두 경우를 늘어놓기만 하거나 때가 다르다는 것만으로 막음 — only · always 문장을 인용해 막아야 함」. 이번에는 **고침꾼 셋(opus)**에게 열 문항씩 맡겨 모두 반영(지적 번호 [n] = 원고 K[n-1]). 이 가운데 19번째는 **영어를 고침**: 「Hyobin's only job there is to …」 → 「Hyobin goes there only to …」(빈칸 문장 「goes to the shelter only ______」의 only를 받치게). 고침꾼이 같은 틈을 14번째에서 더 찾아 영어를 고침(「her only job there is to pack …」 → 「she goes there only to pack …」)
- **고친 것 확인 한 판**(`sheets79/pr_verify2.txt`): 3번째에 같은 틈 1건 → 영어 「Dohyun goes there only to put the potatoes in paper bags.」로 고치고 한글을 맞춤. 고침꾼이 알려 준 약한 해설 둘(25번째 ⑤ · 30번째 ③)도 only 인용으로 고침
- 마지막 판 독립 풀이(`sheets80/`): 마지막 문장만 **14/30(확신 0)** · 지문 전체 **30/30** · 감사꾼 문제 없음

### 점검
- `draft/chk74.py` 걸린 것 0 · `draft/lenpart.py 34 1` 정답이 가장 긴 3 · 첫째 · 둘째로 긴 13 · B 0 · C 0 · E 0 · `zcheck31.py 34 1` 두텁게 쓴 문항 30/30 · `regauge.py 34 1` 판정 맞음 · `zjosa2.py --strict --fix` 둘 다 어긋난 곳 0 · `check_all.py` 통과(② 정답 번호 변동 0건 · ④ **143/144** · 경고 「34번 L1: 평균 46단어(목표 약 16단어)」는 옛 길이 기준이라 그대로)

### 아직 하지 않은 것 (숨기지 않고 적어 둠)
- 학생이 실제로 푼 결과는 없음(풀이꾼 · 감사꾼 · 교정꾼 · 고침꾼은 같은 종류의 모델)
- 34번 레벨1이 33번 레벨1과 짜임이 아주 닮음(정답 구의 길이만 다름). 34번다운 「긴 구 · 넓은 말」은 레벨2 이상에서 살릴 것
- 32번 L2의 확신 4 · 31번 L2의 통과선 걸침 · 바탕의 관사 탈(32번 L8 19번째) · 21번 L1의 C · D (DEFERRED 7번)
- 레벨1이 「맞음」이 아닌 나머지 약 열네 유형을 어떻게 할지는 아직 여쭙지 못했음

### 새 도구와 바뀐 문서
- `draft/chk74.py` · `draft/gen74.py` · `fin75.sh` · `docs358.py`(일회용) · `draft/brief_d74.txt` · `draft/brief_k74.txt` · `draft/d74_probe.py` · `sheets77/`(옛 판 시험) · `sheets78a/` · `sheets79/`(교정 기록) · `sheets80/`(마지막 판) · `bak78/` · `bak79/`(고치기 전 원고) · `draft/topics_used.txt`(150줄 — 33번 레벨1의 첫 문장을 더함)
- `LEVEL_GUIDE.md`(「34번 레벨1의 꼴」 새 절) · `README.md` · `DEFERRED.md` 7 · 13번 · `page/template.html`(34번 L1 칸 11~14/30)

### 다음에 시작할 때
- `git pull` 뒤 index.html 크기를 볼 것: **25,033,390바이트(`5c14ac4`, X69~X73까지)**이면 아직 → `PYTHONPATH=pending python3 build.py edits_X74a,edits_X74b out/index.html` → **''' + SIZE + '''바이트**(바탕에 X69~X73이 이미 들어 있으므로 X74만 얹음). 그보다 이전 판(`510e17c` 25,007,765바이트)이면 `edits_X73a,edits_X73b,edits_X74a,edits_X74b`를 차례로
- 다음은 **40번(요약문) 레벨1**: 먼저 지금 판(338 · 339번)을 마지막 문장(요약문) · 보기만 보여 주고 풀게 해 통과선(20/30 이하 · 확신 6 이하)을 넘는지 볼 것. 넘으면 다시 씀 → 그다음 레벨2 줄을 33번부터(칸마다 마지막 문장 시험, 통과선 16/30 이하 · 확신 3 이하) → 위쪽 한 칸 시험 → 레벨3 이후
- 한 칸 순서: (지금 판 시험) → 영어 원고(조건 대비 꼴 · only/always는 빈칸 문장과 글이 같은 것에 걸리게 · 초안이 `draft/lenpart.py`로 길이를 직접 맞춤) → 독립 풀이(`solve72.py`/`score72.py`) → 한글 원고(**오답 해설마다 only · always 문장을 «인용»해 막으라고 브리프에 적을 것**) → 교정꾼(번역 · 논리) → 고침꾼(열 문항씩) → 고친 것 확인 한 판 → `zjosa2.py --strict --fix` → `check_all.py`(④ 143) · `lenfix.py` · `regauge.py` · `zcheck31.py` → 영어를 바꿨으면 마지막 풀이 한 판 → 문서 → `pack.py` → 측정표 페이지 → 내보내기(GitHub 최신 다시 확인 · push)
- (학생용 시험지는 필요 없다고 하셨음 — 만들지도 묻지도 말 것. 특허 일은 다른 방)
- 새 방은 `LEVEL_GUIDE.md`부터 읽을 것. **새 방 첫 줄**: 「인계문서 358번까지 올렸습니다. 40번 레벨1을 봅니다.」
'''
h = h.rstrip('\n') + e358
wr(W + 'out/그루앙스_작업인계문서.md', h)

# ================= 측정표 페이지 템플릿 =================
t = rd(W + 'page/template.html')
t = rep(t, '· 34번 레벨1 (10-09, 인계문서 325번) ·',
        '· <b style="color:var(--fg)">34번 레벨1</b> (10-09, 인계문서 325번 → 10-12 인계문서 358번에서 <b>다시 씀</b> — 두 경우를 맞세운 일과·규칙 이야기, 네 문장 · 단문 100% · 정답 긴 구가 글에 그대로 나옴. 마지막 문장만 보여 주고 풀게 하면 11~14/30(다시 쓰기 전 판은 29/30)) ·')
def cell_repl(t, rowname, idx, old_num, new_html):
    i = t.index('<b>%s</b></td>' % rowname); j = t.index('</tr>', i)
    row = t[i:j]; cells = row.split('<td class="g">')
    assert old_num in cells[idx], (rowname, idx, cells[idx][:200])
    cells[idx] = new_html
    return t[:i] + '<td class="g">'.join(cells) + t[j:]
def cell(cls, num, sure):
    return ('<span class="%s" style="display:inline-block;min-width:52px;border-radius:4px;padding:3px 6px;font-weight:700">%s</span><br><small style="color:var(--muted);font-size:11.5px">확신 %s</small></td>' % (cls, num, sure))
t = cell_repl(t, '34번 빈칸(긴 구)', 1, '>30<', cell('v-ok', '11~14 *', '0'))
t = rep(t, '* 31번 레벨1(6~7/30) · 32번 레벨1(5~7/30) · 33번 레벨1(10~15/30)은 10월 11~12일 새 꼴',
        '* 31번 레벨1(6~7/30) · 32번 레벨1(5~7/30) · 33번 레벨1(10~15/30) · 34번 레벨1(11~14/30)은 10월 11~12일 새 꼴')
wr(W + 'page/template.html', t)
print('docs358 완료', SIZE)
