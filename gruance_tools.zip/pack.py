# -*- coding: utf-8 -*-
# 내보내기: 도구 묶음(zip) · index.html · 인계문서를 /home/claude/outputs/ 에 둠 (경로는 모두 절대 경로 — 315번)
#   python3 /home/claude/work/pack.py          (index.html도 함께)
#   python3 /home/claude/work/pack.py noindex  (문항을 고치지 않은 날)
import os, sys, zipfile, shutil
W = '/home/claude/work'; OUT = '/home/claude/outputs'
SKIP_DIR = {'out', '__pycache__'}; SKIP = {'gauge_run.err', 'gauge_run.log', '_local.html', 'desk.png', 'phone.png', 'shot.js'}
def main():
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT): os.remove(os.path.join(OUT, f))
    zp = os.path.join(OUT, 'gruance_tools.zip'); n = 0
    with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for root, dirs, files in os.walk(W):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIR)
            for f in sorted(files):
                if f in SKIP or f.endswith('.pyc'): continue
                full = os.path.join(root, f); z.write(full, os.path.relpath(full, W)); n += 1
    assert zipfile.ZipFile(zp).testzip() is None
    shutil.copy(os.path.join(W, 'out', '그루앙스_작업인계문서.md'), OUT)
    if 'noindex' not in sys.argv: shutil.copy(os.path.join(W, 'out', 'index.html'), OUT)
    for f in sorted(os.listdir(OUT)): print('%-28s %s바이트' % (f, format(os.path.getsize(os.path.join(OUT, f)), ',')))
    print('zip에 든 파일', n)
if __name__ == '__main__': main()
