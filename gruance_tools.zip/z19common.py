# -*- coding: utf-8 -*-
# 361번: 19번(심경 변화) 레벨1을 새 꼴로 다시 쓰기 — 공통 도우미
#   rw(n, 정답 자리, 지문, [보기 다섯 'a → b'], 해석, 처음 문장, 그 해석, 처음 풀이, 나중 문장, 그 해석, 나중 풀이, [보기 뜻 다섯 '뜻 → 뜻'], 낱말, [까닭 다섯])
#   해설: ① 처음 마음(문장 · 해석 · → 풀이) → ② 나중 마음 → ③ 그러니까 … → 정답 → 📌 낱말. «…»는 지문에 그대로 있는 말만, 서수 뒤 «…»는 그 문장 안의 말
import re, sys; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
W = ['첫째', '둘째', '셋째', '넷째']
def maker(E, T='19', LV='1'):
    def rw(n, ans, text, choices, ko, s1, k1, w1, s2, k2, w2, gl, words, cn):
        it = _tb[T][LV][n]
        assert it['answer'] == ans, (n, '정답 자리가 문항과 다름')
        assert len(choices) == 5 == len(set(choices)) == len(cn) == len(gl), n
        S = [s.strip() for s in re.split(r'(?<=[.?!])\s+', text)]
        assert len(S) == 4 and s1 in S and s2 in S and S.index(s1) < S.index(s2), (n, '처음 · 나중 문장')
        assert all(' → ' in g for g in gl), (n, '보기 뜻은 「뜻 → 뜻」')
        assert all('정답' not in c for c in cn) and '정답' not in w1 + w2, (n, '까닭에 정답이라는 말')
        a, b = choices[ans].split(' → ')
        assert re.search(r'\b' + a, s1.lower()) and re.search(r'\b' + b, s2.lower()), (n, '처음 · 나중 문장에 정답 낱말')
        def q(tx):
            for m in re.findall(r'«([^»]*)»', tx): assert m in text, (n, '지문에 없는 인용', m)
            for who, m in re.findall(r'(첫째|둘째|셋째|넷째) 문장[^«\n]{0,14}«([^»]*)»', tx):
                assert m in S[W.index(who)], (n, '문장 자리가 어긋남', who, m)
            return tx.replace('«', '"').replace('»', '"')
        ga, gb = gl[ans].split(' → ')
        walk = ('① 처음 마음은 주인공의 마음을 말하는 앞쪽 문장에서 찾아요. 이 글에서는 %s 문장이에요.\n"%s" (%s)\n→ %s\n'
                '② 나중 마음은 일이 일어난 뒤 주인공의 마음을 말하는 문장에서 찾아요. 이 글에서는 %s 문장이에요.\n"%s" (%s)\n→ %s\n'
                "③ 그러니까 주인공의 마음은 '%s'에서 '%s'(으)로 바뀌었어요. → 정답: '%s'\n📌 낱말: %s") % (
                W[S.index(s1)], s1, k1, q(w1), W[S.index(s2)], s2, k2, q(w2), ga, gb, choices[ans], words)
        last = gb[-1]; ro = '로' if (not ('가' <= last <= '힣')) or (ord(last) - 0xAC00) % 28 in (0, 8) else '으로'
        walk = walk.replace("'(으)로 바뀌었어요", "'%s 바뀌었어요" % ro)
        out = [("정답이에요! " if k == ans else "") + "'%s'(%s) — %s" % (choices[k], gl[k], q(cn[k])) for k in range(5)]
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(choices), 'ko': ko, 'walk': walk, 'cn': out}}
    return rw
