# 보기만 · 전체 풀이 점수: python3 score_any.py <폴더> <유형> <레벨>  (ans_last1 · ans_last2 · ans_blind 가운데 있는 것)
import sys, os; sys.path.insert(0,'/home/claude/work')
from lib import load
F,T,L=sys.argv[1:4]; _,tb,_=load()
key=[tb[T][L][n]['answer']+1 for n in range(30)]
for f in ('ans_last1','ans_last2','ans_blind'):
    p=os.path.join(F,f+'.txt')
    if not os.path.exists(p): continue
    R=[l.split() for l in open(p) if l.strip()]
    hit=[int(a[0]) for a in R if int(a[1])==key[int(a[0])-1]]
    conf=[int(a[0]) for a in R if a[2] in ('sure','high')]
    print('%-9s 맞힘 %2d/30 · 확신 %d (확신하고 맞힘 %d) · 맞힌 번호 %s'%(f[4:],len(hit),len(conf),len(set(hit)&set(conf)),hit if f!='ans_blind' else ''))
