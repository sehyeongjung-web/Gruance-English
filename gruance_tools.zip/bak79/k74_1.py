# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 한글 (d74.py I[0]~I[4]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[0] = dict(
 ko="지원이는 매일 밤 침대에서 잠깐 동안 책을 읽는다. 토요일 밤에는, 그녀의 아빠는 그녀가 손전등을 켜고 만화책을 읽게 해 준다. 학교 가기 전날 밤에는, 그는 그녀가 오직 새 책의 한 챕터만 읽게 해 준다. 그래서 학교 가기 전날 밤에, 아빠는 지원이에게 오직 ______만 하게 해 준다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on school nights, Dad only lets Jiwon»(그래서 학교 가기 전날 밤에, 아빠는 지원이에게 오직 …만 하게 해 준다) 뒤가 비어 있어요. 아빠가 오직 무엇만 하게 해 주는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On school nights, he only lets her read one chapter of her new book.»(학교 가기 전날 밤에는, 그는 그녀가 오직 새 책의 한 챕터만 읽게 해 준다.) 'read one chapter of her new book'(새 책의 한 챕터 읽기)이 그대로 나와요. 빈칸 문장과 같은 때의 이야기이고, 'only'(오직)도 같아요.",
 "3) 확인: 둘째 문장 «On Saturday nights, her dad lets her read comic books with a flashlight.»(토요일 밤에는, 그녀의 아빠는 그녀가 손전등을 켜고 만화책을 읽게 해 준다.) 'read comic books with a flashlight'(손전등을 켜고 만화책 읽기)는 'On Saturday nights'(토요일 밤에는)의 일이에요.",
 "4) 묶기: 학교 가기 전날 밤에 하게 해 주는 것 = 'read one chapter of her new book'(새 책의 한 챕터 읽기)."],
 traps="「손전등을 켜고 만화책 읽기」가 끌릴 수 있어요. 둘째 문장에 'read comic books with a flashlight'(손전등을 켜고 만화책 읽기)가 그대로 나오고, 빈칸 문장만 보면 밤에 하는 일로 자연스럽거든요. 하지만 그것은 'On Saturday nights'(토요일 밤에는)의 일이고, 셋째 문장은 학교 가기 전날 밤에는 오직 새 책의 한 챕터만 읽게 해 준다고 해요.",
 cn=[("엄마에게 짧은 시 읽어 주기", "엄마에게 시를 읽어 주는 이야기는 글에 나오지 않아요. 셋째 문장 «On school nights, he only lets her read one chapter of her new book.»에서 학교 가기 전날 밤에 아빠가 하게 해 주는 것은 오직 새 책의 한 챕터 읽기예요."),
     ("손전등을 켜고 만화책 읽기", "둘째 문장 «On Saturday nights, her dad lets her read comic books with a flashlight.»에서 손전등을 켜고 만화책을 읽는 것은 토요일 밤의 일이에요. 학교 가기 전날 밤에는 셋째 문장대로 'read one chapter of her new book'(새 책의 한 챕터 읽기)만 하게 해 줘요."),
     ("새 책의 한 챕터 읽기", "셋째 문장 «On school nights, he only lets her read one chapter of her new book.»이 근거예요. 학교 가기 전날 밤에 아빠는 지원이가 오직 새 책의 한 챕터만 읽게 해 주니, 빈칸 문장의 'only'(오직) 뒤에 들어갈 것도 이것이에요."),
     ("과학책 한 쪽 읽기", "과학책은 글에 나오지 않아요. 'read'(읽기)는 같지만, 셋째 문장에서 학교 가기 전날 밤에 읽게 해 주는 것은 'one chapter of her new book'(새 책의 한 챕터)이에요."),
     ("영어책 두 쪽 읽기", "영어책은 글에 나오지 않아요. 셋째 문장이 말하는 학교 가기 전날 밤의 일은 'read one chapter of her new book'(새 책의 한 챕터 읽기)이고, 'only'(오직)가 그것 하나만 남겨요.")])
K[1] = dict(
 ko="소민이는 일주일에 한 번 할머니와 함께 동네 도서관에 간다. 소민이는 항상 도서관 2층에서 책을 읽는다. 그녀의 할머니는 정문 근처의 소파에서 신문을 읽는다. 그래서 매주, 소민이는 항상 ______ 책을 읽는다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every week, Somin always reads»(그래서 매주, 소민이는 항상 … 책을 읽는다) 뒤가 비어 있어요. 소민이가 항상 어디에서 책을 읽는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Somin always reads on the second floor of the library.»(소민이는 항상 도서관 2층에서 책을 읽는다.) 'on the second floor of the library'(도서관 2층에서)가 그대로 나와요. 'always'(항상)도 빈칸 문장과 같으니, 소민이가 책을 읽는 곳은 도서관 2층이에요.",
 "3) 확인: 셋째 문장 «Her grandma reads the newspaper on the sofa near the front door.»(그녀의 할머니는 정문 근처의 소파에서 신문을 읽는다.) 'on the sofa near the front door'(정문 근처의 소파에서)는 'Her grandma'(그녀의 할머니)가 신문을 읽는 곳이에요. 소민이가 읽는 곳이 아니에요.",
 "4) 묶기: 소민이가 항상 책을 읽는 곳 = 'on the second floor of the library'(도서관 2층에서)."],
 traps="「정문 근처의 소파에서」가 끌릴 수 있어요. 셋째 문장에 'on the sofa near the front door'(정문 근처의 소파에서)가 그대로 나오고, 빈칸 문장만 보면 소파에서 책을 읽는다는 말도 자연스럽거든요. 하지만 그곳은 'Her grandma'(그녀의 할머니)가 신문을 읽는 곳이고, 둘째 문장은 소민이가 항상 도서관 2층에서 읽는다고 해요. 「정문 밖의 벤치에서」도 'front door'(정문)가 같아 끌리지만, 둘째 문장이 말하는 소민이의 자리는 도서관 2층이에요.",
 cn=[("도서관 2층에서", "둘째 문장 «Somin always reads on the second floor of the library.»이 근거예요. 소민이는 항상 도서관 2층에서 책을 읽으니, 빈칸 문장의 매주 책을 읽는 곳도 도서관 2층이에요."),
     ("정문 근처의 소파에서", "셋째 문장 «Her grandma reads the newspaper on the sofa near the front door.»에서 정문 근처의 소파는 할머니가 신문을 읽는 곳이에요. 소민이는 둘째 문장대로 항상 'on the second floor of the library'(도서관 2층에서) 읽어요."),
     ("도서관 뒤의 정원에서", "도서관 뒤의 정원은 글에 나오지 않아요. 둘째 문장에서 소민이가 항상 책을 읽는 곳은 'on the second floor of the library'(도서관 2층에서)예요."),
     ("도서관 옆의 공원에서", "공원은 글에 나오지 않아요. 둘째 문장이 말하는 소민이의 자리는 도서관 2층이고, 셋째 문장이 말하는 할머니의 자리는 정문 근처의 소파예요."),
     ("정문 밖의 벤치에서", "벤치는 글에 나오지 않아요. 셋째 문장에서 'front door'(정문) 근처에 있는 것은 할머니가 신문을 읽는 소파이고, 소민이는 둘째 문장대로 항상 도서관 2층에서 읽어요.")])
K[2] = dict(
 ko="매주 토요일, 도현이는 시장에 있는 할아버지의 채소 노점에 간다. 그의 누나 예슬이는 할아버지를 위해 돈을 세러 그곳에 간다. 그곳에서 도현이의 유일한 일은 감자를 종이봉투에 담는 것이다. 그래서 도현이는 오직 ______ 그 노점에 간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So Dohyun goes to the stand only»(그래서 도현이는 오직 … 그 노점에 간다) 뒤가 비어 있어요. 도현이가 무엇을 하러 노점에 가는지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Dohyun's only job there is to put the potatoes in paper bags.»(그곳에서 도현이의 유일한 일은 감자를 종이봉투에 담는 것이다.) 'to put the potatoes in paper bags'(감자를 종이봉투에 담으러)가 그대로 나와요. 'only job'(유일한 일)이 이것 하나이니, 도현이가 노점에 가는 목적도 감자를 종이봉투에 담는 것이에요.",
 "3) 확인: 둘째 문장 «His older sister Yeseul goes there to count the money for Grandpa.»(그의 누나 예슬이는 할아버지를 위해 돈을 세러 그곳에 간다.) 'to count the money for Grandpa'(할아버지를 위해 돈을 세러)는 누나 예슬이가 가는 목적이에요. 도현이의 일이 아니에요.",
 "4) 묶기: 도현이가 노점에 가는 목적 = 'to put the potatoes in paper bags'(감자를 종이봉투에 담으러)."],
 traps="「할아버지를 위해 돈을 세러」가 끌릴 수 있어요. 둘째 문장에 'to count the money for Grandpa'(할아버지를 위해 돈을 세러)가 그대로 나오고, 빈칸 문장만 보면 노점 일로 아주 자연스럽거든요. 하지만 그것은 누나 예슬이가 가는 목적이고, 셋째 문장은 도현이의 'only job'(유일한 일)이 감자를 종이봉투에 담는 것이라고 해요.",
 cn=[("감자를 종이봉투에 담으러", "셋째 문장 «Dohyun's only job there is to put the potatoes in paper bags.»이 근거예요. 그곳에서 도현이의 유일한 일이 감자를 종이봉투에 담는 것이니, 도현이가 노점에 가는 목적도 오직 이것이에요."),
     ("할아버지를 위해 돈을 세러", "둘째 문장 «His older sister Yeseul goes there to count the money for Grandpa.»에서 돈을 세러 가는 사람은 누나 예슬이에요. 도현이의 유일한 일은 셋째 문장대로 감자를 종이봉투에 담는 것이에요."),
     ("무거운 사과 상자를 나르러", "사과 상자를 나르는 이야기는 글에 나오지 않아요. 셋째 문장 «Dohyun's only job there is to put the potatoes in paper bags.»에서 도현이의 유일한 일은 감자를 종이봉투에 담는 것이에요."),
     ("이웃들에게 싱싱한 옥수수를 팔러", "옥수수를 판다는 이야기는 글에 나오지 않아요. 셋째 문장이 말하는 도현이의 'only job'(유일한 일)은 감자를 종이봉투에 담는 것이에요."),
     ("당근을 찬물에 씻으러", "당근은 글에 나오지 않아요. 셋째 문장에서 도현이의 유일한 일은 'potatoes'(감자)를 'paper bags'(종이봉투)에 담는 것이에요.")])
K[3] = dict(
 ko="민우는 자유 시간에 공 세 개로 저글링하는 법을 배우고 있다. 평일에는, 그는 오직 침대 위로 공 두 개를 던지는 것으로만 연습한다. 주말에는, 그는 마당에서 삼촌을 지켜보는 것으로 새 묘기를 배운다. 그래서 평일에, 민우는 오직 ______만 연습한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on weekdays, Minu practices only by»(그래서 평일에, 민우는 오직 …만 연습한다) 뒤가 비어 있어요. 평일에 민우가 무엇을 하는 것으로 연습하는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On weekdays, he practices only by throwing two balls over his bed.»(평일에는, 그는 오직 침대 위로 공 두 개를 던지는 것으로만 연습한다.) 'throwing two balls over his bed'(침대 위로 공 두 개를 던지는 것으로)가 그대로 나와요. 빈칸 문장과 같은 평일의 이야기이고, 'only by'(오직 …으로만)도 같아요.",
 "3) 확인: 셋째 문장 «On weekends, he learns new tricks by watching his uncle in the yard.»(주말에는, 그는 마당에서 삼촌을 지켜보는 것으로 새 묘기를 배운다.) 'watching his uncle in the yard'(마당에서 삼촌을 지켜보는 것으로)는 'On weekends'(주말에는)의 일이에요. 평일의 연습 방법이 아니에요.",
 "4) 묶기: 평일에 민우가 연습하는 방법 = 'throwing two balls over his bed'(침대 위로 공 두 개를 던지는 것으로)."],
 traps="「마당에서 삼촌을 지켜보는 것으로」가 끌릴 수 있어요. 셋째 문장에 'watching his uncle in the yard'(마당에서 삼촌을 지켜보는 것으로)가 그대로 나오고, 빈칸 문장만 보면 저글링을 익히는 방법으로 자연스럽거든요. 하지만 그것은 'On weekends'(주말에는)의 일이고, 둘째 문장은 평일에 민우가 오직 침대 위로 공 두 개를 던지는 것으로만 연습한다고 해요.",
 cn=[("휴대폰으로 짧은 영상을 보는 것으로", "휴대폰 영상은 글에 나오지 않아요. 둘째 문장 «On weekdays, he practices only by throwing two balls over his bed.»에서 평일에 민우가 연습하는 방법은 오직 침대 위로 공 두 개를 던지는 것이에요."),
     ("침대 위로 공 두 개를 던지는 것으로", "둘째 문장 «On weekdays, he practices only by throwing two balls over his bed.»이 근거예요. 평일에 민우는 오직 침대 위로 공 두 개를 던지는 것으로만 연습하니, 빈칸 문장의 평일 연습 방법도 이것이에요."),
     ("마당에서 삼촌을 지켜보는 것으로", "셋째 문장 «On weekends, he learns new tricks by watching his uncle in the yard.»에서 삼촌을 지켜보는 것은 주말에 새 묘기를 배우는 방법이에요. 평일에는 둘째 문장대로 오직 침대 위로 공 두 개를 던지는 것으로만 연습해요."),
     ("복도에서 부드러운 양말 세 개를 쓰는 것으로", "양말은 글에 나오지 않아요. 첫째 문장에서 민우가 배우는 것은 공 세 개로 하는 저글링이고, 둘째 문장에서 평일에 연습할 때 던지는 것은 'two balls'(공 두 개)예요."),
     ("받은 횟수를 소리 내어 세는 것으로", "횟수를 센다는 이야기는 글에 나오지 않아요. 둘째 문장이 말하는 평일의 연습 방법은 'throwing two balls over his bed'(침대 위로 공 두 개를 던지는 것으로)예요.")])
K[4] = dict(
 ko="매주 토요일, 엄마는 유진이와 그녀의 남동생 태오를 위해 도시락을 싼다. 유진이의 도시락에는 항상 주먹밥 두 개와 닭고기 조금이 들어 있다. 태오의 도시락에는 항상 치즈빵 조금과 오렌지 한 개가 들어 있다. 그래서 토요일마다, 유진이의 도시락에는 항상 ______이(가) 들어 있다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Saturdays, Yujin's lunch box always has»(그래서 토요일마다, 유진이의 도시락에는 항상 …이(가) 들어 있다) 뒤가 비어 있어요. 유진이의 도시락에 무엇이 들어 있는지를 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Yujin's lunch box always has two rice balls and some chicken.»(유진이의 도시락에는 항상 주먹밥 두 개와 닭고기 조금이 들어 있다.) 'two rice balls and some chicken'(주먹밥 두 개와 닭고기 조금)이 그대로 나와요. 빈칸 문장과 같은 유진이의 도시락 이야기이고, 'always'(항상)도 같아요.",
 "3) 확인: 셋째 문장 «Taeo's lunch box always has some cheese bread and an orange.»(태오의 도시락에는 항상 치즈빵 조금과 오렌지 한 개가 들어 있다.) 'some cheese bread and an orange'(치즈빵 조금과 오렌지 한 개)는 남동생 태오의 도시락에 든 것이에요. 유진이의 도시락 이야기가 아니에요.",
 "4) 묶기: 토요일마다 유진이의 도시락에 든 것 = 'two rice balls and some chicken'(주먹밥 두 개와 닭고기 조금)."],
 traps="「치즈빵 조금과 오렌지 한 개」가 끌릴 수 있어요. 셋째 문장에 'some cheese bread and an orange'(치즈빵 조금과 오렌지 한 개)가 그대로 나오고 'always'(항상)도 같아서, 빈칸 문장만 보면 아주 자연스럽거든요. 하지만 그것은 남동생 태오의 도시락이고, 둘째 문장은 유진이의 도시락에 항상 주먹밥 두 개와 닭고기 조금이 들어 있다고 해요.",
 cn=[("햄 샌드위치 하나와 포도 조금", "햄 샌드위치는 글에 나오지 않아요. 둘째 문장 «Yujin's lunch box always has two rice balls and some chicken.»에서 유진이의 도시락에 항상 들어 있는 것은 주먹밥 두 개와 닭고기 조금이에요."),
     ("치즈빵 조금과 오렌지 한 개", "셋째 문장 «Taeo's lunch box always has some cheese bread and an orange.»에서 치즈빵과 오렌지는 남동생 태오의 도시락에 든 것이에요. 유진이의 도시락에는 둘째 문장대로 'two rice balls and some chicken'(주먹밥 두 개와 닭고기 조금)이 들어 있어요."),
     ("김밥 조금과 작은 사과 한 개", "김밥은 글에 나오지 않아요. 둘째 문장이 말하는 유진이의 도시락에 든 것은 주먹밥 두 개와 닭고기 조금이고, 셋째 문장이 말하는 태오의 도시락에 든 것은 치즈빵 조금과 오렌지 한 개예요."),
     ("주먹밥 두 개와 닭고기 조금", "둘째 문장 «Yujin's lunch box always has two rice balls and some chicken.»이 근거예요. 첫째 문장대로 엄마는 매주 토요일 도시락을 싸고, 유진이의 도시락에는 항상 주먹밥 두 개와 닭고기 조금이 들어 있으니, 토요일의 도시락에도 이것이 들어 있어요."),
     ("어묵과 우유 한 팩", "어묵과 우유는 글에 나오지 않아요. 둘째 문장에서 유진이의 도시락에 항상 들어 있는 것은 'two rice balls and some chicken'(주먹밥 두 개와 닭고기 조금)이에요.")])
