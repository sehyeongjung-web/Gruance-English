# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 한글 (d74.py I[20]~I[24]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[20] = dict(
 ko="민재의 사진 동아리는 매달 두 번, 일요일에 사진을 찍으러 나간다. 첫 번째 일요일에는, 회원들은 오직 붐비는 생선 시장에서만 사진을 찍는다. 세 번째 일요일에는, 그들은 오직 큰 꽃 정원에서만 사진을 찍는다. 그래서 첫 번째 일요일에, 민재의 동아리는 오직 ______만 사진을 찍는다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on the first Sunday, Minjae's club takes pictures only»(그래서 첫 번째 일요일에, 민재의 동아리는 오직 …만 사진을 찍는다) 뒤가 비어 있어요. 사진을 찍는 곳을 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On the first Sunday, the members take pictures only at the busy fish market.»(첫 번째 일요일에는, 회원들은 오직 붐비는 생선 시장에서만 사진을 찍는다.) 'at the busy fish market'(붐비는 생선 시장에서)가 그대로 나와요. 빈칸 문장과 같은 첫 번째 일요일의 이야기예요.",
 "3) 확인: 셋째 문장 «On the third Sunday, they take pictures only in the big flower garden.»(세 번째 일요일에는, 그들은 오직 큰 꽃 정원에서만 사진을 찍는다.) 'in the big flower garden'(큰 꽃 정원에서)는 'On the third Sunday'(세 번째 일요일에는)의 일이에요. 둘째 문장의 'only'(오직)이 첫 번째 일요일의 장소를 생선 시장 하나로 정해요.",
 "4) 묶기: 첫 번째 일요일에 사진을 찍는 곳 = 'at the busy fish market'(붐비는 생선 시장에서)."],
 traps="「큰 꽃 정원에서」가 끌릴 수 있어요. 셋째 문장에 'in the big flower garden'(큰 꽃 정원에서)가 그대로 나오고, 빈칸 문장만 보면 꽃 정원도 자연스럽거든요. 하지만 그것은 'On the third Sunday'(세 번째 일요일에는)의 일이고, 둘째 문장은 첫 번째 일요일에는 오직 생선 시장에서만 찍는다고 해요.",
 cn=[("큰 꽃 정원에서", "셋째 문장 «On the third Sunday, they take pictures only in the big flower garden.»에서 큰 꽃 정원에서 사진을 찍는 것은 세 번째 일요일의 일이에요. 첫 번째 일요일에는 둘째 문장대로 'only at the busy fish market'(오직 붐비는 생선 시장에서만) 찍어요."),
     ("오래된 돌다리 위에서", "돌다리는 글에 나오지 않아요. 둘째 문장 «On the first Sunday, the members take pictures only at the busy fish market.»에서 첫 번째 일요일에 사진을 찍는 곳은 붐비는 생선 시장이고, 셋째 문장에서 세 번째 일요일에 찍는 곳은 'the big flower garden'(큰 꽃 정원)이에요."),
     ("조용한 강변 길을 따라서", "강변 길은 글에 나오지 않아요. 둘째 문장 «On the first Sunday, the members take pictures only at the busy fish market.»에서 첫 번째 일요일에 회원들은 오직 붐비는 생선 시장에서만 사진을 찍어요."),
     ("작은 기차역에서", "기차역은 글에 나오지 않아요. 첫째 문장에서 동아리는 매달 두 번, 일요일에 사진을 찍으러 나가고, 둘째 문장 «On the first Sunday, the members take pictures only at the busy fish market.»에서 그 가운데 첫 번째 일요일에 찍는 곳은 붐비는 생선 시장이에요."),
     ("붐비는 생선 시장에서", "둘째 문장 «On the first Sunday, the members take pictures only at the busy fish market.»이 근거예요. 첫 번째 일요일에 회원들은 오직 붐비는 생선 시장에서만 사진을 찍으니, 빈칸 문장의 첫 번째 일요일에도 사진을 찍는 곳은 붐비는 생선 시장이에요.")])
K[21] = dict(
 ko="주말마다, 소희는 집 부엌에서 아빠와 함께 쿠키를 굽는다. 토요일마다, 그녀는 항상 쿠키마다 견과 한 알을 올려서 그것들을 장식한다. 일요일마다, 그녀는 항상 분홍색 크림으로 웃는 얼굴을 그려서 그것들을 장식한다. 그래서 일요일마다, 소희는 항상 ______ 쿠키를 장식한다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on Sundays, Sohee always decorates the cookies by»(그래서 일요일마다, 소희는 항상 … 쿠키를 장식한다) 뒤가 비어 있어요. 장식하는 방법을 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On Sundays, she always decorates them by drawing smiles with pink cream.»(일요일마다, 그녀는 항상 분홍색 크림으로 웃는 얼굴을 그려서 그것들을 장식한다.) 'drawing smiles with pink cream'(분홍색 크림으로 웃는 얼굴을 그려서)가 그대로 나와요. 빈칸 문장과 같은 일요일의 이야기예요.",
 "3) 확인: 둘째 문장 «On Saturdays, she always decorates them by putting a nut on each cookie.»(토요일마다, 그녀는 항상 쿠키마다 견과 한 알을 올려서 그것들을 장식한다.) 'putting a nut on each cookie'(쿠키마다 견과 한 알을 올려서)는 'On Saturdays'(토요일마다)의 방법이에요. 두 문장의 'always'(항상)은 각자 그 요일에만 걸려요.",
 "4) 묶기: 일요일의 장식 방법 = 'drawing smiles with pink cream'(분홍색 크림으로 웃는 얼굴을 그려서)."],
 traps="「쿠키마다 견과 한 알을 올려서」가 끌릴 수 있어요. 둘째 문장에 'putting a nut on each cookie'(쿠키마다 견과 한 알을 올려서)가 그대로 나오고, 'always'(항상)까지 붙어 있어서 늘 하는 장식처럼 보이거든요. 하지만 그것은 'On Saturdays'(토요일마다)의 일이고, 셋째 문장은 일요일마다 크림으로 웃는 얼굴을 그려서 장식한다고 해요.",
 cn=[("쿠키마다 견과 한 알을 올려서", "둘째 문장 «On Saturdays, she always decorates them by putting a nut on each cookie.»에서 쿠키마다 견과 한 알을 올리는 것은 토요일의 장식 방법이에요. 일요일에는 셋째 문장대로 'drawing smiles with pink cream'(분홍색 크림으로 웃는 얼굴을 그려서) 장식해요."),
     ("하얀 설탕으로 덮어서", "하얀 설탕은 글에 나오지 않아요. 셋째 문장 «On Sundays, she always decorates them by drawing smiles with pink cream.»에서 일요일에 소희는 분홍색 크림으로 웃는 얼굴을 그려서 쿠키를 장식하고, 둘째 문장에서 토요일에는 쿠키마다 견과 한 알을 올려서 장식해요."),
     ("위에 알록달록한 사탕을 얹어서", "사탕은 글에 나오지 않아요. 셋째 문장 «On Sundays, she always decorates them by drawing smiles with pink cream.»에서 일요일마다 소희는 항상 분홍색 크림으로 웃는 얼굴을 그려서 쿠키를 장식해요."),
     ("초콜릿으로 짧은 낱말을 써서", "초콜릿은 글에 나오지 않아요. 셋째 문장 «On Sundays, she always decorates them by drawing smiles with pink cream.»에서 일요일에 소희가 크림으로 그리는 것은 낱말이 아니라 'smiles'(웃는 얼굴)예요."),
     ("분홍색 크림으로 웃는 얼굴을 그려서", "셋째 문장 «On Sundays, she always decorates them by drawing smiles with pink cream.»이 근거예요. 일요일마다 소희는 항상 분홍색 크림으로 웃는 얼굴을 그려서 쿠키를 장식하니, 빈칸 문장의 일요일 장식 방법도 이것이에요.")])
K[22] = dict(
 ko="일요일마다, 가은과 그녀의 남동생 시우는 작은 마을로 할머니를 찾아간다. 할머니께 드리는 시우 자신의 선물은 항상 싱싱한 오렌지 한 봉지이다. 할머니께 드리는 가은 자신의 선물은 항상 노란 꽃 한 다발이다. 그래서 일요일마다, 할머니께 드리는 가은 자신의 선물은 ______이다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every Sunday, Gaeun's own gift for Grandma is»(그래서 일요일마다, 할머니께 드리는 가은 자신의 선물은 …이다) 뒤가 비어 있어요. 가은이 할머니께 드리는 자기 선물이 무엇인지를 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «Gaeun's own gift for Grandma is always a bunch of yellow flowers.»(할머니께 드리는 가은 자신의 선물은 항상 노란 꽃 한 다발이다.) 'a bunch of yellow flowers'(노란 꽃 한 다발)이 그대로 나와요. 빈칸 문장과 같은 가은의 선물 이야기이니, 가은 자신의 선물은 노란 꽃 한 다발이에요.",
 "3) 확인: 둘째 문장 «Siu's own gift for Grandma is always a bag of fresh oranges.»(할머니께 드리는 시우 자신의 선물은 항상 싱싱한 오렌지 한 봉지이다.) 'a bag of fresh oranges'(싱싱한 오렌지 한 봉지)는 시우의 선물이에요. 'own'(자신의)이 선물을 사람마다 따로 나누니, 오렌지는 가은의 선물이 아니에요.",
 "4) 묶기: 일요일마다 할머니께 드리는 가은 자신의 선물 = 'a bunch of yellow flowers'(노란 꽃 한 다발)."],
 traps="「싱싱한 오렌지 한 봉지」가 끌릴 수 있어요. 둘째 문장에 'a bag of fresh oranges'(싱싱한 오렌지 한 봉지)가 그대로 나오고, 빈칸 문장만 보면 할머니께 드리는 선물로 아주 자연스럽거든요. 하지만 그것은 «Siu's own gift for Grandma»(할머니께 드리는 시우 자신의 선물)이고, 셋째 문장은 가은 자신의 선물이 'always'(항상) 노란 꽃 한 다발이라고 해요.",
 cn=[("싱싱한 오렌지 한 봉지", "둘째 문장 «Siu's own gift for Grandma is always a bag of fresh oranges.»에서 싱싱한 오렌지 한 봉지는 시우 자신의 선물이에요. 가은 자신의 선물은 셋째 문장대로 'a bunch of yellow flowers'(노란 꽃 한 다발)예요."),
     ("딸기잼 한 병", "딸기잼은 글에 나오지 않아요. 셋째 문장 «Gaeun's own gift for Grandma is always a bunch of yellow flowers.»에서 가은 자신의 선물은 항상 노란 꽃 한 다발이고, 둘째 문장에서 시우 자신의 선물은 싱싱한 오렌지 한 봉지예요."),
     ("노란 꽃 한 다발", "셋째 문장 «Gaeun's own gift for Grandma is always a bunch of yellow flowers.»이 근거예요. 할머니께 드리는 가은 자신의 선물은 항상 노란 꽃 한 다발이니, 빈칸 문장의 일요일 선물도 노란 꽃 한 다발이에요."),
     ("달콤한 떡 한 상자", "떡은 글에 나오지 않아요. 셋째 문장 «Gaeun's own gift for Grandma is always a bunch of yellow flowers.»에서 가은 자신의 선물은 항상 노란 꽃 한 다발이에요."),
     ("청포도 한 바구니", "청포도는 글에 나오지 않아요. 둘째 문장에 'a bag of fresh oranges'(싱싱한 오렌지 한 봉지)가 나오지만, 그것은 시우 자신의 선물이에요. 가은 자신의 선물은 셋째 문장대로 'a bunch of yellow flowers'(노란 꽃 한 다발)예요.")])
K[23] = dict(
 ko="준서네 집 근처의 스케이트장에는 특별한 주말 규칙이 두 가지 있다. 스케이트를 타는 사람들은 오직 토요일에만 얼음판을 돌며 서로 경주할 수 있다. 스케이트를 타는 사람들은 오직 일요일에만 친구들과 하키를 할 수 있다. 그래서 이 스케이트장에서, 스케이트를 타는 사람들은 오직 토요일에만 ______ 수 있다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So at this rink, skaters can»(그래서 이 스케이트장에서, 스케이트를 타는 사람들은 … 수 있다)와 «only on Saturdays.»(오직 토요일에만) 사이가 비어 있어요. 토요일에만 할 수 있는 일을 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Skaters can race each other around the ice only on Saturdays.»(스케이트를 타는 사람들은 오직 토요일에만 얼음판을 돌며 서로 경주할 수 있다.) 'race each other around the ice'(얼음판을 돌며 서로 경주할) 부분이 그대로 나와요. 'only on Saturdays'(오직 토요일에만)까지 빈칸 문장과 똑같아요.",
 "3) 확인: 셋째 문장 «Skaters can play hockey with their friends only on Sundays.»(스케이트를 타는 사람들은 오직 일요일에만 친구들과 하키를 할 수 있다.) 'play hockey with their friends'(친구들과 하키를 할) 일은 'only on Sundays'(오직 일요일에만) 할 수 있어서 토요일의 일이 아니에요.",
 "4) 묶기: 이 스케이트장에서 오직 토요일에만 할 수 있는 일 = 'race each other around the ice'(얼음판을 돌며 서로 경주할)."],
 traps="「친구들과 하키를 할」이 끌릴 수 있어요. 셋째 문장에 'play hockey with their friends'(친구들과 하키를 할) 부분이 그대로 나오고, 빈칸 문장만 보면 스케이트장의 하키도 자연스럽거든요. 하지만 하키는 'only on Sundays'(오직 일요일에만) 할 수 있고, 토요일의 일은 둘째 문장의 경주예요.",
 cn=[("얼음판을 돌며 서로 경주할", "둘째 문장 «Skaters can race each other around the ice only on Saturdays.»이 근거예요. 얼음판을 돌며 서로 경주하는 것은 오직 토요일에만 할 수 있으니, 빈칸 문장이 묻는 토요일에만 할 수 있는 일도 이것이에요."),
     ("친구들과 하키를 할", "셋째 문장 «Skaters can play hockey with their friends only on Sundays.»에서 친구들과 하키를 하는 것은 오직 일요일에만 할 수 있는 일이에요. 토요일에만 할 수 있는 일은 둘째 문장대로 'race each other around the ice'(얼음판을 돌며 서로 경주할) 일이에요."),
     ("휴대폰의 음악에 맞춰 스케이트를 탈", "음악에 맞춰 스케이트를 타는 것은 글에서 이야기하는 규칙이 아니에요. 첫째 문장 «The ice rink near Junseo's house has two special rules for weekends.»에서 주말 규칙은 두 가지이고, 둘째 문장이 말하는 토요일의 규칙은 얼음판을 돌며 서로 경주하는 것이에요."),
     ("가운데 원에서 점프를 해 볼", "점프는 글에 나오지 않아요. 둘째 문장 «Skaters can race each other around the ice only on Saturdays.»에서 오직 토요일에만 할 수 있는 일은 얼음판을 돌며 서로 경주하는 것이에요."),
     ("옆쪽 벤치에서 간식을 먹을", "간식은 글에 나오지 않아요. 둘째 문장 «Skaters can race each other around the ice only on Saturdays.»에서 토요일에만 할 수 있는 일은 얼음판을 돌며 서로 경주하는 것이고, 셋째 문장에서 일요일에만 할 수 있는 일은 친구들과 하키를 하는 것이에요.")])
K[24] = dict(
 ko="도윤은 자기 숙제 책상 위쪽 벽에 작은 화이트보드를 하나 두고 있다. 학교 가기 전날 밤에는, 그 보드는 오직 도윤이 수업마다 필요한 책을 기억하는 것만 도와준다. 토요일에는, 그 보드는 오직 도윤이 새 영어 단어를 복습하는 것만 도와준다. 그래서 학교 가기 전날 밤에는, 그 보드는 오직 도윤이 ______만 도와준다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on school nights, the board only helps Doyun»(그래서 학교 가기 전날 밤에는, 그 보드는 오직 도윤이 …만 도와준다) 뒤가 비어 있어요. 보드가 돕는 일을 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On school nights, the board only helps him remember the books for each class.»(학교 가기 전날 밤에는, 그 보드는 오직 도윤이 수업마다 필요한 책을 기억하는 것만 도와준다.) 'remember the books for each class'(수업마다 필요한 책을 기억하는 것)이 그대로 나와요. 빈칸 문장과 같은 학교 가기 전날 밤의 이야기예요.",
 "3) 확인: 셋째 문장 «On Saturdays, the board only helps him review his new English words.»(토요일에는, 그 보드는 오직 도윤이 새 영어 단어를 복습하는 것만 도와준다.) 'review his new English words'(새 영어 단어를 복습하는 것)은 'On Saturdays'(토요일에는)의 일이에요. 두 문장의 'only'(오직)은 각자 그날에만 걸려요.",
 "4) 묶기: 학교 가기 전날 밤에 돕는 일 = 'remember the books for each class'(수업마다 필요한 책을 기억하는 것)."],
 traps="「새 영어 단어를 복습하는 것」이 끌릴 수 있어요. 셋째 문장에 'review his new English words'(새 영어 단어를 복습하는 것)이 그대로 나오고, 빈칸 문장만 보면 단어 복습도 자연스럽거든요. 하지만 그것은 'On Saturdays'(토요일에는)의 일이고, 둘째 문장은 학교 가기 전날 밤에는 책을 기억하는 것만 돕는다고 해요.",
 cn=[("새 영어 단어를 복습하는 것", "셋째 문장 «On Saturdays, the board only helps him review his new English words.»에서 새 영어 단어를 복습하도록 돕는 것은 토요일의 일이에요. 학교 가기 전날 밤에는 둘째 문장대로 'remember the books for each class'(수업마다 필요한 책을 기억하는 것)만 도와줘요."),
     ("수업마다 필요한 책을 기억하는 것", "둘째 문장 «On school nights, the board only helps him remember the books for each class.»이 근거예요. 학교 가기 전날 밤에는 그 보드가 오직 도윤이 수업마다 필요한 책을 기억하는 것만 도와주니, 빈칸 문장의 학교 가기 전날 밤에도 이것이에요."),
     ("금요일까지 과학 보고서를 끝내는 것", "과학 보고서는 글에 나오지 않아요. 둘째 문장 «On school nights, the board only helps him remember the books for each class.»에서 학교 가기 전날 밤에 보드가 돕는 일은 오직 수업마다 필요한 책을 기억하는 것이에요."),
     ("수학 답을 한 번 더 확인하는 것", "수학 답은 글에 나오지 않아요. 첫째 문장 «Doyun keeps a small whiteboard on the wall above his homework desk.»에서 보드는 숙제 책상 위쪽 벽에 있지만, 둘째 문장에서 학교 가기 전날 밤에 그 보드가 돕는 일은 'remember the books for each class'(수업마다 필요한 책을 기억하는 것)이에요."),
     ("한 주의 공부 시간을 계획하는 것", "공부 시간을 계획한다는 이야기는 글에 나오지 않아요. 둘째 문장 «On school nights, the board only helps him remember the books for each class.»에서 학교 가기 전날 밤의 일은 책을 기억하는 것이고, 셋째 문장에서 토요일의 일은 'review his new English words'(새 영어 단어를 복습하는 것)이에요.")])
