# -*- coding: utf-8 -*-
# 34번(빈칸 — 긴 구) 레벨1 한글 (d74.py I[5]~I[9]). K[n] = dict(ko=해석, steps=[적용 네 줄], traps=끌리는 오답, cn=[(뜻, 까닭)×5])
K = {}
K[5] = dict(
 ko="마을 수영장에는 여름에 어린이들을 위한 규칙이 두 가지 있다. 열 살이 안 된 어린이들은 오직 부모와 함께 작은 수영장에서만 수영할 수 있다. 나이가 더 많은 어린이들은 가장자리에서 깊은 수영장으로 뛰어들 수 있다. 그래서 열 살이 안 된 어린이들은 오직 ______ 수 있다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So children under ten may only»(그래서 열 살이 안 된 어린이들은 오직 … 수 있다) 뒤가 비어 있어요. 그 어린이들이 무엇을 할 수 있는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Children under ten may only swim in the small pool with a parent.»(열 살이 안 된 어린이들은 오직 부모와 함께 작은 수영장에서만 수영할 수 있다.) 'swim in the small pool with a parent'(부모와 함께 작은 수영장에서 수영한다)가 그대로 나와요. 빈칸 문장과 같은 어린이들의 규칙이고 'may only'(오직 … 수 있다)도 같아요.",
 "3) 확인: 셋째 문장 «Older children may jump into the deep pool from the side.»(나이가 더 많은 어린이들은 가장자리에서 깊은 수영장으로 뛰어들 수 있다.) 이것은 'Older children'(나이가 더 많은 어린이들)의 규칙이에요. 둘째 문장의 'only'(오직)가 열 살이 안 된 어린이들의 일을 작은 수영장에서의 수영 하나로 정해요.",
 "4) 묶기: 열 살이 안 된 어린이들의 일 = 'swim in the small pool with a parent'(부모와 함께 작은 수영장에서 수영한다)."],
 traps="「가장자리에서 깊은 수영장으로 뛰어들」 수 있다는 보기가 끌릴 수 있어요. 셋째 문장에 그대로 나오고, 빈칸 문장만 보면 자연스럽거든요. 하지만 셋째 문장은 나이가 더 많은 어린이들의 규칙이고, 둘째 문장은 열 살이 안 된 어린이들의 일을 오직 작은 수영장에서의 수영으로 정해요. 「선생님과 함께 작은 수영장에서 수영할」도 끌리지만, 둘째 문장에서 함께하는 사람은 'a parent'(부모)예요.",
 cn=[("부모와 함께 작은 수영장에서 수영할", "둘째 문장 «Children under ten may only swim in the small pool with a parent.»이 근거예요. 열 살이 안 된 어린이들은 오직 부모와 함께 작은 수영장에서만 수영할 수 있고, 빈칸 문장도 같은 열 살이 안 된 어린이들의 규칙이에요."),
     ("가장자리에서 깊은 수영장으로 뛰어들", "셋째 문장 «Older children may jump into the deep pool from the side.»에서 깊은 수영장으로 뛰어들 수 있는 것은 나이가 더 많은 어린이들이에요. 열 살이 안 된 어린이들은 둘째 문장대로 오직 부모와 함께 'the small pool'(작은 수영장)에서만 수영할 수 있어요."),
     ("선생님과 함께 작은 수영장에서 수영할", "선생님은 글에 나오지 않아요. 둘째 문장 «Children under ten may only swim in the small pool with a parent.»에서 열 살이 안 된 어린이들과 함께 수영하는 사람은 'a parent'(부모)예요."),
     ("30분 동안 물에서 놀", "30분 동안 논다는 이야기는 글에 나오지 않아요. 둘째 문장 «Children under ten may only swim in the small pool with a parent.»에서 열 살이 안 된 어린이들의 규칙은 오직 부모와 함께 작은 수영장에서 수영하는 것이에요."),
     ("구명조끼를 입고 물 미끄럼틀을 탈", "물 미끄럼틀과 구명조끼는 글에 나오지 않아요. 첫째 문장 «The town pool has two rules for children in the summer.»에서 규칙은 두 가지이고, 열 살이 안 된 어린이들의 규칙은 «swim in the small pool with a parent»(부모와 함께 작은 수영장에서 수영한다)예요.")])
K[6] = dict(
 ko="서준과 그의 엄마는 그들의 아파트 근처의 길고양이 세 마리를 돌본다. 매일 저녁, 서준은 오직 고양이들에게 깨끗한 물을 주러 밖에 나간다. 그의 엄마는 그릇에 마른 사료를 담으러 아침에 나간다. 그래서 매일 저녁, 서준은 오직 ______ 밖에 나간다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So every evening, Seojun goes outside only»(그래서 매일 저녁, 서준은 오직 … 밖에 나간다) 뒤가 비어 있어요. 매일 저녁 서준이 무엇을 하러 밖에 나가는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «Every evening, Seojun goes outside only to give the cats fresh water.»(매일 저녁, 서준은 오직 고양이들에게 깨끗한 물을 주러 밖에 나간다.) 'to give the cats fresh water'(고양이들에게 깨끗한 물을 주러)가 그대로 나와요. 빈칸 문장과 같은 매일 저녁, 같은 서준의 이야기이고 'only'(오직)까지 똑같아요.",
 "3) 확인: 셋째 문장 «His mom goes out in the morning to put dry food in a bowl.»(그의 엄마는 그릇에 마른 사료를 담으러 아침에 나간다.) 'to put dry food in a bowl'(그릇에 마른 사료를 담으러)은 'His mom'(그의 엄마)이 'in the morning'(아침에) 나가는 목적이에요. 둘째 문장의 'only'(오직)가 서준의 저녁 목적을 깨끗한 물 하나로 정해요.",
 "4) 묶기: 매일 저녁 서준이 밖에 나가는 목적 = 'to give the cats fresh water'(고양이들에게 깨끗한 물을 주러)."],
 traps="「그릇에 마른 사료를 담으러」가 끌릴 수 있어요. 셋째 문장에 그대로 나오고, 빈칸 문장만 보면 고양이에게 사료를 주러 나간다는 말이 아주 자연스럽거든요. 하지만 그것은 엄마가 아침에 나가는 목적이고, 둘째 문장은 서준이 매일 저녁 'only'(오직) 고양이들에게 깨끗한 물을 주러 나간다고 해요.",
 cn=[("그릇에 마른 사료를 담으러", "셋째 문장 «His mom goes out in the morning to put dry food in a bowl.»에서 그릇에 마른 사료를 담으러 나가는 사람은 엄마이고, 그때는 아침이에요. 매일 저녁 서준은 둘째 문장대로 'only to give the cats fresh water'(오직 고양이들에게 깨끗한 물을 주러) 밖에 나가요."),
     ("빗으로 고양이들의 털을 빗겨 주러", "빗질 이야기는 글에 나오지 않아요. 둘째 문장 «Every evening, Seojun goes outside only to give the cats fresh water.»에서 매일 저녁 서준이 밖에 나가는 목적은 오직 고양이들에게 깨끗한 물을 주는 것이에요."),
     ("고양이들에게 깨끗한 물을 주러", "둘째 문장 «Every evening, Seojun goes outside only to give the cats fresh water.»이 근거예요. 매일 저녁 서준은 오직 고양이들에게 깨끗한 물을 주러 밖에 나가니, 빈칸 문장의 매일 저녁 나가는 목적도 이것 하나예요."),
     ("잠시 고양이들과 놀러", "고양이들과 논다는 이야기는 글에 나오지 않아요. 둘째 문장 «Every evening, Seojun goes outside only to give the cats fresh water.»에서 매일 저녁 서준이 밖에 나가는 목적은 오직 고양이들에게 깨끗한 물을 주는 것이에요."),
     ("작은 고양이들의 사진을 찍으러", "사진 이야기는 글에 나오지 않아요. 첫째 문장 «Seojun and his mom take care of three street cats near their apartment.»에서 두 사람은 길고양이들을 돌보고, 매일 저녁 서준이 나가는 목적은 둘째 문장대로 오직 고양이들에게 깨끗한 물을 주는 것이에요.")])
K[7] = dict(
 ko="하준은 매일 아침 10분 동안 쉬운 스트레칭을 몇 가지 한다. 평일에는, 짧은 영상이 오직 그가 목과 어깨를 스트레칭하는 것만 도와준다. 토요일마다, 그의 누나는 그가 다리를 곧게 편 채 발가락을 만지는 것을 도와준다. 그래서 평일에, 그 짧은 영상은 오직 하준이 ______ 도와준다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on weekdays, the short video only helps Hajun»(그래서 평일에, 그 짧은 영상은 오직 하준이 … 도와준다) 뒤가 비어 있어요. 평일 영상이 어떤 스트레칭을 돕는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «On weekdays, a short video only helps him stretch his neck and his shoulders.»(평일에는, 짧은 영상이 오직 그가 목과 어깨를 스트레칭하는 것만 도와준다.) 'stretch his neck and his shoulders'(목과 어깨를 스트레칭한다)가 그대로 나와요. 빈칸 문장과 같은 평일의 이야기이고 'only helps'(오직 … 도와준다)도 같아요.",
 "3) 확인: 셋째 문장 «On Saturdays, his older sister helps him touch his toes with straight legs.»(토요일마다, 그의 누나는 그가 다리를 곧게 편 채 발가락을 만지는 것을 도와준다.) 이것은 'On Saturdays'(토요일마다) 누나가 도와주는 일이에요. 둘째 문장의 'only'(오직)가 평일 영상이 돕는 일을 목과 어깨 스트레칭 하나로 정해요.",
 "4) 묶기: 평일 영상이 돕는 일 = 'stretch his neck and his shoulders'(목과 어깨를 스트레칭한다)."],
 traps="「다리를 곧게 편 채 발가락을 만지는 것을」이 끌릴 수 있어요. 셋째 문장에 그대로 나오고, 빈칸 문장만 보면 자연스럽거든요. 하지만 그것은 토요일에 누나가 돕는 일이고, 둘째 문장은 평일 영상이 오직 목과 어깨 스트레칭만 돕는다고 해요. 「무릎과 발목을 스트레칭하는 것을」도 'stretch'(스트레칭한다)가 같아 끌리지만, 둘째 문장의 몸 부분은 목과 어깨예요.",
 cn=[("다리를 곧게 편 채 발가락을 만지는 것을", "셋째 문장 «On Saturdays, his older sister helps him touch his toes with straight legs.»에서 다리를 곧게 편 채 발가락을 만지는 것은 토요일마다 누나가 도와주는 일이에요. 평일에 짧은 영상이 돕는 것은 둘째 문장대로 'only'(오직) 목과 어깨 스트레칭이에요."),
     ("고양이처럼 천천히 등을 구부리는 것을", "등을 구부리는 스트레칭은 글에 나오지 않아요. 둘째 문장 «On weekdays, a short video only helps him stretch his neck and his shoulders.»에서 평일에 짧은 영상이 돕는 것은 오직 목과 어깨를 스트레칭하는 것이에요."),
     ("목과 어깨를 스트레칭하는 것을", "둘째 문장 «On weekdays, a short video only helps him stretch his neck and his shoulders.»이 근거예요. 평일에 짧은 영상은 오직 하준이 목과 어깨를 스트레칭하는 것만 도와주니, 빈칸 문장의 평일 영상이 돕는 일도 이것이에요."),
     ("무릎과 발목을 스트레칭하는 것을", "무릎과 발목은 글에 나오지 않아요. 둘째 문장에서 평일에 영상이 돕는 스트레칭은 «stretch his neck and his shoulders»(목과 어깨를 스트레칭한다)예요. 'stretch'(스트레칭한다)라는 말은 같지만 몸의 부분이 달라요."),
     ("몸을 왼쪽과 오른쪽으로 돌리는 것을", "몸을 돌리는 스트레칭은 글에 나오지 않아요. 둘째 문장 «On weekdays, a short video only helps him stretch his neck and his shoulders.»에서 평일에 짧은 영상이 돕는 것은 목과 어깨 스트레칭 하나예요.")])
K[8] = dict(
 ko="매주, 아라는 독서 동아리를 위해 짧은 시 한 편을 외운다. 집에서는, 그녀는 오직 자기 고양이에게 한 줄씩 읽어 주는 것으로만 그 시를 외운다. 버스에서는, 그녀는 휴대폰으로 자기 목소리를 듣는 것으로 그것을 외운다. 그래서 집에서, 아라는 오직 ______ 자기 시를 외운다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So at home, Ara learns her poem only by»(그래서 집에서, 아라는 오직 … 자기 시를 외운다) 뒤가 비어 있어요. 집에서 아라가 어떤 방법으로 시를 외우는지 물어요.",
 "2) 짝꿍 문장: 둘째 문장이에요. «At home, she learns the poem only by reading each line to her cat.»(집에서는, 그녀는 오직 자기 고양이에게 한 줄씩 읽어 주는 것으로만 그 시를 외운다.) 'reading each line to her cat'(자기 고양이에게 한 줄씩 읽어 주기)이 그대로 나와요. 빈칸 문장과 같은 집에서의 이야기이고 'only by'(오직 … 것으로만)까지 똑같아요.",
 "3) 확인: 셋째 문장 «On the bus, she learns it by listening to her voice on her phone.»(버스에서는, 그녀는 휴대폰으로 자기 목소리를 듣는 것으로 그것을 외운다.) 'listening to her voice on her phone'(휴대폰으로 자기 목소리를 듣기)은 'On the bus'(버스에서는) 쓰는 방법이에요. 둘째 문장의 'only'(오직)가 집에서의 방법을 고양이에게 읽어 주기 하나로 정해요.",
 "4) 묶기: 집에서 아라가 시를 외우는 방법 = 'reading each line to her cat'(자기 고양이에게 한 줄씩 읽어 주기)."],
 traps="「휴대폰으로 자기 목소리를 듣는 것으로」가 끌릴 수 있어요. 셋째 문장에 그대로 나오고, 빈칸 문장만 보면 시를 외우는 방법으로 자연스럽거든요. 하지만 그것은 'On the bus'(버스에서는) 쓰는 방법이고, 둘째 문장은 집에서는 'only'(오직) 고양이에게 한 줄씩 읽어 주는 것으로만 외운다고 해요.",
 cn=[("휴대폰으로 자기 목소리를 듣는 것으로", "셋째 문장 «On the bus, she learns it by listening to her voice on her phone.»에서 휴대폰으로 자기 목소리를 듣는 것은 버스에서 시를 외우는 방법이에요. 집에서는 둘째 문장대로 'only'(오직) 고양이에게 한 줄씩 읽어 주는 것으로만 외워요."),
     ("자기 공책에 그 시를 쓰는 것으로", "공책에 쓴다는 이야기는 글에 나오지 않아요. 둘째 문장 «At home, she learns the poem only by reading each line to her cat.»에서 집에서 아라가 시를 외우는 방법은 오직 고양이에게 한 줄씩 읽어 주는 것이에요."),
     ("그 줄들을 노래처럼 부르는 것으로", "노래처럼 부른다는 이야기는 글에 나오지 않아요. 둘째 문장 «At home, she learns the poem only by reading each line to her cat.»에서 집에서 아라는 줄들을 노래처럼 부르지 않고 고양이에게 한 줄씩 읽어 줘요."),
     ("줄마다 그림을 하나씩 그리는 것으로", "그림 이야기는 글에 나오지 않아요. 둘째 문장 «At home, she learns the poem only by reading each line to her cat.»에서 집에서 아라가 줄마다 하는 일은 고양이에게 읽어 주는 것 하나예요."),
     ("자기 고양이에게 한 줄씩 읽어 주는 것으로", "둘째 문장 «At home, she learns the poem only by reading each line to her cat.»이 근거예요. 집에서 아라는 오직 자기 고양이에게 한 줄씩 읽어 주는 것으로만 시를 외우니, 빈칸 문장의 집에서 외우는 방법도 이것 하나예요.")])
K[9] = dict(
 ko="여름에는 토요일 밤마다, 연우는 아빠와 함께 작은 텐트에서 잔다. 맑은 밤에는, 그들은 집 뒤의 마당에 텐트를 세운다. 비 오는 밤에는, 그들은 항상 거실 바닥에 그것을 세운다. 그래서 비 오는 밤에, 텐트는 항상 ______ 서 있다.",
 steps=[
 "1) 빈칸 문장: 넷째 문장이에요. «So on rainy nights, the tent always stands»(그래서 비 오는 밤에, 텐트는 항상 … 서 있다) 뒤가 비어 있어요. 비 오는 밤에 텐트가 어디에 서 있는지 물어요.",
 "2) 짝꿍 문장: 셋째 문장이에요. «On rainy nights, they always put it on the floor of the living room.»(비 오는 밤에는, 그들은 항상 거실 바닥에 그것을 세운다.) 'on the floor of the living room'(거실 바닥에)이 그대로 나와요. 'it'(그것)은 첫째 문장의 텐트이고, 빈칸 문장과 같은 비 오는 밤의 이야기이며 'always'(항상)까지 똑같아요.",
 "3) 확인: 둘째 문장 «On clear nights, they put the tent in the yard behind the house.»(맑은 밤에는, 그들은 집 뒤의 마당에 텐트를 세운다.) 'in the yard behind the house'(집 뒤의 마당에)는 'On clear nights'(맑은 밤에는)의 자리예요. 셋째 문장의 'always'(항상)가 비 오는 밤의 자리를 거실 바닥 하나로 정해요.",
 "4) 묶기: 비 오는 밤에 텐트가 서 있는 곳 = 'on the floor of the living room'(거실 바닥에)."],
 traps="「집 뒤의 마당에」가 끌릴 수 있어요. 둘째 문장에 'in the yard behind the house'(집 뒤의 마당에)가 그대로 나오고, 빈칸 문장만 보면 텐트가 서 있을 곳으로 아주 자연스럽거든요. 하지만 그것은 'On clear nights'(맑은 밤에는)의 자리이고, 셋째 문장은 비 오는 밤에는 'always'(항상) 거실 바닥에 텐트를 세운다고 해요.",
 cn=[("집 뒤의 마당에", "둘째 문장 «On clear nights, they put the tent in the yard behind the house.»에서 집 뒤의 마당에 텐트를 세우는 것은 맑은 밤의 일이에요. 비 오는 밤에는 셋째 문장대로 'always'(항상) 거실 바닥에 세워요."),
     ("차고 지붕 아래에", "차고는 글에 나오지 않아요. 셋째 문장 «On rainy nights, they always put it on the floor of the living room.»에서 비 오는 밤에 텐트를 세우는 곳은 항상 거실 바닥이에요."),
     ("연우의 침실 옆 복도에", "복도와 침실은 글에 나오지 않아요. 셋째 문장 «On rainy nights, they always put it on the floor of the living room.»에서 비 오는 밤의 텐트 자리는 거실 바닥이에요."),
     ("거실 바닥에", "셋째 문장 «On rainy nights, they always put it on the floor of the living room.»이 근거예요. 비 오는 밤에 연우와 아빠는 항상 텐트를 거실 바닥에 세우니, 빈칸 문장의 비 오는 밤 텐트 자리도 거실 바닥이에요."),
     ("계단 아래의 작은 방에", "계단 아래의 방은 글에 나오지 않아요. 첫째 문장 «Yeonwoo sleeps in a small tent with his dad»에 'small'(작은)이 나오지만 그것은 텐트를 꾸미는 말이에요. 비 오는 밤에는 셋째 문장대로 'always'(항상) 거실 바닥에 텐트를 세워요.")])
