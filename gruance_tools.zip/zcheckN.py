# -*- coding: utf-8 -*-
# 23번 레벨6~8 선택지 명사구화 — 자체 검사 (206번~)   python3 zcheckN.py 8
# 볼 것: 지문·정답 번호·해석·풀이 불변 / 선택지별 해설의 머리가 새 선택지와 글자까지 같음 / 해설 글(머리 뒤)은 한 글자도 안 바뀜
#        / why·how 따위로 시작하는 선택지가 남지 않음 / 해설 글에 옛 선택지에만 있던 영어 낱말이 남지 않음
import re, sys, collections; sys.path.insert(0, '.')
from lib import *
LV = sys.argv[1] if len(sys.argv) > 1 else '8'
s, tb, te = load('out/index.html'); s0, tb0, te0 = load()
PAT = r"^(정답입니다\. )?'(.*?)' \((.*?)\) — (.*)$"
ch = ans = same_ko = 0
for n in range(30):
    it = tb['23'][LV][n]; b0 = tb0['23'][LV][n]; ex = te['23'][LV][n]; e0 = te0['23'][LV][n]
    assert it['text'] == b0['text'] and it['answer'] == b0['answer'] and it.get('q') == b0.get('q'), (n, '지문·정답 번호')
    thick = '【이 문제에 적용】' in ex['walk']   # 해설을 두텁게 다시 쓴 문항(209번~)은 풀이·해설 글이 달라지는 것이 맞음 — 머리만 봄
    assert ex['ko'] == e0['ko'] and (thick or ex['walk'] == e0['walk']), (n, '해석·풀이가 바뀜')
    assert len(set(it['choices'])) == 5
    for k in range(5):
        m = re.match(PAT, ex['cn'][k], re.S); m0 = re.match(PAT, e0['cn'][k], re.S)
        assert m and m.group(2) == it['choices'][k], (n, k, '해설 머리가 선택지와 다름')
        assert bool(m.group(1)) == (k == it['answer']), (n, k)
        assert thick or m.group(4) == m0.group(4), (n, k, '해설 글이 바뀜')
        if it['choices'][k] != b0['choices'][k]:
            ch += 1; ans += (k == it['answer'])
            same_ko += (m.group(3) == m0.group(3))   # why → the reason처럼 우리말 해석이 그대로여도 되는 것
            gone = set(w.lower() for w in re.findall(r'[A-Za-z]{4,}', b0['choices'][k])) - set(w.lower() for w in re.findall(r'[A-Za-z]{4,}', it['choices'][k] + ' ' + it['text']))
            left = [w for w in re.findall(r'[A-Za-z]{4,}', m.group(4)) if w.lower() in gone]
            if left: print('!! 해설 글에 옛 선택지의 낱말이 남음: %d번째 %d — %s' % (n + 1, k + 1, left))
        else: assert thick or ex['cn'][k] == e0['cn'][k], (n, k, '안 바꾼 선택지의 해설이 바뀜')
c = collections.Counter(x.split()[0].lower() for it in tb['23'][LV] for x in it['choices'])
wh = {k: v for k, v in c.items() if k in ('why', 'how', 'what', 'when', 'which', 'where', 'who')}
print('레벨%s: 바꾼 선택지 %d / 150 (정답 문구 %d, 우리말 해석이 그대로인 것 %d) · 남은 why·how 꼴 %s' % (LV, ch, ans, same_ko, wh or 0))
print('첫 낱말:', c.most_common(8))
