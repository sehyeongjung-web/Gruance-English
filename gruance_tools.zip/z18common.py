# -*- coding: utf-8 -*-
# 360번: 18번(글의 목적) 레벨1을 새 꼴로 다시 쓰기 — 공통 도우미
#   rw(n, 정답 자리, 지문(편지 전체), [선택지 다섯], 해석, 목적 문장, 그 해석, 몇째(1~4, 본문 문장 기준), 풀이 ②, 낱말, [선택지별 까닭 다섯])
#   해설: ① 목적 문장 찾기(몇째 문장) → "문장" (해석) → ② 까닭과 곁가지 → ③ 그러니까 … → 📌 낱말. 말끝은 「~어요」
#   «…»는 편지에 그대로 있는 말만(빌드 때 확인 후 큰따옴표로 바꿈). 「첫째·둘째·셋째·넷째 문장」 바로 뒤의 «…»는 그 문장 안의 말이어야 함
import re, sys; sys.path.insert(0, '/home/claude/work')
from lib import load as _load
_tb = _load()[1]
ORD = {1: '첫째', 2: '둘째', 3: '셋째', 4: '넷째'}
LEAD = "① 편지를 쓴 목적은 부탁 · 질문 · 알림 · 초대 · 사과처럼 편지가 꼭 하고 싶은 말이 담긴 문장에서 찾아요. 이 편지에서는 %s 문장이에요."
def body_sents(text):
    parts = [p.strip() for p in text.split('\n\n')]
    assert len(parts) == 3, '편지는 「받는 이,」 / 본문 / 「끝맺음,\\n이름」 세 덩이'
    return [s.strip() for s in re.split(r'(?<=[.?!])\s+', parts[1])]
def maker(E, T='18', LV='1'):
    def rw(n, ans, text, choices, ko, purpose, purpose_ko, pos, why, words, cn):
        it = _tb[T][LV][n]
        assert it['answer'] == ans, (n, '정답 자리가 문항과 다름')
        assert len(choices) == 5 == len(set(choices)) == len(cn), n
        S = body_sents(text)
        assert len(S) == 4, (n, '본문 문장 수', len(S))
        assert S[pos - 1] == purpose, (n, '목적 문장의 자리', S[pos - 1])
        assert all('정답' not in c for c in cn) and '정답' not in why, (n, '까닭에 정답이라는 말')
        def q(tx):
            for m in re.findall(r'«([^»]*)»', tx): assert m in text, (n, '편지에 없는 인용', m)
            for who, m in re.findall(r'(첫째|둘째|셋째|넷째) 문장[^«\n]{0,14}«([^»]*)»', tx):
                assert m in S[['첫째', '둘째', '셋째', '넷째'].index(who)], (n, '문장 자리가 어긋남', who, m)
            return tx.replace('«', '"').replace('»', '"')
        walk = LEAD % ORD[pos] + '\n"%s" (%s)\n② %s\n③ 그러니까 이 편지는 \'%s\' 쓴 거예요.\n📌 낱말: %s' % (purpose, purpose_ko, q(why), choices[ans], words)
        out = [("정답이에요! " if k == ans else "") + "'%s' — %s" % (choices[k], q(cn[k])) for k in range(5)]
        assert (T, LV, n) not in E, (n, '같은 문항을 두 번 씀')
        E[(T, LV, n)] = {'passage_ok': True, 'ans_ok': True, 'rewrite': {'text': text, 'choices': list(choices), 'ko': ko, 'walk': walk, 'cn': out}}
    return rw
