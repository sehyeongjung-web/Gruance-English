# -*- coding: utf-8 -*-
# 40번 읽기: python3 show40.py 7 10 20
import sys, re; sys.path.insert(0, '.')
from lib import *
lv, a, b = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
s, tb, te = load()
for n in range(a, b):
    it = tb['40'][lv][n]; ex = te['40'][lv][n]
    print('=====', n + 1, 'ans', it['answer']); print(it['text'])
    for k, c in enumerate(it['choices']):
        m = re.match(r"(?:정답입니다\. )?'([^']*)'", ex['cn'][k]); print('   %s%d %s  | %s' % ('*' if k == it['answer'] else ' ', k, c, m.group(1) if m else ''))
