# -*- coding: utf-8 -*-
# 38-39번(문장 넣기) 레벨 기준으로 다시 쓸 때의 원고 도구 (327번)
#   ① 낱말 맞추기 검사 + 재기
#        PYTHONPATH=pending python3 z3839draft.py match edits_X60a 1 0 15 [문장 수=6]
#        python3 z3839draft.py match <원고 모듈이 있는 폴더>/draft60a 1 0 15      (원고 모듈: I[n] = (주어진 문장, [지문 다섯 문장], 답 자리 1~5))
#      - 주어진 문장과 앞·뒤 문장이 겹치는 낱말 수를 자리마다 세어, 「낱말만 맞추는 학생」이 고를 자리를 보여 줌
#      - 목표: 답 자리가 혼자 가장 많이 겹치는 문항 0 (선생님 결정 「나」 — 낱말 맞추기만으로는 안 풀리게)
#      - 「자리 규칙」 줄: 가리키는 말(this/that + 낱말)이 든 첫/둘째/마지막 문장의 바로 앞 자리가 답인 문항 수 — 어느 것도 절반을 넘지 않게
#   ② 독립 검사에 줄 문제지 (지어진 out/index.html에서 뽑음)
#        python3 z3839draft.py sheets <레벨> <처음> <끝> <폴더> <꼬리표>
#      - <꼬리표>_full.txt   : 주어진 문장 + 지문(답 없음) — 답을 모르는 채로 풀기
#      - <꼬리표>_skip.txt   : 주어진 문장을 뺀 지문 — 건너뛴 곳 찾기
#      - <꼬리표>_explain.txt: 답 + 해석 + 풀이 + 자리별 해설 — 해설 교정
import sys, re, os, importlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import load
T = '38_39'; C = '①②③④⑤'
STOP = set('a an the and or but of to in on at by for from with without into onto up down out off over under after before between next his her him she he it its they them their this that these those was were is are be been had has have did do does not no so as than then there here very one two also only even all some any every each last first new old few more most much many little now still again just'.split())
def stem(w):
    for suf in ('ing', 'ed', 'es', 's'):
        if w.endswith(suf) and len(w) - len(suf) >= 3: return w[:-len(suf)]
    return w
def words(s): return {stem(w) for w in re.findall(r"[a-z]+", s.lower().replace("'s", "")) if w not in STOP and len(w) > 2}
def split(text):
    m = re.match(r'^\[삽입할 문장\] (.*?)\n\n(.*)$', text, re.S); assert m, '지문 꼴'
    parts = [x.strip() for x in re.split(r'\( [①②③④⑤] \)', m.group(2))]; assert len(parts) == 6 and not parts[5], '자리 다섯(⑤ 뒤는 비어 있어야 함)'
    return m.group(1).strip(), parts[:5]
def lay(ins, P): return "[삽입할 문장] " + ins + "\n\n" + " ".join(P[k] + " ( %s )" % C[k] for k in range(5))

def match(mod, lv, lo, hi, nsent=6):
    _, tb, _ = load()
    d, name = os.path.split(mod)
    if d: sys.path.insert(0, d)
    M = importlib.import_module(name); items = {}
    for n in range(lo, hi):
        if hasattr(M, 'I'): ins, P, a = M.I[n]
        else: R = M.E[(T, lv, n)]['rewrite']; ins, P = split(R['text']); a = R.get('answer', tb[T][lv][n]['answer']) + 1   # 정답 자리를 옮긴 문항은 수정안의 답
        items[n] = (ins, P, a)
    ok1 = ok2 = uniq = 0; key = ''; texts = {}
    for n, (ins, P, a) in sorted(items.items()):
        wi = words(ins); B = [len(wi & words(P[k])) for k in range(5)]         # 자리 k+1의 앞 문장 = P[k]
        A = [len(wi & words(P[k + 1])) if k < 4 else 0 for k in range(5)]     # 자리 k+1의 뒤 문장 = P[k+1]
        sc = [B[k] + A[k] for k in range(5)]; p1 = sc.index(max(sc)) + 1; p2 = B.index(max(B)) + 1
        ok1 += p1 == a; ok2 += p2 == a; uniq += sc[a - 1] == max(sc) and sc.count(max(sc)) == 1
        print('%2d번째 답 %s · 겹치는 낱말(앞+뒤) %s · 낱말 맞추기가 고르는 자리 %s%s' % (n + 1, C[a - 1], sc, C[p1 - 1], '  ← 답과 같음' if p1 == a else ''))
        texts[n] = (lay(ins, P), C[a - 1]); key += str(a)
    print('낱말 맞추기(앞+뒤)로 맞는 문항 %d/%d · 앞 문장만으로 %d/%d · 답 자리가 혼자 가장 많이 겹치는 문항 %d' % (ok1, len(items), ok2, len(items), uniq)); print('정답 줄', key)
    # 자리 규칙으로 찍기: 가리키는 말(this/that/these/those + 낱말 — These days는 뺌)이 든 지문 문장의 바로 앞 자리를 고르면 몇 문항이 맞나
    DEM = re.compile(r"\b(this|that|these|those)\s+(?!days\b)[a-z]", re.I)
    hit = {'첫': [], '둘째': [], '마지막': []}; none = []
    for n, (ins, P, a) in sorted(items.items()):
        ix = [k for k in range(1, 5) if DEM.search(P[k])]          # P[k]의 바로 앞 자리 = k (1~4). 첫 문장 P[0] 앞에는 자리가 없음
        if not ix: none.append(n + 1); continue
        if ix[0] == a: hit['첫'].append(n + 1)
        if len(ix) > 1 and ix[1] == a: hit['둘째'].append(n + 1)
        if ix[-1] == a: hit['마지막'].append(n + 1)
    print('자리 규칙(가리키는 말이 든 문장의 바로 앞 자리): ' + ' · '.join('%s 문장 %d/%d %s' % (k, len(v), len(items), v) for k, v in hit.items()) + (' · 가리키는 말이 없는 문항 %s' % none if none else ''))
    from zlevel import check_texts
    check_texts(T, lv, texts, nsent)

def sheets(lv, lo, hi, folder, tag):
    s, tb, te = load(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'out', 'index.html'))
    f = open(os.path.join(folder, tag + '_full.txt'), 'w', encoding='utf-8'); g = open(os.path.join(folder, tag + '_skip.txt'), 'w', encoding='utf-8')
    h = open(os.path.join(folder, tag + '_explain.txt'), 'w', encoding='utf-8'); key = ''
    for n in range(lo, hi):
        it = tb[T][lv][n]; ex = te[T][lv][n]; ins, P = split(it['text']); key += str(it['answer'] + 1)
        f.write('[%d] 글의 흐름으로 보아, 주어진 문장이 들어가기에 가장 적절한 곳은?\n%s\n\n' % (n + 1, it['text'].replace('[삽입할 문장]', '[주어진 문장]')))
        g.write('[%d]\n%s\n\n' % (n + 1, ' '.join(P)))
        h.write('=== [%d] 정답 %s ===\n%s\n\n[해석]\n%s\n\n[풀이]\n%s\n\n[자리별 해설]\n%s\n\n' % (n + 1, C[it['answer']], it['text'], ex['ko'], ex['walk'].split('【이 문제에 적용】')[-1].strip(), '\n'.join(ex['cn'])))
    print('문제지 셋을 씀:', folder, tag, '· 정답 줄', key)

if __name__ == '__main__':
    a = sys.argv[1:]
    if a and a[0] == 'match': match(a[1], a[2], int(a[3]), int(a[4]), int(a[5]) if len(a) > 5 else 6)
    elif a and a[0] == 'sheets': sheets(a[1], int(a[2]), int(a[3]), a[4], a[5])
    else: print(__doc__ or '쓰는 법은 파일 머리의 주석을 볼 것')
