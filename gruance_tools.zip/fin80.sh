#!/bin/bash
# 363번: 22번 레벨1 — GitHub 최신본을 받아 그 위에 X79만 얹어 빌드 (선생님 말씀 10-12 17:28 「GitHub 최신본 위에 얹어 줘」)
cd /home/claude/Gruance-English && git pull -q --rebase && echo "바탕: $(git log --oneline -1)" || exit 1
cd /home/claude/work
python3 draft/gen80.py a && python3 draft/gen80.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X79a.py pending/edits_X79b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X79a,edits_X79b out/index.html | tail -3
