#!/bin/bash
# 371번: 25번 레벨1 — GitHub 최신본을 받아 그 위에 X87만 얹어 빌드
cd /home/claude/Gruance-English && git pull -q --rebase && echo "바탕: $(git log --oneline -1)" || exit 1
cd /home/claude/work
python3 draft/gen88.py a && python3 draft/gen88.py b || exit 1
PYTHONPATH=pending python3 zjosa2.py --strict --fix pending/edits_X87a.py pending/edits_X87b.py | tail -3
PYTHONPATH=pending python3 build.py edits_X87a,edits_X87b out/index.html | tail -3
