# 349번 이후: 풀이꾼 답안 채점. python3 score69.py <폴더>
import sys,re,importlib.util
sys.path.insert(0,'/home/claude/work')
from lib import load
_,tb,_=load('/home/claude/Gruance-English/index.html')
key={n:tb['31']['1'][n]['answer']+1 for n in range(30)}
d=sys.argv[1]
def parse(p):
    r={}
    try:
        for l in open(p,encoding='utf-8'):
            m=re.match(r'\s*(\d+)\s+(\d)\s+(\w+)(.*)',l)
            if m: r[int(m.group(1))-1]=(int(m.group(2)),m.group(3),m.group(4).strip())
    except FileNotFoundError: pass
    return r
for name in ('last1','last2','last','blind'):
    r=parse('%s/ans_%s.txt'%(d,name))
    if not r: continue
    ok=[n+1 for n in r if r[n][0]==key[n]]; sure=[n+1 for n in r if r[n][1]=='sure']; sok=[n for n in sure if r[n-1][0]==key[n-1]]
    print('%-6s 맞힘 %2d/30 · 확신 %d (맞힘 %d) · 맞힌 번호 %s'%(name,len(ok),len(sure),len(sok),ok if name!='blind' else ''))
    if name=='blind':
        for n in sorted(r):
            if r[n][0]!=key[n] or r[n][1]!='high' or r[n][2]: print('   blind',n+1,r[n],'key',key[n])
